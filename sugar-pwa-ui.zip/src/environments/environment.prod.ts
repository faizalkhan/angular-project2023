export const environment = {
  production: true,
  apiUrl : "https://mobiledevcloud.dalmiabharat.com/sugar_pwa"
};

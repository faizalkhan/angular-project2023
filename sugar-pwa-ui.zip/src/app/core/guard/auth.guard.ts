import { HttpParams } from '@angular/common/http';
import { Injectable, ViewChild } from '@angular/core';
import { CanLoad, Router, Route, UrlSegment, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/auth/service/auth.service';
import { LoadingService } from '../services/shared/loading.service';
import { StorageService } from '../services/storage/storage.service';


@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanLoad {

  public authLink: any;
  public qu: any;
  public authNumber: any
  public paramValue: any;
  constructor(private _toaster: ToastrService, private _route: ActivatedRoute, private _authService: AuthService,
    private _router: Router, private _storage: StorageService, private _loading: LoadingService) {
  }

  canLoad(route: Route, segments: UrlSegment[]): any {

    this._storage.deleteToken();
    const url = window.location.href;
    let paramValue;
    if (url.includes('?')) {
      const httpParams = new HttpParams({ fromString: url.split('?')[1] });
      this.paramValue = httpParams.get('qu');
      this.paramValue = encodeURIComponent(this.paramValue);
    }
    else {
      const httpParams = new HttpParams({ fromString: url.split('?')[1] });
      this.paramValue = httpParams.delete('qu');
    }

    if (!this._authService.isLoggedIn() && (this.paramValue == null || this.paramValue === "null" || this.paramValue == undefined || this.paramValue == '')) {

      return true;
    }
    else {
      if (this.paramValue) {
        this._authService.login({ qu: this.paramValue }).subscribe((data: any) => {
          if(Object.keys(data.body.data).length === 0)
          {
            this._toaster.error("Customer data is not available");
          }         
          this._storage.customerCode = data?.body?.data?.customerCode;
          this._router.navigate(['mycontracts']);
        })
      }
      else {
        return true;
      }
    }
  }
}
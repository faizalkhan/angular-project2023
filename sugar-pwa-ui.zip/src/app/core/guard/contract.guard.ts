import { Injectable } from '@angular/core';
import { CanLoad, Router, Route, UrlSegment} from '@angular/router';
import { StorageService } from '../services/storage/storage.service';

@Injectable({
  providedIn: 'root'
})
export class ContractGuard implements CanLoad {
  constructor(private _router: Router, private _storage : StorageService ) {  }
  canLoad(route: Route, segments: UrlSegment[]): any{
    if(this._storage.customerCode)
    {        
      return true;
    }
    
    else
    {
      this._router.navigate(['auth/login']);
      return false;
    }
    }
}
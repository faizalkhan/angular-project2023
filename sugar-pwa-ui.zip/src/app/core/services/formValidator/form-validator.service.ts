import { Injectable } from '@angular/core';
import { AbstractControl, FormGroup, ValidationErrors, ValidatorFn } from '@angular/forms';
import { ONLY_NUMBERS_REGEX } from '../constants';

@Injectable({
  providedIn: 'root'
})
export class FormValidatorService {

  constructor() { }


  nameValidator(qtys:any): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => { 
      let qty =  qtys;
      //const isValid = control.value;
      return   null;
    };
    
  }

  negativeValidation(control: AbstractControl): ValidationErrors | null  {
      if (control.value < 0) {
        return { 'negativeValue': 'Negative values are not allowed' }
      } 
      return null;
  }

  noDecimalsValidation (control: AbstractControl) : any {
    if(control.value > 0) {
      const value = !ONLY_NUMBERS_REGEX.test(control.value);
      return value ? { 'gstPattern':'Input should not be Decimals' } : null;
    }
  }
}

import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable()

export class ContractService {

  private contractSource = new BehaviorSubject('');
  currentContract = this.contractSource.asObservable();
  contractData:any = [];
  contractRemove : any =[];

  constructor() { }

  
  changeContract(message:any) {
    this.contractSource.next(message);
     this.contractData = message;
  }

}
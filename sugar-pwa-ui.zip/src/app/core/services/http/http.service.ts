import { Injectable } from '@angular/core';
import { environment } from './../../../../environments/environment';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http'
import { ApiMethod, Endpoints, ErrorCodes, colorCodes, SuccessCodes, ErrorMessage, ErrorKeys } from './../constants';
import { throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { StorageService } from './../storage/storage.service';

import { PromptService } from '../../modules/shared/components/prompt/prompt.service';
import { QueryParamsService } from '../queryParams/query-params.service';

import { SnackbarService } from '../snackBar/snackbar.service';



@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(
    private http: HttpClient,
    private _storageService: StorageService,
    private _queryParams: QueryParamsService,
    private _PromptService: PromptService,
    private _snackBar: SnackbarService
  ) { }

  requestCall(api: Endpoints, method: ApiMethod, data?: any) {
    let response;
    switch (method) {

      case ApiMethod.GET:
        response = this.http.get(`${environment.apiUrl}${api}`)
          .pipe(catchError((err) => this.handleError(err, this)));
        break;

      case ApiMethod.GETPARAMS:
        let reqParams = this._queryParams.getParams(data);
        response = this.http.get(`${environment.apiUrl}${api}`, { params: reqParams })
          .pipe(catchError((err) => this.handleError(err, this)));
        break;
      case ApiMethod.SEARCHDOWNLOADPARAMS:
        response = this.http.get(`${environment.apiUrl}${api}`, { 
          headers: new HttpHeaders({}),
          responseType: 'text',
          params: data
        }).pipe(catchError((err) => this.handleError(err, this)));
        break;

      case ApiMethod.SEARCHPARAMS:
        response = this.http.get<any>(`${environment.apiUrl}${api}`, { params: data })
          .pipe(catchError((err) => this.handleError(err, this)));
        break;

      case ApiMethod.POST:
        response = this.http.post(`${environment.apiUrl}${api}`, data)
          .pipe(catchError((err) => this.handleError(err, this)));
        break;

      case ApiMethod.PUT:
        response = this.http.put(`${environment.apiUrl}${api}`, data)
          .pipe(catchError((err) => this.handleError(err, this)));
        break;

      case ApiMethod.DELETE:
        response = this.http.delete(`${environment.apiUrl}${api}`)
          .pipe(catchError((err) => this.handleError(err, this)));
        break;

      case ApiMethod.DOWNLOAD:
        response = this.http.get(`${environment.apiUrl}${api}`, {
          headers: new HttpHeaders({}),
          responseType: 'text'
        })
          .pipe(catchError((err) => this.handleError(err, this)));
        break;

      case ApiMethod.DOWNLOAD_PARAMS:
        let downloadParams = this._queryParams.getParams(data);
        response = this.http.get(`${environment.apiUrl}${api}`, { 
          headers: new HttpHeaders({}),
          responseType: 'text',
          params: downloadParams
        }).pipe(catchError((err) => this.handleError(err, this)));
        break;

        case ApiMethod.DOWNLOAD_BLOB:
          response = this.http.get(`${environment.apiUrl}${api}`, {
            headers: new HttpHeaders({}),
            responseType: 'blob'
          })
            .pipe(catchError((err) => this.handleError(err, this)));
          break;
      default:
        break;

    }
    return response;

  }

  handleError(error: HttpErrorResponse, self:any):any {
    if (error.error instanceof ErrorEvent) {
      console.error('Error occured', error.error.message);
    }
    else {
        
    }
  }

  whichSuccess(successCode: number, successMessage: string) { 
    switch(successCode) {
      case SuccessCodes.HTTP_200_OK:
        this._snackBar.loadSnackBar('Success! Request completed successfully', colorCodes.SUCCESS);
        break;

      case SuccessCodes.HTTP_201_CREATED:
        this._snackBar.loadSnackBar('Success! Created successfully', colorCodes.SUCCESS);
        break;

      default:
        this._snackBar.loadSnackBar('Success! Request completed successfully', colorCodes.SUCCESS);
    }
  }



}

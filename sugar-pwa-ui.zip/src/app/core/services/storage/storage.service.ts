import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class StorageService {

  public customerCode:any;

  public authLink:any;
  public authNumber :any;
  public removeItems:any;
  indexValue:any;

  constructor(private _router: Router) { }
 

  setToken(token:string):void {
    localStorage.setItem('token', token)
  }
  setRefreshToken(refreshToken:string):void {
    localStorage.setItem('refreshToken', refreshToken)
  }

  setCustomerCode(customerCode:any):void{
    localStorage.setItem('customerCode', customerCode)
  }
  setParamValue(paramValue:any):void{
    localStorage.setItem('paramValue', paramValue);
  }
  getParamValue() {
    return !!localStorage.getItem('paramValue');
  }
  getCustomerCode() {
    return localStorage.getItem('customerCode');
  }
// purpose to checking in guards 

  getToken() {
    return localStorage.getItem('token');
  }

  getRefreshToken() {
    return localStorage.getItem('refreshToken');
  }
  
  deleteToken():void {
    localStorage.removeItem('token');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('customerCode'); 
    localStorage.removeItem('paramValue');   
  }


  




  clearStorageRedirect() {
    this.deleteToken();
    this._router.navigate(['auth']);
  }
  
 

  notFoundRedirect() {
    this._router.navigate(['404']);
  }

}

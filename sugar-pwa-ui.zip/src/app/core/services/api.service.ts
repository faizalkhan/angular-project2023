import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from "@angular/common/http";
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private httpclient: HttpClient) { }
  
  getMethod(webURL: any) {
    const apiurl =  webURL;   
    return this.httpclient.get<HttpResponse<Object>>(apiurl);
  }

  getMethodwithToken(webURL: any, token: any) {
    const apiurl =  webURL;  
    return this.httpclient.get<HttpResponse<Object>>(apiurl);
  }
  
  postMethod(endurl:any, payload:any) {
    const apiurl =  endurl;
    return this.httpclient.post(apiurl, JSON.stringify(payload));
  }
  postMethodwithToken(endurl:any, payload:any, token: any) { 
    const apiurl = endurl;
    return this.httpclient.post<HttpResponse<Object>>(apiurl, JSON.stringify(payload));
  }
  
  formDataPostMethod(webURL: any, webParams: any, token: any) {
       return this.httpclient.post<HttpResponse<Object>>(webURL, webParams);
  }
  
  getDocument(webURL: any): Observable<Blob> {
    const apiurl = webURL;   
    return <any>this.httpclient.get(apiurl);
  }
  
  deleteMethod(webURL: any, token: any) {
    const apiurl =  webURL;   
    return this.httpclient.delete<HttpResponse<Object>>(apiurl);
  }
}

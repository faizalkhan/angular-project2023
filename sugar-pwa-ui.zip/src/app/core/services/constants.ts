
export enum ApiMethod {
  GET = "GET",
  POST = "POST",
  PUT = "PUT",
  DELETE = "DELETE",
  DOWNLOAD = "DOWNLOAD",
  GETPARAMS = "GETPARAMS",
  SEARCHDOWNLOADPARAMS = "SEARCHDOWNLOADPARAMS",
  SEARCHPARAMS = "SEARCHPARAMS",
  DOWNLOAD_PARAMS = "DOWNLOAD_PARAMS",
  DOWNLOAD_BLOB = "DOWNLOAD_BLOB"
}



export enum Endpoints {
  // LOGIN = "/rest-auth/login/",
  LOGIN = "/customerAuth/getCustomerCode?qu=",
  
  AUTH = "/customerAuth/getAuthData",
  ALLCONTRACT = "/contract/getAllContracts",
  GETCONTRACT = "/contract/getContract/",
  ORDERCONTRACT = "/contract/contractso/"
  
 }

export enum SuccessCodes {
  HTTP_200_OK = 200, 
  HTTP_201_CREATED = 201,
  HTTP_202_ACCEPTED = 202,
}

export enum ErrorCodes {
  HTTP_400_BAD_REQUEST = 400,
  HTTP_401_UNAUTHORIZED = 401,
  HTTP_403_FORBIDDEN = 403,
  HTTP_404_NOT_FOUND = 404,
  HTTP_500_ERROR = 500,
  HTTP_CONN_REFUSED = 0,
}
export enum ErrorKeys {
  NON_FIELD_ERRORS = 'non_field_errors'
}

export enum colorCodes {
  SUCCESS = "Success",
  WARNING = "Warning",
  ERROR = "Error",
  INFO = "Info"
}




















export const EMAIL_ID_REGEX = /^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;

export const ONLY_NUMBERS_REGEX = /^\d+$/





export const BECKMAN_GODOWN = "Tamil Nadu"
export const SHIPPING ="shipping";
export const BILLING = "billing";
export const BILL_TO = "bill_to";
export const SHIP_TO = "ship_to";






export enum SuccessMessage {


}
export enum ErrorMessage  {

}


export const CreditDebitControls  = {
  issuance_comment: 'Issuance Comment',
  tax : 'Tax',
  edit_line : 'Edit Line',
  cp_bill_to : 'CP Bill To',
  cp_ship_to : 'CP Ship To'
}

export const OtlTransferControls  = {
   otl_transfer_add : 'Add',
  otl_transfer_export : 'Export'
 
}
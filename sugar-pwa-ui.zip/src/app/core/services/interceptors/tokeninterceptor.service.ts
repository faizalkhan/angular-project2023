import { catchError, switchMap, filter, take, finalize, tap } from 'rxjs/operators';
import { Injectable, Injector } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { StorageService } from './../storage/storage.service';
import { Observable, throwError, BehaviorSubject, of } from 'rxjs';
import { Router } from '@angular/router';
import { HttpService } from '../http/http.service';
import { ToastrService } from 'ngx-toastr';
import { ErrorMessage, Endpoints } from '../constants';
import { environment } from '../../../../environments/environment';
import { AuthService } from 'src/app/auth/service/auth.service';

@Injectable({
  providedIn: 'root'
})
export class TokeninterceptorService implements HttpInterceptor {
  constructor(
    private _toaster: ToastrService,
    private _storage: StorageService,
    private _authService: AuthService,
    private router: Router,
    private _http: HttpService,

  ) { }
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let apiUrl = environment.apiUrl + request.url;
    if (localStorage.getItem('token') != null) {
      const token: any = localStorage.getItem('token');
      const headers = new HttpHeaders().set("Authorization", token);
      const AuthRequest = request.clone({ headers: headers, url: apiUrl });
      return next.handle(AuthRequest)
    }
    else {      
      const AuthRequest = request.clone({ url: apiUrl });
      return next.handle(AuthRequest).pipe(
        tap(res => {
          if (res instanceof HttpResponse) {
            if (res.headers.has('token')) {
              let authtoken: any = res.headers.get('token');
              this._storage.setToken(authtoken);
              this._storage.setCustomerCode(res.body.data.customerCode);
            }
          }
        },
          (err: any) => {
            if (err instanceof HttpErrorResponse) {
              if (err.status == 401) {
                this._toaster.error(err.error);
                this._storage.deleteToken();
                this.router.navigate(['auth/login']);
              }
              if (err.status !== 401) {
                return;
              }
              this._toaster.error(err.error);
              this._storage.deleteToken();
              this.router.navigate(['auth/login']);
            }
            if (err instanceof HttpErrorResponse && err.status == 500) {

              this._toaster.error(err.error);
              this._storage.deleteToken();
              this.router.navigate(['auth/login']);
             }
          }),
        catchError((err: any) => {
          this._toaster.error("Server not available");
          this.router.navigate(['auth/login']);
          return of(err);
        }));
    }
  }
}
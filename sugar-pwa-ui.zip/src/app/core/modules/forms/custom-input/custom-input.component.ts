import { Component, OnInit, EventEmitter, Output, Input, ViewEncapsulation } from '@angular/core';
import { AbstractControl, ValidationErrors } from '@angular/forms';
import { PromptService } from '../../shared/components/prompt/prompt.service';

@Component({
  selector: 'app-custom-input',
  templateUrl: './custom-input.component.html',
  styleUrls: ['./custom-input.component.css'],
  encapsulation:ViewEncapsulation.None
})
export class CustomInputComponent implements OnInit {
  @Output() valueChanges: EventEmitter<any> = new EventEmitter<any>();
  @Output() focusOut: EventEmitter<any> = new EventEmitter<any>();
  @Input() formInnerControlName:any;
  @Input() parentForm:any;
  @Input() type:any;
  @Input() qty:any;
  @Input() label:any;
  @Input() placeholder:any;
  @Input() max :any;
  @Input() min:any;
  @Input() readonly:any;
  @Input() fieldMaxLength:any;
  @Input() inputValue:any;
  @Input() opfValue:any;
  @Input() qtys:any;
  currentValue: any;
  opfLength: any;
  difference: any

  constructor(private _PromptService:PromptService) { }
  ngOnInit(): void {   
      this.min = this.min ? this.min : 0;
      if(this.inputValue){
      this.currentValue = this.inputValue;
    }
    if(this.opfValue){
      this.opfLength = this.opfValue+1;
      this.difference = Math.abs(36-this.opfLength);
      this.fieldMaxLength = this.difference;
    }
    if (this.valueChanges.observers.length > 0){
      this.parentForm.get(this.formInnerControlName).valueChanges.subscribe((response:any) => { 
        this.valueChanges.emit(response);
       })
    }   
  }
  onBlurChanges(event:any){    
    if(event)
    {
      //this.parentForm.get(this.formInnerControlName).setValue(event); 
      if(parseInt(event) <= parseInt(this.qtys))    {
        this.focusOut.emit({event : event, qty:this.qtys})        
      }
      else
      {
        this.focusOut.emit({event : event, qty:this.qtys})
        this.popup();         
      }   
    }   
  }
  get validator() {
    const validator = this.parentForm.get(this.formInnerControlName).validator ? this.parentForm.get(this.formInnerControlName).validator({} as AbstractControl) : '';
    if (validator && validator.required) {
      return true;
    }
    return false
  }
  
  popup()
  {
    this._PromptService.openDialog({title : 'INSUFFICIENT BALANCE!', 
    type : false,
    status : false,
    btnLabel : 'OK',
     content: 'Your Order Value is more than your available balance. Please make additional payment or edit order'},'')
  } 
}

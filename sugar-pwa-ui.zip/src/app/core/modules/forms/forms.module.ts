import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule} from '../material/material.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CustomInputComponent } from './custom-input/custom-input.component';;



@NgModule({
  declarations: [CustomInputComponent],
  imports: [
    CommonModule,
    MaterialModule,
    ReactiveFormsModule,
    FormsModule
  ],
  exports:[CustomInputComponent,ReactiveFormsModule,FormsModule]
})
export class CustomFormsModule { }

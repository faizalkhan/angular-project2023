import { Injectable } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Endpoints, ApiMethod, SuccessCodes, colorCodes } from 'src/app/core/services/constants';
import { BehaviorSubject } from 'rxjs';
import { tap } from 'rxjs/operators';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { HttpService } from 'src/app/core/services/http/http.service';
import { LoginPayload } from '../interface/auth';


import { HttpClient, HttpErrorResponse } from "@angular/common/http";


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  user$ = new BehaviorSubject(null);
  private redirectUrl:any;
  constructor(
     private _router: Router,
     private _route: ActivatedRoute,
     private _storage : StorageService,
    // private _http: HttpService,
     private _httpClient: HttpClient
  ) { }


  isLoggedIn() {
    return !!this._storage.getToken();
  }

 


  auth() {

    return this._httpClient.get(Endpoints.AUTH);

  }

  login(loginPayload: any) {

    return this._httpClient.get(Endpoints.LOGIN + loginPayload.qu, {observe:'response'});

  }


  getcontractlist(customerCode: any) {
    
      return this._httpClient.post(Endpoints.ALLCONTRACT, { customerCode: customerCode}, {observe:'response'});

  }

  getcontractdetail(contractId: any, customerCode:any) {
    
  
    return this._httpClient.post(Endpoints.GETCONTRACT + contractId, { customerCode: customerCode}, {observe:'response'});

  }

  contractOrder(contractOrderPayload:any) {
    
  
    return this._httpClient.post(Endpoints.ORDERCONTRACT, contractOrderPayload, {observe:'response'});

  }

}

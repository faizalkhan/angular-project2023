export interface LoginPayload {
    token: string;
}
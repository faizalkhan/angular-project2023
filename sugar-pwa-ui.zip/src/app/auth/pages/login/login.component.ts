import { Component, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { LoadingService } from 'src/app/core/services/shared/loading.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { AuthService } from '../../service/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  isLoading:boolean = false;
  authLink:any;
  authNumber :any;

  constructor(private _authService: AuthService, private _loading: LoadingService) { }

  ngOnInit(): void {
   
    this._authService.auth().subscribe((data:any):any =>
    {
      if(data)
      {
         this.authLink = data.authLink;
        this.authNumber= data.authNumber;       
     
      }    
            
    });    

  }
 
  gotoDalmia() : void {
    window.open("https://www.dalmia.com/web", "_blank");
  }

  
}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContractDetailComponent } from './contract-detail/contract-detail.component';
import { ContractListsComponent } from './contract-lists/contract-lists.component';
import { ContractOrderComponent } from './contract-order/contract-order.component';

import { MycontractsComponent } from './mycontracts.component';

const routes: Routes = [
  {
    path : '',
    component : MycontractsComponent,
    children : [
      {
        path : '', component : ContractListsComponent
      },
      {
        path : 'view/:id', component : ContractDetailComponent
      },
      {
        path : 'order/:id', component : ContractOrderComponent
      },
      
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MycontractsRoutingModule { }

import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/auth/service/auth.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { ContractService } from 'src/app/core/services/shared/contract.services';
import { StorageService } from 'src/app/core/services/storage/storage.service';

@Component({
  selector: 'app-contract-order',
  templateUrl: './contract-order.component.html',
  styleUrls: ['./contract-order.component.css']
})
export class ContractOrderComponent implements OnInit {


  public contractForm!: FormGroup;
  public searchText: any;
  public contractdetails: any = []
  public orderQuantity: any;
  public orderTotal: any;
  public contractQty: any;
  customerCode: any;
  contractId: any;
  public contractIncoTerm: any;
  public contGSTMessage: any;
  constructor(private _router: Router, private activatedRoute: ActivatedRoute, private _storage: StorageService, private _authService: AuthService, private _contractService: ContractService, private _PromptService: PromptService, private fb: FormBuilder, private _FormValidatorService: FormValidatorService) { }

  ngOnInit(): void {
     this.contractId = this.activatedRoute.snapshot?.paramMap.get('id');
    this._contractService.currentContract.subscribe((res: any) => {
      this.orderTotal = res[0].totalSalesAmounts ? res[0].totalSalesAmounts : 0;
      this.contractdetails = res[1];
      this.contGSTMessage = res[1].contGSTMessage;
      this.orderQuantity = this.contractdetails.reduce((sum: any, current: any) => sum + current.SelectedQty, 0);
    });



    this.contractForm = this.fb.group(
      {
        contractQty: ['', [this._FormValidatorService.negativeValidation, Validators.required]]
      }
    )
    for (let index = 0; index < this.contractdetails.length; index++) {
      this.contractForm.addControl('contractQty' + index, new FormControl(''))
    }
  }

  placeOrder() {
    let payload: any = {};
    payload['customerCode'] = this._storage.getCustomerCode();
    payload['contractNo'] = this.contractId;
    payload['ordType'] = "ZSPS";
    let items = [];
    for (let index = 0; index < this.contractdetails.length; index++) {
      let item: any = {};
      item['itemNo'] = this.contractdetails[index].contOrderItmno;
      item['material'] = this.contractdetails[index].contOrderProduct;
      item['qty'] = this.contractdetails[index].SelectedQty ? this.contractdetails[index].SelectedQty : 0;
      items.push(item);

    }
    payload['item'] = items;
    this._authService.contractOrder(payload).subscribe((res: any) => {
      let id: any = res.body.salesdocument;
      let remark: any = res.body.remark;
      let trackLink = res.body.trackLink;
      this.contGSTMessage = res.body.contGSTMessage;
      this.orderTotal = this.orderTotal ? this.orderTotal : 0;
      if (res.body.error && res.body.error.length > 0) {
        this._PromptService.openDialog({
          title: 'ORDER NOT CREATED',
          url: this.redirecturl,

          btnLabel: 'OK',
          type: false,
          status: false,
          content: `${res.body.error[0].message}`
        })
      }

      else {
        this._PromptService.openDialog({ title: 'ORDER CONFIRMED!', url: this.redirecturl, type: true, btnLabel1: 'CLOSE', status: false, content: `Your Order for ${this.orderQuantity} items 0f <b class="amount-value"> ₹ ${this.orderTotal}/- </b> (${this.contGSTMessage}) has been confirmed. Your order ID is <b>${id}.</b> You can track the same via whatsapp @ <a class="cursor-pointer" href ='http://${trackLink}' target="_blank"> ${trackLink} </a>` })
      }

    })

  }

  checkItem = (index: any) => {
     let result:any =[];
    result =  this.contractdetails.splice(index, 1);    
    console.log(this._contractService.contractData)
   // this._contractService.contractData[1].push(result[0]);

   for(var i =0; i < result.length; i++)
   {
    this._contractService.contractRemove.push(result[i]);
   }
 
   
 

  

    this.orderTotal = this.contractdetails.reduce((sum: any, current: any) => sum + current.Totalamount, 0);
    this.orderQuantity = this.contractdetails.reduce((sum: any, current: any) => sum + current.SelectedQty, 0);
  }

  redirecturl = () => {

    this._router.navigate(['/mycontracts/']);
  }
  removeItem(index: any) {

    this._PromptService.openDialog({ index: index, function: this.checkItem, type: false, status: true, btnLabel: 'REMOVE', btnLabel1: 'CANCEL', content: 'Are you sure you want to remove the Selected Item?' });

  }
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractOrderComponent } from './contract-order.component';

describe('ContractOrderComponent', () => {
  let component: ContractOrderComponent;
  let fixture: ComponentFixture<ContractOrderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContractOrderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

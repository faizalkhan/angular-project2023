import { Component, Inject, OnDestroy, OnInit } from "@angular/core";
import { ICellRendererAngularComp } from "ag-grid-angular";
import { IAfterGuiAttachedParams } from "ag-grid-community";



@Component({
  selector: "btn-cell-renderer",
  template: `
    <button mat-raised-button color="primary" (click)="btnClickedHandler($event)">Place Order</button>
  `,
  styles : [ `.cursor-pointer { cursor: pointer; }`]
})
export class BtnCellRenderer implements ICellRendererAngularComp, OnDestroy {

  public isSelected = false;
  constructor( )
  {

  }
  refresh(params: any): boolean {
    throw new Error("Method not implemented.");
  }
  afterGuiAttached?(params?: IAfterGuiAttachedParams): void {
    throw new Error("Method not implemented.");
  }
  private params: any;

  agInit(params: any): void {
    this.params = params;
  }

  btnClickedHandler(event:any) {
  
    this.params.clicked(this.params.value);
    this.isSelected = true;
    //this.dialog.open(MycontractsComponent, { data : { video: this.params.value } } )     
    
  }

  ngOnDestroy() {
    
  }
}




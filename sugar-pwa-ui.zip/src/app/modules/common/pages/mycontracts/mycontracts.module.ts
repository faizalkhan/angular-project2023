import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MycontractsComponent } from './mycontracts.component';
import { MycontractsRoutingModule } from './mycontracts-routing.module';
import { FormsModule } from '@angular/forms';
import { AgGridModule } from 'ag-grid-angular';
import { LayoutModule } from 'src/app/layout/layout.module';
import { MaterialModule } from 'src/app/core/modules/material/material.module';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { BtnCellRenderer } from './btn-cell-renderer.component';
import { ContractOrderComponent } from './contract-order/contract-order.component';
import { ContractListsComponent } from './contract-lists/contract-lists.component';
import { ContractDetailComponent } from './contract-detail/contract-detail.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';

@NgModule({
  declarations: [ 
    MycontractsComponent,
    ContractListsComponent,
    ContractOrderComponent,
    ContractDetailComponent,   
    BtnCellRenderer],
  imports: [
    CommonModule,
    AgGridModule.withComponents([BtnCellRenderer]),
    MycontractsRoutingModule,
    LayoutModule,
    MaterialModule,
    FormsModule,
    CustomFormsModule,
    Ng2SearchPipeModule
   
  ]
})
export class MycontractsModule { }

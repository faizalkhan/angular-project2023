import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { IGetRowsParams } from 'ag-grid-community';
import * as moment from 'moment';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { BtnCellRenderer } from './btn-cell-renderer.component';
@Component({
  selector: 'app-mycontracts',
  templateUrl: './mycontracts.component.html',
  styleUrls: ['./mycontracts.component.css'],
 
})
export class MycontractsComponent implements OnInit {
  ngOnInit(): void {
    
  }
  

}

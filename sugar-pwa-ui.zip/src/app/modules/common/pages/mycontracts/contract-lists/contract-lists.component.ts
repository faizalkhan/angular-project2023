import { Component, ElementRef, HostListener, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { IGetRowsParams, PaginationChangedEvent, RowSelectedEvent, SelectionChangedEvent } from 'ag-grid-community';
import * as moment from 'moment';
import { AgGridRouterComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-router.component';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { BtnCellRenderer } from '../btn-cell-renderer.component';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth/service/auth.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { ContractService } from 'src/app/core/services/shared/contract.services';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-contract-lists',
  templateUrl: './contract-lists.component.html',
  styleUrls: ['./contract-lists.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ContractListsComponent implements OnInit {
  @ViewChild('url') url!: ElementRef;
  @ViewChild('contractLists') contractLists!: any;
  public gridOptions: any;
  public gridApi: any;
  public gridColumnApi: any;
  public searchValue: any;
  public gridData = [];
  public columnDefs: any;
  public defaultColDef: any;
  public editOpfActionMenu = false;
  public editOpf = false;
  public pageSize = 10;
  rowHeight: any;
  rowData: any = [];
  rowindex = 0;
  contractList: any = [];
  public rowSelection = 'multiple';
  public therichpostFunction: any;
  public overlayLoadingTemplate: any;
  constructor(
    private _contractService: ContractService,
    private _momentService: MomentService,
    private _router: Router,
    private _storage: StorageService,
    private _authService: AuthService,
    private _toaster: ToastrService
  ) { }

  @HostListener('window:resize', ['$event']) onResize(event: any) {

    this.gridApi.sizeColumnsToFit();
  }
  ngOnInit() {
    this._contractService.contractData = [];
    this.rowHeight = 50;
    this.rowSelection = this.columnDefs;
    this.columnDefs = [

      {
        field: 'contOrderId',
        headerName: 'Contract ID',
        sortable: false,
        filter: false      
      },
      {
        headerName: 'Ship to Party',
        field: 'contSoldToName',
        width: 500,
        sortable: true,
        filter: false
      },

      {
        headerName: 'Incoterm',
        field: 'contIncoterm',
        filter: false,
        sortable: true     

      },
      {
        headerName: 'Contract Date',
        field: 'contOrderDate',
        sortable: true,
        filter: false,       
        cellRenderer: (params: any) => {
          return '<span class="d-flex"><i class="material-icons">date_range</i>' + moment(params.value).format("MM-DD-YYYY") + '</span>'
        }
      },
      {
        field: 'url',
        headerName: 'Action',
        sortable: false,
        filter: false,
        suppressSizeToFit: true,
        cellRenderer: AgGridRouterComponent,
        cellRendererParams: {
          inRouterLink: '/mycontracts/view/',
          navigateId: 'contOrderId'
        }
      },
    ];

    if (window.innerWidth < 767) {
      this.columnDefs = [
        {
          field: 'contOrderId',
          headerName: 'Contract Lists',
          sortable: false,
          filter: false,
          cellRenderer: (data: any) => {
            return '<b>Contract ID : </b>' + data.data.contOrderId + '<br>' + ' ' + '<b> Ship to Party : </b>' + data.data.contShipToName + '<br>' +
              '<b> Incoterm : </b>' + data.data.contIncoterm + '<br>' + ' ' + '<b> Contract Date : </b>' + '<span><i class="material-icons">date_range</i>' + data.data.contOrderDate + '<br>' +
              '<button mat-raised-button color="primary" class="primary" [routerLink]=' + data.data.contOrderId + '>' + 'Place Order' + "</button>";
          }
        }
      ];
    }
    this.gridOptions = {
      rowStyle: {
        'border-bottom': 'white 10px solid',
        'border-top': 'red 10px solid',
        'margin-bottom': '90px',
      }
    }
  }
  onRowSelected(event: RowSelectedEvent, params?: any) {
    this._contractService.contractData = [];
    this._router.navigate(['/mycontracts/view/', event.data.contOrderId]);
  }
  onPaginationChanged(event:PaginationChangedEvent, params?: any)
  {
    this.contractList.length = this.contractLists._nativeElement.getElementsByClassName('ag-center-cols-container')[0].childNodes.length;
  } 
  getContractList() {  
      this.contractList = [{
        contOrderId : 1,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
       {
        contOrderId :2,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
     {
        contOrderId : 3,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
       {
        contOrderId : 4,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
       {
        contOrderId : 5,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
     {
        contOrderId : 6,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
      {
        contOrderId : 7,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
      {
        contOrderId : 8,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
     {
        contOrderId : 9,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
      {
        contOrderId : 10,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
      {
        contOrderId : 11,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
      {
        contOrderId : 12,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
      {
        contOrderId : 13,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
      {
        contOrderId : 14,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },

      {
        contOrderId : 15,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
      {
        contOrderId : 16,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
      {
        contOrderId : 17,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
      {
        contOrderId : 18,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
      {
        contOrderId : 19,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
      {
        contOrderId : 20,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
      {
        contOrderId : 21,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
      {
        contOrderId : 22,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
      {
        contOrderId : 23,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
      {
        contOrderId : 24,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      },
      {
        contOrderId : 25,
        contSoldToName : "ff",
        contIncoterm : "sdad",
        contOrderDate : "08-04-1983"
      }

      ]
      this.gridData = this.contractList;
      this.gridApi.setRowData(this.gridData);

      
    let customerCode: any = this._storage.getCustomerCode();
    //this.onBtShowLoading();
    this._authService.getcontractlist(customerCode).subscribe((res:any) => {
      
      //this.onBtHide();
       if(res.body.length < 0)
      {
       
      }
      else
      {
        this._toaster.error("No Contract Available");
        this.onBtShowNoRows();
    
      }
   
    })
  }
  onGridReady(params: any) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.getContractList();
  }
  formatDate(params: any) {
    return params.value ? this._momentService.getDate(params.value) : ""
  }
  filterEnabled: any;
  onQuickFilterChanged(params: any) {
    let filters = params.api;      
    this.gridApi.setQuickFilter(this.searchValue);
    let filterValue = this.contractLists._nativeElement.getElementsByClassName('ag-pinned-left-cols-container')[0].style.height;
    if (filterValue < '50px') {
      this.onBtShowNoRows();
    }
    else {
      this.onBtHide()
    }
    this.gridApi.refreshCells();
  }
  onBtShowLoading() {
    this.gridApi.showLoadingOverlay();
  }
  onBtShowNoRows() {
    this.gridApi.showNoRowsOverlay();
  }
  onBtHide() {
    this.gridApi.hideOverlay();
  }
}
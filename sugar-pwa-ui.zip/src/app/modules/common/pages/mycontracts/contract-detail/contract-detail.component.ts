import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidationErrors, Validators, ValidatorFn } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/auth/service/auth.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { ContractService } from 'src/app/core/services/shared/contract.services';
import { StorageService } from 'src/app/core/services/storage/storage.service';
@Component({
  selector: 'app-contract-detail',
  templateUrl: './contract-detail.component.html',
  styleUrls: ['./contract-detail.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ContractDetailComponent implements OnInit {

  constructor(private activatedRoute: ActivatedRoute,
    private _authService: AuthService,
    private _contractService: ContractService,
    private _router: Router,
    private fb: FormBuilder,
    private _PromptService: PromptService,
    private _FormValidatorService: FormValidatorService,
    private _storage: StorageService) {
  }
  public contractForm!: FormGroup;
  public qtycheck: any;
  public searchText: any = '';
  public contractdetails: any = []
  public isMobileView: boolean = false;
  public isDesktopView: boolean = false;
  public quantityValue: any;
  public totalSalesAmount = 0;
  qty: any;
  public eventnumber: any;
  public eventqty: any;
  customerCode: any;
  public contractId: any;
  public contractDetailsdata: any = [];
  contractDetailsObj: any = {};
  public amount: any;
  public contractOrder: any;
  public contractIncoTerm: any;
  public contGSTMessage:any;


  ngOnInit(): void {


   
    this.contractForm = this.fb.group(
      {
      })
    this.contractId = this.activatedRoute.snapshot?.paramMap.get('id');
    this.customerCode = this._storage.getCustomerCode();
    if (this._contractService.contractData.length > 0 || this._contractService.contractRemove.length > 0 ) {
      if(this._contractService.contractRemove)
      {

        for(var i =0; i < this._contractService.contractRemove.length; i++)
        {
          this._contractService.contractData[1].push(this._contractService.contractRemove[i]);
        }
   
      
      }
      this.contractdetails = this._contractService.contractData[1] ?  this._contractService.contractData[1]  : this._contractService.contractData[0] ;
      this.contractOrder = this.contractId
      this.contractIncoTerm = this.contractdetails.contractIncoTerm;
      this.contGSTMessage = this.contractdetails.contGSTMessage;
      //this.contractdetails.push(this._storage.removeItems[0]);
      
      for (let index = 0; index < this.contractdetails.length; index++) {
        this.contractForm.addControl('contractQty' + index, new FormControl(this.contractdetails[index].SelectedQty, [this._FormValidatorService.negativeValidation, this._FormValidatorService.noDecimalsValidation, this._FormValidatorService.nameValidator(this.contractdetails[index].contOrderQty), Validators.required]))
      }
      this.totalSalesAmount = this.contractdetails.reduce((sum: any, current: any) => sum + current.Totalamount, 0);
    }

    else {
      this._authService.getcontractdetail(this.contractId, this.customerCode).subscribe((res: any) => {
        this.contractdetails = res?.body?.item;
        this.contractOrder = res?.body?.contOrderId;
        this.contractIncoTerm = res?.body?.contIncoterm;
        this.contGSTMessage = res?.body?.contGSTMessage;
        for (let index = 0; index < this.contractdetails.length; index++) {
          this.contractdetails[index].SelectedQty = 0;
          this.contractdetails[index].contractIncoTerm = this.contractIncoTerm;
          this.contractdetails[index].contOrderQty = 0;
          if (this.contractdetails[index].contOrderQty > 0) {
            this.contractdetails[index]['Totalamount'] = Math.floor(this.contractdetails[index].contOrderQty) * this.contractdetails[index].contCasePrice;
          }
          else {
            this.contractdetails[index]['Totalamount'] = 0;
          }
          this.contractForm.addControl('contractQty' + index, new FormControl(this.contractdetails[index].contOrderQty, [this._FormValidatorService.negativeValidation, this._FormValidatorService.noDecimalsValidation, this._FormValidatorService.nameValidator(this.contractdetails[index].contOrderQty), Validators.required]))
        }
        this.totalSalesAmount = this.contractdetails.reduce((sum: any, current: any) => sum + current.Totalamount, 0);
      })
    }
    this.quantityValue = 10;
  }

  vals(event: any, index: any) {

    this.eventnumber = event;
    this.eventqty = parseInt(event.qty);
    if (this.eventnumber.event > this.eventqty) {
      setTimeout(() => {
        this.contractForm.get('contractQty' + index)?.setValue(this.contractdetails[index].contractQty);
      }, 5);
    }
    else {
      if (this.eventnumber.event > 0) {
        this.contractdetails[index].Totalamount = Math.floor(this.contractdetails[index].contCasePrice) * this.eventnumber.event;
      }
      else {
        this.contractdetails[index].Totalamount = 0;
      }
      this.contractdetails[index].SelectedQty = this.eventnumber.event == '' ? 0 :  this.eventnumber.event;
      this.totalSalesAmount = this.contractdetails.reduce((sum: any, current: any) => sum + current.Totalamount, 0);
    }

  }
  sendContractdetails() {
    this.contractDetailsdata.push(this.contractDetailsObj);
  }
  proceed() {
    this._contractService.contractRemove =[];
    this.sendContractdetails();
    this.contractDetailsObj.totalSalesAmounts = this.totalSalesAmount;
    this.contractdetails = this.contractdetails.filter((e: any) => e.SelectedQty > 0)
    this.contractDetailsObj = this.contractdetails;

    this.contractIncoTerm = this.contractdetails.contractIncoTerm;
    this.contractdetails.contGSTMessage =  this.contGSTMessage;
    this.contractDetailsdata.push(this.contractDetailsObj);
    this._contractService.changeContract(this.contractDetailsdata);
    this._router.navigate(['/mycontracts/order/', this.contractId]);
  }
  onResize(event: any) {
    event.target.innerWidth;

  }
}
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './core/guard/auth.guard';
import { ContractGuard } from './core/guard/contract.guard';

const routes: Routes = [
  { 
    path: 'auth', 
    loadChildren: () => import('./auth/auth.module').then(m => m.AuthModule),
    canLoad:[AuthGuard],
  },
  {
    path: '',
    redirectTo: 'auth',
    pathMatch:'full'
  },
  { 
    path: 'mycontracts', 
    loadChildren: () => import('./modules/common/pages/mycontracts/mycontracts.module').then(m => m.MycontractsModule),
    //canLoad:[ContractGuard],
    
  },

  {
    path: '404',
    loadChildren: () => import('./core/modules/404/not-found.module').then(m => m.NotFoundModule),

  },
  {
    path: '**',
    redirectTo: '404'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

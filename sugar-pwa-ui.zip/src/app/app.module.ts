import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './core/modules/material/material.module';
import { AgGridModule } from 'ag-grid-angular';
import { AgGridRouterComponent } from './core/modules/shared/components/ag-grid-router/ag-grid-router.component';
import { PromptComponent } from './core/modules/shared/components/prompt/prompt.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { TokeninterceptorService } from './core/services/interceptors/tokeninterceptor.service';
import { LoadingService } from './core/services/shared/loading.service';
import { ContractService } from './core/services/shared/contract.services';


import { ToastrModule } from 'ngx-toastr';
import { SnackbarService } from './core/services/snackBar/snackbar.service';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { BnNgIdleService } from 'bn-ng-idle';

@NgModule({
  declarations: [
    AppComponent,
    AgGridRouterComponent,
    PromptComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    HttpClientModule,
    ToastrModule.forRoot(),
    AgGridModule.withComponents([]),
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: environment.production,
      // Register the ServiceWorker as soon as the application is stable
      // or after 30 seconds (whichever comes first).
      registrationStrategy: 'registerWhenStable:30000'
    })

  ],
  entryComponents:[PromptComponent],
  providers: [ BnNgIdleService, SnackbarService, LoadingService, ContractService],
  bootstrap: [AppComponent]
})
export class AppModule { }


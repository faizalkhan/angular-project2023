import { Component } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { BnNgIdleService } from 'bn-ng-idle';
import { ToastrService } from 'ngx-toastr';
import { StorageService } from './core/services/storage/storage.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public paramValue :any;
  constructor(private matDialog: MatDialog,private bnIdle: BnNgIdleService, private router : Router, private _toaster : ToastrService, private _storage:StorageService) {
 
  }
   title = 'sugar-pwa-ui';
  
   ngOnInit(): void {
     //1800
    this.bnIdle.startWatching(1800).subscribe((isTimedOut: boolean) => {
      if (isTimedOut) {    
        this.router.navigate(['../auth/login']);
        this._toaster.error("Session expired");
        this._storage.deleteToken();
        this.matDialog.closeAll();
   
      }
    });
  }


}

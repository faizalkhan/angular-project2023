# Development

## Should be follow the below step for development progress.
  
### Step 1. Get the requirement propely from Business lead. need to be check below item in gathering the requirement time.
     
1. Need to confirm API developed or not. If developed get the detail about the API (POSTMAN COLLECTION).

2. Need to be check validation fields if any calculation part get the clarity of that.

3. Need to be check the design as well
     
### Step 2. Create the CR # for tracking sheet. 
     
1. Where I'm getting the CR number? **Once did you get the requirement and fill the CR form. [Click here](https://forms.gle/QJ2GpSMnECrerSTJ8) then you will get the CR number.**
     
### Step 3. Create the branch from main (branch)

ex. **dev/CR#/nameofthedeveloper**

### Step 4. Acceptance demo with respective team. If they give the review fix with same branch but different commit. 

### Step 5. Create the pull request 

### Step 6. Review the code if any comment come fix the same branch but differenct commit.
     
### Step 7. Finally merge the code into main and deploy the UAT environmet and demo with Business lead.
      


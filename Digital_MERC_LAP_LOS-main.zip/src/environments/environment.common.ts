// environment.common.ts

export const commonEnv = {
    production: false,
    environmentName: "Local",
    api: "/local/API/LAP",
    downloadEndPoints: "LAP_DmsDownLoadDocs",
    commonDownload: "/proxy/MERC_LAP_Service/Service.svc",
    AES_ENCRYPTION_KEY: "=abcd!#Axd*G!pxP"
};
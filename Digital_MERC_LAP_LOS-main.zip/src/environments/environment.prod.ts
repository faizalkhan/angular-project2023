// environment.prod.ts

import { commonEnv } from "./environment.common";

const env: Partial<typeof commonEnv> = {
  production: true,
  environmentName: "production",
  api:"https://miflowappuat.ltferp.com/LAP_APIs/API/lap",
  downloadEndPoints:"LAP_DmsDownLoadDocs",
  commonDownload:"https://miflowappuat.ltferp.com/MERC_LAP_Service/Service.svc",
  AES_ENCRYPTION_KEY:"=abcd!#Axd*G!pxP"
};

// Export all settings of common replaced by dev options
export const environment = Object.assign(commonEnv, env);
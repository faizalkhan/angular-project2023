
import { commonEnv } from "./environment.common";

const env: Partial<typeof commonEnv> = {
    production: false,
    api:"/proxy/LAP_APIs/API/lap",
    downloadEndPoints:"LAP_DmsDownLoadDocs",
    commonDownload:"/proxy/MERC_LAP_Service/Service.svc",
    AES_ENCRYPTION_KEY:"=abcd!#Axd*G!pxP"
};

// Export all settings of common replaced by dev options
export const environment = Object.assign(commonEnv, env);
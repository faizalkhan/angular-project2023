import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTableModule } from '@angular/material/table';
import { HttpClientModule } from '@angular/common/http';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { LayoutModule, LayoutService, LegalModule, RiskControlUnitModule, SanctionModule, TechnicalModule, OPSQueriesModule, RMCDocumentModule, DisbursementDetailsModule } from './pages/index';
import { TabsetConfig, TabsModule } from 'ngx-bootstrap/tabs';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InfoServices } from './Injectable/info.services';
import { ServiceModule } from './shared/services';
import { NgHttpLoaderModule } from 'ng-http-loader';
import { ToastrModule } from 'ngx-toastr';
import { OperationalQueriesScreenComponent } from './pages/OperationalQueries/operational-queries-screen/operational-queries-screen.component';
import { AppDynamicDirective } from './shared/directive/app-dynamic.directive';
import { BrowserModule } from '@angular/platform-browser';
import { CookieService } from 'ngx-cookie-service';
import { NgxPaginationModule } from 'ngx-pagination';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ErrorMessageComponent } from './pages/layout/error-message/error-message.component';
import { LayoutFormGroupComponent } from './pages/layout/layout-form-group/layout-form-group.component';
import { UploadViewDownloadComponent } from './pages/layout/button/upload-view-download/upload-view-download.component';
import { DatePipe } from '@angular/common';
import { NumberDirective } from './shared/directive/input-controls/numeric-only/numeric-only.directive';
import { AllowAlphabetDirective } from './shared/directive/input-controls/allow-alphabet/allow-alphabet.directive';
import { NumericwithdecimalDirective } from './shared/directive/input-controls/numericwithdecimal/numericwithdecimal.directive';
import { RiskdashboardComponent } from './pages/riskcontrolunit/riskdashboard/riskdashboard.component';
import { AllowAlphabetNumericDirective } from './shared/directive/input-controls/allow-alphabet-numeric/allow-alphabet-numeric-directive.directive';
import { DynamicFormComponent } from './pages/layout/dynamic-form/dynamic-form.component';
import { ListComponent } from './pages/sanction/obligation-form/list/list.component';
@NgModule({
  declarations: [
    AppComponent,
    SanctionModule,
    TechnicalModule,
    LegalModule,
    LayoutModule,
    RiskControlUnitModule,
    OPSQueriesModule,
    RMCDocumentModule,
    DisbursementDetailsModule,
    OperationalQueriesScreenComponent,
    AppDynamicDirective,
    ErrorMessageComponent,
    LayoutFormGroupComponent,
    UploadViewDownloadComponent,
    NumberDirective,
    AllowAlphabetDirective,
    NumericwithdecimalDirective,
    RiskdashboardComponent,
    AllowAlphabetNumericDirective,
    DynamicFormComponent,
    ListComponent
  ],
  imports: [
    BrowserModule, 
    FormsModule, 
    ReactiveFormsModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({ preventDuplicates: true }),
    AppRoutingModule,
    MatExpansionModule,
    MatTableModule,
    HttpClientModule,
    TabsModule.forRoot(),
    FormsModule,
    NgHttpLoaderModule.forRoot(),
    NgxPaginationModule
  ],
  providers: [CookieService, InfoServices, Location, TabsetConfig, DatePipe, { provide: LocationStrategy, useClass: HashLocationStrategy }, ServiceModule, LayoutService],
  bootstrap: [AppComponent],
})
export class AppModule {

  constructor() {

  }

}


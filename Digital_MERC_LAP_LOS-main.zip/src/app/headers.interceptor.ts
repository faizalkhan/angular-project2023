import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { animate } from '@angular/animations';
import { environment } from 'src/environments/environment';
import * as CryptoJS from 'crypto-js'
@Injectable()
export class HeadersInterceptor implements HttpInterceptor {

  constructor() { }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {

    request = request.clone({
      setHeaders: {
        'hashString': this.encryptUsingAES128(request.body),
        'X-IBM-Client-Secret': 'E4eW1yA0bU2nU5gI1kV6lS0lK5nN8sF5dA4wE6aD8nE0dE2iG7',
        'X-IBM-Client-Id': '5b80efab-ab01-412d-bf04-2a141ea3ff0c'
      }
    })
    return next.handle(request);
  }
  encryptUsingAES128(arg0: any) {
    let value = "";
    if (arg0._base64Fields) {
      arg0._base64Fields.forEach((element: any) => {
        delete arg0[element];
      });
    }
    value = JSON.stringify(arg0);
    if (environment.AES_ENCRYPTION_KEY !== undefined) {
      const key = String(environment.AES_ENCRYPTION_KEY);
      const encryptionKey = CryptoJS.enc.Utf8.parse(key);
      const iv = CryptoJS.enc.Utf8.parse(key);
      const encrypted = CryptoJS.AES.encrypt(
        CryptoJS.enc.Utf8.parse(value),
        encryptionKey,
        {
          keySize: 16,
          iv: iv,
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        },
      );
      return encrypted.toString();
    }
    return value;

  }

  removeImageFields() {

  }
}


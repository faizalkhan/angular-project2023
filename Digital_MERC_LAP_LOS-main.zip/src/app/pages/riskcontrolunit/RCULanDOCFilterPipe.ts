import { Pipe, PipeTransform } from '@angular/core';
import { RCULANDocCheckModel } from './RCU.Model';

@Pipe({
  name: 'RCULanDOCFilterPipe'
})
export class RCULanDOCFilterPipe implements PipeTransform {

  transform(value: RCULANDocCheckModel[], input: string): RCULANDocCheckModel[] {
    
    if (input) {
        return value.filter(val => val.applicantType === input || (input==="Other documents" && val.applicantType===null));
      } else {
        return value;
      }
     }
}


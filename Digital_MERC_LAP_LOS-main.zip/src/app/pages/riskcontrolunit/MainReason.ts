
export class MainReason{
    status:string='';
    Id:number=0;
    constructor( status: string, Id:number){
        this.status=status;
        this.Id=Id;
    }
    
 }
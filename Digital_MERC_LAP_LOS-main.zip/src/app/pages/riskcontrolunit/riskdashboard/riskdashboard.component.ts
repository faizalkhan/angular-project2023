import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router, TitleStrategy } from '@angular/router';
import { Subscription } from 'rxjs';
import { InfoServices } from 'src/app/Injectable/info.services';
import { NotificationService } from 'src/app/notification.service';
import { headerModel } from 'src/app/shared/models/common/header-table';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
import { requestmodel } from 'src/app/shared/models/sanction/request.model';
import { ISearch } from 'src/app/shared/models/sanction/search/search';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { SearchService } from 'src/app/shared/services/search/search.service';
import { MenuService } from '../../layout/header/menu-service.service';
import { MenuResponse } from '../../layout/login/login.service';
import { IPendingDashboardModel, PendingDahboardModel } from '../RCU.Model';

@Component({
  selector: 'app-riskdashboard',
  templateUrl: './riskdashboard.component.html',
  styleUrls: ['./riskdashboard.component.css']
})
export class RiskdashboardComponent implements OnInit,OnDestroy {

  title: any = "Pending for screening Dashboard"
  isDashboard: Boolean = true;
  private _header: any[] = [];
  private _data: any[] = [];

  public get Data(): any[] {
    return this._data;
  }
  public set Data(value: any[]) {
    this._data = value;
  }

  public get Header(): any[] {
    return this._header;
  }
  public set Header(value: any[]) {
    this._header = value;
  }
  loggedInUserRoleId: string = '';
  _userId: string = '';
  roleId: string = '';
  dispRole :string ="";
  currentDateTime: any = new Date();
  private _selectedRow: PendingDahboardModel = new PendingDahboardModel();
  public get SelectedRow(): PendingDahboardModel {
    return this._selectedRow;
  }

  public set SelectedRow(value: PendingDahboardModel) {
    this._selectedRow = value;
  }

  UserId: string = "";

  constructor(private http: ConfigService, private notify: NotificationService, private info: InfoServices,
    private route: Router, private _searchService: SearchService, private menuService: MenuService) {

  }
  ngOnDestroy(): void {
    this.subcription.unsubscribe();
  }
  subcription: Subscription = new Subscription();
  ngOnInit(): void {

    this.getLoggedInUserRole();

    if (this.roleId === "RRM-V") {
       this.dispRole = this.roleId;
      this.roleId = "RRMV";
    }

    if (this.roleId === "RRM-I") {
      this.dispRole = this.roleId;
      this.roleId = "RRMI";
    }

   this.getHeader();

    const request = new requestmodel();
    request.FromDate = new Date().toString();
    request.ToDate = new Date().toString();
    request.UserID = this.UserId;
    request.Role = this.roleId;
    request.ScreenType = "";
    request.FieldName = "FLO";
    request.FieldValue = "FLO"

    this.subcription = this._searchService.SearchData.subscribe((res: ISearch) => {

      this.getHeader();
      if (res.role === "RRM-V") {
        res.role = "RRMV";
      }

      if (res.role === "RRM-I") {
        res.role = "RRMI";
      }
      request.FieldName = res.fieldName;
      request.FieldValue = res.fieldValue;
      request.FromDate = res.fromDate.toString();
      request.ToDate = res.toDate.toString()
      //this.RMCSearch.screenType="";
      request.Role = res.role;
      request.UserID = res.login_PS_ID;
      this.getPendingActionlist(request.RCUPendingActiontoJSON());

    });
  }

  getHeader(){ 
    this._header = [
      new headerModel('loanAccountNumber', 'Lan no.'), 
      new headerModel('name', 'Name'),
      new headerModel('coApplicantName', 'Co-Applicants'),
      new headerModel('state', 'State'),
      new headerModel('executive_ID', 'MC Code'),
      new headerModel('executive_Name', 'MC Name'),
      new headerModel('mobileNo', 'Mobile Number of Applicant'),
      new headerModel('rcuTriggeredDate', 'Date of trigger to ' + this.dispRole),
      new headerModel('ageing', 'Ageing'),
      new headerModel('triggerType', 'Trigger Type'),
      new headerModel('subStage', 'Sub Stage'),
      //new headerModel('category', 'Category'),
      new headerModel('caseStatus', 'Case Status')
    ]; 
  }

  getLoggedInUserRole() {

    var loggedInUserRole = JSON.parse(this.info.getItem('menu')) as MenuResponse;
    this.loggedInUserRoleId = loggedInUserRole.menuUserDetail.roleId;
    this.UserId = loggedInUserRole.menuUserDetail.userId;
    let loggedInUserRoleDetails = loggedInUserRole.roleDetails.find(x => x.roleId == this.loggedInUserRoleId);
    if (loggedInUserRoleDetails !== null)
      this.roleId = loggedInUserRoleDetails?.roleName === undefined ? "" : loggedInUserRoleDetails.roleName;

    if (this.roleId === "RRM-V") {
      this.dispRole=this.roleId;
      this.roleId = "RRMV";
    }

    if (this.roleId === "RRM-I") {
      this.dispRole=this.roleId;
      this.roleId = "RRMI";
    }
  }


  getPendingActionlist(param: any) {

    this.http.httpPost<IresponseModel<PendingDahboardModel[]>>(param, 'LAP_RCUPendingAction').subscribe((res: IresponseModel<PendingDahboardModel[]>) => {
      this.Data = [];
      if (res.rcuPendingActionList != null && res.rcuPendingActionList.length >= 0) {

        
        this.notify.showSuccess("Dashboard data retrived successfully", "Pending for Screening");
        let pendingList;
        if (this.roleId === "RRMI")
          pendingList = res.rcuPendingActionList.filter(x => x.category !== "Sampled" && x.category !== "Completed");
        else
          pendingList = res.rcuPendingActionList.filter(x => x.category !== "Sampled" && x.category !== "RiskAlert" && x.category !== "Completed");
 
        this.Data = pendingList.map((x: IPendingDashboardModel) => {
          return new PendingDahboardModel(x);
        });
      }
      else {
        this.notify.showWarning("Something went wrong", "Pending for screening");
      }
    })
  }

  row_click(event: any): void {
    this.SelectedRow = event;
    this.menuService.IsShow = false;
    this.info.setItem("PendingScreenInfo", JSON.stringify(this.SelectedRow));
    this.info.setItem("CaseType", "Pending for screening");
    this.route.navigateByUrl("/pendingscreen");
  }
  btnBack() {
    this.route.navigateByUrl("/riskcontolunitdash");
  }
}

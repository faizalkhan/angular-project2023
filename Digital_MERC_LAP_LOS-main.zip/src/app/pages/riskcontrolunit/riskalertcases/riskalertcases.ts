import { DatePipe } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { InfoServices } from 'src/app/Injectable/info.services';
import { NotificationService } from 'src/app/notification.service';
import { headerModel } from 'src/app/shared/models/common/header-table';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
import { requestmodel } from 'src/app/shared/models/sanction/request.model';
import { ISearch } from 'src/app/shared/models/sanction/search/search';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { ModalService } from 'src/app/shared/services/modal/modal.service';
import { SearchService } from 'src/app/shared/services/search/search.service';
import { MenuService } from '../../layout/header/menu-service.service';
import { MenuResponse } from '../../layout/login/login.service';
import { IPendingDashboardModel, PendingDahboardModel } from '../RCU.Model';
import { RemarkReasonService } from '../RCU.service';


@Component({
  selector: 'app-riskalert',
  templateUrl: './riskalertcases.html',
  styleUrls: ['./riskalertcases.css']
})
export class RiskAlertCasesComponent implements OnInit, OnDestroy {
  title: any = "Risk Alert Cases Dashboard"
  isDashboard: Boolean = true;
  private _header: any[] = [];
  private _data: any[] = [];

  public get Data(): any[] {
    return this._data;
  }
  public set Data(value: any[]) {
    this._data = value;
  }

  public get Header(): any[] {
    return this._header;
  }
  public set Header(value: any[]) {
    this._header = value;
  }
  private _selectedRow: PendingDahboardModel = new PendingDahboardModel();
  public get SelectedRow(): PendingDahboardModel {
    return this._selectedRow;
  }

  public set SelectedRow(value: PendingDahboardModel) {
    this._selectedRow = value;
  }

  loggedInUserRoleId: string = '';
  roleId: string = '';
  dispRole:string='';
  _userId: string = '';

  currentDateTime: any = new Date();
  constructor(private http: ConfigService, private notify: NotificationService,
    private _searchService: SearchService, private reason: RemarkReasonService,
    private modal: ModalService, private route: Router, private info: InfoServices, private menuService: MenuService) {

  }
  ngOnDestroy(): void {
    this.subcriptions.unsubscribe();
  }
  subcriptions: Subscription = new Subscription();
  ngOnInit(): void {


    this.getLoggedInUserRole(); 
    
    if (this.roleId === "RRMV") {
     // this.roleId = "RRMV";
      this._header = [
        new headerModel('loanAccountNumber', 'Lan no.'),
        new headerModel('name', 'Name'),
        new headerModel('coApplicantName', 'Co-Applicants'),
        new headerModel('state', 'State'),
        new headerModel('executive_ID', 'MC Code'),
        new headerModel('executive_Name', 'MC Name'),
        new headerModel('mobileNo', 'Mobile Number of Applicant'),
        new headerModel('rcuTriggeredDate', 'Date of trigger to ' +  this.dispRole),
        new headerModel('ageing', 'Ageing'),
       // new headerModel('token', 'Risk Alert Token'),
        new headerModel('subStage', 'Sub Stage'),
        new headerModel('caseStatus', 'Case Status')
      ];
      
    }

    if (this.roleId === "RRMI") {
      //this.roleId = "RRMI";
      this._header = [
        new headerModel('loanAccountNumber', 'Lan no.'),
        new headerModel('name', 'Name'),
        new headerModel('coApplicantName', 'Co-Applicants'),
        new headerModel('state', 'State'),
        new headerModel('executive_ID', 'MC Code'),
        new headerModel('executive_Name', 'MC Name'),
        new headerModel('mobileNo', 'Mobile Number of Applicant'),
        new headerModel('rcuTriggeredDate', 'Date of trigger to ' +  this.dispRole),
        new headerModel('ageing', 'Ageing'),
        new headerModel('token', 'Risk Alert Token'),
        new headerModel('subStage', 'Sub Stage'),
        new headerModel('caseStatus', 'Case Status')
      ];
    }

   

    // this._header = [
    //   new headerModel('loanAccountNumber', 'Lan no.'),
    //   new headerModel('name', 'Name'),
    //   new headerModel('coApplicantName', 'Co-Applicants'),
    //   new headerModel('state', 'State'),
    //   new headerModel('executive_ID', 'MC Code'),
    //   new headerModel('executive_Name', 'MC Name'),
    //   new headerModel('mobileNo', 'Mobile Number of Applicant'),
    //   new headerModel('rcuTriggeredDate', 'Date of trigger to ' +  this.dispRole),
    //   new headerModel('ageing', 'Ageing'),
    //   new headerModel('token', 'Risk Alert Token'),
    //   new headerModel('subStage', 'Sub Stage'),
    //   new headerModel('caseStatus', 'Case Status')
    // ];

  
    const request = new requestmodel();
    request.FromDate = new Date().toString();
    request.ToDate = new Date().toString();
    request.UserID = this._userId;
    request.Role = this.roleId;
    request.ScreenType = "";
    request.FieldName = "FLO";
    request.FieldValue = "FLO"


    this.subcriptions = this._searchService.SearchData.subscribe((res: ISearch) => {


      if (res.role === "RRM-V") {
        res.role = "RRMV"; 
      }

      if (res.role === "RRM-I") {
        res.role = "RRMI"; 
      }

      request.FieldName = res.fieldName;
      request.FieldValue = res.fieldValue;
      request.FromDate = res.fromDate.toString();
      request.ToDate = res.toDate.toString();
      //this.RMCSearch.screenType="";
      request.Role = res.role;
      request.UserID = res.login_PS_ID;
      this.getRiskAlertlist(request.RCUPendingActiontoJSON());

    });

  }

  row_click(event: any): void {
    this.isDashboard = false;
    this.SelectedRow = event;
    this.menuService.IsShow = false;
    this.info.setItem("PendingScreenInfo", JSON.stringify(this.SelectedRow));
    this.info.setItem("CaseType", "Risk alert case");
    this.route.navigateByUrl("/pendingscreen");
    //alert(JSON.stringify(event));
  }

  getLoggedInUserRole() {
    var loggedInUserRole = JSON.parse(this.info.getItem('menu')) as MenuResponse;
    this.loggedInUserRoleId = loggedInUserRole.menuUserDetail.roleId;
    this._userId = loggedInUserRole.menuUserDetail.userId;
    let loggedInUserRoleDetails = loggedInUserRole.roleDetails.find(x => x.roleId == this.loggedInUserRoleId);
    if (loggedInUserRoleDetails !== null)
      this.roleId = loggedInUserRoleDetails?.roleName === undefined ? "" : loggedInUserRoleDetails.roleName;

    if (this.roleId === "RRM-V") {
      this.dispRole=this.roleId;
      this.roleId = "RRMV";
    }

    if (this.roleId === "RRM-I") {
      this.dispRole=this.roleId;
      this.roleId = "RRMI";
    }
  }

  //  selectedStatus: String = "--Choose Status--";
  //  MainStatusList: Array<any> = [
  //   { status: 'KYC 1 & 2 of both applicant / co applicant', substatus: ['Fake/Tampered KYC ', 'Random Image / Unclear Image uploaded (either 1st or 2nd page)', 'Applicant is Outside Age Limit','Complete Name Mismatch','Complete Mismatch with Picture on KYC applicants live picture','Number Mismatch','Invalid (Online checks)','Gender Mismatch (basis online check)','Sourcing using Photocopy','DOB Mismatch - Age as per policy','Others'] },
  //   { status: 'Bank', substatus: ['Complete mismatch in name from borrower name','Random / Unclear Image uploaded','Manually updated / Printed Bank A/C No. Reverse feedback - Beneficiary Name mismatch','Co-borrower Passbook (not Joint A/C)','Number Mismatch - Any digit mismatch ','Joint A/C with a non co-applicant individual','Fake/Tampering (Ground Checks . Info)','IFSC wrong/ not mentioned','Others'] },
  //   { status: 'Mobile Number relate', substatus: ['Third party mobile number updated','Customer number not in service / invalid','Others'] },
  //   { status: 'Policy related', substatus: ['Relation of borrower and co-borrower not matched as per application / not established','Blood / close relatives in one group','Co-borrower Stays in abroad','Co-borrower currently not in the state (working outside/abroad)','Migrant Customer','Others'] },
  //   {status:'Process Violation',substatus:['Customer live photo not captured','Borrowers dont know each other','Customer not interested to take loan','CIBIL below the benchmark approval not taken','Loan applicant / co applicant engaged in negative business','Properties not as per the policy have been sourced','Charge already created with different institution or charge not created','Others']},
  //   {status:'Valuation',substatus:['Valuation report tampered','Address mismatch with the valuation done','Valuation and legal report details mismtach','Second valuation not done for the cases before the sanction']},
  //   {status:'Legal',substatus:['Title deed not in the name of the applicant','Litigation on the property','Negative area','Litigation on the applicant / co applicant','Mismatch in the property owner','Legal report not available at the time of sanction','Legal report address mismtch with the property details','Others']}
  // ];
  // substatus: Array<any>=[];
  // ChangeSubStatus(count:any) {
  //   this.substatus = this.MainStatusList.find((con:any) => con.status == count.target.value).substatus;
  // }

  getRiskAlertlist(param: any) {

    this.http.httpPost<IresponseModel<PendingDahboardModel[]>>(param, 'LAP_RCUPendingAction').subscribe((res: IresponseModel<PendingDahboardModel[]>) => {
      this.Data = [];
      if (res.rcuPendingActionList != null && res.rcuPendingActionList.length >= 0) {
        let riskAlertData = res.rcuPendingActionList.filter(x => x.category === "RiskAlert");
        this.notify.showSuccess("Dashboard data retrived successfully", "Risk Alert Cases");
        this.Data = riskAlertData.map((x: IPendingDashboardModel) => {
          return new PendingDahboardModel(x);
        });
      }
      else {
        this.notify.showWarning("Something went wrong", "Risk alert Cases");
      }
    })
  }
  btnBack() {
    this.route.navigateByUrl("/riskcontolunitdash");
  }
}
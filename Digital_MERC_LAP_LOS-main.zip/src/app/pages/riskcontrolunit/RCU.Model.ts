import { Call, compileDeclareNgModuleFromMetadata, identifierName } from "@angular/compiler";
import { values } from "pdf-lib";
import { DocumentInfo } from "src/app/shared/models/sanction/Legal/legalDashboard";
import { SubReason } from "./subreason";

 
export interface IRCUSummaryDashboardModel {
    totalTriggered: number;
    totalHunter: number; 
    totalPending:number;
    totalInternalTriggers:number;
    totalClosed:number;
    totalHunterInternalTriggers:number;
}

export class RCUSummaryDahboardModel implements IRCUSummaryDashboardModel {
    totalTriggered: number=0;
    totalHunter: number=0; 
    totalPending:number=0;
    totalInternalTriggers:number=0;
    totalClosed:number=0;
    totalHunterInternalTriggers:number=0; 

    constructor(params?: IRCUSummaryDashboardModel) {
        if (params) {
            this.totalTriggered = params.totalTriggered;
            this.totalHunter = params.totalHunter;
            this.totalPending=params.totalPending;
            this.totalInternalTriggers=params.totalInternalTriggers;
            this.totalClosed = params.totalClosed;
            this.totalHunterInternalTriggers = params.totalHunterInternalTriggers;            
        } 
    }

}


export interface IPendingDashboardModel {
    applicationNo: string;
    name: string; 
    coApplicant:string;
    state:string;
    executive_ID:string;
    executive_Name:string;
    mobileNo: string;
    rcuTriggeredDate: string;
    ageing: string; 
    triggerType: string;
    subStage: string;
    category: string;
    loanAccountNumber:string; 
    leadID:string;
    type:string;
    preSancRCU_ARM_Action:string;
    preSancRCU_RRMV_Action:string;
    preSancRCU_RRMI_Action:string;
    postSancRCU_ARM_Action:string;
    postSancRCU_RRMV_Action:string;
    postSancRCU_RRMI_Action:string;          
    caseStatus:string;    
    preSancRCU_CompletedDate:string; 
    postSancRCU_CompletedDate:string; 
    preSancRCU_Sample_Review:string;
    postSancRCU_Sample_Review:string;
}

export class PendingDahboardModel implements IPendingDashboardModel {
    applicationNo: string="";
    name: string=""; 
    private _coApplicant: string = "";

    public get coApplicant(): string {
        return this._coApplicant;
    }
    public set coApplicant(value: string) {
        let coApplicantName1 = value;
        if(value!="" && value!=null){
        this.GetCoApplicant(value.substring(0, value.length - 1));
        coApplicantName1 = coApplicantName1.replace(/,/g, ' ');
        this._coApplicant = coApplicantName1;       
        }
    }  

    private _coApplicantName: string[] = [];
    
    public get coApplicantName(): string[] {
        return this._coApplicantName;
    }
    public set coApplicantName(value: string[]) {
        // let coApplicantName = value;
        // coApplicantName = coApplicantName.replace(/,/g, ' ');
        this._coApplicantName = value;       
    }
    state:string="";
    executive_ID:string="";
    executive_Name:string="";
    mobileNo: string="";
    rcuTriggeredDate: string="";
    ageing: string=""; 
    triggerType: string="";
    subStage: string="";
    category: string="";
    loanAccountNumber:string=""; 
    leadID: string="";
    type: string="";
    preSancRCU_ARM_Action: string='';
    preSancRCU_RRMV_Action: string='';
    preSancRCU_RRMI_Action: string='';
    postSancRCU_ARM_Action: string='';
    postSancRCU_RRMV_Action: string='';
    postSancRCU_RRMI_Action: string='';
    caseStatus:string='';
    preSancRCU_CompletedDate:string='';
    postSancRCU_CompletedDate:string='';
    preSancRCU_Sample_Review:string="";
    postSancRCU_Sample_Review:string="";
    constructor(params?: IPendingDashboardModel) {
        if (params) {
           
            this.name= params.name; 
            this.coApplicant=params.coApplicant;
            this.state=params.state;
            this.executive_ID=params.executive_ID;
            this.executive_Name=params.executive_Name;
            this.mobileNo=params.mobileNo;
            this.rcuTriggeredDate=params.rcuTriggeredDate;
            this.ageing=params.ageing;
            this.triggerType=params.triggerType;
            this.subStage=params.subStage;
            this.category=params.category;       
            this.applicationNo = params.applicationNo;
            this.loanAccountNumber = params.loanAccountNumber;
            this.leadID = params.leadID;
            this.type=params.type;
            this.preSancRCU_ARM_Action=params.preSancRCU_ARM_Action;
            this.preSancRCU_RRMI_Action=params.preSancRCU_RRMI_Action;
            this.preSancRCU_RRMV_Action=params.preSancRCU_RRMV_Action;
            this.postSancRCU_ARM_Action=params.postSancRCU_ARM_Action;
            this.postSancRCU_RRMI_Action=params.postSancRCU_RRMI_Action;
            this.postSancRCU_RRMV_Action=params.postSancRCU_RRMV_Action;
            this.caseStatus=params.caseStatus;
            this.preSancRCU_CompletedDate=params.preSancRCU_CompletedDate;
            this.postSancRCU_CompletedDate=params.postSancRCU_CompletedDate;
            this.preSancRCU_Sample_Review =params.preSancRCU_Sample_Review;
            this.postSancRCU_Sample_Review =params.postSancRCU_Sample_Review;
        } 

    }
   
   
    GetCoApplicant(data:string){
       
        this.coApplicantName =  data!="" ? data.split(",") : [];
    }
   

}


export interface IPendingApplicationModel {
     
    name: string;
    mobileno: string;
    state: string;
    pin_code: string;
    createdOn: string;
    product: string;
    scheme: string;
    appliedTenure: number;
    loanAppliedAmount: number;
    address1: string;
    financial_status: string;
    applicantType: string;
    occupation: string;
    dob: Date;
    rel_with_applicant: string;
    gender: string;
    emailid: string;
    kyC1Type: string;
    kyC1No: string;
    kyC2Type: string;
    kyC2No: string;
    token_Number: string;
    triggerType: string;
    subStage: string;
    category: string;
    preSanctionStatus: string;
    dateAndTime: Date;
    branchName:string;
    kyC1Status:string;
    kyC2Status:string;

}

export class PendingApplicationModel implements IPendingApplicationModel {
     
   
    name: string=""; 
    mobileno: string=""; 
    state: string=""; 
    pin_code: string=""; 
    createdOn: string=""; 
    product: string=""; 
    scheme: string=""; 
    appliedTenure: number=0 
    loanAppliedAmount:number=0; 
    address1: string=""; 
    financial_status: string=""; 
    applicantType: string=""; 
    occupation: string=""; 
    dob: Date= new Date();
    rel_with_applicant: string=""; 
    gender: string=""; 
    emailid: string=""; 
    kyC1Type: string=""; 
    kyC1No: string=""; 
    kyC2Type: string=""; 
    kyC2No: string=""; 
    token_Number: string=""; 
    triggerType: string=""; 
    subStage: string=""; 
    category: string=""; 
    preSanctionStatus: string=""; 
    branchName:string='';
    dateAndTime: Date=new Date(); 
    kyC1Status:string='';
    kyC2Status:string='';

    constructor(params?: IPendingApplicationModel) {
        if (params) {
           
            this.name= params.name; 
            this.mobileno= params.mobileno; 
            this.state= params.state; 
            this.pin_code=params.pin_code
            this.createdOn= params.createdOn; 
            this.product=params.product;
            this.scheme= params.scheme; 
            this.appliedTenure= params.appliedTenure; 
            this.loanAppliedAmount=params.loanAppliedAmount;
            this.address1=params.address1; 
            this.financial_status=params.financial_status; 
            this.applicantType=params.applicantType; 
            this.occupation =params.occupation; 
            this.dob=params.dob;
            this.rel_with_applicant =params.rel_with_applicant; 
            this.gender = params.gender; 
            this.emailid=params.emailid; 
            this.kyC1Type=params.kyC1Type; 
            this.kyC1No=params.kyC1No; 
            this.kyC2Type=params.kyC2Type;
            this.kyC2No=params.kyC2No;
            this.token_Number=params.token_Number;
            this.triggerType=params.triggerType;
            this.subStage =params.subStage;
            this.category=params.category;
            this.preSanctionStatus=params.preSanctionStatus;
            this.dateAndTime=params.dateAndTime;
            this.branchName=params.branchName;
            this.kyC1Status=params.kyC1Status;
            this.kyC2Status=params.kyC2Status;

        } 

    }
   
    

}


export interface IRuleTriggerModel {
     
    type: string;
    customerName: string;
    rel_with_applicant: string;
    financial_status: string;
    category: string;
    ruleType: string;
    ruleTriggered: string;
}

export class RuleTriggerModel implements IRuleTriggerModel {
     
   
    type: string='';
    customerName: string='';
    rel_with_applicant: string='';
    financial_status: string='';
    category: string='';
    ruleType: string='';
    ruleTriggered: string='';

    constructor(params?: IRuleTriggerModel) {
        if (params) {
           
            this.customerName= params.customerName; 
            this.type= params.type; 
            this.rel_with_applicant= params.rel_with_applicant; 
            this.financial_status=params.financial_status
            this.category= params.category; 
            this.ruleType=params.ruleType;
            this.ruleTriggered= params.ruleTriggered;  

        } 

    }
   
    

}



export interface IRCULANDoc{
    
    loanAccountNumber: string;
    applicationNo: string;
    leadId: string;
    docType: string;
    docTypeDescription: string;
    imageMIMEType: string;
    module: string;
    dmS_FileName: string;
    dmS_UUID: string;
    lat: string;
    lng: string;
    bankDetailID: string;
    methodName: string;
    rcuMakerVerificationStatus: string;
    rcuMakerDiscrepantReason: string;
    rcuMakerDiscrepantSubReason: string;
    rcuCheckerVerificationStatus: string;
    isDiscrepant: string;
    rcuMakerRemark: string;
    rcuCheckerRemark: string;
    opsMakerVerificationStatus: string;
    opsMakerRemarks: string;
    opsCheckerVerificationStatus: string;
    opsCheckerRemarks: string;
    rmC_Status: string;
    applicantType: string;
    subReasonList : SubReason[];
    ext:string;
    remark:string;
    docTypeName:string;
    displayDocType():any;
    //MainStatusList: RCULANDocCheckMainStatus[]
}



export class RCULANDocCheckModel implements IRCULANDoc{
    loanAccountNumber: string='';
    applicationNo: string='';
    leadId: string='';
    //docType: string='';
    private _docType:string="";
    public get docType():string{
        return this._docType;
    }
    public set docType(value:string){
        this._docType=value; 
        //this.displayDocType();
    }

    docTypeDescription: string='';
    imageMIMEType: string='';
    module: string='';
    dmS_FileName: string='';
    dmS_UUID: string='';
    lat: string='';
    lng: string='';
    bankDetailID: string='';
    methodName: string='';
    rcuMakerVerificationStatus: string='';
    rcuMakerDiscrepantReason: string='';
    rcuMakerDiscrepantSubReason: string='';
    rcuCheckerVerificationStatus: string='';
    isDiscrepant: string='';
    rcuMakerRemark: string='';
    rcuCheckerRemark: string='';
    opsMakerVerificationStatus: string='';
    opsMakerRemarks: string='';
    opsCheckerVerificationStatus: string='';
    opsCheckerRemarks: string='';
    rmC_Status: string='';
    applicantType: string='';
    ext:string='';
    private _increment:number=0;
    public get increment():number{
        return this._increment;
    }
    public set increment(value:number){
        this._increment=value;
    }

    private _subReasonList:SubReason[]=[];
    public get subReasonList() : SubReason[]{
        return this._subReasonList;
    }
    public set subReasonList(value:SubReason[]){
         this._subReasonList=value;
    }
   
    // private _SubStatusList:RCULANDocCheckSubStatus[]=[];
    // public get SubStatusList():RCULANDocCheckSubStatus[]{
    //     let self =this;
      
    // }
    // public set SubStatusList(value){
    //      this._SubStatusList =value;
    // }

    // public get MainStatusList(): RCULANDocCheckMainStatus[] {
    //     let self = this;
        
    //   }  \
    private _remark:string='';
    public get remark():string{
        return this._remark;
    }
    public set remark(value:string){
        this._remark=value;
    }

    docTypeName:string="";

    //private _isDiscrepant
    //remark:string ='';

    constructor(params?:IRCULANDoc){
        if(params){
            this.loanAccountNumber =params.loanAccountNumber;
            this.applicationNo=params.applicationNo;
            this.leadId=params.leadId;
            this.docType=params.docType;
            this.docTypeDescription=params.docTypeDescription;
            this.imageMIMEType=params.imageMIMEType;
            this.module=params.module;
            this.dmS_FileName=params.dmS_FileName;
            this.dmS_UUID=params.dmS_UUID;
            this.lat=params.lat;
            this.lng=params.lng;
            this.bankDetailID=params.bankDetailID;
            this.methodName=params.methodName;
            this.rcuMakerVerificationStatus=params.rcuMakerVerificationStatus;
            this.rcuMakerDiscrepantReason=params.rcuMakerDiscrepantReason;
            this.rcuMakerDiscrepantSubReason=params.rcuMakerDiscrepantSubReason;
            this.rcuCheckerVerificationStatus=params.rcuCheckerVerificationStatus;
            this.isDiscrepant=params.isDiscrepant;
            this.rcuMakerRemark=params.rcuMakerRemark;
            this.rcuCheckerRemark=params.rcuCheckerRemark;
            this.opsMakerVerificationStatus=params.opsMakerVerificationStatus;
            this.opsMakerRemarks=params.opsMakerRemarks;
            this.opsCheckerVerificationStatus=params.opsCheckerVerificationStatus;
            this.opsCheckerRemarks=params.opsCheckerRemarks;
            this.rmC_Status=params.rmC_Status; 
            this.applicantType= params.applicantType;
            this.subReasonList = params.subReasonList;
            this.ext=params.ext;
            this.remark=params.remark;
            this.displayDocType();
            //this.docTypeName=params.docTypeName;
            //this.MainStatusList = params.MainStatusList;
        }
    }
    
    displayDocType() {  
        if(this.applicantType==="A"){
            switch (this.docType?.toLowerCase()){
                case "address_proof":{
                    this.docTypeName = "Address Proof";
                    break;
                }
                case "ka1_back":{
                    this.docTypeName = "Aadhaar Back";
                    break;
                }
                case "ka1_front":{
                    this.docTypeName = "Aadhaar Front";
                    break;
                }
                case "pan":{
                    this.docTypeName = "Pan Card";
                    break;
                }
                case "applicantimg":{
                    this.docTypeName = "Customer Image";
                    break;
                }
                default:{
                    this.docTypeName = this.docType;
                }
            } 
        }
        else if(this.applicantType?.substring(0,2)==="CA"){
            switch (this.docType?.toLowerCase()){
                case "address_proof":{
                    this.docTypeName = "Address Proof";
                    break;
                }
                case "ka1_back":{
                    this.docTypeName = "Aadhaar Back";
                    break;
                }
                case "ka1_front":{
                    this.docTypeName = "Aadhaar Front";
                    break;
                }
                case "coapplicantimg":{
                    this.docTypeName = "Customer Image";
                    break;
                }
                default:{
                    this.docTypeName = this.docType;
                }
            } 
        }else {
            this.docTypeName = this.docType;
        }
    }


    getApplicantType (applicantType:String){
       
        let returnValue:string ="";
        if(applicantType === "A"){
            returnValue = "Applicant";
        }

        if(applicantType === "" || applicantType === null ){
            returnValue = "Household & Business photo";
        }

        if(applicantType.substring(0,2) === "CA"){
            if(this.increment===0){
            returnValue = "Primary Co-Applicant"; 
           }else{
            returnValue = "Primary Co-Applicant " + this.increment.toString(); 
           } 
            this.increment = this.increment + 1;
        }
 
        return returnValue;
    }

    
}

// export interface IPreSanctionFinalReview{
//     Approved:string;
//     Reject:string;
//     Referred:string;
//     RiskAlert:string;
//     RCUStatus:string;
//     RCUMainReason:string;
//     RCUSubReason:string;
//     Remark:string;
//     reviewed:string;
//     sampled:string; 
// }

// export class PreSanctionFinalReview implements IPreSanctionFinalReview{
//     Approved:string='';
//     Reject:string='';
//     Referred:string='';
//     RiskAlert:string='';
//     RCUStatus:string='';
//     RCUMainReason:string='';
//     RCUSubReason:string='';
//     Remark:string='';
//     reviewed:string='';
//     sampled:string='';

//     constructor(params?:IPreSanctionFinalReview){
//         if(params){
//               this.Approved = params.Approved;
//               this.Reject=params.Reject;
//               this.Referred=params.Referred;
//               this.RiskAlert=params.RiskAlert;
//               this.RCUStatus=params.RCUStatus;
//               this.RCUMainReason=params.RCUMainReason;
//               this.RCUSubReason=params.RCUSubReason;
//               this.Remark=params.Remark;
//               this.reviewed=params.reviewed;
//               this.sampled=params.sampled;
//         }
//     }
// }

export interface IRCUSanctionDiscrepant{
    loanAccountNumber: string;
    applicationNo: string;
    docType: string;
    docRCUStatus: string;
    docReason:string;
    docSubreason: string;
    docRemark: string; 
}
export class RCUSanctionDiscrepant implements IRCUSanctionDiscrepant{
    loanAccountNumber: string='';
    applicationNo: string='';
    docType: string=''; 
    docRCUStatus: string='';
    docReason:string='';
    docSubreason: string='';
    docRemark: string='';
    constructor(param?:IRCUSanctionDiscrepant){
        if(param){
        this.loanAccountNumber= param.loanAccountNumber;
        this.applicationNo= param.applicationNo;
        this.docType= param.docType;
        this.docRCUStatus=param.docRCUStatus;
        this.docReason=param.docReason;
        this.docSubreason=param.docSubreason;
        this.docRemark= param.docRemark; 
        }
    }

}


export interface IRCUSanctionSubmit{
    loanAccountNumber: string;
    login_ps_id:string;
    preSancRCU_Sample_Review: string;
    preSancRCU_TriggerType: string;
    preSancRCU_ARM_Action: string;
    preSancRCU_RejectReason: string;
    preSancRCU_RejectSubReason: string;
    preSancRCU_ARM_Remarks: string;
    preSancTypeOfVerification: string;
    preSancRCU_RRMV_Action: string;
    preSancRCU_RRMV_Remarks: string;
    preSancRCU_RRMI_Action: string;
    preSancRCU_RRMI_Remarks: string;
    postSancRCU_Status: string;
    postSancRCU_Sample_Review: string;
    postSancRCU_ARM_Action: string;
    postSancRCU_RejectReason: string;
    postSancRCU_RejectSubReason: string;
    postSancRCU_ARM_Remarks: string;
    postSancTypeOfVerification: string;
    postSancRCU_RRMV_Action: string;
    postSancRCU_RRMV_Remarks: string;
    postSancRCU_RRMI_Action: string;
    postSancRCU_RRMI_Remarks: string;
    TokenNumber: string;
    preSancRCU_Status: string;
    preSancRCU_ARM_TriggeredDate:Date,
    preSancRCU_RRMV_TriggeredDate:Date,
    preSancRCU_RRMI_TriggeredDate:Date,
    postSancRCU_TriggerType: string;
    postSancRCU_ARM_TriggeredDate:Date,
    postSancRCU_RRMV_TriggeredDate:Date,
    postSancRCU_RRMI_TriggeredDate:Date,
    createdBy: string;
    createdOn:Date,
    modifiedBy: string;
    modifiedOn:Date;
    rcuDiscrepantResult: RCUSanctionDiscrepant[];
    roleId:string;
    screenType:string;
    preSanc_RRMI_RiskAlertDetails:string;
    preSanc_RRMI_RemarksBy_ARM:string;
    preSanc_RRMI_RiskControlType:string;
    preSanc_RRMI_FinalRemarksByDM:string;
    postSanc_RRMI_RiskAlertDetails:string;
    postSanc_RRMI_RemarksBy_ARM:string;
    postSanc_RRMI_RiskControlType:string;
    postSanc_RRMI_FinalRemarksByDM:string;
    postTokenNumber:string;
    post_RRMI_Upload_Ref:string;
    pre_RRMI_Upload_Ref:string;
    postSancRCU_ARM_Query:string;
}

export class RCUSanctionSubmit implements IRCUSanctionSubmit{
    loanAccountNumber: string='';
    login_ps_id:string='';
    preSancRCU_Sample_Review: string='';
    preSancRCU_TriggerType: string='';
    preSancRCU_ARM_Action: string='';
    preSancRCU_RejectReason: string='';
    preSancRCU_RejectSubReason: string='';
    preSancRCU_ARM_Remarks: string='';
    preSancTypeOfVerification: string='';
    preSancRCU_RRMV_Action: string='';
    preSancRCU_RRMV_Remarks: string='';
    preSancRCU_RRMI_Action: string='';
    preSancRCU_RRMI_Remarks: string='';
    postSancRCU_Status: string='';
    postSancRCU_Sample_Review: string='';
    postSancRCU_ARM_Action: string='';
    postSancRCU_RejectReason: string='';
    postSancRCU_RejectSubReason: string='';
    postSancRCU_ARM_Remarks: string='';
    postSancTypeOfVerification: string='';
    postSancRCU_RRMV_Action: string='';
    postSancRCU_RRMV_Remarks: string='';
    postSancRCU_RRMI_Action: string='';
    postSancRCU_RRMI_Remarks: string='';
    TokenNumber: string='';
    preSancRCU_Status: string='';
    preSancRCU_ARM_TriggeredDate:Date = new Date();
    preSancRCU_RRMV_TriggeredDate:Date= new Date();
    preSancRCU_RRMI_TriggeredDate:Date= new Date();
    postSancRCU_TriggerType: string='';
    postSancRCU_ARM_TriggeredDate:Date= new Date();
    postSancRCU_RRMV_TriggeredDate:Date= new Date();
    postSancRCU_RRMI_TriggeredDate:Date= new Date();
    createdBy: string='';
    createdOn:Date= new Date();
    modifiedBy: string='';
    modifiedOn:Date= new Date();
    rcuDiscrepantResult: RCUSanctionDiscrepant[]=[];
    roleId:string='';
    screenType:string='';
    preSanc_RRMI_RiskAlertDetails:string='';
    preSanc_RRMI_RemarksBy_ARM:string='';
    preSanc_RRMI_RiskControlType:string='';
    preSanc_RRMI_FinalRemarksByDM:string='';
    postSanc_RRMI_RiskAlertDetails:string='';
    postSanc_RRMI_RemarksBy_ARM:string='';
    postSanc_RRMI_RiskControlType:string='';
    postSanc_RRMI_FinalRemarksByDM:string='';
    postTokenNumber:string='';
    post_RRMI_Upload_Ref:string='';
    pre_RRMI_Upload_Ref:string='';
    postSancRCU_ARM_Query:string='';

    constructor(param?:IRCUSanctionSubmit){

        if(param){
        this.loanAccountNumber = param.loanAccountNumber;
        this.preSancRCU_Sample_Review = param.preSancRCU_Sample_Review;
        this.preSancRCU_TriggerType= param.preSancRCU_TriggerType;
        this.preSancRCU_ARM_Action= param.preSancRCU_ARM_Action;
        this.preSancRCU_RejectReason= param.preSancRCU_RejectReason;
        this.preSancRCU_RejectSubReason= param.preSancRCU_RejectSubReason;
        this.preSancRCU_ARM_Remarks= param.preSancRCU_ARM_Remarks;
        this.preSancTypeOfVerification= param.preSancRCU_Sample_Review;
        this.preSancRCU_RRMV_Action = param.preSancRCU_RRMV_Action;
        this.preSancRCU_RRMV_Remarks=param.preSancRCU_RRMV_Remarks;
        this.preSancRCU_RRMI_Action=param.preSancRCU_RRMI_Action;
        this.preSancRCU_RRMI_Remarks=param.preSancRCU_RRMI_Remarks;
        this.postSancRCU_Status=param.postSancRCU_Status;
        this.postSancRCU_Sample_Review=param.postSancRCU_Sample_Review;
        this.postSancRCU_ARM_Action=param.postSancRCU_ARM_Action;
        this.postSancRCU_RejectReason=param.postSancRCU_RejectReason;
        this.postSancRCU_RejectSubReason=param.postSancRCU_RejectSubReason;
        this.postSancRCU_ARM_Remarks=param.postSancRCU_ARM_Remarks;
        this.postSancTypeOfVerification=param.postSancTypeOfVerification;
        this.postSancRCU_RRMV_Action=param.postSancRCU_RRMV_Action;
        this.postSancRCU_RRMV_Remarks=param.postSancRCU_RRMV_Remarks;
        this.postSancRCU_RRMI_Action=param.postSancRCU_RRMI_Action;
        this.postSancRCU_RRMI_Remarks=param.postSancRCU_RRMI_Remarks;
        this.TokenNumber=param.TokenNumber;
        this.preSancRCU_Status=param.preSancRCU_Status;
        this.preSancRCU_ARM_TriggeredDate=param.preSancRCU_ARM_TriggeredDate;
        this.preSancRCU_RRMV_TriggeredDate=param.preSancRCU_RRMV_TriggeredDate;
        this.preSancRCU_RRMI_TriggeredDate=param.preSancRCU_RRMI_TriggeredDate;
        this.postSancRCU_TriggerType=param.postSancRCU_TriggerType;
        this.postSancRCU_ARM_TriggeredDate=param.postSancRCU_ARM_TriggeredDate;
        this.postSancRCU_RRMV_TriggeredDate=param.postSancRCU_RRMV_TriggeredDate;
        this.postSancRCU_RRMI_TriggeredDate=param.postSancRCU_RRMI_TriggeredDate;
        this.createdBy=param.createdBy;
        this.createdOn=param.createdOn;
        this.modifiedBy=param.modifiedBy;
        this.modifiedOn=param.modifiedOn;
        this.rcuDiscrepantResult=param.rcuDiscrepantResult;
        this.roleId=param.roleId;
        this.screenType=param.screenType;
        this.preSanc_RRMI_RiskAlertDetails=param.preSanc_RRMI_RiskAlertDetails;
        this.preSanc_RRMI_RemarksBy_ARM=param.preSanc_RRMI_RemarksBy_ARM;
        this.preSanc_RRMI_RiskControlType=param.preSanc_RRMI_RiskControlType;
        this.preSanc_RRMI_FinalRemarksByDM=param.preSanc_RRMI_FinalRemarksByDM;
        this.postSanc_RRMI_RiskAlertDetails=param.postSanc_RRMI_RiskAlertDetails;
        this.postSanc_RRMI_RemarksBy_ARM=param.postSanc_RRMI_RemarksBy_ARM;
        this.postSanc_RRMI_RiskControlType=param.postSanc_RRMI_RiskControlType;
        this.postSanc_RRMI_FinalRemarksByDM=param.postSanc_RRMI_FinalRemarksByDM;
        this.postTokenNumber=param.postTokenNumber;
        this.post_RRMI_Upload_Ref=param.post_RRMI_Upload_Ref;
        this.pre_RRMI_Upload_Ref=param.pre_RRMI_Upload_Ref;
        this.postSancRCU_ARM_Query=param.postSancRCU_ARM_Query;
        this.login_ps_id=param.login_ps_id;
        }
     
    }
}

export interface IRCUBankingModel{
      bankName: string;
      branchName: string;
      bankAccountNumber: string;
      bankAccountHolderName: string;
      ifscCode: string;
      averageBankBalance: number;
      servicableEMI: string;
}

export class RCUBankingModel implements IRCUBankingModel{
    bankName: string='';
    branchName: string='';
    bankAccountNumber: string='';
    bankAccountHolderName: string='';
    ifscCode: string='';
    averageBankBalance: number=0;
    servicableEMI: string='';

    constructor(param?:IRCUBankingModel)
    {
        if(param){
        this.bankName=param.bankName;
        this.branchName=param.branchName;
        this.bankAccountNumber=param.bankAccountNumber;
        this.bankAccountHolderName=param.bankAccountHolderName;
        this.ifscCode=param.ifscCode;
        this.averageBankBalance=param.averageBankBalance;
        this.servicableEMI=param.servicableEMI;
        }
    }
}

export interface IHAPhysicalDiscussionModel{
    point_of_Contact: string;
    createdDate: string;
    createdTime: string;
    sales_FLO_Name: string;
    sales_FLO_PSID: string;
    creditOfcr_Designation: string;
    creditOfcr_PSID: string;
    creditOfcr_Name: string;
    physicalDiscussionType:string;
}

export class HAPhysicalDiscussionModel implements IHAPhysicalDiscussionModel{
    point_of_Contact: string='';
    createdDate: string='';
    createdTime: string='';
    sales_FLO_Name: string='';
    sales_FLO_PSID: string='';
    creditOfcr_Designation: string='';
    creditOfcr_PSID: string='';
    creditOfcr_Name: string='';
    physicalDiscussionType:string='';

    constructor(param?:IHAPhysicalDiscussionModel){
        if(param){
            this.point_of_Contact=param.point_of_Contact;
            this.createdDate=param.createdDate;
            this.createdTime=param.createdTime;
            this.sales_FLO_Name=param.sales_FLO_Name;
            this.sales_FLO_PSID =param.sales_FLO_PSID;
            this.creditOfcr_Designation=param.creditOfcr_Designation;
            this.creditOfcr_PSID=param.creditOfcr_PSID;
            this.creditOfcr_Name=param.creditOfcr_Name;
            this.physicalDiscussionType=param.physicalDiscussionType;
        }

    }
}
 
export interface IHAAccomodationAndCompositionModel{

      locality: string;
      noOfFamilyMembers: string;
      constructionType: string;
      adults: string;
      houseCategory: string;
      earningMembers: string;
      propertyType: string;
      dependentMembers: string;
      children: string;
      noOfChildrenGoingToSchoolNCollege: string;
      TypeOfSchoolCollege:string;

}

export class HAAccomodationAndCompositionModel implements IHAAccomodationAndCompositionModel{
    locality: string='';
    noOfFamilyMembers: string='';
    constructionType: string='';
    adults: string='';
    houseCategory: string='';
    earningMembers: string='';
    propertyType: string='';
    dependentMembers: string='';
    children: string='';
    noOfChildrenGoingToSchoolNCollege: string='';    
    TypeOfSchoolCollege: string='';

    constructor(param?:IHAAccomodationAndCompositionModel){

        if(param){
        this.locality=param.locality;
        this.noOfFamilyMembers=param.noOfFamilyMembers;
        this.constructionType=param.constructionType;
        this.adults=param.adults;
        this.houseCategory=param.houseCategory;
        this.earningMembers=param.earningMembers;
        this.propertyType=param.propertyType;
        this.dependentMembers=param.dependentMembers;
        this.children=param.children;
        this.noOfChildrenGoingToSchoolNCollege=param.noOfChildrenGoingToSchoolNCollege;
        this.TypeOfSchoolCollege=param.TypeOfSchoolCollege;
     }
    }

}

export interface IFinancialModel{
    applicationNo: string;
    salary_Status: string;
    financial_status: string;
    name: string;
    occupation: string;
}

export class FinancialModel implements IFinancialModel{

    applicationNo: string='';
    salary_Status: string='';
    financial_status: string='';
    name: string='';
    occupation: string='';
     
    constructor(param?:IFinancialModel) {
        if(param){
            this.applicationNo=param.applicationNo;
            this.salary_Status=param.salary_Status;
            this.financial_status=param.financial_status;
            this.name=param.name;
            this.occupation=param.occupation;
        }
    }
}

export interface IIASalariesModel{
    applicationNo: string;
    employerName: string;
    emplyr_Industry: string;
    grossSal_Annual: string;
    salaryMode: string;
    serviceDuration_Years: string;
    workExp_Total_Years: string;
    emplyr_Relation: string;
    emplyr_partofLoan_conf: string;
    officeAddrss: string;
    emplyr_PinCode: string;
    emplyr_Village: string;
    emplyr_District: string;
    emplyr_State: string;
    prev_Emplyr_Contact: string;
}

export class IASalariesModel implements IIASalariesModel{
    applicationNo: string='';
    employerName: string='';
    emplyr_Industry: string='';
    grossSal_Annual: string='';
    salaryMode: string='';
    serviceDuration_Years: string='';
    workExp_Total_Years: string='';
    emplyr_Relation: string='';
    emplyr_partofLoan_conf: string='';
    officeAddrss: string='';
    emplyr_PinCode: string='';
    emplyr_Village: string='';
    emplyr_District: string='';
    emplyr_State: string='';
    prev_Emplyr_Contact: string='';

    /**
     *
     */
    constructor(param?:IASalariesModel) {
        if(param){
            this.applicationNo= param.applicationNo;
            this.employerName=param.employerName;
            this.emplyr_Industry=param.emplyr_Industry;
            this.grossSal_Annual=param.grossSal_Annual;
            this.salaryMode=param.salaryMode;
            this.serviceDuration_Years=param.serviceDuration_Years;
            this.workExp_Total_Years=param.workExp_Total_Years;
            this.emplyr_Relation=param.emplyr_Relation;
            this.emplyr_partofLoan_conf=param.emplyr_partofLoan_conf;
            this.officeAddrss=param.officeAddrss;
            this.emplyr_PinCode=param.emplyr_PinCode;
            this.emplyr_Village=param.emplyr_Village;
            this.emplyr_District=param.emplyr_District;
            this.emplyr_State = param.emplyr_State;
            this.prev_Emplyr_Contact = param.prev_Emplyr_Contact;
        }
    }

}

export interface ISelfEmployeeModel{
    applicationNo:string;
    mainLineOfBusiness: string;
    businessAddress:string;
    village: string;
    city: string;
    district: string;
    state: string;
    totalRevenueEarned_CurrentYear: string;
    pincode: string;
    totalExpensesCurrentYear: string;
    numofPartners:string;
    profSharingRatio:string;
    totalRevenueEarnedMonthly:number;
    total_Exp_monthly:number;
    typeOfBusiness:string;
}

export class SelfEmployeeModel implements ISelfEmployeeModel{
    mainLineOfBusiness: string='';
    businessAddress: string='';
    village: string='';
    city: string='';
    district: string='';
    state: string='';
    totalRevenueEarned_CurrentYear: string='';
    pincode: string='';
    totalExpensesCurrentYear: string='';
    applicationNo: string=''; 
    numofPartners: string='';
    profSharingRatio: string='';
    totalRevenueEarnedMonthly: number=0;
    total_Exp_monthly: number=0;
    typeOfBusiness:string='';

    /**
     *
     */
    constructor(param?:ISelfEmployeeModel) {
       if(param){
        this.mainLineOfBusiness=param.mainLineOfBusiness;
        this.businessAddress=param.businessAddress;
        this.village=param.village;
        this.city=param.city;
        this.district=param.district;
        this.state=param.state;
        this.totalRevenueEarned_CurrentYear=param.totalRevenueEarned_CurrentYear;
        this.pincode= param.pincode;
        this.totalExpensesCurrentYear = param.totalExpensesCurrentYear;
        this.applicationNo= param.applicationNo;
        this.numofPartners= param.numofPartners;
        this.profSharingRatio= param.profSharingRatio;
        this.totalRevenueEarnedMonthly= param.totalRevenueEarnedMonthly;
        this.total_Exp_monthly= param.total_Exp_monthly;
        this.typeOfBusiness=param.typeOfBusiness;
       } 
    } 
   
}

export interface IBusinessModel{

    applicationNo:String;
    typeOfBusiness:String;
    numofPartners:String;
    profSharingRatio:String;
    totalRevenueEarnedMonthly:number;
    total_Exp_monthly:number;
    totalRevenueEarned_CurrentYear:number;
    totalExpensesCurrentYear:number;

}

export class BusinessModel implements IBusinessModel{
    applicationNo: String='';
    typeOfBusiness: String='';
    numofPartners: String='';
    profSharingRatio: String='';
    totalRevenueEarnedMonthly: number=0;
    total_Exp_monthly: number=0;
    totalRevenueEarned_CurrentYear: number=0;
    totalExpensesCurrentYear: number=0;

    /**
     *
     */
    constructor(param?:IBusinessModel) {
        if(param){
            this.applicationNo=param.applicationNo;
            this.typeOfBusiness=param.typeOfBusiness;
            this.numofPartners=param.numofPartners;
            this.profSharingRatio=param.profSharingRatio;
            this.totalRevenueEarnedMonthly=param.totalRevenueEarnedMonthly;
            this.total_Exp_monthly = param.total_Exp_monthly
            this.totalRevenueEarned_CurrentYear=param.totalRevenueEarned_CurrentYear;
            this.totalExpensesCurrentYear=param.totalExpensesCurrentYear;
        }        
    }

}
  
export interface IRCUBSanctionModel{
    haPhysicalDiscussion: HAPhysicalDiscussionModel[];
    haAccomodationAndComposition : HAAccomodationAndCompositionModel[];
    finanicalDetail:FinancialModel[];
    iaSalaries:IASalariesModel[];
    selfEmployedDetail:SelfEmployeeModel[];
   // businessModel : BusinessModel[];    
}

export class RCUBSanctionModel implements IRCUBSanctionModel{
    haPhysicalDiscussion: HAPhysicalDiscussionModel[]=[];
    haAccomodationAndComposition: HAAccomodationAndCompositionModel[]=[];
    finanicalDetail: FinancialModel[]=[];
    iaSalaries: IASalariesModel[]=[];
    selfEmployedDetail: SelfEmployeeModel[]=[];
    //businessModel: BusinessModel[]=[];

    /**
     *
     */
    constructor(param?:IRCUBSanctionModel) {

        if(param){
            this.haPhysicalDiscussion=param.haPhysicalDiscussion;
            this.haAccomodationAndComposition=param.haAccomodationAndComposition;
            this.finanicalDetail=param.finanicalDetail;
            this.iaSalaries=param.iaSalaries;
            this.selfEmployedDetail=param.selfEmployedDetail;
            //this.businessModel=param.businessModel;
        }
    } 
}

export interface IPropertyModel{
    propertyUsageType: string;
    commercialUsePercentage: string;
    landApprovalType: string;
    landType: string;
    houseType: string;
    surroundingArea: string;
    localityType: string;
    approachRoadType: string;
    constructionQuality: string;
    constructionYear: string;
    property_Type: string;
    unitDetails: string;
    constructionType: string;
    residualValYrs: string;
    materialWall: string;
    materialRoof: string;
    meterialFloor: string;
    modificationDtl: string;
    ownerName:string;
    rel_with_applicant:string;
}

export class PropertyModel implements IPropertyModel{
    propertyUsageType: string='';
    commercialUsePercentage: string='';
    landApprovalType: string='';
    landType: string='';
    houseType: string='';
    surroundingArea: string='';
    localityType: string='';
    approachRoadType: string='';
    constructionQuality: string='';
    constructionYear: string='';
    property_Type: string='';
    unitDetails: string='';
    constructionType: string='';
    residualValYrs: string='';
    materialWall: string='';
    materialRoof: string='';
    meterialFloor: string='';
    modificationDtl: string='';
    ownerName: string='';
    rel_with_applicant: string='';

    /**
     *
     */
    constructor(param?:IPropertyModel) {
       if(param){
        this.propertyUsageType=param.propertyUsageType;
        this.commercialUsePercentage=param.commercialUsePercentage;
        this.landApprovalType=param.landApprovalType;
        this.landType=param.landType;
        this.houseType=param.houseType;
        this.surroundingArea=param.surroundingArea;
        this.localityType=param.localityType;
        this.approachRoadType=param.approachRoadType;
        this.constructionQuality=param.constructionQuality;
        this.constructionYear=param.constructionYear;
        this.property_Type=param.property_Type;
        this.unitDetails=param.unitDetails;
        this.constructionType=param.constructionType;
        this.residualValYrs=param.residualValYrs;
        this.materialWall=param.materialWall;
        this.materialRoof=param.materialRoof;
        this.meterialFloor=param.meterialFloor;
        this.modificationDtl=param.modificationDtl;
        this.ownerName=param.ownerName;
        this.rel_with_applicant=param.rel_with_applicant;
       }        
    }
    
}

export interface IRCUFinalReviewModel{ 
    preSancRCU_Sample_Review:string;
    preSancRCU_ARM_Action:string;
    preSancRCU_RejectReason:string;
    preSancRCU_RejectSubReason:string;
    preSancRCU_ARM_Remarks:string;
    preSancTypeOfVerification:string;
    preSancRCU_RRMV_Action:string;
    preSancRCU_RRMV_Remarks:string;
    preSancRCU_RRMI_Action:string;
    preSancRCU_RRMI_Remarks:string;
    postSancRCU_Status:string;
    postSancRCU_Sample_Review:string;
    postSancRCU_ARM_Action:string;
    postSancRCU_RejectReason:string;
    postSancRCU_RejectSubReason:string;
    postSancRCU_ARM_Remarks:string;
    postSancTypeOfVerification:string;
    postSancRCU_RRMV_Action:string;
    postSancRCU_RRMV_Remarks:string;
    postSancRCU_RRMI_Action:string;
    postSancRCU_RRMI_Remarks:string;
    pre_RRMI_Upload_YN:string; 
    post_RRMI_Upload_YN:string; 
    postSanc_RRMI_RiskAlertDetails:string;
    postSanc_RRMI_RemarksBy_ARM:string;
    postSanc_RRMI_RiskControlType:string;
    postSanc_RRMI_FinalRemarksByDM:string;
    preSanc_RRMI_FinalRemarksByDM:string;
    preSanc_RRMI_RiskAlertDetails:string;
    preSanc_RRMI_RemarksBy_ARM:string;
    preSanc_RRMI_RiskControlType:string; 
    tokenNumber:string;
    postTokenNumber:string;
    post_RRMI_Upload_Ref:string;
    pre_RRMI_Upload_Ref:string;
    postSancRCU_ARM_Query:string;
}

export class RCUFinalReviewModel implements IRCUFinalReviewModel{
    preSancRCU_Sample_Review: string='';
    preSancRCU_ARM_Action: string='';
    preSancRCU_RejectReason: string='';
    preSancRCU_RejectSubReason: string='';
    private _preSancRCU_ARM_Remarks: string='';

    public get preSancRCU_ARM_Remarks():string{
        return this._preSancRCU_ARM_Remarks;
    }
    public set preSancRCU_ARM_Remarks(value:string){
        this._preSancRCU_ARM_Remarks=value;
    }

    preSancTypeOfVerification: string='';
    preSancRCU_RRMV_Action: string='';
    
    private _preSancRCU_RRMV_Remarks: string=''; 

    public get preSancRCU_RRMV_Remarks():string{
        return this._preSancRCU_RRMV_Remarks;
    }
    public set preSancRCU_RRMV_Remarks(value:string){
        this._preSancRCU_RRMV_Remarks=value;
    }

    preSancRCU_RRMI_Action: string='';
     
    private _preSancRCU_RRMI_Remarks:string ='';
    public get preSancRCU_RRMI_Remarks():string{
        return this._preSancRCU_RRMI_Remarks;
    }
    public set preSancRCU_RRMI_Remarks(value:string){
        this._preSancRCU_RRMI_Remarks=value;
    }
    postSancRCU_Status: string='';
    postSancRCU_Sample_Review: string='';
    postSancRCU_ARM_Action: string='';
    postSancRCU_RejectReason: string='';
    postSancRCU_RejectSubReason: string='';
    private _postSancRCU_ARM_Remarks: string='';

    public get postSancRCU_ARM_Remarks():string{
        return this._postSancRCU_ARM_Remarks;
    }
    public set postSancRCU_ARM_Remarks(value:string){
        this._postSancRCU_ARM_Remarks=value;
    }
    postSancTypeOfVerification: string='';
    postSancRCU_RRMV_Action: string='';
    private _postSancRCU_RRMV_Remarks: string='';

    public get postSancRCU_RRMV_Remarks():string{
        return this._postSancRCU_RRMV_Remarks;
    }
    public set postSancRCU_RRMV_Remarks(value:string){
        this._postSancRCU_RRMV_Remarks=value;
    }
    postSancRCU_RRMI_Action: string='';
    private _postSancRCU_RRMI_Remarks: string='';

    public get postSancRCU_RRMI_Remarks():string{
        return this._postSancRCU_RRMI_Remarks;
    }
    public set postSancRCU_RRMI_Remarks(value:string){
        this._postSancRCU_RRMI_Remarks=value;
    }
    pre_RRMI_Upload_YN: string=''; 
    post_RRMI_Upload_YN: string=''; 
    postSanc_RRMI_RiskAlertDetails: string='';
    postSanc_RRMI_RemarksBy_ARM: string='';
    postSanc_RRMI_RiskControlType: string='';
    postSanc_RRMI_FinalRemarksByDM: string='';
    preSanc_RRMI_FinalRemarksByDM: string='';
    preSanc_RRMI_RiskAlertDetails: string='';
    preSanc_RRMI_RemarksBy_ARM: string='';
    preSanc_RRMI_RiskControlType: string='';
    tokenNumber:string='';
    postTokenNumber:string='';
    post_RRMI_Upload_Ref:string='';
    pre_RRMI_Upload_Ref:string='';
    postSancRCU_ARM_Query:string='';
    /**
     *
     */
    constructor(param?:IRCUFinalReviewModel) {
       if(param){
        this.preSancRCU_Sample_Review =param.preSancRCU_Sample_Review;
        this.preSancRCU_ARM_Action =param.preSancRCU_ARM_Action;
        this.preSancRCU_RejectReason =param.preSancRCU_RejectReason;
        this.preSancRCU_RejectSubReason =param.preSancRCU_RejectSubReason;
        this.preSancRCU_ARM_Remarks =param.preSancRCU_ARM_Remarks;
        this.preSancTypeOfVerification =param.preSancTypeOfVerification;
        this.preSancRCU_RRMV_Action =param.preSancRCU_RRMV_Action;
        this.preSancRCU_RRMV_Remarks =param.preSancRCU_RRMV_Remarks;
        this.preSancRCU_RRMI_Action =param.preSancRCU_RRMI_Action;
        this.preSancRCU_RRMI_Remarks =param.preSancRCU_RRMI_Remarks;
        this.postSancRCU_Status =param.postSancRCU_Status;
        this.postSancRCU_Sample_Review =param.postSancRCU_Sample_Review;
        this.postSancRCU_ARM_Action =param.postSancRCU_ARM_Action;
        this.postSancRCU_RejectReason =param.postSancRCU_RejectReason;
        this.postSancRCU_RejectSubReason =param.postSancRCU_RejectSubReason;
        this.postSancRCU_ARM_Remarks =param.postSancRCU_ARM_Remarks;
        this.postSancTypeOfVerification =param.postSancTypeOfVerification;
        this.postSancRCU_RRMV_Action =param.postSancRCU_RRMV_Action;
        this.postSancRCU_RRMV_Remarks =param.postSancRCU_RRMV_Remarks;
        this.postSancRCU_RRMI_Action =param.postSancRCU_RRMI_Action;
        this.postSancRCU_RRMI_Remarks =param.postSancRCU_RRMI_Remarks;
        this.pre_RRMI_Upload_YN =param.pre_RRMI_Upload_YN; 
        this.post_RRMI_Upload_YN=param.post_RRMI_Upload_YN;
        this.postSanc_RRMI_RiskAlertDetails=param.postSanc_RRMI_RiskAlertDetails;
        this.postSanc_RRMI_RemarksBy_ARM=param.postSanc_RRMI_RemarksBy_ARM;
        this.postSanc_RRMI_RiskControlType=param.postSanc_RRMI_RiskControlType;
        this.postSanc_RRMI_FinalRemarksByDM=param.postSanc_RRMI_FinalRemarksByDM;
        this.preSanc_RRMI_FinalRemarksByDM=param.preSanc_RRMI_FinalRemarksByDM;
        this.preSanc_RRMI_RiskAlertDetails=param.preSanc_RRMI_RiskAlertDetails;
        this.preSanc_RRMI_RemarksBy_ARM=param.preSanc_RRMI_RemarksBy_ARM;
        this.preSanc_RRMI_RiskControlType=param.preSanc_RRMI_RiskControlType;
        this.tokenNumber=param.tokenNumber;
        this.postTokenNumber=param.postTokenNumber;
        this.post_RRMI_Upload_Ref=param.post_RRMI_Upload_Ref;
        this.pre_RRMI_Upload_Ref=param.pre_RRMI_Upload_Ref;
        this.postSancRCU_ARM_Query=param.postSancRCU_ARM_Query;
       }
    } 
}

export interface IInterActionDetail{
    loanAccountNumber:string;
    sender:string;
    sender_Remarks:string;
    sender_Doc1:string;
    sender_Doc2:string;
    receiver:string;
    receiver_Remarks:string;
    receiver_Doc1:string;
    receiver_Doc2:string;
    status:string;
    createdBy:string;
    createdOn:string;
    modifiedBy:string;
    modifiedOn:string;
    sender_Role:string;
    receiver_Doc3:string;
    receiver_Doc4:string;
    source:string;
    receiver_Role:string;
    sender_Doc3:string;
    sender_Doc4:string;
    receiverDoc1_UUID:string;
    receiverDoc2_UUID:string;
    receiverDoc3_UUID:string;
    receiverDoc4_UUID:string;
    senderDoc1_UUID:string;
    senderDoc2_UUID:string;
    senderDoc3_UUID:string;
    senderDoc4_UUID:string;
    receiver_Remarks_Date:string;
    interactionId:number;
    docs:DocumentInfo[]; 
}

export class InterActionDetail{
    loanAccountNumber:string='';
    sender:string='';
    sender_Remarks:string='';
    sender_Doc1:string='';
    sender_Doc2:string='';
    receiver:string='';
    receiver_Remarks:string='';
    private _receiver_Doc1:string='';

    public get receiver_Doc1(): string {
        return this._receiver_Doc1;
    }
    public set receiver_Doc1(value: string) { 
        this.populateDoc(value,"documentType",0);
        this._receiver_Doc1 = value;       
    }

    private _receiver_Doc2:string='';

    public get receiver_Doc2(): string {
        return this._receiver_Doc2;
    }
    public set receiver_Doc2(value: string) { 
        this.populateDoc(value,"documentType",1);
        // if(value!==null && value!==""){
        //     let doc = new DocumentInfo();
        //     doc.documentType = this.receiver_Doc2;
        //     doc.uuid=this.receiverDoc2_UUID;

        //     this.docs.push(doc);
        // }
        this._receiver_Doc2 = value;       
    }
    status:string='';
    createdBy:string='';
    createdOn:string='';
    modifiedBy:string='';
    modifiedOn:string='';
    sender_Role:string='';
    receiver_Remarks_Date:string='';
    private _receiver_Doc3:string='';
    
    public get receiver_Doc3(): string {
        return this._receiver_Doc3;
    }
    public set receiver_Doc3(value: string) { 

        this.populateDoc(value,"documentType",2);
        // if(value!==null && value!==""){
        //     let doc = new DocumentInfo();
        //     doc.documentType = this.receiver_Doc3;
        //     doc.uuid=this.receiverDoc3_UUID;

        //     this.docs.push(doc);
        // }
        this._receiver_Doc3 = value;       
    }    

    private _receiver_Doc4:string='';
    
    public get receiver_Doc4(): string {
        return this._receiver_Doc4;
    }
    public set receiver_Doc4(value: string) {         
        this.populateDoc(value,"documentType",3);
        this._receiver_Doc4 = value;       
    }

    source:string='';
    receiver_Role:string='';
    sender_Doc3:string='';
    sender_Doc4:string='';

    _receiverDoc1_UUID:string='';
    public get receiverDoc1_UUID(): string {
        return this._receiverDoc1_UUID;
    }
    public set receiverDoc1_UUID(value: string) {         
        this.populateDoc(value,"UUID",0);
        this._receiverDoc1_UUID = value;       
    }


    _receiverDoc2_UUID:string='';
    public get receiverDoc2_UUID(): string {
        return this._receiverDoc2_UUID;
    }
    public set receiverDoc2_UUID(value: string) {         
        this.populateDoc(value,"UUID",1);
        this._receiverDoc2_UUID = value;       
    }

    _receiverDoc3_UUID:string='';
    public get receiverDoc3_UUID(): string {
        return this._receiverDoc3_UUID;
    }
    public set receiverDoc3_UUID(value: string) {         
        this.populateDoc(value,"UUID",2);
        this._receiverDoc3_UUID = value;       
    }


    _receiverDoc4_UUID:string='';
    public get receiverDoc4_UUID(): string {
        return this._receiverDoc2_UUID;
    }
    public set receiverDoc4_UUID(value: string) {         
        this.populateDoc(value,"UUID",3);
        this._receiverDoc4_UUID = value;       
    }
    // receiverDoc2_UUID:string='';
    // receiverDoc3_UUID:string='';
    // receiverDoc4_UUID:string='';
    senderDoc1_UUID:string='';
    senderDoc2_UUID:string='';
    senderDoc3_UUID:string='';
    senderDoc4_UUID:string='';
    interactionId:number=0;
    docs:DocumentInfo[]=[];

    /**
     *
     */
    constructor(param?:IInterActionDetail) {
        if(param){
            this.loanAccountNumber=param.loanAccountNumber;
            this.sender=param.sender;
            this.sender_Remarks=param.sender_Remarks;
            this.receiverDoc1_UUID=param.receiverDoc1_UUID;
            this.receiverDoc2_UUID=param.receiverDoc2_UUID;
            this.receiverDoc3_UUID=param.receiverDoc3_UUID;
            this.receiverDoc4_UUID=param.receiverDoc4_UUID;
            this.senderDoc1_UUID=param.senderDoc1_UUID;
            this.senderDoc2_UUID=param.senderDoc2_UUID;
            this.senderDoc3_UUID=param.senderDoc3_UUID;
            this.senderDoc4_UUID=param.senderDoc4_UUID;
            this.sender_Doc1=param.sender_Doc1;
            this.sender_Doc2=param.sender_Doc2;
            this.receiver=param.receiver;
            this.receiver_Remarks=param.receiver_Remarks;
            this.receiver_Doc1=param.receiver_Doc1
            this.receiver_Doc2=param.receiver_Doc2
            this.status=param.status;
            this.createdBy=param.createdBy;
            this.createdOn=param.createdOn;
            this.modifiedBy=param.modifiedBy;
            this.modifiedOn=param.modifiedOn;
            this.sender_Role=param.sender_Role;
            this.receiver_Doc3=param.receiver_Doc3;
            this.receiver_Doc4=param.receiver_Doc4;
            this.source=param.source;
            this.receiver_Role=param.receiver_Role;
            this.sender_Doc3=param.sender_Doc3;
            this.sender_Doc4=param.sender_Doc4; 
            this.receiver_Remarks_Date= param.receiver_Remarks_Date;
            //this.docs=param.docs;
            this.interactionId=param.interactionId;
        }        
    }

    populateDoc(value:string,key:string,indentifier:number){ 
        let doc = new DocumentInfo();

       if(value!=="" && (this.docs.length <= indentifier || this.docs.length===0)){ 
            if(key==="documentType"){
               doc.documentType=value;
            }
            if(key==="UUID"){
                doc.uuid=value;
             } 
            this.docs.push(doc); 
        }else if(value!="" && this.docs.length>=indentifier){
            this.docs.forEach((item,index)=>{
                if(index===indentifier){
                    if(key==="documentType"){
                        item.documentType=value;
                     }
                     if(key==="UUID"){
                         item.uuid=value;
                      } 
                }
            })
        }
       
    }
}
import { CustomRouteConfig } from "src/app/shared/models/common/route-config";
import { RCUDashComponent } from "./dashboard/dashboard.component";
import { PendingScreeningComponent } from "./pendingscreening/pendingscreening";
import{SampledCasesComponent} from "./sampledcases/sampledcases";
import{RiskAlertCasesComponent} from "./riskalertcases/riskalertcases";
import{ClosedCasesComponent} from "./closedcases/closedcases";
import { RCULanDOCFilterPipe } from './RCULanDOCFilterPipe';
import { RiskdashboardComponent } from "./riskdashboard/riskdashboard.component";

export const RiskControlUnitModule = [PendingScreeningComponent, RCUDashComponent,SampledCasesComponent,RiskAlertCasesComponent,
    ClosedCasesComponent,RCULanDOCFilterPipe,RiskdashboardComponent]

export const RiskControlUnitRoute: CustomRouteConfig[] = [];


//Parent Menu
RiskControlUnitRoute.push(new CustomRouteConfig({ menuName: "Risk Control Unit", title: "Risk Control Unit", path: "riskcontrolunit", redirectTo: "/riskcontolunitdash" }));

RiskControlUnitRoute.push(new CustomRouteConfig({ path: "riskcontolunitdash", componentName: RCUDashComponent, title: "Risk Control Unit / Dashboard", parentName: "Risk Control Unit" }));

//Child menu
RiskControlUnitRoute.push(new CustomRouteConfig({ path: "riskcontolunitdashpage",componentName: RiskdashboardComponent, title: "Risk Control Unit / Home",  parentName: "Risk Control Unit", menuName: "Dashboard Summary" }));
RiskControlUnitRoute.push(new CustomRouteConfig({ path: "riskhome", title: "Risk Control Unit / Home", redirectTo: '/riskcontolunitdash', parentName: "Risk Control Unit", menuName: "riskcontolunitdash" }));
RiskControlUnitRoute.push(new CustomRouteConfig({ path: "riskcontolunitdash", componentName: PendingScreeningComponent, title: "Risk Control Unit", parentName: "Risk Control Unit", menuName: "Back" }));
RiskControlUnitRoute.push(new CustomRouteConfig({ path: "pendingscreen", componentName: PendingScreeningComponent, title: "Risk Control Unit / Pending for Screening", parentName: "Risk Control Unit", menuName: "Pending for Screening", }));
RiskControlUnitRoute.push(new CustomRouteConfig({ path: "sampledcases", componentName: SampledCasesComponent, title: "Risk Control Unit / Pending for Screening", parentName: "Risk Control Unit", menuName: "Sampled Cases", }));
RiskControlUnitRoute.push(new CustomRouteConfig({ path: "closedcases", componentName: ClosedCasesComponent, title: "Risk Control Unit / Pending for Screening", parentName: "Risk Control Unit", menuName: "Closed Cases", }));
RiskControlUnitRoute.push(new CustomRouteConfig({ path: "riskalertcases", componentName: RiskAlertCasesComponent, title: "Risk Control Unit / Pending for Screening", parentName: "Risk Control Unit", menuName: "Risk alert cases", }));
RiskControlUnitRoute.push(new CustomRouteConfig({ path: "reports", title: "Risk Control Unit / Pending for Screening", parentName: "Risk Control Unit", menuName: "Reports", redirectTo: "/riskcontolunitdash"}));
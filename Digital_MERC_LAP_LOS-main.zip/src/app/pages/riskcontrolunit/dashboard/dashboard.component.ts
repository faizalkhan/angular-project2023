import { Component, OnInit } from "@angular/core";
import { headerModel } from "src/app/shared/models/common/header-table";
import { ConfigService } from "src/app/shared/services/common/http.services";
import { DOCUMENT } from '@angular/common';
import { Observable } from 'rxjs';
import { requestmodel } from 'src/app/shared/models/sanction/request.model';
import { Inject } from '@angular/core';
import { SearchService } from "src/app/shared/services/search/search.service";
import { ISearch } from "src/app/shared/models/sanction/search/search";
import { RCUSummaryDahboardModel } from "../RCU.Model";
import { IresponseModel } from "src/app/shared/models/common/response.model";
import { NotificationService } from "src/app/notification.service";
import { MenuService } from "../../layout/header/menu-service.service";
import { MenuResponse } from "../../layout/login/login.service";
import { InfoServices } from "src/app/Injectable/info.services";
import { SanctionService } from "src/app/shared/services/sanction/sanction.service";
import { SanctionDashboardModel } from "src/app/shared/models/sanction/dashboard";

@Component({
    selector: "app-riskcontroldash",
    templateUrl: "./dashboard.component.html",
    styleUrls: ["./dashboard.component.css"],
    providers: [ConfigService]
})
export class RCUDashComponent implements OnInit {
    title: any = "Risk Control Unit Dashboard"
    // private _header: any[] = [];
    private _data: RCUSummaryDahboardModel = new RCUSummaryDahboardModel();

    public get Data(): RCUSummaryDahboardModel {
        return this._data;
    }
    public set Data(value: RCUSummaryDahboardModel) {
        this._data = value;
    }


    loggedInUserRoleId: string = '';
    roleId: string = '';

    // public get Header(): any[] {
    //     return this._header;
    // }
    // public set Header(value: any[]) {
    //     this._header = value;
    // }

    //dashboardData : IPendingDashboardModel[] =[];

    constructor(private http: ConfigService, private _searchService: SearchService,
        private notify: NotificationService, private menuService: MenuService, private info: InfoServices, private sanctionService: SanctionService) { }

    getDashboardSummary(param: any) {

        this.http.httpPost<IresponseModel<RCUSummaryDahboardModel[]>>(param, 'LAP_RCUDashboardSummary').subscribe((res: IresponseModel<RCUSummaryDahboardModel[]>) => {
            this.Data = new RCUSummaryDahboardModel();

            //if (res.errorcode == "00") {
            if (res.rcuDashboardSummaryResult.length >= 0) {
                this.notify.showSuccess(res.errorDescription, "Data retrived successfully");
                this.Data = new RCUSummaryDahboardModel(res.rcuDashboardSummaryResult[0]);
            }
        })
    }

    ngOnInit(): void {
        this.sanctionService.LanInfo = {} as SanctionDashboardModel;
        var loggedInUserRole = JSON.parse(this.info.getItem('menu')) as MenuResponse;
        this.loggedInUserRoleId = loggedInUserRole.menuUserDetail.roleId;

        let loggedInUserRoleDetails = loggedInUserRole.roleDetails.find(x => x.roleId == this.loggedInUserRoleId);
        if (loggedInUserRoleDetails !== null)
            this.roleId = loggedInUserRoleDetails?.roleName === undefined ? "" : loggedInUserRoleDetails.roleName;

        let parameter = {
            "userId": this.menuService.CurrentUserId,
            "role": this.roleId
        }
        //this._searchService.SearchData.subscribe((res: ISearch) => {

        this.getDashboardSummary(parameter);
        //}); 

    }

    row_click(event: any): void {
        alert(JSON.stringify(event));
    }
}


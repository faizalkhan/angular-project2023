import { DatePipe } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { headerModel } from 'src/app/shared/models/common/header-table';
import { ConfigService } from "src/app/shared/services/common/http.services";
import { requestmodel } from 'src/app/shared/models/sanction/request.model';
import { Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Observable, Subscription } from 'rxjs';
import { IPendingDashboardModel, PendingDahboardModel } from '../RCU.Model';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
import { NotificationService } from 'src/app/notification.service';
import { InfoServices } from 'src/app/Injectable/info.services';
import { Router } from '@angular/router';
import { MenuResponse } from '../../layout/login/login.service';
import { SearchService } from 'src/app/shared/services/search/search.service';
import { ISearch } from 'src/app/shared/models/sanction/search/search';
import { MenuService } from '../../layout/header/menu-service.service';

@Component({
  selector: 'app-sampledcases',
  templateUrl: './sampledcases.html',
  styleUrls: ['./sampledcases.css'],
  providers: [ConfigService]
})
export class SampledCasesComponent implements OnInit, OnDestroy {
  title: any = "Sampled Cases Dashboard"
  isDashboard: Boolean = true;
  private _header: any[] = [];
  private _data: any[] = [];

  public applicationDetilslist: any = [];
  public bankDetilslist: any;
  public propertyDetilslist: any = [];
  public propertyValuation: any = [];
  public physicalDiscussion: any = [];
  public accomodationAndComposition: any = [];
  public finanicalDetail: any = [];
  public salaries: any = [];
  public selfEmployedDetail: any = [];
  public ruleTrigerList: any = [];
  public businessDetail: any = [];
  public finalreviewDetails: any = [];

  loggedInUserRoleId: string = '';
  roleId: string = '';
  _userId: string = '';

  public get Data(): any[] {
    return this._data;
  }
  public set Data(value: any[]) {
    this._data = value;
  }

  public get Header(): any[] {
    return this._header;
  }
  public set Header(value: any[]) {
    this._header = value;
  }
  currentDateTime: any = new Date();

  private _selectedRow: PendingDahboardModel = new PendingDahboardModel();
  public get SelectedRow(): PendingDahboardModel {
    return this._selectedRow;
  }

  public set SelectedRow(value: PendingDahboardModel) {
    this._selectedRow = value;
  }
  constructor(@Inject(DOCUMENT) doc: Document, private http: ConfigService, private notify: NotificationService,
    private info: InfoServices, private route: Router, private _searchService: SearchService, private menuService: MenuService) { }
  ngOnDestroy(): void {
    this.subcriptions.unsubscribe();
  }

  getPendingActionlist(param: any) {
    // Create request
    this.http.httpPost<IresponseModel<PendingDahboardModel[]>>(param, 'LAP_RCUPendingAction').subscribe((res: IresponseModel<PendingDahboardModel[]>) => {
      this.Data = [];
      if (res.rcuPendingActionList != null && res.rcuPendingActionList.length >= 0) {
        let sampledData = res.rcuPendingActionList.filter(x => x.category === "Sampled");
        this.notify.showSuccess("Dashboard data retrived successfully", "Sampled Cases");
        this.Data = sampledData.map((x: IPendingDashboardModel) => {
          return new PendingDahboardModel(x);
        });
      }
      else {
        this.notify.showWarning("Something went wrong", "Sampled Cases");
      }
    })
  }

  getApplicationDetailslist(param: any) {
    // Create request
    this.http.httpPost<IresponseModel<PendingDahboardModel[]>>(param, 'LAP_RCUPendingAction').subscribe((res: IresponseModel<PendingDahboardModel[]>) => {
      this.Data = [];
      if (res.rcuPendingActionList != null && res.rcuPendingActionList.length >= 0) {
        this.notify.showSuccess("Dashboard data retrived successfully", "Pending for screening Dashboard");
        this.Data = res.rcuPendingActionList.map((x: IPendingDashboardModel) => {
          return new PendingDahboardModel(x);
        });
      }
      else {
        this.notify.showWarning("Something went wrong", "Pending for screening Dashboard");
      }
    })
  }

  getBankDetailslist(): Observable<any> {
    // Create request
    const request = new requestmodel();
    request.LoanAccountNumber = "L0822132456"

    return this.http.httpPost(request.RCUAppDetailstoJSON(), 'LAP_RCULANBank')
  }

  getPropertyDetailslist(): Observable<any> {
    // Create request
    const request = new requestmodel();
    request.UserID = "20105989";
    request.LoanAccountNumber = "L0822132456"

    return this.http.httpPost(request.RCUAppDetailstoJSON(), 'LAP_RCULANProperty')
  }

  getSanctionDetails(): Observable<any> {
    // Create request
    const request = new requestmodel();
    request.LoanAccountNumber = "L0822132456"

    return this.http.httpPost(request.RCUAppDetailstoJSON(), 'LAP_RCULANSanction')
  }


  getRuleTrigerlist(): Observable<any> {
    // Create request
    const request = new requestmodel();
    request.UserID = "20105989";
    request.LoanAccountNumber = "L0822132456"

    return this.http.httpPost(request.RCUAppDetailstoJSON(), 'LAP_RCULANRuleTriggers')
  }

  getFinalReviewDetails(): Observable<any> {
    // Create request
    const request = new requestmodel();
    request.LoanAccountNumber = "L0822132456"

    return this.http.httpPost(request.RCUAppDetailstoJSON(), 'LAP_RCULANFinalReview')
  }
  subcriptions: Subscription = new Subscription();



  ngOnInit(): void {
    this._header = [
      // new headerModel('lannumber', 'Lan no.'),
      // new headerModel('applicantname', 'Applicant name'),
      // new headerModel('coapplicant', 'Co-Applicants'),
      // new headerModel('state','State'),
      // new headerModel('mccode','MC Code'),
      // new headerModel('mcname', 'MC Name'),
      // new headerModel('mobilenumber', 'Mobile Number of Applicant'),
      // new headerModel('rcutriggereddate', 'RCU Triggered Date'),
      // new headerModel('ageing', 'Ageing'),
      // new headerModel('substage', 'Sub Stage'),
      // new headerModel('category', 'Category'),
      new headerModel('loanAccountNumber', 'Lan no.'),
      new headerModel('name', 'Name'),
      new headerModel('coApplicantName', 'Co-Applicants'),
      new headerModel('state', 'State'),
      new headerModel('executive_ID', 'MC Code'),
      new headerModel('executive_Name', 'MC Name'),
      new headerModel('mobileNo', 'Mobile Number of Applicant'),
      new headerModel('rcuTriggeredDate', 'RCU Triggered Date'),
      new headerModel('ageing', 'Ageing'),
      //new headerModel('triggertype', 'Trigger Type'),
      new headerModel('subStage', 'Sub Stage'),
      //new headerModel('category', 'Category'),
      new headerModel('caseStatus', 'Case Status')
    ];
    // this.Data = [
    //   { lannumber: 'ILAP345579867', applicantname: 'Deepak Sahu', coapplicant: "Harsal Bansal,Lokesh Talreja & Shruti Rajyadhax", state:'Maharashtra', mccode:'500449955', mcname: 'Shinish Bharadwaraj',mobilenumber:'9819463496', rcutriggereddate:'01-08-2022', ageing:'1', triggertype: 'Hunter',  substage: 'Pre-Sanction', category:'New' },
    //   { lannumber: 'ILAP345579868', applicantname: 'Prashant Gaikwad', coapplicant: "Gunjan Khanna,Sagar Rajyadhax", state:'Maharashtra', mccode:'500449955', mcname: 'Shinish Bharadwaraj',mobilenumber:'9819463496', rcutriggereddate:'01-08-2022', ageing:'1', triggertype: 'Internal Trigger',  substage: 'Post-Sanction', category:'Reassigned By RRM' },
    //   { lannumber: 'ILAP345579869', applicantname: 'Priya Pandey', coapplicant: "Harsal Bansal,Lokesh Talreja, Shruti Rajyadhax", state:'Maharashtra', mccode:'500449955', mcname: 'Shinish Bharadwaraj',mobilenumber:'9819463496', rcutriggereddate:'01-08-2022', ageing:'1', triggertype: 'Sample',  substage: 'Post-Sanction', category:'Response By Credit' },
    //   { lannumber: 'ILAP345579870', applicantname: 'Rahul Shinde', coapplicant: "Harsal Bansal,Lokesh Talreja , Shruti Rajyadhax", state:'Maharashtra', mccode:'500449955', mcname: 'Shinish Bharadwaraj',mobilenumber:'9819463496', rcutriggereddate:'31-08-2022', ageing:'2', triggertype: 'Hunter+Internal Trigger',  substage: 'Pre-Sanction', category:'Pending with Credit' },
    //   { lannumber: 'ILAP345579871', applicantname: 'Rahul Shinde', coapplicant: "Harsal Bansal,Lokesh Talreja, Shruti Rajyadhax", state:'Maharashtra', mccode:'500449955', mcname: 'Shinish Bharadwaraj',mobilenumber:'9819463496', rcutriggereddate:'31-08-2022', ageing:'2', triggertype: 'Hunter+Internal Trigger',  substage: 'Post-Sanction', category:'Pending with RRM' },
    // ];

    this.getLoggedInUserRole();

    if (this.roleId === "RRM-V") {
      this.roleId = "RRMV";
    }

    if (this.roleId === "RRM-I") {
      this.roleId = "RRMI";
    }

    const request = new requestmodel();
    request.FromDate = new Date().toString();
    request.ToDate = new Date().toString();
    request.UserID = this._userId;
    request.Role = this.roleId;
    request.ScreenType = "";
    request.FieldName = "FLO";
    request.FieldValue = "FLO"
    this.subcriptions = this._searchService.SearchData.subscribe((res: ISearch) => {
      if (res.role === "RRM-V") {
        res.role = "RRMV";
      }

      if (res.role === "RRM-I") {
        res.role = "RRMI";
      }

      request.FieldName = res.fieldName;
      request.FieldValue = res.fieldValue;
      request.FromDate = res.fromDate.toString();
      request.ToDate = res.toDate.toString();
      //this.RMCSearch.screenType="";
      request.Role = res.role;
      request.UserID = res.login_PS_ID;
      this.getPendingActionlist(request.RCUPendingActiontoJSON());

    });
    // this.getApplicationDetailslist()
    //   .subscribe(res => {
    //     this.applicationDetilslist = res.rcuApplicationResult ?? res.rcuApplicationResult;
    //   });

    // this.getBankDetailslist()
    //   .subscribe(res => {
    //     this.bankDetilslist = res.rcuLandBankResult ?? res.rcuLandBankResult;
    //   });

    // this.getPropertyDetailslist()
    //   .subscribe(res => {
    //     this.propertyDetilslist = res.rcuLANPropertyResult ?? res.rcuLANPropertyResult;
    //     this.propertyValuation = res.rcuPropertyValuation ?? res.rcuPropertyValuation;
    //   });

    // this.getSanctionDetails()
    //   .subscribe(res => {
    //     this.physicalDiscussion = res.haPhysicalDiscussion ?? res.haPhysicalDiscussion;
    //     this.accomodationAndComposition = res.haAccomodationAndComposition ?? res.haAccomodationAndComposition;
    //     this.finanicalDetail = res.finanicalDetail ?? res.finanicalDetail;
    //     this.salaries = res.iaSalaries ?? res.iaSalaries;
    //     //this.finanicalDetail = res.finanicalDetail ?? res.finanicalDetail;
    //     //this.salaries = res.iaSalaries ?? res.iaSalaries;
    //     this.selfEmployedDetail = res.selfEmployedDetail ?? res.selfEmployedDetail;
    //     this.businessDetail = res.businessDetail ?? res.businessDetail;
    //   });

    //   this.getRuleTrigerlist()
    //   .subscribe(res => {
    //     this.ruleTrigerList = res.rcuLoanResult ?? res.rcuLoanResult;
    //   });

    //   this.getFinalReviewDetails()
    //   .subscribe(res => {
    //     this.finalreviewDetails = res.rcuLANFinalReviewsResult ?? res.rcuLANFinalReviewsResult;
    //   });     

  }

  getLoggedInUserRole() {
    var loggedInUserRole = JSON.parse(this.info.getItem('menu')) as MenuResponse;
    this.loggedInUserRoleId = loggedInUserRole.menuUserDetail.roleId;
    this._userId = loggedInUserRole.menuUserDetail.userId;
    let loggedInUserRoleDetails = loggedInUserRole.roleDetails.find(x => x.roleId == this.loggedInUserRoleId);
    if (loggedInUserRoleDetails !== null)
      this.roleId = loggedInUserRoleDetails?.roleName === undefined ? "" : loggedInUserRoleDetails.roleName;

    if (this.roleId === "RRM-V") {
      this.roleId = "RRMV";
    }

    if (this.roleId === "RRM-I") {
      this.roleId = "RRMI";
    }
  }


  row_click(event: any): void {
    // this.isDashboard = false;
    // alert(JSON.stringify(event));

    this.isDashboard = false;
    this.SelectedRow = event;
    this.menuService.IsShow = false;
    this.info.setItem("CaseType", "Sampled case");
    this.info.setItem("PendingScreenInfo", JSON.stringify(this.SelectedRow));
    this.route.navigateByUrl("/pendingscreen");

  }

  Submit() {
    var request = {
      "loanAccountNumber": "L0822132456",
      "preSancRCU_Sample_Review": "Testing",
      "preSancRCU_TriggerType": "",
      "preSancRCU_ARM_Action": "",
      "preSancRCU_RejectReason": "",
      "preSancRCU_RejectSubReason": "",
      "preSancRCU_ARM_Remarks": "",
      "preSancTypeOfVerification": "",
      "preSancRCU_RRMV_Action": "",
      "preSancRCU_RRMV_Remarks": "",
      "preSancRCU_RRMI_Action": "",
      "preSancRCU_RRMI_Remarks": "",
      "postSancRCU_Status": "",
      "postSancRCU_Sample_Review": "",
      "postSancRCU_ARM_Action": "",
      "postSancRCU_RejectReason": "",
      "postSancRCU_RejectSubReason": "",
      "postSancRCU_ARM_Remarks": "",
      "postSancTypeOfVerification": "",
      "postSancRCU_RRMV_Action": "",
      "postSancRCU_RRMV_Remarks": "",
      "postSancRCU_RRMI_Action": "",
      "postSancRCU_RRMI_Remarks": "",
      "tokenNumber": "",
      "preSancRCU_Status": "",
      "preSancRCU_ARM_TriggeredDate": "2022-10-05T05:22:42.265Z",
      "preSancRCU_RRMV_TriggeredDate": "2022-10-05T05:22:42.265Z",
      "preSancRCU_RRMI_TriggeredDate": "2022-10-05T05:22:42.265Z",
      "postSancRCU_TriggerType": "",
      "postSancRCU_ARM_TriggeredDate": "2022-10-05T05:22:42.265Z",
      "postSancRCU_RRMV_TriggeredDate": "2022-10-05T05:22:42.265Z",
      "postSancRCU_RRMI_TriggeredDate": "2022-10-05T05:22:42.265Z",
      "createdBy": "",
      "createdOn": "2022-10-05T05:22:42.265Z",
      "modifiedBy": "",
      "modifiedOn": "2022-10-05T05:22:42.265Z",
      "rcuDiscrepantResult": ""
    };

    this.http.httpPost(request, 'LAP_SubmitRCULANFinalReview')
      .subscribe(res => {
      });
  }


  selectedStatus: String = "--Choose Status--";
  MainStatusList: Array<any> = [
    { status: 'KYC 1 & 2 of both applicant / co applicant', substatus: ['Fake/Tampered KYC ', 'Random Image / Unclear Image uploaded (either 1st or 2nd page)', 'Applicant is Outside Age Limit', 'Complete Name Mismatch', 'Complete Mismatch with Picture on KYC applicants live picture', 'Number Mismatch', 'Invalid (Online checks)', 'Gender Mismatch (basis online check)', 'Sourcing using Photocopy', 'DOB Mismatch - Age as per policy', 'Others'] },
    { status: 'Bank', substatus: ['Complete mismatch in name from borrower name', 'Random / Unclear Image uploaded', 'Manually updated / Printed Bank A/C No. Reverse feedback - Beneficiary Name mismatch', 'Co-borrower Passbook (not Joint A/C)', 'Number Mismatch - Any digit mismatch ', 'Joint A/C with a non co-applicant individual', 'Fake/Tampering (Ground Checks . Info)', 'IFSC wrong/ not mentioned', 'Others'] },
    { status: 'Mobile Number relate', substatus: ['Third party mobile number updated', 'Customer number not in service / invalid', 'Others'] },
    { status: 'Policy related', substatus: ['Relation of borrower and co-borrower not matched as per application / not established', 'Blood / close relatives in one group', 'Co-borrower Stays in abroad', 'Co-borrower currently not in the state (working outside/abroad)', 'Migrant Customer', 'Others'] },
    { status: 'Process Violation', substatus: ['Customer live photo not captured', 'Borrowers dont know each other', 'Customer not interested to take loan', 'CIBIL below the benchmark approval not taken', 'Loan applicant / co applicant engaged in negative business', 'Properties not as per the policy have been sourced', 'Charge already created with different institution or charge not created', 'Others'] },
    { status: 'Valuation', substatus: ['Valuation report tampered', 'Address mismatch with the valuation done', 'Valuation and legal report details mismtach', 'Second valuation not done for the cases before the sanction'] },
    { status: 'Legal', substatus: ['Title deed not in the name of the applicant', 'Litigation on the property', 'Negative area', 'Litigation on the applicant / co applicant', 'Mismatch in the property owner', 'Legal report not available at the time of sanction', 'Legal report address mismtch with the property details', 'Others'] }
  ];
  substatus: Array<any> = [];
  ChangeSubStatus(count: any) {
    this.substatus = this.MainStatusList.find((con: any) => con.status == count.target.value).substatus;
  }

  btnBack() {
    this.route.navigateByUrl("/riskcontolunitdash");
  }
}
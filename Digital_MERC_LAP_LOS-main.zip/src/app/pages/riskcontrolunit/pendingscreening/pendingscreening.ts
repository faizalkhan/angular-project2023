import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { headerModel } from 'src/app/shared/models/common/header-table';
import { ConfigService } from "src/app/shared/services/common/http.services";
import { requestmodel } from 'src/app/shared/models/sanction/request.model';
import { BusinessModel, FinancialModel, HAAccomodationAndCompositionModel, HAPhysicalDiscussionModel, IASalariesModel, IFinancialModel, IHAPhysicalDiscussionModel, IInterActionDetail, InterActionDetail, IPendingApplicationModel, IPendingDashboardModel, IPropertyModel, IRCUBankingModel, IRCULANDoc, IRuleTriggerModel, 
  ISelfEmployeeModel, 
  PendingApplicationModel, PendingDahboardModel, 
  PropertyModel, 
  RCUBankingModel, 
  RCUBSanctionModel, 
  RCUFinalReviewModel, 
  RCULANDocCheckModel, RCUSanctionDiscrepant, RCUSanctionSubmit, RuleTriggerModel, SelfEmployeeModel } from '../RCU.Model';
import { IresponseModel, responseModel } from 'src/app/shared/models/common/response.model';
import { NotificationService } from 'src/app/notification.service';
import { SearchService } from 'src/app/shared/services/search/search.service';
import { ISearch } from 'src/app/shared/models/sanction/search/search';
import { IModalCommon, ModalCommon, ModalService } from 'src/app/shared/services/modal/modal.service';
import { IDownloadDocument } from 'src/app/shared/models/sanction/Legal/legalDashboard';
import { RemarkReasonService } from '../RCU.service';
import { MainReason } from '../MainReason';
import { SubReason } from '../subreason';
import { Router } from '@angular/router';
import { InfoServices } from 'src/app/Injectable/info.services';
import { SanctionDashboardModel } from 'src/app/shared/models/sanction/dashboard';
import { ThisReceiver } from '@angular/compiler';
import { lowSurrogate, numberToString } from 'pdf-lib';
import { MenuResponse } from '../../layout/login/login.service';
import { FileUpload, IfileUpload, UploadViewDownloadService } from '../../layout/button/upload-view-download/upload-view-download.service';
import { MenuService } from '../../layout/header/menu-service.service';
 

@Component({
  selector: 'app-pendingscreen',
  templateUrl: './pendingscreening.html',
  styleUrls: ['./pendingscreening.css'],
  providers: [ConfigService]
})
export class PendingScreeningComponent implements OnInit {
  title: any = "Pending for Screening"
 // isDashboard: boolean = true;
  isARMPreSanctionScreen : boolean=false;
  isARMPostSanctionScreen : boolean=false;
  isRRMPreSanctionScreen : boolean=false;
  isRRMPostSanctionScreen : boolean=false;
  isRRMIPostSanctionScreen:boolean=false;
  isRRMIPretSanctionScreen:boolean=false;
  isDiscrepantEdit:boolean=false;
  preARMEnableReason:boolean=false;
  postARMEnableReason:boolean=false;
  //showDiscrpantReason:boolean=true;
  

  isEdit:boolean=true;
  enablePreSanctionTypeOfVerification:boolean=true;
  enablePostSanctionTypeOfVerification:boolean=true;
  showDownload:boolean=false;
  preARMReviewisEdit:boolean=false;
  showFinalSubmitButton:boolean=false;
  postARMReviewisEdit:boolean=false;
  preRRMReviewisEdit:boolean=false;
  postRRMReviewisEdit:boolean=false;
  postRRMIReviewEdit:boolean=false;
  preRRMIReviewEdit:boolean=false;
  riskAlertCases:boolean=true;
  queriesARMSection:boolean=true;

  preARMReviedSampled:boolean=false;
  postARMReviedSampled:boolean=false;
  fileUpload:IfileUpload=new FileUpload();

  selectedLoanAccountNumber : string ="";
  UserId:string="";
  private _header: any[] = [];
  private _data: PendingDahboardModel[] = [];
  private _applicationData: PendingApplicationModel = new PendingApplicationModel();
  private _coApplicationData: PendingApplicationModel[] = [];
  private _ruelTriggerData : RuleTriggerModel[]=[];
  private _rcuLANDocCheck : RCULANDocCheckModel[]=[];
  private __rcuPreSanctionLANDocCheck: RCULANDocCheckModel[]=[];
  private _rcuPostSanctionLANDocCheck: RCULANDocCheckModel[]=[];
  private _rcuBankLANDocCheck: RCULANDocCheckModel[]=[];
  //private _preSanctionARMFinalReview:PreSanctionFinalReview =new PreSanctionFinalReview();
  private _rcuSanctionSubmit: RCUSanctionSubmit= new RCUSanctionSubmit();
  private _rcuSanctionDiscrepantSubmit: RCUSanctionDiscrepant[]=[];
  private _rcuBankingData : RCUBankingModel= new RCUBankingModel();
  private _haPhysicalDiscussion: HAPhysicalDiscussionModel[]= [];
  private _haAccomodationAndComposition: HAAccomodationAndCompositionModel=new HAAccomodationAndCompositionModel();
  private _financialModel: FinancialModel[]=[];
  private _iaSalaries: IASalariesModel= new IASalariesModel();
  private _selfEmployeeModel: SelfEmployeeModel[]=[];
  private _businessModel: BusinessModel[]=[]; 
  private _haHW:HAPhysicalDiscussionModel= new HAPhysicalDiscussionModel();
  private _haIA:HAPhysicalDiscussionModel= new HAPhysicalDiscussionModel();
  private _propertyModel:PropertyModel = new PropertyModel();
  private _rcuFinalReviewModel: RCUFinalReviewModel = new RCUFinalReviewModel();
  private _rcuQueriesModel: InterActionDetail[] = [];
   
  public applicationDetilslist: any = [];
  public bankDetilslist: any;
  public propertyDetilslist: any = [];
  public propertyValuation: any = [];
  public physicalDiscussion: any = [];
  public accomodationAndComposition: any = [];
  public finanicalDetail: any = [];
  public salaries: any = [];
  public selfEmployedDetail: any = [];
  public ruleTrigerList: any = [];
  public businessDetail: any = [];
  public finalreviewDetails: any = [];

  public get Data(): PendingDahboardModel[] {
    return this._data;
  }
  public set Data(value: PendingDahboardModel[]) {
    this._data = value;
  }

  public get applicationData() : PendingApplicationModel{
    return this._applicationData;
  }

  public set applicationData(value: PendingApplicationModel) {
    this._applicationData = value;
  }

  public get coApplicationData() : PendingApplicationModel[]{
    return this._coApplicationData;
  }

  public set coApplicationData(value: PendingApplicationModel[]) {
    this._coApplicationData = value;
  }

  public get ruelTriggerData() : RuleTriggerModel[]{
    return this._ruelTriggerData;
  }

  public set ruelTriggerData(value: RuleTriggerModel[]) {
    this._ruelTriggerData = value;
  }

  public get rcuLANDocCheckData() : RCULANDocCheckModel[]{
    return this._rcuLANDocCheck;
  }

  public set rcuLANDocCheckData(value: RCULANDocCheckModel[]) {
    this._rcuLANDocCheck = value;
  }

  public get rcuPreSanctionLANDocCheck() : RCULANDocCheckModel[]{
    return this.__rcuPreSanctionLANDocCheck;
  }

  public set rcuPreSanctionLANDocCheck(value: RCULANDocCheckModel[]) {
    this.__rcuPreSanctionLANDocCheck = value;
  }

  public get rcuBankLANDocCheck() : RCULANDocCheckModel[]{
    return this._rcuBankLANDocCheck;
  }

  public set rcuBankLANDocCheck(value: RCULANDocCheckModel[]) {
    this._rcuBankLANDocCheck = value;
  } 

  public get rcuPostSanctionLANDocCheck() : RCULANDocCheckModel[]{
    return this._rcuPostSanctionLANDocCheck;
  }

  public set rcuPostSanctionLANDocCheck(value: RCULANDocCheckModel[]) {
    this._rcuPostSanctionLANDocCheck = value;
  } 

  private _rcuPostSanctionLANDocCheckResp : RCULANDocCheckModel[] =[];

  public get rcuPostSanctionLANDocCheckResp() : RCULANDocCheckModel[]{
    return this._rcuPostSanctionLANDocCheckResp;
  }

  public set rcuPostSanctionLANDocCheckResp(value: RCULANDocCheckModel[]) {
    this._rcuPostSanctionLANDocCheckResp = value;
  } 

  

  // public get preSanctionARMFinalReview() : PreSanctionFinalReview{
  //   return this._preSanctionARMFinalReview;
  // }

  // public set preSanctionARMFinalReview(value: PreSanctionFinalReview) {
  //   this._preSanctionARMFinalReview = value;
  // }

  //preSanctionARM submit variable
  public get rcuSanctionSubmit() : RCUSanctionSubmit{
    return this._rcuSanctionSubmit;
  }

  public set rcuSanctionSubmit(value: RCUSanctionSubmit) {
    this._rcuSanctionSubmit = value;
  }

  public get rcuSanctionDiscrepantSubmit() : RCUSanctionDiscrepant[]{
    return this._rcuSanctionDiscrepantSubmit;
  }

  public set rcuSanctionDiscrepantSubmit(value: RCUSanctionDiscrepant[]) {
    this._rcuSanctionDiscrepantSubmit = value;
  }
  
  public get rcuBankingData() : RCUBankingModel{
    return this._rcuBankingData;
  }

  public set rcuBankingData(value: RCUBankingModel) {
    this._rcuBankingData = value;
  }

  public get haPhysicalDiscussion(): HAPhysicalDiscussionModel[]{
    return this._haPhysicalDiscussion;
  }

  public set haPhysicalDiscussion(value: HAPhysicalDiscussionModel[]) {
    this._haPhysicalDiscussion = value;
  } 

  public get haAccomodationAndComposition() : HAAccomodationAndCompositionModel{
    return this._haAccomodationAndComposition;
  }

  public set haAccomodationAndComposition(value: HAAccomodationAndCompositionModel) {
    this._haAccomodationAndComposition = value;
  } 
  public get financialModel() : FinancialModel[]{
    return this._financialModel;
  }

  public set financialModel(value: FinancialModel[]) {
    this._financialModel = value;
  } 

  public get iaSalaries() : IASalariesModel{
    return this._iaSalaries;
  }

  public set iaSalaries(value: IASalariesModel) {
    this._iaSalaries = value;
  } 

  public get selfEmployeeModel() : SelfEmployeeModel[]{
    return this._selfEmployeeModel;
  }

  public set selfEmployeeModel(value: SelfEmployeeModel[]) {
    this._selfEmployeeModel = value;
  } 

  
  public get businessModel() : BusinessModel[]{
    return this._businessModel;
  }

  public set businessModel(value: BusinessModel[]) {
    this._businessModel = value;
  }  

  public get Header(): any[] {
    return this._header;
  }
  public set Header(value: any[]) {
    this._header = value;
  }

  public get haHW(): HAPhysicalDiscussionModel{
    return this._haHW;
  }

  public set haHW(value: HAPhysicalDiscussionModel) {
    this._haHW = value;
  } 

  public get haIA(): HAPhysicalDiscussionModel{
    return this._haIA;
  }

  public set haIA(value: HAPhysicalDiscussionModel) {
    this._haIA = value;
  } 

  public get propertyModel(): PropertyModel{
    return this._propertyModel;
  }

  public set propertyModel(value: PropertyModel) {
    this._propertyModel =value ;
  } 

  public get rcuFinalReviewModel(): RCUFinalReviewModel{
    return this._rcuFinalReviewModel;
  }

  public set rcuFinalReviewModel(value: RCUFinalReviewModel) {
    this._rcuFinalReviewModel =value ;
  } 


  public get rcuQueriesModel(): InterActionDetail[]{
    return this._rcuQueriesModel;
  }

  public set rcuQueriesModel(value: InterActionDetail[]) {
    this._rcuQueriesModel =value ;
  } 

  private _selectedRow:PendingDahboardModel= new PendingDahboardModel();
  public get SelectedRow():PendingDahboardModel{
     return this._selectedRow;
  }

  public set SelectedRow(value:PendingDahboardModel){
    this._selectedRow=value;
  }

  CaseType:string='';
  roleId:string='';
  loggedInUserRoleId:string='';
  
  MainStatusLists:MainReason[]=[];
  SubReasonList:SubReason[]=[];


  UniqueDocType:string[]=[];
  uniqueBankDocType:string[]=[];

  TrigerType = ["Hunter", "Sample", "Hunter+Internal Trigger"]
  SubStage = ["PreSanction", "PostSanction"]
  Category = ["New", "Re-assigned By RRM", "Response By Credit", "Pending With Credit", "Pending With RRM"]
  FinancialStatus = ["Financier", "Non Financier"]
  TypeofApplicant = ["Primary Applicant", "Co-Applicant"]
  SalaryStatus = ["Salaried", "Self Employed"]
  KYCStatus = ["Verified", "Non Verified"]

  currentDateTime: any = new Date();
  constructor(private http: ConfigService,private notify: NotificationService,
     private _searchService: SearchService,private reason: RemarkReasonService,
     private modal: ModalService,private route: Router,private info: InfoServices, 
     private download: UploadViewDownloadService,private menuService:MenuService ) { }
 
  getPendingActionlist(param:any) {
     
     this.http.httpPost<IresponseModel<PendingDahboardModel[]>>(param, 'LAP_RCUPendingAction').subscribe((res: IresponseModel<PendingDahboardModel[]>) => {
      this.Data = []; 
      if(res.rcuPendingActionList!=null && res.rcuPendingActionList.length>=0){
        let pendingList;
        if(this.roleId==="RRMI") 
            pendingList = res.rcuPendingActionList.filter(x=>x.category!=="Sampled"  && x.category!=="Completed");
        else
           pendingList = res.rcuPendingActionList.filter(x=>x.category!=="Sampled" && x.category!=="RiskAlert" && x.category!=="Completed");
 
          this.Data = pendingList.map((x: IPendingDashboardModel) => {
              return new PendingDahboardModel(x);
          });  
        }
        else{
          this.notify.showWarning("Something went wrong", "Pending for screening");
        }
       })  
   }  

  getApplicationDetailslist(param:any) { 
    this.http.httpPost<IresponseModel<PendingApplicationModel[]>>(param, 'LAP_RCUApplications').subscribe((res: IresponseModel<PendingApplicationModel[]>) => {       
          if( res.rcuApplicationResult!==null && res.rcuApplicationResult.length>=0){
            //&& x.applicantType.substring(0,1)==="C"
            let coApplicationDataList= res.rcuApplicationResult.filter((x: IPendingApplicationModel) =>x.applicantType!== null);
            //sorting the array based on applicant type

            if(coApplicationDataList){ 
            this.coApplicationData = coApplicationDataList.sort((a,b) => a.applicantType.localeCompare(b.applicantType));
            }
           
            //this.notify.showSuccess("Application & Applicant data retrived successfully", "Application");
            this.applicationData = new PendingApplicationModel(res.rcuApplicationResult.filter(x=>x.applicantType!== null && x.applicantType==="A")[0]);
          } else{
            this.notify.showWarning("Something went wrong", "Application");
          }
     })  
  }

  getRuleTrigerlist(param:any){ 
    this.http.httpPost<IresponseModel<RuleTriggerModel[]>>(param, 'LAP_RCULANRuleTriggers').subscribe((res: IresponseModel<RuleTriggerModel[]>) => {       
      if( res.rcuLoanResult!==null && res.rcuLoanResult.length>=0){
         
        //this.notify.showSuccess("Application & Applicant data retrived successfully", "Application");
        this.ruelTriggerData = res.rcuLoanResult.map((x: IRuleTriggerModel) => {
          return new RuleTriggerModel(x);
      });  
      } else{
        this.notify.showWarning("Something went wrong", "Application");
      }
    })  
    //return this.http.httpPost(request.RCUAppDetailstoJSON(), 'LAP_RCULANRuleTriggers')
  }

  getRCULANDoclist(param:any){ 
    
    var isFound:boolean=false; 
    this.http.httpPost<IresponseModel<RCULANDocCheckModel[]>>(param, 'LAP_RCULanDocCheck').subscribe((res: IresponseModel<RCULANDocCheckModel[]>) => {       
      if( res.rcuLandDocCheckResult!==null && res.rcuLandDocCheckResult.length>=0){
       
        //this.notify.showSuccess("Documents retrived successfully", "Application");  
     
        if(this.isARMPostSanctionScreen){
            this.rcuPostSanctionLANDocCheckResp =  res.rcuLandDocCheckResult 
             .filter(x=>x.module===null || (x.module.toUpperCase()!=="SOURCING" 
             && x.module.toUpperCase()!=="UPDATE PAN NUMBER"&& x.module.toUpperCase()!=="SUBMITPERSONALDEATILS" 
             && x.module.toUpperCase()!=="SUBMITPERSONALDETAILS" && x.module.toUpperCase()!=="BUREAU"
             && x.module.toUpperCase()!=="SUBMITBUSINESSDETAILS MAIN" 
             && x.module.toUpperCase()!=="SUBMITBUSINESSDEATILS MAIN"
             && x.module.toUpperCase()!=="SUBMITBUSINESSDETAILS"
             && x.module.toUpperCase()==="SUBMITBUSINESSDEATILS"));
            
            this.rcuPostSanctionLANDocCheck =  this.rcuPostSanctionLANDocCheckResp.sort((a,b) => a.applicationNo.localeCompare(b.applicationNo));
         
            this.rcuPostSanctionLANDocCheck = this.rcuPostSanctionLANDocCheck.map((x: IRCULANDoc) => {

              isFound=false;
              this.UniqueDocType.map((item,index)=>{ 
                 if(item === x.applicantType || (x.applicantType===null && item==="Other documents")){
                   isFound=true;
                   return;
                 }
             });
              if(!isFound){ 
                if(x.applicantType===null){
                  this.UniqueDocType.push("Other documents");
                }else{
                this.UniqueDocType.push(x.applicantType);
                }
              } 

              this.UniqueDocType =  this.UniqueDocType.sort();

              return new RCULANDocCheckModel(x);
             });
        }  

        if(this.isARMPreSanctionScreen){
          this.rcuPreSanctionLANDocCheck = res.rcuLandDocCheckResult.filter(x=>x.module!==null && (x.module.toUpperCase()==="SOURCING" 
          || x.module.toUpperCase()==="UPDATE PAN NUMBER"|| x.module.toUpperCase()==="SUBMITPERSONALDEATILS" 
          || x.module.toUpperCase()==="SUBMITPERSONALDETAILS" || x.module.toUpperCase()==="BUREAU" 
          || x.module.toUpperCase()==="SUBMITBUSINESSDETAILS MAIN" 
          || x.module.toUpperCase()=== "SUBMITBUSINESSDEATILS MAIN"
          || x.module.toUpperCase()==="SUBMITBUSINESSDETAILS"
          || x.module.toUpperCase()==="SUBMITBUSINESSDEATILS" )); 

          this.rcuPreSanctionLANDocCheck = this.rcuPreSanctionLANDocCheck.map((x: IRCULANDoc) => {         
          
            if(x.rcuMakerDiscrepantReason!=="" && x.rcuMakerDiscrepantReason!==null){ 
              var findSubStatusId = this.reason.getMainReason().filter((item)=>item.status===x.rcuMakerDiscrepantReason);
              if(findSubStatusId!==null && findSubStatusId.length>=0){
                x.subReasonList = this.reason.getSubReason().filter((item) => item.Id == findSubStatusId[0].Id || item.Id == 0);
              }
            }
            
            isFound=false;
            this.UniqueDocType.map((item,index)=>{ 
              if(item === x.applicantType 
                || (x.applicantType===null && item==="Other documents")){
                isFound=true;
                //return;
              }
            });
            if(!isFound){ 
              if(x.applicantType===null){
                this.UniqueDocType.push("Other documents");
              }else{
              this.UniqueDocType.push(x.applicantType);
              }
            } 
            this.UniqueDocType =  this.UniqueDocType.sort();

            return new RCULANDocCheckModel(x);
          }); 
        }

        this.rcuBankLANDocCheck = res.rcuLandDocCheckResult.filter(x=>x.module!==null && x.module.toUpperCase()==="BANKING");
        this.rcuBankLANDocCheck = this.rcuBankLANDocCheck.map((x: IRCULANDoc) => { 
        this.uniqueBankDocType.map((item,index)=>{
          if(item === x.applicantType){
            isFound=true;
            return;
          }
          });
          if(!isFound){
            this.uniqueBankDocType.push(x.applicantType);
          }
          return new RCULANDocCheckModel(x);
        }); 
        

      }else{
        this.notify.showWarning("Something went wrong", "Application");
      }
    })  
  }

  getBankDetailslist(param:any) {
    this.http.httpPost<IresponseModel<RCUBankingModel[]>>(param, 'LAP_RCULANBank').subscribe((res: IresponseModel<RCUBankingModel[]>) => {       
        if( res.rcuLandBankResult!==null && res.rcuLandBankResult.length>=0){ 
          //this.notify.showSuccess("Banking details retrived successfully", "Banking"); 
          this.rcuBankingData =new RCUBankingModel(res.rcuLandBankResult[0] as (IRCUBankingModel));
        }
        else{
          this.notify.showSuccess("Something went wrong", "Banking");
        } 
      });
    }

    getSanctionDetails(param:any) {
      
      this.http.httpPost<IresponseModel<RCUBSanctionModel>>(param, 'LAP_RCULANSanction').subscribe((res: IresponseModel<RCUBSanctionModel>) => {       
        
        if( res!==null && res.rcuSanction!==undefined && res.rcuSanction!==null){ 

            this.haAccomodationAndComposition = new HAAccomodationAndCompositionModel(res.rcuSanction.haAccomodationAndComposition[0]); 
            this.haPhysicalDiscussion = res.rcuSanction.haPhysicalDiscussion.map((x: IHAPhysicalDiscussionModel) => {
              return new HAPhysicalDiscussionModel(x);
            });   
            
            this.haHW = new HAPhysicalDiscussionModel(this.haPhysicalDiscussion.filter(x=>x.physicalDiscussionType==='Household Assessment')[0]);

            this.haIA = new HAPhysicalDiscussionModel(this.haPhysicalDiscussion.filter(x=>x.physicalDiscussionType==='Income Assessment')[0]);
            
            this.iaSalaries = new IASalariesModel(res.rcuSanction.iaSalaries[0]); 

            this.financialModel = res.rcuSanction.finanicalDetail.map((x: IFinancialModel) => {
              return new FinancialModel(x);
            }); 

            this.selfEmployeeModel = res.rcuSanction.selfEmployedDetail.map((x:ISelfEmployeeModel)=>{
               return new SelfEmployeeModel(x);
            })  
            this.selfEmployeeModel = res.rcuSanction.selfEmployedDetail;

           // this.notify.showSuccess("Sanction details retrived successfully", "Banking");  
          }
          else{
            this.notify.showWarning("Something went wrong", "Banking");
          } 
        }); 
      }

  getPropertyDetailslist(param:any) {
    this.http.httpPost<IresponseModel<PropertyModel[]>>(param, 'LAP_RCULANProperty').subscribe((res: IresponseModel<PropertyModel[]>) => {       
          
        if( res.rcuPropertyValuation!==null && res.rcuPropertyValuation.length>=0){
            
          //this.notify.showSuccess("Property data retrived successfully", "Application");
          this.propertyModel = new PropertyModel(res.rcuPropertyValuation[0] as (IPropertyModel));         
        } else{
          this.notify.showWarning("Something went wrong", "Application");
        }
      });
    }

    getQueries(param:any) {
    this.http.httpPost<IresponseModel<InterActionDetail[]>>(param, 'GetOpsCreditInteractionDtl').subscribe((res: IresponseModel<InterActionDetail[]>) => { 
        if( res!==null){ 
          //this.notify.showSuccess("Queries retrived successfully", "Application"); 
          
          this.rcuQueriesModel = res.creditInteractionDtl.map((x: IInterActionDetail) => {
            return new InterActionDetail(x);
        });  
         
        } else{
          //this.notify.showSuccess("Something went wrong", "Application");
        }
      });
    }

    getFinalReviewDetails(param:any){
      this.http.httpPost<RCUFinalReviewModel>(param, 'LAP_RCULANFinalReview').subscribe((res: RCUFinalReviewModel) => {       
          
        if( res!==null){
            
          this.notify.showSuccess("Data retrived successfully", "Application");
        
          if(this.rcuFinalReviewModel.preSancRCU_RejectReason!==""){
              var findSubStatusId = this.reason.getMainReason().filter((item)=>item.status===this.rcuFinalReviewModel.preSancRCU_RejectReason);
              if(findSubStatusId!==null && findSubStatusId.length>=0){
              this.SubReasonList = this.reason.getSubReason().filter((item) => item.Id == findSubStatusId[0].Id || item.Id == 0);
              }
          }
          
          
          this.rcuFinalReviewModel = new RCUFinalReviewModel(res);
          if(this.roleId==="RRMI" && this.SelectedRow.subStage==="Presanction" && 
              (this.rcuFinalReviewModel.tokenNumber==="" || this.rcuFinalReviewModel.tokenNumber!==null)){           
            this.rcuFinalReviewModel.tokenNumber = this.reason.GenerateToken(20);
          }

          
          if(this.roleId==="RRMI" && this.SelectedRow.subStage==="Postsanction" && 
              (this.rcuFinalReviewModel.postTokenNumber==="" || this.rcuFinalReviewModel.postTokenNumber===null)){
            
            this.rcuFinalReviewModel.postTokenNumber = this.reason.GenerateToken(20);
          }

          if(this.rcuFinalReviewModel.preSancRCU_Sample_Review==="Sampled"){ 
            this.preARMReviewisEdit=false;   
            this.preARMEnableReason=false;
          }  

          if(this.rcuFinalReviewModel.postSancRCU_Sample_Review==="Sampled"){ 
            this.postARMReviewisEdit=false;   
            this.postARMEnableReason=false;
          }  
        } else{
          //this.notify.showWarning("Something went wrong", "Application");
        }
      });
    }
      
  ngOnInit(): void {

    this.menuService.IsShow=false;

    this.getLoggedInUserRole();

    const request = new requestmodel();
    request.FromDate = new Date().toString();
    request.ToDate = new Date().toString();
    request.UserID = this.UserId; 
    request.Role = this.roleId;
    request.ScreenType = "";
    request.FieldName = "FLO";
    request.FieldValue = "FLO" 
    if(this.info.IsItem("CaseType")){
       this.CaseType = this.info.getItem("CaseType");
    }
     
    if(this.info.getItem('PendingScreenInfo')!='' && this.SelectedRow.loanAccountNumber==="")
      this.SelectedRow = JSON.parse(this.info.getItem('PendingScreenInfo')) as PendingDahboardModel;
     
    this.loadPageData();
    //this.info.removeItem("PendingScreenInfo"); 
  }

  row_click(event: any): void {     
     this.SelectedRow = event;
     this.menuService.IsShow =false;
     this.loadPageData(); 
  }

  loadPageData(){ 
   
    if(this.SelectedRow.loanAccountNumber===""){
      return;
    }

    this.selectedLoanAccountNumber = this.SelectedRow.loanAccountNumber;
    //this.isDashboard = false;


    
    let setParameter:SanctionDashboardModel = new SanctionDashboardModel();
    
    setParameter.lan = this.selectedLoanAccountNumber;
    setParameter.flopsid= this.UserId;
    setParameter.readOnly=true;

    this.info.setItem("LanInfo", JSON.stringify(setParameter));

    var param ={
      "LoanAccountNumber" : this.selectedLoanAccountNumber,
      "UserID" : this.UserId
    } 
 
    this.showScreenType(); 
    
    this.getApplicationDetailslist(param);
    this.getRuleTrigerlist(param);
    
    var param1 ={
      "LoanAccountNumber" : this.selectedLoanAccountNumber
    }

    this.MainStatusLists = this.reason.getMainReason();
    this.SubReasonList = this.reason.getSubReason();
   
    this.getRCULANDoclist(param1);
    
    if(this.isARMPostSanctionScreen){
      this.getBankDetailslist(param1); 
      this.getSanctionDetails(param1);
      this.getPropertyDetailslist(param);
    }
    
    this.getFinalReviewDetails(param1);

    var queriesParam ={
      "LoanAccountNumber" : this.selectedLoanAccountNumber,
      "Source":"RCU"
    }

    this.queriesARMSection=false;
    if(this.roleId==="ARM" && this.SelectedRow.subStage==="Postsanction"){
      this.queriesARMSection=true;
      this.getQueries(queriesParam);
    }
    
  }

  disableFinalReviewControl(){
    this.preARMReviewisEdit=false;   
    this.preRRMReviewisEdit=false;
    this.postARMReviewisEdit=false;
    this.postRRMReviewisEdit=false; 
    this.preARMReviedSampled=false;
    this.postARMReviedSampled=false;
    this.showFinalSubmitButton=false;
    this.postRRMIReviewEdit=false;
    this.preRRMIReviewEdit=false;
    this.postARMEnableReason=false;
    this.preARMEnableReason=false; 
     this.isDiscrepantEdit=false;
     this.enablePreSanctionTypeOfVerification=false;
     this.enablePostSanctionTypeOfVerification=false;
  }

  getLoggedInUserRole(){

    var loggedInUserRole = JSON.parse(this.info.getItem('menu')) as MenuResponse;
    this.loggedInUserRoleId = loggedInUserRole.menuUserDetail.roleId; 
    this.UserId=loggedInUserRole.menuUserDetail.userId;
    let loggedInUserRoleDetails =  loggedInUserRole.roleDetails.find(x=>x.roleId==this.loggedInUserRoleId);
    if(loggedInUserRoleDetails!==null)
        this.roleId = loggedInUserRoleDetails?.roleName === undefined ? "" :  loggedInUserRoleDetails.roleName;   

    if(this.roleId==="RRM-V"){
      this.roleId="RRMV";
    }

    if(this.roleId==="RRM-I"){
      this.roleId="RRMI";
    }
  }

  showScreenType(){
    
   debugger;
    this.postRRMIReviewEdit=false;
    this.isRRMIPostSanctionScreen=false;
    this.isRRMIPretSanctionScreen=false;
    this.preRRMIReviewEdit=false;
    this.isDiscrepantEdit=false;
    this.riskAlertCases=false;

    this.download.uploadLoad = new FileUpload({
      flO_Id: "",
      loanAccountNumber: this.SelectedRow.loanAccountNumber,
      moduleName: "RCU - " + this.roleId + " - " + this.SelectedRow.subStage,
      applicationNo : this.SelectedRow.applicationNo,
      leadID:this.SelectedRow.applicationNo
  } as IfileUpload);
 
    if(this.roleId==="ARM"){ 
      if(this.SelectedRow.subStage==="Presanction"){

        this.isDiscrepantEdit=true;
        this.preARMReviewisEdit=true;
        this.preARMEnableReason=true;
        this.showFinalSubmitButton=true;
        this.preARMReviedSampled=true;
        this.isRRMPreSanctionScreen=false; 
        this.enablePreSanctionTypeOfVerification=true;
        if(this.SelectedRow.preSancRCU_ARM_Action === "Rejected" || this.SelectedRow.preSancRCU_ARM_Action === "Referred" || 
        this.SelectedRow.preSancRCU_ARM_Action === "RiskAlert" ||  this.SelectedRow.preSancRCU_ARM_Action === "Approved")
        {
          this.preARMReviewisEdit=false;
          this.preARMEnableReason=false;
          this.showFinalSubmitButton=false;
          this.preARMReviedSampled=false;
          this.enablePreSanctionTypeOfVerification=false;
          this.isDiscrepantEdit=false;
        } 
        if(this.SelectedRow.preSancRCU_RRMV_Action==="ReferredBackARM"){
          this.preARMReviewisEdit=true;
          this.preARMEnableReason=true;
          this.showFinalSubmitButton=true;
          this.isRRMPreSanctionScreen=true;
          this.isDiscrepantEdit=true;
          this.enablePreSanctionTypeOfVerification=true;
        }

        if(this.SelectedRow.preSancRCU_ARM_Action === "Approved"){
          this.preARMEnableReason=false;
        }


        if(this.SelectedRow.preSancRCU_Sample_Review === "Sampled" && this.CaseType==="Pending Screen"){
          this.preARMReviewisEdit=false;
          this.preARMEnableReason=false;
          this.showFinalSubmitButton=false;
          this.preARMReviedSampled=false;
          this.enablePreSanctionTypeOfVerification=false;
          this.isDiscrepantEdit=false;
        }

        this.isARMPreSanctionScreen = true; 
        this.isARMPostSanctionScreen=false;
        
        this.isRRMPostSanctionScreen=false;        
      }

      //ARM post
       if(this.SelectedRow.subStage==="Postsanction"){ 
        this.postARMReviewisEdit=true;
        this.postARMEnableReason=true;
        this.showFinalSubmitButton=true;
        this.postARMReviedSampled=true;
        this.isRRMPostSanctionScreen=false;
        this.enablePreSanctionTypeOfVerification=false;
        this.enablePostSanctionTypeOfVerification=true;
        if(this.SelectedRow.postSancRCU_ARM_Action === "Rejected" 
        || this.SelectedRow.postSancRCU_ARM_Action === "Referred" || 
        this.SelectedRow.postSancRCU_ARM_Action === "RiskAlert" 
        ||  this.SelectedRow.postSancRCU_ARM_Action === "Approved" 
        ||  this.SelectedRow.postSancRCU_ARM_Action === "Query")
        {
          this.postARMEnableReason=false;
          this.postARMReviewisEdit=false;
          this.showFinalSubmitButton=false;
          this.postARMReviedSampled=false;
          this.enablePostSanctionTypeOfVerification=false;
        } 

        if(this.SelectedRow.postSancRCU_RRMV_Action==="ReferredBackARM"){
          this.postARMEnableReason=true;
          this.postARMReviewisEdit=true;
          this.showFinalSubmitButton=true;
          this.postARMReviedSampled=true;
          this.enablePostSanctionTypeOfVerification=true;
          this.isRRMPostSanctionScreen=true;
        }

        
        if(this.SelectedRow.postSancRCU_ARM_Action === "Approved"){
          this.postARMEnableReason=false;
        }

        if(this.SelectedRow.postSancRCU_Sample_Review === "Sampled" && this.CaseType==="Pending Screen"){
          this.postARMEnableReason=false;
          this.postARMReviewisEdit=false;
          this.showFinalSubmitButton=false;
          this.postARMReviedSampled=false;
          this.enablePostSanctionTypeOfVerification=false;
        }

        this.isARMPreSanctionScreen=true;
        this.isARMPostSanctionScreen = true;
        this.isRRMPreSanctionScreen=true;
        this.preARMReviewisEdit=false;
        this.preARMEnableReason=false; 
        this.preRRMReviewisEdit=false;     
        
        this.preARMReviedSampled=false;
      } 
    }
    
    if(this.roleId==="RRMV" || this.roleId==="RRMI"){ 
      if(this.SelectedRow.subStage==="Presanction"){ 

        this.preRRMReviewisEdit=true;
        this.showFinalSubmitButton=true;
        this.enablePreSanctionTypeOfVerification=false;

         if(this.roleId==="RRMV"){
           this.isDiscrepantEdit=true;
         }

        if(this.roleId==="RRMV" && (this.SelectedRow.preSancRCU_RRMV_Action === "Rejected" 
                                 || this.SelectedRow.preSancRCU_RRMV_Action === "Referred" 
                                 || this.SelectedRow.preSancRCU_RRMV_Action === "RiskAlert" 
                                 || this.SelectedRow.preSancRCU_RRMV_Action === "Approved"
                                 || this.SelectedRow.preSancRCU_RRMV_Action === "ReferredBackARM"))
        {
          this.preRRMReviewisEdit=false; 
          this.showFinalSubmitButton=false;
          this.isDiscrepantEdit=false;
        }

        if(this.roleId==="RRMV" && this.SelectedRow.preSancRCU_RRMV_Action === "ReferredBackARM"){
          this.preRRMReviewisEdit=false; 
          this.showFinalSubmitButton=false;
        }


        if(this.SelectedRow.preSancRCU_ARM_Action==="RiskAlert" && this.SelectedRow.caseStatus==='Pending with RRMV'){
          this.riskAlertCases=true;
        }

        if(this.roleId==="RRMI" && (this.SelectedRow.preSancRCU_RRMI_Action === "Rejected" 
                                  || this.SelectedRow.preSancRCU_RRMI_Action === "Referred" 
                                  || this.SelectedRow.preSancRCU_RRMI_Action === "RiskAlert" 
                                  ||  this.SelectedRow.preSancRCU_RRMI_Action === "Approved" 
                                  || this.SelectedRow.category==="Completed"))
        {
          this.preRRMReviewisEdit=false; 
          this.showFinalSubmitButton=false;     
          this.isRRMIPretSanctionScreen=true;  
          this.preRRMIReviewEdit=false;   
        }else if(this.roleId==="RRMI"){
          this.preRRMReviewisEdit=false; 
          this.isRRMIPretSanctionScreen=true;
          this.showFinalSubmitButton=true;
          this.preRRMIReviewEdit=true;   
        }


        this.isARMPreSanctionScreen = true;        
        this.preARMReviewisEdit=false; 
        this.preARMEnableReason=false;
        this.isARMPostSanctionScreen=false;
        this.isRRMPreSanctionScreen=true;
        

        this.postARMReviewisEdit=false;
        this.postARMEnableReason=false;
        this.isRRMPostSanctionScreen=false;
        this.isEdit=false;
      }

      //RRM Post && this.SelectedRow.category==="RRMV"
       if(this.SelectedRow.subStage==="Postsanction"){
         
        this.postRRMReviewisEdit=true;
        this.showFinalSubmitButton=true;
        this.enablePreSanctionTypeOfVerification=false;
        this.enablePostSanctionTypeOfVerification=false;
        if(this.SelectedRow.postSancRCU_RRMV_Action === "Rejected" 
        || this.SelectedRow.postSancRCU_RRMV_Action === "Referred" 
        || this.SelectedRow.postSancRCU_RRMV_Action === "RiskAlert" 
        ||  this.SelectedRow.postSancRCU_RRMV_Action === "Approved"
        || this.SelectedRow.postSancRCU_RRMV_Action === "ReferredBackARM")
        {
          this.postRRMReviewisEdit=false;
          this.showFinalSubmitButton=false;
        }

        if(this.roleId==="RRMV" && this.SelectedRow.postSancRCU_RRMV_Action === "ReferredBackARM"){
          this.postRRMReviewisEdit=false; 
          this.showFinalSubmitButton=false;
        }

        if(this.roleId==="RRMI" && (this.SelectedRow.postSancRCU_RRMI_Action === "Rejected" 
              || this.SelectedRow.postSancRCU_RRMI_Action === "Referred" 
              || this.SelectedRow.postSancRCU_RRMI_Action === "RiskAlert" 
              ||  this.SelectedRow.postSancRCU_RRMI_Action === "Approved" 
              || this.SelectedRow.category==="Completed"
              ))
        {
          this.postRRMReviewisEdit=false;
          this.showFinalSubmitButton=false;
          this.postRRMIReviewEdit=false;
          this.isRRMIPostSanctionScreen=true;
        }else if(this.roleId==="RRMI"){
          this.postRRMReviewisEdit=false;
          this.showFinalSubmitButton=true;
          this.postRRMIReviewEdit=true;
          this.isRRMIPostSanctionScreen=true;
        }

        this.isARMPreSanctionScreen = true;
        this.isRRMPreSanctionScreen=true; 
        this.isARMPostSanctionScreen=true;
        this.isRRMPostSanctionScreen=true;
        

        this.preARMReviewisEdit=false;
        this.postARMReviewisEdit=false;         
        this.preRRMReviewisEdit=false;  
        this.isEdit=false;
        this.preARMReviedSampled=false;
        this.postARMReviedSampled=false;
       } 
    }
    
    if(this.SelectedRow.caseStatus==="Completed"){
      this.disableFinalReviewControl();
    }
      
  } 

  radioDiscrpantChange(event:any,doctype:string,applicationNo:string,type:string){

    let itemIndex:number=0;
    this.rcuPreSanctionLANDocCheck.map((x: IRCULANDoc,index) => { 
      if(x.applicationNo === applicationNo && x.docType===doctype)
          itemIndex= index;  
    });

    if(type==="Discrepant"){
       if(event.currentTarget.checked){
        this.rcuPreSanctionLANDocCheck[itemIndex].isDiscrepant = 'Y'; 
       }
      }
      if(type==="NonDiscrepant"){
        if(event.currentTarget.checked){ 
         this.rcuPreSanctionLANDocCheck[itemIndex].isDiscrepant = 'N';
         this.rcuPreSanctionLANDocCheck[itemIndex].rcuMakerDiscrepantReason = '';
         this.rcuPreSanctionLANDocCheck[itemIndex].rcuMakerDiscrepantSubReason = '';
        }
       }
    }
  
    validate(){ 
     let isReviewed =  this.rcuFinalReviewModel.preSancRCU_Sample_Review;
     

     let docReason :string="";
     let docSubReason :string = "";
     let invalidEntry : boolean=false;
     let invalidSubReasonEntry : boolean=false;
     let discrepantReasonSelect:string="";
     let invalidDiscrepantEntry:boolean=false;

     
     this.rcuPreSanctionLANDocCheck.forEach((value)=>{ 

      if(value.isDiscrepant==="" || value.isDiscrepant===null || value.isDiscrepant===undefined){
        discrepantReasonSelect="Please select discrepant/non discrepant";
        invalidDiscrepantEntry =true;
      }

      if(value.isDiscrepant==="Y"){
        if(value.rcuMakerDiscrepantReason==="" || value.rcuMakerDiscrepantReason===null){
          docReason = "Please select discrepant reason for the document type " + value.docTypeName;
          invalidEntry=true; 
        } 

        if(value.rcuMakerDiscrepantSubReason==="" || value.rcuMakerDiscrepantSubReason===null || value.rcuMakerDiscrepantSubReason.trim()==="Select" ){
          docSubReason = "Please select discrepant sub reason for the document type " + value.docTypeName;
          invalidSubReasonEntry =true;
        } 
      } 
      });
    

      if(invalidDiscrepantEntry){
        this.notify.showWarning(discrepantReasonSelect,"Final review");
        return false;
      }
      if(invalidEntry){
        this.notify.showWarning(docReason,"Final review");
        return false;
      }

      if(invalidSubReasonEntry){
        this.notify.showWarning(docSubReason,"Final review");
        return false;
      }


      if(isReviewed === "Sampled"){
        return true;
       }

      let preSanctionARMAction = this.rcuFinalReviewModel.preSancRCU_ARM_Action;

      if(preSanctionARMAction==="" && isReviewed !== "Sampled"){
        this.notify.showWarning("Please select anyone action","Final review");
        return false;
      }

      if( this.rcuFinalReviewModel.preSancTypeOfVerification===""){
        this.notify.showWarning("Please select the Type of verification","Final Review");
        return false;
      }

      if(preSanctionARMAction==="Rejected"  ||  preSanctionARMAction==="RiskAlert" 
        ||  preSanctionARMAction==="Referred"){
        
         if( this.rcuFinalReviewModel.preSancRCU_RejectReason===""){
          this.notify.showWarning("Please select the RCU reason (Main status)","Final Review");
          return false;
        }
        if( this.rcuFinalReviewModel.preSancRCU_RejectSubReason==="" || this.rcuFinalReviewModel.preSancRCU_RejectSubReason.trim()==="Select"){
          this.notify.showWarning("Please select the RCU reason (Sub status)","Final Review");
          return false;
        }
      }
       
      if(preSanctionARMAction==="Rejected"  ||  preSanctionARMAction==="RiskAlert" ||  preSanctionARMAction==="Referred" 
      || preSanctionARMAction==="Approved")
      {
        if(this.rcuFinalReviewModel.preSancRCU_ARM_Remarks===undefined || this.rcuFinalReviewModel.preSancRCU_ARM_Remarks===""){
          this.notify.showWarning("Please specify the remark","Final Review");
          return false;
        }
      }

      return true;
    }

    validatePostARM(){

      if(this.rcuFinalReviewModel.postSancRCU_Sample_Review===""){
        this.notify.showWarning("Please select either reviewed or sampled","Final review");
        return false;
      }

      if(this.rcuFinalReviewModel.postSancRCU_ARM_Action===""){
        this.notify.showWarning("Please select anyone action","Final review");
        return false;
      } 

      let postSanctionARMAction = this.rcuFinalReviewModel.postSancRCU_ARM_Action;

      if( this.rcuFinalReviewModel.postSancTypeOfVerification===""){
        this.notify.showWarning("Please select the Type of verification ","Final Review");
        return false;
      }
     
      if(postSanctionARMAction==="Rejected"  ||  postSanctionARMAction==="RiskAlert" ||  postSanctionARMAction==="Referred"){
       
        if( this.rcuFinalReviewModel.postSancRCU_RejectReason===""){
         this.notify.showWarning("Please select the RCU reason (Main status)","Final Review");
         return false;
       }
       if( this.rcuFinalReviewModel.postSancRCU_RejectSubReason===""){
         this.notify.showWarning("Please select the RCU sub reason (Sub status)","Final Review");
         return false;
       }
     }

     if(postSanctionARMAction==="Approved"  ||  postSanctionARMAction==="RiskAlert" ||  postSanctionARMAction==="Referred"){
       if(this.rcuFinalReviewModel.postSancRCU_ARM_Remarks ===undefined ||this.rcuFinalReviewModel.postSancRCU_ARM_Remarks===""){
        this.notify.showWarning("Please specify the remark","Final Review");
        return false;
       }
     }
       


      return true; 
    }

    validatePreRRM(){

      if(this.rcuFinalReviewModel.preSancRCU_RRMV_Action===""){
        this.notify.showWarning("Please select anyone action","Final review");
        return false;
      } 

      if(this.rcuFinalReviewModel.preSancRCU_RRMV_Remarks === undefined || this.rcuFinalReviewModel.preSancRCU_RRMV_Remarks===""){
        this.notify.showWarning("Please specify the remarks","Final review");
        return false;
      } 

      
      return true;      
    }

    validatePostRRM(){
      
      if(this.rcuFinalReviewModel.postSancRCU_RRMV_Action===""){
        this.notify.showWarning("Please select anyone action","Final review");
        return false;
      } 
      if(this.rcuFinalReviewModel.postSancRCU_RRMV_Remarks === undefined || this.rcuFinalReviewModel.postSancRCU_RRMV_Remarks===""){
        this.notify.showWarning("Please specify the remarks","Final review");
        return false;
      } 
      return true;
    }

    validatePreRRMI(){
      if(this.rcuFinalReviewModel.pre_RRMI_Upload_Ref==="" || this.rcuFinalReviewModel.pre_RRMI_Upload_Ref===null)
      { 
        this.notify.showWarning("Please upload the report","Final review");
        return false;
      } 

      if(this.rcuFinalReviewModel.preSancRCU_RRMI_Remarks===undefined || this.rcuFinalReviewModel.preSancRCU_RRMI_Remarks==="")
      { 
        this.notify.showWarning("Please speicify the remarks","Final review");
        return false;
      }

      this.rcuFinalReviewModel.preSancRCU_RRMI_Action="Approved";
      return true;
    }

    validatePostRRMI(){
      if(this.rcuFinalReviewModel.post_RRMI_Upload_Ref==="" || this.rcuFinalReviewModel.post_RRMI_Upload_Ref==="")
      { 
        this.notify.showWarning("Please upload the report","Final review");
        return false;
      } 

      if(this.rcuFinalReviewModel.postSancRCU_RRMI_Remarks ===undefined || this.rcuFinalReviewModel.postSancRCU_RRMI_Remarks==="")
      { 
        this.notify.showWarning("Please speicify the remarks","Final review");
        return false;
      }
      this.rcuFinalReviewModel.postSancRCU_RRMI_Action="Approved";
      return true;
    }

  Submit() {  
    
    if(this.preARMReviewisEdit && (!this.validate()))
     return;

    if(this.postARMReviewisEdit && (!this.validatePostARM())){ 
        return; 
    } 

    if(this.preRRMReviewisEdit && (!this.validatePreRRM())){ 
      return; 
    }

    if(this.postRRMReviewisEdit && (!this.validatePostRRM())){ 
      return; 
    }
   
    if(this.preRRMIReviewEdit && (!this.validatePreRRMI())){ 
      return; 
    }

    if(this.postRRMIReviewEdit && (!this.validatePostRRMI())){ 
      return; 
    }
    this.rcuSanctionDiscrepantSubmit=[];    
     this.rcuPreSanctionLANDocCheck.forEach((value)=>{
        if(value.docType!==null && value.docType!==""){
        let rcusanctionDiscrepant:RCUSanctionDiscrepant = new RCUSanctionDiscrepant();
        rcusanctionDiscrepant.applicationNo = value.applicationNo;
        rcusanctionDiscrepant.loanAccountNumber = this.selectedLoanAccountNumber;
        rcusanctionDiscrepant.docReason=value.rcuMakerDiscrepantReason;
        rcusanctionDiscrepant.docSubreason =value.rcuMakerDiscrepantSubReason;
        rcusanctionDiscrepant.docType = value.docType;
        rcusanctionDiscrepant.docRCUStatus = value.isDiscrepant;
        this.rcuSanctionDiscrepantSubmit.push(rcusanctionDiscrepant);
        }
     });
    
      this.rcuPostSanctionLANDocCheck.forEach((value)=>{
        if(value.docType!==null && value.docType!=="" && value.remark!==null && value.remark!==undefined){
        let rcusanctionDiscrepant:RCUSanctionDiscrepant = new RCUSanctionDiscrepant();
        rcusanctionDiscrepant.applicationNo = value.applicationNo;
        rcusanctionDiscrepant.loanAccountNumber = this.selectedLoanAccountNumber;
        rcusanctionDiscrepant.docType = value.docType;
        rcusanctionDiscrepant.docRemark = value.remark;
        if(value.remark!=="")
            this.rcuSanctionDiscrepantSubmit.push(rcusanctionDiscrepant);
        }
     });

     if(this.rcuSanctionDiscrepantSubmit.length===0){
       this.rcuSanctionDiscrepantSubmit.push(new RCUSanctionDiscrepant());       
     }

     this.rcuSanctionSubmit.roleId=this.roleId;
     this.rcuSanctionSubmit.screenType =this.SelectedRow.subStage;
     this.rcuSanctionSubmit.loanAccountNumber = this.selectedLoanAccountNumber;
     this.rcuSanctionSubmit.login_ps_id = this.UserId;
     // pre ARM     
     this.rcuSanctionSubmit.preSancRCU_Sample_Review = this.rcuFinalReviewModel.preSancRCU_Sample_Review;
     this.rcuSanctionSubmit.preSancRCU_ARM_Remarks = this.rcuFinalReviewModel.preSancRCU_ARM_Remarks;
     this.rcuSanctionSubmit.preSancRCU_ARM_Action = this.rcuFinalReviewModel.preSancRCU_ARM_Action == null ? "" : this.rcuFinalReviewModel.preSancRCU_ARM_Action;    
     this.rcuSanctionSubmit.preSancTypeOfVerification = this.rcuFinalReviewModel.preSancTypeOfVerification;
     this.rcuSanctionSubmit.preSancRCU_RejectReason = this.rcuFinalReviewModel.preSancRCU_RejectReason;
     this.rcuSanctionSubmit.preSancRCU_RejectSubReason = this.rcuFinalReviewModel.preSancRCU_RejectSubReason;
     this.rcuSanctionSubmit.rcuDiscrepantResult = this.rcuSanctionDiscrepantSubmit; 
     //post ARM
     this.rcuSanctionSubmit.postSancRCU_ARM_Action = this.rcuFinalReviewModel.postSancRCU_ARM_Action== null ? "" : this.rcuFinalReviewModel.postSancRCU_ARM_Action;    
     this.rcuSanctionSubmit.postSancRCU_Sample_Review = this.rcuFinalReviewModel.postSancRCU_Sample_Review;
     this.rcuSanctionSubmit.postSancRCU_ARM_Remarks=this.rcuFinalReviewModel.postSancRCU_ARM_Remarks;     
     this.rcuSanctionSubmit.postSancTypeOfVerification = this.rcuFinalReviewModel.postSancTypeOfVerification;
     this.rcuSanctionSubmit.postSancRCU_RejectReason = this.rcuFinalReviewModel.postSancRCU_RejectReason;
     this.rcuSanctionSubmit.postSancRCU_RejectSubReason = this.rcuFinalReviewModel.postSancRCU_RejectSubReason;
     this.rcuSanctionSubmit.postSancRCU_ARM_Query = this.rcuFinalReviewModel.postSancRCU_ARM_Query; 
     //Pre RRM 
     this.rcuSanctionSubmit.preSancRCU_RRMV_Action = this.rcuFinalReviewModel.preSancRCU_RRMV_Action === null ? "" : this.rcuFinalReviewModel.preSancRCU_RRMV_Action;
     this.rcuSanctionSubmit.preSancRCU_RRMV_Remarks =this.rcuFinalReviewModel.preSancRCU_RRMV_Remarks; 
     let preSancRcuStatus:string ='';
     preSancRcuStatus = this.GetPreSanctionStatus();
     this.rcuSanctionSubmit.preSancRCU_Status = preSancRcuStatus===null ? "" :  preSancRcuStatus;
     
     let postSancRcuStatus:string ='';
     postSancRcuStatus = this.GetPostSanctionStatus();
     this.rcuSanctionSubmit.postSancRCU_Status = postSancRcuStatus===null ? "" :  postSancRcuStatus;

     //post RRM Verfication
     this.rcuSanctionSubmit.postSancRCU_RRMV_Action = this.rcuFinalReviewModel.postSancRCU_RRMV_Action===null ? "" : this.rcuFinalReviewModel.postSancRCU_RRMV_Action;
     this.rcuSanctionSubmit.postSancRCU_RRMV_Remarks = this.rcuFinalReviewModel.postSancRCU_RRMV_Remarks;
     //RRM Investigation      
     this.rcuSanctionSubmit.pre_RRMI_Upload_Ref = this.rcuFinalReviewModel.pre_RRMI_Upload_Ref; 
     this.rcuSanctionSubmit.preSancRCU_RRMI_Action = this.rcuFinalReviewModel.preSancRCU_RRMI_Action=== null ? "" : this.rcuFinalReviewModel.preSancRCU_RRMI_Action;
     this.rcuSanctionSubmit.TokenNumber = this.rcuFinalReviewModel.tokenNumber===undefined ? "" : this.rcuFinalReviewModel.tokenNumber;
     this.rcuSanctionSubmit.preSancRCU_RRMI_Remarks = this.rcuFinalReviewModel.preSancRCU_RRMI_Remarks;
     this.rcuSanctionSubmit.postTokenNumber=this.rcuFinalReviewModel.postTokenNumber===null ? "" : this.rcuFinalReviewModel.postTokenNumber;
     this.rcuSanctionSubmit.post_RRMI_Upload_Ref = this.rcuFinalReviewModel.post_RRMI_Upload_Ref;
     this.rcuSanctionSubmit.postSancRCU_RRMI_Action = this.rcuFinalReviewModel.postSancRCU_RRMI_Action === null ? "" : this.rcuFinalReviewModel.postSancRCU_RRMI_Action;
     this.rcuSanctionSubmit.postSancRCU_RRMI_Remarks = this.rcuFinalReviewModel.postSancRCU_RRMI_Remarks; 

     this.SelectedRow.preSancRCU_Sample_Review = this.rcuFinalReviewModel.preSancRCU_Sample_Review;
     this.SelectedRow.preSancRCU_ARM_Action =this.rcuFinalReviewModel.preSancRCU_ARM_Action;
     this.SelectedRow.preSancRCU_RRMV_Action = this.rcuFinalReviewModel.preSancRCU_RRMV_Action;
     this.SelectedRow.preSancRCU_RRMI_Action = this.rcuFinalReviewModel.preSancRCU_RRMI_Action;
     
     this.SelectedRow.postSancRCU_Sample_Review = this.rcuFinalReviewModel.postSancRCU_Sample_Review;
     this.SelectedRow.postSancRCU_ARM_Action =this.rcuFinalReviewModel.postSancRCU_ARM_Action;
     this.SelectedRow.postSancRCU_RRMV_Action = this.rcuFinalReviewModel.postSancRCU_RRMV_Action;
     this.SelectedRow.postSancRCU_RRMI_Action = this.rcuFinalReviewModel.postSancRCU_RRMI_Action;

     if(this.roleId==="ARM"){
         if(this.rcuFinalReviewModel.postSancRCU_RRMV_Action === "ReferredBackARM"){
          this.rcuSanctionSubmit.postSancRCU_RRMV_Action ="";
          this.SelectedRow.postSancRCU_RRMV_Action="";
         }
         if(this.rcuFinalReviewModel.preSancRCU_RRMV_Action === "ReferredBackARM"){
          this.rcuSanctionSubmit.preSancRCU_RRMV_Action ="";
          this.SelectedRow.preSancRCU_RRMV_Action="";
         }
     }

     this.info.removeItem('PendingScreenInfo');
     this.info.setItem('PendingScreenInfo',JSON.stringify(this.SelectedRow));
     
    this.http.httpPost(this.rcuSanctionSubmit, 'LAP_SubmitRCULANFinalReview')
      .subscribe((res:any) => {
        
        if(res.errorcode!="E408"){
        this.notify.showSuccess("Data has been saved successfully","RCU")
        this.disableFinalReviewControl();
        }
        else{
          this.notify.showError("Something went wrong! Please try again later","RCU")
        } 
      });
  }

  GetPreSanctionStatus(){
    if(this.roleId==="ARM"){
      if(this.rcuFinalReviewModel.preSancRCU_ARM_Action==="Approved"){
        return "Completed";
      }
       return this.rcuFinalReviewModel.preSancRCU_ARM_Action;
    }

    if(this.roleId==="RRMV"){

      if(this.rcuFinalReviewModel.preSancRCU_RRMV_Action==="Approved" || this.rcuFinalReviewModel.preSancRCU_RRMV_Action==="Rejected"){
        return "Completed";
      }
      return this.rcuFinalReviewModel.preSancRCU_RRMV_Action;
    }

    if(this.roleId==="RRMI"){
      return "Completed";
    }

    return "NARM";
  }

  GetPostSanctionStatus(){

    if(this.roleId==="ARM"){ 
       return this.rcuFinalReviewModel.postSancRCU_ARM_Action;
    } 
    if(this.roleId==="RRMV"){
      if(this.rcuFinalReviewModel.postSancRCU_RRMV_Action==="Rejected" || this.rcuFinalReviewModel.postSancRCU_RRMV_Action==="Approved"){
        return "Completed";
      }
      return this.rcuFinalReviewModel.postSancRCU_RRMV_Action;
    } 
    if(this.roleId==="RRMI"){ 
      return "Completed";
    } 
    return "NARM";
  }

  btnBankStmtLnk(){ 
    this.info.setItem("PendingScreenInfo", JSON.stringify(this.SelectedRow));  
    this.route.navigateByUrl("/bankingassessment");
  } 

  btnLegalCheckLnk(){
    this.info.setItem("PendingScreenInfo", JSON.stringify(this.SelectedRow));  
    this.route.navigateByUrl("/legalcheck");
  }

  btnTechnicalLnk(){
    this.info.setItem("PendingScreenInfo", JSON.stringify(this.SelectedRow));  
    this.route.navigateByUrl("/technicalcheck");
  }

  selectedStatus: String = "--Choose Status--"; 
  ChangeSubStatus(count: any) { 
    var selectedMainStaus = this.MainStatusLists.find(x=>x.status=== count.target.value);
    this.SubReasonList =  this.reason.getSubReason().filter((item) => item.Id == selectedMainStaus?.Id ||  item.Id ==0);
  }

  ChangeSubStatuss(count: any,doctype:string,applicationNo:string) { 
   let itemIndex:number=0;
    var selectedMainStaus = this.MainStatusLists.find(x=>x.status=== count.target.value); 
  
   this.rcuPreSanctionLANDocCheck.map((x: IRCULANDoc,index) => { 
          if(x.applicationNo === applicationNo && x.docType===doctype)
              itemIndex= index;  
       });  
    this.rcuPreSanctionLANDocCheck[itemIndex].subReasonList =this.reason.getSubReason().filter((item) => item.Id == selectedMainStaus?.Id || item.Id==0); 
  }

  showModal(e: any) {
     
    var data ={
      UUID :e
    }
    this.http.httpPost<IDownloadDocument>((data), 'LAP_DownloadDocument').subscribe((res: IDownloadDocument) => {
      var imgContent = `data:image/jpg;base64,${res.imageData}`;
      let data = new ModalCommon({
        message: `<div class="w-100 text-center"> <img class="w-25 img-thumbnail" src="${imgContent}" /> </div>`,
        title: "Photo"
      } as IModalCommon);
       this.modal.ShowModal(data);
    })
  }
 
  chkChange(event:any,typeValue:string){
    
    if(typeValue==="Reviewed" && event.currentTarget.checked){ 
      this.preARMReviewisEdit=true; 
      this.preARMEnableReason=true;
      this.rcuFinalReviewModel.preSancRCU_Sample_Review = "Reviewed"; 
    }
    else if(typeValue==="Reviewed" && (!event.currentTarget.checked)){ 
      this.preARMReviewisEdit=true;
      this.rcuFinalReviewModel.preSancRCU_Sample_Review = ""; 
    }

    if(typeValue==="Sampled" && event.currentTarget.checked){
      this.rcuFinalReviewModel.preSancRCU_Sample_Review =  "Sampled";      
      this.rcuFinalReviewModel.preSancRCU_ARM_Action =  "";      
      this.preARMReviewisEdit=false;         
      this.preARMEnableReason=false;
    }else if(typeValue==="Sampled" && (!event.currentTarget.checked)){ 
      this.preARMReviewisEdit=false;
      this.preARMEnableReason=true;
      this.rcuFinalReviewModel.preSancRCU_Sample_Review = ""; 
    }
  } 

  chkPostARMChange(event:any,itemType:string){
    
    if(itemType==="Reviewed" && event.currentTarget.checked){
      this.postARMReviewisEdit=true;
      this.postARMEnableReason=true;
      this.rcuFinalReviewModel.postSancRCU_Sample_Review =  "Reviewed"; 
    }else if(itemType==="Reviewed" && (!event.currentTarget.checked)){
      this.postARMReviewisEdit=true;
      this.rcuFinalReviewModel.postSancRCU_Sample_Review =  ""; 
    }

    if(itemType==="Sampled" &&  event.currentTarget.checked){
      this.rcuFinalReviewModel.postSancRCU_Sample_Review =  "Sampled"; 
      this.rcuFinalReviewModel.postSancRCU_ARM_Action="";     
      this.postARMReviewisEdit=false; 
      this.postARMEnableReason=false;
    }else  if(itemType==="Sampled" &&  (!event.currentTarget.checked)){
      this.rcuFinalReviewModel.postSancRCU_Sample_Review =  "";      
      this.postARMReviewisEdit=true;
      this.postARMEnableReason=true; 
    }
  }

  onPreSanARMRadioChange(event:any,itemType:string){ 
    if(itemType==="Approved" && event.currentTarget.checked){
      this.preARMEnableReason=false;
      this.rcuFinalReviewModel.preSancRCU_RejectReason="";
      this.rcuFinalReviewModel.preSancRCU_RejectSubReason="";
      this.rcuFinalReviewModel.preSancRCU_ARM_Action= "Approved"; 
    }

    if(itemType==="Reject" && event.currentTarget.checked){
      this.preARMEnableReason=true;
      this.rcuFinalReviewModel.preSancRCU_ARM_Action= "Rejected"; 
    }


    if(itemType==="Referred" && event.currentTarget.checked){
      this.preARMEnableReason=true;
      this.rcuFinalReviewModel.preSancRCU_ARM_Action= "Referred"; 
    }


    if(itemType==="RiskAlert" && event.currentTarget.checked){
      this.preARMEnableReason=true;
      this.rcuFinalReviewModel.preSancRCU_ARM_Action= "RiskAlert"; 
    } 
  }

  onPostSanARMRadioChange(event:any,itemType:string){ 
    if(itemType==="Approved" && event.currentTarget.checked){
      this.postARMEnableReason=false;      
      this.rcuFinalReviewModel.postSancRCU_RejectReason="";
      this.rcuFinalReviewModel.postSancRCU_RejectSubReason="";
     // this.rcuFinalReviewModel.postSancTypeOfVerification="";
      this.rcuFinalReviewModel.postSancRCU_ARM_Action= "Approved"; 
    }

    if(itemType==="Reject" && event.currentTarget.checked){
      this.postARMEnableReason=true;
      this.rcuFinalReviewModel.postSancRCU_ARM_Action="Rejected"; 
    }


    if(itemType==="Referred" && event.currentTarget.checked){
      this.postARMEnableReason=true;
      this.rcuFinalReviewModel.postSancRCU_ARM_Action="Referred"; 
    }

    if(itemType==="Query" && event.currentTarget.checked){
      this.postARMEnableReason=true;
      this.rcuFinalReviewModel.postSancRCU_ARM_Action="Query"; 
    }


    if(itemType==="RiskAlert" && event.currentTarget.checked){
      this.postARMEnableReason=true;
      this.rcuFinalReviewModel.postSancRCU_ARM_Action="RiskAlert"; 
    } 
  }

  onPostSanRRMRadioChange(event:any,itemType:string){
    if(itemType==="Approved" && event.currentTarget.checked){
      this.rcuFinalReviewModel.postSancRCU_RRMV_Action= "Approved"; 
    }

    if(itemType==="Reject" && event.currentTarget.checked){
      this.rcuFinalReviewModel.postSancRCU_RRMV_Action="Rejected"; 
    }


    if(itemType==="Reffered" && event.currentTarget.checked){
      this.rcuFinalReviewModel.postSancRCU_RRMV_Action="Referred"; 
    }

    if(itemType==="ReferredBackARM" && event.currentTarget.checked){
      this.rcuFinalReviewModel.postSancRCU_RRMV_Action="ReferredBackARM"; 
    }


    if(itemType==="RiskAlert" && event.currentTarget.checked){
      this.rcuFinalReviewModel.postSancRCU_RRMV_Action= "RiskAlert"; 
    }
  }

  onPreSanRRMRadioChange(event:any,itemType:string){
    if(itemType==="Approved" && event.currentTarget.checked){
      this.rcuFinalReviewModel.preSancRCU_RRMV_Action= "Approved"; 
    }

    if(itemType==="Reject" && event.currentTarget.checked){
      this.rcuFinalReviewModel.preSancRCU_RRMV_Action= "Rejected"; 
    }

    if(itemType==="ReferredBackARM" && event.currentTarget.checked){
      this.rcuFinalReviewModel.preSancRCU_RRMV_Action="ReferredBackARM"; 
    }


    if(itemType==="Reffered" && event.currentTarget.checked){
      this.rcuFinalReviewModel.preSancRCU_RRMV_Action="Referred"; 
    }


    if(itemType==="RiskAlert" && event.currentTarget.checked){
      this.rcuFinalReviewModel.preSancRCU_RRMV_Action= "RiskAlert"; 
    }
  } 

  BackButton(){
    this.route.navigateByUrl("/riskcontolunitdash");
  }
}
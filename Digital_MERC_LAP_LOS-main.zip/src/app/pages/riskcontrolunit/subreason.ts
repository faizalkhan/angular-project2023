export class SubReason{
    subStatus:string='';
    Id:number=0;
    constructor( subStatus: string, Id:number){
        this.subStatus=subStatus;
        this.Id=Id;
    } 
}

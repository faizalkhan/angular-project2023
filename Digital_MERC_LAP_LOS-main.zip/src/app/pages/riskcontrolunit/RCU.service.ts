import { Injectable } from '@angular/core';
import { MainReason } from './MainReason';
import { SubReason } from './subreason';

@Injectable()
export class RemarkReasonService {

  getMainReason() {
    return[    
        { 
           status:"KYC 1 & 2 of both applicant / co applicant", 
           Id:1
         },
         {
           status:"Bank",
           Id:2 
         },
         {
           status:"Mobile Number relate",
           Id:3
         },
         {
           status:"Policy related",
           Id:4
         },
         {
           status:"Process Violation",
           Id:5
         }, 
         {
             status:"Valuation",
             Id:6
         }, 
         {
             status:"Legal",
             Id:7
         }    
     ];
  }
  
  getSubReason() {
   return[
        { 
            subStatus:'Select ',
            Id:0
        },
        { 
            subStatus:'Fake/Tampered KYC ',
            Id:1 
        },
        { 
            subStatus:'Random Image / Unclear Image uploaded (either 1st or 2nd page)',
            Id:1 
        },
        { 
            subStatus:'Applicant is Outside Age Limit',
            Id:1 
        },
        { 
            subStatus:'Complete Name Mismatch',
            Id:1 
        },
        { 
            subStatus:'Complete Mismatch with Picture on KYC applicants live picture',
            Id:1 
        },
        { 
            subStatus:'Number Mismatch',
            Id:1 
        },
        { 
            subStatus:'Invalid (Online checks)',
            Id:1 
        },
        { 
            subStatus:'Gender Mismatch (basis online check)',
            Id:1 
        },
        { 
            subStatus:'Sourcing using Photocopy',
            Id:1 
        },
        { 
            subStatus:'DOB Mismatch - Age as per policy',
            Id:1 
        },
        { 
            subStatus:'Others',
            Id:1 
        },
        {
            subStatus:"Complete mismatch in name from borrower name",
            Id:2
        },
        {
            subStatus:"Random / Unclear Image uploaded",
            Id:2
        },
        {
            subStatus:"Manually updated / Printed Bank A/C No. Reverse feedback - Beneficiary Name mismatch",
            Id:2
        },
        {
            subStatus:"Co-borrower Passbook (not Joint A/C)",
            Id:2
        },
        {
            subStatus:"Number Mismatch - Any digit mismatch",
            Id:2
        },
        {
            subStatus:"Joint A/C with a non co-applicant individual",
            Id:2
        },
        {
            subStatus:"Fake/Tampering (Ground Checks . Info)",
            Id:2
        },
        {
            subStatus:"IFSC wrong/ not mentioned",
            Id:2
        },
        {
            subStatus:"Others",
            Id:2
        },
        {
            subStatus:"Third party mobile number updated",
            Id:3
        },
        {
            subStatus:"Customer number not in service / invalid",
            Id:3
        },
        {
            subStatus:"Others",
            Id:3
        },
        {
            subStatus:"Relation of borrower and co-borrower not matched as per application / not established",
            Id:4
        },
        {
            subStatus:"Blood / close relatives in one group",
            Id:4
        },
        {
            subStatus:"Co-borrower Stays in abroad",
            Id:4
        },
        {
            subStatus:"Co-borrower currently not in the state (working outside/abroad)",
            Id:4
        },
        {
            subStatus:"Migrant Customer",
            Id:4
        },
        {
            subStatus:"Others",
            Id:4
        },
        {
            subStatus:"Customer live photo not captured",
            Id:5
        },
        {
            subStatus:"Borrowers dont know each other",
            Id:5
        },
        {
            subStatus:"Customer not interested to take loan",
            Id:5
        },
        {
            subStatus:"CIBIL below the benchmark approval not taken",
            Id:5
        },
        {
            subStatus:"Loan applicant / co applicant engaged in negative business",
            Id:5
        },
        {
            subStatus:"Properties not as per the policy have been sourced",
            Id:5
        } ,
        {
            subStatus:"Charge already created with different institution or charge not created",
            Id:5
        },
        {
            subStatus:"Others",
            Id:5
        },
        {
            subStatus:"Valuation report tampered",
            Id:6
        },
        {
            subStatus:"Address mismatch with the valuation done",
            Id:6
        },
        {
            subStatus:"Valuation and legal report details mismtach",
            Id:6
        },
        {
            subStatus:"Second valuation not done for the cases before the sanction",
            Id:6
        },
        {
            subStatus:"Title deed not in the name of the applicant",
            Id:7
        },
        {
            subStatus:"Litigation on the property",
            Id:7
        },
        {
            subStatus:"Negative area",
            Id:7
        },
        {
            subStatus:"Litigation on the applicant / co applicant",
            Id:7
        },
        {
            subStatus:"Mismatch in the property owner",
            Id:7
        },
        {
            subStatus:"Legal report not available at the time of sanction",
            Id:7
        },
        {
            subStatus:"Legal report address mismtch with the property details",
            Id:7
        },
        {
            subStatus:"Others",
            Id:7
        }         
    ]  ;
  }

  GenerateToken(length:number) {
    var result           = '';
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
} 
}
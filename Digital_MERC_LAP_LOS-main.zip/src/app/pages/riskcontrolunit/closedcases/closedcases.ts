import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InfoServices } from 'src/app/Injectable/info.services';
import { NotificationService } from 'src/app/notification.service';
import { headerModel } from 'src/app/shared/models/common/header-table';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
import { requestmodel } from 'src/app/shared/models/sanction/request.model';
import { ISearch } from 'src/app/shared/models/sanction/search/search';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { SearchService } from 'src/app/shared/services/search/search.service';
import { __param } from 'tslib';
import { MenuService } from '../../layout/header/menu-service.service';
import { MenuResponse } from '../../layout/login/login.service';
import { IPendingDashboardModel, PendingDahboardModel } from '../RCU.Model';


@Component({
  selector: 'app-closedcases',
  templateUrl: './closedcases.html',
  styleUrls: ['./closedcases.css']
})
export class ClosedCasesComponent implements OnInit {
  title: any = "Closed Cases Dashboard"
  isDashboard: Boolean = true;
  private _header: any[] = [];
  private _data: any[] = [];
  public nullData: boolean = true;
  page: number = 1;
  PerPage: number = 5;

  public get Data(): any[] {
    return this._data;
  }
  public set Data(value: any[]) {
    this._data = value;
  }

  public get Header(): any[] {
    return this._header;
  }
  public set Header(value: any[]) {
    this._header = value;
  }
  loggedInUserRoleId:string='';
  _userId:string='';
  roleId:string ='';
  currentDateTime: any = new Date();
  private _selectedRow:PendingDahboardModel= new PendingDahboardModel();
  public get SelectedRow():PendingDahboardModel{
     return this._selectedRow;
  }

  public set SelectedRow(value:PendingDahboardModel){
    this._selectedRow=value;
  }
  constructor(private http: ConfigService,private notify: NotificationService,private info: InfoServices,
    private route: Router,private _searchService: SearchService,private menuService:MenuService) {

  }

  getLoggedInUserRole(){
    var loggedInUserRole = JSON.parse(this.info.getItem('menu')) as MenuResponse;
    this.loggedInUserRoleId = loggedInUserRole.menuUserDetail.roleId; 
    this._userId = loggedInUserRole.menuUserDetail.userId;
    let loggedInUserRoleDetails =  loggedInUserRole.roleDetails.find(x=>x.roleId==this.loggedInUserRoleId);
    if(loggedInUserRoleDetails!==null)
        this.roleId = loggedInUserRoleDetails?.roleName === undefined ? "" :  loggedInUserRoleDetails.roleName;   

    if(this.roleId==="RRM-V"){
      this.roleId="RRMV";
    }

    if(this.roleId==="RRM-I"){
      this.roleId="RRMI";
    }
  }

  ngOnInit(): void {
    // this._header = [
    //   // new headerModel('lannumber', 'Lan no.'),
    //   // new headerModel('applicantname', 'Applicant name'),
    //   // new headerModel('substage', 'Sub Stage'),
    //   // new headerModel('state','State'),
    //   // new headerModel('branch', 'Branch'),
    //   // new headerModel('mobilenumber', 'Mobile Number'),
    //   // new headerModel('ageing', 'Ageing'),
    //   // new headerModel('closeddate','Closed Date'),
    //   // new headerModel('action', 'Action'),

    //   new headerModel('loanAccountNumber', 'Lan no.'),
    //   new headerModel('name', 'Name'), 
    //   new headerModel('state', 'State'), 
    //   new headerModel('mobileNo', 'Mobile Number of Applicant'),
    //   new headerModel('rcuTriggeredDate', 'RCU Triggered Date'),
    //   new headerModel('ageing', 'Ageing'),
    //   new headerModel('preSancRCU_CompletedDate', 'Closed Date'),
    //   new headerModel('subStage', 'Sub Stage'),
    //   //new headerModel('category', 'Category'), 
    //   new headerModel('caseStatus', 'Case Status')
    // ];


    this.getLoggedInUserRole();

    if(this.roleId==="RRM-V"){
      this.roleId="RRMV";
    }

    if(this.roleId==="RRM-I"){
      this.roleId="RRMI";
    }

    const request = new requestmodel();
    request.FromDate = new Date().toString();
    request.ToDate = new Date().toString();
    request.UserID = this._userId;
    request.Role = this.roleId;
    request.ScreenType = "";
    request.FieldName = "FLO";
    request.FieldValue = "FLO"
 
    if (!this._searchService.SearchData.observed) {
 
     this._searchService.SearchData.subscribe((res: ISearch) => { 

      if(res.role==="RRM-V"){
        res.role="RRMV";
      }
  
      if(res.role==="RRM-I"){
        res.role="RRMI";
      }
      request.FieldName=res.fieldName;
      request.FieldValue = res.fieldValue;
      request.FromDate=res.fromDate.toString();
      request.ToDate=res.toDate.toString();
      //this.RMCSearch.screenType="";
      request.Role=res.role;
      request.UserID=res.login_PS_ID;           
      this.getPendingActionlist(request.RCUPendingActiontoJSON());
       
    });
    } 
    else{
      this.getPendingActionlist(request.RCUPendingActiontoJSON());
    }
  }

  getPendingActionlist(param:any) {
     
    this.http.httpPost<IresponseModel<PendingDahboardModel[]>>(param, 'LAP_RCUPendingAction').subscribe((res: IresponseModel<PendingDahboardModel[]>) => {
     this.Data = []; 
     
     if(res.rcuPendingActionList!=null && res.rcuPendingActionList.length>=0){
      this.nullData = false;
         let pendingList = res.rcuPendingActionList.filter(x=>x.category==="Completed");
         this.notify.showSuccess("Dashboard data retrived successfully", "Closed Cases");
         this.Data = pendingList.map((x: IPendingDashboardModel) => {
             return new PendingDahboardModel(x);
         });    
       }
       else{
        this.nullData = true;
         this.notify.showWarning("Something went wrong", "Closed Cases");
       }
      })  
  }  

  row_click(event: any): void {
    this.isDashboard = false;
    this.SelectedRow = event;
    this.menuService.IsShow=false;
    this.info.setItem("PendingScreenInfo", JSON.stringify(this.SelectedRow));  
    this.info.setItem("CaseType", "Closed case");
    this.route.navigateByUrl("/pendingscreen");
   }
   btnBack(){
    this.route.navigateByUrl("/riskcontolunitdash");
  }
}
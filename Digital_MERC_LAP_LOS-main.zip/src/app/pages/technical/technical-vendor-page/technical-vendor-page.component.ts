import { Component, OnInit } from '@angular/core';
import { InfoServices } from 'src/app/Injectable/info.services';
import { ConfigService } from 'src/app/shared/services/common/http.services';

@Component({
  selector: 'app-technical-vendor-page',
  templateUrl: './technical-vendor-page.component.html',
  styleUrls: ['./technical-vendor-page.component.css'],
  providers:[ConfigService]
})
export class TechnicalVendorPageComponent implements OnInit {

  legalRequestData:any;
   
  constructor(private Info: InfoServices) {
    
      var data = this.Info.getItem('TechnicalVendor_LanInfo');         
      
      if (data != '') {
          this.legalRequestData = JSON.parse(data);
      }
      else {
          return;
      }
       
  }
  ngOnInit(): void {
    
  }
    


}

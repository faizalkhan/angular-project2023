import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TechnicalVendorPageComponent } from './technical-vendor-page.component';

describe('TechnicalVendorPageComponent', () => {
  let component: TechnicalVendorPageComponent;
  let fixture: ComponentFixture<TechnicalVendorPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TechnicalVendorPageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TechnicalVendorPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

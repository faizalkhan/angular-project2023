import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TechnicalVendorDashboardComponent } from './technical-vendor-dashboard.component';

describe('TechnicalVendorDashboardComponent', () => {
  let component: TechnicalVendorDashboardComponent;
  let fixture: ComponentFixture<TechnicalVendorDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TechnicalVendorDashboardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TechnicalVendorDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

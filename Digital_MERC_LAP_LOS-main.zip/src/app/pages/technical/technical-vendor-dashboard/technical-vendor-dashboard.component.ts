import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InfoServices } from 'src/app/Injectable/info.services';
import { IDropdown } from 'src/app/shared/models/common/control.model';
import { ITechnicalVendorDashboardResponseModel, LegalVendorSearch } from 'src/app/shared/models/common/response.model';
import {  TechnicalVendorDashboardModel } from 'src/app/shared/models/sanction/Legal/legalDashboard';
import { ISearch } from 'src/app/shared/models/sanction/search/search';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { SearchService } from 'src/app/shared/services/search/search.service';
import { MenuResponse } from '../../layout/login/login.service';

@Component({
  selector: 'app-technical-vendor-dashboard',
  templateUrl: './technical-vendor-dashboard.component.html',
  styleUrls: ['./technical-vendor-dashboard.component.css'],
  providers:[ConfigService]
})
export class TechnicalVendorDashboardComponent implements OnInit {
 
  param: any;
  ResponseData:any; 
  private _data: TechnicalVendorDashboardComponent[] = [];
  searchBy: IDropdown[] = [];   
  txtSearchValue:string='';
  fromDate:Date= new Date;
  toDate:Date=new Date;
  selectedValue:any='';
  selectedOption:string='';
  technicalVendorSearch:LegalVendorSearch = new LegalVendorSearch();
  _userId:string='';

  constructor(private http: ConfigService, private Info: InfoServices, private route: Router, private _searchService: SearchService) {
       
  }

  public get Data(): any[] {
    return this._data;
  }
  public set Data(value: any[]) {
      this._data = value;
  }

  ngOnInit(): void { 
    var loggedInUserRole = JSON.parse(this.Info.getItem('menu')) as MenuResponse;
    //this.loggedInUserRoleId = loggedInUserRole.menuUserDetail.roleId; 
    this._userId=loggedInUserRole.menuUserDetail.userId;
      //this.GetSearchBy();
      this._searchService.SearchData.subscribe((res: ISearch) => {
       // res.login_PS_ID="VEN04223"; 
        this.technicalVendorSearch.FromDate = res.fromDate;
        this.technicalVendorSearch.toDate=res.toDate;
        this.technicalVendorSearch.fieldName=res.fieldName;
        this.technicalVendorSearch.role=loggedInUserRole.menuUserDetail.roleId;
        this.technicalVendorSearch.fieldValue=res.fieldValue;
        this.technicalVendorSearch.login_PS_ID=this._userId;
        this.technicalVendorSearch.selectedOption=this.selectedOption; 
        this.GetLAPLegalVendorDashboard(this.technicalVendorSearch.toJson());
        
      });
      //this.GetLAPLegalVendorDashboard();
  }

 GetSearchBy(){
    this.searchBy =[
      { displayName: 'Select', selected: true, value: '' },
      { displayName: 'Branch', selected: false, value: 'test' } 
     ]
  }

  GetLAPLegalVendorDashboard(param:any){
    // this.param =  { lan: "string",
    //     loginPSID: "?20105989",
    //     apiInvokeDateTime: new Date(),
    //     role: "FLO",
    //     fromDate:new Date(),
    //     toDate:new Date(),
    //     keyColumn:"",
    //     keyValue:""   
    // }

    this.http.httpPost<ITechnicalVendorDashboardResponseModel<TechnicalVendorDashboardModel[]>>(param, 'LAP_GetTechnicalVendorDashboard').subscribe((res: ITechnicalVendorDashboardResponseModel<TechnicalVendorDashboardModel[]>) => {
        this.Data = res.technicalVendorDashboardDetails;
    })
}

NavigateClick(item: any) {

    var data = {            
        "lan": item.lanid,
        "login_PS_ID": this._userId,
        "apiInvokeDateTime": "2022-09-15T05:03:52.964Z",
        "role": "FLO"
    }
    // var data = {
    //     "LoanAccountNumber": "123",
    //     "FLO_PsId": "23423",
    //     "CreatedON": "2022-08-04"
    // };
    this.Info.setItem('TechnicalVendor_LanInfo', JSON.stringify(data));
    
    
    switch (item.caseStatus) {
        case "New Cases": 
            this.Info.setItem('Screen_Type', "");
            this.route.navigateByUrl("/technicalVendorunassginedcases");
            break;
        case "Refer": 
            this.Info.setItem('Screen_Type', "Refer");
            this.route.navigateByUrl("/technicalVendorunassginedcases");
            break;       
        default:             
            this.Info.setItem('Screen_Type', "");
            this.route.navigateByUrl("/technicalVendorunassginedcases");
            break;
    }

  }

  onRadioChange(event:any,selectedItem:string){
    
      if(selectedItem==="NewCase"){
         this.selectedOption = event.currentTarget.checked ? "New" : "";
      }
      if(selectedItem==="SentBackCase"){
        this.selectedOption = event.currentTarget.checked ? "SentBack" : "";
     }

     if(this.selectedOption!=""){
      this.technicalVendorSearch.selectedOption=this.selectedOption; 
      this.GetLAPLegalVendorDashboard(this.technicalVendorSearch.toJson());
     }
  }
  
}
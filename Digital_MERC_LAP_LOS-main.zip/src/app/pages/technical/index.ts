import { CustomRouteConfig } from "src/app/shared/models/common/route-config";
import { LegalVendorPageComponent } from "../legal/legal-vendor-page/legal-vendor-page.component";
import { TechnicalVendorDashboardComponent } from "./technical-vendor-dashboard/technical-vendor-dashboard.component";
import { TechnicalVendorPageComponent } from "./technical-vendor-page/technical-vendor-page.component";

export const TechnicalModule = [TechnicalVendorPageComponent,TechnicalVendorDashboardComponent];

export const TechnicalRoute: CustomRouteConfig[] = [];

TechnicalRoute.push(new CustomRouteConfig({ menuName: "Technical Check", title: "Technical Check", path: "technicalvendor", redirectTo: "/technicalvendor", isActive: true }));

TechnicalRoute.push(new CustomRouteConfig({ path: "technicalvendor", componentName: TechnicalVendorDashboardComponent, title: "Technical Check / Home", parentName: "Technical Check", menuName: "Home" }));
TechnicalRoute.push(new CustomRouteConfig({ path: "back", title: "Technical Check", parentName: "Technical Check", menuName: "Back", redirectTo: "/technicalvendor" }));
TechnicalRoute.push(new CustomRouteConfig({ path: "legalVendorunassginedcases", componentName: LegalVendorPageComponent, title: "Technical Check / Legal Check", parentName: "Technical Check" }));
TechnicalRoute.push(new CustomRouteConfig({ path: "technicalVendorunassginedcases", componentName: TechnicalVendorPageComponent, title: "Technical Check / Legal Check", parentName: "Technical Check" }));

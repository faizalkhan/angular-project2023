import { CustomRouteConfig } from "src/app/shared/models/common/route-config";
import { OperationalQueriesScreenComponent } from "./operational-queries-screen/operational-queries-screen.component"; 


export const OPSQueriesModule = [OperationalQueriesScreenComponent]

export const OPSQueriesRoute: CustomRouteConfig[] = [];


//Parent Menu
OPSQueriesRoute.push(new CustomRouteConfig({ menuName: "Ops/RCU Query to Creditt",componentName: OperationalQueriesScreenComponent, title: "Ops/RCU Query to Credit", path: "opsrcuhome", redirectTo: "/opsrcuhome" }));

 
//Child menu
OPSQueriesRoute.push(new CustomRouteConfig({ path: "opsrcuhome", componentName: OperationalQueriesScreenComponent, title: "Ops-RCU Query to Credit / Home", parentName: "Ops/RCU Query to Credit", menuName: "Home" })); 
OPSQueriesRoute.push(new CustomRouteConfig({ path: "back", title: "Ops/RCU Query to Credit", parentName: "Ops/RCU Query to Credit", menuName: "Back", redirectTo: "/OpsRCUHome" }));
OPSQueriesRoute.push(new CustomRouteConfig({ path: "opsrcuscreen", componentName: OperationalQueriesScreenComponent, title: "OPS/RCU Queries", parentName: "Ops/RCU Query to Credit", menuName: "OPS/RCU Queries", }));
 
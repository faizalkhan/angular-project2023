import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OperationalQueriesScreenComponent } from './operational-queries-screen.component';

describe('OperationalQueriesScreenComponent', () => {
  let component: OperationalQueriesScreenComponent;
  let fixture: ComponentFixture<OperationalQueriesScreenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OperationalQueriesScreenComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OperationalQueriesScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

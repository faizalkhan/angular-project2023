import { formatNumber } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InfoServices } from 'src/app/Injectable/info.services';
import { NotificationService } from 'src/app/notification.service';
import { IDropdown } from 'src/app/shared/models/common/control.model';
import { headerModel } from 'src/app/shared/models/common/header-table';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
import { IOperationalQueries, IOperationalQueriesDashboard, OperationalQueries, OperationalQueriesDashboardModel, OPSRCUQueriesSearch, OPSRCUSubmitModel } from 'src/app/shared/models/OperationalQueries/OperationalQueries.model';
import { DocumentInfo } from 'src/app/shared/models/sanction/Legal/legalDashboard';
import { ISearch } from 'src/app/shared/models/sanction/search/search';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { SearchService } from 'src/app/shared/services/search/search.service';
import { FileUpload, IfileUpload, UploadViewDownloadService } from '../../layout/button/upload-view-download/upload-view-download.service';
import { MenuService } from '../../layout/header/menu-service.service';

import { MenuResponse } from '../../layout/login/login.service';
import { IInterActionDetail, InterActionDetail } from '../../riskcontrolunit/RCU.Model';

@Component({
  selector: 'app-operational-queries-screen',
  templateUrl: './operational-queries-screen.component.html',
  styleUrls: ['./operational-queries-screen.component.css']
})
export class OperationalQueriesScreenComponent implements OnInit {
  isEdit: boolean = true; 
  isDashboard:boolean=true;
  title: any = "Operational Queries"
  private _data: any[] = [];
  private _header: any[] = [];
  
  public get Data(): any[] {
    return this._data;
  }
  public set Data(value: any[]) {
    this._data = value;
  }
  public get Header(): any[] {
    return this._header;
  }
  public set Header(value: any[]) {
    this._header = value;
  }
  private _rcuQueriesModel: InterActionDetail[] = [];
  public get rcuQueriesModel(): InterActionDetail[]{
    return this._rcuQueriesModel;
  }

  public set rcuQueriesModel(value: InterActionDetail[]) {
    this._rcuQueriesModel =value ;
  } 

  private _selectedRow:OperationalQueriesDashboardModel= new OperationalQueriesDashboardModel();
  public get SelectedRow():OperationalQueriesDashboardModel{
     return this._selectedRow;
  }

  public set SelectedRow(value:OperationalQueriesDashboardModel){
    this._selectedRow=value;
  }

  private _OPSRCUSearch:OPSRCUQueriesSearch= new OPSRCUQueriesSearch();
  public get OPSRCUSearch():OPSRCUQueriesSearch{
     return this._OPSRCUSearch;
  }

  public set OPSRCUSearch(value:OPSRCUQueriesSearch){
    this._OPSRCUSearch=value;
  }

  private _queryDoc:DocumentInfo[]  =[];

  public get queryDoc():DocumentInfo[]{
    return this._queryDoc;
 }

 public set queryDoc(value:DocumentInfo[]){
   this._queryDoc=value;
 }

 private _OPSRCUSubmit:OPSRCUSubmitModel  = new OPSRCUSubmitModel();

  public get OPSRCUSubmit():OPSRCUSubmitModel{
    return this._OPSRCUSubmit;
 }

 public set OPSRCUSubmit(value:OPSRCUSubmitModel){
   this._OPSRCUSubmit=value;
 }

 recevier_Remarks:String="";
 uploadNotification:boolean=true;
 

 DocumentType: IDropdown[] = [];   
 recordCount:number=0;

  @Input() requestData: any;
  OperationalQueries: OperationalQueries[]=[];
  constructor(private http: ConfigService,private notify: NotificationService, 
    private _searchService: SearchService,private route: Router,private download: UploadViewDownloadService,
    private info: InfoServices,private menuService: MenuService) {

  }

  ngOnInit(): void {

    
    this._header = [
      new headerModel('loanAccountNumber', 'LAN Number'),
      new headerModel('name', 'Applicant Name'), 
      new headerModel('state', 'State'),
      new headerModel('executive_ID', 'MC Code'),
      new headerModel('executive_Name', 'MC Name'),
      new headerModel('mobileNo', 'Date of Sourcing of LAN'),
      new headerModel('dateOfQueryRaised', 'Date of Query Raised'),
      new headerModel('ageing', 'Ageing') 
    ];  
 
    if (!this._searchService.SearchData.observed) {
      this._searchService.SearchData.subscribe((res: ISearch) => { 
        this.OPSRCUSearch.fieldName=res.fieldName;
        this.OPSRCUSearch.fieldValue = res.fieldValue;
        this.OPSRCUSearch.fromDate=res.fromDate;
        this.OPSRCUSearch.toDate=res.toDate;
        this.OPSRCUSearch.screenType="";
        this.OPSRCUSearch.role=res.role;
        this.OPSRCUSearch.userID=res.login_PS_ID;

        this.GetOperationalQueries(this.OPSRCUSearch.toJson());
      });
    } else{
      this.GetOperationalQueries(this.OPSRCUSearch.toJson());
    }
  }

  onRadioChange(event:any,type:string){
    if(type==="RCU"){
      this.Data =[];
      this.OPSRCUSearch.screenType="RCU";
      this.GetOperationalQueries(this.OPSRCUSearch.toJson());
    }

    if(type==="OPS"){
      this.Data =[];
      this.OPSRCUSearch.screenType="OPS";
      this.GetOperationalQueries(this.OPSRCUSearch.toJson());
    }
  }

  GetOperationalQueries(param:any) {
      this.http.httpPost<IresponseModel<OperationalQueriesDashboardModel[]>>(param, 'LAP_GetOpsCreditInteractionDashboard').subscribe((res: IresponseModel<OperationalQueriesDashboardModel[]>) => {
        this.Data = res.creditInteractionDashboard.map((x: IOperationalQueriesDashboard) => {
          return new OperationalQueriesDashboardModel(x);
      }); 
      })
  }

  getQueries(param:any) {
    this.http.httpPost<IresponseModel<InterActionDetail[]>>(param, 'GetOpsCreditInteractionDtl').subscribe((res: IresponseModel<InterActionDetail[]>) => { 
        if( res!==null){ 
          this.notify.showSuccess("Queries retrived successfully", "Application"); 
          this.rcuQueriesModel = res.creditInteractionDtl.map((x: IInterActionDetail) => {
            return new InterActionDetail(x);
        });  
         
          this.recordCount = this.rcuQueriesModel.length === 0 ? 0 : this.rcuQueriesModel.length-1;
        } else{
          this.notify.showSuccess("Something went wrong", "Application");
        }
      });
    }

    removeDocument(event:any,index:number){
      this.queryDoc.splice(index,1);
    }

  row_click(event:any){
    this.SelectedRow = event;
   // this.route.navigateByUrl("/opsrcuscreen");
    this.loadPageData(); 
  }

  loadPageData(){
    this.isDashboard=false;
    this.menuService.IsShow = false;

    this.DocumentType = [
      { displayName: 'Select', selected: true, value: '' },
      { displayName: 'AADHAAR', selected: false, value: 'AADHAAR' }, 
      { displayName: 'NOC', selected: false, value: 'NOC_Doc' },
      { displayName: 'Non Agriculture form', selected: false, value: 'NONAgri_Doc' },
      { displayName: 'Mutation form', selected: false, value: 'Mutation_Doc' },
     ] 


    this.download.uploadLoad = new FileUpload({
      flO_Id: "",
      loanAccountNumber: this.SelectedRow.loanAccountNumber,
      moduleName: "Interaction - " + this.SelectedRow.source,
      applicationNo : this.SelectedRow.applicationNo,
      leadID:this.SelectedRow.leadId
  } as IfileUpload);

    var queriesParam ={
      "LoanAccountNumber" : this.SelectedRow.loanAccountNumber,
      "Source":this.SelectedRow.source
    }
    this.getQueries(queriesParam);

    if(this.SelectedRow.status==="Completed"){
     this.isEdit=false;
    }
  }

  documentTypeChange(event:any){
      let iCount=0;    
      let returnField:boolean=true;    

       this.queryDoc.forEach((item,index)=>{
      
         if(item.documentType===event.target.value){
          iCount = iCount+1; 
         } 

         if(iCount>1){ 
          this.notify.showWarning(this.queryDoc[index].documentType + " has been selected. Please select another document type");
          this.queryDoc[index].documentType=''; 
          event.target.value=''; 
          returnField = false;                    
         } 

       }) 
       return returnField;
  }

  addmore() {

    this.uploadNotification=false;
    //let returnField:boolean=true;

    if(this.queryDoc.length>=4){
      this.notify.showWarning("All file type has been selected");
      return false;
    }
     let uniqueNumber:number=1;
     let queryDocCount = this.queryDoc.length;
    if(this.rcuQueriesModel){
        uniqueNumber = this.rcuQueriesModel.length === 0 ?  4 : this.rcuQueriesModel.length*4;
    }
    let uniqueValue = uniqueNumber + queryDocCount;

    let docInfo = new DocumentInfo();
    docInfo.documentType="";
    docInfo.remark="";
    docInfo.uuid=""; 
    docInfo.uniqueId= uniqueValue.toString();  
    this.queryDoc.push(docInfo);   
    
    return true;
  }
  
  Submit(){

     if(!this.fnValidate()){
      return;
     }

     var loggedInUserRole = JSON.parse(this.info.getItem('menu')) as MenuResponse; 

     this.OPSRCUSubmit.loanAccountNumber=this.SelectedRow.loanAccountNumber;
     this.OPSRCUSubmit.receiver_Remarks = this.recevier_Remarks.toString();
     this.OPSRCUSubmit.source=this.SelectedRow.source;
     this.OPSRCUSubmit.status="Completed";
     this.OPSRCUSubmit.receiver_Role= loggedInUserRole.menuUserDetail.roleId;
     this.OPSRCUSubmit.receiver=loggedInUserRole.menuUserDetail.userId;
     
     if(this.queryDoc.length>0){
      this.queryDoc.forEach((item,index)=>{ 
         if(index==0){
            this.OPSRCUSubmit.receiverDoc1_UUID = item.uuid;
            this.OPSRCUSubmit.receiver_Doc1=item.documentType;
         }
         if(index==1){
          this.OPSRCUSubmit.receiverDoc2_UUID = item.uuid;
          this.OPSRCUSubmit.receiver_Doc2=item.documentType;
          }
        if(index==2){
          this.OPSRCUSubmit.receiverDoc3_UUID = item.uuid;
          this.OPSRCUSubmit.receiver_Doc3=item.documentType;
        }
        if(index==3){
          this.OPSRCUSubmit.receiverDoc4_UUID = item.uuid;
          this.OPSRCUSubmit.receiver_Doc4=item.documentType;
        } 
      });
     }

     this.http.httpPost(this.OPSRCUSubmit.toJSON(), 'OpsCreditInteractionDtl')
      .subscribe((res:any) => {
        if(res.errorcode!="E408"){
          this.notify.showSuccess("Data has been saved successfully","OPS/RCU Queries") 
          this.isEdit=false;
        }
        else{
          this.notify.showError("Something went wrong! Please try again later","OPS/RCU Queries")
        } 
      });

  }

  fnValidate(){
    if(this.queryDoc.length==0){
      return true;
    }

    if(this.recevier_Remarks===""){
      this.notify.showWarning("Please speicify the remarks");
      return false;
    }

    let isFound:boolean=true;
    this.queryDoc.forEach((item,index)=>{ 
      if(this.queryDoc[index].documentType === ""){ 
       this.notify.showWarning("Please select the document type"); 
       isFound =  false;                    
      } 

      if(this.queryDoc[index].uuid === ""){ 
        this.notify.showWarning("Please upload the document for this file type" + this.queryDoc[index].documentType); 
        isFound =  false;                    
       }  
    }) 
    return isFound;
  }
}

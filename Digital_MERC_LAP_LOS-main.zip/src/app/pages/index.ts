import { OperationalQueries } from '../shared/models/OperationalQueries/OperationalQueries.model';
import { DisbursementDetailsRoute } from './disbursementdetails';
import { LegalRoute } from './legal/index';
import { OPSQueriesModule, OPSQueriesRoute } from './OperationalQueries/index';
import { RiskControlUnitRoute } from './riskcontrolunit/index';
import { RMCDocumentRoute } from './rmcdocument';
import { SanctionRoute } from './sanction/index';
import { TechnicalRoute } from './technical/index';

export * from './sanction/index';
export * from './legal/index';
export * from './technical/index';
export * from './layout/index'
export * from './riskcontrolunit/index'; 
export * from './disbursementdetails/index';
export * from './OperationalQueries/index';
export * from './rmcdocument/index';


export const FinalRoute = [...SanctionRoute, ...LegalRoute, ...TechnicalRoute, ...RiskControlUnitRoute,
    ...DisbursementDetailsRoute,...OPSQueriesRoute,...RMCDocumentRoute]



import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LodReportComponent } from './lod-report.component';

describe('LodReportComponent', () => {
  let component: LodReportComponent;
  let fixture: ComponentFixture<LodReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LodReportComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LodReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

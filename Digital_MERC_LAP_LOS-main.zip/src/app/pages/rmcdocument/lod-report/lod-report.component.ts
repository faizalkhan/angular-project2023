import { Component, OnInit } from '@angular/core';
import { RMCApplicationDashboardModel, RMCDashboardSearch, RMCReport } from 'src/app/shared/models/RMC/dashboard';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { NotificationService } from 'src/app/notification.service';
import { FileUpload, IfileUpload, UploadViewDownloadService, Ifile } from '../../layout/button/upload-view-download/upload-view-download.service';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
@Component({
  selector: 'app-lod-report',
  templateUrl: './lod-report.component.html',
  styleUrls: ['./lod-report.component.css']
})
export class LodReportComponent implements OnInit {
  constructor(private http: ConfigService, private _notification: NotificationService, private downloadUpload: UploadViewDownloadService) { }
  LoanData: any = {};
  loanNumber: any = '';
  Status: any = true;
  ngOnInit(): void {
    this.getLoan();
  }

  getLoan() {
    var param = {
      "Login_PS_ID": "",
      "Role": ""
    }
    this.http.httpPost<RMCReport>(param, 'LAP_GetRMCReport').subscribe((res: RMCReport) => {
      this.LoanData = JSON.parse(res.content);
    });
  }

  PrintLOD(event: any) {
    if (this.loanNumber == "") {
      this._notification.showWarning("Please enter the loan account number");
    }
    else {
      let loanACNo = this.loanNumber
      var filterData = this.LoanData.filter(function (el: any) {
        return el["Loan AccountNumber"] == loanACNo
      });
      if (filterData.length > 0 && filterData[0]["Status"] == "Completed") {
        let data = {
          "DocType": "LAP_LOD",
          "LoanAccountNumber": this.loanNumber,
          "ApplicationNo": "",
          "FLO_PsId": ""
        }
        this.http.httpCommondownload<IresponseModel<any>>(data, 'LAP_GetDownloadDocs').subscribe((res: IresponseModel<any>) => {
          this.downloadUpload.downloadFile(res.PdfDoc, 'application/pdf', `${event}.pdf`);
          this._notification.showSuccess("Data Downloaded Successfully");
        });
      } else {
        this._notification.showWarning("No Data Found");
      }
    }
  }
}

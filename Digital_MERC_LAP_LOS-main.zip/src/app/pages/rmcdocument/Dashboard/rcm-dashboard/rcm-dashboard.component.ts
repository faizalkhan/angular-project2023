import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InfoServices } from 'src/app/Injectable/info.services';
import { MenuResponse } from 'src/app/pages/layout/login/login.service';
import { headerModel } from 'src/app/shared/models/common/header-table';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
import { RMCApplicationDashboardModel, RMCDashboardSearch, RMCReport } from 'src/app/shared/models/RMC/dashboard';
import { ISearch } from 'src/app/shared/models/sanction/search/search';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { SearchService } from 'src/app/shared/services/search/search.service';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-rcm-dashboard',
  templateUrl: './rcm-dashboard.component.html',
  styleUrls: ['./rcm-dashboard.component.css']
})
export class RcmDashboardComponent implements OnInit {

  private _data: any[] = [];
  
  public get Data(): any[] {
    return this._data;
  }
  public set Data(value: any[]) {
    this._data = value;
  }
  title: any = "RMC Dashboard"

  private _RMCSearch:RMCDashboardSearch= new RMCDashboardSearch();
  public get RMCSearch():RMCDashboardSearch{
     return this._RMCSearch;
  }

  public set RMCSearch(value:RMCDashboardSearch){
    this._RMCSearch=value;
  }
  userId:string='';
  roleName:string='';
  loanNumber:any='';
  rmcDashboard: boolean = true;
  lodReport: boolean = false;
  backBtn: boolean = false;

  constructor(private http: ConfigService, private Info: InfoServices, private route: Router, 
    private _searchService: SearchService ) { }

  public get Header(): headerModel[] {
    return [
      new headerModel('loanAccountNumber', 'Lan no.'),
      new headerModel('name', 'Name'), 
      new headerModel('state','State'),
      new headerModel('executive_ID','MC Code'),
      new headerModel('executive_Name', 'MC Name'),
      new headerModel('mobileNo', 'Mobile Number of Applicant'),
      //new headerModel('triggeredDate', 'Triggered Date'),
      new headerModel('ageing', 'Ageing'),
    ]
  }

  ngOnInit(): void {

    var loggedInUserRole = JSON.parse(this.Info.getItem('menu')) as MenuResponse; 
    this.userId=loggedInUserRole.menuUserDetail.userId;
    this.roleName=loggedInUserRole.menuUserDetail.roleId;
   
    var param ={        
          "Login_PS_ID": this.userId,
          "Role": this.roleName,
          "FromDate": "",
          "ToDate": "",
          "FieldName": "",
          "FieldValue": ""
      }

      if (!this._searchService.SearchData.observed) {
        this._searchService.SearchData.subscribe((res: ISearch) => {           
          this.RMCSearch.fieldName=res.fieldName;
          this.RMCSearch.fieldValue = res.fieldValue;
          this.RMCSearch.fromDate=res.fromDate;
          this.RMCSearch.toDate=res.toDate;
          //this.RMCSearch.screenType="";
          this.RMCSearch.role=res.role;
          this.RMCSearch.userID=res.login_PS_ID;
          this.getRMCDashboard(this.RMCSearch.toJson());
        });
      } 
      else{
         this.getRMCDashboard(param);
      }
  }

  getRMCDashboard(param:any){

    //9let item :RMCApplicationDashboardModel = new RMCApplicationDashboardModel();

    
    this.http.httpPost<IresponseModel<RMCApplicationDashboardModel[]>>(param, 'LAP_GetRMCDashboard').subscribe((res: IresponseModel<RMCApplicationDashboardModel[]>) => {
      this.Data = res.dashboardDetails;
    });
  }

  row_click(event: any): void {     
    this.Info.setItem("rmcLanInfo",event.loanAccountNumber);
    this.route.navigateByUrl("/rmcpending");
  }
   
  export(event:any){

    var param={
      "Login_PS_ID": this.userId,
      "Role": ""
    }

    // let content1:string = "[{\"LAN\":\"L08220000127\",\"Name\":\"ANDIBENDABHI\",\"MCCode\":\"MC513\",\"POD_Number\":0,\"POD_Date\":\"2022-12-13T05:57:51.953\",\"Barcode1\":\"<script>alert('xss')</script>\",\"Chain Document\":\"\",\"Date\":null,\"Legal Report\":\"NA\",\"MODT Document\":\"NA\",\"MODT No.\":null,\"Mutation Doc.\":\"NA\",\"Mutation\":null,\"Other Property Document\":\"NA\",\"Physical Mandate\":\"NA\",\"Place\":null,\"Poch(SPDC-3 & Physical Mandate)\":null,\"Property Tax Receipt\":\"NA\",\"Property Title Doc.\":\"NA\",\"SPDC-1\":\"NA\",\"SPDC-2\":\"NA\",\"SPDC-3\":\"NA\",\"Technical Report\":\"NA\"},{\"LAN\":\"L08220000131\",\"Name\":\"AmrutaAnandrao Gole\",\"MCCode\":\"MC513\",\"POD_Number\":0,\"POD_Date\":\"2022-12-13T04:58:04.74\",\"Barcode1\":\"\",\"Chain Document\":\"\",\"Date\":null,\"Legal Report\":\"NA\",\"MODT Document\":\"NA\",\"MODT No.\":null,\"Mutation Doc.\":\"NA\",\"Mutation\":null,\"Other Property Document\":\"NA\",\"Physical Mandate\":\"NA\",\"Place\":null,\"Poch(SPDC-3 & Physical Mandate)\":null,\"Property Tax Receipt\":\"NA\",\"Property Title Doc.\":\"NA\",\"SPDC-1\":\"NA\",\"SPDC-2\":\"NA\",\"SPDC-3\":\"NA\",\"Technical Report\":\"NA\"},{\"LAN\":\"L08220000132\",\"Name\":\"AmrutaAnandrao Gole\",\"MCCode\":\"MC513\",\"POD_Number\":123,\"POD_Date\":\"2022-12-12T08:27:08.317\",\"Barcode1\":\"666 777 888\",\"Chain Document\":\"555 444 222\",\"Date\":null,\"Legal Report\":\"NA\",\"MODT Document\":\"NA\",\"MODT No.\":null,\"Mutation Doc.\":\"No\",\"Mutation\":null,\"Other Property Document\":\"NA\",\"Physical Mandate\":\"NA\",\"Place\":null,\"Poch(SPDC-3 & Physical Mandate)\":null,\"Property Tax Receipt\":\"NA\",\"Property Title Doc.\":\"Yes\",\"SPDC-1\":\"NA\",\"SPDC-2\":\"NA\",\"SPDC-3\":\"NA\",\"Technical Report\":\"NA\"},{\"LAN\":\"L0822132456\",\"Name\":\"ApplicantA\",\"MCCode\":\"MC919\",\"POD_Number\":3223,\"POD_Date\":\"2022-10-17T15:20:21.077\",\"Barcode1\":\"323\",\"Chain Document\":\"2323\",\"Date\":\"NA\",\"Legal Report\":\"NA\",\"MODT Document\":\"NA\",\"MODT No.\":\"NA\",\"Mutation Doc.\":\"NA\",\"Mutation\":\"Yes\",\"Other Property Document\":\"NA\",\"Physical Mandate\":null,\"Place\":\"NA\",\"Poch(SPDC-3 & Physical Mandate)\":\"No\",\"Property Tax Receipt\":\"NA\",\"Property Title Doc.\":\"Yes\",\"SPDC-1\":null,\"SPDC-2\":null,\"SPDC-3\":null,\"Technical Report\":\"No\"},{\"LAN\":\"L0822132459\",\"Name\":\"AmrutaL\",\"MCCode\":\"MC919\",\"POD_Number\":0,\"POD_Date\":\"2022-12-13T05:35:44.183\",\"Barcode1\":\"＜script ＞alert(document.cookie)＜/script＞\",\"Chain Document\":\"\",\"Date\":null,\"Legal Report\":\"NA\",\"MODT Document\":\"NA\",\"MODT No.\":null,\"Mutation Doc.\":\"NA\",\"Mutation\":null,\"Other Property Document\":\"NA\",\"Physical Mandate\":\"NA\",\"Place\":null,\"Poch(SPDC-3 & Physical Mandate)\":null,\"Property Tax Receipt\":\"NA\",\"Property Title Doc.\":\"NA\",\"SPDC-1\":\"NA\",\"SPDC-2\":\"NA\",\"SPDC-3\":\"NA\",\"Technical Report\":\"NA\"},{\"LAN\":\"L0922000005\",\"Name\":\"AmrutaAnandrao Gole\",\"MCCode\":\"MC513\",\"POD_Number\":0,\"POD_Date\":\"2022-12-13T05:32:16.777\",\"Barcode1\":\"\",\"Chain Document\":\"<script>alert('xss')</script>\",\"Date\":null,\"Legal Report\":\"NA\",\"MODT Document\":\"NA\",\"MODT No.\":null,\"Mutation Doc.\":\"NA\",\"Mutation\":null,\"Other Property Document\":\"NA\",\"Physical Mandate\":\"NA\",\"Place\":null,\"Poch(SPDC-3 & Physical Mandate)\":null,\"Property Tax Receipt\":\"NA\",\"Property Title Doc.\":\"NA\",\"SPDC-1\":\"NA\",\"SPDC-2\":\"NA\",\"SPDC-3\":\"NA\",\"Technical Report\":\"NA\"},{\"LAN\":\"L09221000001\",\"Name\":\"Amruta\",\"MCCode\":\"MC513\",\"POD_Number\":78545,\"POD_Date\":\"2022-12-09T06:24:31.787\",\"Barcode1\":\"test\",\"Chain Document\":\"Test001\",\"Date\":null,\"Legal Report\":\"NA\",\"MODT Document\":\"NA\",\"MODT No.\":null,\"Mutation Doc.\":\"NA\",\"Mutation\":null,\"Other Property Document\":\"NA\",\"Physical Mandate\":\"No\",\"Place\":null,\"Poch(SPDC-3 & Physical Mandate)\":null,\"Property Tax Receipt\":\"NA\",\"Property Title Doc.\":\"NA\",\"SPDC-1\":\"NA\",\"SPDC-2\":\"Yes\",\"SPDC-3\":\"NA\",\"Technical Report\":\"NA\"},{\"LAN\":\"L09221000003\",\"Name\":\"AmrutaAnandrao Gole\",\"MCCode\":\"MC513\",\"POD_Number\":0,\"POD_Date\":\"2022-12-13T05:31:24.1\",\"Barcode1\":\"<script>alert('xss')</script>\",\"Chain Document\":\"\",\"Date\":null,\"Legal Report\":\"NA\",\"MODT Document\":\"NA\",\"MODT No.\":null,\"Mutation Doc.\":\"NA\",\"Mutation\":null,\"Other Property Document\":\"NA\",\"Physical Mandate\":\"NA\",\"Place\":null,\"Poch(SPDC-3 & Physical Mandate)\":null,\"Property Tax Receipt\":\"NA\",\"Property Title Doc.\":\"NA\",\"SPDC-1\":\"NA\",\"SPDC-2\":\"NA\",\"SPDC-3\":\"NA\",\"Technical Report\":\"NA\"},{\"LAN\":\"L1222000791\",\"Name\":\"AshwiniRajesh Damle\",\"MCCode\":\"MC1244\",\"POD_Number\":0,\"POD_Date\":\"2022-12-13T05:57:18.57\",\"Barcode1\":\"<script>alert('xss')</script>\",\"Chain Document\":\"\",\"Date\":null,\"Legal Report\":\"NA\",\"MODT Document\":\"NA\",\"MODT No.\":null,\"Mutation Doc.\":\"NA\",\"Mutation\":null,\"Other Property Document\":\"NA\",\"Physical Mandate\":\"NA\",\"Place\":null,\"Poch(SPDC-3 & Physical Mandate)\":null,\"Property Tax Receipt\":\"NA\",\"Property Title Doc.\":\"NA\",\"SPDC-1\":\"NA\",\"SPDC-2\":\"NA\",\"SPDC-3\":\"NA\",\"Technical Report\":\"NA\"}]";

    // import("xlsx").then(xlsx => {
    //   const worksheet = xlsx.utils.json_to_sheet(JSON.parse(content1)); 
    //   const workbook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    //   const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
    //   this.saveAsExcelFile(excelBuffer, "RCU_Report");
    //   });

    this.http.httpPost<RMCReport>(param, 'LAP_GetRMCReport').subscribe((res: RMCReport) => {
      //this.Data = res.content; 
      import("xlsx").then(xlsx => {
        const worksheet = xlsx.utils.json_to_sheet(JSON.parse(res.content));  
        const workbook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
        const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
        this.saveAsExcelFile(excelBuffer, "RCU_Report");
        });

     });
  }

  

  saveAsExcelFile(buffer: any, fileName: string): void { 
      let EXCEL_TYPE =
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
      let EXCEL_EXTENSION = ".xlsx";
      const data: Blob = new Blob([buffer], {
        type: EXCEL_TYPE
      });

      saveAs.saveAs(
        data,
        fileName + "_export_" + new Date().getTime() + EXCEL_EXTENSION
      ); 
  } 
  
  backLOD() {
    this.lodReport = false;
    this.backBtn = false;
    this.rmcDashboard = true;
  }
  PrintLOD(event:any) {
    this.lodReport = true;
    this.backBtn = true;
    this.rmcDashboard = false;
  }
}

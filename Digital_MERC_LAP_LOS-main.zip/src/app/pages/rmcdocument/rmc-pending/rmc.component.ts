import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { InfoServices } from "src/app/Injectable/info.services";
import { NotificationService } from "src/app/notification.service";
import { headerModel } from "src/app/shared/models/common/header-table";
import { IresponseModel } from "src/app/shared/models/common/response.model";
import { RMCApplicationDashboardModel, RMCApplicationModel, RMCDocumentInfo } from "src/app/shared/models/RMC/dashboard"; 
import { ISearch } from "src/app/shared/models/sanction/search/search";
import { ConfigService } from "src/app/shared/services/common/http.services";
import { SearchService } from "src/app/shared/services/search/search.service";
import { MenuService } from "../../layout/header/menu-service.service";
import { MenuResponse } from "../../layout/login/login.service";

@Component({
    selector: "app-dishome",
    templateUrl: "./rmc.component.html",
    styleUrls: ["./rmc.component.css"],
    providers: [ConfigService]
})
export class RMCDocumentComponent implements OnInit {

    
    isDashboard: Boolean = false; 
    hideDiscrepancy:boolean=true;    
    currentDateTime: any = new Date();
    RMCData:RMCApplicationModel=new RMCApplicationModel();
    isEdit:boolean=true;
    userId:string='';
    roleName:string='';
    rmcSelectedrow:string='';

    constructor(private http: ConfigService, private Info: InfoServices, private route: Router,
      private menuServie:MenuService,private notify:NotificationService) { 
    }

    ngOnInit(): void {
      this.rmcSelectedrow  = this.Info.getItem("rmcLanInfo");
      this.Info.removeItem("rmcLanInfo");
      var loggedInUserRole = JSON.parse(this.Info.getItem('menu')) as MenuResponse; 
      this.userId=loggedInUserRole.menuUserDetail.userId;
      this.roleName=loggedInUserRole.menuUserDetail.roleName;      
      this.RMCData.rmcData.lan = this.rmcSelectedrow;
      this.RMCData.rmcData.userID = loggedInUserRole.menuUserDetail.userId;
      this.RMCData.rmcData.barcode_File= '';
      this.RMCData.rmcData.barcode_Pouch= '';
      this.RMCData.rmcData.poD_Number= 0;
      this.RMCData.rmcData.poD_Date= new Date();
      this.RMCData.rmcData.createdBy= '';
      this.RMCData.rmcData.createdOn= new Date();
      this.RMCData.rmcData.modifiedBy= '';
      this.RMCData.rmcData.modifiedOn= new Date();
      this.RMCData.rmcData.courierName= '';
      this.RMCData.rmcData.courierDate=  new Date('');;
      this.RMCData.rmcData.officeBoyName= '';
      this.RMCData.rmcData.officeBoyMobileNo= '';
      this.RMCData.rmcData.status= 'Completed';
      let docDetail =   new RMCDocumentInfo();
      docDetail.id=1;
      docDetail.lan = this.rmcSelectedrow;
      docDetail.docType= 'Property Title Doc.';
      docDetail.doc_Source= 'RMC';
      docDetail.imgData= '';
      docDetail.uuid=  '';
      docDetail.remark= '';
      docDetail.createdBy= '';
      docDetail.createdOn= new Date();
      docDetail.modifiedBy= '';
      docDetail.modifiedOn= new Date();  
      this.RMCData.docs.push(docDetail);

      docDetail =   new RMCDocumentInfo();
      docDetail.id=2;
      docDetail.lan = this.rmcSelectedrow;
      docDetail.docType= 'Mutation Doc.';
      docDetail.doc_Source= 'RMC';
      docDetail.imgData= '';
      docDetail.uuid=  '';
      docDetail.remark= '';
      docDetail.createdBy= '';
      docDetail.createdOn= new Date();
      docDetail.modifiedBy= '';
      docDetail.modifiedOn= new Date(); 
      this.RMCData.docs.push(docDetail);

      docDetail =   new RMCDocumentInfo();
      docDetail.id=3;
      docDetail.lan = this.rmcSelectedrow;
      docDetail.docType= 'Property Tax Receipt';
      docDetail.doc_Source= 'RMC';
      docDetail.imgData= '';
      docDetail.uuid=  '';
      docDetail.remark= '';
      docDetail.createdBy= '';
      docDetail.createdOn= new Date();
      docDetail.modifiedBy= '';
      docDetail.modifiedOn= new Date();  
      this.RMCData.docs.push(docDetail);

      docDetail =   new RMCDocumentInfo();
      docDetail.id=4;
      docDetail.lan = this.rmcSelectedrow;
      docDetail.docType= 'Chain Document';
      docDetail.doc_Source= 'RMC';
      docDetail.imgData= '';
      docDetail.uuid=  '';
      docDetail.remark= '';
      docDetail.createdBy= '';
      docDetail.createdOn= new Date();
      docDetail.modifiedBy= '';
      docDetail.modifiedOn= new Date();
      this.RMCData.docs.push(docDetail);
      
      docDetail =   new RMCDocumentInfo();
      docDetail.id=5;
      docDetail.lan = this.rmcSelectedrow;
      docDetail.docType= 'Other Property Document';
      docDetail.doc_Source= 'RMC';
      docDetail.imgData= '';
      docDetail.uuid=  '';
      docDetail.remark= '';
      docDetail.createdBy= '';
      docDetail.createdOn= new Date();
      docDetail.modifiedBy= '';
      docDetail.modifiedOn= new Date();
      this.RMCData.docs.push(docDetail);
     
      docDetail =   new RMCDocumentInfo();
      docDetail.id=6;
      docDetail.lan = this.rmcSelectedrow;
      docDetail.docType= 'Legal Report';
      docDetail.doc_Source= 'RMC';
      docDetail.imgData= '';
      docDetail.uuid=  '';
      docDetail.remark= '';
      docDetail.createdBy= '';
      docDetail.createdOn= new Date();
      docDetail.modifiedBy= '';
      docDetail.modifiedOn= new Date();   
      this.RMCData.docs.push(docDetail);
   
      docDetail =   new RMCDocumentInfo();
      docDetail.id=7;
      docDetail.lan = this.rmcSelectedrow;
      docDetail.docType= 'Technical Report';
      docDetail.doc_Source= 'RMC';
      docDetail.imgData= '';
      docDetail.uuid=  '';
      docDetail.remark= '';
      docDetail.createdBy= '';
      docDetail.createdOn= new Date();
      docDetail.modifiedBy= '';
      docDetail.modifiedOn= new Date();  
      this.RMCData.docs.push(docDetail);

      docDetail =   new RMCDocumentInfo();
      docDetail.id=8;
      docDetail.lan = this.rmcSelectedrow;
      docDetail.docType= 'MODT Document';
      docDetail.doc_Source= 'RMC';
      docDetail.imgData= '';
      docDetail.uuid=  '';
      docDetail.remark= '';
      docDetail.createdBy= '';
      docDetail.createdOn= new Date();
      docDetail.modifiedBy= '';
      docDetail.modifiedOn= new Date(); 
      this.RMCData.docs.push(docDetail);

      docDetail =   new RMCDocumentInfo();
      docDetail.id=9;
      docDetail.lan = this.rmcSelectedrow;
      docDetail.docType= 'SPDC-1';
      docDetail.doc_Source= 'RMC';
      docDetail.imgData= '';
      docDetail.uuid=  '';
      docDetail.remark= '';
      docDetail.createdBy= '';
      docDetail.createdOn= new Date();
      docDetail.modifiedBy= '';
      docDetail.modifiedOn= new Date();   
      this.RMCData.docs.push(docDetail);

      docDetail =   new RMCDocumentInfo();
      docDetail.id=10;
      docDetail.lan = this.rmcSelectedrow;
      docDetail.docType= 'SPDC-2';
      docDetail.doc_Source= 'RMC';
      docDetail.imgData= '';
      docDetail.uuid=  '';
      docDetail.remark= '';
      docDetail.createdBy= '';
      docDetail.createdOn= new Date();
      docDetail.modifiedBy= '';
      docDetail.modifiedOn= new Date();   
      this.RMCData.docs.push(docDetail);

      docDetail =   new RMCDocumentInfo();
      docDetail.id=11;
      docDetail.lan = this.rmcSelectedrow;
      docDetail.docType= 'SPDC-3';
      docDetail.doc_Source= 'RMC';
      docDetail.imgData= '';
      docDetail.uuid=  '';
      docDetail.remark= '';
      docDetail.createdBy= '';
      docDetail.createdOn= new Date();
      docDetail.modifiedBy= '';
      docDetail.modifiedOn= new Date();
      this.RMCData.docs.push(docDetail);

      docDetail =   new RMCDocumentInfo();
      docDetail.id=12;
      docDetail.lan = this.rmcSelectedrow;
      docDetail.docType= 'Physical Mandate';
      docDetail.doc_Source= 'RMC';
      docDetail.imgData= '';
      docDetail.uuid=  '';
      docDetail.remark= '';
      docDetail.createdBy= '';
      docDetail.createdOn= new Date();
      docDetail.modifiedBy= '';
      docDetail.modifiedOn= new Date();     
      this.RMCData.docs.push(docDetail);


      if(this.rmcSelectedrow===""){
        this.isEdit=false;
      } 
      
    }

  //   GetApplicationStatus() {

  //     var param ={
  //         "CaseType": "",
  //         "FieldName": "",
  //         "FieldValue": "",
  //         "FLO_PsId": "20133106",
  //         "FromDate": "2022-08-04",
  //         "RoleName": "BCM",
  //         "ToDate": "2022-08-04"
  //       }

  // }

  
  
    // row_click(event: any): void {
    //   this.isDashboard = false;
    //   alert(JSON.stringify(event));
    //  }
     
    radiChange(event:any,Id:number){    
        
      this.RMCData.docs.forEach((val, index) => {
        if(val.id===Id){
          val.remark = event.target.value; 
        }     
      })
    }

    fnValidate(){
      this.RMCData.docs.forEach((value) => {
        if(value.docType == "Property Title Doc." && value.remark == "") {
          this.RMCData.invalidPropertyDocEntry = true;
        } else if(value.docType == "Mutation Doc." && value.remark == "") {
          this.RMCData.invalidMutationDocEntry = true;
        } else if(value.docType == "Property Tax Receipt" && value.remark == "") {
          this.RMCData.invalidPropertyTaxRecDocEntry = true;
        } else if(value.docType == "Chain Document" && value.remark == ""){
          this.RMCData.invalidChainDocDocEntry = true;
        }  else if(value.docType == "Other Property Document" && value.remark == ""){
          this.RMCData.invalidOtherPropertyDocEntry = true;
        }  else if(value.docType == "Legal Report" && value.remark == ""){
          this.RMCData.invalidLegalReportDocEntry = true;
        }  else if(value.docType == "Technical Report" && value.remark == ""){
          this.RMCData.invalidTechnicalReportDocEntry = true;
        }  else if(value.docType == "MODT Document" && value.remark == ""){
          this.RMCData.invalidMODTDocEntry = true;
        }  else if(value.docType == "SPDC-1" && value.remark == ""){
          this.RMCData.invalidSPDC1DocEntry = true;
        }  else if(value.docType == "SPDC-2" && value.remark == ""){
          this.RMCData.invalidSPDC2DocEntry = true;
        }  else if(value.docType == "SPDC-3" && value.remark == ""){
          this.RMCData.invalidSPDC3DocEntry = true;
        }  else if(value.docType == "Physical Mandate" && value.remark == ""){
          this.RMCData.invalidPhysicalMandateDocEntry = true;
        }
      });

      if(this.RMCData.invalidPropertyDocEntry) {
        this.notify.showWarning("Please select the Property Title Doc.");
        this.RMCData.invalidPropertyDocEntry = false;
        return false;
      }
      if(this.RMCData.invalidMutationDocEntry) {
        this.notify.showWarning("Please select the Mutation Doc.");
        this.RMCData.invalidMutationDocEntry = false;
        return false;
      }
      if(this.RMCData.invalidPropertyTaxRecDocEntry) {
        this.notify.showWarning("Please select the Property Tax Receipt Doc.");
        this.RMCData.invalidPropertyTaxRecDocEntry = false;
        return false;
      }
      if(this.RMCData.invalidChainDocDocEntry) {
        this.notify.showWarning("Please select the Chain Document Doc.");
        this.RMCData.invalidChainDocDocEntry = false;
        return false;
      }
      if(this.RMCData.invalidOtherPropertyDocEntry) {
        this.notify.showWarning("Please select the Other Property Document Doc.");
        this.RMCData.invalidOtherPropertyDocEntry = false;
        return false;
      }
      if(this.RMCData.invalidLegalReportDocEntry) {
        this.notify.showWarning("Please select the Legal Report Doc.");
        this.RMCData.invalidLegalReportDocEntry = false;
        return false;
      }
      if(this.RMCData.invalidTechnicalReportDocEntry) {
        this.notify.showWarning("Please select the Technical Report Doc.");
        this.RMCData.invalidTechnicalReportDocEntry = false;
        return false;
      }
      if(this.RMCData.invalidMODTDocEntry) {
        this.notify.showWarning("Please select the MODT Document Doc.");
        this.RMCData.invalidMODTDocEntry = false;
        return false;
      }
      if(this.RMCData.invalidSPDC1DocEntry) {
        this.notify.showWarning("Please select the SPDC-1 Doc.");
        this.RMCData.invalidSPDC1DocEntry = false;
        return false;
      }
      if(this.RMCData.invalidSPDC2DocEntry) {
        this.notify.showWarning("Please select the SPDC-2 Doc.");
        this.RMCData.invalidSPDC2DocEntry = false;
        return false;
      }
      if(this.RMCData.invalidSPDC3DocEntry) {
        this.notify.showWarning("Please select the SPDC-3 Doc.");
        this.RMCData.invalidSPDC3DocEntry = false;
        return false;
      }
      if(this.RMCData.invalidPhysicalMandateDocEntry) {
        this.notify.showWarning("Please select the Physical Mandate Doc.");
        this.RMCData.invalidPhysicalMandateDocEntry = false;
        return false;
      }

      if(this.RMCData.rmcData.barcode_File===""){
        this.notify.showWarning("Please specify the file barcode","RMC");
        return false;
      }

      if(this.RMCData.rmcData.barcode_Pouch===""){
        this.notify.showWarning("Please specify the pouch barcode","RMC");
        return false;
      }

      if(this.RMCData.rmcData.poD_Number===0){
        this.notify.showWarning("Please specify the POD number","RMC");
        return false;
      }

      if(this.RMCData.rmcData.courierName===""){
        this.notify.showWarning("Please specify the courier name","RMC");
        return false;
      }

      if(this.RMCData.rmcData.courierDate===null){
        this.notify.showWarning("Please specify the courier date","RMC");
        return false;
      }

      if(this.RMCData.rmcData.courierDate.toString()==="Invalid Date"){
        this.notify.showWarning("Please specify the courier date","RMC");
        return false;
      }

      return true;
    }

    SubmitRMC(){
     if(!this.fnValidate()){
        return;
      }

      this.http.httpPost(this.RMCData, 'LAP_RMCSubmitDocs').subscribe((res:any) => {

        if(res.errorcode==="200"){
          this.notify.showSuccess("Data Updated Successfully","RMC");
          this.isEdit=false;
          this.rmcSelectedrow="";
        }else{
          this.notify.showError("Something went wrong","RMC");
        } 
      })
    }

    keyPressAlphaNumeric(event:any) { 
      var inp = String.fromCharCode(event.keyCode);
      var regex = new RegExp("^[a-zA-Z0-9 ]+$");
      if (regex.test(inp)) {
        return true;
      }

    // e.preventDefault();
    // return false;
    //   if (/[a-zA-Z0-9]/.test(inp)) {
    //     return true;
    //   } else {
        event.preventDefault();
        return false;
      //}
    }

    onPaste(event:any) {
      event.preventDefault();
      return false;
    }
}
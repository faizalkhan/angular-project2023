import { CustomRouteConfig } from "src/app/shared/models/common/route-config"; 

import { RcmDashboardComponent } from "./Dashboard/rcm-dashboard/rcm-dashboard.component";
import { LodReportComponent } from "./lod-report/lod-report.component";
import { RMCDocumentComponent } from "./rmc-pending/rmc.component";
 
// import {RegisterEnachComponent } from "src/app/pages/disbursementdetails/register-enach/register-enach.component";

export const RMCDocumentModule = [RMCDocumentComponent,RcmDashboardComponent,LodReportComponent]
export const RMCDocumentRoute: CustomRouteConfig[] = [];

RMCDocumentRoute.push(new CustomRouteConfig({ menuName: "RMC Details", componentName: RcmDashboardComponent, title: "RMC Details", path: "rmchome", redirectTo: "/rmcdash" }))
 
//child menu
RMCDocumentRoute.push(new CustomRouteConfig({ path: "rmchome", componentName: RcmDashboardComponent, title: "RMC Details / Home", parentName: "RMC Details", menuName: "Home" }));
RMCDocumentRoute.push(new CustomRouteConfig({ path: "rmcdash", componentName: RcmDashboardComponent, title: "RMC Details / Home", parentName: "RMC Details", menuName: "Home" }));
RMCDocumentRoute.push(new CustomRouteConfig({ path: "rmcback", title: "RMC Details / Back", parentName: "RMC Details", redirectTo: "/rmchome", menuName: "Back" }));
RMCDocumentRoute.push(new CustomRouteConfig({ path: "rmcpending", componentName: RMCDocumentComponent, title: "RMC Details / Pending", parentName: "RMC Details", menuName: "Pending For Action" }));
RMCDocumentRoute.push(new CustomRouteConfig({ path: "lodreport", componentName: LodReportComponent, title: "RMC Details-Pending", parentName: "RMC Details", menuName: "Print LOD" }));
// RMCDocumentRoute.push(new CustomRouteConfig({ path: "closedcases", compoentName: MakerCheckerClosedCasesComponent, title: "RMC Details / Pending", parentName: "RMC Details", menuName: "Closed Cases"}));

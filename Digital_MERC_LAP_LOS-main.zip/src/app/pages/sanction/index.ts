import { IncomeAssessmentComponent } from '../sanction/income-assessment/incomeassessment.component';
import { BusinessDetailsComponent } from '../sanction/business-details/businessdetails.component';
import { IncomeEligibilityComponent } from '../sanction/income-eligibility/incomeeligibility.component';
import { SanctionDashComponent } from '../sanction/dashboard/sanctiondash.component';
import { HouseholdAssessmentComponent } from './household-assessment/household-assessment.component';
import { BankAssessmentComponent } from './banking-assessment/bankingassessment.component';
import { SanctionHomeComponent } from './home/home.component';
import { CustomRouteConfig } from 'src/app/shared/models/common/route-config';
import { PersonalDetailComponent } from './personal-details/personaldetail.component';

import { PropertyValuationComponent } from './propertyvaluations/propertyvaluations.component';
import { STechnicalPage1Component } from './technical/page1/page1.component';
import { SLegalPage1Component } from './legal/page1/page1.component';
import { STechnicalDashboardComponent } from './technical/dashboard/dashboard.component';
import { SLegalDashboardComponent } from './legal/dashboard/dashboard.component';
import { LegalCommonComponent } from './Common/legal-common/legal-common.component';
import { TechnicalCommonComponent } from './Common/technical-common/technical-common.component';
import { LegalVendorPageComponent } from '../legal/legal-vendor-page/legal-vendor-page.component';
import { TechnicalVendorPageComponent } from '../technical/technical-vendor-page/technical-vendor-page.component';
import { TechnicalVendorCommonComponent } from './Common/technical-vendor-common/technical-vendor-common.component';

import { ReferenceCheckComponent } from './reference-check/referencecheck.component';
import { SLegalPage2Component } from './legal/page2/page2.component';
import { SLegalPage3Component } from './legal/page3/page3.component';
import { STechnicalPage2Component } from './technical/page2/page2.component';
import { STechnicalPage3Component } from './technical/page3/page3.component';
import { CamDetailsComponent } from './cam-details/camdetails.component';
import { BankCalculatorComponent } from './banking-calculator/bankingcalculator.component';
import { ObligationFormComponent } from './obligation-form/obligation-form.component';
import { ListComponent } from './obligation-form/list/list.component';


export const SanctionModule =
    [
      
        SanctionDashComponent,
        IncomeAssessmentComponent,
        BusinessDetailsComponent,
        IncomeEligibilityComponent,
        HouseholdAssessmentComponent,
        BankCalculatorComponent,
        SanctionHomeComponent,
        PersonalDetailComponent,
        PropertyValuationComponent,
        STechnicalPage1Component,
        SLegalPage1Component,
        STechnicalDashboardComponent,
        SLegalDashboardComponent,
        LegalCommonComponent,
        TechnicalCommonComponent,
        LegalVendorPageComponent,
        TechnicalVendorPageComponent,
        TechnicalVendorCommonComponent,
        ReferenceCheckComponent,
        STechnicalPage2Component,
        SLegalPage2Component,
        CamDetailsComponent,
        BankCalculatorComponent,
        ObligationFormComponent,ListComponent
    ];

export const SanctionRoute: CustomRouteConfig[] = [];
//Parent Menu
SanctionRoute.push(new CustomRouteConfig({ menuName: "Credit Sanction", title: "Credit Sanction", path: "sanction", redirectTo: "/sanctiondash", isActive: true }));
SanctionRoute.push(new CustomRouteConfig({ path: "sanctiondash", componentName: SanctionDashComponent, title: "Credit Sanction / Dashboard", parentName: "Credit Sanction" }));

//Child menu
SanctionRoute.push(new CustomRouteConfig({ path: "home", componentName: SanctionHomeComponent, title: "Credit Sanction / Home", parentName: "Credit Sanction", menuName: "Home" }));
SanctionRoute.push(new CustomRouteConfig({ path: "back to Dashboard", title: "Credit Sanction", parentName: "Credit Sanction", menuName: "Back", redirectTo: "/sanctiondash" }));
SanctionRoute.push(new CustomRouteConfig({ path: "perosnal", componentName: PersonalDetailComponent, title: "Credit Sanction / Personal Info", parentName: "Credit Sanction", menuName: "Personal Details" }));
SanctionRoute.push(new CustomRouteConfig({ path: "business", componentName: BusinessDetailsComponent, title: "Credit Sanction / Business Info", parentName: "Credit Sanction", menuName: "Business Details" }));
SanctionRoute.push(new CustomRouteConfig({ path: "reference", componentName: ReferenceCheckComponent, title: "Credit Sanction / Reference Info", parentName: "Credit Sanction", menuName: "Reference Details" }));
SanctionRoute.push(new CustomRouteConfig({ path: "householdassessment", componentName: HouseholdAssessmentComponent, title: "Credit Sanction / Household Assessment", parentName: "Credit Sanction", menuName: "Household Assessment" }));
SanctionRoute.push(new CustomRouteConfig({ path: "incomeassessment", componentName: IncomeAssessmentComponent, title: "Credit Sanction / Income Assessment", parentName: "Credit Sanction", menuName: "Income Assessment" }));
SanctionRoute.push(new CustomRouteConfig({ path: "propertyvaluation", componentName: PropertyValuationComponent, title: "Credit Sanction / Property Valuation", parentName: "Credit Sanction", menuName: "Property Valuation" }));
SanctionRoute.push(new CustomRouteConfig({ path: "bankingassessment", componentName: BankCalculatorComponent, title: "Credit Sanction / Banking Assessment", parentName: "Credit Sanction", menuName: "Banking Assessment" }));
SanctionRoute.push(new CustomRouteConfig({ path: "legalcheck", componentName: SLegalPage1Component, title: "Credit Sanction / Legal Check", parentName: "Credit Sanction" }));
SanctionRoute.push(new CustomRouteConfig({ path: "technicalcheck", componentName: STechnicalPage1Component, title: "Credit Sanction / Technical Check", parentName: "Credit Sanction" }));
SanctionRoute.push(new CustomRouteConfig({ path: "incomeeligibility", componentName: IncomeEligibilityComponent, title: "Credit Sanction / Income Eligibility", parentName: "Credit Sanction", menuName: "Income Eligibility" }));
SanctionRoute.push(new CustomRouteConfig({ path: "camdetail", componentName: CamDetailsComponent, title: "Credit Sanction / CAM Details", parentName: "Credit Sanction", menuName: "CAM Detail" }));
SanctionRoute.push(new CustomRouteConfig({ path: "legalinprograsswithvendor", componentName: SLegalPage2Component, title: "Credit Sanction / Legal Check", parentName: "Credit Sanction" }));
SanctionRoute.push(new CustomRouteConfig({ path: "legalapprovedrejectedcases", componentName: SLegalPage3Component, title: "Credit Sanction / Legal Check", parentName: "Credit Sanction" }));
SanctionRoute.push(new CustomRouteConfig({ path: "techunassginedcases", componentName: SLegalPage1Component, title: "Credit Sanction / Legal Check", parentName: "Credit Sanction" }));
SanctionRoute.push(new CustomRouteConfig({ path: "techinprograsswithvendor", componentName: STechnicalPage2Component, title: "Credit Sanction / Legal Check", parentName: "Credit Sanction" }));
SanctionRoute.push(new CustomRouteConfig({ path: "techapprovedrejectedcases", componentName: STechnicalPage3Component, title: "Credit Sanction / Legal Check", parentName: "Credit Sanction" }));
SanctionRoute.push(new CustomRouteConfig({ path: "ObligationList", componentName: ListComponent, title: "Credit Sanction / Obligation", parentName: "Credit Sanction", menuName: "Obligation" }));
import { Component } from '@angular/core';
import { ActivatedRoute } from "@angular/router";

@Component({
    selector: "app-slegalpage2",
    templateUrl: "./page2.component.html",
    styleUrls: ["./page2.component.css"]
})
export class SLegalPage2Component {
    applications =
        {
            applicantName: 'ILAP345331', contactNo: 'Deepak Sahu', district: 'Pending', State: 'Approved', pincode: 'Approved', loginDate: 'Approved',
            product: 'test', schema: 'test', branchName: 'test', appliedTenure: 'test', appliedLoadAmount: '222'
        }

    audittrails = [
        { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
        { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
        { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
        { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
    ];

    docrows: any = [{ docname: '', doctype: '', filename: '', remarks: '' }]

    addmore() {
        let row = { docname: '', doctype: '', filename: '', remarks: '' }
        this.docrows.push(row);
    }
}


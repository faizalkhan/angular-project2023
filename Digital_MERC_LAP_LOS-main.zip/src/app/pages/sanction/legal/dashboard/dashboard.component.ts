import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";
import { InfoServices } from 'src/app/Injectable/info.services';
import { ILegalDashboardResponseModel } from 'src/app/shared/models/common/response.model';
import { LegalDashboardModel } from 'src/app/shared/models/sanction/Legal/legalDashboard';
import { ISearch } from 'src/app/shared/models/sanction/search/search';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { SearchService } from 'src/app/shared/services/search/search.service';

@Component({
    selector: "app-legaldashboard",
    templateUrl: "./dashboard.component.html",
    styleUrls: ["./dashboard.component.css"],
    providers:[ConfigService]
})



export class SLegalDashboardComponent implements OnInit {

    title: any = "Legal Dashboard"
    param: any;
    ResponseData:any;
    @Input() Title_1:any;
    private _data: SLegalDashboardComponent[] = [];
     

    applications = [
        { lanid: 'ILAP345331', primaryApplicantName: 'Deepak Sahu', loanType: 'LAP', mcCode: 'Shinish Bharadwaraj', caseStatus: 'Unassigned Cases' },
        { lanid: 'ILAP345332', primaryApplicantName: 'Prashant Gaikwad', loantype: 'BT-Topup', mcCode: 'Shinish Bharadwaraj', caseStatus: 'Inprograss with Vendor' },
        { lanid: 'ILAP345333', primaryApplicantName: 'Priya Pandy', loantype: 'BT-Topup', mcCode: 'Shinish Bharadwaraj', caseStatus: 'Unassigned Cases' },
        { lanid: 'ILAP345334', primaryApplicantName: 'Rahul Shinde', loantype: 'LAP', mcCode: 'Shinish Bharadwaraj', caseStatus: 'Approved/Rejected Cases' },
    ];
    constructor(private http: ConfigService, private Info: InfoServices, private route: Router, private _searchService: SearchService) {
       
    }

    public get Data(): any[] {
        return this._data;
    }
    public set Data(value: any[]) {
        this._data = value;
    }

    ngOnInit(): void {
        
        this._searchService.SearchData.subscribe((res: ISearch) => {
             
            this.GetLAPLegalDashboard(res.toJson());
          });
        
    }

     
    GetLAPLegalDashboard(param:any){
        // this.param =  { lan: "string",
        //     loginPSID: "?20105989",
        //     apiInvokeDateTime: new Date(),
        //     role: "FLO",   
        // }

        this.http.httpPost<ILegalDashboardResponseModel<LegalDashboardModel[]>>(param, 'LAP_GetlLegalDashboard').subscribe((res: ILegalDashboardResponseModel<LegalDashboardModel[]>) => {
            this.Data = res.vendorDashboardDetails;
        })
    }

    NavigateClick(item: any) {

        var data = {            
            "lan": item.lanid,
            "login_PS_ID": "?20105989",
            "apiInvokeDateTime": "2022-09-15T05:03:52.964Z",
            "role": "FLO"
        }
        // var data = {
        //     "LoanAccountNumber": "123",
        //     "FLO_PsId": "23423",
        //     "CreatedON": "2022-08-04"
        // };
        this.Info.setItem('Legal_LanInfo', JSON.stringify(data));
        
        
        switch (item.caseStatus) {
            case "Inprogress with vendor":
                this.Title_1 ="Vendor Queries Queue";
                this.Info.setItem('Screen_Type', "Vendor Queries Queue");
                break;
            case "Legal vendor queries":
                this.Title_1 ="Vendor Queries Queue";
                this.Info.setItem('Screen_Type', "Vendor Queries Queue");
                this.route.navigateByUrl("/legalunassginedcases");
                break;
            case "Approved":
            case "Rejected":
                this.Title_1 ="Status Queue";
                this.Info.setItem('Screen_Type', "Status Queue");
                this.route.navigateByUrl("/legalunassginedcases");
                break;
            default:
                this.Title_1 ="Unassigned Queue";
                this.Info.setItem('Screen_Type', "Unassigned Queue");
                this.route.navigateByUrl("/legalunassginedcases");
                break;
        }

    }

}
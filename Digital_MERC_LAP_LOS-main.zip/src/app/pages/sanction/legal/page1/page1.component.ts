import { AnimationQueryMetadata } from '@angular/animations';
import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";
import { InfoServices } from 'src/app/Injectable/info.services';
import { ConfigService } from 'src/app/shared/services/common/http.services';

@Component({ 
        selector: "app-slegalpage1",
        templateUrl: "./page1.component.html",
        styleUrls: ["./page1.component.css"],
        providers:[ConfigService]
     })
export class SLegalPage1Component implements OnInit {
  legalRequestData:any;
   
    constructor(private http: ConfigService, private Info: InfoServices, private route: Router) {
        var data = this.Info.getItem('Legal_LanInfo');         
        
        if (data != '') {
            this.legalRequestData = JSON.parse(data);
        }
        else {
            return;
        }
         
    }
    ngOnInit(): void {
      
    }
      


   // docrows: any = []

    // addmore() {
    //     let row =  { docname: '', doctype: '', filename: '', remarks: '' }
    //     this.docrows.push(row);
    // }
}


import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { NotificationService } from 'src/app/notification.service';
import { InfoServices } from 'src/app/Injectable/info.services';
import { ISanctionDashboardModel, SanctionDashboardModel } from 'src/app/shared/models/sanction/dashboard';
import { IBankingAssessment, IIncomeEligibility, IncomeEligibility } from './incomeeligibility.service';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';

@Component({
  selector: 'app-incomeeligibility',
  templateUrl: './incomeeligibility.component.html',
  styleUrls: ['./incomeeligibility.component.css'],
  providers: [ConfigService]
})
export class IncomeEligibilityComponent implements OnInit {

  MonthlyExp: IIncomeEligibility = new IncomeEligibility();
  binding: any;
  arrData: any;
  financialApplicantID_1: any;
  financialApplicantName_1: any;
  typeofCustomer: any;
  total_Monthly_Assessed_Income: any;
  appliedLoanAmount: any;
  financialApplicantID_2: any;
  financialApplicantName_2: any;
  financialApplicant1_IncomeSource1: any;
  type_of_BusinessA: any;
  financialApplicant1_IncomeSource2: any;
  type_of_BusinessB: any;
  financialApplicant2_IncomeSource1: any;
  financialApplicant2_IncomeSource2: any;
  total_Monthly_H_Income: any;
  average_Bank_Balance: any;
  incomeAssessmentEligibility: any;
  abb: any;
  banking_AssessmentElibility: any;
  appliedTenure: any;
  eligibleAmount: any;
  eligibleIncome_Dev_YN: any;
  rejection_Reason: any;
  approve_YN: any;
  IsEdit: boolean = false;
  lanInfo: ISanctionDashboardModel = new SanctionDashboardModel();
  disposableIncome: any;
  public get readOnly(): boolean {
    return this.info.LanInfo.readOnly;
  }

  constructor(private http: ConfigService,
    private notify: NotificationService,
    private info: SanctionService
  ) { }
  considerData: any;
  ngOnInit(): void {
    this.lanInfo = this.info.LanInfo;
    this.GetMonthlyHouseholdExpenditure();
    this.considerData = "Assessed Income";
  }

  savedata(a: string) {
    if (a.toLowerCase() == "n" && (!this.MonthlyExp.bankassessment.rejection_Reason || this.MonthlyExp.bankassessment.rejection_Reason == '')) {
      this.notify.showWarning("Required reject reason");
    }
    else {
      var data = {
        EligibleAmount: a.toLowerCase() == 'n' ? "" : this.MonthlyExp.bankassessment.eligibleAmount,
        EligibleIncome_Dev_YN: this.MonthlyExp.bankassessment.eligibleIncome_Dev_YN.toLowerCase() == "deviation" ? "Y" : "N",
        IncomeEligility: a.toLowerCase() == 'n' ? "" : this.MonthlyExp.bankassessment.incomeEligility,
        Rejection_Reason: this.MonthlyExp.bankassessment.rejection_Reason,
        "Approve_YN": a,
        "SourceThrough": "LOS",
        "LoginPSID": this.info.userInfo.userId,
        "LoanAccountNumber": this.lanInfo.lan
      };
      this.http.httpPost(data, 'LAP_IncomeEligibility').subscribe((res: any) => {
        this.notify.showSuccess(res.errorDescription);
        this.GetMonthlyHouseholdExpenditure();
      })
    }

  }
  selectChange(event: any) {
    let value: boolean = false;
    let incomeAssessmentEligibility = (this.MonthlyExp.bankassessment.incomeAssessmentEligibility && this.MonthlyExp.bankassessment.incomeAssessmentEligibility != "") ? Number(this.MonthlyExp.bankassessment.incomeAssessmentEligibility) : 0;
    let eligibleAmount = (this.MonthlyExp.bankassessment.appliedLoanAmount && this.MonthlyExp.bankassessment.appliedLoanAmount != "") ? Number(this.MonthlyExp.bankassessment.appliedLoanAmount) : 0;
    let banking_AssessmentElibility = (this.MonthlyExp.bankassessment.banking_AssessmentElibility && this.MonthlyExp.bankassessment.banking_AssessmentElibility != "") ? Number(this.MonthlyExp.bankassessment.banking_AssessmentElibility) : 0;
    if (event.currentTarget.value != "") {
      switch (event.currentTarget.value.toLowerCase()) {
        case 'assessed income':
          value = banking_AssessmentElibility < incomeAssessmentEligibility
          break;
        case 'banking assessment':
          value = banking_AssessmentElibility > incomeAssessmentEligibility
          break;
      }
    }
    this.MonthlyExp.bankassessment.eligibleAmount = (this, this.MonthlyExp.bankassessment.incomeEligility.toLowerCase() == "assessed income" ? incomeAssessmentEligibility : banking_AssessmentElibility).toFixed(2);
    this.MonthlyExp.bankassessment.eligibleIncome_Dev_YN = value == true ? "Y" : "N";
  }

  GetMonthlyHouseholdExpenditure() {
    var data = {
      "LoanAccountNumber": this.lanInfo.lan,
      "LoginPSID": this.info.userInfo.userId,
      "CreatedON": "2022-09-12"
    };
    this.http.httpPost<IIncomeEligibility>(data, 'GetLAP_IncomeEligibility').subscribe((res: IIncomeEligibility) => {
      if (res.errorcode == "00") {
        this.MonthlyExp = new IncomeEligibility(res);
      }
      this.appliedTenure = Math.floor(this.MonthlyExp.bankassessment.tenure / 12.00);
      this.disposableIncome = (this.MonthlyExp.GetAssessedIncome() * (this.MonthlyExp.bankassessment.foirValue / 100)).toFixed(2);
    });
  }
}

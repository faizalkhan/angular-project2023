
export interface IApplicantIncomeAssesment {
    applicationId: string;
    name: string;
    incomeSource: string;
    amount: string;
}
export class ApplicantIncomeAssesment implements IApplicantIncomeAssesment {
    applicationId: string = "";
    name: string = "";
    incomeSource: string = "";
    private _amount: string = "";
    public get amount(): any {
        return this._amount != "" ? Number(this._amount) : 0;
    }
    public set amount(value: string) {
        this._amount = value ?? "";
    }

    constructor(params?: IApplicantIncomeAssesment) {
        if (params) {
            this.applicationId = params.applicationId;
            this.amount = params.amount;
            this.incomeSource = params.incomeSource;
            this.name = params.name;
        }
    }

}

export interface IObligationData {
    applicationId: string;
    obligationdata: string;
}
export class ObligationData implements IObligationData {
    applicationId: string = "";
    obligationdata: string = "";
    constructor(params?: IObligationData) {
        if (params) {
            this.applicationId = params.applicationId;
            this.obligationdata = params.obligationdata;
        }
    }
}
export interface IBankingAssessment {
    foirValue: number;
    obligation: string;
    appliedLoanAmount: string;
    incomeAssessmentEligibility: string;
    abb: string;
    banking_AssessmentElibility: string;
    tenure: number;
    incomeEligility: string;
    eligibleAmount: string;
    eligibleIncome_Dev_YN: string;
    rejection_Reason: string;
    approve_YN: string;
    servicableEMI: string;
    roi: string;
}
export class BankingAssessment implements IBankingAssessment {
    foirValue: number = 0;
    obligation: string = "";
    appliedLoanAmount: string = "";
    private _incomeAssessmentEligibility: string = "";
    public get incomeAssessmentEligibility(): string {
        return this._incomeAssessmentEligibility;
    }
    public set incomeAssessmentEligibility(value: string) {
        this._incomeAssessmentEligibility = value;
    }
    abb: string = "";
    banking_AssessmentElibility: string = "";
    tenure: number = 0;
    incomeEligility: string = "";
    servicableEMI: string = "";
    roi: string = "";
    private _eligibleAmount: string = "";

    private _eligibleIncome_Dev_YN: string = "";
    public get eligibleIncome_Dev_YN(): string {
        return this._eligibleIncome_Dev_YN;
    }
    public set eligibleIncome_Dev_YN(value: string) {
        this._eligibleIncome_Dev_YN = value == "Y" ? "Deviation" : "No deviation";
    }
    rejection_Reason: string = "";
    private _approve_YN: string = "";
    public get approve_YN(): string {
        return this._approve_YN;
    }
    public set approve_YN(value: string) {
        if (value.toLowerCase() == "n") {
            this._approve_YN = "Rejected";
        }
        else if (value.toLowerCase() == "y") {
            this._approve_YN = "Approved";
        }
        else
            this._approve_YN = "";
    }
    constructor(params?: IBankingAssessment) {
        if (params) {
            this.foirValue = params.foirValue;
            this.obligation = params.obligation;
            this.appliedLoanAmount = Number(params.appliedLoanAmount).toFixed(2);
            this.incomeAssessmentEligibility = Number(params.incomeAssessmentEligibility).toFixed(2);
            this.abb = Number(params.abb).toFixed(2);
            this.banking_AssessmentElibility = Number(params.banking_AssessmentElibility).toFixed(2);
            this.tenure = params.tenure;
            this.servicableEMI = (Number(params.servicableEMI == "" ? 0 : params.servicableEMI) - Number(params.obligation == "" ? 0 : params.obligation)).toFixed(2);
            this.roi = params.roi;
            this.incomeEligility = params.incomeEligility;
            this.eligibleAmount = Number(params.eligibleAmount).toFixed(2) ?? undefined;
            this.eligibleIncome_Dev_YN = params.eligibleIncome_Dev_YN ?? 'N';
            this.rejection_Reason = params.rejection_Reason;
            this.approve_YN = params.approve_YN;
            this.incomeEligility = params.incomeEligility ?? "Assessed Income";
        }
    }

    public set eligibleAmount(value: any) {
        this._eligibleAmount = value;
    }
    public get eligibleAmount(): any {
        return this._eligibleAmount;
    }


}
export interface IIncomeEligibility {
    errorcode: string;
    errorDescription: string;
    applicantIncomeAssesment: IApplicantIncomeAssesment[];
    obligationsdata: IObligationData[];
    data: IBankingAssessment[];
    bankassessment: IBankingAssessment;
    deserilizeIncome: any;
    GetdeserilizeIncome(name: any): any[]
    GetAssessedIncome(name?: any): number;
}

export class IncomeEligibility implements IIncomeEligibility {
    errorcode: string = "";
    errorDescription: string = "";
    applicantIncomeAssesment: IApplicantIncomeAssesment[] = [];
    obligationsdata: IObligationData[] = [];

    data: IBankingAssessment[] = [];
    _bankassessment: IBankingAssessment = new BankingAssessment();
    get bankassessment(): IBankingAssessment {
        return this._bankassessment;
    }
    set bankassessment(value: IBankingAssessment) {
        this._bankassessment = value;
    }
    get deserilizeIncome(): any {
        // return [];
        let result = this.applicantIncomeAssesment.reduce(function (r, a) {
            r[a.name] = r[a.name] || [];
            r[a.name].push(a);
            return r;
        }, Object.create(null));
        return { data: result, list: Object.keys(result) };
    }
    GetdeserilizeIncome(name: any): any[] {
        return this.deserilizeIncome.data[name] as any[];
    }
    GetAssessedIncome(name?: any): any {
        if (name) {
            let data = this.deserilizeIncome.data[name];
            return data.map((x: any) => {
                return Number(x.amount ?? 0);
            }).reduce((a: any, b: any) => a + b, 0).toFixed(2)
        }
        else {
            let data = 0;
            this.deserilizeIncome.list.forEach((x: any) => {
                let y = this.deserilizeIncome.data[x]
                data += y.map((z: any) => {
                    return Number(z.amount ?? 0);
                }).reduce((a: any, b: any) => a + b, 0);
            });
            return data.toFixed(2);
        }
    }
    SumMonthlyIncome()
    {
        
    }
    constructor(params?: IIncomeEligibility) {
        if (params) {
            this.applicantIncomeAssesment = params.applicantIncomeAssesment.map(x => { return new ApplicantIncomeAssesment(x); });
            this.data = params.data.map(x => new BankingAssessment(x));
            this.bankassessment = this.data.length > 0 ? this.data[0] : new BankingAssessment();
            this.obligationsdata = params.obligationsdata.map(x => new ObligationData(x));
        }

    }

}

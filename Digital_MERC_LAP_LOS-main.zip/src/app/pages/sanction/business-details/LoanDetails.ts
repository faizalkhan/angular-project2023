import { common } from "src/app/shared/models/common";
import { Ifile } from "../../layout/button/upload-view-download/upload-view-download.service";
import { ILoanDetails } from "./businessdetailsservice";
import { IDetail } from "./IDetail";
import { Detail } from "./Detail";
import { IUploadDocument } from "../../disbursementdetails/makers/makers.service";


export class LoanDetails implements ILoanDetails {
  private _businessType: any = "";
  public get businessType(): any {
    return this._businessType;
  }
  public set businessType(value: any) {
    this._businessType = value;
  }
  private _businessImage: any = "";
  public get businessImage(): any {
    return this._businessImage;
  }
  public set businessImage(value: any) {
    this._businessImage = value;
  }
  private _businessImage1: any = "";
  public get businessImage1(): any {
    return this._businessImage1;
  }
  public set businessImage1(value: any) {
    this._businessImage1 = value;
  }
  private _businessDocType: any = "";
  public get businessDocType(): any {
    return this._businessDocType;
  }
  public set businessDocType(value: any) {
    this._businessDocType = value;
    this.otherBusinessType = "";
  }
  private _businessProofDocImg: any = "";
  public get businessProofDocImg(): any {
    return this._businessProofDocImg;
  }
  public set businessProofDocImg(value: any) {
    this._businessProofDocImg = value;
  }
  private _businessImage_Ref: any = "";
  public get businessImage_Ref(): any {
    return this._businessImage_Ref;
  }
  public set businessImage_Ref(value: any) {
    this._businessImage_Ref = value;
  }
  private _details: IDetail[] = [];
  public get details(): IDetail[] {
    return this._details;
  }
  public set details(value: IDetail[]) {
    this._details = value;
  }
  get uploadfile(): Ifile {
    return { extension: 'jpg', format: "image/jpg", file: this.businessImage, filename: this.businessType } as Ifile;
  }


  constructor(params?: ILoanDetails) {
    if (params) {
      common.ObjectMapping(params, this);
      this.details = this.details.map(x => new Detail(x));
      this.CurrentFile = this.uploadfile;
    }
  }
  private _Documents: IUploadDocument[] = [];
  public get Documents(): IUploadDocument[] {
    return this._Documents;
  }
  public set Documents(value: IUploadDocument[]) {
    this._Documents = value;
  }
  private _otherBusinessType: string = "";
  public get otherBusinessType(): any {
    return this._otherBusinessType;
  }
  public set otherBusinessType(value: any) {
    this._otherBusinessType = value;
  }
  private _businessAddress: string = "";
  public get businessAddress(): any {
    return this._businessAddress;
  }
  public set businessAddress(value: any) {
    this._businessAddress = value;
  }
  private _CurrentFile: Ifile = {} as Ifile;
  public get CurrentFile(): Ifile {
    return this._CurrentFile;
  }
  public set CurrentFile(value: Ifile) {
    this._CurrentFile = value;
  }

  private _mcCode: any = "";
  public get mcCode(): any {
    return this._mcCode;
  }
  public set mcCode(value: any) {
    this._mcCode = value;
  }
  private _loanApplicationNo: any = "";
  public get loanApplicationNo(): any {
    return this._loanApplicationNo;
  }
  public set loanApplicationNo(value: any) {
    this._loanApplicationNo = value;
  }
  private _loanAccountNumber: any = "";
  public get loanAccountNumber(): any {
    return this._loanAccountNumber;
  }
  public set loanAccountNumber(value: any) {
    this._loanAccountNumber = value;
  }
  private _leadId: any = "";
  public get leadId(): any {
    return this._leadId;
  }
  public set leadId(value: any) {
    this._leadId = value;
  }
  private _associateId: any = "";
  public get associateId(): any {
    return this._associateId;
  }
  public set associateId(value: any) {
    this._associateId = value;
  }

  toJson() {
    return {
      "AssociateID": this.associateId,
      "BusinessAddress": this.businessAddress,
      "BusinessImage": this.CurrentFile?.file,
      "BusinessImgExt": this.CurrentFile?.extension,
      "BusinessImgMIMEType": this.CurrentFile?.format,
      "BusinessType": this.businessType,
      "GL_Latitude": "19.0731419",
      "GL_Longitude": "72.8689755",
      //"Details": this.details.map(x => { return x.toJson(); }),
      "Module": "",
      "LeadID": this.leadId,
      "LoanAccountNumber": this.loanAccountNumber,
      "LoanApplicationNo": this.loanApplicationNo,
      "McCode": this.mcCode,
      "BusinessDocType": this.businessDocType,
      "SourceThrough": "LOS",
      "AddOrModify": "Modify",
      "OtherBusinessType": this.otherBusinessType
    };
  }

  toJsonWithOutImage() {
    return {
      "AssociateID": this.associateId,
      "BusinessAddress": this.businessAddress,
      //"BusinessImage": this.businessImage,
      "BusinessImgExt": this.CurrentFile?.extension,
      "BusinessImgMIMEType": this.CurrentFile?.format,
      "BusinessType": this.businessType,
      "GL_Latitude": "19.0731419",
      "GL_Longitude": "72.8689755",
      //"Details": this.details.map(x => { return x.toJson(); }),
      "Module": "",
      "LeadID": this.leadId,
      "LoanAccountNumber": this.loanAccountNumber,
      "LoanApplicationNo": this.loanApplicationNo,
      "McCode": this.mcCode,
      "BusinessDocType": this.businessDocType,
      "SourceThrough": "LOS",
      "AddOrModify": "Modify",
      "OtherBusinessType": this.otherBusinessType
    };
  }
}

import { Component, OnInit } from '@angular/core';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { ILoanDetails } from './businessdetailsservice';
import { IDetail } from "./IDetail";
import { Detail } from "./Detail";
import { LoanDetails } from "./LoanDetails";
import { ModalService } from "src/app/shared/services/modal/modal.service";
import 'rxjs'
import { SanctionDashboardModel } from 'src/app/shared/models/sanction/dashboard';
import { InfoServices } from 'src/app/Injectable/info.services';
import { NotificationService } from 'src/app/notification.service';
import { Dropdown, IDropdown } from 'src/app/shared/models/common/control.model';
import { FileUpload, Ifile, IfileUpload, UploadViewDownloadService } from '../../layout/button/upload-view-download/upload-view-download.service';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { masterModuleDropdown } from 'src/app/shared/models/sanction/masterDropdown';
import { common } from 'src/app/shared/models/common';

@Component({
  selector: 'app-businessdetails',
  templateUrl: './businessdetails.component.html',
  styleUrls: ['./businessdetails.component.css']
})
export class BusinessDetailsComponent implements OnInit {
  loanisEdit: boolean = false;
  loanInfo: ILoanDetails = new LoanDetails();
  fileUpload: IfileUpload = new FileUpload();
  _requestData: SanctionDashboardModel = new SanctionDashboardModel();
  public get requestData(): any {
    return {
      "LoanApplicationNo": this._requestData.lan,
      "LeadID": this._requestData.leadId,
      "AssociateID": this._requestData.flopsid,
      "McCode": this._requestData.mcCode,
      "LoanAccountNumber": this._requestData.lan
    };

  }
  upload(event: IfileUpload): Ifile {
    return { extension: event.extension, file: event.imageData, filename: event.name, format: event.imageMIMEType } as Ifile;
  }
  detail: IDetail = new Detail();
  private _businessDocTypeList: IDropdown[] = [new Dropdown({ displayName: "GST Reciept" }), new Dropdown({ displayName: "Shop Establishment" }), new Dropdown({ displayName: "Udyam Registration" }), new Dropdown({ displayName: "Rental Agreement" }), new Dropdown({ displayName: "ITR" })
    , new Dropdown({ displayName: "Other Document 1" })
    , new Dropdown({ displayName: "Other Document 2" })
    , new Dropdown({ displayName: "Other Document 3" })
    , new Dropdown({ displayName: "Other Document 4" })
  ];
  public get businessDocTypeList(): IDropdown[] {
    return this._businessDocTypeList;
  }
  public set businessDocTypeList(value: IDropdown[]) {
    this._businessDocTypeList = value;
  }
  BusinessType: IDropdown[] = masterModuleDropdown.BusinessType;
  constructor(private http: ConfigService,
    private modal: ModalService,
    private Info: SanctionService,
    private Notify: NotificationService,
    private uploadService: UploadViewDownloadService,
    private storage: InfoServices) {

  }
  remove(index: any) {

    this.loanInfo?.details.splice(index, 1);

  }
  ngOnInit(): void {
    this._requestData = this.Info.LanInfo as SanctionDashboardModel;
    this.fileUpload.loanAccountNumber = this._requestData.lan;
    this.fileUpload.flO_Id = this._requestData.flopsid;
    this.fileUpload.moduleName = "BusinessDetail";
    this.fileUpload.type = "";
    this.GetPersonalDetails();

    this.uploadService.uploadLoad = new FileUpload({ leadID: this.Info.LanInfo.leadId, moduleName: "SubmitBusinessDeatils", flO_Id: this.Info.LanInfo.flopsid, loanAccountNumber: this.Info.LanInfo.lan } as IfileUpload);

  }

  GetPersonalDetails() {
    this.http.httpPost<LoanDetails>(this.requestData, 'LAP_GetAppnBussinessDeatils').subscribe((res: LoanDetails) => {
      this.loanInfo = new LoanDetails(res);
      this.loanInfo.loanAccountNumber = this.Info.LanInfo.lan;
      this.loanInfo.leadId = this.Info.LanInfo.leadId;
      this.loanInfo.associateId = this.Info.LanInfo.flopsid;
      this.loanInfo.loanApplicationNo = this.Info.LanInfo.lan
    })
  }

  showModal(e: Ifile) {
    this.uploadService.ShowFile(e);
  }
  save(event: any) {
    if (this.validate()) {
      this.loanisEdit = !this.loanisEdit
    }
  }
  validate(): boolean {
    if (this.loanInfo?.details.filter(x => x.businessDocType == "")?.length > 0) {
      this.Notify.showWarning("Please enter Business document Type");
      return false;
    }
    else if (this.loanInfo?.details.filter(x => !x.CurrentFile)?.length > 0) {
      this.Notify.showWarning("Please upload the document");
      return false;
    }
    else if (this.loanInfo.businessType.toLowerCase() == "others" && (!this.loanInfo.otherBusinessType || this.loanInfo.otherBusinessType == '')) {
      this.Notify.showWarning("Required Business detail (Others)")
      return false;
    }
    else if (common.toFindDuplicates(this.loanInfo?.details, 'businessDocType').length > 0) {
      this.Notify.showWarning("Please duplicate documents not allowed")
      return false;
    }
    return true;
  }

  PersonalSubmit() {
    if (this.validate()) {
      this.http.httpPostWithouImageData<any>(this.loanInfo?.toJson(), 'LAP_SubmitBusinessDeatils_1', this.loanInfo?.toJsonWithOutImage()).subscribe((res: any) => {
        if (res.errorcode == '00') {
          this.GetPersonalDetails();
          this.Notify.showSuccess(res.errorDescription);
        }
        else {
          this.Notify.showError(res.errorDescription);
        }
      })
    }
  }
  addMore() {
    if (this.validate()) {
      this.detail.isAdded = true;
      this.loanInfo?.details.push(this.detail);
      this.detail = new Detail();
    }
  }

  Cancel(event: any) {
    let business = JSON.parse(this.storage.currentEdit);

    this.loanInfo = new LoanDetails(business);
    this.loanisEdit = !this.loanisEdit;
  }
  edit(event: any) {
    this.storage.currentEdit = JSON.stringify(this.loanInfo);
    this.loanisEdit = !this.loanisEdit;
  }
}
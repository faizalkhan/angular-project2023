import { IUploadDocument } from "../../disbursementdetails/makers/makers.service";
import { Ifile } from "../../layout/button/upload-view-download/upload-view-download.service";
import { IDetail } from "./IDetail";

export interface ILoanDetails {
  CurrentFile: Ifile;
  associateId: any;
  mcCode: any;
  leadId: any;
  businessAddress: any;
  loanAccountNumber: any;
  loanApplicationNo: any;
  businessType: any;
  businessImage: any;
  businessImage_Ref: any;
  businessImage1: any;
  businessDocType: any;
  businessProofDocImg: any;
  uploadfile: Ifile;
  details: IDetail[];
  otherBusinessType: any;
  toJson(): any;
  toJsonWithOutImage(): any;
}




import { Ifile } from "../../layout/button/upload-view-download/upload-view-download.service";


export interface IDetail {
  CurrentFile: Ifile;
  businessDocType: string;
  businessProofDocImg: string;
  businessProofDocImg_Ref: string;
  businessDocTypeDescription: string;
  businessProofDocImgMIMEType?: any;
  businessProofDocImgExt?: any;
  toJsonWithOutImage(): any;
  toJson(): any;
  isOtherDocs: boolean;
  uploadfile: Ifile;
  isAdded: boolean;
}

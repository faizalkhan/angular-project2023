import { common } from "src/app/shared/models/common";
import { Ifile } from "../../layout/button/upload-view-download/upload-view-download.service";
import { IDetail } from "./IDetail";

export class Detail implements IDetail {
  private _businessDocType: string = "";
  public get businessDocType(): string {
    return this._businessDocType;
  }
  public set businessDocType(value: string) {
    this._businessDocType = value;
    if (value) {
      this.isOtherDocs = this.businessDocType.toString().toLowerCase().startsWith('other');
      this.businessDocTypeDescription = "";
    }
  }
  private _businessProofDocImg: string = "";
  public get businessProofDocImg(): string {
    return this._businessProofDocImg;
  }
  public set businessProofDocImg(value: string) {
    this._businessProofDocImg = value;
  }
  private _businessDocTypeDescription: string = "";
  public get businessDocTypeDescription(): string {
    return this._businessDocTypeDescription;
  }
  public set businessDocTypeDescription(value: string) {
    this._businessDocTypeDescription = value;
  }
  private _businessProofDocImgMIMEType?: any = "";
  public get businessProofDocImgMIMEType(): any {
    return this._businessProofDocImgMIMEType;
  }
  public set businessProofDocImgMIMEType(value: any) {
    this._businessProofDocImgMIMEType = value;
  }
  private _businessProofDocImgExt?: any = "";
  public get businessProofDocImgExt(): any {
    return this._businessProofDocImgExt;
  }
  public set businessProofDocImgExt(value: any) {
    this._businessProofDocImgExt = value;
  }
  private _uploadfile: Ifile = {} as Ifile;
  get uploadfile(): Ifile {
    return this._uploadfile;
  }
  set uploadfile(value: Ifile) {
    this._uploadfile = value;
  }
  private _businessProofDocImg_Ref: string = "";
  public get businessProofDocImg_Ref(): string {
    return this._businessProofDocImg_Ref;
  }
  public set businessProofDocImg_Ref(value: string) {
    this._businessProofDocImg_Ref = value;
  }
  constructor(params?: IDetail) {
    if (params) {
      common.ObjectMapping(params, this);
      this.isOtherDocs = (this.businessDocTypeDescription && this.businessDocTypeDescription != "") == true;
      this.CurrentFile = { extension: this.businessProofDocImgExt, file: this.businessProofDocImg, filename: this.businessDocTypeDescription, format: this.businessProofDocImgMIMEType } as Ifile;
    }
  }
  private _BusinessProofDocImg_Ref: string="";
  public get BusinessProofDocImg_Ref(): string {
    return this._BusinessProofDocImg_Ref;
  }
  public set BusinessProofDocImg_Ref(value: string) {
    this._BusinessProofDocImg_Ref = value;
  }
 
  private _isOtherDocs: boolean = false;
  public get isOtherDocs(): boolean {
    return this._isOtherDocs;
  }
  public set isOtherDocs(value: boolean) {
    this._isOtherDocs = value;
  }
  isAdded: boolean = false;
  private _CurrentFile: Ifile = {} as Ifile;
  public get CurrentFile(): Ifile {
    return this._CurrentFile;
  }
  public set CurrentFile(value: Ifile) {
    this._CurrentFile = value;
  }
  toJson(): any {
    return {
      "BusinessDocType": this.businessDocType,
      "BusinessDocTypeDescription": this.businessDocTypeDescription,
      "BusinessProofDocImg": this.CurrentFile.file,
      "BusinessProofDocImgExt": this.CurrentFile.extension,
      "businessProofDocImgMIMEType": this.CurrentFile.format,
    };
  }
  toJsonWithOutImage(): any {
    return {
      "BusinessDocType": this.businessDocType,
      "BusinessDocTypeDescription": this.businessDocTypeDescription,
      "BusinessProofDocImgExt": this.CurrentFile.extension,
      "businessProofDocImgMIMEType": this.CurrentFile.format,
    };
  }
}

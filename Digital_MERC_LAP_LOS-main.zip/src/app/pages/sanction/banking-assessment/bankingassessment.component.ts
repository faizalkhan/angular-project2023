import { Component } from '@angular/core';
import { ActivatedRoute } from "@angular/router";

@Component({
    selector: "app-page4",
    templateUrl: "./bankingassessment.component.html",
    styleUrls: ["./bankingassessment.component.css"]
})
export class BankAssessmentComponent {

}


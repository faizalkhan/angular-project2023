import { Component, OnInit } from '@angular/core';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { IReferenceCheck, ReferenceCheck } from 'src/app/shared/models/sanction/reference-check/referencecheck.model';
import { InfoServices } from 'src/app/Injectable/info.services';
import { ISanctionDashboardModel } from 'src/app/shared/models/sanction/dashboard';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { NotificationService } from 'src/app/notification.service';
import { Dropdown, IDropdown } from 'src/app/shared/models/common/control.model';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { common } from 'src/app/shared/models/common';

@Component({
  selector: 'app-reference-check',
  templateUrl: './referencecheck.component.html',
  styleUrls: ['./referencecheck.component.css'],
  providers: [ConfigService, DatePipe]

})
export class ReferenceCheckComponent implements OnInit {
  reference: ReferenceCheck[] = [new ReferenceCheck()];
  isEdit: boolean = false;
  mobNo: any;
  FinalRemarks: string = "";
  private _summary: any;
  public get summary(): any {
    return this._summary;
  }
  public set summary(value: any) {
    this._summary = value;
  }

  public getSummary(): any {
    if (this.reference.length > 0) {
      this.summary = {
        Negative: this.reference.filter(x => x.checkResult?.toLowerCase() == "negative").length
        , Positive: this.reference.filter(x => x.checkResult?.toLowerCase() == "positive").length
      }
    }
    else {
      this.summary = {
        Negative: 0
        , Positive: 0
      }
    }
  }
  private _LanInfo: any;
  public get LanInfo(): any {
    return this._LanInfo;
  }
  public set LanInfo(value: any) {
    this._LanInfo = value;
  }
  data: any = {};
  public get NoDataFound(): boolean {
    return (this.reference && this.reference.length > 0) == false;
  }

  public get editable(): boolean {
    if (this.reference && this.reference.length > 0) {
      return this.reference.filter(x => x.isEdit).length > 0
    }
    else {
      return false;
    }
  }

  constructor(private http: ConfigService, private info: InfoServices, private _datepipe: DatePipe, private notify: NotificationService, private sanctionService: SanctionService) {
  }

  ngOnInit(): void {
    if (this.info.IsItem('ReferenceData')) {
      this.data = JSON.parse(this.info.getItem('ReferenceData'));
      this.DeSerializeReference();
    }
    else {
      this.GetReferenceDetails();
    }
  }
  toReferenceDetails() {
    this.LanInfo = this.sanctionService.LanInfo as ISanctionDashboardModel;

    return { "LoanAccountNumber": this.LanInfo.lan, "FLO_PsId": this.LanInfo.flopsid, "CreatedON": this.LanInfo.dateSourced }
  }
  GetReferenceDetails() {
    this.reference = [];
    this.http.httpPost<any>(this.toReferenceDetails(), 'LAP_GetReferenceDetails').subscribe((res: any) => {
      if (res.errorcode == "00") {
        this.notify.showSuccess(res.errorDescription, "Reference")
        this.data = res.data[0];
        this.reference = [];
        this.DeSerializeReference();
      } else {
        this.notify.showError(res.errorDescription, "Reference")
      }
    })

  }
  DeSerializeReference() {

    this.reference = [];
    this.FinalRemarks = this.data.finalRemarks;
    for (let i = 1; i <= 5; i++) {
      var typeValue = this.data[`ref${i}_Type`] ?? this.data[`Ref${i}_Type`];
      if (typeValue !== '') {
        this.reference.push(new ReferenceCheck(
          {
            Id: i - 1,
            loanAccountNumber: this.sanctionService.LanInfo.lan,
            createdOn: new Date(),
            flO_PsId: this.sanctionService.LanInfo.flopsid,
            name: this.data[`ref${i}_Name`] ?? this.data[`Ref${i}_Name`],
            type: this.data[`ref${i}_Type`] ?? this.data[`Ref${i}_Type`],
            mobileNo: this.data[`ref${i}_MobileNo`] ?? this.data[`Ref${i}_MobileNo`],
            checkResult: this.data[`ref${i}_CheckResult`] ?? this.data[`Ref${i}_CheckResult`],
            relationship: this.data[`ref${i}_Relationship`] ?? this.data[`Ref${i}_Relationship`],
            remark: this.data[`ref${i}_Remark`] ?? this.data[`Ref${i}_Remark`]
          } as IReferenceCheck
        ));
        this.getSummary();
      }
    }
  }
  SerializeReference() {
    this.data = {};
    for (let index = 0; index <= 5; index++) {
      this.data['LoanAccountNumber'] = this.sanctionService.LanInfo.lan;
      this.data['CreatedOn'] = this._datepipe.transform(new Date(), "yyyy-MM-dd");
      this.data['FLO_PsId'] = this.sanctionService.LanInfo.flopsid;
      this.data['SourceThrough'] = "LOS";
      this.data[`Ref${index + 1}_Name`] = this.reference[index] ? this.reference[index]?.name : "";
      this.data[`Ref${index + 1}_Type`] = this.reference[index] ? this.reference[index]?.type : "";
      this.data[`Ref${index + 1}_MobileNo`] = this.reference[index] ? this.reference[index]?.mobileNo : "";
      this.data[`Ref${index + 1}_CheckResult`] = this.reference[index] ? this.reference[index]?.checkResult : "";
      this.data[`Ref${index + 1}_Relationship`] = this.reference[index] ? this.reference[index]?.relationship : "";
      this.data[`Ref${index + 1}_Remark`] = this.reference[index] ? this.reference[index]?.remark : "";
    }
  }


  radiChange(event: any, valueIndex: number) {
    // if (event.target.value === "P") {
    //   this.reference[valueIndex].checkResult = "Positive";
    // } else {
    //   this.reference[valueIndex].checkResult = "Negative";
    // }
    this.getSummary();
  }
  Remove() {
    this.reference.pop();
    this.getSummary();
  }
  AddMore() {
    let valid = true;
    if (this.reference.length > 0) {
      let lastBind = this.reference[this.reference.length - 1];
      if ((!lastBind.name || lastBind.name == "") || (!lastBind.mobileNo || lastBind.mobileNo == "")
        || (!lastBind.type || lastBind.type == "") || (!lastBind.remark || lastBind.remark == "")
      ) {
        this.notify.showWarning("please fill the current reference detail.");
        valid = false;
      }

    }
    if (valid) {
      let ref = new ReferenceCheck();
      ref.isEdit = true;
      this.reference.push(ref);
    }
  }
  Submit(i: number) {
    let item = this.reference[i];
    if (!item.name || item.name == '') {
      this.notify.showWarning("Please enter the name");
      return;
    }
    if (item.name && item.name.length < 3) {
      this.notify.showWarning("Please enter valid the name");
      return;
    }
    else if (!item.mobileNo || item.mobileNo == '') {
      this.notify.showWarning("Please enter the mobile no.");
      return;
    }
    else if (item.mobileNo && (!common.isValid_MobileNo(item.mobileNo) || item.mobileNo.length != 10)) {
      this.notify.showWarning("Please enter valid mobile no.");
      return;
    }
    else if (!item.type || item.type == '') {
      this.notify.showWarning("Please enter the reference type");
      return;
    }
    else if (item.isTradeSelected && (!item.relationship || item.relationship == '')) {
      this.notify.showWarning("Please enter the Reference Relationship");
      return;
    }
    else if (!item.checkResult || item.checkResult == '') {
      this.notify.showWarning("Please choose any feedback (Positive / Negative)");
      return;
    }
    else if (!item.remark || item.remark == '') {
      this.notify.showWarning("Please enter the Reference Remarks");
      return;
    }
    // else if (item.remark && item.remark.length < 50) {
    //   this.notify.showWarning("Reference Remarks not allowed less than 50 characters");
    //   return;
    // }
    item.isEdit = !item.isEdit;
    // this.SerializeReference().then(res=>this.fnAssignReferenceData()); 
    this.SerializeReference();
    this.info.setItem('ReferenceData', JSON.stringify(this.data));
    this.getSummary();
  }
  fnAssignReferenceData() {
    this.info.setItem('ReferenceData', JSON.stringify(this.data));
  }
  onChange(event: any) {
    this.mobNo = event;
  }
  cancel(event: any, i: number) {
    this.reference[i] = new ReferenceCheck(event);
    this.getSummary();
  }
  Finalvalidation(): boolean {
    let message: string = "";
    if (this.reference.length < 2) {
      message = "Minimum one Trade Reference and one Residence Neighbour Reference is required as per policy norms."
    }
    else if (this.reference.find(x => x.type.toLowerCase() == 'trade reference') === undefined || this.reference.find(x => x.type.toLowerCase() == 'residence neighbour reference') === undefined) {
      message = "Minimum one Trade Reference and one Residence Neighbour Reference is required as per policy norms."
    }
    else if (!this.FinalRemarks || this.FinalRemarks == '') {
      message = "Please enter the final remarks"
    }
    if (message.length > 0)
      this.notify.showWarning(message);
    return message.length == 0;
  }
  savedata() {
    if (this.Finalvalidation()) {
      this.SerializeReference();
      let data = {
        "FLO_PsId": this.data['FLO_PsId'],
        "LoanAccountNumber": this.data['LoanAccountNumber'],
        "Ref1_CheckResult": this.data['Ref1_CheckResult'],
        "Ref1_MobileNo": this.data["Ref1_MobileNo"],
        "Ref1_Name": this.data["Ref1_Name"],
        "Ref1_Relationship": this.data["Ref1_Relationship"],
        "Ref1_Remark": this.data["Ref1_Remark"],
        "Ref1_Type": this.data["Ref1_Type"],
        "Ref2_CheckResult": this.data["Ref2_CheckResult"],
        "Ref2_MobileNo": this.data["Ref2_MobileNo"],
        "Ref2_Name": this.data["Ref2_Name"],
        "Ref2_Relationship": this.data["Ref2_Relationship"],
        "Ref2_Remark": this.data["Ref2_Remark"],
        "Ref2_Type": this.data["Ref2_Type"],
        "Ref3_CheckResult": this.data["Ref3_CheckResult"],
        "Ref3_MobileNo": this.data["Ref3_MobileNo"],
        "Ref3_Name": this.data["Ref3_Name"],
        "Ref3_Relationship": this.data["Ref3_Relationship"],
        "Ref3_Remark": this.data["Ref3_Remark"],
        "Ref3_Type": this.data["Ref3_Type"],
        "Ref4_CheckResult": this.data["Ref4_CheckResult"],
        "Ref4_MobileNo": this.data["Ref4_MobileNo"],
        "Ref4_Name": this.data["Ref4_Name"],
        "Ref4_Relationship": this.data["Ref4_Relationship"],
        "Ref4_Remark": this.data["Ref4_Remark"],
        "Ref4_Type": this.data["Ref4_Type"],
        "Ref5_CheckResult": this.data["Ref5_CheckResult"],
        "Ref5_MobileNo": this.data["Ref5_MobileNo"],
        "Ref5_Name": this.data["Ref5_Name"],
        "Ref5_Relationship": this.data["Ref5_Relationship"],
        "Ref5_Remark": this.data["Ref5_Remark"],
        "Ref5_Type": this.data["Ref5_Type"],
        "Ref6_CheckResult": this.data["Ref6_CheckResult"],
        "Ref6_MobileNo": this.data["Ref6_MobileNo"],
        "Ref6_Name": this.data["Ref6_Name"],
        "Ref6_Relationship": this.data["Ref6_Relationship"],
        "Ref6_Remark": this.data["Ref6_Remark"],
        "Ref6_Type": this.data["Ref6_Type"],
        "SourceThrough": "LOS",
        "FinalRemarks": this.FinalRemarks
      };
      this.http.httpPost(data, 'LAP_ReferenceDetails').subscribe(res => {
        this.info.removeItem('ReferenceData');
        this.notify.showSuccess("Data saved successfully");
      });
    }
  }

}

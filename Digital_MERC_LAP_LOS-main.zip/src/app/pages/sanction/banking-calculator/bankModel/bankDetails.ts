import { CustomerBankDetail, IDocumentReferenceBanking } from "./CustomerBankDetail";
import { CustomerBankAccountDetail, ICustomerBankAccountDetail } from "./CustomerBankAccountDetail";
import { CustomerBankABBDetail, ICustomerBankABBDetail } from "./CustomerBankABBDetail";

export class BankDetails implements IBankDetails {
    loanAccountNumber: string = "";
    errorcode: string = "";
    errorDescription: string = "";
    monthList: any[] = ["Jan", "Feb", "Mar", "	Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    private _customerBankDetails: CustomerBankDetail[] = [];
    public get customerBankDetails(): CustomerBankDetail[] {
        return this._customerBankDetails ?? [];
    }
    public set customerBankDetails(value: CustomerBankDetail[]) {
        this._customerBankDetails = value;
    }
    private _customerBankAccountDetails: ICustomerBankAccountDetail[] = [];
    public get customerBankAccountDetails(): ICustomerBankAccountDetail[] {

        return this._customerBankAccountDetails;
    }
    public set customerBankAccountDetails(value: ICustomerBankAccountDetail[]) {
        this._customerBankAccountDetails = value;
    }
    private _customerBankABBDetails: CustomerBankABBDetail[] = [];
    public get customerBankABBDetails(): CustomerBankABBDetail[] {
        return this._customerBankABBDetails;
    }
    public set customerBankABBDetails(value: CustomerBankABBDetail[]) {
        this._customerBankABBDetails = value;
    }
    public get totalOfABB(): any {
        let data = this._customerBankDetails.map(x => { return (x.abbTotal && x.abbTotal != "" ? Number(x.abbTotal) : 0); });
        return data.reduce((a, b) => a + b, 0);
    }
    public get totalOfCreditEntries(): Number {
        return this._customerBankDetails.map(x => { return (x.sum_NoOfCreditEntries && x.sum_NoOfCreditEntries != "" ? Number(x.sum_NoOfCreditEntries) : 0); }).reduce((a, b) => a + b, 0);
    }
    public get totalCreditAmount(): Number {
        return this._customerBankDetails.map(x => { return (x.sum_TotalCreditAmount) ?? 0; }).reduce((a, b) => a + b, 0);
    }
    public get totalLoanCreditAmount(): Number {
        return this._customerBankDetails.map(x => { return x.sum_LoanCreditsAmount ?? 0; }).reduce((a, b) => a + b, 0);
    }
    public get totalNetCreditAmount(): Number {
        return this._customerBankDetails.map(x => { return x.sum_NetCreditAmount ?? 0; }).reduce((a, b) => a + b, 0);
    }
    public get totalOfInwardReturn(): Number {
        return this._customerBankDetails.map(x => x.sum_InwardChequeReturns ?? 0).reduce((a, b) => a + b, 0);
    }
    public get totalOfOutwardReturn(): Number {
        return this._customerBankDetails.map(x => { return x.sum_OutwardChequeReturns ?? 0; }).reduce((a, b) => a + b, 0);
    }
    totalAccountAmountDetails: any[] = [];

    constructor(params?: IBankDetails) {
        if (params) {
            this.errorcode = params.errorcode;
            this.errorDescription = params.errorDescription;
            this.loanAccountNumber = params.loanAccountNumber;
            this.documents = params.documents;
            this.customerBankABBDetails = params.customerBankABBDetails.map(x => { x.loanAccountNumber = params.loanAccountNumber; return new CustomerBankABBDetail(x); });
            this.customerBankAccountDetails = params.customerBankAccountDetails.map(x => { x.loanAccountNumber = params.loanAccountNumber; return new CustomerBankAccountDetail(x); });
            this.customerBankDetails = params.customerBankDetails.map(x => {
                x.loanAccountNumber = params.loanAccountNumber;
                this.setDocumentId(x)
                return new CustomerBankDetail(x);
            });

            this.BankDetail();
        }

    }
    setDocumentId(bank: CustomerBankDetail) {
        let doc = this.documents.find(x => x.accountNumber.toLowerCase() == bank.accountNumber.toLowerCase());
        if (doc) {
            bank.documentId = doc.documentId;
            bank.bankDetailId = doc.bankDetailId;
        }

    }
    private _documents: IDocumentReferenceBanking[] = [];
    public get documents(): IDocumentReferenceBanking[] {
        return this._documents;
    }
    public set documents(value: IDocumentReferenceBanking[]) {
        this._documents = value;
    }
    private _disbursement!: CustomerBankDetail;
    public get disbursement(): CustomerBankDetail {
        return this._disbursement;
    }
    public set disbursement(value: CustomerBankDetail) {
        this._disbursement = value;
        this.customerBankDetails.forEach((x: CustomerBankDetail) => {

            if (value && value.accountNumber != "") {
                x.isDisbursement = x.accountNumber == value.accountNumber;
                x.isDisable = !x.isDisbursement;
            }
            else {
                x.isDisbursement = false;
                x.isDisable = false;
            }
        });
    }
    GetMonthAndYear(a: number): any[] {
        let data = [];
        for (let i = 1; i <= a; i++) {
            let date = new Date();
            let _mon = new Date(date.setMonth(date.getMonth() - i)).getMonth();
            data.push(`${this.monthList[_mon]}-${date.getFullYear()}`);
        }
        return data;
    }
    BankDetail() {
        this.customerBankDetails.forEach(x => {
            if (x.accountNumber) {
                let acc = this._customerBankAccountDetails.filter(y => y.accountNumber == x.accountNumber) as CustomerBankAccountDetail[];
                if (x.customerBankAccountDetails && acc) {
                    x.customerBankAccountDetails = acc;

                }
                let abb = this._customerBankABBDetails.filter(y => y.accountNumber == x.accountNumber) as CustomerBankABBDetail[];

                if (abb && x.customerBankABBDetails) {
                    x.customerBankABBDetails = abb;

                }
            }
        });
    }
    GetAccountDetail(): CustomerBankAccountDetail[] {
        let data: any[] = [];
        let self = this;
        this.customerBankDetails.forEach(x => {
            data = [...data, ...x.customerBankAccountDetails.map(y => { y.accountNumber = x.accountNumber; return y.toJSON(); })];
        });

        return data;
    }
    GetAccountABBDetail(): ICustomerBankABBDetail[] {
        let data: ICustomerBankABBDetail[] = [];

        this.customerBankDetails.forEach(x => {
            data = [...data, ...x.customerBankABBDetails.map(z => { z.accountNumber = x.accountNumber; return z.toJSON(); })];
        });

        return data;
    }
}

export interface IBankDetails {
    loanAccountNumber: string;
    errorcode: string;
    errorDescription: string;
    customerBankDetails: CustomerBankDetail[];
    customerBankAccountDetails: ICustomerBankAccountDetail[];
    customerBankABBDetails: ICustomerBankABBDetail[];
    totalAccountAmountDetails: any[];
    disbursement: CustomerBankDetail | undefined;
    BankDetail(): void;
    GetAccountDetail(): ICustomerBankAccountDetail[];
    GetAccountABBDetail(): ICustomerBankABBDetail[];
    //Summary
    totalOfABB: any;
    totalOfCreditEntries: any;
    totalCreditAmount: any;
    totalLoanCreditAmount: any;
    totalNetCreditAmount: any;
    totalOfInwardReturn: any;
    totalOfOutwardReturn: any;
    GetMonthAndYear(a: Number): any;
    documents: IDocumentReferenceBanking[];
}

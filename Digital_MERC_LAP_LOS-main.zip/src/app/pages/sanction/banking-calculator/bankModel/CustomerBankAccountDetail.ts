
export interface ICustomerBankAccountDetail {
    loanAccountNumber: string;
    accountNumber: string;
    noOfMonth: string;
    monthAndYear: string;
    noOfDebitEntries: string;
    totalDebitAmount: string;
    noOfCreditEntries: string;
    totalCreditAmount: string;
    loanCreditsAmount: string;
    netCreditAmount: string;
    noOfOutwardChequesReceived: string;
    outwardChequeReturns: string;
    noOfInwardChequesIssued: string;
    inwardChequeReturns: string;
    editFieldName: string;
    toJSON(): any;
}

export class CustomerBankAccountDetail implements ICustomerBankAccountDetail {
    loanAccountNumber: string = "";
    accountNumber: string = "";
    noOfMonth: string = "";
    monthAndYear: string = "";
    private _noOfDebitEntries: string = "";
    public get noOfDebitEntries(): string {
        return this._noOfDebitEntries;
    }
    public set noOfDebitEntries(value: string) {
        this._noOfDebitEntries = value ?? "";
    }
    private _totalDebitAmount: string = "";
    public get totalDebitAmount(): any {
        return (this._totalDebitAmount != "") ? Number(this._totalDebitAmount) : "";
    }
    public set totalDebitAmount(value: string) {
        this._totalDebitAmount = value;
    }
    private _noOfCreditEntries: string = "";
    public get noOfCreditEntries(): string {
        return this._noOfCreditEntries;
    }
    public set noOfCreditEntries(value: any) {
        this._noOfCreditEntries = value ?? "";
    }
    private _totalCreditAmount: string = "";
    public get totalCreditAmount(): string {
        return this._totalCreditAmount;
    }
    public set totalCreditAmount(value: string) {
        this._totalCreditAmount = value;
    }
    private _loanCreditsAmount: string = "";
    public get loanCreditsAmount(): any {
        return (this._loanCreditsAmount != "") ? Number(this._loanCreditsAmount) : 0;
    }
    public set loanCreditsAmount(value: any) {
        this._loanCreditsAmount = value;
    }
    private _netCreditAmount: string = "";
    public get netCreditAmount(): any {
        let totalCreditAmount = Number(this.totalCreditAmount != "" ? this.totalCreditAmount : 0);
        let loanCreditsAmount = Number(this.loanCreditsAmount != "" ? this.loanCreditsAmount : 0);
        if (totalCreditAmount === 0 && loanCreditsAmount == 0) {
            return "";
        }
        else {
            return (totalCreditAmount - loanCreditsAmount);
        }
    }
    public set netCreditAmount(value: string) {
        this._netCreditAmount = value;
    }
    noOfOutwardChequesReceived: string = "";
    outwardChequeReturns: string = "";
    noOfInwardChequesIssued: string = "";
    inwardChequeReturns: string = "";
    editFieldName: string = "";

    toJSON(): any {
        return {
            "LoanAccountNumber": this.loanAccountNumber,
            "AccountNumber": this.accountNumber.toString(),
            "NoOfMonth": this.noOfMonth,
            "MonthAndYear": this.monthAndYear,
            "NoOfDebitEntries": this.noOfDebitEntries != "" ? Number(this.noOfDebitEntries) : 0,
            "TotalDebitAmount": this.totalDebitAmount!=""?Number(this.totalDebitAmount):0,
            "NoOfCreditEntries": this.noOfCreditEntries!=""?Number(this.noOfCreditEntries):0,
            "TotalCreditAmount": this.totalCreditAmount!=""?Number(this.totalCreditAmount):0,
            "LoanCreditsAmount": this.loanCreditsAmount != "" ? Number(this.loanCreditsAmount) : 0,
            "NetCreditAmount": this.netCreditAmount!=""?Number(this.netCreditAmount):0,
            "NoOfOutwardChequesReceived": this.noOfOutwardChequesReceived!=""?Number.parseInt(this.noOfOutwardChequesReceived):0,
            "OutwardChequeReturns": this.outwardChequeReturns!=""?Number.parseInt(this.outwardChequeReturns):0,
            "NoOfInwardChequesIssued": this.noOfInwardChequesIssued!=""?Number.parseInt(this.noOfInwardChequesIssued):0,
            "InwardChequeReturns": this.inwardChequeReturns!=""?Number.parseInt(this.inwardChequeReturns):0
        };
    }

    constructor(params?: ICustomerBankAccountDetail) {
        if (params) {
            this.loanAccountNumber = params.loanAccountNumber;
            this.accountNumber = params.accountNumber;
            this.noOfMonth = params.noOfMonth;
            this.monthAndYear = params.monthAndYear;
            this.noOfDebitEntries = params.noOfDebitEntries;
            this.totalDebitAmount = params.totalDebitAmount;
            this.noOfCreditEntries = params.noOfCreditEntries;
            this.totalCreditAmount = params.totalCreditAmount;
            this.loanCreditsAmount = params.loanCreditsAmount;
            this.netCreditAmount = params.netCreditAmount;
            this.noOfOutwardChequesReceived = params.noOfOutwardChequesReceived;
            this.outwardChequeReturns = params.outwardChequeReturns;
            this.noOfInwardChequesIssued = params.noOfInwardChequesIssued;
            this.inwardChequeReturns = params.inwardChequeReturns;
            this.editFieldName = params.editFieldName;

        }
    }

}

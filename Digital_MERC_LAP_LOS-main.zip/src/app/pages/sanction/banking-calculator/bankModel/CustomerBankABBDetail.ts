
export interface ICustomerBankABBDetail {
    loanAccountNumber: string;
    accountNumber: string;
    dateMonth: string;
    bal_1st: string;
    bal_5th: string;
    bal_10th: string;
    bal_15th: string;
    bal_20th: string;
    bal_25th: string;
    average: string;
    editFieldName: string;
    toJSON(): any;
}

export class CustomerBankABBDetail implements ICustomerBankABBDetail {
    accountNumber: string = "";
    dateMonth: string = "";
    bal_1st: string = "";
    bal_5th: string = "";
    bal_10th: string = "";
    bal_15th: string = "";
    bal_20th: string = "";
    bal_25th: string = "";
    public get average(): string {
        let bal_1st = this.bal_1st != "" ? Number(this.bal_1st) : 0;
        let bal_5th = this.bal_5th != "" ? Number(this.bal_5th) : 0;
        let bal_10th = this.bal_10th != "" ? Number(this.bal_10th) : 0;
        let bal_15th = this.bal_15th != "" ? Number(this.bal_15th) : 0;
        let bal_20th = this.bal_20th != "" ? Number(this.bal_20th) : 0;
        let bal_25th = this.bal_25th != "" ? Number(this.bal_25th) : 0;
        let total = ((bal_1st + bal_5th + bal_10th + bal_15th + bal_20th + bal_25th) / 6);
        return total == 0 ? "" : total.toFixed(2);

    }
   
    editFieldName: string = "";

    constructor(params?: ICustomerBankABBDetail) {
        if (params) {
            this.accountNumber = params.accountNumber;
            this.dateMonth = params.dateMonth;
            this.bal_1st = params.bal_1st ?? "";
            this.bal_5th = params.bal_5th ?? "";
            this.bal_10th = params.bal_10th ?? "";
            this.bal_15th = params.bal_15th ?? "";
            this.bal_20th = params.bal_20th ?? "";
            this.bal_25th = params.bal_25th ?? "";
            this.loanAccountNumber = params.loanAccountNumber ?? "";
        }
    }
    loanAccountNumber: string = "";
    toJSON(): any {
        return {
            LoanAccountNumber: this.loanAccountNumber,
            AccountNumber: this.accountNumber.toString(),
            DateMonth: this.dateMonth,
            Bal_1st: this.bal_1st != "" ? Number(this.bal_1st) : 0,
            Bal_5th: this.bal_5th != "" ? Number(this.bal_5th) : 0,
            Bal_10th: this.bal_10th != "" ? Number(this.bal_10th) : 0,
            Bal_15th: this.bal_15th != "" ? Number(this.bal_15th) : 0,
            Bal_20th: this.bal_20th != "" ? Number(this.bal_20th) : 0,
            Bal_25th: this.bal_25th != "" ? Number(this.bal_25th) : 0,
            Average: this.average != "" ? Number(this.average) :0,
        };
    };
}

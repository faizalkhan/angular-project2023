import * as BankDetails from "./bankDetails";

export const bankModule = [BankDetails]
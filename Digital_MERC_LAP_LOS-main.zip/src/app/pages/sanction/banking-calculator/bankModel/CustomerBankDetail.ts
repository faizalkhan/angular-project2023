import { animate } from "@angular/animations";
import { FileUpload } from "src/app/pages/layout/button/upload-view-download/upload-view-download.service";
import { IValidation } from "src/app/pages/layout/error-message/error-message.component";
import { common } from "src/app/shared/models/common";
import { CustomerBankABBDetail, ICustomerBankABBDetail } from "./CustomerBankABBDetail";
import { CustomerBankAccountDetail } from "./CustomerBankAccountDetail";

export interface ICustomerBankDetail {
    isEdit: boolean;
    GetMonthAndYear(a: number): any[];
    IsValidate(): IValidation;
    abbTotal?: any;
    bankName: string;
    accountNumber: string;
    ifscCode: string;
    accountHolderName: string;
    disbursement: string;
    branch: string;
    accountType: string;
    accountCategory: string;
    noofmonth: string;
    monthyear: string;
    customerBankAccountDetails: CustomerBankAccountDetail[];
    customerBankABBDetails: ICustomerBankABBDetail[];
    sum_NoOfDebitEntries?: any;
    sum_TotalDebitAmount?: any;
    sum_NoOfCreditEntries?: any;
    sum_TotalCreditAmount?: any;
    sum_LoanCreditsAmount?: any;
    sum_NetCreditAmount?: any;
    sum_NoOfOutwardChequesReceived?: any;
    sum_OutwardChequeReturns?: any;
    sum_NoOfInwardChequesIssued?: any;
    sum_InwardChequeReturns?: any;
    monthList: any[];
    loanAccountNumber: string;
    bankAccOrder: any;
    errorMessage: any;
    bankDetailId: string;
    documentId: string;
}

export class CustomerBankDetail implements ICustomerBankDetail {
    isSubmit: boolean = false;
    style: any;
    isEdit: boolean = true;
    fileUpload: FileUpload = new FileUpload();
    get abbTotal(): any {
        let val = (this.customerBankABBDetails.map(x => { return (x.average && x.average != "") ? Number(x.average) : 0; }).reduce((a, b) => a + b, 0) / 6);
        return val;
    };
    private _isDisbursement: boolean = false;
    public get isDisbursement(): boolean {
        return this._isDisbursement;
    }
    public set isDisbursement(value: boolean) {
        this._isDisbursement = value;
    }
    private _isDisable: boolean = false;
    public get isDisable(): boolean {
        if (this.bankName && this.bankName != "")
            return this._isDisable;
        else {
            return true;
        }
    }
    public set isDisable(value: boolean) {
        this._isDisable = value;
    }
    public get DocumentType() {
        return `${this.loanAccountNumber}_${this.accountNumber}`
    }
    bankDetailId: string = "";
    documentId: string = "";
    bankName: string = "";
    accountNumber: string = "";
    ifscCode: string = "";
    accountHolderName: string = "";
    disbursement: string = "";
    branch: string = "";
    accountType: string = "";
    accountCategory: string = "";
    noofmonth: string = "";
    monthyear: string = "";
    monthList: any[] = ["Jan", "Feb", "Mar", "	Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    bankAccOrder: any;
    private _customerBankAccountDetails: CustomerBankAccountDetail[] = [];
    public get customerBankAccountDetails(): CustomerBankAccountDetail[] {
        let accountNumber = this.accountNumber;
        if (this._customerBankAccountDetails.length < 6) {
            let temp: any[] = [];
            let _data = this.GetMonthAndYear(6).reverse();
            let _cust: CustomerBankAccountDetail;
            _data.forEach((x, i) => {
                let exists = this._customerBankAccountDetails.find(y => y.monthAndYear == x);
                if (exists) {
                    _cust = new CustomerBankAccountDetail(exists);
                }
                else {
                    _cust = new CustomerBankAccountDetail();
                    _cust.accountNumber = accountNumber;
                    _cust.monthAndYear = x;
                    _cust.noOfMonth = i.toString();
                }

                temp.push(_cust as CustomerBankAccountDetail);
            });
            console.debug(_data);
            this._customerBankAccountDetails = temp;
        }
        return this._customerBankAccountDetails ?? [];
    }
    public set customerBankAccountDetails(value: CustomerBankAccountDetail[]) {
        this._customerBankAccountDetails = value;
    }
    private _customerBankABBDetails: ICustomerBankABBDetail[] = [];
    public get customerBankABBDetails(): ICustomerBankABBDetail[] {
        let accountNumber = this.accountNumber;
        if (this._customerBankABBDetails.length < 6) {
            console.debug(this._customerBankABBDetails.length);
            let temp: any[] = [];
            let _data = this.GetMonthAndYear(6).reverse();
            _data.forEach(x => {
                let exists = this._customerBankABBDetails.find(y => y.dateMonth == x);
                if (exists) {
                    temp.push(new CustomerBankABBDetail(exists as ICustomerBankABBDetail));
                }

                else
                    temp.push(new CustomerBankABBDetail({ accountNumber: accountNumber, dateMonth: x } as ICustomerBankABBDetail));
            });
            console.debug(_data);
            this._customerBankABBDetails = temp;
        }
        return this._customerBankABBDetails ?? [];
    }
    public set customerBankABBDetails(value: ICustomerBankABBDetail[]) {
        this._customerBankABBDetails = value;
    }
    get sum_NoOfDebitEntries(): any {
        return this.customerBankAccountDetails.map(x => { return (x.noOfDebitEntries && x.noOfDebitEntries != "") ? Number(x.noOfDebitEntries) : 0; }).reduce((a, b) => a + b, 0);
    };
    get sum_TotalDebitAmount(): any {
        return this.customerBankAccountDetails.map(x => { return (x.totalDebitAmount && x.totalDebitAmount != "") ? Number(x.totalDebitAmount) : 0; }).reduce((a, b) => a + b, 0);
    };
    get sum_NoOfCreditEntries(): any {
        return this.customerBankAccountDetails.map(x => { return (x.noOfCreditEntries && x.noOfCreditEntries != "") ? Number(x.noOfCreditEntries) : 0; }).reduce((a, b) => a + b, 0);
    };
    get sum_TotalCreditAmount(): any {
        return this.customerBankAccountDetails.map(x => { return (x.totalCreditAmount && x.totalCreditAmount != "") ? Number(x.totalCreditAmount) : 0; }).reduce((a, b) => a + b, 0);
    };
    get sum_LoanCreditsAmount(): any {
        return this.customerBankAccountDetails.map(x => { return (x.loanCreditsAmount && x.loanCreditsAmount != "") ? Number(x.loanCreditsAmount) : 0; }).reduce((a, b) => a + b, 0);
    };
    get sum_NetCreditAmount(): any {
        return this.customerBankAccountDetails.map(x => {
            return (x.netCreditAmount && x.netCreditAmount != "") ? Number(x.netCreditAmount) : 0;
        }).reduce((a, b) => a + b, 0);
    };
    get sum_NoOfOutwardChequesReceived(): any {
        return this.customerBankAccountDetails.map(x => { return (x.noOfOutwardChequesReceived && x.noOfOutwardChequesReceived != "") ? Number(x.noOfOutwardChequesReceived) : 0; }).reduce((a, b) => a + b, 0);
    };
    get sum_OutwardChequeReturns(): any {
        return this.customerBankAccountDetails.map(x => { return (x.outwardChequeReturns && x.outwardChequeReturns != "") ? Number(x.outwardChequeReturns) : 0; }).reduce((a, b) => a + b, 0);
    };
    get sum_NoOfInwardChequesIssued(): any {
        return this.customerBankAccountDetails.map(x => { return (x.noOfInwardChequesIssued && x.noOfInwardChequesIssued != "") ? Number(x.noOfInwardChequesIssued) : 0; }).reduce((a, b) => a + b, 0);
    };
    get sum_InwardChequeReturns(): any {
        return this.customerBankAccountDetails.map(x => { return (x.inwardChequeReturns && x.inwardChequeReturns != "") ? Number(x.inwardChequeReturns) : 0; }).reduce((a, b) => a + b, 0);
    };
    GetMonthAndYear(a: number): any[] {
        let data: any[] = [];
        let noOfHours = (a * 30) * 24;
        let startDate = new Date(new Date().setHours(-noOfHours))
        let i = 0;
        do {
            data.unshift(`${this.monthList[startDate.getMonth()]}-${startDate.getFullYear()}`);
            startDate = new Date(startDate.setMonth(startDate.getMonth() + 1));
            i++;
        } while (i < a)
        return data;
    }
    constructor(params?: ICustomerBankDetail) {
        if (params) {
            this.bankName = params.bankName ?? "";
            this.accountNumber = params.accountNumber ?? "";
            this.ifscCode = params.ifscCode;
            this.accountHolderName = params.accountHolderName ?? "";
            this.disbursement = params.disbursement ?? "";
            this.branch = params.branch ?? "";
            this.accountType = params.accountType ?? "";
            this.accountCategory = params.accountCategory ?? "";
            this.noofmonth = params.noofmonth ?? "";
            this.monthyear = params.monthyear ?? "";
            this.customerBankAccountDetails = (params.customerBankAccountDetails) ? params.customerBankAccountDetails : [];
            this.customerBankABBDetails = (params.customerBankABBDetails) ? params.customerBankABBDetails : [];
            this.isEdit = false;
            this.bankAccOrder = params.bankAccOrder;
            this.loanAccountNumber = params.loanAccountNumber;
            this.bankDetailId = params.bankDetailId;
            this.documentId = params.documentId;
        }
    }


    loanAccountNumber: string = "";

    toJSON(): any {
        return {
            "LoanAccountNumber": this.loanAccountNumber,
            'BankName': this.bankName.toString(),
            "BankAccOrder": this.bankAccOrder.toString(),
            'Branch': this.branch.toString(),
            'AccountNumber': this.accountNumber.toString(),
            'AccountHolderName': this.accountHolderName.toString(),
            'IfscCode': this.ifscCode.toString(),
            'AccountType': this.accountType,
            'AccountCategory': this.accountCategory,
            'AbbTotal': this.abbTotal.toFixed(),
            'Sum_NoOfDebitEntries': this.sum_NoOfDebitEntries.toFixed(0),
            'Sum_TotalDebitAmount': this.sum_TotalDebitAmount != "" ? Number(this.sum_TotalDebitAmount) : 0,
            'Sum_NoOfCreditEntries': this.sum_NoOfCreditEntries != "" ? Number(this.sum_NoOfCreditEntries) : 0,
            'Sum_TotalCreditAmount': this.sum_TotalCreditAmount != "" ? Number(this.sum_TotalCreditAmount) : 0,
            'Sum_LoanCreditsAmount': this.sum_LoanCreditsAmount != "" ? Number(this.sum_LoanCreditsAmount) : 0,
            'Sum_NetCreditAmount': this.sum_NetCreditAmount != "" ? Number(this.sum_NetCreditAmount) : 0,
            'Sum_NoOfOutwardChequesReceived': this.sum_NoOfOutwardChequesReceived != "" ? Number.parseInt(this.sum_NoOfOutwardChequesReceived) : 0,
            'Sum_OutwardChequeReturns': this.sum_OutwardChequeReturns != "" ? Number.parseInt(this.sum_OutwardChequeReturns) : 0,
            'Sum_NoOfInwardChequesIssued': this.sum_NoOfInwardChequesIssued != "" ? Number.parseInt(this.sum_NoOfInwardChequesIssued) : 0,
            'Sum_InwardChequeReturns': this.sum_InwardChequeReturns != "" ? Number.parseInt(this.sum_InwardChequeReturns) : 0
        };
    }
    IsValidate(): IValidation {
        if (!this.accountNumber || this.accountNumber == "") {
            return {
                errorMessage: "Please select one bank account for disbursement"
            };
        }
        else
            return { errorMessage: "", isValid: true } as IValidation;
    }

    public get errorMessage(): any {
        if (!this.accountHolderName || this.accountHolderName == "") {
            return "Please enter the account holder name";
        }
        else if (!this.accountNumber || this.accountNumber == "") {
            return "Please enter the account number";
        }
        else if (!this.accountType || this.accountType == "") {
            return "Please enter the account type";
        }
        else if (!this.accountCategory || this.accountCategory == "") {
            return "Please enter the account category";
        }
        else if (!this.branch || this.branch == "") {
            return "Please enter the branch name";
        }
        else if (!this.ifscCode || this.ifscCode == "") {
            return "Please enter the IFSC";
        }
        else if (!common.isValid_IFSC_Code(this.ifscCode)) {
            return "Please enter valid IFSC";
        }
        else if (!this.bankName || this.bankName == "") {
            return "Please enter the bank name";
        }

        else
            return "";
    }

}


export interface IDocumentReferenceBanking {
    bankDetailId: string;
    documentId: string;
    accountNumber: string;
}
export class DocumentReferenceBanking implements IDocumentReferenceBanking {
    private _accountNumber: string = "";
    public get accountNumber(): string {
        return this._accountNumber;
    }
    public set accountNumber(value: string) {
        this._accountNumber = value;
    }
    private _bankDetailId: string = "";
    public get bankDetailId(): string {
        return this._bankDetailId;
    }
    public set bankDetailId(value: string) {
        this._bankDetailId = value;
    }
    private _documentId: string = "";
    public get documentId(): string {
        return this._documentId;
    }
    public set documentId(value: string) {
        this._documentId = value;
    }
}

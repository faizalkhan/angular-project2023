export class BankStatementUPL {  
    constructor(  
        UserID: string,
        LoanAccountNumber: string,
        BankDetailID: string,
        GL_Latitude: string,
        GL_Longitude: string,
        ImageData: string,
        MimeType: string,
        Ext: string  
    ){}  
}  
export class BankDisbDetails {  
    constructor(  
        disBank1Name: string,
        disBank1Accno: string,
        disBank1HolderName: string,
        disBank1IfsCode: string    
    ){}  
}  
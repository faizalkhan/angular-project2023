import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { IRequestModel, requestmodel } from 'src/app/shared/models/sanction/request.model';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { Observable } from 'rxjs';
import { InfoServices } from 'src/app/Injectable/info.services';
import { SanctionDashboardModel } from 'src/app/shared/models/sanction/dashboard';
import { NotificationService } from 'src/app/notification.service';
import { Dropdown, IDropdown } from 'src/app/shared/models/common/control.model';
import { FileUpload, IfileUpload, UploadViewDownloadService } from '../../layout/button/upload-view-download/upload-view-download.service';
import { Router } from '@angular/router';
import { IBankDetails, BankDetails } from './bankModel/bankDetails';
import { CustomerBankDetail, ICustomerBankDetail } from './bankModel/CustomerBankDetail';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { common } from 'src/app/shared/models/common';

@Component({
  selector: "app-page4",
  templateUrl: "./bankingcalculator.component.html",
  styleUrls: ["./bankingcalculator.component.css"],
  providers: [ConfigService]
})
export class BankCalculatorComponent implements OnInit {
  @ViewChild('myIdentifier')
  myIdentifier!: ElementRef;
  bankDetail: IBankDetails = new BankDetails();
  currentTabId: Number = 0;
  public get readonly(): boolean {
    return this.sanctionService.LanInfo.readOnly;
  }
  public get minimumABB(): any {
    return Number(this.bankDetail.totalOfABB) < 5000 ? "Deviation" : "No Deviation";
  }
  public get minimumCreditEntries(): any {
    return Number(this.bankDetail.totalOfCreditEntries) < 5 ? "Deviation" : "No Deviation";
  }

  public get minimumCreditAmount(): any {
    return Number(this.bankDetail.totalCreditAmount) < 5000 ? "Deviation" : "No Deviation";
  }

  public get maximumInwardReturn(): any {
    return Number(this.bankDetail.totalOfInwardReturn) > 3 ? "Deviation" : "No Deviation";;
  }


  accountType: IDropdown[] = [new Dropdown({ displayName: "Saving" }), new Dropdown({ displayName: "Current" })];
  acccategory: IDropdown[] = [new Dropdown({ displayName: "Joint Account" }), new Dropdown({ displayName: "Individual" })];
  get disbursement(): CustomerBankDetail {
    let data = this.bankDetail.customerBankDetails.find(x => x.isDisbursement) as CustomerBankDetail;
    if (data)
      return data;
    else
      return new CustomerBankDetail();
  }


  private _lanInfo: SanctionDashboardModel = new SanctionDashboardModel();
  public get lanInfo(): SanctionDashboardModel {
    return this._lanInfo;
  }
  public set lanInfo(value: SanctionDashboardModel) {
    this._lanInfo = value;
  }

  constructor(private http: ConfigService, private info: InfoServices, private notify: NotificationService,
    private route: Router, private uploadService: UploadViewDownloadService, private sanctionService: SanctionService) {
  }
  request: any;

  private _height: any;
  public get height(): any {
    return (this.myIdentifier) ? `${this.myIdentifier.nativeElement.offsetHeight}px !important` : `69px !important`;
  }
  public set height(value: any) {
    this._height = value;
  }
  getDisbBankDetails() {
    const request = new requestmodel({} as IRequestModel)
    request.UserID = this.sanctionService.userInfo.userId;
    request.LoanAccountNumber = this.sanctionService.LanInfo.lan;
    request.McCode = "MC919";
    return this.http.httpPost(request, 'LAP_GetApplicationDisbBankDetails').subscribe((res: any) => {
      this.bankDetail.disbursement = new CustomerBankDetail({ accountHolderName: res.bankAccountHolderName, accountNumber: res.bankAccountNumber, bankName: res.bankName, branch: res.branchName, ifscCode: res.ifscCode } as ICustomerBankDetail);
      this.bankDetail.customerBankDetails.forEach(x => {
        x.isDisbursement = res.bankAccountNumber == x.accountNumber;
      })
    })
  }
  Radiochange(item: CustomerBankDetail, event: any) {
    item.isDisbursement = event.toLowerCase() == "yes";
    this.bankDetail.disbursement = event.toLowerCase() == "yes" ? item : new CustomerBankDetail();
  }


  ngOnInit() {
    debugger;
    this.lanInfo = this.sanctionService.LanInfo;
    this.uploadService.uploadLoad = new FileUpload({
      flO_Id: this.lanInfo.flopsid,
      loanAccountNumber: this.lanInfo.lan,
      moduleName: "Banking Assessment",
      uuid: "LOS",
      leadID: this.lanInfo.leadId,
    } as IfileUpload);
    // Create request
    this.GetApplicationBankDetails()



  }

  GetApplicationBankDetails() {
    const request = {
      'UserID': this.sanctionService.userInfo.userId,
      'LoanAccountNumber': this.sanctionService.LanInfo.lan
    };

    this.http.httpPost<IBankDetails>(request, 'LAP_GetApplicationBankDetails').subscribe((res: IBankDetails) => {
      if (res.errorcode == '200') {
        res.loanAccountNumber = this.sanctionService.LanInfo.lan;
        this.bankDetail = new BankDetails(res);
      }
      else {
        this.notify.showError(res.errorDescription);
      }
    })
  }
  buttonName: string = "Add Bank 1st/2nd/3rd/4th";
  lst: any[] = ['1st', '2nd', '3rd', '4th'];
  AddMoreBank() {
    let valid = this.bankDetail.customerBankDetails.filter(x => {
      return x.errorMessage != "";

    }).length == 0
    let cust = new CustomerBankDetail();
    if (valid) {
      cust.bankAccOrder = this.bankDetail.customerBankDetails.length;
      this.bankDetail.customerBankDetails.push(cust);
      this.buttonName = `Add Bank ${common.range(this.lst, this.bankDetail.customerBankDetails.length).join('/')}`;
    }
    else {
      this.notify.showWarning("Please enter above bank detail");
    }
  }

  remove(i: number) {
    this.bankDetail.customerBankDetails.splice(i, 1);
    this.buttonName = `Add Bank ${common.range(this.lst, this.bankDetail.customerBankDetails.length).join('/')}`;
  }
  BankingSnapshot() {
    this.getDisbBankDetails();
  }
  submitDisbankingDetails() {

    let validation = this.disbursement.IsValidate();
    if (validation && validation.errorMessage == "") {
      var request = {
        "UserID": this.sanctionService.userInfo.userId,
        "LoanAccountNumber": this.sanctionService.LanInfo.lan,
        "BankName": this.disbursement.bankName, //"HDFC",
        "IfscCode": this.disbursement.ifscCode, //"HDFC000044",
        "BranchName": this.disbursement.branch,
        "BankAccountNumber": this.disbursement.accountNumber, //"Test123456",
        "BankAccountHolderName": this.disbursement.accountHolderName //"TEst"
      };
      this.http.httpPost(request, 'LAP_SubmitApplicationDisbBankDetails')
        .subscribe((res: any) => {
          if (res.errorcode == "200") {
            this.currentTabId = 2;
            this.notify.showSuccess(res.errorDescription);
          }
          else {
            this.notify.showError(res.errorDescription);
          }
        })
    }
    else {

      this.notify.showWarning(validation.errorMessage);
    }

  }


  onEdit() {
  }

  close() {
  }

  submitData() {

    let self = this;
    let valid = this.bankDetail.customerBankDetails.filter(x => {
      let _valid = x.errorMessage != "";
      if (_valid)
        self.notify.showWarning(x.errorMessage);
      return _valid;
    }).length == 0
    let dupicate = common.toFindDuplicates(this.bankDetail.customerBankDetails, 'accountNumber').length > 0;
    if (valid && dupicate)
      self.notify.showWarning('Account number is duplicate entry.');
    if (valid && !dupicate) {
      var request = {
        "UserID": this.sanctionService.userInfo.userId,
        "McCode": this.sanctionService.LanInfo.mcCode,
        "LoanAccountNumber": this.sanctionService.LanInfo.lan,
        "bankDetails": this.bankDetail.customerBankDetails.filter(x => x.errorMessage == "").map(x => {
          let data = x.toJSON();
          x.isEdit = false;
          data['LoanAccountNumber'] = this.sanctionService.LanInfo.lan;
          return data;
        }),
        "BankAccountDetails": this.bankDetail.GetAccountDetail(),
        "AbbDetails": this.bankDetail.GetAccountABBDetail(),

      };
      var request1 = {
        "UserID": this.sanctionService.userInfo.userId,
        "McCode": this.sanctionService.LanInfo.mcCode,
        "LoanAccountNumber": this.sanctionService.LanInfo.lan,
        "bankDetails": this.bankDetail.customerBankDetails.filter(x => x.errorMessage == "").map(x => {
          let data = x.toJSON();
          data['LoanAccountNumber'] = this.sanctionService.LanInfo.lan;
          return data;
        })

      };
      console.debug(request);
      this.http.httpPostWithouImageData(request, 'LAP_CustomerSubmitBankDetails', request1)
        .subscribe((res: any) => {
          if (res.errorcode == "200") {
            this.notify.showSuccess("Banking Details saved and submitted successfully.");
            this.ngOnInit();
          }
          else {
            this.notify.showError(res.errorDescription);
          }
        });
    }

  }
  View(event: any, item: any) {
  }
  save(fileInput: any, item: CustomerBankDetail) {
    let files: FileList = fileInput.target.files;
    if (fileInput.target.files && fileInput.target.files[0]) {
      // Size Filter Bytes

      const reader = new FileReader();
      reader.onload = (e: any) => {
        const imgBase64Path = e.target.result as string;
        item.fileUpload.imageData = imgBase64Path;
        item.fileUpload.imageMIMEType = fileInput.target.files[0].type;
        item.fileUpload.extension = fileInput.target.files[0].name.split('.').pop().toLowerCase();
        if (item.documentId != "") {

        }
      };

      reader.readAsDataURL(fileInput.target.files[0]);


    }
  }


  UploadBank1(item: CustomerBankDetail) {
    if (!item.fileUpload.imageData || item.fileUpload.imageData == "") {
      this.notify.showWarning("Please upload the documents..")
      return;
    }
    var request = {
      "UserID": this.sanctionService.userInfo.userId,
      "LoanAccountNumber": this.sanctionService.LanInfo.lan,
      "GL_Latitude": "",
      "GL_Longitude": "",
      "BankDetailID": item.accountNumber,
      "ImageData": item.fileUpload.imageData,
      "MimeType": item.fileUpload.imageMIMEType,
      "Ext": item.fileUpload.extension
    };

    var requestWithOut = {
      "UserID": this.sanctionService.userInfo.userId,
      "LoanAccountNumber": this.sanctionService.LanInfo.lan,
      "GL_Latitude": "",
      "GL_Longitude": "",
      "BankDetailID": item.accountNumber,
      "MimeType": item.fileUpload.imageMIMEType,
      "Ext": item.fileUpload.extension
    };
    this.http.httpPostWithouImageData(request, 'LAP_SaveBankStatementUPL', requestWithOut)
      .subscribe((res: any) => {
        if (res.errorcode == "0" || res.errorcode == "00" || res.errorcode == "01") {
          this.notify.showSuccess("Document uploaded successfully");
          this.currentTabId = 0;
        }
        else {
          this.notify.showError(res.errorDescription);
        }
      })
  }

  btnBack() {
    this.route.navigateByUrl("/pendingscreen");
  }
  onChange() {

  }
}


import { Component, OnInit } from '@angular/core';
import { InfoServices } from 'src/app/Injectable/info.services';
import { SanctionDashboardModel } from 'src/app/shared/models/sanction/dashboard';
import { NotificationService } from 'src/app/notification.service';
//import { MatAccordion, MatExpansionModule } from '@angular/material/expansion';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { ApprovalOrder, CamDetail, CreditCommentDetail, ICamDetail, ICreditCommentDetail } from "./camdetail.service";
import { IDropdown } from 'src/app/shared/models/common/control.model';
import { Menu } from 'src/app/shared/models/common/menu.model';
import { MenuResponse } from '../../layout/login/login.service';
import { UploadViewDownloadService } from '../../layout/button/upload-view-download/upload-view-download.service';
import { common } from 'src/app/shared/models/common';

import { masterModuleDropdown } from 'src/app/shared/models/sanction/masterDropdown'
import { MenuService } from '../../layout/header/menu-service.service';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { IModalCommon, ModalCommon, ModalService } from 'src/app/shared/services/modal/modal.service';


@Component({
  selector: 'app-cam-details',
  templateUrl: './camdetails.component.html',
  styleUrls: ['./camdetails.component.css'],
  providers: [ConfigService, MenuService]

})



export class CamDetailsComponent implements OnInit {
  private _isReject: boolean = true;
  public get isReject(): boolean {
    return this._isReject;
  }
  public set isReject(value: boolean) {
    this._isReject = value;
  }
  _CamDetail: ICamDetail = new CamDetail();
  RejectOption: IDropdown[] = masterModuleDropdown.RejectOption;
  CreditDesicion: IDropdown[] = [];
  currentTabId: number = 0;
  Result: IDropdown[] = masterModuleDropdown.CERSAIReportCheck;
  basicdetailInfo: boolean = false;
  ApplicantInfo: boolean = false;
  CollateralInfo: boolean = false;
  IncomeInfo: boolean = false;
  TermType: any[] = [];
  public get readonly(): any {
    return this.Info.readonly;
  }

  SelectOption: IDropdown[] = [
    { value: "N", displayName: "NO" },
    { value: "Y", displayName: "YES" }
  ];
  private _IsNotBCM: boolean = false;
  public get IsNotBCM(): boolean {
    return this._IsNotBCM;
  }
  public set IsNotBCM(value: boolean) {
    this._IsNotBCM = value;
  }
  constructor(private http: ConfigService,
    private notify: NotificationService,
    private Info: SanctionService,
    private download: UploadViewDownloadService, private modal: ModalService) { }



  ngOnInit(): void {
    this.IsNotBCM = this.Info.userInfo.roleName.toLowerCase() != "bcm";
    this.CreditDesicion = this.IsNotBCM ? masterModuleDropdown.CreditDesicionForL2 : masterModuleDropdown.CreditDesicionForL1;

    this.GetPersonalDetails();
  }

  GetPersonalDetails() {
    var data = {
      "userID": this.Info.userInfo.userId,
      "loanAccountNumber": this.Info.LanInfo.lan,
      "mcCode": "MC919"
    };
    this.http.httpPost<CamDetail>(data, 'LAP_GetLoanCamDeatils').subscribe((res: CamDetail) => {
      let current: ICreditCommentDetail;
      if (res.errorcode == "200") {
        this._CamDetail = new CamDetail(res);
        this._CamDetail.checkAndVerificationDetails.creditCommentDetails = this._CamDetail.checkAndVerificationDetails.creditCommentDetails.map(x => new CreditCommentDetail(x));
        current = this._CamDetail.checkAndVerificationDetails.creditCommentDetails[this._CamDetail.checkAndVerificationDetails.creditCommentDetails.length - 1];
        if (current) {
          if (current.userID == this.Info.userInfo.userId && (current.finalStatus == "" || current.finalStatus.toLowerCase() == 'save')) {
            current.isCurrentUser = true;
          }
          else if (this.getCurrentRoleOrder() > current.roleOrder && current.finalStatus.toLowerCase() == 'approve') {
            this.AddNewApproval();
          }
          else if (this.getCurrentRoleOrder() < current.roleOrder && current.finalStatus.toLowerCase() != 'approve') {
            this.AddNewApproval();
          }
        }
        else {
          this.AddNewApproval();
        }
        this.TermType = common.getTermType(Number(this._CamDetail.sanctionDetails.finalEligibleLoanAmt));
        this._CamDetail.loanAccountNumber = this.Info.LanInfo.lan;
        this._CamDetail.mcCode = this.Info.LanInfo.mcCode;
        this._CamDetail.userId = this.Info.userInfo.userId;
      }
      else {
        this.notify.showError(res.errorDescription);
      }
    })


  }
  AddNewApproval() {
    let current = new CreditCommentDetail();
    current.userName = this.Info.userInfo.userName
    current.roleName = this.Info.userInfo.roleName;
    current.userID = this.Info.userInfo.userId;
    current.role_id = this._CamDetail.checkAndVerificationDetails.creditCommentDetails.length.toString();
    current.isCurrentUser = (current.finalStatus == "" || current.finalStatus.toLowerCase() == "save");
    this._CamDetail.checkAndVerificationDetails.creditCommentDetails.push(current);
  }
  showDialog(documentId: any) {
    this.download.showModal(documentId);
  }
  savedata(a: any) {
    let creditCommentDetails = this._CamDetail.checkAndVerificationDetails.creditCommentDetails.find(x => x.isCurrentUser);
    if (creditCommentDetails) {
      if (a.toLowerCase() == 'reject') {
        if (!creditCommentDetails.rejectionReason || creditCommentDetails.rejectionReason == '') {
          this.notify.showWarning('Rejection Reason is required');
        }
        else {
          creditCommentDetails.status = creditCommentDetails.finalStatus = "Reject";
          this.finalSave('Reject')
        }

      }
      else if (a.toLowerCase() == 'approved') {

        if (!creditCommentDetails.creditRemark || creditCommentDetails.creditRemark == '') {
          this.notify.showWarning('Credit remark is required');

        }
        else if (!creditCommentDetails.caseSummary || creditCommentDetails.caseSummary == '') {
          this.isReject = false;
          this.notify.showWarning('Case summary is required');
        }
        else if (!creditCommentDetails.sanctionCondition || creditCommentDetails.sanctionCondition == '') {
          this.notify.showWarning('sanction condition is required');
        }
        
        else if (!this._CamDetail.personalDetailsCompleted) {
          this.notify.showWarning('Personal Details Section is not completed!! Kindly complete to proceed with CAM approval.');
        }
        else if (!this._CamDetail.businessDetailsCompleted) {
          this.notify.showWarning('Business Details Section is not completed!! Kindly complete to proceed with CAM approval.');
        }
        else if (!this._CamDetail.referenceChecked_YN) {
          this.notify.showWarning('Reference Details Section is not completed!! Kindly complete to proceed with CAM approval.');
        }
        else if (!this._CamDetail.householdAssesment_YN) {
          this.notify.showWarning('Household Assessment Section is not completed!! Kindly complete to proceed with CAM approval.');
        }
        else if (!this._CamDetail.propertyValuation_YN) {
          this.notify.showWarning('Property Valuation Section is not completed!! Kindly complete to proceed with CAM approval.');
        }
        else if (!this._CamDetail.disbursmentCompleted) {
          this.notify.showWarning('Banking Assessment is not completed!! Kindly complete to proceed with CAM approval. ');
        }
        else if (!this._CamDetail.bankStateCompleted) {
          this.notify.showWarning('Banking Account Statements not uploaded for all Banks input!! Kindly upload to proceed with CAM approval. ');
        }
        else if (!this._CamDetail.legalStatus) {
          this.notify.showWarning('Legal Check not completed!! Kindly complete to proceed with CAM approval.');
        }
        else if (!this._CamDetail.technicalStatus_YN) {
          this.notify.showWarning('Technical Check not completed!! Kindly complete to proceed with CAM approval.');
        }
        else if (!this._CamDetail.incomeEligibility_YN) {
          this.notify.showWarning('Income Eligibility not completed!! Kindly complete to proceed with CAM approval. ');
        }
        else if (!this._CamDetail.preSancRCU_Status) {
          this.notify.showWarning('RCU Presanction Stage is not completed. CAM can be approved post completion of the same.');
        }
        else {
          creditCommentDetails.status = creditCommentDetails.finalStatus = "Approve";
          this.Info.readonlySubject.next(true);
          this.finalSave('Approve')
        }

      }
      else if (a.toLowerCase() == 'send back') {
        creditCommentDetails.status = creditCommentDetails.finalStatus = "SendBack";
        this.finalSave('Send Back')
      }
      else {
        creditCommentDetails.status = creditCommentDetails.finalStatus = "Save";
        this.finalSave('Save')
      }

    }



  }
  getCurrentRoleOrder(): ApprovalOrder {
    let _approvalOrder: ApprovalOrder = 1;
    switch (this.Info.userInfo.roleName.toLowerCase()) {
      case 'bcm':
        _approvalOrder = ApprovalOrder.BCM;
        break;
      case 'acm':
        _approvalOrder = ApprovalOrder.ACM;
        break;
      case 'rcm':
        _approvalOrder = ApprovalOrder.RCM;
        break;
      case 'zcm':
        _approvalOrder = ApprovalOrder.ZCM;
        break;
      default:
        _approvalOrder = ApprovalOrder.BCM;
        break
    }
    return _approvalOrder;
  }
  finalSave(a: any) {

    let Action: Function = () => {

      this.http.httpPost<any>(this._CamDetail.toJson(), 'LAP_SubmitLoanCamStatus').subscribe((res: any) => {
        if (res.errorcode == "200") {
          this.isReject = true;
          this.notify.showSuccess(res.errorDescription);
          this.GetPersonalDetails();
        }
        else {
          this.notify.showWarning(res.errorDescription);
          this.ngOnInit();
        }
      })
    }

    let modal = new ModalCommon({
      title: "Confirmation",
      message: `Are you sure you want to ${a}? Please confirm to proceed.?`,
      sAction: Action,
      sActionText: 'Confirm',
      sActionShow: true
    } as IModalCommon);
    this.modal.ShowModal(modal);
  }

}


import { common } from "src/app/shared/models/common";

export interface IAppCoAppDetail {
    applicantType: string;
    applicantName: string;
    currentAddress: string;
    age: string;
    relWithApp: string;
    incomeEarningYN: string;
    propertyOwnerYN: string;
    profile: string;
    bureauReferenceNumber: string;
}

export class AppCoAppDetail implements IAppCoAppDetail {
    private _applicantType: string = "";
    public get applicantType(): string {
        let value = "";
        switch (this._applicantType.toLowerCase()) {
            case 'a':
                value = "Applicant";
                break;
            case "ca1":
                value = "Primary Co-applicant";
                break;
            case "ca2":
            case "ca3":
            case "ca4":
            case "ca5":
                value = "Co-applicant";
                break;

        }
        return value;
    }
    public set applicantType(value: string) {

        this._applicantType = value;
    }
    applicantName: string = "";
    currentAddress: string = "";
    age: string = "";
    relWithApp: string = "";
    incomeEarningYN: string = "";
    private _propertyOwnerYN: string = "";
    public get propertyOwnerYN(): string {
        return this._propertyOwnerYN == 'Y' ? "Yes" : "No";
    }
    public set propertyOwnerYN(value: string) {
        this._propertyOwnerYN = value;
    }
    private _profile: string = "";
    public get profile(): string {
        return this._profile == "" ? "Non-financial" : this._profile;
    }
    public set profile(value: string) {
        this._profile = value;
    }

    constructor(params?: IAppCoAppDetail) {
        if (params) {
            this.applicantType = params.applicantType;
            this.applicantName = params.applicantName;
            this.currentAddress = params.currentAddress;
            this.age = params.age;
            this.relWithApp = params.relWithApp;
            this.incomeEarningYN = params.incomeEarningYN;
            this.propertyOwnerYN = params.propertyOwnerYN;
            this.profile = params.profile;
            this.bureauReferenceNumber = params.bureauReferenceNumber;
        }
    }
    bureauReferenceNumber: string = "";
}

export interface IDetailsOfCollaterals {
    propertyType: string;
    occupancy: string;
    locationOfProperty: string;
    landAreaPerDoc: string;
    marketVal1: string;
    marketVal2: string;
    ltv: string;
    eligibleLoanAmt: string;
    legalOpinion: string;
    cersaiReport: string;
    cersaiResult: string;
    bcmName: string;
    technicalAgencyName: string;
    agreementValueAsPerSaleDeed: any;
    agreementDate: any;
    technicalStatus: string;
}
export class DetailsOfCollaterals implements IDetailsOfCollaterals {
    propertyType: string = "";
    occupancy: string = "";
    locationOfProperty: string = "";
    landAreaPerDoc: string = "";
    marketVal1: string = "";
    marketVal2: string = "";
    ltv: string = "";
    eligibleLoanAmt: string = "";
    legalOpinion: string = "";
    cersaiReport: string = "";
    cersaiResult: string = "";
    bcmName: string = "";
    technicalAgencyName: string = "";


    constructor(params?: IDetailsOfCollaterals) {
        if (params) {
            this.propertyType = params.propertyType;
            this.occupancy = params.occupancy;
            this.locationOfProperty = params.locationOfProperty;
            this.landAreaPerDoc = params.landAreaPerDoc;
            this.marketVal1 = params.marketVal1;
            this.marketVal2 = params.marketVal2;
            this.ltv = params.ltv;
            this.eligibleLoanAmt = params.eligibleLoanAmt;
            this.legalOpinion = params.legalOpinion;
            this.cersaiReport = params.cersaiReport;
            this.cersaiResult = params.cersaiResult;
            this.bcmName = params.bcmName;
            this.technicalAgencyName = params.technicalAgencyName;
            this.agreementValueAsPerSaleDeed = params.agreementValueAsPerSaleDeed;
            this.agreementDate = params.agreementDate;
            this.technicalStatus = params.technicalStatus;
        }
    }
    technicalStatus: string = "";
    agreementValueAsPerSaleDeed: number = 0;
    agreementDate: Date = new Date();


}
export interface IApplicantIncomeAssesment {
    applicationId: string;
    name: string;
    incomeSource: string;
    amount: string;
}
export class ApplicantIncomeAssesment implements IApplicantIncomeAssesment {
    applicationId: string = "";
    name: string = "";
    incomeSource: string = "";
    amount: string = "";

    constructor(params: IApplicantIncomeAssesment) {
        if (params) {
            this.applicationId = params.applicationId;
            this.name = params.name;
            this.incomeSource = params.incomeSource;
            this.amount = params.amount;
        }
    }

}
export interface IApplicationABBDetails {
    abb_Dev_YN: string;
    abbValue: string;
}

export class ApplicationABBDetails implements IApplicationABBDetails {
    abb_Dev_YN: string = "";
    abbValue: string = "";
    constructor(params?: IApplicationABBDetails) {
        if (params) {
            this.abb_Dev_YN = (params.abb_Dev_YN && params.abb_Dev_YN != null) ? params.abb_Dev_YN : "";
            this.abbValue = (params.abbValue && params.abbValue != null) ? params.abbValue : "";
        }
    }
}

export interface IAbBEmiRatio {
    abbValue: string;
    maxServiceableValue: string;
    serviceableEMIRatio: string;
    abb_EmiRatio_dev_YN: string;
    abb_EmiRatio_dev: string;
}
export class AbBEmiRatio implements IAbBEmiRatio {
    private _abbValue: string = "";
    public get abbValue(): string {
        return this._abbValue;
    }
    public set abbValue(value: string) {
        this._abbValue = value;
    }
    private _maxServiceableValue: string = "";
    public get maxServiceableValue(): string {
        return this._maxServiceableValue;
    }
    public set maxServiceableValue(value: string) {
        this._maxServiceableValue = value;
    }
    private _serviceableEMIRatio: string = "";
    public get serviceableEMIRatio(): string {
        return this._serviceableEMIRatio;
    }
    public set serviceableEMIRatio(value: string) {
        this._serviceableEMIRatio = value;
    }
    private _abb_EmiRatio_dev_YN: string = "";
    public get abb_EmiRatio_dev_YN(): string {
        return this._abb_EmiRatio_dev_YN;
    }
    public set abb_EmiRatio_dev_YN(value: string) {
        this._abb_EmiRatio_dev_YN = value;
    }
    constructor(params?: IAbBEmiRatio) {
        if (params) {
            common.ObjectMapping(params, this);
        }
    }
    public get abb_EmiRatio_dev(): string {
        return this._abb_EmiRatio_dev_YN.toLowerCase() == 'y' ? 'Deviation' : 'No Deviation';
    }


}
export interface ILoanDisbursementDetail {
    bankName: string;
    accountNumber: string;
    accountHolderName: string;
    ifscCode?: any;
    branch: string;
}
export class LoanDisbursementDetail implements ILoanDisbursementDetail {
    bankName: string = "";
    accountNumber: string = "";
    accountHolderName: string = "";
    ifscCode?: any = "";
    branch: string = "";
    constructor(params?: ILoanDisbursementDetail) {
        if (params) {
            this.bankName = params.bankName;
            this.accountHolderName = params.accountHolderName;
            this.accountNumber = params.accountNumber;
            this.ifscCode = params.ifscCode;
            this.branch = params.branch;
        }
    }
}
export interface IApplicationBankingDetail {
    applicationABBDetails: IApplicationABBDetails;
    abB_EmiRatio: IAbBEmiRatio;
    creditAmtDev_YN: string;
    minimumCreditAmount: string;
    inwardReturnsDev_YN: string;
    sum_InwardChequeReturns: string;
    maximumInwardReturns: string;
    loanDisbursementDetail: ILoanDisbursementDetail;

}
export class ApplicationBankingDetail implements IApplicationBankingDetail {
    applicationABBDetails: IApplicationABBDetails = new ApplicationABBDetails();
    abB_EmiRatio: IAbBEmiRatio = new AbBEmiRatio();
    creditAmtDev_YN: string = "";
    minimumCreditAmount: string = "";
    inwardReturnsDev_YN: string = "";
    sum_InwardChequeReturns: string = "";
    maximumInwardReturns: string = "";
    loanDisbursementDetail: ILoanDisbursementDetail = new LoanDisbursementDetail();

    constructor(params?: IApplicationBankingDetail) {
        if (params) {
            this.applicationABBDetails = new ApplicationABBDetails(params.applicationABBDetails);
            this.abB_EmiRatio = new AbBEmiRatio(params.abB_EmiRatio);
            this.creditAmtDev_YN = params.creditAmtDev_YN;
            this.minimumCreditAmount = params.minimumCreditAmount;
            this.inwardReturnsDev_YN = params.inwardReturnsDev_YN;
            this.sum_InwardChequeReturns = params.sum_InwardChequeReturns;
            this.maximumInwardReturns = params.maximumInwardReturns;
            this.loanDisbursementDetail = new LoanDisbursementDetail(params.loanDisbursementDetail);
        }
    }

}
export interface ISanctionDetails {
    eligibleLoanAmtBaseOnPropVal: string;
    eligibleLoanAmtBaseOnIncome: string;
    appliedLoanAmt: any;
    finalEligibleLoanAmt: any;
    sanctionTenure: string;
    emi: string;
    appliedTenure: string;
    roi: string;
    Emicalc(): any;
}
export class SanctionDetails implements ISanctionDetails {
    eligibleLoanAmtBaseOnPropVal: string = "";
    eligibleLoanAmtBaseOnIncome: string = "";
    appliedLoanAmt: string = "";
    private _finalEligibleLoanAmt: any = "";
    public get finalEligibleLoanAmt(): any {
        return this._finalEligibleLoanAmt;
    }
    public set finalEligibleLoanAmt(value: any) {
        this._finalEligibleLoanAmt = value;
        this.Emicalc();
    }
    private _sanctionTenure: string = "";
    public get sanctionTenure(): string {
        return this._sanctionTenure;
    }
    public set sanctionTenure(value: string) {
        this._sanctionTenure = value;
        this.Emicalc();

    }
    private _appliedTenure: string = "";
    public get appliedTenure(): string {
        return this._appliedTenure;
    }
    public set appliedTenure(value: string) {
        this._appliedTenure = value;
    }
    private _roi: string = "";
    public get roi(): string {
        return this._roi;
    }
    public set roi(value: string) {
        this._roi = value;
        this.Emicalc();
    }
    Emicalc() {
        if (this.finalEligibleLoanAmt && this.finalEligibleLoanAmt != "") {
            let inretestRate = (this.roi && this.roi != "") ? Number(this.roi) : 0;
            inretestRate = (inretestRate / 100) / 12;
            let amount = (this.finalEligibleLoanAmt && this.finalEligibleLoanAmt != "") ? Number(this.finalEligibleLoanAmt) : 0;
            this.emi = common.emiCalc(inretestRate, Number(this.sanctionTenure), 0, 0, amount).toFixed(2);
        }
        else
            this.emi = "";
    }
    constructor(params?: ISanctionDetails) {
        if (params) {
            this.eligibleLoanAmtBaseOnPropVal = params.eligibleLoanAmtBaseOnPropVal;
            this.eligibleLoanAmtBaseOnIncome = params.eligibleLoanAmtBaseOnIncome;
            this.appliedLoanAmt = params.appliedLoanAmt;
            this.finalEligibleLoanAmt = params.finalEligibleLoanAmt;
            this.sanctionTenure = params.sanctionTenure;
            this.appliedTenure = params.appliedTenure;
            this.roi = params.roi;
            this.Emicalc();
        }
    }
    private _emi: string = "";
    public get emi(): string {
        return this._emi;
    }
    public set emi(value: string) {
        this._emi = value;
    }
}

export interface INormsDetails {
    Result: any;
    DeviationYN: any;
    Authority: any;
    Comment: any;
}
export class NormsDetails implements INormsDetails {
    Result: any = "";
    DeviationYN: any = "";
    Authority: any = "";
    Comment: any = "";
    constructor(params?: INormsDetails) {
        if (params) {
            this.Result = params.Result;
            this.DeviationYN = params.DeviationYN;
            this.Authority = params.Authority;
            this.Comment = params.Comment;

        }
    }
}

export interface ICamDetail {
    userId: any;
    mcCode: any;
    errorcode: string;
    errorDescription: string;
    loanAccountNumber: string;
    loginDate: string;
    scheme: string;
    branchID: string;
    branchName: string;
    roi: string;
    applicantName: string;
    residentAddress: string;
    propertyAddress: string;
    businessAddress: string;
    mobileNo: string;
    appCoAppDetails: IAppCoAppDetail[];
    detailsOfCollaterals: IDetailsOfCollaterals;
    applicantIncomeAssesment: IApplicantIncomeAssesment[];
    houseHoldIncome: string;
    foir: string;
    maxServiceIncomeEMI: string;
    eligibleLoanAmount: string;
    applicationBankingDetail: IApplicationBankingDetail;
    sanctionDetails: ISanctionDetails;
    checkAndVerificationDetails: ICheckAndVerificationDetails;
    groupedApplicantIA: GroupedValue[];
    referenceChecked_YN: boolean;
    householdAssesment_YN: boolean;
    incomeAssesment_YN: boolean;
    propertyValuation_YN: boolean;
    legalStatus: boolean;
    technicalStatus_YN: boolean;
    incomeEligibility_YN: boolean;
    disbursmentCompleted: boolean;
    bankStateCompleted: boolean;
    personalDetailsCompleted: boolean;
    businessDetailsCompleted: boolean;
    preSancRCU_Status: boolean;
    toJson(): any;
}
export interface GroupedValue {
    groupName: any;
    displayName: any;
    headerName: any;
    values: any[];
}
export class CamDetail implements ICamDetail {
    errorcode: string = "";
    errorDescription: string = "";
    loanAccountNumber: string = "";
    loginDate: string = "";
    scheme: string = "";
    branchID: string = "";
    branchName: string = "";
    roi: string = "";
    applicantName: string = "";
    residentAddress: string = "";
    propertyAddress: string = "";
    businessAddress: string = "";
    mobileNo: string = "";
    appCoAppDetails: IAppCoAppDetail[] = [];
    detailsOfCollaterals: IDetailsOfCollaterals = new DetailsOfCollaterals();
    applicantIncomeAssesment: IApplicantIncomeAssesment[] = [];
    userId: any = "";
    mcCode: any = "";
    public get groupedApplicantIA(): GroupedValue[] {
        let gropValues: GroupedValue[] = [];
        this.applicantIncomeAssesment?.forEach(x => {
            let _grbVal = gropValues.find((res: GroupedValue) => res.groupName.toLowerCase() == x.applicationId.toLowerCase());
            if (_grbVal) {
                _grbVal.values.push({
                    applicationId: x.applicationId,
                    name: x.name,
                    incomeSource: x.incomeSource,
                    amount: x.amount
                });
            }
            else {
                let value = {
                    displayName: x.name,
                    headerName: `${x.applicationId} - ${x.name}`,
                    groupName: x.applicationId, values: [{
                        applicationId: x.applicationId,
                        name: x.name,
                        incomeSource: x.incomeSource,
                        amount: x.amount,
                        isEdit: false
                    }]
                } as GroupedValue;

                gropValues.push(value);
            }
        });
        return gropValues;
    }
    houseHoldIncome: string = "";
    foir: string = "";
    maxServiceIncomeEMI: string = "";
    eligibleLoanAmount: string = "";
    applicationBankingDetail: IApplicationBankingDetail = new ApplicationBankingDetail();
    sanctionDetails: ISanctionDetails = new SanctionDetails();
    checkAndVerificationDetails: ICheckAndVerificationDetails = new CheckAndVerificationDetails();
    referenceChecked_YN: boolean = false;
    householdAssesment_YN: boolean = false;
    incomeAssesment_YN: boolean = false;
    propertyValuation_YN: boolean = false;
    legalStatus: boolean = false;
    technicalStatus_YN: boolean = false;
    incomeEligibility_YN: boolean = false;
    disbursmentCompleted: boolean = false;
    bankStateCompleted: boolean = false;
    constructor(params?: ICamDetail) {
        if (params) {
            this.errorcode = params.errorcode;
            this.errorDescription = params.errorDescription;
            this.loanAccountNumber = params.loanAccountNumber;
            this.loginDate = params.loginDate;
            this.scheme = params.scheme;
            this.branchID = params.branchID;
            this.branchName = params.branchName;
            this.roi = params.roi;
            this.applicantName = params.applicantName;
            this.residentAddress = params.residentAddress;
            this.propertyAddress = params.propertyAddress;
            this.businessAddress = params.businessAddress;
            this.mobileNo = params.mobileNo;
            this.appCoAppDetails = params.appCoAppDetails.map(x => { return new AppCoAppDetail(x) });
            this.detailsOfCollaterals = params.detailsOfCollaterals;
            this.applicantIncomeAssesment = params.applicantIncomeAssesment;
            this.houseHoldIncome = params.houseHoldIncome;
            this.foir = params.foir;
            this.maxServiceIncomeEMI = params.maxServiceIncomeEMI;
            this.eligibleLoanAmount = params.eligibleLoanAmount;
            this.applicationBankingDetail = new ApplicationBankingDetail(params.applicationBankingDetail);
            this.sanctionDetails = new SanctionDetails(params.sanctionDetails);
            this.checkAndVerificationDetails = new CheckAndVerificationDetails(params.checkAndVerificationDetails);
            this.referenceChecked_YN = params.referenceChecked_YN;
            this.householdAssesment_YN = params.householdAssesment_YN;
            this.incomeAssesment_YN = params.incomeAssesment_YN;
            this.propertyValuation_YN = params.propertyValuation_YN;
            this.legalStatus = params.legalStatus;
            this.technicalStatus_YN = params.technicalStatus_YN;
            this.incomeEligibility_YN = params.incomeEligibility_YN;
            this.disbursmentCompleted = params.disbursmentCompleted;
            this.bankStateCompleted = params.bankStateCompleted;
            this.personalDetailsCompleted = params.personalDetailsCompleted;
            this.businessDetailsCompleted = params.businessDetailsCompleted;
            this.preSancRCU_Status = params.preSancRCU_Status;

        }
    }
    preSancRCU_Status: boolean = false;
    personalDetailsCompleted: boolean = false;
    businessDetailsCompleted: boolean = false;

    toJson() {
        let current = this.checkAndVerificationDetails.creditCommentDetails.find((x: any) => x.isCurrentUser)
        return {
            "UserID": this.userId,
            "McCode": this.mcCode,
            "LoanAccountNumber": this.loanAccountNumber,
            CpvResiResult: this.checkAndVerificationDetails.cpvResi.cpvResiResult,
            "AgreementDate": this.detailsOfCollaterals.agreementDate,
            "AgreementValueAsPerSaleDeed": this.detailsOfCollaterals.agreementValueAsPerSaleDeed,
            "ReferenceCheck_Comment": this.checkAndVerificationDetails.refDetails.referenceCheckResult,
            BureauCheck_Comment: this.checkAndVerificationDetails.bureauDetails.bureauCheckComment,
            CpvResiComment: this.checkAndVerificationDetails.cpvResi.cpvResiComment,
            CpvOfficeComment: this.checkAndVerificationDetails.cpvOffice.cpvOfficeComment,
            CpvOfficeResult: this.checkAndVerificationDetails.cpvOffice.cpvOfficeResult,
            AgeNorms_Comments: this.checkAndVerificationDetails.ageNormsDetails.ageNormsComments,
            Business_Vintage_Comments: this.checkAndVerificationDetails.businessNorms.businessVintageComments,
            PropertyArea_Comments: this.checkAndVerificationDetails.propertyDevDetail.propertyAreaComments,
            Ltv_Comments: this.checkAndVerificationDetails.ltvDev.ltvDeviation,
            RCU_Comments: this.checkAndVerificationDetails.rcuDev.rcuResult,
            "CreditDecision": current?.creditDecision,
            "CreditRemark": current?.creditRemark,
            "SanctionCondition": current?.sanctionCondition,
            "FinalStatus": current?.finalStatus,
            "RejectionReason": current?.rejectionReason,
            "RejectReasonDtl": current?.rejectReasonDtl,
            "CaseSummary": current?.caseSummary,
            "Status": current?.status,
            "RoleName": current?.roleName,
            "SanctionTenure": Number(this.sanctionDetails.sanctionTenure),
            "ROI": this.sanctionDetails.roi,
            "FinalEligibleAmount": this.sanctionDetails.finalEligibleLoanAmt
        };
    }
}


export interface IBureauDetails {
    bureauCheckResult: any;
    bureauCheckDeviation: any;
    bureauCheckAuthority: any;
    bureauCheckComment: any;
}
export class BureauDetails implements IBureauDetails {
    bureauCheckResult: any;
    bureauCheckDeviation: any;
    bureauCheckAuthority: any;
    bureauCheckComment: any;
    constructor(params?: IBureauDetails) {
        if (params) {
            this.bureauCheckResult = params.bureauCheckResult;
            this.bureauCheckDeviation = params.bureauCheckDeviation;
            this.bureauCheckAuthority = params.bureauCheckAuthority;
            this.bureauCheckComment = params.bureauCheckComment;
        }
    }
}
export class CpvResi {
    cpvResiResult?: any;
    cpvResiComment?: any;
}

export class CpvOffice {
    cpvOfficeResult?: any;
    cpvOfficeComment?: any;
}

export class AgeNormsDetails {
    ageNormsResult?: any;
    ageNormsDeviationYN?: any;
    ageNormsAuthority?: any;
    ageNormsComments?: any;
}

export class BusinessNorms {
    businessVintageResult?: any;
    businessVintageDeviation?: any;
    businessVintageAuthority?: any;
    businessVintageComments?: any;
}

export class PropertyDevDetail {
    propertyAreaResult?: any;
    propertyAreaDeviation?: any;
    propertyAreaAuthority?: any;
    propertyAreaComments?: any;
}

export class LtvDev {
    ltvResult?: any;
    ltvDeviation?: any;
    ltvAuthority?: any;
    ltvComments?: any;
}

export class RcuDev {
    rcuResult?: any;
    rcuRemark?: any;
    rcuComments?: any;
}

export interface ICheckAndVerificationDetails {
    refDetails: any;
    bureauDetails: BureauDetails;
    cpvResi: CpvResi;
    cpvOffice: CpvOffice;
    ageNormsDetails: AgeNormsDetails;
    businessNorms: BusinessNorms;
    propertyDevDetail: PropertyDevDetail;
    ltvDev: LtvDev;
    rcuDev: RcuDev;
    creditCommentDetails: ICreditCommentDetail[];
}
export class CheckAndVerificationDetails implements ICheckAndVerificationDetails {
    refDetails: any = {};
    bureauDetails: IBureauDetails = {} as IBureauDetails;
    cpvResi: CpvResi = {} as CpvResi;
    cpvOffice: CpvOffice = {} as CpvOffice;
    ageNormsDetails: AgeNormsDetails = {} as AgeNormsDetails;
    businessNorms: BusinessNorms = {} as BusinessNorms;
    propertyDevDetail: PropertyDevDetail = {} as PropertyDevDetail;
    ltvDev: LtvDev = {} as LtvDev;
    rcuDev: RcuDev = {} as RcuDev;
    private _creditCommentDetails: ICreditCommentDetail[] = [];
    public get creditCommentDetails(): ICreditCommentDetail[] {
        return this._creditCommentDetails;
    }
    public set creditCommentDetails(value: ICreditCommentDetail[]) {
        this._creditCommentDetails = value;
    }

    constructor(params?: ICheckAndVerificationDetails) {
        if (params) {
            this.refDetails = params.refDetails;
            this.bureauDetails = new BureauDetails(params.bureauDetails);
            this.cpvResi = params.cpvResi;
            this.cpvOffice = params.cpvOffice;
            this.ageNormsDetails = params.ageNormsDetails;
            this.businessNorms = params.businessNorms;
            this.propertyDevDetail = params.propertyDevDetail;
            this.ltvDev = params.ltvDev;
            this.rcuDev = params.rcuDev;
            this.creditCommentDetails = params.creditCommentDetails.map((x: ICreditCommentDetail) => { return new CreditCommentDetail(x); })
        }
    }

}
export interface ICreditCommentDetail {
    creditDecision: string;
    creditRemark: string;
    sanctionCondition: string;
    finalStatus: string;
    rejectionReason: string;
    rejectReasonDtl: string;
    caseSummary: string;
    status: string;
    cS_id: string;
    userID: string;
    userName: string;
    roleName: string;
    role_id: string;
    roleOrder: ApprovalOrder;
    isCurrentUser: boolean;
    CreatedDate: Date;
}

export class CreditCommentDetail implements ICreditCommentDetail {
    private _creditDecision: string = "";
    public get creditDecision(): string {
        return this._creditDecision;
    }
    public set creditDecision(value: string) {
        this._creditDecision = value;
    }
    private _creditRemark: string = "";
    public get creditRemark(): string {
        return this._creditRemark;
    }
    public set creditRemark(value: string) {
        this._creditRemark = value;
    }
    private _sanctionCondition: string = "";
    public get sanctionCondition(): string {
        return this._sanctionCondition;
    }
    public set sanctionCondition(value: string) {
        this._sanctionCondition = value;
    }
    private _finalStatus: string = "";
    public get finalStatus(): string {
        return this._finalStatus;
    }
    public set finalStatus(value: string) {
        this._finalStatus = value;
    }
    private _rejectionReason: string = "";
    public get rejectionReason(): string {
        return this._rejectionReason;
    }
    public set rejectionReason(value: string) {
        this._rejectionReason = value;
    }
    private _rejectReasonDtl: string = "";
    public get rejectReasonDtl(): string {
        return this._rejectReasonDtl;
    }
    public set rejectReasonDtl(value: string) {
        this._rejectReasonDtl = value;
    }
    private _caseSummary: string = "";
    public get caseSummary(): string {
        return this._caseSummary;
    }
    public set caseSummary(value: string) {
        this._caseSummary = value;
    }
    private _status: string = "";
    public get status(): string {
        return this._status;
    }
    public set status(value: string) {
        this._status = value;
    }
    private _cS_id: string = "";
    public get cS_id(): string {
        return this._cS_id;
    }
    public set cS_id(value: string) {
        this._cS_id = value;
    }
    private _userID: string = "";
    public get userID(): string {
        return this._userID;
    }
    public set userID(value: string) {
        this._userID = value;
    }
    private _userName: string = "";
    public get userName(): string {
        return this._userName;
    }
    public set userName(value: string) {
        this._userName = value;
    }
    private _roleName: string = "";
    public get roleName(): string {
        return this._roleName;
    }
    public set roleName(value: string) {
        this._roleName = value;
    }
    private _role_id: string = "";
    public get role_id(): string {
        return this._role_id;
    }
    public set role_id(value: string) {
        this._role_id = value;
    }
    private _roleOrder: ApprovalOrder = 1;
    public get roleOrder(): ApprovalOrder {
        return this._roleOrder;
    }
    public set roleOrder(value: ApprovalOrder) {
        this._roleOrder = value;
    }
    constructor(params?: ICreditCommentDetail) {
        if (params) {
            common.ObjectMapping(params, this);
            this.roleOrder = this.getApprovalOrder();
        }
    }
    private _CreatedDate: Date = new Date();
    public get CreatedDate(): Date {
        return this._CreatedDate;
    }
    public set CreatedDate(value: Date) {
        this._CreatedDate = value;
    }
    private _isCurrentUser: boolean = false;
    public get isCurrentUser(): boolean {
        return this._isCurrentUser;
    }
    public set isCurrentUser(value: boolean) {
        this._isCurrentUser = value;
    }
    getApprovalOrder(): ApprovalOrder {
        let _approvalOrder: ApprovalOrder = 1;
        switch (this.roleName.toLowerCase()) {
            case 'bcm':
                _approvalOrder = ApprovalOrder.BCM;
                break;
            case 'acm':
                _approvalOrder = ApprovalOrder.ACM;
                break;
            case 'rcm':
                _approvalOrder = ApprovalOrder.RCM;
                break;
            case 'zcm':
                _approvalOrder = ApprovalOrder.ZCM;
                break;
            default:
                _approvalOrder = ApprovalOrder.BCM;
                break
        }
        return _approvalOrder;
    }
}

export enum ApprovalOrder {
    BCM = 1, ACM, RCM, ZCM
}



import { Component, OnInit } from '@angular/core';
import { CamDetail, ICamDetail, IPropertyOwner } from './propertyvaluation';
import { PropertyDetail } from "./PropertyDetail";
import { ConfigService } from 'src/app/shared/services/common/http.services';
import 'rxjs';
import { Dropdown, IDropdown } from 'src/app/shared/models/common/control.model';
import { InfoServices } from 'src/app/Injectable/info.services';
import { NotificationService } from 'src/app/notification.service';
import { FileUpload, IfileUpload, UploadViewDownloadService } from '../../layout/button/upload-view-download/upload-view-download.service';
import { IValidation } from '../../layout/error-message/error-message.component';
import { PropertyvaluationService } from './propertyvaluation.service';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { masterModuleDropdown } from 'src/app/shared/models/sanction/masterDropdown';
import { IModalCommon, ModalCommon, ModalService } from 'src/app/shared/services/modal/modal.service';
import { IPropertyDetail } from './IPropertyDetail';


@Component({
    selector: "app-propertyvaluations",
    templateUrl: "./propertyvaluations.component.html",
    styleUrls: ["./propertyvaluations.component.css"]
})
export class PropertyValuationComponent implements OnInit  {
    ngAfterViewInit() {
        // ...

        this.isLTVEdit = false
      }
    public get editable(): boolean {
        return (this.isEditProperty || this.isStructureEdit1 || this.isStructureEdit2 || this.isLTVEdit);
    }
    public get propertyvaluation(): IPropertyDetail {
        return this.propService.propertyvaluation;
    }
    //Static dropdown
    resprooftype: IDropdown[] = [new Dropdown({ displayName: "Property Tax Receipt" }), new Dropdown({ displayName: "Copy of Deed page" }), new Dropdown({ displayName: "Utility Bills" })];
    PropertyUsageTypes: IDropdown[] = [new Dropdown({ displayName: "Residential" }), new Dropdown({ displayName: "Commercial" }), new Dropdown({ displayName: "Both" })]
    TypeofLandApprovels = [new Dropdown({ displayName: "Gram Panchayat" }), new Dropdown({ displayName: "Town Panchayat" }), new Dropdown({ displayName: "Nagar Palika" }), new Dropdown({ displayName: "Municipal Corporation" })]
    LandTypes: IDropdown[] = [new Dropdown({ displayName: "Freehold" }),
    new Dropdown({ displayName: "Leasehold" }),
    new Dropdown({ displayName: "Gramtal" }),
    new Dropdown({ displayName: "Gaothan Freehold" })
    ]
    HouseType = masterModuleDropdown.HouseType;
    ApproachedRoadType = masterModuleDropdown.ApproachedRoadType;
    SurroundingArea = masterModuleDropdown.SurroundingArea;
    TypeofLocality = masterModuleDropdown.TypeofLocality;
    ConstructionQuality = masterModuleDropdown.ConstructionQuality;
    ConstructionYear = masterModuleDropdown.ConstructionYear;
    PropertyType = masterModuleDropdown.PropertyType;
    UnitDetails = masterModuleDropdown.UnitDetail;
    ConstructionType = [new Dropdown({ displayName: "Type 1" }), new Dropdown({ displayName: "Type 2" }), new Dropdown({ displayName: "Type 3" })]
    YesNo: IDropdown[] = masterModuleDropdown.Conditional;
    MaterialWall: IDropdown[] = masterModuleDropdown.MaterialsUsedinWall;
    MeterialFloor: IDropdown[] = masterModuleDropdown.MaterialsUsedinFloors;
    MaterialRoof: IDropdown[] = masterModuleDropdown.MaterialsUsedinRoofs;
    documentId: any = "76151426"
    _CamDetail: ICamDetail = new CamDetail();
    SelectOption: IDropdown[] = [
        { value: "N", displayName: "NO" },
        { value: "Y", displayName: "YES" }
    ];
    applications =
        {
            applicantName: 'ILAP345331', contactNo: 'Deepak Sahu', district: 'Pending', State: 'Approved', pincode: 'Approved', loginDate: 'Approved',
            product: 'test', schema: 'test', branchName: 'test', appliedTenure: 'test', appliedLoadAmount: '222'
        };
    audittrails = [
        { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
        { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
        { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
        { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
    ];
    cersaiStatus: IDropdown[] = [new Dropdown({ displayName: "Positive" }),
    new Dropdown({ displayName: "Negative" }),
    ];
    isShown: boolean = false;

    valuationDetails: any = []

    propertydoctype: any[] = []
    PropertyOwnerList: IPropertyOwner[] = [];
    prop_Type: any;
    type: any;
    prop_from: any;
    max_rate: any;
    objAll: any = [];
    LtvPerValue: any;
    floorRoom: any[] = [{ 'titleName': `Floor 1: No. of rooms` }];
    public get readonly(): boolean {
        return this.Info.LanInfo.readOnly;
    }
    constructor(private http: ConfigService,
        private Info: SanctionService,
        private notify: NotificationService,
        private download: UploadViewDownloadService,
        private propService: PropertyvaluationService,
        private modalService: ModalService,
        private storage: InfoServices
    ) { }
    ngOnInit(): void {
        this.propService.getPropValuationsDetails()
        this.download.uploadLoad = new FileUpload({
            flO_Id: this.Info.LanInfo.flopsid,
            loanAccountNumber: this.Info.LanInfo.lan,
            moduleName: "PROPERTYVALUATION",
            type: "Applicant",
            uuid: "LOS",
            leadID: this.Info.LanInfo.leadId,
        } as IfileUpload);

    }

    property_TypeChange(event: any) {
        let data = this.propService.circleRates.data.filter(x => x.prop_Type == event).map(x => x.type);
        this.ConstructionType = [...new Set(data)].map(x => new Dropdown({ displayName: x }));
        this.propertyvaluation.constructionType = "";
    }
    GetRelationShip(data: any) {
        let selected = this.propertyvaluation.data.find(x => x.applicationNo == data.item.value);
        if (selected)
            selected.isselected = data.event.currentTarget.checked ? 'Y' : 'N';
        this.propertyvaluation.propertyOwner = this.propertyvaluation.data.filter(x => x.isselected.toLowerCase() == 'y').map(x => `${x.ownerName}-(${x.relationShip})`).join(",");
        this.propertyvaluation.propertyOwners = this.propertyvaluation.getProperOwnerList();
    }

    ShowModal(text: any) {
        let data = new ModalCommon({
            message: `<label class='label-error p-1'> ${text}</lable>`,
            title: "Remarks"
        } as IModalCommon);
        this.modalService.ShowModal(data);
    }
    ValuationRemarks() {
        let data = new ModalCommon({
            message: `<div class="label-error"> <ol><li>Property without roof/tin shed roof/Kaccha in nature will not be allowed.</li>
            <li>If Property is in an open area it shouldn't be considered.</li>
            <li>If Property is dilapidated (Poor livable condition), valuation of building should not be considered.</li></ol></div>`,
            title: "Remarks"
        } as IModalCommon);
        this.modalService.ShowModal(data);
    }
    GetMaxRate() {
        try {
            var age = this.prop_from.split('-');
            var dt = this.objAll.filter((x: any) => x.prop_Type == this.prop_Type && x.type == this.type && x.from == age[0] && x.to == age[1]);
            if (dt.length > 0) {

                this.max_rate = dt[0].max_Rate;
            }
        } catch (ex) {

        }
    }
    protertyUses: any;
    PropLandArea: any = true;
    PropStatus: any = true;
    ChangeProperty() {

        this.PropStatus = this.propertyvaluation.propertyUsageType == 'Both' ? false : true
        this.PropLandArea = this.propertyvaluation.propertyUsageType == 'Both' ? true : false
    }


    cancel(event: any) {
        this.propService.propertyvaluation = new PropertyDetail(event);
    }
    protertyValue: any;
    PropValue: any = false;
    ChangePropertyValue() {
        this.isPropError = false;
        this.error = "";
        let landArea = this.propertyvaluation.landArea != "" ? Number.parseInt(this.propertyvaluation.landArea) : 0;
        let loanAmt = 0;
        if (loanAmt > 200000) {
            if (this.propertyvaluation.propertyUsageType == "SORP" && landArea < 450) {
                this.error = "Minimum area norms not met";
                this.notify.showError("Minimum area norms not met");
                this.isPropError = true;
            }
            else if (this.propertyvaluation.propertyUsageType == "SOCP" && landArea < 225) {
                this.error = "Minimum area norms not met";
                this.notify.showError("Minimum area norms not met");
                this.isPropError = true;
            }

        }
    }
    isPropError: boolean = false;
    error: string = "";
    LtvValue: any;
    LtValue: any = false;
    ChangeLtvValue(event: any): any {
        this.ChaValue = event < 5;

        if (!this.ChaValue) {
            this.propertyvaluation.titleChainYrs = event;
        }
        else {
            this.propertyvaluation.titleChainYrs = "";
        }
    }


    ConstructedValue: any;
    ConstValue: any = false;

    ChangePropertyConstructed() {
        this.ConstValue = false;
        if (this.ConstructedValue < 50) {
            this.ConstValue = true;
        }
        else {
            this.ConstValue = false;
        }
    }

    ChainValue: any;
    ChaValue: any = false;

    ChangeChain() {
        this.ChaValue = false;
        if (this.ChainValue < 5) {
            this.ChaValue = true;
        }
        else {
            this.ChaValue = false;
        }
    }

    addmore() {
        let row = { docname: '', filename: '', roomtype: '', roomtypedoc: '' };
        this.valuationDetails.push(row);
    }
    remove(index: any) {
        if (index == -1) {
            this.propertyvaluation.titleDocs = [];
        }
        else {
            this.propertyvaluation.titleDocs.splice(index, 1);
        }
    }
    addmorepropertydoctype() {

        this.propService.propertyvaluation.titleDocAddMore();
    }

    onChange(e: any) {
        this.isShown = !this.isShown; //e.target.value;
    }


    isEditProperty: boolean = false;
    Editpropertydetails() {
        this.isEditProperty = !this.isEditProperty;
    }
    PropertyDetailSubmit() {

        this.propService.submit(this.propertyvaluation);
    }
    isLTVEdit: boolean = false;
    isStructureEdit1: boolean = false;
    isStructureEdit2: boolean = false;
    Valuation: IValidation | undefined;
    validationForValuation() {
        this.propService.propertyvaluation = this.propertyvaluation;
        this.Valuation = this.propService.ValuationDetail();
        this.isStructureEdit1 = (this.Valuation.errorMessage ?? "") != "";
        if (this.Valuation.errorMessage ?? "" != "") {
            this.notify.showWarning(this.Valuation?.errorMessage);
        }
    }
    StructureError: IValidation | undefined;
    validationForStructure() {
        this.propService.propertyvaluation = this.propertyvaluation;
        this.StructureError = this.propService.StructureValidate();
        this.isStructureEdit2 = (this.StructureError?.errorMessage ?? "") != "";
        if (this.StructureError.errorMessage ?? "" != "") {
            this.notify.showWarning(this.StructureError?.errorMessage);
            this.propertyvaluation.builtMarketRate = "";
        }
    }
    PropertyDocumentError: IValidation | undefined;
    PropertyDocumentValidate() {
        this.propService.propertyvaluation = this.propertyvaluation;
        this.PropertyDocumentError = this.propService.PropertyDocumentValidate();
        this.isEditProperty = (this.PropertyDocumentError?.errorMessage ?? "") != "";
        if (this.PropertyDocumentError.errorMessage ?? "" != "") {
            this.notify.showWarning(this.PropertyDocumentError?.errorMessage);
        }
    }
    FinalLTVError: IValidation | undefined;
    FinalLTVValidate() {
        this.propService.propertyvaluation = this.propertyvaluation;
        this.FinalLTVError = this.propService.LTVValidate();
        this.isLTVEdit = (this.FinalLTVError?.errorMessage ?? "") != "";
        if (this.FinalLTVError.errorMessage ?? "" != "") {
            this.notify.showWarning(this.FinalLTVError?.errorMessage);
        }
    }
    ClearText() {
        this.propService.UnitDetailChange();
    }

    getDisabled() {
        return this.isEditProperty || this.isStructureEdit1 || this.isStructureEdit2 || this.isLTVEdit;
    }
}


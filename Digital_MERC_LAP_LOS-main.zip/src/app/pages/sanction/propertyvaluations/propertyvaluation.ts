import { IPropertyDetail } from "./IPropertyDetail";
export class APIResponse implements IPropertyResponse {
    propertyOwner: IPropertyOwner[] = [];
    data: IPropertyDetail[] = [];
    errorcode: any;
    errorDescription: any;
}
export interface IPropertyResponse {
    propertyOwner: IPropertyOwner[];
    data: IPropertyDetail[];
}
export interface IPropertyOwner {
    applicationNo: string;
    type: string;
    ownerName: string;
    isselected: string;
    relationShip: string;
    propertyid: string;

}
export class PropertyOwner implements IPropertyOwner {
    applicationNo: any;
    type: any;
    ownerName: any;
    isselected: any;
    relationShip: any;
    propertyid: any;

}
export interface ICamDetail {
    errorcode: string;
    errorDescription: string;
    data: ICercleRate[];
    getMaxRate(age: number, propType: any, type: any): any;
}
export interface ICercleRate {
    prop_Type: string;
    type: string;
    from: number;
    to: number;
    max_Rate: number;
}
export class CercleRate implements ICercleRate {
    prop_Type: string;
    type: string;
    from: number;
    to: number;
    max_Rate: number;

    constructor(params: ICercleRate) {
        this.prop_Type = params.prop_Type;
        this.type = params.type;
        this.from = params.from;
        this.to = params.to;
        this.max_Rate = params.max_Rate;
    }


}

export class CamDetail implements ICamDetail {

    errorcode: string = "";
    errorDescription: string = "";
    data: ICercleRate[] = [];
    constructor(params?: ICamDetail) {
        if (params) {
            this.errorcode = params.errorcode;
            this.errorDescription = params.errorDescription;
            this.data = params.data.map(x => new CercleRate(x));
        }
    }
    getMaxRate(age: number, propType: any, type: any): any {
        console.debug(`age:${age}-propType:${propType}-type:${type}`);
        let data = this.data.find(x => {
            return ((x.from <= age && x.to >= age) && (x.prop_Type.toLowerCase() == propType.toLowerCase()) && (x.type.toLowerCase() == type.toLowerCase()))
        });

        return data ? data.max_Rate : null;
    }

}


export interface ITitleDoc {
    description: string;
    doc_Ref: string;
    doc_Ref_YN: string;
    doc_Type: string;
    doc_visible?: boolean;
    disabled?: boolean;
}



export interface CircleRates {

}



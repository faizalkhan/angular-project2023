import { common } from "src/app/shared/models/common";
import { IDropdown } from "src/app/shared/models/common/control.model";
import { IPropertyDetail } from "./IPropertyDetail";
import { ITitleDoc, IPropertyOwner } from "./propertyvaluation";

export class PropertyDetail implements IPropertyDetail {
    _propertyOwner: string = "";
    public get propertyOwner(): string {
        return this._propertyOwner;
    }
    public set propertyOwner(value: string) {
        this._propertyOwner = value;
    }
    private _loanAccountNumber: string = "";
    public get loanAccountNumber(): string {
        return this._loanAccountNumber;
    }
    public set loanAccountNumber(value: string) {
        this._loanAccountNumber = value;
    }
    private _titleDoc_Upload_YN: string = "";
    public get titleDoc_Upload_YN(): string {
        return this._titleDoc_Upload_YN;
    }
    public set titleDoc_Upload_YN(value: string) {
        this._titleDoc_Upload_YN = value;
    }
    private _titleDoc_Upload_Ref: string = "";
    public get titleDoc_Upload_Ref(): string {
        return this._titleDoc_Upload_Ref;
    }
    public set titleDoc_Upload_Ref(value: string) {
        this._titleDoc_Upload_Ref = value;
    }
    private _landRec_Upload_YN: string = "";
    public get landRec_Upload_YN(): string {
        return this._landRec_Upload_YN;
    }
    public set landRec_Upload_YN(value: string) {
        this._landRec_Upload_YN = value;
    }
    private _gramPanchayat_Upload_YN: string = "";
    public get gramPanchayat_Upload_YN(): string {
        return this._gramPanchayat_Upload_YN;
    }
    public set gramPanchayat_Upload_YN(value: string) {
        this._gramPanchayat_Upload_YN = value;
    }
    private _nA_Upload_YN: string = "";
    public get nA_Upload_YN(): string {
        return this._nA_Upload_YN;
    }
    public set nA_Upload_YN(value: string) {
        this._nA_Upload_YN = value;
    }
    private _cersaiReport_YN: string = "";
    public get cersaiReport_YN(): string {
        return this._cersaiReport_YN;
    }
    public set cersaiReport_YN(value: string) {
        this._cersaiReport_YN = value;
    }
    private _cersaiReportStatus: string = "";
    public get cersaiReportStatus(): string {
        return this._cersaiReportStatus;
    }
    public set cersaiReportStatus(value: string) {
        this._cersaiReportStatus = value;
    }
    private _propDoc1_YN: string = "";
    public get propDoc1_YN(): string {
        return this._propDoc1_YN;
    }
    public set propDoc1_YN(value: string) {
        this._propDoc1_YN = value;
    }
    private _propDoc1_Dtl: string = "";
    public get propDoc1_Dtl(): string {
        return this._propDoc1_Dtl;
    }
    public set propDoc1_Dtl(value: string) {
        this._propDoc1_Dtl = value;
    }
    private _propDoc2_YN: string = "";
    public get propDoc2_YN(): string {
        return this._propDoc2_YN;
    }
    public set propDoc2_YN(value: string) {
        this._propDoc2_YN = value;
    }
    private _propDoc2_Dtl: string = "";
    public get propDoc2_Dtl(): string {
        return this._propDoc2_Dtl;
    }
    public set propDoc2_Dtl(value: string) {
        this._propDoc2_Dtl = value;
    }
    private _propDoc3_YN: string = "";
    public get propDoc3_YN(): string {
        return this._propDoc3_YN;
    }
    public set propDoc3_YN(value: string) {
        this._propDoc3_YN = value;
    }
    private _propDoc3_Dtl: string = "";
    public get propDoc3_Dtl(): string {
        return this._propDoc3_Dtl;
    }
    public set propDoc3_Dtl(value: string) {
        this._propDoc3_Dtl = value;
    }
    private _propDoc4_YN: string = "";
    public get propDoc4_YN(): string {
        return this._propDoc4_YN;
    }
    public set propDoc4_YN(value: string) {
        this._propDoc4_YN = value;
    }
    private _propDoc4_Dtl: string = "";
    public get propDoc4_Dtl(): string {
        return this._propDoc4_Dtl;
    }
    public set propDoc4_Dtl(value: string) {
        this._propDoc4_Dtl = value;
    }
    private _propDoc5_YN: string = "";
    public get propDoc5_YN(): string {
        return this._propDoc5_YN;
    }
    public set propDoc5_YN(value: string) {
        this._propDoc5_YN = value;
    }
    private _propDoc5_Dtl: string = "";
    public get propDoc5_Dtl(): string {
        return this._propDoc5_Dtl;
    }
    public set propDoc5_Dtl(value: string) {
        this._propDoc5_Dtl = value;
    }
    private _residenceProofType: string = "";
    public get residenceProofType(): string {
        return this._residenceProofType;
    }
    public set residenceProofType(value: string) {
        this._residenceProofType = value;
    }
    private _residenceProofUpload: string = "";
    public get residenceProofUpload(): string {
        return this._residenceProofUpload;
    }
    public set residenceProofUpload(value: string) {
        this._residenceProofUpload = value;
    }
    private _commercialUsePercentage: string = "";
    public get commercialUsePercentage(): string {
        return this._commercialUsePercentage;
    }
    public set commercialUsePercentage(value: string) {
        this._commercialUsePercentage = value;
    }
    private _nearestLandmark: string = "";
    public get nearestLandmark(): string {
        return this._nearestLandmark;
    }
    public set nearestLandmark(value: string) {
        this._nearestLandmark = value;
    }
    private _distFromNearestLandmark: string = "";
    public get distFromNearestLandmark(): string {
        return this._distFromNearestLandmark;
    }
    public set distFromNearestLandmark(value: string) {
        this._distFromNearestLandmark = value;
    }
    private _distFromDistHQ: string = "";
    public get distFromDistHQ(): string {
        return this._distFromDistHQ;
    }
    public set distFromDistHQ(value: string) {
        this._distFromDistHQ = value;
    }
    private _distFromSchool: string = "";
    public get distFromSchool(): string {
        return this._distFromSchool;
    }
    public set distFromSchool(value: string) {
        this._distFromSchool = value;
    }
    private _distFromRailwaystn: string = "";
    public get distFromRailwaystn(): string {
        return this._distFromRailwaystn;
    }
    public set distFromRailwaystn(value: string) {
        this._distFromRailwaystn = value;
    }
    private _distFromBusStn: string = "";
    public get distFromBusStn(): string {
        return this._distFromBusStn;
    }
    public set distFromBusStn(value: string) {
        this._distFromBusStn = value;
    }
    private _constuctionApproved_YN: string = "";
    public get constuctionApproved_YN(): string {
        return this._constuctionApproved_YN;
    }
    public set constuctionApproved_YN(value: string) {
        this._constuctionApproved_YN = value;
    }
    private _landApprovalType: string = "";
    public get landApprovalType(): string {
        return this._landApprovalType;
    }
    public set landApprovalType(value: string) {
        this._landApprovalType = value;
    }
    private _landType: string = "";
    public get landType(): string {
        return this._landType;
    }
    public set landType(value: string) {
        this._landType = value;
    }
    private _landTypeVal: string = "";
    public get landTypeVal(): string {
        return this._landTypeVal;
    }
    public set landTypeVal(value: string) {
        this._landTypeVal = value;
    }
    _landArea: string = "";
    public get landArea(): string {
        return this._landArea;
    }
    public set landArea(value: string) {
        this._landArea = value;
        this.getTotalVal();
    }
    private _houseType: string = "";
    public get houseType(): string {
        return this._houseType;
    }
    public set houseType(value: string) {
        this._houseType = value;
    }
    private _approachRoadType: string = "";
    public get approachRoadType(): string {
        return this._approachRoadType;
    }
    public set approachRoadType(value: string) {
        this._approachRoadType = value;
    }
    private _roadWidthDisable: boolean = false;
    public get roadWidthDisable(): boolean {
        return this._roadWidthDisable;
    }
    public set roadWidthDisable(value: boolean) {
        this._roadWidthDisable = value;
    }
    private _roadWidth: string = "";
    public get roadWidth(): string {
        return this._roadWidth;
    }
    public set roadWidth(value: string) {
        this._roadWidth = value;
        if (value && value != "") {
            this.roadWidthDisable = (Number(value) < 4) == false;
            this.remarks_roadwidth = "";
        }
    }
    private _motorable_YN: string = "";
    public get motorable_YN(): string {
        return this._motorable_YN;
    }
    public set motorable_YN(value: string) {
        this._motorable_YN = value;
    }
    private _surroundingArea: string = "";
    public get surroundingArea(): string {
        return this._surroundingArea;
    }
    public set surroundingArea(value: string) {
        this._surroundingArea = value;
    }
    private _localityType: string = "";
    public get localityType(): string {
        return this._localityType;
    }
    public set localityType(value: string) {
        this._localityType = value;
    }
    private _populationDensity: string = "";
    public get populationDensity(): string {
        return this._populationDensity;
    }
    public set populationDensity(value: string) {
        this._populationDensity = value;
    }
    private _north_AsperDoc: string = "";
    public get north_AsperDoc(): string {
        return this._north_AsperDoc;
    }
    public set north_AsperDoc(value: string) {
        this._north_AsperDoc = value;
    }
    private _south_AsperDoc: string = "";
    public get south_AsperDoc(): string {
        return this._south_AsperDoc;
    }
    public set south_AsperDoc(value: string) {
        this._south_AsperDoc = value;
    }
    private _east_AsperDoc: string = "";
    public get east_AsperDoc(): string {
        return this._east_AsperDoc;
    }
    public set east_AsperDoc(value: string) {
        this._east_AsperDoc = value;

    }
    private _west_AsperDoc: string = "";
    public get west_AsperDoc(): string {
        return this._west_AsperDoc;
    }
    public set west_AsperDoc(value: string) {
        this._west_AsperDoc = value;

    }
    private _north_AsperDoc_YN: string = "";
    public get north_AsperDoc_YN(): string {
        return this._north_AsperDoc_YN;
    }
    public set north_AsperDoc_YN(value: string) {
        this._north_AsperDoc_YN = value;
        if (value && value.toLowerCase() == 'y') {
            this.north_AsperInv = "";
        }
    }
    private _south_AsperDoc_YN: string = "";
    public get south_AsperDoc_YN(): string {
        return this._south_AsperDoc_YN;
    }
    public set south_AsperDoc_YN(value: string) {
        this._south_AsperDoc_YN = value;
        if (value && value.toLowerCase() == 'y') {
            this.south_AsperInv = "";
        }
    }
    private _east_AsperDoc_YN: string = "";
    public get east_AsperDoc_YN(): string {
        return this._east_AsperDoc_YN;
    }
    public set east_AsperDoc_YN(value: string) {
        this._east_AsperDoc_YN = value;
        if (value && value.toLowerCase() == 'y') {
            this.east_AsperInv = "";
        }
    }
    private _west_AsperDoc_YN: string = "";
    public get west_AsperDoc_YN(): string {
        return this._west_AsperDoc_YN;
    }
    public set west_AsperDoc_YN(value: string) {
        this._west_AsperDoc_YN = value;
        if (value && value.toLowerCase() == 'y') {
            this.west_AsperInv = "";
        }
    }
    private _north_AsperInv: string = "";
    public get north_AsperInv(): string {
        return this._north_AsperInv;
    }
    public set north_AsperInv(value: string) {
        this._north_AsperInv = value;
    }
    private _south_AsperInv: string = "";
    public get south_AsperInv(): string {
        return this._south_AsperInv;
    }
    public set south_AsperInv(value: string) {
        this._south_AsperInv = value;
    }
    private _east_AsperInv: string = "";
    public get east_AsperInv(): string {
        return this._east_AsperInv;
    }
    public set east_AsperInv(value: string) {
        this._east_AsperInv = value;
    }
    private _west_AsperInv: string = "";
    public get west_AsperInv(): string {
        return this._west_AsperInv;
    }
    public set west_AsperInv(value: string) {
        this._west_AsperInv = value;
    }
    private _constructionQuality: string = "";
    public get constructionQuality(): string {
        return this._constructionQuality;
    }
    public set constructionQuality(value: string) {
        this._constructionQuality = value;
    }
    private _property_Type: string = "";
    public get property_Type(): string {
        return this._property_Type;
    }
    public set property_Type(value: string) {
        this._property_Type = value;
    }
    private _constructionType: string = "";
    public get constructionType(): string {
        return this._constructionType;
    }
    public set constructionType(value: string) {
        this._constructionType = value;
    }
    _constructionYear: string = "";
    public get constructionYear(): string {
        return this._constructionYear;
    }
    public set constructionYear(value: string) {
        this._constructionYear = value;
    }
    private _unitDetails: string = "";
    public get unitDetails(): string {
        return this._unitDetails;
    }
    public set unitDetails(value: string) {
        this._unitDetails = value;
    }
    private _kitchen_Area: string = "";
    public get kitchen_Area(): string {
        return this._kitchen_Area;
    }
    public set kitchen_Area(value: string) {
        this._kitchen_Area = value;
        this.totalFlatArea();
    }
    private _bedroom_Area: string = "";
    public get bedroom_Area(): string {

        return this._bedroom_Area;
    }
    public set bedroom_Area(value: string) {
        this._bedroom_Area = value; this.totalFlatArea();
    }
    private _hall_Area: string = "";
    public get hall_Area(): string {
        return this._hall_Area;
    }
    public set hall_Area(value: string) {
        this._hall_Area = value; this.totalFlatArea();
    }
    private _washroom_Area: string = "";
    public get washroom_Area(): string {
        return this._washroom_Area; this.totalFlatArea();
    }
    public set washroom_Area(value: string) {
        this._washroom_Area = value; this.totalFlatArea();
    }
    private _others_dtl: string = "";
    public get others_dtl(): string {
        return this._others_dtl;
    }
    public set others_dtl(value: string) {
        this._others_dtl = value;
    }
    private _other_Area: string = "";
    public get other_Area(): string {
        return this._other_Area; this.totalFlatArea();
    }
    public set other_Area(value: string) {
        this._other_Area = value;
        this.totalFlatArea();
    }
    private _totalArea_Flat: string = "";
    public get totalArea_Flat(): string {
        return this._totalArea_Flat;
    }
    public set totalArea_Flat(value: string) {
        this._totalArea_Flat = value;
    }
    GetInvestigationYN_Count(): Number {
        let val = 0;
        if (this.west_AsperDoc_YN.toLowerCase() == 'n') {
            val++;
        }
        if (this.east_AsperDoc_YN.toLowerCase() == 'n') {
            val++;
        }
        if (this.south_AsperDoc_YN.toLowerCase() == 'n') {
            val++;
        }
        if (this.north_AsperDoc_YN.toLowerCase() == 'n') {
            val++;
        }
        return val;
    }
    totalFlatArea() {
        let _kitchen_Area = this._kitchen_Area != "" ? Number(this._kitchen_Area) : 0;
        let _bedroom_Area = this._bedroom_Area != "" ? Number(this._bedroom_Area) : 0;
        let _hall_Area = this._hall_Area != "" ? Number(this._hall_Area) : 0;
        let _washroom_Area = this._washroom_Area != "" ? Number(this._washroom_Area) : 0;
        let _other_Area = this._other_Area != "" ? Number(this._other_Area) : 0;

        this.totalArea_Flat = (_kitchen_Area + _bedroom_Area + _hall_Area + _washroom_Area + _other_Area).toFixed();
    }
    private _materialWall: string = "";
    public get materialWall(): string {
        return this._materialWall;
    }
    public set materialWall(value: string) {
        this._materialWall = value;
    }
    private _meterialFloor: string = "";
    public get meterialFloor(): string {
        return this._meterialFloor;
    }
    public set meterialFloor(value: string) {
        this._meterialFloor = value;
    }
    private _materialRoof: string = "";
    public get materialRoof(): string {
        return this._materialRoof;
    }
    public set materialRoof(value: string) {
        this._materialRoof = value;
    }
    _residualValYrs: number = 0;
    public get residualValYrs(): any {
        return this._residualValYrs;
    }
    public set residualValYrs(value: number) {
        this._residualValYrs = value;
    }
    private _modificationDtl: string = "";
    public get modificationDtl(): string {
        return this._modificationDtl;
    }
    public set modificationDtl(value: string) {
        this._modificationDtl = value;
    }
    public get plotArea(): any {
        return this.landArea;
    }
    _plotCircleRate: string = "";
    public get plotCircleRate(): string {
        return this._plotCircleRate;
    }
    public set plotCircleRate(value: string) {
        this._plotCircleRate = value;
        this.getTotalVal();
    }
    _plotMarketRate: string = "";
    public get plotMarketRate(): string {
        return this._plotMarketRate;
    }
    public set plotMarketRate(value: string) {
        this._plotMarketRate = value;
        this.getTotalVal();
    }
    public get builtArea(): string {
        if (this.unitDetails?.toLowerCase() == 'flat') {
            return this.totalArea_Flat;
        }
        else if (this.unitDetails?.toLowerCase() != 'flat') {
            return this.totalArea_NonFlat;
        }
        else
            return "";
    }

    _builtCircleRate: string = "";
    public get builtCircleRate(): string {
        return this._builtCircleRate;
    }
    public set builtCircleRate(value: string) {
        this._builtCircleRate = value;
        this.getTotalVal();
    }
    _builtMarketRate: string = "";
    public get builtMarketRate(): string {
        return this._builtMarketRate;
    }
    public set builtMarketRate(value: string) {
        this._builtMarketRate = value;
        this.getTotalVal();
    }
    private _totalVal: any = "";
    public get totalVal(): any {
        return this._totalVal;
    }
    public set totalVal(value: any) {
        this._totalVal = value;
    }
    private _residenceProofRef: string = "";
    public get residenceProofRef(): string {
        return this._residenceProofRef;
    }
    public set residenceProofRef(value: string) {
        this._residenceProofRef = value;
    }
    private _poprtyandOwnrPhotoRef: string = "";
    public get poprtyandOwnrPhotoRef(): string {
        return this._poprtyandOwnrPhotoRef;
    }
    public set poprtyandOwnrPhotoRef(value: string) {
        this._poprtyandOwnrPhotoRef = value;
    }
    private _approachRoadImgRef: string = "";
    public get approachRoadImgRef(): string {
        return this._approachRoadImgRef;
    }
    public set approachRoadImgRef(value: string) {
        this._approachRoadImgRef = value;
    }
    private _backSideImgRef: string = "";
    public get backSideImgRef(): string {
        return this._backSideImgRef;
    }
    public set backSideImgRef(value: string) {
        this._backSideImgRef = value;
    }
    private _internalImg1Ref: string = "";
    public get internalImg1Ref(): string {
        return this._internalImg1Ref;
    }
    public set internalImg1Ref(value: string) {
        this._internalImg1Ref = value;
    }
    private _internalImg2Ref: string = "";
    public get internalImg2Ref(): string {
        return this._internalImg2Ref;
    }
    public set internalImg2Ref(value: string) {
        this._internalImg2Ref = value;
    }
    private _roomImg1Ref: string = "";
    public get roomImg1Ref(): string {
        return this._roomImg1Ref;
    }
    public set roomImg1Ref(value: string) {
        this._roomImg1Ref = value;
    }
    private _roomImg2Ref: string = "";
    public get roomImg2Ref(): string {
        return this._roomImg2Ref;
    }
    public set roomImg2Ref(value: string) {
        this._roomImg2Ref = value;
    }
    private _roomImg3Ref: string = "";
    public get roomImg3Ref(): string {
        return this._roomImg3Ref;
    }
    public set roomImg3Ref(value: string) {
        this._roomImg3Ref = value;
    }
    private _roomImg4Ref: string = "";
    public get roomImg4Ref(): string {
        return this._roomImg4Ref;
    }
    public set roomImg4Ref(value: string) {
        this._roomImg4Ref = value;
    }
    private _hallImg1Ref: string = "";
    public get hallImg1Ref(): string {
        return this._hallImg1Ref;
    }
    public set hallImg1Ref(value: string) {
        this._hallImg1Ref = value;
    }
    private _hallImg2Ref: string = "";
    public get hallImg2Ref(): string {
        return this._hallImg2Ref;
    }
    public set hallImg2Ref(value: string) {
        this._hallImg2Ref = value;
    }
    private _hallImg3Ref: string = "";
    public get hallImg3Ref(): string {
        return this._hallImg3Ref;
    }
    public set hallImg3Ref(value: string) {
        this._hallImg3Ref = value;
    }
    private _hallImg4Ref: string = "";
    public get hallImg4Ref(): string {
        return this._hallImg4Ref;
    }
    public set hallImg4Ref(value: string) {
        this._hallImg4Ref = value;
    }
    private _kitchenImg1Ref: string = "";
    public get kitchenImg1Ref(): string {
        return this._kitchenImg1Ref;
    }
    public set kitchenImg1Ref(value: string) {
        this._kitchenImg1Ref = value;
    }
    private _washoomImg1Ref: string = "";
    public get washoomImg1Ref(): string {
        return this._washoomImg1Ref;
    }
    public set washoomImg1Ref(value: string) {
        this._washoomImg1Ref = value;
    }
    private _washoomImg2Ref: string = "";
    public get washoomImg2Ref(): string {
        return this._washoomImg2Ref;
    }
    public set washoomImg2Ref(value: string) {
        this._washoomImg2Ref = value;
    }
    public get ltV_TotalPropVal(): any {
        return this.totalVal;
    }
    public get propEligibility(): any {
        let ltvPer = this.ltvPer != "" ? Number(this.ltvPer) / 100 : 0;
        let ltV_TotalPropVal = this.ltV_TotalPropVal != "" ? Number(this.ltV_TotalPropVal) : 0;
        return (ltvPer * ltV_TotalPropVal).toFixed(0);
    }

    _titleChainYrs: number = 0;
    public get titleChainYrs(): any {
        return this._titleChainYrs;
    }
    public set titleChainYrs(value: any) {
        this._titleChainYrs = value;
    }
    _appliedLTV: number = 0;
    public get appliedLTV(): any {
        return this._appliedLTV;
    }
    public set appliedLTV(value: number) {
        this._appliedLTV = value;
         this.getFinalLTV();
    }
    _loanAmount: any = "";
    public get loanAmount(): any {
        return this._loanAmount;
    }
    public set loanAmount(value: any) {
        this._loanAmount = value;
    }



    private _createdBy: string = "";
    public get createdBy(): string {
        return this._createdBy;
    }
    public set createdBy(value: string) {
        this._createdBy = value;
    }
    private _sourceThrough: string = "";
    public get sourceThrough(): string {
        return this._sourceThrough;
    }
    public set sourceThrough(value: string) {
        this._sourceThrough = value;
    }
    private _propAddress: string = "";
    public get propAddress(): string {
        return this._propAddress;
    }
    public set propAddress(value: string) {
        this._propAddress = value;
    }
    constructor(params?: IPropertyDetail) {
        if (params) {
            common.ObjectMapping(params, this);
            this.roadWidthDisable = ((this.roadWidth && this.roadWidth != "") ? Number(this.roadWidth) : 0) < 4 == false;
        }
        this.propertyOwner = this.data.filter(x => x.isselected.toLowerCase() == 'y').map(x => `${x.ownerName}-(${x.relationShip})`).join(",");
        this.titleDocs = this.getTitleDocs().filter(x => ((x.description != "" && x.doc_Ref != "") || x.doc_visible));
        this.NonFlatList = this.GetNonFlatList();
        this.getFinalLTV();
    }
    private _ratePlot: string = "";
    public get ratePlot(): string {
        return this._ratePlot;
    }
    public set ratePlot(value: string) {
        this._ratePlot = value;
    }
    private _rateBuilt: string = "";
    public get rateBuilt(): string {
        return this._rateBuilt;
    }
    public set rateBuilt(value: string) {
        this._rateBuilt = value;
    }
    private _valPlot: string = "";
    public get valPlot(): string {
        return this._valPlot;
    }
    public set valPlot(value: string) {
        this._valPlot = value;
    }
    private _valBuilt: string = "";
    public get valBuilt(): string {
        return this._valBuilt;
    }
    public set valBuilt(value: string) {
        this._valBuilt = value;
    }
    private _propertyOwnerRelation: string = "";
    public get propertyOwnerRelation(): string {
        return this._propertyOwnerRelation;
    }
    public set propertyOwnerRelation(value: string) {
        this._propertyOwnerRelation = value;
    }
    private _landRec_Upload_Ref: string = "";
    public get landRec_Upload_Ref(): string {
        return this._landRec_Upload_Ref;
    }
    public set landRec_Upload_Ref(value: string) {
        this._landRec_Upload_Ref = value;
    }
    private _gramPanchayat_Ref: string = "";
    public get gramPanchayat_Ref(): string {
        return this._gramPanchayat_Ref;
    }
    public set gramPanchayat_Ref(value: string) {
        this._gramPanchayat_Ref = value;
    }
    private _nA_Upload_Ref: string = "";
    public get nA_Upload_Ref(): string {
        return this._nA_Upload_Ref;
    }
    public set nA_Upload_Ref(value: string) {
        this._nA_Upload_Ref = value;
    }
    private _cersaiReport_Ref: string = "";
    public get cersaiReport_Ref(): string {
        return this._cersaiReport_Ref;
    }
    public set cersaiReport_Ref(value: string) {
        this._cersaiReport_Ref = value;
    }
    private _propDoc1_Ref: string = "";
    public get propDoc1_Ref(): string {
        return this._propDoc1_Ref;
    }
    public set propDoc1_Ref(value: string) {
        this._propDoc1_Ref = value;
    }
    private _propDoc2_Ref: string = "";
    public get propDoc2_Ref(): string {
        return this._propDoc2_Ref;
    }
    public set propDoc2_Ref(value: string) {
        this._propDoc2_Ref = value;
    }
    private _propDoc3_Ref: string = "";
    public get propDoc3_Ref(): string {
        return this._propDoc3_Ref;
    }
    public set propDoc3_Ref(value: string) {
        this._propDoc3_Ref = value;
    }
    private _propDoc4_Ref: string = "";
    public get propDoc4_Ref(): string {
        return this._propDoc4_Ref;
    }
    public set propDoc4_Ref(value: string) {
        this._propDoc4_Ref = value;
    }
    private _propDoc5_Ref: string = "";
    public get propDoc5_Ref(): string {
        return this._propDoc5_Ref;
    }
    public set propDoc5_Ref(value: string) {
        this._propDoc5_Ref = value;
    }
    private _residenceProofUpload_Ref: string = "";
    public get residenceProofUpload_Ref(): string {
        return this._residenceProofUpload_Ref;
    }
    public set residenceProofUpload_Ref(value: string) {
        this._residenceProofUpload_Ref = value;
    }
    private _constructedArea: string = "";
    public get constructedArea(): string {
        return this._constructedArea;
    }
    public set constructedArea(value: string) {
        this._constructedArea = value;
    }
    private _technicalvaluation: any = "";
    public get technicalvaluation(): any {
        return this._technicalvaluation;
    }
    public set technicalvaluation(value: any) {
        this._technicalvaluation = value;
        this.getFinalLTV();
    }
    private _remarks_roadwidth: any = "";
    public get remarks_roadwidth(): any {
        return this._remarks_roadwidth;
    }
    public set remarks_roadwidth(value: any) {
        this._remarks_roadwidth = value;
    }
    private _technicalval_status: string = "";
    public get technicalval_status(): any {
        return this._technicalval_status;
    }
    public set technicalval_status(value: any) {
        this._technicalval_status = value;
        this.getFinalLTV();
    }
    private _propValInternal: any = "";
    public get propValInternal(): any {
        return this._propValInternal;
    }
    public set propValInternal(value: any) {
        this._propValInternal = value;
    }
   
    private _propValExternal: any = "";
    public get propValExternal(): any {
        return this._propValExternal;
    }
    public set propValExternal(value: any) {
        this._propValExternal = value;

    }
    

    _data: IPropertyOwner[] = [];
    public get data(): IPropertyOwner[] {
        return this._data;
    }
    public set data(value: IPropertyOwner[]) {
        this._data = value;
        this.propertyOwner = this.data.filter(x => x.isselected.toLowerCase() == 'y').map(x => `${x.ownerName}-(${x.relationShip})`).join(",");
        this._propertyOwners = this.getProperOwnerList();
    }
    /**Get Set Properties */
    // Calulate the LTV %
    public get ltvPer(): any {

        let loanAppliedAmoun = this.loanAmount != "" ? Number.parseFloat(this.loanAmount) : 0;
        console.debug(loanAppliedAmoun);
        let titleChainYrs = this.titleChainYrs != "" ? Number.parseInt(this.titleChainYrs) : 0;

        if ((loanAppliedAmoun <= 200000 || loanAppliedAmoun > 200000) && (this.titleChainYrs < 13 || this.titleChainYrs >= 13) && (this.propertyUsageType.toLowerCase() == 'commercial' || this.propertyUsageType.toLowerCase() == 'both')) {
            return "50";
        }
        else if (loanAppliedAmoun <= 200000 && this.titleChainYrs < 13 && this.propertyUsageType.toLowerCase() == 'residential') {
            return "50";
        }
        else if (loanAppliedAmoun <= 200000 && this.titleChainYrs >= 13 && this.propertyUsageType.toLowerCase() == 'residential') {
            return "55";
        }
        else if (loanAppliedAmoun > 200000 && this.titleChainYrs >= 13 && this.propertyUsageType.toLowerCase() == 'residential') {
            return "60";
        }
        else
            return "";
    }
    public get age(): number {
        let age: number = 0;
        switch (this.constructionYear.toLowerCase()) {
            case "<5 years":
                age = 4;
                break;
            case "5–10 years":
                age = 9;
                break;
            case ">10 years":
                age = 11;
                break;
        }
        return age;
    }
    _propertyOwners: IDropdown[] = [];
    public get propertyOwners(): IDropdown[] {
        return this._propertyOwners;
    }
    public set propertyOwners(value: IDropdown[]) {
        this._propertyOwners = value;
    }
    _propertyUsageType: string = "";
    public get propertyUsageType(): string {
        return this._propertyUsageType;
    }
    public set propertyUsageType(value: string) {
        this._propertyUsageType = value;

        if (value.toLowerCase() != "both") {
            this.commercialUsePercentage = "";
        }
    }
    _titleDocs: ITitleDoc[] = [];
    public get titleDocs(): ITitleDoc[] {
        return this._titleDocs;
    }
    public set titleDocs(value: ITitleDoc[]) {
        this._titleDocs = value;
    }
    public get percentConstructed(): any {
        let constructedArea = this._constructedArea != "" ? Number(this._constructedArea) : 0;
        let landArea = this.landArea != "" ? Number(this.landArea) : 0;
        if (constructedArea > 0 && landArea > 0) {
            return ((constructedArea / landArea) * 100).toFixed(0);
        }

        else
            return "";
    }
    ConvertJSON(): any {
        this.SetNonFlatList();
        return {
            "AppliedLTV": this.appliedLTV.toString(),
            "ApproachRoadImgRef": this._approachRoadImgRef,
            "ApproachRoadType": this._approachRoadType,
            "BackSideImgRef": this._backSideImgRef,
            "Bedroom_Area": this._bedroom_Area.toString(),
            "BuiltArea": this.builtArea.toString(),
            "BuiltCircleRate": this.builtCircleRate,
            "BuiltMarketRate": this.builtMarketRate.toString(),
            "CersaiReportStatus": this._cersaiReportStatus,
            "CersaiReport_YN": this._cersaiReport_YN,
            "CommercialUsePercentage": this._commercialUsePercentage.toString(),
            "ConstructedArea": this._constructedArea.toString(),
            "ConstructionQuality": this._constructionQuality,
            "ConstructionType": this._constructionType,
            "ConstructionYear": this.constructionYear,
            "ConstuctionApproved_YN": this._constuctionApproved_YN,
            "CreatedBy": this._createdBy,
            "DistFromBusStn": this._distFromBusStn,
            "DistFromDistHQ": this._distFromDistHQ,
            "DistFromNearestLandmark": this._distFromNearestLandmark,
            "DistFromRailwaystn": this._distFromRailwaystn,
            "DistFromSchool": this._distFromSchool,
            "East_AsperDoc": this._east_AsperDoc,
            "East_AsperDoc_YN": this._east_AsperDoc_YN,
            "East_AsperInv": this._east_AsperInv,
            "FinalValLTV": this.finalValLTV.toFixed(2),
            "Flr1_Area": this._flr1_Area.toString(),
            "Flr1_Rooms": this._flr1_Rooms.toString(),
            "Flr2_Area": this._flr2_Area.toString(),
            "Flr2_Rooms": this._flr2_Rooms.toString(),
            "Flr3_Area": this._flr3_Area.toString(),
            "Flr3_Rooms": this._flr3_Rooms.toString(),
            "Flr4_Area": this._flr4_Area.toString(),
            "Flr4_Rooms": this._flr4_Rooms.toString(),
            "Flr5_Area": this._flr5_Area.toString(),
            "Flr5_Rooms": this._flr5_Rooms.toString(),
            "GramPanchayat_Upload_YN": this._gramPanchayat_Upload_YN ?? "",
            "GramPanchayat_Ref": this._gramPanchayat_Ref ?? "",
            "HallImg1Ref": this._hallImg1Ref,
            "HallImg2Ref": this._hallImg2Ref,
            "HallImg3Ref": this._hallImg3Ref,
            "HallImg4Ref": this._hallImg4Ref,
            "Hall_Area": this._hall_Area,
            "HouseType": this._houseType,
            "InternalImg1Ref": this._internalImg1Ref,
            "InternalImg2Ref": this._internalImg2Ref,
            "KitchenImg1Ref": this._kitchenImg1Ref,
            "Kitchen_Area": this._kitchen_Area,
            "LTVPer": this.ltvPer,
            "LTV_TotalPropVal": this.ltV_TotalPropVal.toString(),
            "LandApprovalType": this._landApprovalType,
            "LandArea": this.landArea,
            "LandRec_Upload_YN": this._landRec_Upload_YN,
            "LandType": this._landType,
            "LandTypeVal": this._landTypeVal,
            "LoanAccountNumber": this._loanAccountNumber,
            "LocalityType": this._localityType,
            "MaterialRoof": this._materialRoof,
            "MaterialWall": this._materialWall,
            "MeterialFloor": this._meterialFloor,
            "ModificationDtl": this._modificationDtl,
            "Motorable_YN": this._motorable_YN,
            "NA_Upload_YN": this._landRec_Upload_YN,
            "NearestLandmark": this._nearestLandmark,
            "North_AsperDoc": this._north_AsperDoc,
            "North_AsperDoc_YN": this._north_AsperDoc_YN,
            "North_AsperInv": this._north_AsperInv,
            "Other_Area": this._other_Area,
            "Others_dtl": this._others_dtl,
            "PercentConstructed": this.percentConstructed,
            "PlotArea": this.plotArea,
            "PlotCircleRate": this.plotCircleRate,
            "PlotMarketRate": this.plotMarketRate,
            "PoprtyandOwnrPhotoRef": this._poprtyandOwnrPhotoRef,
            "PopulationDensity": this._populationDensity,
            "PropAddress": this._propAddress,
            "PropDoc1_Dtl": this.findByDocumentType('PROPERTY_DOC_ONE')?.description ?? "",
            "PropDoc1_Ref": this.findByDocumentType('PROPERTY_DOC_ONE')?.doc_Ref ?? "",
            "PropDoc1_YN": this.findByDocumentType('PROPERTY_DOC_ONE')?.doc_Ref != "" ? 'Y' : 'N',
            "PropDoc2_Dtl": this.findByDocumentType('PROPERTY_DOC_TWO')?.description ?? "",
            "PropDoc2_Ref": this.findByDocumentType('PROPERTY_DOC_TWO')?.doc_Ref ?? "",
            "PropDoc2_YN": this.findByDocumentType('PROPERTY_DOC_TWO')?.doc_Ref != "" ? 'Y' : 'N',
            "PropDoc3_Dtl": this.findByDocumentType('PROPERTY_DOC_THREE')?.description ?? "",
            "PropDoc3_Ref": this.findByDocumentType('PROPERTY_DOC_THREE')?.doc_Ref ?? "",
            "PropDoc3_YN": this.findByDocumentType('PROPERTY_DOC_THREE')?.doc_Ref != "" ? 'Y' : 'N',
            "PropDoc4_Dtl": this.findByDocumentType('PROPERTY_DOC_FOUR')?.description ?? "",
            "PropDoc4_Ref": this.findByDocumentType('PROPERTY_DOC_FOUR')?.doc_Ref ?? "",
            "PropDoc4_YN": this.findByDocumentType('PROPERTY_DOC_FOUR')?.doc_Ref != "" ? 'Y' : 'N',
            "PropDoc5_Dtl": this.findByDocumentType('PROPERTY_DOC_FIVE')?.description ?? "",
            "PropDoc5_Ref": this.findByDocumentType('PROPERTY_DOC_FIVE')?.doc_Ref ?? "",
            "PropDoc5_YN": this.findByDocumentType('PROPERTY_DOC_FIVE')?.doc_Ref != "" ? 'Y' : 'N',
            "PropEligibility": this.propEligibility,
            "PropertyUsageType": this.propertyUsageType,
            "Property_Type": this._property_Type,
            "RateBuilt": this._rateBuilt,
            "RatePlot": this._ratePlot,
            "ResidenceProofType": this._residenceProofType,
            "ResidenceProofUpload": this._residenceProofUpload,
            "ResidualValYrs": this._residualValYrs,
            "RoadWidth": this._roadWidth,
            "RoomImg1Ref": this._roomImg1Ref,
            "RoomImg2Ref": this._roomImg2Ref,
            "RoomImg3Ref": this._roomImg3Ref,
            "RoomImg4Ref": this._roomImg4Ref,
            "SourceThrough": "LOS",
            "South_AsperDoc": this._south_AsperDoc,
            "South_AsperDoc_YN": this._south_AsperDoc_YN,
            "South_AsperInv": this._south_AsperInv,
            "SurroundingArea": this._surroundingArea,
            "TitleChainYrs": this.titleChainYrs.toString(),
            "TitleDoc_Upload_YN": this.findByDocumentType('TITLE_DOCUMENT')?.doc_Ref_YN ?? "",
            "TitleDoc_Upload_Ref": this._titleDoc_Upload_Ref ?? "",
            "TotalArea_Flat": this.totalArea_Flat.toString(),
            "TotalArea_NonFlat": this.totalArea_NonFlat.toString(),
            "TotalVal": this.totalVal,
            "UnitDetails": this._unitDetails,
            "ValBuilt": this._valBuilt,
            "ValPlot": this._valPlot,
            "WashoomImg1Ref": this._washoomImg1Ref,
            "WashoomImg2Ref": this._washoomImg2Ref,
            "Washroom_Area": this._washroom_Area,
            "West_AsperDoc": this._west_AsperDoc,
            "West_AsperDoc_YN": this._west_AsperDoc_YN,
            "West_AsperInv": this._west_AsperInv,
            "CersaiReport_Ref": this._cersaiReport_Ref,
            "Data": this.data,
            "NA_Upload_Ref": this._nA_Upload_Ref ?? "",
            "LandRec_Upload_Ref": this._landRec_Upload_Ref ?? "",
            "Remarks_roadwidth": this.remarks_roadwidth
        };

    }
    findByDocumentType(name: any): ITitleDoc | undefined {
        return this.titleDocs.find((x: ITitleDoc) => x.doc_Type.toLowerCase() == name.toLowerCase()) ?? undefined;
    }
    getTitleDocs() {
        let data: ITitleDoc[] = [];
        // // Static
        // data.push({ doc_visible: true, description: "Title Document", doc_Ref: this._titleDoc_Upload_Ref, doc_Ref_YN: this._titleDoc_Upload_YN, doc_Type: "TITLE_DOCUMENT", disabled: true } as ITitleDoc);
        // data.push({ doc_visible: true, description: "Land Document", doc_Ref: this._landRec_Upload_Ref, doc_Ref_YN: this._landRec_Upload_YN, doc_Type: "LAND_RECORDS", disabled: true } as ITitleDoc);
        // data.push({ doc_visible: true, description: "Gram Panchayat Plan & Construction Permission / NOC & TPDA Layout Plan", doc_Ref: this._gramPanchayat_Ref, doc_Ref_YN: this._gramPanchayat_Upload_YN, doc_Type: "GRAM_PANCHAYAT_PLAN", disabled: true } as ITitleDoc);
        // data.push({ doc_visible: true, description: "NA Document", doc_Ref: this._nA_Upload_Ref, doc_Ref_YN: this._nA_Upload_YN, doc_Type: "NA_DOCUMENT", disabled: true } as ITitleDoc);
        // Others
        data.push({ description: this._propDoc1_Dtl, doc_Ref: this._propDoc1_Ref, doc_Ref_YN: this._propDoc1_YN, doc_Type: "PROPERTY_DOC_ONE" } as ITitleDoc);
        data.push({ description: this._propDoc2_Dtl, doc_Ref: this._propDoc2_Ref, doc_Ref_YN: this._propDoc2_YN, doc_Type: "PROPERTY_DOC_TWO" } as ITitleDoc);
        data.push({ description: this._propDoc3_Dtl, doc_Ref: this._propDoc3_Ref, doc_Ref_YN: this._propDoc3_YN, doc_Type: "PROPERTY_DOC_THREE" } as ITitleDoc);
        data.push({ description: this._propDoc4_Dtl, doc_Ref: this._propDoc4_Ref, doc_Ref_YN: this._propDoc4_YN, doc_Type: "PROPERTY_DOC_FOUR" } as ITitleDoc);
        data.push({ description: this._propDoc5_Dtl, doc_Ref: this._propDoc5_Ref, doc_Ref_YN: this._propDoc5_YN, doc_Type: "PROPERTY_DOC_FIVE" } as ITitleDoc);

        return data;
    }

    getProperOwnerList(): IDropdown[] {
        return this.data.map(x => { return { displayName: `${x.ownerName} - (${x.relationShip})`, value: x.applicationNo, selected: x.isselected == 'Y' } as IDropdown; });
    }
    titleDocRemove(index: number) {
        if (this._titleDocs[index].doc_Ref == "")
            this._titleDocs[index].doc_visible = false;
    }
    titleDocAddMore() {
        let data = this.getTitleDocs();
        let find = data[this.titleDocs.length];

        find.description = find.doc_Ref = "";
        this._titleDocs.push(find);
    }
    // NonFlat
    private _NonFlatList: any[] = [];
    public get NonFlatList(): any[] {
        return this._NonFlatList;
    }
    public set NonFlatList(value: any[]) {
        this._NonFlatList = value;
    }
    errorMessage: any = "";
    AddNonFlat() {
        this.errorMessage = "";
        if (this.NonFlatList.length > 0 && this.NonFlatList.filter(x => { return (!x.room || x.room == '') && (!x.area || x.area == '') }).length > 0) {
            this.errorMessage = "Please enter no. of rooms";
        }
        else if (this.NonFlatList.length > 0 && this.NonFlatList.filter(x => { return (!x.area || x.area == '') }).length > 0) {
            this.errorMessage = "Please enter area of floor";
        }
        else if (this.NonFlatList.length < 5) {
            this.NonFlatList.push({ floor: this.NonFlatList.length + 1, room: "", area: "" });
        }
    }
    RemoveNonFlat(index: number) {
        this.NonFlatList.splice(index, 1);
    }
    GetNonFlatList() {
        let data: any[] = [];
        if (this._flr1_Rooms > 0 && this._flr1_Area != "") {
            data.push({ floor: 1, room: this._flr1_Rooms, area: this._flr1_Area });
        }
        if (this._flr2_Rooms > 0 && this._flr2_Area != "") {
            data.push({ floor: 2, room: this._flr2_Rooms, area: this._flr2_Area });
        }
        if (this._flr3_Rooms > 0 && this._flr3_Area != "") {
            data.push({ floor: 3, room: this._flr3_Rooms, area: this._flr3_Area });
        }
        if (this._flr4_Rooms > 0 && this._flr4_Area != "") {
            data.push({ floor: 4, room: this._flr4_Rooms, area: this._flr4_Area });
        }
        if (this._flr5_Rooms > 0 && this._flr5_Area != "") {
            data.push({ floor: 5, room: this._flr5_Rooms, area: this._flr5_Area });
        }
        return data;
    }
    SetNonFlatList() {
        this.NonFlatList.forEach((x: any) => {
            if (x.floor == 1) {
                this._flr1_Rooms = x.room;
                this._flr1_Area = x.area;
            }
            else if (x.floor == 2) {
                this._flr2_Rooms = x.room;
                this._flr2_Area = x.area;
            }
            else if (x.floor == 3) {
                this._flr3_Rooms = x.room;
                this._flr3_Area = x.area;
            }
            else if (x.floor == 4) {
                this._flr4_Rooms = x.room;
                this._flr4_Area = x.area;
            }
            else if (x.floor == 5) {
                this._flr5_Rooms = x.room;
                this._flr5_Area = x.area;
            }
        })
    }
    private _flr1_Rooms: any = "";
    public get flr1_Rooms(): any {
        return this._flr1_Rooms;
    }
    public set flr1_Rooms(value: any) {
        this._flr1_Rooms = value;
    }
    private _flr1_Area: string = "";
    public get flr1_Area(): string {
        return this._flr1_Area;
    }
    public set flr1_Area(value: string) {
        this._flr1_Area = value;
    }
    private _flr2_Rooms: any = "";
    public get flr2_Rooms(): any {
        return this._flr2_Rooms;
    }
    public set flr2_Rooms(value: any) {
        this._flr2_Rooms = value;
    }
    private _flr2_Area: string = "";
    public get flr2_Area(): string {
        return this._flr2_Area;
    }
    public set flr2_Area(value: string) {
        this._flr2_Area = value;
    }
    private _flr3_Rooms: any = "";
    public get flr3_Rooms(): any {
        return this._flr3_Rooms;
    }
    public set flr3_Rooms(value: any) {
        this._flr3_Rooms = value;
    }
    private _flr3_Area: string = "";
    public get flr3_Area(): string {
        return this._flr3_Area;
    }
    public set flr3_Area(value: string) {
        this._flr3_Area = value;
    }
    private _flr4_Rooms: any = "";
    public get flr4_Rooms(): any {
        return this._flr4_Rooms;
    }
    public set flr4_Rooms(value: any) {
        this._flr4_Rooms = value;
    }
    private _flr4_Area: string = "";
    public get flr4_Area(): string {
        return this._flr4_Area;
    }
    public set flr4_Area(value: string) {
        this._flr4_Area = value;
    }
    private _flr5_Rooms: any = "";
    public get flr5_Rooms(): any {
        return this._flr5_Rooms;
    }
    public set flr5_Rooms(value: any) {
        this._flr5_Rooms = value;
    }
    private _flr5_Area: string = "";
    public get flr5_Area(): string {
        return this._flr5_Area;
    }
    public set flr5_Area(value: string) {
        this._flr5_Area = value;
    }
    public get totalArea_NonFlat(): string {
        return this.NonFlatList.map(x => { return x.area; })?.reduce((a, b) => Number(a) + Number(b), 0);
    }
    private _finalValLTV: any = "";
    public get finalValLTV(): any {
        return this._finalValLTV;
    }
    public set finalValLTV(value: any) {
        this._finalValLTV = value;
    }


    getFinalLTV() {
        let ltvPer = this.appliedLTV != "" ? Number(this.appliedLTV) / 100 : 0;
        let ltV_TotalPropVal = this.ltV_TotalPropVal != "" ? Number(this.ltV_TotalPropVal) : 0;
        this.propValInternal = (ltvPer * ltV_TotalPropVal).toFixed(0);

        let technicalvaluation = this.technicalvaluation && this.technicalvaluation != "" ? Number(this.technicalvaluation ?? 0) : 0;
        this.propValExternal= (ltvPer * technicalvaluation).toFixed(0);

        let propValInternal = this.propValInternal && this.propValInternal != '' ? Number(this.propValInternal) : 0;
        let propValExternal = this.propValExternal && this.propValExternal != '' ? Number(this.propValExternal) : 0;
        if (this.technicalval_status && this.technicalval_status?.toLowerCase() == 'n') {
            this.finalValLTV = propValInternal;
        }
        else {
            this.finalValLTV = propValInternal > propValExternal ? propValExternal : propValInternal;
        }
    }

    getTotalVal()
    {
        let plotcircleRate = this.plotCircleRate != "" ? Number(this.plotCircleRate) : 0;
        let plotMarketRate = this.plotMarketRate != "" ? Number(this.plotMarketRate) : 0;
        let builtCircleRate = this.builtCircleRate != "" ? Number(this.builtCircleRate) : 0;
        let builtMarketRate = this.builtMarketRate != "" ? Number(this.builtMarketRate) : 0;
        if (plotcircleRate != 0 && plotMarketRate != 0 && builtMarketRate != 0 && builtCircleRate != 0) {
            let plotArea = this.plotArea != "" ? Number(this.plotArea) : 0;
            let builtArea = this.builtArea != "" ? Number(this.builtArea) : 0;
            this.totalVal= (((plotcircleRate + plotMarketRate) / 2) * plotArea) + (((builtCircleRate + builtMarketRate) / 2) * builtArea).toFixed(2);
        }
        this.totalVal= "0";
    }

}

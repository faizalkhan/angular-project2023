import { Injectable } from '@angular/core';
import { NotificationService } from 'src/app/notification.service';
import { Dropdown, IDropdown } from 'src/app/shared/models/common/control.model';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { IValidation } from '../../layout/error-message/error-message.component';
import { APIResponse, CamDetail, ICamDetail } from './propertyvaluation';
import { PropertyDetail } from "./PropertyDetail";
import { IPropertyDetail } from "./IPropertyDetail";

@Injectable({
  providedIn: 'root'
})
export class PropertyvaluationService {
  propertyvaluation: IPropertyDetail = new PropertyDetail();
  private _circleRates: ICamDetail = new CamDetail();
  private _PropertyType: IDropdown[] = [];
  public get PropertyType(): IDropdown[] {
    return this._PropertyType;
  }
  public set PropertyType(value: IDropdown[]) {
    this._PropertyType = value;
  }
  public get circleRates(): ICamDetail {
    if (this._circleRates) {
      return this._circleRates;
    }
    else {
      return this._circleRates;
    }

  }
  public set circleRates(value: ICamDetail) {
    this._circleRates = value;
  }
  constructor(private http: ConfigService, private notify: NotificationService, private sanctionService: SanctionService) {
    this.getCircleRates();
  }
  getCircleRates() {
    var data = {
      "userID": this.sanctionService.LanInfo.flopsid
    };

    this.http.httpPost<ICamDetail>(data, 'LAP_GetCircleRate').subscribe((res: ICamDetail) => {
      this.circleRates = new CamDetail(res);
      this.PropertyType = [...new Set(this._circleRates.data.map(x => {
        return new Dropdown({ displayName: x.prop_Type });
      }))];
    })
  }
  getPropValuationsDetails() {
    let lanInfo = this.sanctionService.LanInfo;

    let data = {
      "LoanAccountNumber": lanInfo.lan,
      "FLO_PsId": lanInfo.flopsid
    };
    this.http.httpPost<APIResponse>(data, 'GetLAP_PropertyValuation').subscribe((res: APIResponse) => {
      if (res.errorcode == "00" || res.errorcode == "0" || res.errorcode == "") {
        this.propertyvaluation = new PropertyDetail(res.data[0]);
        this.propertyvaluation.data = res.propertyOwner;
      }
      else {
        this.propertyvaluation = new PropertyDetail();
        this.notify.showError(res.errorDescription);
      }
    });
  }
  submit(propertyvaluation: IPropertyDetail) {
    this.propertyvaluation = propertyvaluation;
    if (this.FinalValidation()) {
      this.http.httpPost<IresponseModel<any>>(propertyvaluation.ConvertJSON(), 'LAP_PropertyValuation').subscribe((res: IresponseModel<any>) => {
        if (res.errorcode == "00") {
          this.notify.showSuccess(res.errorDescription);
        }
        else {
          this.notify.showError(res.errorDescription);
        }
      })
    }
  }
  FinalValidation(): boolean {
    let data = this.ValuationDetail();
    if ((data?.errorMessage ?? "") != "") {
      this.notify.showWarning(data?.errorMessage);
      return false;
    }
    data = this.StructureValidate();
    if ((data?.errorMessage ?? "") != "") {
      this.notify.showWarning(data?.errorMessage);
      return false;
    }
    data = this.PropertyDocumentValidate();
    if ((data?.errorMessage ?? "") != "") {
      this.notify.showWarning(data?.errorMessage);
      return false;
    }
    data = this.LTVValidate();
    if ((data?.errorMessage ?? "") != "") {
      this.notify.showWarning(data?.errorMessage);
      return false;
    }
    return true;
  }
  ValuationDetail(): IValidation {
    if (!this.propertyvaluation.constructionQuality || this.propertyvaluation.constructionQuality == "") {
      return { errorMessage: "Required Construction Quality" } as IValidation;
    }
    else if (!this.propertyvaluation.constructionYear || this.propertyvaluation.constructionYear == "") {
      return { errorMessage: "Required Construction Year" } as IValidation;
    }
    else if (!this.propertyvaluation.property_Type || this.propertyvaluation.property_Type == "") {
      return { errorMessage: "Required Property Type" } as IValidation;
    }
    else if (!this.propertyvaluation.constructionType || this.propertyvaluation.constructionType == "") {
      return { errorMessage: "Required Construction Type" } as IValidation;
    }
    else if (!this.propertyvaluation.materialRoof || this.propertyvaluation.materialRoof == "") {
      return { errorMessage: "Required Materials Used in Roofs" } as IValidation;
    }
    else if (!this.propertyvaluation.residualValYrs || this.propertyvaluation.residualValYrs == "") {
      return { errorMessage: "Required Estimated Residual Value (in Years)" } as IValidation;
    }
    if (this.propertyvaluation.residualValYrs && Number(this.propertyvaluation.residualValYrs) > 50) {
      return { errorMessage: "Estimated Residual Value (in Years) >50 years not allowed as per policy norms" } as IValidation;
    }
    else if (this.propertyvaluation.north_AsperDoc_YN.toLowerCase() == 'n' && (!this.propertyvaluation.north_AsperInv || this.propertyvaluation.north_AsperInv == "")) {
      return { errorMessage: "Required north as per investigation." } as IValidation;
    }
    else if (this.propertyvaluation.south_AsperDoc_YN.toLowerCase() == 'n' && (!this.propertyvaluation.south_AsperInv || this.propertyvaluation.south_AsperInv == "")) {
      return { errorMessage: "Required south as per investigation." };
    }
    else if (this.propertyvaluation.east_AsperDoc_YN.toLowerCase() == 'n' && (!this.propertyvaluation.east_AsperInv || this.propertyvaluation.east_AsperInv == "")) {
      return { errorMessage: "Required east as per investigation." };
    }
    else if (this.propertyvaluation.west_AsperDoc_YN.toLowerCase() == 'n' && (!this.propertyvaluation.west_AsperInv || this.propertyvaluation.west_AsperInv == "")) {
      return { errorMessage: "Required west as per investigation." };
    }
    else if (!this.propertyvaluation.unitDetails || this.propertyvaluation.unitDetails == '') {
      return { errorMessage: "Required unit detail" };
    }
    else if (this.propertyvaluation.unitDetails.toLowerCase() == 'flat' && (!this.propertyvaluation.kitchen_Area || this.propertyvaluation.kitchen_Area == '')) {
      return { errorMessage: "Required area of kitchen" };
    }
    else if (this.propertyvaluation.unitDetails.toLowerCase() == 'flat' && (!this.propertyvaluation.bedroom_Area || this.propertyvaluation.bedroom_Area == '')) {
      return { errorMessage: "Required area of bedroom" };
    }
    else if (this.propertyvaluation.unitDetails.toLowerCase() == 'flat' && (!this.propertyvaluation.hall_Area || this.propertyvaluation.hall_Area == '')) {
      return { errorMessage: "Required area of hall" };
    }
    else if (this.propertyvaluation.unitDetails.toLowerCase() == 'flat' && (!this.propertyvaluation.washroom_Area || this.propertyvaluation.washroom_Area == '')) {
      return { errorMessage: "Required area of washroom" };
    }
    else if (this.propertyvaluation.unitDetails.toLowerCase() == 'flat' && this.propertyvaluation.others_dtl && (!this.propertyvaluation.other_Area || this.propertyvaluation.other_Area == '')) {
      return { errorMessage: "Required area of other" };
    }
    else if (this.propertyvaluation.unitDetails.toLowerCase() == 'flat' && this.propertyvaluation.other_Area && Number(this.propertyvaluation.other_Area)>0 && (!this.propertyvaluation.others_dtl || this.propertyvaluation.others_dtl == '')) {
      return { errorMessage: "Please specify details of other room mentioned for flat." };
    }
    else if (this.propertyvaluation.unitDetails.toLowerCase() != 'flat' && this.propertyvaluation.NonFlatList.length == 0) {
      return { errorMessage: "Please provide room and area details." };
    }
    else if (this.propertyvaluation.unitDetails.toLowerCase() != 'flat' && this.propertyvaluation.NonFlatList.filter(x => { return (!x.room || x.room == '') }).length > 0) {
      return { errorMessage: "Please provide room and area details." };
    }
    else if (this.propertyvaluation.unitDetails.toLowerCase() != 'flat' && this.propertyvaluation.NonFlatList.filter(x => { return (!x.area || x.area == '') }).length > 0) {
      return { errorMessage: "Please provide room and area details." };
    }
    return { errorMessage: "" };
  }

  StructureValidate(): IValidation {
    let rate = this.circleRates.getMaxRate(this.propertyvaluation.age, this.propertyvaluation.property_Type, this.propertyvaluation.constructionType);
    if (rate) {
      let MarketRate = this.propertyvaluation.builtMarketRate != "" ? Number(this.propertyvaluation.builtMarketRate) : 0;

      if (MarketRate > rate) {
        return { errorMessage: "Max value allowed for market rate of built-up area" + ": " + rate };
      }
    }
    else {
      return { errorMessage: "Please check the circle rate not matched" };
    }
    return { errorMessage: undefined };
  }

  PropertyDocumentValidate(): IValidation {
    if (!this.propertyvaluation.propertyUsageType || this.propertyvaluation.propertyUsageType == "") {
      return { errorMessage: "Required property usage type" } as IValidation;
    }
    else if (this.propertyvaluation.propertyUsageType.toLowerCase() == "both" && (!this.propertyvaluation.commercialUsePercentage || this.propertyvaluation.commercialUsePercentage == "")) {
      return { errorMessage: "Required Percentage of Property used for commercial purpose" } as IValidation;
    }
    else if (this.propertyvaluation.propertyUsageType.toLowerCase() == "both" && (Number(this.propertyvaluation.commercialUsePercentage) > 50)) {
      return { errorMessage: "% of Property Used for commercial purpose>50% Not allowed as per Policy Norms" } as IValidation;
    }
    else if (!this.propertyvaluation.landArea && this.propertyvaluation.landArea == "") {
      return { errorMessage: "Required land area" } as IValidation;
    }
    else if ((this.propertyvaluation.propertyUsageType.toLowerCase() == "residential" || this.propertyvaluation.propertyUsageType.toLowerCase() == "both") && Number(this.propertyvaluation.landArea) < 500) {
      return { errorMessage: "Land Area less than 500 sqft not allowed as per policy norms" } as IValidation;
    }
    else if ((this.propertyvaluation.propertyUsageType.toLowerCase() == "commercial") && Number(this.propertyvaluation.landArea) < 250) {
      return { errorMessage: "Land Area less than 250 sqft not allowed as per policy norms." } as IValidation;
    }
    else if ((this.propertyvaluation.propertyUsageType.toLowerCase() == "residential" || this.propertyvaluation.propertyUsageType.toLowerCase() == "both" || this.propertyvaluation.propertyUsageType.toLowerCase() == 'commercial') && Number(this.propertyvaluation.landArea) > 5000) {
      return { errorMessage: "As per policy Land Area should not allowed greater than 5000." } as IValidation;
    }
    else if (!this.propertyvaluation.constructedArea || this.propertyvaluation.constructedArea == "") {
      return { errorMessage: "Required Constructed Area" } as IValidation;
    }
    else if (this.propertyvaluation.constructedArea && Number(this.propertyvaluation.constructedArea)>5000) {
      return { errorMessage: "Constructed Area cannot be greater than 5000 sq ft. as per policy norms." } as IValidation;
    }
    else if ((Number(this.propertyvaluation.constructedArea) < (Number(this.propertyvaluation.landArea) * .5))) {

      return { errorMessage: "Contructed Area cannot be less than 50 % of Land Area as per policy norms" } as IValidation;
    }
    else if (!this.propertyvaluation.roadWidth || this.propertyvaluation.roadWidth == "") {
      return { errorMessage: "Required Width of the Entrance Road" } as IValidation;
    }
    else if (Number(this.propertyvaluation.roadWidth) > 60) {
      return { errorMessage: "Width of the Entrance Road allowed maximimum 60ft" } as IValidation;
    }
    else if (Number(this.propertyvaluation.roadWidth) < 4 && (!this.propertyvaluation.remarks_roadwidth || this.propertyvaluation.remarks_roadwidth == "")) {
      return { errorMessage: "Please input remark (for road width <4 ft)" } as IValidation;
    }
    else if (this.propertyvaluation.titleDocs.filter(x => { return (!x.description || x.description == "") }).length > 0) {
      return { errorMessage: "Please enter the document name" } as IValidation;
    }
    else if (this.propertyvaluation.titleDocs.filter(x => { return (!x.doc_Ref || x.doc_Ref == "") }).length > 0) {
      return { errorMessage: "Please upload the document." } as IValidation;
    }
    return { errorMessage: undefined };
  }

  LTVValidate(): IValidation {
    if (!this.propertyvaluation.titleChainYrs || this.propertyvaluation.titleChainYrs < 5) {
      return { errorMessage: "Title Chain <5 years not allowed" } as IValidation;
    }
    if (this.propertyvaluation.titleChainYrs && (this.propertyvaluation.loanAmount > 200000 && this.propertyvaluation.titleChainYrs < 13)) {
      return { errorMessage: "Title Chain < 13 years not allowed for loan amount > 2 lakhs" } as IValidation;
    }
    else if (!this.propertyvaluation.appliedLTV || this.propertyvaluation.appliedLTV == "") {
      return { errorMessage: "Please enter Applied LTV % value." } as IValidation;
    }
    else if (Number(this.propertyvaluation.appliedLTV) < 1) {
      return { errorMessage: "Please enter Applied LTV % value." } as IValidation;
    }
    else if (Number(this.propertyvaluation.appliedLTV) > Number(this.propertyvaluation.ltvPer)) {
      return { errorMessage: "Applied LTV % > LTV % as per policy norms is not allowed. " } as IValidation;
    }
    return { errorMessage: undefined };
  }

  UnitDetailChange() {
    if (this.propertyvaluation.unitDetails.toLowerCase() == "flat") {
      this.propertyvaluation.flr1_Area = "";
      this.propertyvaluation.flr1_Rooms = "";
      this.propertyvaluation.flr2_Area = "";
      this.propertyvaluation.flr2_Rooms = "";
      this.propertyvaluation.flr3_Area = "";
      this.propertyvaluation.flr3_Rooms = "";
      this.propertyvaluation.flr4_Area = "";
      this.propertyvaluation.flr4_Rooms = "";
      this.propertyvaluation.flr5_Area = "";
      this.propertyvaluation.flr5_Rooms = "";
    }
    else {
      this.propertyvaluation.kitchen_Area = "";
      this.propertyvaluation.bedroom_Area = "";
      this.propertyvaluation.hall_Area = "";
      this.propertyvaluation.washroom_Area = "";
      this.propertyvaluation.other_Area = "";
      this.propertyvaluation.others_dtl = "";
      this.propertyvaluation.NonFlatList = this.propertyvaluation.GetNonFlatList();
    }

  }
}





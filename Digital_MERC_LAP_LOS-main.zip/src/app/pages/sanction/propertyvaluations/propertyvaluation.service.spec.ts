import { TestBed } from '@angular/core/testing';

import { PropertyvaluationService } from './propertyvaluation.service';

describe('PropertyvaluationService', () => {
  let service: PropertyvaluationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PropertyvaluationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

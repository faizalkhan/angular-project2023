import { Component, OnInit } from '@angular/core';
import { InfoServices } from 'src/app/Injectable/info.services';
import { NotificationService } from 'src/app/notification.service';
import { IDropdown } from 'src/app/shared/models/common/control.model';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
import { AccomodationAndComposition, IAccomodationAndComposition } from 'src/app/shared/models/sanction/AccomodationAndComposition';
import { AmenitiesAndLifestyle, IAmenitiesAndLifeStyle } from 'src/app/shared/models/sanction/amenities-life-style/amenitieslifestyle';
import { ISanctionDashboardModel, SanctionDashboardModel } from 'src/app/shared/models/sanction/dashboard';
import { IMonthlyHouseholdExpenditure, MonthlyHouseholdExpenditure } from 'src/app/shared/models/sanction/monthly-household-expenditure/monthlyhouseholdexpenditure';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { AccomadationCompositionComponent } from '../../layout/functional/ha-accomadation-composition/haaccomadationcomposition.component';
import { HouseholdAssessmentService } from './household-assessment.service';

@Component({
    selector: "household-assessment",
    templateUrl: "./household-assessment.component.html",
    styleUrls: ["./household-assessment.component.css"],
    providers: [ConfigService, HouseholdAssessmentService]
})
export class HouseholdAssessmentComponent implements OnInit {
    private _MonthlyExp: IMonthlyHouseholdExpenditure = new MonthlyHouseholdExpenditure();
    private _AmenitiesAndLifestyleModel: IAmenitiesAndLifeStyle = new AmenitiesAndLifestyle();
    private _AccomondationGroup: IAccomodationAndComposition = new AccomodationAndComposition();

    public get AccomondationGroup(): IAccomodationAndComposition {
        return this._AccomondationGroup;
    }
    public set AccomondationGroup(value: IAccomodationAndComposition) {
        this._AccomondationGroup = value;
    }
    public get AmenitiesAndLifestyleModel(): IAmenitiesAndLifeStyle {
        return this._AmenitiesAndLifestyleModel;
    }
    public set AmenitiesAndLifestyleModel(value: IAmenitiesAndLifeStyle) {
        this._AmenitiesAndLifestyleModel = value;
    }
    public get MonthlyExp(): IMonthlyHouseholdExpenditure {
        return this._MonthlyExp;
    }
    public set MonthlyExp(value: IMonthlyHouseholdExpenditure) {
        this._MonthlyExp = value;
    }

    isEdit: boolean = false;
    ListOf: IDropdown[] = [];
    url: any = "LAP_HA_GetCustPointVerification";

    requestData: ISanctionDashboardModel = new SanctionDashboardModel();
    public get RequestData(): any {
        return {
            "LoanAccountNumber": this.requestData.lan,
            "FLO_PsId": this.requestData.flopsid,
            "CreatedON": this.requestData.dateSourced
        }
    }
    public set RequestData(value: any) {
        this.requestData = value;
    }

    ngOnInit(): void {
        this.requestData = this.Info.LanInfo;
        this.HAService.getMonthlyExp().subscribe((res: IMonthlyHouseholdExpenditure) => {
            this.MonthlyExp = res;
            this.MonthlyExp.flO_PsId=this.Info.LanInfo.flopsid;
        });
        this.HAService.getAmenitiesAndLifestyle().subscribe((res: IAmenitiesAndLifeStyle) => {
            this.AmenitiesAndLifestyleModel = res;
            this.AmenitiesAndLifestyleModel.flO_PsId=this.Info.LanInfo.flopsid;
        })
        this.HAService.AccomondationGroup.subscribe((res: IAccomodationAndComposition) => {
            this.AccomondationGroup = res;
            this.AccomondationGroup.flO_PsId=this.Info.LanInfo.flopsid;
        })
        this.ListOf = [{ displayName: 'Public', selected: true, value: 'Public' }, { displayName: 'Private', selected: false, value: 'Private' }]
    }

    constructor(private http: ConfigService, private Info: SanctionService, private HAService: HouseholdAssessmentService, private notify: NotificationService) {

    }
    OnChange(event: any, data: any) {
        switch (data) {
            case 'electricityWaterGas':
                this.MonthlyExp.electricityWaterGas = event;
                break;
            case 'entertainmentReligiousExpensesMonthly':
                this.MonthlyExp.entertainmentReligiousExpensesMonthly = event;
                break;
            case 'foodNOtherHouseholdExp':
                this.MonthlyExp.foodNOtherHouseholdExp = event;
                break;
            case 'insuranceMediclaimPremium':
                this.MonthlyExp.insuranceMediclaimPremium = event;
                break;
            case 'otherMonthlyExpenses':
                this.MonthlyExp.otherMonthlyExpenses = event;
                break;
            case 'otherUtilities':
                this.MonthlyExp.otherUtilities = event;
                break;
            case 'rent':
                this.MonthlyExp.rent = event;
                break;
            case 'schoolCollegeFees':
                this.MonthlyExp.schoolCollegeFees = event;
                break;
            case 'transportAndOtherConveyanceExp':
                this.MonthlyExp.transportAndOtherConveyanceExp = event;
                break;
        }
    }
    public get IsRented(): boolean {
        return this.AmenitiesAndLifestyleModel.shop.toLowerCase().startsWith('y') && this.AmenitiesAndLifestyleModel.shopType.toLowerCase() == "rented";
    }
    public get IsElectrical(): boolean {
        return this.AmenitiesAndLifestyleModel.electricity.toLowerCase().startsWith('y');
    }

    public get IsSchool(): boolean {
        return (this.AccomondationGroup?.noOfChildrenGoingToSchoolNCollege ?? 0) > 0;
    }
    Cancel(event: IMonthlyHouseholdExpenditure) {
        this.MonthlyExp = new MonthlyHouseholdExpenditure(event);
    }
    Validation() {
        this.MonthlyExp.isError = false;
        this.MonthlyExp.errorMessage = "";
        if (this.IsRented && (!this.MonthlyExp.rent || this.MonthlyExp.rent.toString() == "")) {
            this.MonthlyExp.errorMessage = "Please enter rent";
        }
        if (this.IsRented && this.MonthlyExp.rent && Number(this.MonthlyExp.rent) == 0) {
            this.MonthlyExp.errorMessage = "Please enter rent";
        }
        else if (this.MonthlyExp.foodNOtherHouseholdExp.toString() == "") {
            this.MonthlyExp.errorMessage = "Food and other household expenses is required";
        }
        else if (this.IsElectrical && (!this.MonthlyExp.electricityWaterGas || this.MonthlyExp.electricityWaterGas.toString() == "")) {
            this.MonthlyExp.errorMessage = "Electricity/Water/Gas Expenses is required";
        }
        else if (this.IsElectrical && this.MonthlyExp.electricityWaterGas && Number(this.MonthlyExp.electricityWaterGas.toString())==0) {
            this.MonthlyExp.errorMessage = "Electricity/Water/Gas Expenses is required";
        }
        else if (this.MonthlyExp.insuranceMediclaimPremium.toString() == "") {
            this.MonthlyExp.errorMessage = "Insurance/Mediclaim premium is required";
        }
        else if (this.MonthlyExp.otherUtilities.toString() == "") {
            this.MonthlyExp.errorMessage = "Other utillities Expenses(Mobile/Data/Cable etc) is required";
        }
        else if (this.MonthlyExp.otherMonthlyExpenses.toString() == "") {
            this.MonthlyExp.errorMessage = "Other Monthly Expenses is required";
        }
        else if (this.MonthlyExp.transportAndOtherConveyanceExp.toString() == "") {
            this.MonthlyExp.errorMessage = "Transport and other conveyance expenses is required";
        }
        else if (this.MonthlyExp.entertainmentReligiousExpensesMonthly.toString() == "") {
            this.MonthlyExp.errorMessage = "Entertainment/ Religious Expenses Monthly is required";
        }
        else if (this.IsSchool && (!this.MonthlyExp.schoolCollegeFees || this.MonthlyExp.schoolCollegeFees.toString() == "")) {
            this.MonthlyExp.errorMessage = "School/Collage fees is required";
        }
        else if (this.IsSchool && this.MonthlyExp.schoolCollegeFees && Number(this.MonthlyExp.schoolCollegeFees)==0) {
            this.MonthlyExp.errorMessage = "School/Collage fees is required";
        }
        if (this.MonthlyExp.errorMessage.length > 0) {
            this.notify.showWarning(this.MonthlyExp.errorMessage);
            this.MonthlyExp.isError = true;
        }
    }
    Submit() {
        this.Validation();
        if (!this.MonthlyExp.isError) {
            this.http.httpPost(this.MonthlyExp.toJSON(), 'LAP_HA_MonthlyHouseholdExpenditure').subscribe((res: any) => {
                this.isEdit = !this.isEdit;
            })
        }
    }

    edit() {
        this.isEdit = !this.isEdit;
    }



}


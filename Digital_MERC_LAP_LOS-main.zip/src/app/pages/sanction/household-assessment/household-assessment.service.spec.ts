import { TestBed } from '@angular/core/testing';

import { HouseholdAssessmentService } from './household-assessment.service';

describe('HouseholdAssessmentService', () => {
  let service: HouseholdAssessmentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HouseholdAssessmentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

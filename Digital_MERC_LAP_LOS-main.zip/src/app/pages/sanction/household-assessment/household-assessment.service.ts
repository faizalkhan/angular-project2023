import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
import { AccomodationAndComposition, IAccomodationAndComposition } from 'src/app/shared/models/sanction/AccomodationAndComposition';
import { AmenitiesAndLifestyle, IAmenitiesAndLifeStyle } from 'src/app/shared/models/sanction/amenities-life-style/amenitieslifestyle';
import { ISanctionDashboardModel } from 'src/app/shared/models/sanction/dashboard';
import { IMonthlyHouseholdExpenditure, MonthlyHouseholdExpenditure } from 'src/app/shared/models/sanction/monthly-household-expenditure/monthlyhouseholdexpenditure';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';

@Injectable({
  providedIn: 'root'
})
export class HouseholdAssessmentService {
  MonthlyExp = new Subject<IMonthlyHouseholdExpenditure>();
  AmenitiesAndLifestyle = new Subject<IAmenitiesAndLifeStyle>();
  AccomondationGroup = new Subject<IAccomodationAndComposition>();
  getMonthlyExp() {
    return this.MonthlyExp.asObservable();
  }
  getAmenitiesAndLifestyle() {
    return this.AmenitiesAndLifestyle.asObservable();
  }
  getAccomondationGroup() {
    return this.AccomondationGroup.asObservable();
  }
  RequestData: any;
  constructor(private http: ConfigService, private sanctionService: SanctionService) {
    let data = this.sanctionService.LanInfo as ISanctionDashboardModel;
    this.RequestData = {
      "LoanAccountNumber": data.lan,
      "FLO_PsId": data.flopsid,
      "CreatedON": data.dateSourced
    };
    this.GetMonthlyHouseholdExpenditure();
    this.GetAmenitiesAndLifestyle();
    this.GetAccomodationComposition();
  }

  GetMonthlyHouseholdExpenditure() {
    this.http.httpPost<IresponseModel<IMonthlyHouseholdExpenditure[]>>(this.RequestData, 'GetLAP_HA_MonthlyHouseholdExpenditure').subscribe((res: IresponseModel<IMonthlyHouseholdExpenditure[]>) => {
      let data = new MonthlyHouseholdExpenditure(res.data[0]);
      data.flO_PsId = this.RequestData.flO_PsId;
      this.MonthlyExp.next(data);
    })
  }
  GetAmenitiesAndLifestyle(): void {
    this.http.httpPost<IresponseModel<IAmenitiesAndLifeStyle[]>>(this.RequestData, 'GetLAP_HA_AmenitiesAndLifestyle').subscribe((res: IresponseModel<IAmenitiesAndLifeStyle[]>) => {
      if (res.errorcode == "00" || res.errorcode == "01") {
        if (res.data[0] !== undefined && res.data[0] !== null) {
          res.data[0].vehicle = res.vehicle;
        }
        let data = new AmenitiesAndLifestyle(res.data[0]);
        data.flO_PsId = this.RequestData.flO_PsId;
        this.AmenitiesAndLifestyle.next(data);
      }
    })
  }
  GetAccomodationComposition() {

    this.http.httpPost<IresponseModel<IAccomodationAndComposition[]>>(this.RequestData, 'GetLAP_HA_AccomodationAndComposition').subscribe((res: IresponseModel<IAccomodationAndComposition[]>) => {
      if (res.errorcode == "00" || res.errorcode == "01") {
        let data = new AccomodationAndComposition(res.data[0]);
        data.flO_PsId = this.RequestData.flO_PsId;
        this.AccomondationGroup.next(data);
      }
    })
  }
}

import { TestBed } from '@angular/core/testing';
import { incomeAssessmentService } from './income-assessment.service';


describe('incomeAssessmentService', () => {
  let service: incomeAssessmentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(incomeAssessmentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { Component, OnInit, ViewChild } from "@angular/core";
import { TabHeadingDirective } from "ngx-bootstrap/tabs";
import { InfoServices } from "src/app/Injectable/info.services";
import { AppDynamicDirective } from "src/app/shared/directive/app-dynamic.directive";
import { Dropdown, IDropdown } from "src/app/shared/models/common/control.model";
import { ISanctionDashboardModel, SanctionDashboardModel } from "src/app/shared/models/sanction/dashboard";
import { ApplicantDetail, SanctionResponse } from "src/app/shared/models/sanction/lap-sanctionapplicationdetails";
import { ISanctionRequestData } from "src/app/shared/models/sanction/sanction.model";
import { ConfigService } from "src/app/shared/services/common/http.services";
import { SanctionService } from "src/app/shared/services/sanction/sanction.service";
import { SalariedComponent } from "../../layout/functional/salaried/salaried.component";
import { ISelfEmployedModel } from "../../layout/functional/self-employed/ISelfEmployedModel";
import { SelfemployedComponent } from "../../layout/functional/self-employed/selfemployed.component";
import { incomeAssessmentService } from "./income-assessment.service";

@Component({
    selector: "app-incomeassessment",
    templateUrl: "./incomeassessment.component.html",
    styleUrls: ["./incomeassessment.component.css"],
})
export class IncomeAssessmentComponent implements OnInit {

    @ViewChild(AppDynamicDirective, { static: true }) dynamicHost!: AppDynamicDirective;

    panelOpenState: boolean = false;
    private _requestData: ISanctionDashboardModel = new SanctionDashboardModel();
    isSalaried: boolean = false;
    trade: any;
    data: any;
    dataWithLan: any;
    private _salairedRequest: any;
    public get SalairedRequest(): any {
        return this._salairedRequest;
    }
    public set SalairedRequest(value: any) {
        this._salairedRequest = value;
    }
    public get TradeList(): IDropdown[] { 
        let finCustomer = this.selectedFinacialCustomer;
        if (this.IAService.SelfEmployed.length > 0 && finCustomer!=="0")
            return [...[new Dropdown({ displayName: "select" })], ...this.IAService.SelfEmployed.map(x => { return new Dropdown({ displayName: x.line_of_Business }); })];
        else
            return [];

    }
    public get RequestData(): any {
        return {
            "LoanAccountNumber": this._requestData.lan,
            "FLO_PsId": this._requestData.flopsid,
            "CreatedON": this._requestData.dateSourced
        }
    }
    public set RequestData(value: ISanctionDashboardModel) {
        this._requestData = value;
    }
    private _finacialCustomerList: ApplicantDetail[] = [];
    public get finacialCustomerList(): IDropdown[] {

        let _list = this._finacialCustomerList.map((x) => {
            return new Dropdown({ displayName: x.applicantName, value: x.applicationNo, selected: x.selected } as IDropdown)
        });

        return [...[new Dropdown({ displayName: "Select", value: "0", selected: true })], ..._list];
    }

    finacialCustomer: string = "0";
    selectedFinacialCustomer: string = "0";

    get finacialProfile(): any {
        if (this.finacialCustomer) {
            return this._finacialCustomerList?.find(x => { return x.applicationNo == this.finacialCustomer; })?.salary_Status;
        }
        else {
            return "";
        }
    }



    constructor(private info: InfoServices,
        private http: ConfigService,
        private _sanctionService: SanctionService,
        public IAService: incomeAssessmentService) {
        this.RequestData = JSON.parse(this.info.getItem('LanInfo')) as ISanctionDashboardModel;
    }
    ngOnInit(): void {
        this._finacialCustomerList = this._sanctionService.GetFinacialRecord();
    }

    loadfinacial(event: any) {

        this.selectedFinacialCustomer = event.currentTarget.value;

        if (event.currentTarget.value && event.currentTarget.value != "0") {
            this.finacialCustomer = event.currentTarget.value;
            let viewConst = this.dynamicHost.viewContainerRef;
            viewConst.clear();
            this.data = {
                "ApplicationNo": event.currentTarget.value,
                "FLO_PsId": this._requestData.flopsid,
                "CreatedON": "2022-08-26"
            } as ISanctionRequestData;


            this.dataWithLan = {
                "ApplicationNo": event.currentTarget.value,
                "FLO_PsId": this._requestData.flopsid,
                "CreatedON": "2022-08-26",
                "LoanAccountNumber": this._requestData.lan
            } as ISanctionRequestData;

            if (this.finacialProfile == "Self Employed") {
                this.IAService.GetSelfEmployed(this.data);

            }
            else {
                this.IAService.SelfEmployed = [];
                let componentRef = viewConst.createComponent<SalariedComponent>(SalariedComponent);
                componentRef.instance.requestData = this.dataWithLan as ISanctionRequestData;
            }
        }
    }

    loadtrade(event: any) {
        let viewConst = this.dynamicHost.viewContainerRef;
        this.trade = this.IAService.currentTrade = event.currentTarget.value;
        viewConst.clear();
        let componentRef = viewConst.createComponent<SelfemployedComponent>(SelfemployedComponent);
        componentRef.instance.RequestData = this.data as ISanctionRequestData;
        componentRef.instance.RequestDataWithLan = this.dataWithLan as ISanctionRequestData;
        componentRef.instance.SelfEmployed = this.IAService.SelfEmployed.find(x => x.line_of_Business == event.currentTarget.value) as ISelfEmployedModel;
    }
}
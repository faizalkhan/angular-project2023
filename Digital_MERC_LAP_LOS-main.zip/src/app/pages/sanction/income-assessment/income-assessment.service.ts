import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { NotificationService } from 'src/app/notification.service';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { ISelfEmployedModel } from '../../layout/functional/self-employed/ISelfEmployedModel';
import { SelfEmployedModel } from '../../layout/functional/self-employed/SelfEmployedModel';
@Injectable({
  providedIn: 'root'
})
export class incomeAssessmentService {
  requestData: any;
  currentTrade: any = "";
  SelfEmployed: ISelfEmployedModel[] = [];
  constructor(private http: ConfigService,
    private notify: NotificationService) {

  }
  GetSelfEmployed(data: any) {
    this.http.httpPost<IresponseModel<ISelfEmployedModel[]>>(data, 'GetLAP_IA_SelfEmployed').subscribe((res: IresponseModel<ISelfEmployedModel[]>) => {
      this.SelfEmployed = [];
      if (res.errorcode == "00") {
        this.SelfEmployed = res.data.map((x: ISelfEmployedModel) => { return new SelfEmployedModel(x); });
      }
      else {
        this.notify.showError(res.errorDescription);
      }
    })
  }
  SaveSelfEmployed(data: ISelfEmployedModel) {

  }


}

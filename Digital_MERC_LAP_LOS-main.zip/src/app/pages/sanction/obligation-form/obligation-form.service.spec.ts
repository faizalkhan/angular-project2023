import { TestBed } from '@angular/core/testing';

import { ObligationFormService } from './obligation-form.service';

describe('ObligationFormService', () => {
  let service: ObligationFormService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ObligationFormService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

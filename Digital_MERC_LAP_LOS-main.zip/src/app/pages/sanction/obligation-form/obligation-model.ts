import { common } from "src/app/shared/models/common";

export interface ReqObligation {
    lanNo: string;
    Id: Number;
}

export interface IObligationModel {
    obligationId: number;
    applicantName: string,
    mode: string,
    loanType: string,
    ownershipDtl: string,
    financier: string,
    loanAmount: Number,
    loanStatus: string,
    pos: Number,
    tenure: Number,
    mobileNo: Number,
    balanceTenure: Number,
    repaymentMode: string,
    repaymentBankName: string,
    repaymentBankAccountNo: Number,
    peakDPDLast6Month: Number,
    emiAmount: Number,
    emiToObligate: string,
    remarks: string;
    loanAccountNumber:string;
    toJSON(): any;
}

export class ObligationModel implements IObligationModel {
    private _obligationId: number = 0;
    public get obligationId(): number {
        return this._obligationId;
    }
    public set obligationId(value: number) {
        this._obligationId = value;
    }
    private _applicantName: string = "";
    public get applicantName(): string {
        return this._applicantName;
    }
    public set applicantName(value: string) {
        this._applicantName = value;
    }
    private _mode: string = "";
    public get mode(): string {
        return this._mode;
    }
    public set mode(value: string) {
        this._mode = value;
    }
    private _loanType: string = "";
    public get loanType(): string {
        return this._loanType;
    }
    public set loanType(value: string) {
        this._loanType = value;
    }
    private _ownershipDtl: string = "";
    public get ownershipDtl(): string {
        return this._ownershipDtl;
    }
    public set ownershipDtl(value: string) {
        this._ownershipDtl = value;
    }
    private _financier: string = '';
    public get financier(): string {
        return this._financier;
    }
    public set financier(value: string) {
        this._financier = value;
    }
    private _loanAmount: Number = 0;
    public get loanAmount(): Number {
        return this._loanAmount;
    }
    public set loanAmount(value: Number) {
        this._loanAmount = value;
    }
    private _loanStatus: string = '';
    public get loanStatus(): string {
        return this._loanStatus;
    }
    public set loanStatus(value: string) {
        this._loanStatus = value;
    }
    private _pos: Number = 0;
    public get pos(): Number {
        return this._pos;
    }
    public set pos(value: Number) {
        this._pos = value;
    }
    private _tenure: Number = 0;
    public get tenure(): Number {
        return this._tenure;
    }
    public set tenure(value: Number) {
        this._tenure = value;
    }
    private _mobileNo: Number = 0;
    public get mobileNo(): any {
        return this._mobileNo;
    }
    public set mobileNo(value: any) {
        this._mobileNo = value;
    }
    private _balanceTenure: Number = 0;
    public get balanceTenure(): Number {
        return this._balanceTenure;
    }
    public set balanceTenure(value: Number) {
        this._balanceTenure = value;
    }
    private _repaymentMode: string = '';
    public get repaymentMode(): string {
        return this._repaymentMode;
    }
    public set repaymentMode(value: string) {
        this._repaymentMode = value;
    }
    private _repaymentBankName: string = '';
    public get repaymentBankName(): string {
        return this._repaymentBankName;
    }
    public set repaymentBankName(value: string) {
        this._repaymentBankName = value;
    }
    private _repaymentBankAccountNo: Number = 0;
    public get repaymentBankAccountNo(): any {
        return this._repaymentBankAccountNo;
    }
    public set repaymentBankAccountNo(value: any) {
        this._repaymentBankAccountNo = value;
    }
    private _peakDPDLast6Month: Number = 0;
    public get peakDPDLast6Month(): Number {
        return this._peakDPDLast6Month;
    }
    public set peakDPDLast6Month(value: Number) {
        this._peakDPDLast6Month = value;
    }
    private _emiAmount: Number = 0;
    public get emiAmount(): Number {
        return this._emiAmount;
    }
    public set emiAmount(value: Number) {
        this._emiAmount = value;
    }
    private _emiToObligate: string = '';
    public get emiToObligate(): string {
        return this._emiToObligate;
    }
    public set emiToObligate(value: string) {
        this._emiToObligate = value;
    }
    private _remarks: string = '';
    public get remarks(): string {
        return this._remarks;
    }
    public set remarks(value: string) {
        this._remarks = value;
    }
    private _loanAccountNumber: string = "";
    public get loanAccountNumber(): string {
        return this._loanAccountNumber;
    }
    public set loanAccountNumber(value: string) {
        this._loanAccountNumber = value;
    }
    constructor(params?: IObligationModel) {
        if (params) {
            common.ObjectMapping(params, this);
        }
    }

    toJSON() {
        return {
            "obligationId": this.obligationId,
            "loanAccountNumber": this.loanAccountNumber,
            "applicantName": this.applicantName,
            "mode": this.mode,
            "loanType": this.loanType,
            "ownershipDtl": this.ownershipDtl,
            "financier": this.financier,
            "loanAmount": this.loanAmount,
            "loanStatus": this.loanStatus,
            "pos": this.pos,
            "tenure": this.tenure,
            "mobileNo": this.mobileNo,
            "balanceTenure": this.balanceTenure,
            "repaymentBankName": this.repaymentBankName,
            "repaymentMode": this.repaymentMode,
            "repaymentBankAccountNo": this.repaymentBankAccountNo,
            "peakDpdLast6Month": this.peakDPDLast6Month,
            "emiAmount": this.emiAmount,
            "emiToObligate": this.emiToObligate,
            "remarks": this.remarks
        }
    }

}
import { Injectable } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Observable, of } from 'rxjs';
import { NotificationService } from 'src/app/notification.service';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { ContidionBasedValidate, MobileValidate } from 'src/app/validators/validator';
import { DropdownQuestion, formBase, Hidden, NumericOnly, NumericWithDecimal, TextArea, TextboxQuestion } from '../../layout/layout-form-group/form-group.model';
import { IObligationModel, ObligationModel } from './obligation-model';

@Injectable({
  providedIn: 'root'
})
export class ObligationFormService {
  Obligation: IObligationModel = new ObligationModel();
  private _Obligations: IObligationModel[] = [];
  public get Obligations(): IObligationModel[] {
    return this._Obligations;
  }
  public set Obligations(value: IObligationModel[]) {
    this._Obligations = value;
  }

  private _FinacierList: any[] = [];
  public get FinacierList(): any[] {
    return this._FinacierList;
  }
  public set FinacierList(value: any[]) {
    this._FinacierList = value;
  }
  constructor(private http: ConfigService, private notify: NotificationService, private sanctionService: SanctionService) {
    this.FinacierList = this.sanctionService.GetFinacialRecord().map(x => { return { key: x.applicationNo, value: x.applicantName } })
  }

  getFormControl() {
    let data = [
      new DropdownQuestion(
        {
          key: 'applicantName',
          label: 'Applicant name',
          value: this.Obligation.applicantName,
          required: true,
          options: this.FinacierList,
          order: 1
        }
      ),
      new DropdownQuestion(
        {
          key: 'mode',
          label: 'Mode',
          value: this.Obligation.mode,
          required: true,
          order: 2,
          options: [{ key: 'Bureau', value: 'Bureau' }, { key: 'Manual', value: 'Manual' }]
        }
      )
      ,
      new TextboxQuestion(
        {
          key: 'loanType',
          label: 'Loan Type',
          value: this.Obligation.loanType,
          required: true,
          order: 3
        }
      ),
      new DropdownQuestion(
        {
          key: 'ownershipDtl',
          label: 'Ownership Detail',
          value: this.Obligation.ownershipDtl,
          required: true,
          order: 4,
          options: [{ key: 'Individual', value: 'Individual' }, { key: 'Joint', value: 'Joint' }, { key: 'Guarantor', value: 'Guarantor' }]
        }
      ),
      new TextboxQuestion(
        {
          key: 'financier',
          label: 'Financier',
          value: this.Obligation.financier,
          required: true,
          order: 5
        }
      )
      ,
      new NumericWithDecimal(
        {
          key: 'loanAmount',
          label: 'Loan Amount',
          value: this.Obligation.loanAmount,
          required: true,
          order: 6
        }
      )
      ,
      new DropdownQuestion(
        {
          key: 'loanStatus',
          label: 'Loan Status',
          value: this.Obligation.loanStatus,
          required: true,
          order: 7,
          options: [{ key: 'Active', value: 'Active' }, { key: 'Closed', value: 'Closed' }]


        }
      ),
      new NumericWithDecimal(
        {
          key: 'pos',
          label: 'POS',
          value: this.Obligation.pos,
          required: true,
          order: 8
        }
      ),
      new NumericWithDecimal(
        {
          key: 'tenure',
          label: 'Tenure',
          value: this.Obligation.tenure,
          required: true,
          order: 9
        }
      ),
      new NumericOnly(
        {
          key: 'mobileNo',
          label: 'Mobile No.',
          value: this.Obligation.mobileNo,
          required: true,
          Customevalidator: [new MobileValidate()],
          order: 10
        }
      ),
      new NumericWithDecimal(
        {
          key: 'balanceTenure',
          label: 'Balance Tenure',
          value: this.Obligation.balanceTenure,
          required: true,
          order: 11
        }
      )
      , new DropdownQuestion(
        {
          key: 'repaymentMode',
          label: 'Repayment Mode',
          value: this.Obligation.repaymentMode,
          required: false,
          order: 12,
          options: [{ key: 'Cash', value: 'Cash' }, { key: 'Bank', value: 'Bank' }]
        }
      ),
      new TextboxQuestion(
        {
          key: 'repaymentBankName',
          label: 'Repayment Bank Name',
          value: this.Obligation.repaymentBankName,
          required: false,
          order: 13
        }
      ),

      new NumericOnly(
        {
          key: 'repaymentBankAccountNo',
          label: 'Repayment Bank Account No.',
          value: this.Obligation.repaymentBankAccountNo,
          required: false,
          order: 14
        }
      ),


      new NumericOnly(
        {
          key: 'peakDPDLast6Month',
          label: 'Peak DPD Last 6 Month',
          value: this.Obligation.peakDPDLast6Month,
          required: true,
          order: 15
        }
      ),
      new NumericWithDecimal(
        {
          key: 'emiAmount',
          label: 'EMI Amount',
          value: this.Obligation.emiAmount,
          required: true,
          order: 16
        }
      ),
      new DropdownQuestion(
        {
          key: 'emiToObligate',
          label: 'EMI To Obligate',
          value: this.Obligation.emiToObligate,
          required: true,
          valueChange: (event: any, control: AbstractControl) => {
            debugger;
            let _grpControl = control.root as FormGroup;
            if (event == 'Y') {
              (_grpControl.controls?.['remarks'] as FormControl).clearValidators();
            }
            else {
              (_grpControl.controls?.['remarks'] as FormControl).addValidators(Validators.required);
            }
            (_grpControl.controls?.['remarks'] as FormControl).updateValueAndValidity();
          },
          options: [{ key: 'Y', value: 'Yes' }, { key: 'N', value: 'No' }, { key: 'NDC', value: 'No - Debt Consolidate' }],
          order: 17
        }
      )
      ,
      new TextArea(
        {
          key: 'remarks',
          label: 'Remarks',
          value: this.Obligation.remarks,
          required: false,
          Customevalidator: [new ContidionBasedValidate()],
          type: 'textarea',
          order: 18
        }
      )
    ] as formBase<any>[];

    return of(data.sort((a, b) => a.order - b.order));
  }
  getFinacierNameByNo(applicationNo: string): string {
    return this.FinacierList.find(x => x.key == applicationNo)?.value ?? '';
  }
  GetAll(lanNo: any): Observable<IresponseModel<IObligationModel[]>> {
    let data = {
      'lanNo': lanNo,
      'id': "0"
    };
    return this.http.httpPost<IresponseModel<IObligationModel[]>>(data, `LAP_GetAllObligation`)
  }
  Get(lanNo: any) {
    let data = {
      'LanNo': lanNo,
      'Id': "0"
    };
    this.http.httpPost<IresponseModel<IObligationModel>>(data, `LAP_GetByIdObligation`).subscribe((res: IresponseModel<IObligationModel>) => {
    })
  }
  Insert() {
    this.Obligation.loanAccountNumber = this.sanctionService.LanInfo.lan;
    debugger;
    this.http.httpPost<IresponseModel<boolean>>(this.Obligation.toJSON(), `LAP_Obligation`).subscribe((res: IresponseModel<boolean>) => {
      if (res.errorCode == "00") {
        this.notify.showSuccess(res.errorDescription);
        this.Obligations.push(this.Obligation);
      }
      else {
        this.notify.showError(res.errorDescription);
      }
    })
  }
  Delete() {
    let data = {
      'lanNo': this.Obligation.obligationId,
      'id': "0"
    }
    this.http.httpPost<IresponseModel<boolean>>(data, `LAP_DeleteObligation`).subscribe((res: IresponseModel<boolean>) => {
      if (res.errorCode == "00") {
        this.notify.showSuccess(res.errorDescription);
        this.Obligations.push(this.Obligation);
      }
      else {
        this.notify.showError(res.errorDescription);
      }
    })
  }
}

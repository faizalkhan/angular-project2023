import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Observable, of } from 'rxjs';
import { AppDynamicDirective } from 'src/app/shared/directive/app-dynamic.directive';
import { common } from 'src/app/shared/models/common';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
import { IModalCommon, ModalCommon, ModalService } from 'src/app/shared/services/modal/modal.service';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { ObligationFormComponent } from '../obligation-form.component';
import { ObligationFormService } from '../obligation-form.service';
import { IObligationModel, ObligationModel } from '../obligation-model';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  private _List: IObligationModel[] = [];
  public get List(): IObligationModel[] {
    return this._List;
  }
  public set List(value: IObligationModel[]) {
    this._List = value;
    this.SumLoanAmount = value.filter(x => x.emiToObligate.toLowerCase() == 'y').map(x => { return Number(x.loanAmount); }).reduce((a, b) => a + b, 0);
    this.SumPOS = value.filter(x => x.emiToObligate.toLowerCase() == 'y').map(x => { return Number(x.pos); }).reduce((a, b) => a + b, 0);
    this.SumemiAmount = value.filter(x => x.emiToObligate.toLowerCase() == 'y').map(x => { return Number(x.emiAmount); }).reduce((a, b) => a + b, 0);
  }
  private _SumLoanAmount: Number = 0;
  public get SumLoanAmount(): Number {
    return this._SumLoanAmount;
  }
  public set SumLoanAmount(value: Number) {
    this._SumLoanAmount = value;
  }
  private _SumPOS: Number = 0;
  public get SumPOS(): Number {
    return this._SumPOS;
  }
  public set SumPOS(value: Number) {
    this._SumPOS = value;
  }
  private _SumemiAmount: Number = 0;
  public get SumemiAmount(): Number {
    return this._SumemiAmount;
  }
  public set SumemiAmount(value: Number) {
    this._SumemiAmount = value;
  }

  constructor(private OblicationService: ObligationFormService, private modal: ModalService, private sanction: SanctionService) {
  }
  @ViewChild('btnCompnentModal')
  btnModal!: ElementRef;
  @ViewChild('CloseCompnentModal') CloseCompnentModal!: ElementRef;
  @ViewChild(AppDynamicDirective, { static: true }) embeddedContainer!: AppDynamicDirective;
  ngOnInit(): void {
    this.getAll();
  }
  getFinacierName(no: string): string {
    return this.OblicationService.getFinacierNameByNo(no);
  }
  getEMItoObligate(name: string) {
    if (name.toLowerCase() == 'y')
      return "Yes";
    else if (name.toLowerCase() == 'n')
      return "No";
    else
      return "No - Debt Consolidate"
  }
  getAll() {
    this.OblicationService.GetAll(this.sanction.LanInfo.lan).subscribe((res: IresponseModel<IObligationModel[]>) => {
      this.List = res.data;
    });
  }
  Add() {

    let componentRef = undefined;
    let viewConst = this.embeddedContainer.viewContainerRef;
    viewConst.clear();

    this.OblicationService.Obligation = new ObligationModel();
    componentRef = viewConst.createComponent<ObligationFormComponent>(ObligationFormComponent);
    componentRef.instance.questions$ = this.OblicationService.getFormControl();
    componentRef.instance.modalRef = this.CloseCompnentModal;
    componentRef.instance.keyObject = { obligationId: 0 };
    this.displayStyle = "block";
    this.btnModal.nativeElement.click();

  }
  submit(event: FormGroup) {
    event.markAllAsTouched();
    if (event.valid) {
      this.OblicationService.Obligation = new ObligationModel(event.getRawValue())
      this.OblicationService.Insert();
      this.displayStyle = "none";
    }
  }
  removeAll() {
    let Action: Function = () => {
      this.OblicationService.Obligations.forEach((element: IObligationModel) => {
        this.OblicationService.Obligation = new ObligationModel(element);
        this.OblicationService.Delete();
      })
    }
    let modal = new ModalCommon({
      title: "Confirmation",
      message: `Are you sure you want to remove All?`,
      sAction: Action,
      sActionText: 'Confirm',
      sActionShow: true
    } as IModalCommon);
    this.modal.ShowModal(modal);
  }
  Delete(item: IObligationModel) {
    let Action: Function = () => {
      this.OblicationService.Delete()
    }
    this.OblicationService.Obligation = new ObligationModel(item);
    this.OblicationService.Obligation.loanAccountNumber = this.sanction.LanInfo.lan;
    this.OblicationService.Obligation.obligationId = 0;
    let modal = new ModalCommon({
      title: "Confirmation",
      message: `Are you sure you want to delete?`,
      sAction: Action,
      sActionText: 'Confirm',
      sActionShow: true
    } as IModalCommon);
    this.modal.ShowModal(modal);
  }
  Edit(item: IObligationModel) {
    let Action: Function = () => {
      let componentRef = undefined;
      let viewConst = this.embeddedContainer.viewContainerRef;
      viewConst.clear();
      componentRef = viewConst.createComponent<ObligationFormComponent>(ObligationFormComponent);
      componentRef.instance.questions$ = this.OblicationService.getFormControl();
      this.OblicationService.Obligation.loanAccountNumber = this.sanction.LanInfo.lan;
      componentRef.instance.modalRef = this.CloseCompnentModal;
      componentRef.instance.keyObject = { obligationId: item.obligationId };
      this.displayStyle = "block";
      this.btnModal.nativeElement.click();
    }
    this.OblicationService.Obligation = new ObligationModel(item);
    let modal = new ModalCommon({
      title: "Confirmation",
      message: `Are you sure you want to edit?`,
      sAction: Action,
      sActionText: 'Confirm',
      sActionShow: true
    } as IModalCommon);
    this.modal.ShowModal(modal);
  }
  displayStyle: string = "none";
  Close(event: any) {
    this.displayStyle = "none";
  }


}


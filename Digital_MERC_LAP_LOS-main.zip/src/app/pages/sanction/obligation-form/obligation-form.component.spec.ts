import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ObligationFormComponent } from './obligation-form.component';

describe('ObligationFormComponent', () => {
  let component: ObligationFormComponent;
  let fixture: ComponentFixture<ObligationFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ObligationFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ObligationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, ElementRef, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Observable } from 'rxjs';
import { formBase } from '../../layout/layout-form-group/form-group.model';
import { ObligationFormService } from './obligation-form.service';
import { ObligationModel } from './obligation-model';

@Component({
  selector: 'app-obligation-form',
  templateUrl: './obligation-form.component.html',
  styleUrls: ['./obligation-form.component.css']
})
export class ObligationFormComponent implements OnInit {

  questions$: Observable<formBase<any>[]>;
  modalRef!: ElementRef;
  keyObject: any | undefined;
  constructor(private service: ObligationFormService) {
    this.questions$ = service.getFormControl();
  }
  ngOnInit(): void {
  }

  cancel(event: FormGroup) {
    debugger;
  }
  submit(event: FormGroup) {
    event.markAllAsTouched();
    if (event.valid) {
      this.service.Obligation = new ObligationModel({ ...event.getRawValue(), ...this.keyObject ?? {} })
      this.service.Insert();
      this.modalRef.nativeElement.click();
    }
  }

}

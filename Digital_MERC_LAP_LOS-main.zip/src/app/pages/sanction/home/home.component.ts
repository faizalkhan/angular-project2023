import { Component } from '@angular/core';
import { NotificationService } from 'src/app/notification.service';
import { common } from 'src/app/shared/models/common';
import { ISanctionDashboardModel, SanctionDashboardModel } from 'src/app/shared/models/sanction/dashboard';
import { ISanctionApplication, SanctionApplication } from 'src/app/shared/models/sanction/sanction.model';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';

@Component({
    selector: "sanction-home",
    templateUrl: "./home.component.html",
    styleUrls: ["./home.component.css"]
})
export class SanctionHomeComponent {
    application: ISanctionApplication = new SanctionApplication();
    lanInfo: ISanctionDashboardModel = new SanctionDashboardModel();

    constructor(private _http: ConfigService,
        private _Info: SanctionService,
        private _notify: NotificationService,
        private _sanctionService: SanctionService
    ) { }
    ngOnInit() {
       
        this.GetBasicDetail();
        this._sanctionService.LoadSanctionApplicationDetail();
    }
    toBasicCaseDetails() {
        this.lanInfo = this._Info.LanInfo;
        return {
            "LeadID": this._Info.LanInfo.leadId,
            "FLO_PsId": this._Info.userInfo.userId,
            "CreatedON": this.lanInfo.dateSourced
        }
    }
    GetBasicDetail() {
        this._http.httpPost<SanctionApplication>(this.toBasicCaseDetails(), "GetLAP_LOS_BasicCaseDetails").subscribe((res: SanctionApplication) => {
            if (res.errorcode == "00") {
                this._notify.showSuccess(res.errorDescription, "Home")
                this.application = new SanctionApplication(res);
                this.application.applicantDetailsData.sort((a, b) => common.sort(a,b,'type_of_Applicant') ).map(x => {
                    x.form60_Ref = this._sanctionService.getApplicationDoc(x.applicationNo, 'FORM60')?.dmS_UUID;
                    x.address_Ref = this._sanctionService.getApplicationDoc(x.applicationNo, 'ADDRESS_PROOF')?.dmS_UUID;
                    x.Ka1_Front_Ref = this._sanctionService.getApplicationDoc(x.applicationNo, 'KA1_FRONT')?.dmS_UUID;
                    x.Ka1_Back_Ref = this._sanctionService.getApplicationDoc(x.applicationNo, 'KA1_BACK')?.dmS_UUID;
                    x.PAN_Ref = this._sanctionService.getApplicationDoc(x.applicationNo, 'PAN')?.dmS_UUID;
                    return x;
                })
                this.application.applicationDetails.forEach(x => x.loanAccountNumber = this.lanInfo.lan);
            }
        })
    }


}


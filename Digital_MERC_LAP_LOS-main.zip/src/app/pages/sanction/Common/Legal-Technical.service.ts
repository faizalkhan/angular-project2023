import { Injectable } from '@angular/core';
@Injectable()
export class LegalTechnicalService {
 
    // getDocumentType(){
    //     return [
    //         { displayName: 'Select', selected: true, value: '' },
    //         { displayName: 'Title Document N', selected: false, value: 'Title_Doc_N' },
    //         { displayName: 'Title Document N-1', selected: false, value: 'Title_Doc_N_1' },
    //         { displayName: 'Title Document N-2', selected: false, value: 'Title_Doc_N_2' },
    //         { displayName: 'Title Document N-3', selected: false, value: 'Title_Doc_N_3' }, 
    //         { displayName: 'Revenue Record 1', selected: false, value: 'Revenue_Record_1' },
    //         { displayName: 'Revenue Record 2', selected: false, value: 'Revenue_Record_2' },
    //         { displayName: 'Revenue Record 3', selected: false, value: 'Revenue_Record_3' },
    //         { displayName: 'EC 1', selected: false, value: 'EC_1' },
    //         { displayName: 'EC 2', selected: false, value: 'EC_2' },
    //         { displayName: 'EC 3', selected: false, value: 'EC_3' },
    //         { displayName: 'Property Tax receipt', selected: false, value: 'Property_Tax_receipt' },
    //         { displayName: 'EB bill', selected: false, value: 'EB_bill' },
    //         { displayName: 'NOC', selected: false, value: 'NOC' },
    //         { displayName: 'NA Certificate', selected: false, value: 'NA_Certificate' },
    //         { displayName: 'Others', selected: false, value: 'Others' },
    //         { displayName: 'Others 1', selected: false, value: 'Others_1' },
    //         { displayName: 'Others 2', selected: false, value: 'Others_2' },
    //        ];  
    // }

    getDocumentType(){
        return [
            { displayName: 'Select', selected: true, value: '' },
            { displayName: 'Title Document 1', selected: false, value: 'Title_Doc_1' },
            { displayName: 'Title Document 2', selected: false, value: 'Title_Doc_2' },
            { displayName: 'Title Document 3', selected: false, value: 'Title_Doc_3' },  
            { displayName: 'Revenue Record 1', selected: false, value: 'Revenue_Record_1' },
            { displayName: 'Revenue Record 2', selected: false, value: 'Revenue_Record_2' },
            { displayName: 'Revenue Record 3', selected: false, value: 'Revenue_Record_3' },
            { displayName: 'EC 1', selected: false, value: 'EC_1' },
            { displayName: 'EC 2', selected: false, value: 'EC_2' },
            { displayName: 'EC 3', selected: false, value: 'EC_3' },
            { displayName: 'Property Tax receipt', selected: false, value: 'Property_Tax_receipt' },
            { displayName: 'EB bill', selected: false, value: 'EB_bill' },
            { displayName: 'NOC', selected: false, value: 'NOC' },
            { displayName: 'NA Certificate', selected: false, value: 'NA_Certificate' },
            { displayName: 'Others', selected: false, value: 'Others' },
            { displayName: 'Others 1', selected: false, value: 'Others_1' },
            { displayName: 'Others 2', selected: false, value: 'Others_2' },
           ];  
    }

    getChainFlow(){
      return  [
            { displayName: 'Select', selected: true, value: '' },
            { displayName: '5 Years', selected: true, value: '5' }, 
            { displayName: '5-13 Years', selected: true, value: '13' }, 
            { displayName: '>13 Years', selected: true, value: '14' }, 
        ]
    }
}
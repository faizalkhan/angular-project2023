import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LegalVendorCommonComponent } from './legal-vendor-common.component';

describe('LegalVendorCommonComponent', () => {
  let component: LegalVendorCommonComponent;
  let fixture: ComponentFixture<LegalVendorCommonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LegalVendorCommonComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LegalVendorCommonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { forkJoin } from 'rxjs';
import { InfoServices } from 'src/app/Injectable/info.services';
import { NotificationService } from 'src/app/notification.service';
import { FileUpload, IfileUpload, UploadViewDownloadService } from 'src/app/pages/layout/button/upload-view-download/upload-view-download.service';
import { TailoringShopService } from 'src/app/pages/layout/functional/self-employed/tailoring-shop/tailoring-shop.service';
import { IDropdown } from 'src/app/shared/models/common/control.model';
import { ImageUploadModel, ImageUploadWithoutImageDataModel, ISubmitLegalAPI } from 'src/app/shared/models/common/imageUpload.model';
import { DocumentInfo, IDownloadDocument, ILegalCasedModel } from 'src/app/shared/models/sanction/Legal/legalDashboard';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { LegalTechnicalService } from '../Legal-Technical.service';

@Component({
  selector: 'app-legal-vendor-common',
  templateUrl: './legal-vendor-common.component.html',
  styleUrls: ['./legal-vendor-common.component.css']

})
export class LegalVendorCommonComponent implements OnInit {

  caption:any;
  legalData!: ILegalCasedModel; 
  legal_Remark:any;
  Title_Search_legal_Remark:any;
  caseStatus:any;
  referCases:boolean=false;
  vendarUpload : DocumentInfo[] = [];
  isEdit:boolean=true;
  tittleReport_UUID:string='';
  legalReport_UUID:string='';
  TitleSearch_Report:string ="TitleSearch-Report";
  Legal_Report:string ="Legal-Report";
  DocumentType: IDropdown[] = [];   
  
  //statuses:string[]=[];
  statuses:string[] = ['Positive', 'Referred', 'Negative'];  
  constructor(private info: InfoServices,private http: ConfigService,private route:Router,
    private notify:NotificationService,private download: UploadViewDownloadService,private legalTechnicalService :LegalTechnicalService) { }

  ngOnInit(): void {
    this.DocumentType = this.legalTechnicalService.getDocumentType();  
    this.caption = this.info.getItem('Screen_Type');    
    this.getLegalCaseDetail();
    if(this.caption==="Refer Cases"){
      this.referCases=true;
    }
  }

  getLegalCaseDetail(){
    var data = this.info.getItem('LegalVendor_LanInfo');

    var param = JSON.parse(data);

    
    this.download.uploadLoad = new FileUpload({
        flO_Id: "",
        loanAccountNumber: param.lan,
        moduleName: "Legal-Vendor",
        applicationNo : param.lan,
        leadID:param.lan,
    } as IfileUpload);
    
    this.http.httpPost<ILegalCasedModel>(JSON.parse(data), 'LAP_GetLegalCaseDtl').subscribe((res: ILegalCasedModel) => {
      this.legalData = res;
      if(res.decision_Legal==="Positive" || res.decision_Legal==="Referred" || res.decision_Legal==="Negative"
         || res.caseStatus ==="Legal vendor queries"){
        this.isEdit=false;
      }

      if(res!==null){
        if(res.legalDocumentsInfo!==undefined && res.legalDocumentsInfo.length>=0){
          res.legalDocumentsInfo.map((item,index)=>{
              let selectedDocumentType;
            if(item.documentType!==null){
               selectedDocumentType = this.DocumentType.find(x=>x.value===item.documentType);
               if(selectedDocumentType){
               res.legalDocumentsInfo[index].documentTypeDesc=selectedDocumentType?.displayName;
               }
            }
          })
        }

        if(res.vendorDocumentsInfo!==undefined && res.vendorDocumentsInfo.length>=0){
          res.vendorDocumentsInfo.map((item,index)=>{
              let selectedDocumentType;
            if(item.documentType!==null){
               selectedDocumentType = this.DocumentType.find(x=>x.value===item.documentType);
               if(selectedDocumentType){
               res.vendorDocumentsInfo[index].documentTypeDesc=selectedDocumentType?.displayName;
               }
            }
          })
        }
      }

      if(res.vendorDocumentsInfo!=null && res.vendorDocumentsInfo.length>=0){
         var titleSearchReport = res.vendorDocumentsInfo.filter(x=>x.documentType==="Title Search Report");
         if(titleSearchReport!==undefined && titleSearchReport.length>=0){
            this.Title_Search_legal_Remark = titleSearchReport[0].remark;
            this.tittleReport_UUID= titleSearchReport[0].uuid;
         }

          var legalReport = res.vendorDocumentsInfo.filter(x=>x.documentType==="Legal Report")
          if(legalReport!==undefined && legalReport.length>=0){
            this.legal_Remark = legalReport[0].remark;
            this.legalReport_UUID= legalReport[0].uuid;
         }
      }
    })
  }

 
 
GetTitleLegalRemark(){

  this.legalData.legalDocumentsInfo.map((x,index)=>{
    if(x.documentType ==="Title Search Report" && this.Title_Search_legal_Remark!=='')
    {
      this.legalData.legalDocumentsInfo[index].remark = this.Title_Search_legal_Remark;
    }

    if(x.documentType ==="Legal Report" && this.legal_Remark!=='')
    {
      this.legalData.legalDocumentsInfo[index].remark = this.legal_Remark;
    }
  })   
}

isValidateInfo(){

  if(this.Title_Search_legal_Remark===undefined || this.Title_Search_legal_Remark===null || this.Title_Search_legal_Remark===""){
    this.notify.showWarning("Please specify the Legal/Title Search Report remark","Legal Vendor");
    return false;
  }

  if(this.legal_Remark===undefined || this.legal_Remark===null || this.legal_Remark===""){
    this.notify.showWarning("Please specify the Vetting Report remark","Legal Vendor");
    return false;
  }

  if(this.legalData.bcmLegalCaseSummary===undefined || this.legalData.bcmLegalCaseSummary===null || this.legalData.bcmLegalCaseSummary===""){
    this.notify.showWarning("Please specify the final comment","Legal Vendor");
    return false;
  }

  

  if(this.vendarUpload.length<=0){
    this.notify.showWarning("Please Upload Legal/ Title Search Report","Legal Vendor");
    return false;
  }

  if(this.vendarUpload.length>=0){
    var titleSearchReport = this.vendarUpload.find(x=>x.documentType==="Title Search Report");
    if(titleSearchReport===undefined){ 
    this.notify.showWarning("Please Upload the Title Search Report","Legal Vendor");
    return false;
    }

    var legalReport = this.vendarUpload.find(x=>x.documentType==="Legal Report");
    if(legalReport===undefined){ 
    this.notify.showWarning("Please Upload the Legal Report","Legal Vendor");
    return false;
    }
  }
  
  if(this.legalData.decision_Legal===undefined || this.legalData.decision_Legal===null || this.legalData.decision_Legal===""){
    this.notify.showWarning("Please Select Either Positive/Negative/Referred","Legal Vendor");
    return false;
  }

  if(this.legalData.decision_Legal === "Positive" || this.legalData.decision_Legal === "Negative"
  || this.legalData.decision_Legal === "Referred"){

    if(this.legalData.isAgreed===false || this.legalData.isAgreed===null ||  this.legalData.isAgreed===undefined){
      this.notify.showWarning("Please Select the I Agree Option","Legal Vendor");
      return false;
    } 
  }

  return true;
}

isValidateSendBackInfo(){
  
  // if(this.legalData.sendBackNotes==="" || this.legalData.sendBackNotes===null){
  //   this.notify.showWarning("Please specify the send back notes");
  //   return false
  // }

  if(this.legalData.legalDocumentsInfo.length===0){
    return true;
  }
 
   var legalRemarkCheck = this.legalData.legalDocumentsInfo.filter(x=>x.legalRemark===null || x.legalRemark.trim()==="");
    if(legalRemarkCheck.length>0 ){
      this.notify.showWarning("Please specify the remarks.");
      return false
    }
    return true;
}

sendBack(){
  if(!this.isValidateSendBackInfo()){
    return
  }
   
  if(this.legalData.caseStatus === "Inprogress with vendor"){
    this.legalData.caseStatus="Legal vendor queries";
  }

  this.legalData.decision_Legal="SentBack";

  this.http.httpPost<ISubmitLegalAPI>((this.legalData), "LAP_SubmitLegalCaseDtl")
  .subscribe(res => {
    if(res.errorcode==="E408"){
      this.notify.showError("Something went wrong","Legal Vendor"); 
    }else{ 
     this.isEdit=false;
     this.notify.showSuccess("Case Send Back Successfully.","Legal Vendor"); 
    }

  });
}

Submit1(){

  if( this.legalData.decision_Legal==="SentBack" || this.legalData.decision_Legal==="New"){
    this.legalData.decision_Legal="";
  }

  
 

  var legalDocuments =[];
  var vendorDocument =[];


  this.GetTitleLegalRemark();


  if(this.tittleReport_UUID!=="")
  {
    let doc = new DocumentInfo();
    doc.documentType="Title Search Report";
    doc.doc_Source="Legal";
    doc.doc_SourceScreen='Vendor';  
    doc.uuid=this.tittleReport_UUID;
    doc.remark=this.Title_Search_legal_Remark===null ? "" : this.Title_Search_legal_Remark;
    this.vendarUpload.push(doc); 
  }

  if(this.legalReport_UUID!=="")
  {
    let doc = new DocumentInfo();
    doc.documentType="Legal Report";
    doc.doc_Source="Legal";
    doc.doc_SourceScreen='Vendor'; 
    doc.uuid=this.legalReport_UUID;
    doc.remark=this.legal_Remark===null ? "" : this.legal_Remark;;
    doc.imageData="";
    //this.legalData.legalDocumentsInfo.push(doc); 
    this.vendarUpload.push(doc);
  } 

  if(!this.isValidateInfo()){
    return
  }

  
  
  // legalDocuments = this.legalData.legalDocumentsInfo.filter(x=>x.imageData!=="" && x.imageData !==null);
  // vendorDocument = this.legalData.vendorDocumentsInfo.filter(x=>x.imageData!=="" && x.imageData !==null);
  // legalDocuments.push(...vendorDocument);

  if(this.vendarUpload.length>=0){
    legalDocuments.push(...this.vendarUpload);
    this.legalData.legalDocumentsInfo.push(...this.vendarUpload);
  }

  // const requestsArray = legalDocuments.map((x, idx) => {

  //   let dataImageUpload = new ImageUploadModel();
  //   let dataWithoutImageData = new ImageUploadWithoutImageDataModel();

  //   dataImageUpload.ApplicationNo= this.legalData.lan;
  //   dataImageUpload.FLO_Id="23";
  //   dataImageUpload.GL_Latitude="2";
  //   dataImageUpload.GL_Longitude="2";
  //   dataImageUpload.ImageType= x.documentType;
  //   dataImageUpload.ImageData= x.imageData;
  //   dataImageUpload.LeadID="2"; 
  //   dataImageUpload.Type="Legal";
  //   dataImageUpload.LoanAccountNumber=this.legalData.lan;
  //   dataImageUpload.DocTypeDescription='';
  //   dataImageUpload.ImageMIMEType='';
  //   dataImageUpload.Extension='';
  //   dataImageUpload.ModuleName='';
  //   dataImageUpload.Name='';
  //   dataImageUpload.BankDetailID='';

  //   dataWithoutImageData.ApplicationNo= this.legalData.lan;
  //   dataWithoutImageData.FLO_Id="23";
  //   dataWithoutImageData.GL_Latitude="2";
  //   dataWithoutImageData.GL_Longitude="2";
  //   dataWithoutImageData.ImageType= x.documentType;
  //   //dataWithoutImageData.ImageData= item.imageData;
  //   dataWithoutImageData.LeadID="2";
  //   dataWithoutImageData.Type="Legal";
  //   dataWithoutImageData.LoanAccountNumber=this.legalData.lan;
  //   dataWithoutImageData.DocTypeDescription='';
  //   dataWithoutImageData.ImageMIMEType='';
  //   dataWithoutImageData.Extension='';
  //   dataWithoutImageData.ModuleName='';
  //   dataWithoutImageData.Name='';
  //   dataWithoutImageData.BankDetailID='';
    

  //   return this.http.httpPostWithouImageData<any>(dataImageUpload,'LAP_SaveImageUPL',dataWithoutImageData);

  // });

  //   this.legalData.legalDocumentsInfo.map((x, idx) => {
  //     if( x.imageData!=undefined || x.imageData!==''){
  //     x.imageData="";
  //     }
  // });

  // this.legalData.vendorDocumentsInfo.map((x, idx) => {
  //   if( x.imageData!=undefined || x.imageData!==''){
  //     x.imageData="";
  //     }
  // });

 
  // const anotherRequest = this.http.httpPost<ISubmitLegalAPI>((this.legalData), "LAP_SubmitLegalCaseDtl");
      
  // forkJoin([...requestsArray, anotherRequest]).subscribe(results => {
  //     if(this.legalData.decision_Legal==="Approve" || this.legalData.decision_Legal==="Refer" || this.legalData.decision_Legal==="Reject" ){
  //       this.isEdit=false;
  //     }
  //     this.notify.showSuccess("Saved successfully","Legal Vendor");
  //     this.route.navigateByUrl("/legalVendorcheck");
  // });

  this.http.httpPost(this.legalData, 'LAP_SubmitLegalCaseDtl').subscribe((res: any) => {
     
    if(res.errorcode=== "E408"){
      this.notify.showError("Something went wrong","Legal Vendor");

    }else{ 

      if(this.legalData.decision_Legal==="Positive" || this.legalData.decision_Legal==="Referred" 
        || this.legalData.decision_Legal==="Negative" ){
        this.isEdit=false;
        this.legalData.legalDocumentsInfo.map((x,index)=>{
          if(x.documentType === "Title Search Report"){
              this.legalData.legalDocumentsInfo.splice(index,1);
          } 
        }); 
  
        this.legalData.legalDocumentsInfo.map((x,index)=>{
          if(x.documentType === "Legal Report"){
            this.legalData.legalDocumentsInfo.splice(index,1);
          } 
        }); 
      }
      this.notify.showSuccess("Saved successfully","Legal Vendor");

    

      this.route.navigateByUrl("/legalVendorcheck");
    }
  })

}


Download(uuid:any){

  var data ={
    UUID :uuid
  }

  this.http.httpPost<IDownloadDocument>((data), 'LAP_DownloadDocument').subscribe((res: IDownloadDocument) => {
    
      if(res.imageData!=""){
        const downloadLink = document.createElement('a');
        const fileName = uuid + ".jpeg";
    
        downloadLink.href =  res.imageData;
        downloadLink.download = fileName;
        downloadLink.click();
      }
     
  })
}

radiChange(type:any){
   if(type==="Positive"){
    this.legalData.decision_Legal="Positive";
   }
   if(type==="Referred"){
    this.legalData.decision_Legal="Referred";
   }
   if(type==="Negative"){
    this.legalData.decision_Legal="Negative";
   }
}

checkboxChange(event:any){

  this.legalData.isAgreed = event.currentTarget.checked;

}
 


}

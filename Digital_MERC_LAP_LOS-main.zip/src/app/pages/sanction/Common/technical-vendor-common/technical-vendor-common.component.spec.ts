import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TechnicalVendorCommonComponent } from './technical-vendor-common.component';

describe('TechnicalVendorCommonComponent', () => {
  let component: TechnicalVendorCommonComponent;
  let fixture: ComponentFixture<TechnicalVendorCommonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TechnicalVendorCommonComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TechnicalVendorCommonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

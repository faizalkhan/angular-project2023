import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { forkJoin } from 'rxjs';
import { InfoServices } from 'src/app/Injectable/info.services';
import { NotificationService } from 'src/app/notification.service';
import { file, FileUpload, IfileUpload, UploadViewDownloadService } from 'src/app/pages/layout/button/upload-view-download/upload-view-download.service';
import { IDropdown } from 'src/app/shared/models/common/control.model';
import { ImageUploadModel, ImageUploadWithoutImageDataModel, ISubmitTechnicalAPI } from 'src/app/shared/models/common/imageUpload.model';
import { DocumentInfo, IDownloadDocument, IVendorCasedModel } from 'src/app/shared/models/sanction/Legal/legalDashboard';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { LegalTechnicalService } from '../Legal-Technical.service';

@Component({
  selector: 'app-technical-vendor-common',
  templateUrl: './technical-vendor-common.component.html',
  styleUrls: ['./technical-vendor-common.component.css']
})
export class TechnicalVendorCommonComponent implements OnInit {

  caption:any;
  legalData!: IVendorCasedModel; 
  legal_Remark:any;
  Title_Search_legal_Remark:any;
  caseStatus:any;
  referCases:boolean=false;
  vendarUpload : DocumentInfo[] = [];
  imageUploadModelList:ImageUploadModel[]=[];
  imageUploadModel!:ImageUploadModel;
  isEdit:boolean=true;
  //statuses:string[]=[];
  statuses:string[] = ['Positive', 'Referred', 'Negative'];  
  tittleReport_UUID:string='';
  technicalReport_UUID:string='';
  TitleSearch_Report:string ="TitleSearch-Report";
  Legal_Report:string ="Legal-Report";
  DocumentType:IDropdown[]= [];
  constructor(private info: InfoServices,private http: ConfigService,private route:Router,
    private notify:NotificationService,private download: UploadViewDownloadService,private legalTechnicalService:LegalTechnicalService) { }

  ngOnInit(): void {
    this.caption = this.info.getItem('Screen_Type'); 
    
    this.DocumentType = this.legalTechnicalService.getDocumentType()
    this.getTechnicalCaseDetail();
    if(this.caption==="Refer Cases"){
      this.referCases=true;
    }
  }

  getTechnicalCaseDetail(){
    var data = this.info.getItem('TechnicalVendor_LanInfo');
    this.http.httpPost<IVendorCasedModel>(JSON.parse(data), 'LAP_GetTechnicalCaseDtl').subscribe((res: IVendorCasedModel) => {
      this.legalData = res;
      if(res.decision_Legal==="Positive" || res.decision_Legal==="Referred" || res.decision_Legal==="Negative"
         || res.caseStatus ==="Technical vendor queries"){
        this.isEdit=false;
      }
      if(res!==null){
        if(res.legalDocumentsInfo!==undefined && res.legalDocumentsInfo.length>=0){
          res.legalDocumentsInfo.map((item,index)=>{
              let selectedDocumentType;
            if(item.documentType!==null){
               selectedDocumentType = this.DocumentType.find(x=>x.value===item.documentType);
               if(selectedDocumentType){
               res.legalDocumentsInfo[index].documentTypeDesc=selectedDocumentType?.displayName;
               }
            }
          })
        }

        if(res.vendorDocumentsInfo!==undefined && res.vendorDocumentsInfo.length>=0){
          res.vendorDocumentsInfo.map((item,index)=>{
              let selectedDocumentType;
            if(item.documentType!==null){
               selectedDocumentType = this.DocumentType.find(x=>x.value===item.documentType);
               if(selectedDocumentType){
               res.vendorDocumentsInfo[index].documentTypeDesc=selectedDocumentType?.displayName;
               }
            }
          })
        }
      }

      if(res.vendorDocumentsInfo!=null && res.vendorDocumentsInfo.length>=0){
        //  var titleSearchReport = res.vendorDocumentsInfo.filter(x=>x.documentType==="Title Search Report");
        //  if(titleSearchReport!==undefined && titleSearchReport.length>=0){
        //     this.Title_Search_legal_Remark = titleSearchReport[0].remark;
        //  }

          var legalReport = res.vendorDocumentsInfo.filter(x=>x.documentType==="Technical Report")
          if(legalReport!==undefined && legalReport.length>=0){
            this.legal_Remark = legalReport[0].remark;
            this.technicalReport_UUID= legalReport[0].uuid;
         }
      }
    })

    var param = JSON.parse(data);
    this.download.uploadLoad = new FileUpload({
      flO_Id: "",
      loanAccountNumber: param.lan,
      moduleName: "Technical-Vendor",
      applicationNo : param.lan,
      leadID:param.lan,
  } as IfileUpload);
  }

  handleFileInput(fileInput: any,element:any) 
    {
      if (fileInput.target.files && fileInput.target.files[0]) {

        let doc: DocumentInfo = new DocumentInfo();
      // Size Filter Bytes
      const max_size = 20971520;
      const allowed_types = ['image/png', 'image/jpeg'];
      const max_height = 15200;
      const max_width = 25600;

      if (fileInput.target.files[0].size > max_size) {
          // this.imageError =
          //     'Maximum size allowed is ' + max_size / 1000 + 'Mb';

          return false;
      }
 

      // if (!_.includes(allowed_types, fileInput.target.files[0].type)) {
      //     this.imageError = 'Only Images are allowed ( JPG | PNG )';
      //     return false;
      // }
      const reader = new FileReader();
      reader.onload = (e: any) => {
          const image = new Image();
          image.src = e.target.result;
                    
          // image.onload = rs => {
          //     const img_height = 100;
          //     const img_width = 120;



          //     if (img_height > max_height && img_width > max_width) {
          //         this.imageError =
          //             'Maximum dimentions allowed ' +
          //             max_height +
          //             '*' +
          //             max_width +
          //             'px';
          //         return false;
          //     } else {
                  const imgBase64Path = e.target.result;
                  // this.cardImageBase64 = imgBase64Path;
                  // this.isImageSaved = true;
                  
                  // let imageUploadModelInfo = new ImageUploadModel;
                  //  imageUploadModelInfo.Type ="legal";                 
                  // var data = this.info.getItem('Legal_LanInfo');
                  // imageUploadModelInfo.ApplicationNo = data.lan;
                  // imageUploadModelInfo.ImageType = "NOC";
                  // imageUploadModelInfo.ImageData =imgBase64Path; 
                  // this.imageUploadModelList.push(this.imageUploadModel);

                if(this.caption==="New cases")
                {
                  if(this.legalData.legalDocumentsInfo.length!==-1){
                    this.legalData.legalDocumentsInfo.forEach((item,index)=>{
                       if(item.documentType===element){
                          doc.imageData=imgBase64Path.replace((imgBase64Path.substring(0,imgBase64Path.indexOf(",")+1)),'');
                          doc.doc_Source='Technical';
                          doc.doc_SourceScreen='Vendor';        
                          this.vendarUpload.push(doc);
                          // this.legalData.legalDocumentsInfo[index].imageData=imgBase64Path.replace((imgBase64Path.substring(0,imgBase64Path.indexOf(",")+1)),'');
                          // this.legalData.legalDocumentsInfo[index].doc_Source='Technical';
                          // this.legalData.legalDocumentsInfo[index].doc_SourceScreen='Vendor';                          
                       }
                    });
                  }

                }

                
                if(this.caption==="Negative")
                {
                  if(this.legalData.vendorDocumentsInfo.length!==-1){
                    this.legalData.vendorDocumentsInfo.forEach((item,index)=>{
                       if(item.documentType===element){
                        doc.imageData=imgBase64Path.replace((imgBase64Path.substring(0,imgBase64Path.indexOf(",")+1)),'');
                        doc.doc_Source='Technical';   
                        doc.doc_SourceScreen='Vendor';    
                        this.vendarUpload.push(doc);        
                          // this.legalData.vendorDocumentsInfo[index].imageData=imgBase64Path.replace((imgBase64Path.substring(0,imgBase64Path.indexOf(",")+1)),'');
                          // this.legalData.vendorDocumentsInfo[index].doc_Source='Technical';   
                          // this.legalData.vendorDocumentsInfo[index].doc_SourceScreen='Vendor';                           
                       }
                    });
                  }
                }


                
                  return true;
                  // this.previewImagePath = imgBase64Path;
          //     }
          // };
      };

      reader.readAsDataURL(fileInput.target.files[0]);
      return true;
    }
    return false;


  }

  handleFileInput1(fileInput: any,element:any) 
  {
    if (fileInput.target.files && fileInput.target.files[0]) {
    // Size Filter Bytes
    const max_size = 20971520;
    const allowed_types = ['image/png', 'image/jpeg'];
    const max_height = 15200;
    const max_width = 25600;
    let file =fileInput.target.files[0] as File;

    if (fileInput.target.files[0].size > max_size) {
        // this.imageError =
        //     'Maximum size allowed is ' + max_size / 1000 + 'Mb';

        return false;
    }


    // if (!_.includes(allowed_types, fileInput.target.files[0].type)) {
    //     this.imageError = 'Only Images are allowed ( JPG | PNG )';
    //     return false;
    // }
    const reader = new FileReader();
    reader.onload = (e: any) => {
        const image = new Image();
        image.src = e.target.result;
                  
        // image.onload = rs => {
        //     const img_height = 100;
        //     const img_width = 120;



        //     if (img_height > max_height && img_width > max_width) {
        //         this.imageError =
        //             'Maximum dimentions allowed ' +
        //             max_height +
        //             '*' +
        //             max_width +
        //             'px';
        //         return false;
        //     } else {
                const imgBase64Path = e.target.result;
                // this.cardImageBase64 = imgBase64Path;
                // this.isImageSaved = true;
                
                // let imageUploadModelInfo = new ImageUploadModel;
                //  imageUploadModelInfo.Type ="legal";                 
                // var data = this.info.getItem('Legal_LanInfo');
                // imageUploadModelInfo.ApplicationNo = data.lan;
                // imageUploadModelInfo.ImageType = "NOC";
                // imageUploadModelInfo.ImageData =imgBase64Path; 
                // this.imageUploadModelList.push(this.imageUploadModel);

              // if(element==="TitleSearchReport")
              // {
              //   let doc = new DocumentInfo();
              //   doc.documentType="Title Search Report";
              //   doc.doc_Source="Technical";
              //   doc.doc_SourceScreen='Vendor'; 
              //   doc.imageData=imgBase64Path.replace((imgBase64Path.substring(0,imgBase64Path.indexOf(",")+1)),'');
                
              //   doc.remark=this.Title_Search_legal_Remark;
              //   this.vendarUpload.push(doc);

              //   let imageUploadModel = new ImageUploadModel();
              //   let extension:any ='';
              //   extension =file.name.split('.').pop() === undefined ? "" : file.name.split('.').pop()?.toString();

              //   imageUploadModel.ImageMIMEType = file.type;
              //   imageUploadModel.Name = file.name;                        
              //   imageUploadModel.ImageType = "Title Search Report";
              //   imageUploadModel.Extension = extension;    
                
              //   this.imageUploadModelList.push(imageUploadModel);
              //   //this.legalData.legalDocumentsInfo.push(doc); 
              // }

              if(element==="legalReport")
              {
                let doc = new DocumentInfo();
                doc.documentType="Technical Report";
                doc.doc_Source="Technical";
                doc.doc_SourceScreen='Vendor'; 
                
                doc.remark=this.legal_Remark;
                doc.imageData=imgBase64Path.replace((imgBase64Path.substring(0,imgBase64Path.indexOf(",")+1)),'');
                this.vendarUpload.push(doc);

                let imageUploadModel = new ImageUploadModel();
                let extension:any ='';
                extension =file.name.split('.').pop() === undefined ? "" : file.name.split('.').pop()?.toString();

                imageUploadModel.ImageMIMEType = file.type;
                imageUploadModel.Name = file.name;                        
                imageUploadModel.ImageType = "Technical Report";
                imageUploadModel.Extension = extension;    
                
                this.imageUploadModelList.push(imageUploadModel);
                //this.legalData.legalDocumentsInfo.push(doc); 
              } 
              
                return true;
                // this.previewImagePath = imgBase64Path;
        //     }
        // };
    };

    reader.readAsDataURL(fileInput.target.files[0]);
    return true;
  }
  return false;


}

GetTitleLegalRemark(){

  this.legalData.legalDocumentsInfo.map((x,index)=>{
    // if(x.documentType ==="Title Search Report" && this.Title_Search_legal_Remark!=='')
    // {
    //   this.legalData.legalDocumentsInfo[index].remark = this.Title_Search_legal_Remark;
    // }

    if(x.documentType ==="Technical Report" && this.legal_Remark!=='')
    {
      this.legalData.legalDocumentsInfo[index].remark = this.legal_Remark;
    }
  })   
}

isValidateInfo(){

  // if(this.Title_Search_legal_Remark===undefined || this.Title_Search_legal_Remark===null || this.Title_Search_legal_Remark===""){
  //   this.notify.showWarning("Please specify the Legal/Title Search Report remark","Technical Vendor");
  //   return false;
  // }

  if(this.legal_Remark===undefined || this.legal_Remark===null || this.legal_Remark===""){
    this.notify.showWarning("Please Specify the Technical Report Remark","Technical Vendor");
    return false;
  }

  if(this.vendarUpload.length<=0){
    this.notify.showWarning("Please Upload the Technical Report","Technical Vendor");
    return false;
  }

  if(this.vendarUpload.length>=0){   
    var legalReport = this.vendarUpload.find(x=>x.documentType==="Technical Report");
    if(legalReport===undefined){ 
    this.notify.showWarning("Please Upload the Technical Report","Technical Vendor");
    return false;
    }
  }

  if(this.legalData.bcmLegalCaseSummary===undefined || this.legalData.bcmLegalCaseSummary===null || this.legalData.bcmLegalCaseSummary===""){
    this.notify.showWarning("Please Specify the Final Comment","Technical Vendor");
    return false;
  }
  

  if(this.legalData.decision_Legal===null || this.legalData.decision_Legal===""){
    this.notify.showWarning("Please Select Either Positive/Negative/Referred","Technical Vendor");
    return false;
  }
  if(this.legalData.decision_Legal === "Positive" || this.legalData.decision_Legal === "Negative"
  || this.legalData.decision_Legal === "Referred"){
    if(this.legalData.isAgreed===false || this.legalData.isAgreed===null || this.legalData.isAgreed===undefined){
      this.notify.showWarning("Please Select the I Agree Option","Technical Vendor");
    return false;
   }
  } 
   
  return true;
}

isValidateSendBackInfo(){


  // if(this.legalData.sendBackNotes==="" || this.legalData.sendBackNotes===null){
  //   this.notify.showWarning("Please specify the send back notes");
  //   return false
  // }

   var legalRemarkCheck = this.legalData.legalDocumentsInfo.filter(x=>x.legalRemark!=="");
    if(legalRemarkCheck===undefined || legalRemarkCheck.length===0 ){
      this.notify.showWarning("Please specify the remarks");
      return false
    }
    return true;
}

sendBack(){
  if(!this.isValidateSendBackInfo()){
    return
  }
   
  if(this.legalData.caseStatus === "Inprogress with vendor"){
    this.legalData.caseStatus="Technical vendor queries";
  }

  this.legalData.decision_Legal="SentBack";

  this.http.httpPost<ISubmitTechnicalAPI>((this.legalData), "LAP_SubmitTechnicalCaseDtl")
  .subscribe(res => {
     this.isEdit=false;
     this.notify.showSuccess("Case Send Back Successfully.","Technical Vendor"); 

  });
}


Submit1(){

  if( this.legalData.decision_Legal==="SentBack" || this.legalData.decision_Legal==="New"){
    this.legalData.decision_Legal="";
  }
  
  
  var legalDocuments =[];
  var vendorDocument =[];

  this.GetTitleLegalRemark();

  // if(this.tittleReport_UUID!=="")
  // {
  //   let doc = new DocumentInfo();
  //   doc.documentType="Title Search Report";
  //   doc.doc_Source="Technical";
  //   doc.doc_SourceScreen='Vendor';  
  //   doc.uuid=this.tittleReport_UUID;
  //   doc.remark=this.Title_Search_legal_Remark;
  //   this.vendarUpload.push(doc); 
  // }

  if(this.technicalReport_UUID!=="")
  {
    let doc = new DocumentInfo();
    doc.documentType="Technical Report";
    doc.doc_Source="Technical";
    doc.doc_SourceScreen='Vendor'; 
    doc.uuid=this.technicalReport_UUID;
    doc.remark=this.legal_Remark;
    doc.imageData="";
    //this.legalData.legalDocumentsInfo.push(doc); 
    this.vendarUpload.push(doc);
  } 

  if(!this.isValidateInfo()){
    return;
  }
  
  // legalDocuments = this.legalData.legalDocumentsInfo.filter(x=>x.imageData!=="" && x.imageData !==null);
  // vendorDocument = this.legalData.vendorDocumentsInfo.filter(x=>x.imageData!=="" && x.imageData !==null);
  // legalDocuments.push(...vendorDocument);

  if(this.vendarUpload.length>=0){
    legalDocuments.push(...this.vendarUpload);
    this.legalData.legalDocumentsInfo.push(...this.vendarUpload);
  }

  // const requestsArray = legalDocuments.map((x, idx) => {
  //   let dataImageUpload = new ImageUploadModel();
  //   let dataWithoutImageData = new ImageUploadWithoutImageDataModel();   

  //   let docImageDetail: ImageUploadModel = new ImageUploadModel()

  //   if(this.imageUploadModelList.length>=-1){
  //      docImageDetail = this.imageUploadModelList.find(image=>image.ImageType===x.documentType) as ImageUploadModel;
  //   }

  //   dataImageUpload.ApplicationNo= this.legalData.lan;
  //   dataImageUpload.FLO_Id="23";
  //   dataImageUpload.GL_Latitude="2";
  //   dataImageUpload.GL_Longitude="2";
  //   dataImageUpload.ImageType= x.documentType;
  //   dataImageUpload.ImageData= x.imageData;
  //   dataImageUpload.LeadID="2";
  //   dataImageUpload.Type="Technical";
  //   dataImageUpload.LoanAccountNumber=this.legalData.lan;
  //   dataImageUpload.DocTypeDescription='';
  //   dataImageUpload.ImageMIMEType=docImageDetail.ImageMIMEType;
  //   dataImageUpload.Extension=docImageDetail.Extension;
  //   dataImageUpload.ModuleName='TechnicalVendor';
  //   dataImageUpload.Name=docImageDetail.Name;
  //   dataImageUpload.BankDetailID='';

  //   dataWithoutImageData.ApplicationNo= this.legalData.lan;
  //   dataWithoutImageData.FLO_Id="23";
  //   dataWithoutImageData.GL_Latitude="2";
  //   dataWithoutImageData.GL_Longitude="2";
  //   dataWithoutImageData.ImageType= x.documentType;
  //   //dataWithoutImageData.ImageData= item.imageData;
  //   dataWithoutImageData.LeadID="2";
  //   dataWithoutImageData.Type="Technical";
  //   dataWithoutImageData.LoanAccountNumber=this.legalData.lan;
  //   dataWithoutImageData.DocTypeDescription='';
  //   dataWithoutImageData.ImageMIMEType=docImageDetail.ImageMIMEType;
  //   dataWithoutImageData.Extension=docImageDetail.Extension;
  //   dataWithoutImageData.ModuleName='TechnicalVendor';
  //   dataWithoutImageData.Name=docImageDetail.Name;
  //   dataWithoutImageData.BankDetailID='';

    

  //   return this.http.httpPostWithouImageData<any>(dataImageUpload,'LAP_SaveImageUPL',dataWithoutImageData);

  // });

  //   this.legalData.legalDocumentsInfo.map((x, idx) => {
  //     if( x.imageData!=undefined || x.imageData!==''){
  //     x.imageData="";
  //     }
  // });

  // this.legalData.vendorDocumentsInfo.map((x, idx) => {
  //   if( x.imageData!=undefined || x.imageData!==''){
  //     x.imageData="";
  //     }
  // });


  // const anotherRequest = this.http.httpPost<ISubmitTechnicalAPI>((this.legalData), "LAP_SubmitTechnicalCaseDtl");
      
  // forkJoin([...requestsArray, anotherRequest]).subscribe(results => {
  //   if(this.legalData.decision_Legal==="Approve" || this.legalData.decision_Legal==="Refer" || this.legalData.decision_Legal==="Reject" ){
  //     this.isEdit=false;
  //   }
  //   this.notify.showSuccess("Saved successfully","Legal Vendor");
  //     this.route.navigateByUrl("/technicalVendorcheck");
  // });

  this.http.httpPost(this.legalData, 'LAP_SubmitTechnicalCaseDtl').subscribe((res: any) => {
     
    if(this.legalData.decision_Legal==="Negative" || this.legalData.decision_Legal==="Referred" 
    || this.legalData.decision_Legal==="Positive" ){
      this.isEdit=false;
      this.legalData.legalDocumentsInfo.map((x,index)=>{
        if(x.documentType === "Title Search Report"){
            this.legalData.legalDocumentsInfo.splice(index,1);
        } 
      }); 

      this.legalData.legalDocumentsInfo.map((x,index)=>{
        if(x.documentType === "Legal Report"){
          this.legalData.legalDocumentsInfo.splice(index,1);
        } 
      }); 
    }
    this.notify.showSuccess("Saved successfully","Technical Vendor");
    this.route.navigateByUrl("/technicalVendorcheck");
  });



}


Download(uuid:any){


  this.download.Download(uuid);
  // var data ={
  //   UUID :uuid
  // }

  // this.http.httpPost<IDownloadDocument>((data), 'LAP_DownloadDocument').subscribe((res: IDownloadDocument) => {
    
  //     if(res.imageData!=""){
  //       const downloadLink = document.createElement('a');
  //       const fileName = uuid + ".jpeg";
    
  //       downloadLink.href =  res.imageData;
  //       downloadLink.download = fileName;
  //       downloadLink.click();
  //     }
     
  // })
}

radiChange(type:any){
   if(type==="Positive"){
    this.legalData.decision_Legal="Positive";
   }
   if(type==="Referred"){
    this.legalData.decision_Legal="Referred";
   }
   if(type==="Negative"){
    this.legalData.decision_Legal="Negative";
   }
}

checkboxChange(event:any){

  this.legalData.isAgreed = event.currentTarget.checked;

}
 


}

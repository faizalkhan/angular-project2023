import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TechnicalCommonComponent } from './technical-common.component';

describe('TechnicalCommonComponent', () => {
  let component: TechnicalCommonComponent;
  let fixture: ComponentFixture<TechnicalCommonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TechnicalCommonComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TechnicalCommonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

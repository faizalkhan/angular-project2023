import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { forkJoin } from 'rxjs';
import { InfoServices } from 'src/app/Injectable/info.services';
import { NotificationService } from 'src/app/notification.service';
import { FileUpload, IfileUpload, UploadViewDownloadService } from 'src/app/pages/layout/button/upload-view-download/upload-view-download.service';
import { common } from 'src/app/shared/models/common';
import { Dropdown, DropdownWithIntValue, IDropdown, IDropdownWithNumberValue } from 'src/app/shared/models/common/control.model';
import { IImageUploadModel, ImageUploadModel, ImageUploadWithoutImageDataModel, IResSaveImageUPL, ISubmitTechnicalAPI } from 'src/app/shared/models/common/imageUpload.model';
import { ISanctionDashboardModel, SanctionDashboardModel } from 'src/app/shared/models/sanction/dashboard';
import { DocumentInfo, IDocumentInfo, IDownloadDocument, IVendorCasedModel, TechnicalRequestParam, VendorList } from 'src/app/shared/models/sanction/Legal/legalDashboard';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { LegalTechnicalService } from '../Legal-Technical.service';

@Component({
  selector: 'app-technical-common',
  templateUrl: './technical-common.component.html',
  styleUrls: ['./technical-common.component.css']
})
export class TechnicalCommonComponent implements OnInit {

  
  isEdit: boolean = true;
  isEditHeader: boolean = false;
  isEditable:boolean=false;
  isDropDownEdit:boolean=true;
  isEditRemark:boolean=true;
  isDocumentTypeDropDownEdit:boolean=true;
  isEnableSubmit:boolean=true;
  isFinalComment:boolean=false;
  vendorUploadEnable:boolean = true;

  @Input() legalRequestData!: TechnicalRequestParam;  
  VendorData: IDropdown[] = [];   
  materialsUsedInFloorsData: IDropdown[] = [];   
  materialsUsedInRoofsData: IDropdown[] = [];   
  materialsUsedLookOfWallsData: IDropdown[] = [];
  propertyTypeData: IDropdown[] = [];
  typeOfHouseData: IDropdown[] = [];
  DocumentType: IDropdown[] = [];   
  legalData!: IVendorCasedModel; 
  documentInfo!:DocumentInfo;
  iDocumentInfo!:IDocumentInfo;
  imageError:string='';
  isImageSaved: boolean=false;
  cardImageBase64: string='';    
  param: any;
  imageUploadModelList:ImageUploadModel[]=[];
  imageUploadModel!:ImageUploadModel;
  imageUploadWithoutImageDataModel!:ImageUploadWithoutImageDataModel;
  vendorList!:VendorList;
  caption:any;
  isShowVendor:boolean=true;
  isShowDownload:boolean=false;
  submitInterval:any;
  isShowQueue:boolean=false;
  titleSearchReport_UUID:string='';
  Title_Search_Technical_Remark:string='';
  technicalReport_UUID:string='';
  technical_Remark:string='';
  isHideAddMore:boolean=false;
  vendorName:any;
  private _requestData: ISanctionDashboardModel = new SanctionDashboardModel();
  public get requestData(): any {
      return {
          "LoanApplicationNo": this._requestData.lan,
          "LeadID": this._requestData.leadId,
          "AssociateID": this._requestData.flopsid,
          "McCode": this._requestData.mcCode,
          "LoanAccountNumber": this._requestData.lan,

      };

  }
  public set requestData(value: ISanctionDashboardModel) {
      this._requestData = value;
  }

constructor(private info: InfoServices,private http: ConfigService,private route:Router,
  private notify:NotificationService,private download: UploadViewDownloadService,private legalTechnicalService :LegalTechnicalService) { }

ngOnInit(): void {
  
  this.requestData = JSON.parse(this.info.getItem('LanInfo')) as SanctionDashboardModel;
  this.caption = this.info.getItem('Screen_Type');
  this.getLegalVendorList();
  this.getMaterialsUsedInFloorsData();
  this.getMaterialsUsedInRoofData();
  this.getMaterialsUsedLookOfWallsData();
  this.getPropertyTypeData();
  this.getTypeOfHouseData();
  this.getTechnicalCaseDetail(); 
 
  // this.DocumentType = [{ displayName: 'Title Document', selected: true, value: 'Title_Doc' }, 
  //                      { displayName: 'NOC', selected: false, value: 'NOC_Doc' },
  //                      { displayName: 'Non Agriculture form', selected: false, value: 'NONAgri_Doc' },
  //                      { displayName: 'Mutation form', selected: false, value: 'Mutation_Doc' },
  //                     ]

  this.DocumentType = this.legalTechnicalService.getDocumentType();


  if(this.caption!=="Unassigned Queue")
  {
    this.isShowVendor=false;
  }

  
  if(this.caption==="Vendor Queries Queue")
  {
    this.isShowDownload=true;
  }

  if(this.caption==="Status Queue"){
    this.isShowQueue=true;
  }

  //this.VendorData = [{ displayName: 'Vendor 1 - Legal', selected: true, value: 'Vend0001' }, { displayName: 'Vendor 2 - Legal', selected: false, value: 'Private' }]
}

keyPressNumbers(event: any) {
  var charCode = (event.which) ? event.which : event.keyCode;
  // Only Numbers 0-9
  if ((charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
  } else {
      return true;
  }
}

getTechnicalCaseDetail(){
  //var data = this.info.getItem('Technical_LanInfo');
  var data = {
    "lan": this.requestData.LoanAccountNumber,
    "login_PS_ID": "",
    "apiInvokeDateTime": "2022-11-07T12:58:16.867Z",
    "role": "string"
  }
  this.http.httpPost<IVendorCasedModel>(JSON.parse(JSON.stringify(data)), 'LAP_GetTechnicalCaseDtl').subscribe((res: IVendorCasedModel) => {
    
    if((res.legalDocumentsInfo.length===0) && (this.caption ==="Unassigned Queue"))
    {
      let legalDocCount  = res.legalDocumentsInfo.length +1;
      let docInfo = new DocumentInfo();
      docInfo.documentType="";
      docInfo.remark="";
      docInfo.uuid="";
      docInfo.uniqueId ="Technical_" + legalDocCount.toString();
      res.legalDocumentsInfo.push(docInfo);
    }  
    
    
    if((res.vendorDocumentsInfo.length===0) && (this.caption ==="Vendor Queries Queue"))
    {

      let legalDocCount  = res.legalDocumentsInfo.length;
        let vendorDocCount  = res.legalDocumentsInfo.length;
        let docCount = legalDocCount + vendorDocCount + 1;


      let docInfo = new DocumentInfo();
      docInfo.documentType="";
      docInfo.remark="";
      docInfo.uuid="";
      docInfo.uniqueId ="Technical_" + docCount.toString();
      res.vendorDocumentsInfo.push(docInfo);
    }  

    if(res.selectedLegalVendor === null){
      res.selectedLegalVendor="";
    }

    this.legalData = res;

    if(res!==null){ 

      if(res.legalDocumentsInfo!==undefined && res.legalDocumentsInfo.length>=0){
        res.legalDocumentsInfo.map((item,index)=>{
            let selectedDocumentType;
          if(item.documentType!==null){
             selectedDocumentType = this.DocumentType.find(x=>x.value===item.documentType);
             if(selectedDocumentType){
             res.legalDocumentsInfo[index].documentTypeDesc=selectedDocumentType?.displayName;
             res.legalDocumentsInfo[index].uniqueId="old";
             }
          }
        })
      }

      if(res.vendorDocumentsInfo!==undefined && res.vendorDocumentsInfo.length>=0){
        res.vendorDocumentsInfo.map((item,index)=>{
            let selectedDocumentType;
          if(item.documentType!==null){
             selectedDocumentType = this.DocumentType.find(x=>x.value===item.documentType);
             if(selectedDocumentType){
             res.vendorDocumentsInfo[index].documentTypeDesc=selectedDocumentType?.displayName;
             res.vendorDocumentsInfo[index].uniqueId="old";
             }
          }
        })
      }
    }

    if(res!==null){
      if(res.vendorDocumentsInfo!==undefined && res.vendorDocumentsInfo.length>=0){
    //   var titleSearchReport = res.vendorDocumentsInfo.filter(x=>x.documentType==="Title Search Report")
    //   if(titleSearchReport.length>0){
    //      this.titleSearchReport_UUID = titleSearchReport[0].uuid;
    //      this.Title_Search_Technical_Remark = titleSearchReport[0].remark;

    //      res.vendorDocumentsInfo.map((x,index)=>{
    //        if(x.documentType === "Title Search Report"){
    //            res.vendorDocumentsInfo.splice(index);
    //        } 
    //      }); 
    //  }

     var legalhReport = res.vendorDocumentsInfo.filter(x=>x.documentType==="Technical Report")
     if(legalhReport.length>0){
        this.technicalReport_UUID = legalhReport[0].uuid;
        this.technical_Remark = legalhReport[0].remark;

      
        
        res.vendorDocumentsInfo.map((x,index)=>{
          if(x.documentType === "Technical Report"){
              res.vendorDocumentsInfo.splice(index,1);
          } 
        }); 
     }
      }
    }
    this.screenType();

  });

 
}

getVendorName(){
  if((this.legalData.selectedLegalVendor) && this.legalData.selectedLegalVendor!==""){
    let selectedVendoName = this.VendorData.find(x=>x.value===this.legalData.selectedLegalVendor)
    this.vendorName = selectedVendoName?.displayName;
  }
}

screenType(){

  this.download.uploadLoad = new FileUpload({
    flO_Id: "",
    loanAccountNumber: this.requestData.LoanAccountNumber,
    moduleName: "Technical",
    applicationNo : this.requestData.LeadID,
    leadID:this.requestData.LeadID
} as IfileUpload);
 

   switch (this.legalData.caseStatus) {
    case "Inprogress with vendor":
       // this.Title_1 ="Vendor Queries Queue";
        this.isEdit = false; 
        this.isShowDownload=true;
        this.isShowVendor=false;
        this.isHideAddMore=true;
        this.isEnableSubmit=false;
        //this.isShowVendor=false;
        this.caption = "Technical Vendor";
        break;
    case "Technical vendor queries":{
       // this.Title_1 ="Vendor Queries Queue";
         this.isShowDownload=true;
         this.isShowVendor=false;          
         this.isEnableSubmit=true; 
         this.caption = "Technical Vendor Queries";
         this.isHideAddMore=false;
         this.legalData.selectedLegalVendor= this.legalData.selectedLegalVendor;
        //this.route.navigateByUrl("/legalunassginedcases");
        break;
    }
    case "Negative":
    case "Positive":
    case "Referred":{
        this.isShowQueue=true;
        this.isShowVendor=false;
        this.isShowDownload=true;
        this.caption  ="Status Queue";
        this.isHideAddMore=true;
        this.isEdit=false;
        this.isEditable=true;
        this.isEnableSubmit=true;
        this.isFinalComment=true;
        //this.Info.setItem('Screen_Type', "Status Queue");
        //this.route.navigateByUrl("/legalunassginedcases");
        break;
    }
    case "Completed": {
          this.isShowQueue=true;
          this.isShowVendor=false;
          this.isShowDownload=true;
          this.caption  ="Completed";
          this.isHideAddMore=true;
          this.isEdit=false;
          this.isEditable=false;
          this.isEnableSubmit=false;
          this.isFinalComment=true;
          //this.Info.setItem('Screen_Type', "Status Queue");
          //this.route.navigateByUrl("/legalunassginedcases");
          break;
      }
    default:{
        //this.Title_1 ="Unassigned Queue";
        this.caption = "Unassigned Queue";
        this.isHideAddMore=false;
        if(this.legalData.legalDocumentsInfo.length==0){
         this.addmore(); 
        }
        this.isShowVendor=true; 
        this.isEnableSubmit=true;
        //this.route.navigateByUrl("/legalunassginedcases");
        break;
      }
}

  if(this.info.IsItem("PendingScreenInfo")){
    this.isEnableSubmit=false;
  }

}

getMaterialsUsedInFloorsData(){
 
  this.param={
    "ItemType": "FLOOR"
  }

  this.http.httpPost<any>(this.param,'LAP_GetItemList').subscribe((res: any) => {
    if (res.resp.errorcode != 'E408') {                
        this.materialsUsedInFloorsData = res.items.map((x: any) => {
            return new Dropdown({ value: x.id, displayName: x.name, selected: false } as IDropdown);
        }); 
        this.materialsUsedInFloorsData.unshift(new Dropdown({ value: "0", displayName: "Please select", selected: true } as IDropdown));
    }
  }) 
}

getMaterialsUsedInRoofData(){
 
  this.param={
    "ItemType": "ROOF"
  }

  this.http.httpPost<any>(this.param,'LAP_GetItemList').subscribe((res: any) => {
    if (res.resp.errorcode != 'E408') {                
        this.materialsUsedInRoofsData = res.items.map((x: any) => {
            return new Dropdown({ value: x.id, displayName: x.name, selected: false } as IDropdown);
        }); 
        this.materialsUsedInRoofsData.unshift(new Dropdown({ value: "0", displayName: "Please select", selected: true } as IDropdown));
    }
  }) 
}

getMaterialsUsedLookOfWallsData(){
 
  this.param={
    "ItemType": "WALL"
  }

  this.http.httpPost<any>(this.param,'LAP_GetItemList').subscribe((res: any) => {
    if (res.resp.errorcode != 'E408') {                
        this.materialsUsedLookOfWallsData = res.items.map((x: any) => {
            return new Dropdown({ value: x.id, displayName: x.name, selected: false } as IDropdown);
        }); 
        this.materialsUsedLookOfWallsData.unshift(new Dropdown({ value: "0", displayName: "Please select", selected: true } as IDropdown));
    }
  }) 
}

  getPropertyTypeData(){
  
    this.param={
      "ItemType": "PROPERTY"
    }

    this.http.httpPost<any>(this.param,'LAP_GetItemList').subscribe((res: any) => {
      if (res.resp.errorcode != 'E408') {                
          this.propertyTypeData = res.items.map((x: any) => {
              return new Dropdown({ value: x.id, displayName: x.name, selected: false } as IDropdown);
          }); 
          this.propertyTypeData.unshift(new Dropdown({ value: "0", displayName: "Please select", selected: true } as IDropdown));
      }
    }) 
  }

  getTypeOfHouseData(){
  
    this.param={
      "ItemType": "HOUSE"
    }

    this.http.httpPost<any>(this.param,'LAP_GetItemList').subscribe((res: any) => {
      if (res.resp.errorcode != 'E408') {                
          this.typeOfHouseData = res.items.map((x: any) => {
              return new Dropdown({ value: x.id, displayName: x.name, selected: false } as IDropdown);
          }); 
          this.typeOfHouseData.unshift(new Dropdown({ value: "0", displayName: "Please select", selected: true } as IDropdown));
      }
    }) 
  }

getLegalVendorList(){
 
  this.param={MCCode: "MC919", Category: "Technical"};    

  this.http.httpPost<any>(this.param,'LAP_GetVendorList').subscribe((res: any) => {
    if (res.resp.errorcode != 'E408') {                
        this.VendorData = res.vendorList.map((x: any) => {
            return new Dropdown({ value: x.vendorId, displayName: x.vendorDesc, selected: false } as IDropdown);
        }); 
        this.VendorData.unshift(new Dropdown({ value: "", displayName: "Please select", selected: true } as IDropdown));
    }
  }) 
}

IsEdit(){
  this.isEdit = !this.isEdit;
}

docrows: any = []

  addmore() {

    let legalDocumentCount:number = this.legalData.legalDocumentsInfo.length+1;

    let docInfo = new DocumentInfo();
    docInfo.documentType="";
    docInfo.remark="";
    docInfo.uuid="";  
    docInfo.doc_Source="Technical";
    docInfo.doc_SourceScreen="Technical";
    docInfo.uniqueId ="Technical_" + legalDocumentCount.toString();
    this.legalData.legalDocumentsInfo.push(docInfo);   
    
    this.validateAllDocUploaded();
  }

  addmoreRowVendor(){
    let legalDocumentCount:number = this.legalData.legalDocumentsInfo.length;
      let vendorDocumentCount:number = this.legalData.vendorDocumentsInfo.length;
      let docCount = legalDocumentCount + vendorDocumentCount + 1;

    let docInfo = new DocumentInfo();
    docInfo.documentType="";
    docInfo.remark="";
    docInfo.uuid="";  
    docInfo.doc_Source="Technical";
    docInfo.doc_SourceScreen="Technical";
    docInfo.uniqueId ="Technical_" + docCount.toString();
    this.legalData.vendorDocumentsInfo.push(docInfo);   
    
    this.validateAllDocUploaded()
  };

  documentTypeChange(event:any){
      
    let iCount=0;       
     this.legalData.legalDocumentsInfo.forEach((item,index)=>{
    
       if(item.documentType===event.target.value){
        iCount = iCount+1; 
        let selectedDocumentType =  this.DocumentType.find(x=>x.value===event.target.value);
        if(selectedDocumentType){
          this.legalData.legalDocumentsInfo[index].documentTypeDesc=selectedDocumentType.displayName;
        }
       }
       if(iCount>1){

        this.legalData.legalDocumentsInfo[index].documentType=''; 
        event.target.value='';
        this.notify.showWarning("The same document type has been selected. Please select someother document type");
        return false;                      
       }
      return true;
     })   
  }

  validateAllDocUploaded(){
    let totalDocCount = this.DocumentType.length; 
    let legalDocCount = this.legalData.legalDocumentsInfo.length;
    let technicalDocCount = this.legalData.vendorDocumentsInfo.length;
    let uploadedDocCount = legalDocCount+technicalDocCount+1;

    if(uploadedDocCount>=totalDocCount){
     this.isHideAddMore=true;
    }
 }

  vendorDocumentTypeChange(event:any){
    
    let iCount=0;   

    // if(this.legalData.legalDocumentsInfo.length>=-1){          
    //   let documentUploaded = this.legalData.legalDocumentsInfo.find(x=>x.documentType===event.target.value)
    //   if(documentUploaded!=null){
    //     this.legalData.legalDocumentsInfo.forEach((item,index)=>{
    //       if(item.documentType===event.target.value){
    //           this.legalData.legalDocumentsInfo[index].uuid="";
    //       }
    //     });
    //   }  
    // }
  

     this.legalData.vendorDocumentsInfo.forEach((item,index)=>{
    
       if(item.documentType===event.target.value){
        iCount = iCount+1; 
        let selectedDocumentType =  this.DocumentType.find(x=>x.value===event.target.value);
        if(selectedDocumentType){
          this.legalData.vendorDocumentsInfo[index].documentTypeDesc=selectedDocumentType.displayName;
        }
       }
       if(iCount>1){

        this.legalData.vendorDocumentsInfo[index].documentType=''; 
        event.target.value='';
        this.notify.showWarning("The same document type has been selected. Please select someother document type");
        return false;                      
       }
      return true;
     })   
  }

  handleFileInput(fileInput: any,element:any) 
  {
    if (fileInput.target.files && fileInput.target.files[0]) {

    let file =fileInput.target.files[0] as File;
    // Size Filter Bytes
    const max_size = 20971520;
    const allowed_types = ['image/png', 'image/jpeg'];
    const max_height = 15200;
    const max_width = 25600;

    if (fileInput.target.files[0].size > max_size) {
        this.imageError =
            'Maximum size allowed is ' + max_size / 1000 + 'Mb';

        return false;
    }


    // if (!_.includes(allowed_types, fileInput.target.files[0].type)) {
    //     this.imageError = 'Only Images are allowed ( JPG | PNG )';
    //     return false;
    // }
    const reader = new FileReader();
    reader.onload = (e: any) => {
        const image = new Image();
        image.src = e.target.result;
                  
        // image.onload = rs => {
        //     const img_height = 100;
        //     const img_width = 120;



        //     if (img_height > max_height && img_width > max_width) {
        //         this.imageError =
        //             'Maximum dimentions allowed ' +
        //             max_height +
        //             '*' +
        //             max_width +
        //             'px';
        //         return false;
        //     } else {
                const imgBase64Path = e.target.result;
                // this.cardImageBase64 = imgBase64Path;
                // this.isImageSaved = true;
                
                // let imageUploadModelInfo = new ImageUploadModel;
                //  imageUploadModelInfo.Type ="legal";                 
                // var data = this.info.getItem('Legal_LanInfo');
                // imageUploadModelInfo.ApplicationNo = data.lan;
                // imageUploadModelInfo.ImageType = "NOC";
                // imageUploadModelInfo.ImageData =imgBase64Path; 
                // this.imageUploadModelList.push(this.imageUploadModel);

              if(this.caption==="Unassigned Queue")
              {
                if(this.legalData.legalDocumentsInfo.length!==-1){
                  this.legalData.legalDocumentsInfo.forEach((item,index)=>{
                     if(item.documentType===element){
                        this.legalData.legalDocumentsInfo[index].imageData=imgBase64Path.replace((imgBase64Path.substring(0,imgBase64Path.indexOf(",")+1)),'');
                        this.legalData.legalDocumentsInfo[index].doc_Source='Technical';
                        this.legalData.legalDocumentsInfo[index].doc_SourceScreen='Legal';      
                       
                        let imageUploadModel = new ImageUploadModel();
                        let extension:any ='';
                        extension =file.name.split('.').pop() === undefined ? "" : file.name.split('.').pop()?.toString();

                        imageUploadModel.ImageMIMEType = file.type;
                        imageUploadModel.Name = file.name;                        
                        imageUploadModel.ImageType = item.documentType;
                        imageUploadModel.Extension = extension;    
                        imageUploadModel.UUID= item.uniqueId;
                        
                        this.imageUploadModelList.push(imageUploadModel);
                     }
                  });
                }

              }

              
              if(this.caption==="Vendor Queries Queue")
              {
                if(this.legalData.vendorDocumentsInfo.length!==-1){
                  this.legalData.vendorDocumentsInfo.forEach((item,index)=>{
                     if(item.documentType===element){
                        this.legalData.vendorDocumentsInfo[index].imageData=imgBase64Path.replace((imgBase64Path.substring(0,imgBase64Path.indexOf(",")+1)),'');
                        this.legalData.vendorDocumentsInfo[index].doc_Source='Technical';   
                        this.legalData.vendorDocumentsInfo[index].doc_SourceScreen='Legal';
                        
                        let imageUploadModel = new ImageUploadModel();
                        let extension:any ='';
                        extension =file.name.split('.').pop() === undefined ? "" : file.name.split('.').pop()?.toString();

                        imageUploadModel.ImageMIMEType = file.type;
                        imageUploadModel.Name = file.name;                        
                        imageUploadModel.ImageType = item.documentType;
                        imageUploadModel.Extension = extension;    
                        imageUploadModel.UUID= item.uniqueId;
                        
                        this.imageUploadModelList.push(imageUploadModel);
                     }
                  });
                }
              }


              
                return true;
                // this.previewImagePath = imgBase64Path;
        //     }
        // };
    };

    reader.readAsDataURL(fileInput.target.files[0]);
    return true;
  }
    return false;
  }
  RemoveLegalDocument(event:any,index:number){
    this.legalData.legalDocumentsInfo.splice(index,1);
  }

  RemoveVendorDocument(event:any,index:number){
    this.legalData.vendorDocumentsInfo.splice(index,1);
  }

  Validate(){

    let isFound:boolean=true;

    if(this.legalData.selectedLegalVendor==="Please select"){
      this.legalData.selectedLegalVendor="";
      
    }

    if((!common.IsRequired(this.legalData.selectedLegalVendor)) || this.legalData.selectedLegalVendor===""){
         this.notify.showWarning("Please select the technical vendor ");
         isFound = false; 
      }  
    

    if(isFound){
      this.legalData.legalDocumentsInfo.forEach((x)=>{
        if(x.uuid==="" && x.uniqueId!=="old"){
          this.notify.showWarning("Please upload the document for the document type " + x.documentType);
          isFound = false; 
        }  
      })
    }

    if(isFound){
      this.legalData.legalDocumentsInfo.forEach((x)=>{
        if(x.uuid!=="" && x.uniqueId!=="old" && x.documentType===""){
          this.notify.showWarning("Please select the document type");
          isFound = false; 
        }  
      })
    }

    if(isFound){
      this.legalData.legalDocumentsInfo.forEach((x)=>{
        if(x.uuid!=="" && x.uniqueId!=="old" && x.documentType!=="" && x.remark===""){
          this.notify.showWarning("Please specify the remark for the document type " + x.documentType);
          isFound = false; 
        }  
      })
    }

    if(isFound){
      let docList =  this.legalData.legalDocumentsInfo.find(x=>x.documentType.includes("Title"))
       if(docList===undefined || docList===null)
       {
         this.notify.showWarning("Please upload the title document");
         isFound = false; 
       }
     }
  
    if(isFound){
      this.legalData.vendorDocumentsInfo.forEach((x)=>{
        if(x.uuid===""  && x.uniqueId!=="old"){
          this.notify.showWarning("Please upload the document for the document type " + x.documentType);
          isFound = false; 
        }  
      })
    }

    if(isFound){
      this.legalData.vendorDocumentsInfo.forEach((x)=>{
        if(x.uuid!==""  && x.uniqueId!=="old" && x.documentType===""){
          this.notify.showWarning("Please select the document type " + x.documentType);
          isFound = false; 
        }  
      })
    }

    if(isFound){
      this.legalData.vendorDocumentsInfo.forEach((x)=>{
        if(x.uuid!=="" && x.uniqueId!=="old" && x.documentType!=="" && x.remark===""){
          this.notify.showWarning("Please specify the remark for the document type " + x.documentType);
          isFound = false; 
        }  
      })
    }

    if(isFound){
      if((this.legalData.yearOfConstruction) && this.legalData.yearOfConstruction.toString()!==""){
          if(!common.IsValidYear(this.legalData.yearOfConstruction)){
            this.notify.showWarning("Please enter the valid year");
            isFound = false; 
          }
      }
    }

    if(this.legalData.legalDocumentsInfo.length>=-1 && this.legalData.vendorDocumentsInfo.length>=-1){ 
      this.legalData.vendorDocumentsInfo.forEach((iItem,iIndex)=>{ 
        let documentUploaded = this.legalData.legalDocumentsInfo.find(x=>x.documentType===iItem.documentType)
        if(documentUploaded!=null){
          this.legalData.legalDocumentsInfo.forEach((item,index)=>{
            if(item.documentType===iItem.documentType){
                this.legalData.legalDocumentsInfo[index].uuid="";
                this.legalData.legalDocumentsInfo[index].imageData="";
            }
          });
        } 
      }); 
   } 

   if(isFound){
    if(this.legalData.caseStatus==="Positive" || this.legalData.caseStatus==="Referred" || this.legalData.caseStatus==="Negative"){
        if(isFound && (!this.legalData.typeOfHouse || this.legalData.typeOfHouse.toString()==="0" ||
                       this.legalData.typeOfHouse.toString()==="")){
            this.notify.showWarning("Please select the Type of House");
            isFound = false;           
        }

        if(isFound && (!this.legalData.propertyType || this.legalData.propertyType.toString()==="0" ||
        this.legalData.propertyType.toString()==="")){
          this.notify.showWarning("Please select the Property Type");
          isFound = false; 
        }
        if(isFound && (!this.legalData.yearOfConstruction || this.legalData.yearOfConstruction.toString()==="0" ||
        this.legalData.yearOfConstruction.toString()==="")){
          this.notify.showWarning("Please specify the Year of Construction");
          isFound = false; 
        }

        if(isFound && (this.legalData.yearOfConstruction.toString().length>4 
        || this.legalData.yearOfConstruction.toString().length <4 )){
          this.notify.showWarning("Please specify the valid Year of Construction");
          isFound = false; 
        }

        if(isFound && (!this.legalData.unitDetails || this.legalData.unitDetails==="")){
          this.notify.showWarning("Please select the Unit details");
          isFound = false; 
        }
        

        if(isFound && (!this.legalData.materialsUsedLookOfWalls || this.legalData.materialsUsedLookOfWalls.toString()==="0"
        || this.legalData.materialsUsedLookOfWalls.toString()==="")){
          this.notify.showWarning("Please specify the Material Used/Exterial Look of walls");
          isFound = false; 
        }
        if(isFound && (!this.legalData.materialsUsedInRoofs || this.legalData.materialsUsedInRoofs.toString()==="0"
        || this.legalData.materialsUsedInRoofs.toString()==="")){
          this.notify.showWarning("Please specify the Materials Used in Roofs");
          isFound = false; 
        }
        if(isFound && (!this.legalData.materialsUsedInFloors || this.legalData.materialsUsedInFloors.toString()==="0"
        || this.legalData.materialsUsedInFloors.toString()==="")){
          this.notify.showWarning("Please specify the Materials Used in Floors");
          isFound = false; 
        }
        if(isFound && (!this.legalData.plot_Area
        || this.legalData.plot_Area.toString()==="")){
          this.notify.showWarning("Please specify the Plot Area");
          isFound = false; 
        }
        if(isFound && (!this.legalData.plot_CircleRate || this.legalData.plot_CircleRate.toString()==="0"
        || this.legalData.plot_CircleRate.toString()==="")){
          this.notify.showWarning("Please specify the Plot Circle Rate");
          isFound = false; 
        }
        if(isFound && (!this.legalData.plot_MarketRate || this.legalData.plot_MarketRate.toString()==="0"
        || this.legalData.plot_MarketRate.toString()==="")){
          this.notify.showWarning("Please specify the Plot Market Rate");
          isFound = false; 
        }
        if(isFound && (!this.legalData.builtUp_Area || this.legalData.builtUp_Area.toString()==="0"
        || this.legalData.builtUp_Area.toString()==="")){
          this.notify.showWarning("Please specify the Build up Area");
          isFound = false; 
        }
        if(isFound && (!this.legalData.builtUp_CircleRate || this.legalData.builtUp_CircleRate.toString()==="0"
        || this.legalData.builtUp_CircleRate.toString()==="")){
          this.notify.showWarning("Please specify the Build up Circle Rate");
          isFound = false; 
        }
        if(isFound && (!this.legalData.builtUp_MarketRate || this.legalData.builtUp_MarketRate.toString()==="0"
        || this.legalData.builtUp_MarketRate.toString()==="")){
          this.notify.showWarning("Please specify the Build up Market Rate");
          isFound = false; 
        }

        if(isFound && (!this.legalData.bcM_TEchValuation || this.legalData.bcM_TEchValuation==="")){
          this.notify.showWarning("Please specify the Final Valuation by Technical Vendor (Amount)");
          isFound = false; 
        }

    }
   }
    return isFound;
  }
  
  Submit1(){
    

    
    if(!this.Validate()){
      return;
     }
    var legalDocuments =[];
    var vendorDocument : DocumentInfo[] =[];
    
    legalDocuments = this.legalData.legalDocumentsInfo.filter(x=>x.imageData!=="" && x.imageData !==null);
    vendorDocument = this.legalData.vendorDocumentsInfo.filter(x=>x.imageData!=="" && x.imageData !==null);
    
    legalDocuments.push(...vendorDocument);

    if(this.legalData.caseStatus === "Unassigned Cases"){
      this.legalData.caseStatus="Inprogress with vendor";
      this.legalData.decision_Legal="New";
    }

    if(this.legalData.caseStatus === "Technical vendor queries"){
      this.legalData.caseStatus="Inprogress with vendor";
    }

    if(this.legalData.caseStatus==="Negative" || this.legalData.caseStatus==="Referred" || this.legalData.caseStatus==="Positive"){
      this.legalData.caseStatus="Completed";
    }

    // const requestsArray = legalDocuments.map((x, idx) => {

    //   let dataImageUpload = new ImageUploadModel();
    //   let dataWithoutImageData = new ImageUploadWithoutImageDataModel();
    //   let docImageDetail: ImageUploadModel = new ImageUploadModel()

      
    //   if(this.imageUploadModelList.length>=-1){
    //      docImageDetail = this.imageUploadModelList.find(image=>image.ImageType===x.documentType) as ImageUploadModel;
    //   }

    //   dataImageUpload.ApplicationNo= this.legalData.lan;
    //   dataImageUpload.FLO_Id="23";
    //   dataImageUpload.GL_Latitude="2";
    //   dataImageUpload.GL_Longitude="2";
    //   dataImageUpload.ImageType=  docImageDetail.UUID;//x.documentType;
    //   dataImageUpload.ImageData= x.imageData;
    //   dataImageUpload.LeadID="2";
    //   dataImageUpload.Type="Technical";
    //   dataImageUpload.LoanAccountNumber=this.legalData.lan;
    //   dataImageUpload.DocTypeDescription='';
    //   dataImageUpload.ImageMIMEType=docImageDetail.ImageMIMEType;
    //   dataImageUpload.Extension=docImageDetail.Extension;
    //   dataImageUpload.ModuleName='Technical';
    //   dataImageUpload.Name=docImageDetail.Name;
    //   dataImageUpload.BankDetailID='';

    //   dataWithoutImageData.ApplicationNo= this.legalData.lan;
    //   dataWithoutImageData.FLO_Id="23";
    //   dataWithoutImageData.GL_Latitude="2";
    //   dataWithoutImageData.GL_Longitude="2";
    //   dataWithoutImageData.ImageType=  docImageDetail.UUID;//x.documentType;
    //   dataWithoutImageData.ImageData= '';
    //   dataWithoutImageData.LeadID="2";
    //   dataWithoutImageData.Type="Technical"; 
    //   dataWithoutImageData.LoanAccountNumber=this.legalData.lan;
    //   dataWithoutImageData.DocTypeDescription='';
    //   dataWithoutImageData.ImageMIMEType=docImageDetail.ImageMIMEType;
    //   dataWithoutImageData.Extension=docImageDetail.Extension;
    //   dataWithoutImageData.ModuleName='Technical';
    //   dataWithoutImageData.Name=docImageDetail.Name;
    //   dataWithoutImageData.BankDetailID='';
    //   //dataWithoutImageData.UUID=docImageDetail.UUID;

    //   return this.http.httpPostWithouImageData<any>(dataImageUpload,'LAP_SaveImageUPL',dataWithoutImageData);

    // });

    //   this.legalData.legalDocumentsInfo.map((x, idx) => {
    //     x.imageData="";
    // });

    
    // this.legalData.vendorDocumentsInfo.map((x, idx) => {
    //   x.imageData="";
    // });


    // const anotherRequest = this.http.httpPost<ISubmitTechnicalAPI>((this.legalData), "LAP_SubmitTechnicalCaseDtl");
        
    // forkJoin([...requestsArray, anotherRequest]).subscribe(results=> {
       
    //     this.notify.showSuccess("Saved successfully","Technical");
    //     this.vendorUploadEnable=false;
    //     if(this.legalData.caseStatus==="Unassigned Queue" || this.legalData.caseStatus==="Technical vendor queries" || this.legalData.caseStatus==="Inprogress with vendor"){
    //       this.isEdit=false;
    //       this.isEnableSubmit=false; 
    //     }
    //     this.route.navigateByUrl("/technicalcheck");
    // });

    this.http.httpPost(this.legalData, 'LAP_SubmitTechnicalCaseDtl').subscribe((res: any) => {

      if(res.errorcode!=="0")
         this.notify.showError(res.errorDescription,"Technical");
      else{
        this.notify.showSuccess("Saved Successfully","Technical");
        
      if(this.legalData.caseStatus==="Unassigned Queue" || this.legalData.caseStatus==="Technical vendor queries" 
       || this.legalData.caseStatus==="Inprogress with vendor" || this.legalData.caseStatus==="Completed"){
        this.isEdit=false;
        this.isEnableSubmit=false; 
        this.isEditable=false;
        this.vendorUploadEnable=false;
        this.isHideAddMore=true;
        this.getVendorName();
      }
      this.route.navigateByUrl("/technicalcheck");
    }
  })

  }

  // Submit(){

    
                  
  //     if(this.legalData.legalDocumentsInfo!=undefined && this.legalData.legalDocumentsInfo.length!=-1){
  //       let dataImageUpload = new ImageUploadModel();
  //       let dataWithoutImageData = new ImageUploadWithoutImageDataModel();
  //       let uploadDocument=[]; 
        
  //       this.legalData.legalDocumentsInfo.forEach((item,array)=>{
            
  //             dataImageUpload.ApplicationNo= this.legalData.lan;
  //             dataImageUpload.FLO_Id="23";
  //             dataImageUpload.GL_Latitude="2";
  //             dataImageUpload.GL_Longitude="2";
  //             dataImageUpload.ImageType= item.documentType;
  //             dataImageUpload.ImageData= item.imageData;
  //             dataImageUpload.LeadID="2";
  //             dataImageUpload.Type="Legal";

  //             dataWithoutImageData.ApplicationNo= this.legalData.lan;
  //             dataWithoutImageData.FLO_Id="23";
  //             dataWithoutImageData.GL_Latitude="2";
  //             dataWithoutImageData.GL_Longitude="2";
  //             dataWithoutImageData.ImageType= item.documentType;
  //             //dataWithoutImageDatadataWithoutImageData.ImageData= item.imageData;
  //             dataWithoutImageData.LeadID="2";
  //             dataWithoutImageData.Type="Legal";

  //             if(item.imageData!==""){ 
  //             this.http.httpPostWithouImageData<IResSaveImageUPL>((dataImageUpload), 'MFI_LAP_SaveImageUPL',dataWithoutImageData).subscribe((res: IResSaveImageUPL) => {        
  //               if(res.Errorcode==="0"){
  //                 this.legalData.legalDocumentsInfo[array].uuid =res.UniqueID;
  //                 this.legalData.legalDocumentsInfo[array].imageData ="";
  //               }
  //             })
  //           }
  //       });         
  //     }
      
  //     if(this.legalData.vendorDocumentsInfo!=undefined && this.legalData.vendorDocumentsInfo.length!=-1){
  //       let dataImageUpload = new ImageUploadModel();
  //       let dataWithoutImageData = new ImageUploadWithoutImageDataModel();
  //       this.legalData.vendorDocumentsInfo.forEach((item,array)=>{
  //           dataImageUpload.ApplicationNo= this.legalData.lan;
  //           dataImageUpload.FLO_Id="";
  //           dataImageUpload.GL_Latitude="";
  //           dataImageUpload.GL_Longitude="";
  //           dataImageUpload.ImageType= item.documentType;
  //           dataImageUpload.ImageData= item.imageData;
  //           dataImageUpload.LeadID="";
  //           dataImageUpload.Type="Legal";

  //           dataWithoutImageData.ApplicationNo= this.legalData.lan;
  //           dataWithoutImageData.FLO_Id="";
  //           dataWithoutImageData.GL_Latitude="";
  //           dataWithoutImageData.GL_Longitude="";
  //           dataWithoutImageData.ImageType= item.documentType;
  //           //dataWithoutImageData.ImageData= item.imageData;
  //           dataWithoutImageData.LeadID="";
  //           dataWithoutImageData.Type="Legal";

  //           //  const requestsArray = this.legalData.vendorDocumentsInfo.map((x, idx) => {

  //           //       dataImageUpload.ApplicationNo= this.legalData.lan;
  //           //       dataImageUpload.FLO_Id="";
  //           //       dataImageUpload.GL_Latitude="";
  //           //       dataImageUpload.GL_Longitude="";
  //           //       dataImageUpload.ImageType= x.documentType;
  //           //       dataImageUpload.ImageData= x.imageData;
  //           //       dataImageUpload.LeadID="";
  //           //       dataImageUpload.Type="Legal";
    
  //           //       dataWithoutImageData.ApplicationNo= this.legalData.lan;
  //           //       dataWithoutImageData.FLO_Id="";
  //           //       dataWithoutImageData.GL_Latitude="";
  //           //       dataWithoutImageData.GL_Longitude="";
  //           //       dataWithoutImageData.ImageType= x.documentType;
  //           //       //dataWithoutImageData.ImageData= item.imageData;
  //           //       dataWithoutImageData.LeadID="";
  //           //       dataWithoutImageData.Type="Legal";
                  
            
  //           //       return this.http.httpPostWithouImageData(dataImageUpload,'MFI_LAP_SaveImageUPL',dataWithoutImageData);
  //           //   });
              
  //           //   const anotherRequest = this.http.httpPostWithouImageData(dataImageUpload,'MFI_LAP_SaveImageUPL',dataWithoutImageData);
              
  //           //   forkJoin([...requestsArray, anotherRequest]).subscribe(results => {
  //           //   });

  //           if(item.imageData!=""){
  //           this.http.httpPostWithouImageData<IResSaveImageUPL>((dataImageUpload), 'MFI_LAP_SaveImageUPL',dataWithoutImageData).subscribe((res: IResSaveImageUPL) => {        
  //               if(res.Errorcode==="0"){
  //               this.legalData.vendorDocumentsInfo[array].uuid =res.UniqueID;
  //               this.legalData.vendorDocumentsInfo[array].imageData ="";
  //               }
  //           })
  //           }
  //       });         
  //   } 

  //   setTimeout(()=>{                           // <<<---using ()=> syntax
  //     this.submitInterval =  this.http.httpPost<ISubmitTechnicalAPI>((this.legalData), "LAP_SubmitTechnicalCaseDtl").subscribe((res: ISubmitTechnicalAPI) => {        
  //       if(res.errorcode==="200"){
  //       }
  //     }); 
  //     }, 5000); 
  // }

 

  Download(uuid:any){
    
    this.download.Download(uuid);
    // var data ={
    //   UUID :uuid
    // }

    // this.http.httpPost<IDownloadDocument>((data), 'LAP_DownloadDocument').subscribe((res: IDownloadDocument) => {
      
    //     if(res.imageData!=""){
    //       const downloadLink = document.createElement('a');
    //       const fileName = uuid + ".jpeg";
      
    //       downloadLink.href =  res.imageData;
    //       downloadLink.download = fileName;
    //       downloadLink.click();
    //     }
      
    // })
  }
  
 

  Reply(documentType:any){

  }

  radiChange(event:any,type:any){
    
    if(type==="flat"){
       this.legalData.unitDetails="flat";
    }
    if(type==="otherthanflat"){
    this.legalData.unitDetails="otherthanflat";
    }
    
  }
}   
import { JsonPipe } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { forkJoin, retry } from 'rxjs';
import { AnyCatcher } from 'rxjs/internal/AnyCatcher';
import { InfoServices } from 'src/app/Injectable/info.services';
import { NotificationService } from 'src/app/notification.service';
import { FileUpload, IfileUpload, UploadViewDownloadService } from 'src/app/pages/layout/button/upload-view-download/upload-view-download.service';
import { common } from 'src/app/shared/models/common';
import { Dropdown, IDropdown } from 'src/app/shared/models/common/control.model';
import { headerModel } from 'src/app/shared/models/common/header-table';
import { IImageUploadModel, ImageUploadModel, ImageUploadWithoutImageDataModel, IResSaveImageUPL, ISubmitLegalAPI } from 'src/app/shared/models/common/imageUpload.model';
import { ILegalDashboardResponseModel } from 'src/app/shared/models/common/response.model';
import { ISanctionDashboardModel, SanctionDashboardModel } from 'src/app/shared/models/sanction/dashboard';

import { DocumentInfo, IDocumentInfo, IDownloadDocument, ILegalCasedModel, ILegalVendordParamModel, IVendorList, LegalDashboardModel, LegalRequestParam, VendorList } from 'src/app/shared/models/sanction/Legal/legalDashboard';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { LegalCommonService } from '../legal-common.service';
import { LegalTechnicalService } from '../Legal-Technical.service';

@Component({
  selector: 'app-legal-common',
  templateUrl: './legal-common.component.html',
  styleUrls: ['./legal-common.component.css']
})
export class LegalCommonComponent implements OnInit {

  isEdit: boolean = true;
  isEditHeader: boolean = false;
  isDropDownEdit: boolean = true;
  //isEditRemark:boolean=true;
  isHideAddMore: boolean = false;
  showSentBack: boolean = false;
  isDocumentTypeDropDownEdit: boolean = true;
  titleSearchReport_UUID: string = '';
  legalReport_UUID: string = '';
  @Input() legalRequestData!: LegalRequestParam;
  @Input() URL: any = 'LAP_HA_PhysicalDiscussion';
  VendorData: IDropdown[] = [];
  DocumentType: IDropdown[] = [];
  chainFlow: IDropdown[] = [];
  legalData!: ILegalCasedModel;
  documentInfo!: DocumentInfo;
  iDocumentInfo!: IDocumentInfo;
  imageError: string = '';
  isImageSaved: boolean = false;
  cardImageBase64: string = '';
  param: any;
  imageUploadModelList: IImageUploadModel[] = [];
  imageUploadModel!: ImageUploadModel;
  imageUploadWithoutImageDataModel!: ImageUploadWithoutImageDataModel;
  vendorList!: VendorList;
  caption: any;
  isShowVendor: boolean = true;
  isShowDownload: boolean = false;
  submitInterval: any;
  isShowQueue: boolean = false;
  private _data: LegalDashboardModel = new LegalDashboardModel();
  Title_Search_legal_Remark: string = '';
  legal_Remark: string = '';
  vendorUploadEnable: boolean = true;
  legalApproveRejectFields: boolean = true;
  vendorName: any;
  public get readonly(): boolean {
    return common.readonly;
  }

  private _requestData: ISanctionDashboardModel = new SanctionDashboardModel();
  public get requestData(): any {
    return {
      "LoanApplicationNo": this._requestData.lan,
      "LeadID": this._requestData.leadId,
      "AssociateID": this._requestData.flopsid,
      "McCode": this._requestData.mcCode,
      "LoanAccountNumber": this._requestData.lan,
    };

  }
  public set requestData(value: ISanctionDashboardModel) {
    this._requestData = value;
  }

  public get Data(): LegalDashboardModel {
    return this._data;
  }
  public set Data(value: LegalDashboardModel) {
    this._data = value;
  }

  constructor(private info: InfoServices, private http: ConfigService, private route: Router, private notify: NotificationService
    , private download: UploadViewDownloadService, private legalTechnicalService: LegalTechnicalService, private sancationService: SanctionService) { }

  ngOnInit(): void {

    this.requestData = this.sancationService.LanInfo as SanctionDashboardModel;

    this.getLegalVendorList();
    this.getLegalCaseDetail();
    this.DocumentType = this.legalTechnicalService.getDocumentType();

    this.chainFlow = this.legalTechnicalService.getChainFlow();
  }

  screenType() {


    this.download.uploadLoad = new FileUpload({
      flO_Id: "",
      loanAccountNumber: this.requestData.LoanAccountNumber,
      moduleName: "Legal",
      applicationNo: this.requestData.LeadID,
      leadID: this.requestData.LeadID
    } as IfileUpload);


    switch (this.legalData.caseStatus) {
      case "Inprogress with vendor":
        // this.Title_1 ="Vendor Queries Queue";
        this.isEdit = false;
        this.isShowDownload = true;
        this.isShowVendor = false;
        this.isHideAddMore = true;
        this.legalApproveRejectFields = false;
        //this.isShowVendor=false;
        this.caption = "Legal Vendor";
        break;
      case "Legal vendor queries": {
        // this.Title_1 ="Vendor Queries Queue";
        this.isShowDownload = true;
        this.isShowVendor = false;
        this.caption = "Legal Vendor Queries";
        this.isHideAddMore = false;
        this.legalData.selectedLegalVendor = this.legalData.selectedLegalVendor;
        //this.route.navigateByUrl("/legalunassginedcases");
        break;
      }
      case "Positive":
      case "Negative":
      case "Referred": {
        this.isShowQueue = true;
        this.isShowVendor = false;
        this.isShowDownload = true;
        this.legalApproveRejectFields = true;
        this.caption = "Status Queue";
        this.isHideAddMore = true;
        this.isEdit = false;
        //this.Info.setItem('Screen_Type', "Status Queue");
        //this.route.navigateByUrl("/legalunassginedcases");
        break;
      }
      case "Completed":{
          this.isShowQueue=true;
          this.isShowVendor=false;
          this.isShowDownload=true;
          this.legalApproveRejectFields=false;
          this.caption  ="Completed";
          this.isHideAddMore=true;
          this.isEdit=false;
          //this.Info.setItem('Screen_Type', "Status Queue");
          //this.route.navigateByUrl("/legalunassginedcases");
          break;
      }
      default: {
        //this.Title_1 ="Unassigned Queue";
        this.caption = "Unassigned Queue";
        this.isHideAddMore = false;
        if (this.legalData.legalDocumentsInfo.length == 0) {
          this.addmore();
        }
        this.isShowVendor = true;
        //this.route.navigateByUrl("/legalunassginedcases");
        break;
      }
    }

    if (this.info.IsItem("PendingScreenInfo")) {
      this.legalApproveRejectFields = false;
    }

  }

  getLegalCaseDetail() {

    // var data = this.info.getItem('Legal_LanInfo');

    var data = {
      "lan": this.requestData.LoanAccountNumber,
      "login_PS_ID": "",
      "apiInvokeDateTime": "2022-11-07T12:58:16.867Z",
      "role": "string"
    }

    this.http.httpPost<ILegalCasedModel>(JSON.parse(JSON.stringify(data)), 'LAP_GetLegalCaseDtl').subscribe((res: ILegalCasedModel) => {


      if (res === undefined || res === null) {
        return;
      }

      if (res.lan === null) {
        return;
      }
      if (res.selectedLegalVendor === null) {
        res.selectedLegalVendor = '';
      }

      this.legalData = res;

      if (res !== null) {
        if (res.legalDocumentsInfo !== undefined && res.legalDocumentsInfo.length >= 0) {
          res.legalDocumentsInfo.map((item, index) => {
            let selectedDocumentType;
            if (item.documentType !== null) {
              selectedDocumentType = this.DocumentType.find(x => x.value === item.documentType);
              if (selectedDocumentType) {
                res.legalDocumentsInfo[index].documentTypeDesc = selectedDocumentType?.displayName;
                res.legalDocumentsInfo[index].uniqueId = "old";
              }
            }
          })
        }

        if (res.vendorDocumentsInfo !== undefined && res.vendorDocumentsInfo.length >= 0) {
          res.vendorDocumentsInfo.map((item, index) => {
            let selectedDocumentType;
            if (item.documentType !== null) {
              selectedDocumentType = this.DocumentType.find(x => x.value === item.documentType);
              if (selectedDocumentType) {
                res.vendorDocumentsInfo[index].documentTypeDesc = selectedDocumentType?.displayName;
                res.vendorDocumentsInfo[index].uniqueId = "old";
              }
            }
          })
        }

        if ((res.legalDocumentsInfo.length === 0) && (this.caption === "Unassigned Queue")) {
          let legalDocCount = res.legalDocumentsInfo.length + 1;
          let docInfo = new DocumentInfo();
          docInfo.documentType = "";
          docInfo.remark = "";
          docInfo.uuid = "";
          docInfo.uniqueId = "Legal_" + legalDocCount.toString();
          res.legalDocumentsInfo.push(docInfo);
        }


        if ((res.vendorDocumentsInfo.length === 0) && (this.caption === "Vendor Queries Queue")) {
          let legalDocCount = res.legalDocumentsInfo.length;
          let vendorDocCount = res.legalDocumentsInfo.length;
          let docCount = legalDocCount + vendorDocCount + 1;

          let docInfo = new DocumentInfo();
          docInfo.documentType = "";
          docInfo.remark = "";
          docInfo.uuid = "";
          docInfo.uniqueId = "Legal_" + docCount.toString();
          res.vendorDocumentsInfo.push(docInfo);
        }

      }


      if (res !== null) {
        if (res.vendorDocumentsInfo !== undefined && res.vendorDocumentsInfo.length >= 0) {
          var titleSearchReport = res.vendorDocumentsInfo.filter(x => x.documentType === "Title Search Report")
          if (titleSearchReport.length > 0) {
            this.titleSearchReport_UUID = titleSearchReport[0].uuid;
            this.Title_Search_legal_Remark = titleSearchReport[0].remark;

            res.vendorDocumentsInfo.map((x, index) => {
              if (x.documentType === "Title Search Report") {
                res.vendorDocumentsInfo.splice(index, 1);
              }
            });
          }

          var legalReport = res.vendorDocumentsInfo.filter(x => x.documentType === "Legal Report")
          if (legalReport.length > 0) {
            this.legalReport_UUID = legalReport[0].uuid;
            this.legal_Remark = legalReport[0].remark;


            res.vendorDocumentsInfo.map((x, index) => {
              if (x.documentType === "Legal Report") {
                res.vendorDocumentsInfo.splice(index, 1);
              }
            });
          }

        }
      }



      this.screenType();
    });
  }

  getLegalVendorList() {

    this.param = { MCCode: "MC919", Category: "Legal" };

    this.http.httpPost<any>(this.param, 'LAP_GetVendorList').subscribe((res: any) => {
      if (res.resp.errorcode != 'E408') {
        this.VendorData = res.vendorList.map((x: any) => {
          return new Dropdown({ value: x.vendorId, displayName: x.vendorDesc, selected: false } as IDropdown);
        });
        this.VendorData.unshift(new Dropdown({ value: '', displayName: "Please select", selected: true } as IDropdown));
      }
    })
  }

  IsEdit() {
    this.isEdit = !this.isEdit;
  }

  docrows: any = []

  addmore() {

    let legalDocumentCount: number = this.legalData.legalDocumentsInfo.length + 1;


    let docInfo = new DocumentInfo();
    docInfo.documentType = "";
    docInfo.remark = "";
    docInfo.uuid = "";
    docInfo.doc_Source = "Legal";
    docInfo.doc_SourceScreen = "Legal";
    docInfo.uniqueId = "Legal_" + legalDocumentCount.toString();
    this.legalData.legalDocumentsInfo.push(docInfo);
    this.validateAllDocUploaded();
  }

  addmoreRowVendor() {
    let legalDocumentCount: number = this.legalData.legalDocumentsInfo.length;
    let vendorDocumentCount: number = this.legalData.vendorDocumentsInfo.length;
    let docCount = legalDocumentCount + vendorDocumentCount + 1;



    let docInfo = new DocumentInfo();
    docInfo.documentType = "";
    docInfo.remark = "";
    docInfo.uuid = "";
    docInfo.doc_Source = "Legal";
    docInfo.doc_SourceScreen = "Legal";
    docInfo.uniqueId = "Legal_" + docCount.toString();
    this.legalData.vendorDocumentsInfo.push(docInfo);

    this.validateAllDocUploaded();
  };

  documentTypeChange(event: any) {

    let iCount = 0;
    this.legalData.legalDocumentsInfo.forEach((item, index) => {

      if (item.documentType === event.target.value) {
        iCount = iCount + 1;
        let selectedDocumentType = this.DocumentType.find(x => x.value === event.target.value);
        if (selectedDocumentType) {
          this.legalData.legalDocumentsInfo[index].documentTypeDesc = selectedDocumentType.displayName;
        }
      }
      if (iCount > 1) {

        this.legalData.legalDocumentsInfo[index].documentType = '';
        event.target.value = '';
        this.notify.showWarning("The same document type has been selected. Please select someother document type");
        return false;
      }
      return true;
    })

  }

  validateAllDocUploaded() {
    let totalDocCount = this.DocumentType.length;
    let legalDocCount = this.legalData.legalDocumentsInfo.length;
    let technicalDocCount = this.legalData.vendorDocumentsInfo.length;
    let uploadedDocCount = legalDocCount + technicalDocCount + 1;

    if (uploadedDocCount >= totalDocCount) {
      this.isHideAddMore = true;
    }
  }

  vendorDocumentTypeChange(event: any) {
    let iCount = 0;
    this.legalData.vendorDocumentsInfo.forEach((item, index) => {
      if (item.documentType === event.target.value) {
        iCount = iCount + 1;
        let selectedDocumentType = this.DocumentType.find(x => x.value === event.target.value);
        if (selectedDocumentType) {
          this.legalData.vendorDocumentsInfo[index].documentTypeDesc = selectedDocumentType.displayName;
        }
      }
      if (iCount > 1) {

        this.legalData.vendorDocumentsInfo[index].documentType = '';
        event.target.value = '';
        this.notify.showWarning("The same document type has been selected. Please select someother document type");
        return false;
      }
      return true;
    })
  }

  RemoveLegalDocument(event: any, index: number) {
    this.legalData.legalDocumentsInfo.splice(index, 1);
  }

  RemoveVendorDocument(event: any, index: number) {
    this.legalData.vendorDocumentsInfo.splice(index, 1);
  }

  handleFileInput(fileInput: any, element: any) {
    if (fileInput.target.files && fileInput.target.files[0]) {
      // Size Filter Bytes
      const max_size = 20971520;
      const allowed_types = ['image/png', 'image/jpeg'];
      const max_height = 15200;
      const max_width = 25600;

      if (fileInput.target.files[0].size > max_size) {
        this.imageError =
          'Maximum size allowed is ' + max_size / 1000 + 'Mb';

        return false;
      }


      // if (!_.includes(allowed_types, fileInput.target.files[0].type)) {
      //     this.imageError = 'Only Images are allowed ( JPG | PNG )';
      //     return false;
      // }
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const image = new Image();
        image.src = e.target.result;

        // image.onload = rs => {
        //     const img_height = 100;
        //     const img_width = 120;



        //     if (img_height > max_height && img_width > max_width) {
        //         this.imageError =
        //             'Maximum dimentions allowed ' +
        //             max_height +
        //             '*' +
        //             max_width +
        //             'px';
        //         return false;
        //     } else {
        const imgBase64Path = e.target.result;
        // this.cardImageBase64 = imgBase64Path;
        // this.isImageSaved = true;

        // let imageUploadModelInfo = new ImageUploadModel;
        //  imageUploadModelInfo.Type ="legal";                 
        // var data = this.info.getItem('Legal_LanInfo');
        // imageUploadModelInfo.ApplicationNo = data.lan;
        // imageUploadModelInfo.ImageType = "NOC";
        // imageUploadModelInfo.ImageData =imgBase64Path; 
        // this.imageUploadModelList.push(this.imageUploadModel);

        if (this.caption === "Unassigned Queue") {
          if (this.legalData.legalDocumentsInfo.length !== -1) {
            this.legalData.legalDocumentsInfo.forEach((item, index) => {
              if (item.documentType === element) {
                this.legalData.legalDocumentsInfo[index].imageData = imgBase64Path.replace((imgBase64Path.substring(0, imgBase64Path.indexOf(",") + 1)), '');
                this.legalData.legalDocumentsInfo[index].doc_Source = 'Legal';
                this.legalData.legalDocumentsInfo[index].doc_SourceScreen = 'Legal';
                //this.legalData.legalDocumentsInfo[index].documentType=element;  
              }
            });
          }

        }


        if (this.caption === "Vendor Queries Queue") {
          if (this.legalData.vendorDocumentsInfo.length !== -1) {
            this.legalData.vendorDocumentsInfo.forEach((item, index) => {
              if (item.documentType === element) {
                this.legalData.vendorDocumentsInfo[index].imageData = imgBase64Path.replace((imgBase64Path.substring(0, imgBase64Path.indexOf(",") + 1)), '');
                this.legalData.vendorDocumentsInfo[index].doc_Source = 'Legal';
                this.legalData.vendorDocumentsInfo[index].doc_SourceScreen = 'Legal';
                //this.legalData.vendorDocumentsInfo[index].documentType=element;                           
              }
            });
          }
        }



        return true;
        // this.previewImagePath = imgBase64Path;
        //     }
        // };
      };

      reader.readAsDataURL(fileInput.target.files[0]);
      return true;
    }
    return false;
  }

  Validate() {

    let isFound: boolean = true;
    if (this.legalData.selectedLegalVendor === "Please select") {
      this.legalData.selectedLegalVendor = "";
    }

    if (!(common.IsRequired(this.legalData.selectedLegalVendor)) || this.legalData.selectedLegalVendor === "") {
      this.notify.showWarning("Please select the legal vendor ");
      isFound = false;
    }


    if (isFound) {
      this.legalData.legalDocumentsInfo.forEach((x) => {
        if (x.uuid === "" && x.uniqueId !== "old") {
          this.notify.showWarning("Please upload the document for the document type " + x.documentType);
          isFound = false;
        }
      })
    }

    if (isFound) {
      this.legalData.legalDocumentsInfo.forEach((x) => {
        if (x.uuid !== "" && x.uniqueId !== "old" && x.documentType === "") {
          this.notify.showWarning("Please select the document type " + x.documentType);
          isFound = false;
        }
      })
    }

    if (isFound) {
      this.legalData.legalDocumentsInfo.forEach((x) => {
        if (x.uuid !== "" && x.uniqueId !== "old" && x.documentType !== "" && x.remark === "") {
          this.notify.showWarning("Please specify the remark for the document type " + x.documentType);
          isFound = false;
        }
      })
    }

    if (isFound) {
      let docList = this.legalData.legalDocumentsInfo.find(x => x.documentType.includes("Title"))
      if (docList === undefined || docList === null) {
        this.notify.showWarning("Please upload the title document");
        isFound = false;
      }
    }



    if (isFound) {
      this.legalData.vendorDocumentsInfo.forEach((x) => {
        if (x.uuid === "" && x.uniqueId !== "old") {
          this.notify.showWarning("Please upload the document for the document type " + x.documentType);
          isFound = false;
        }
      })
    }

    if (isFound) {
      this.legalData.vendorDocumentsInfo.forEach((x) => {
        if (x.uuid !== "" && x.uniqueId !== "old" && x.documentType === "") {
          this.notify.showWarning("Please select the document type.");
          isFound = false;
        }
      })
    }

    if (isFound) {
      this.legalData.vendorDocumentsInfo.forEach((x) => {
        if (x.uuid !== "" && x.uniqueId !== "old" && x.documentType !== "" && x.remark === "") {
          this.notify.showWarning("Please specify the remark for the document type " + x.documentType);
          isFound = false;
        }
      })
    }

    if (isFound) {
      if (this.legalData.caseStatus === "Positive" || this.legalData.caseStatus === "Referred" || this.legalData.caseStatus === "Negative") {

        if (isFound && ((!this.legalData.property_OwnerName) || this.legalData.property_OwnerName === "")) {
          this.notify.showWarning("Please specify the Property Owner Name");
          isFound = false;
        }

        if (isFound && ((!this.legalData.property_Address) || this.legalData.property_Address === "")) {
          this.notify.showWarning("Please specify the Property Address / Schedule of property");
          isFound = false;
        }

        if (isFound && ((!this.legalData.property_Address) || this.legalData.property_Address === "")) {
          this.notify.showWarning("Please specify the Property Address / Schedule of property");
          isFound = false;
        }

        if (isFound && ((!this.legalData.chainFlow) || this.legalData.chainFlow === "")) {
          this.notify.showWarning("Please specify the Chain flow");
          isFound = false;
        }
        if (isFound && ((!this.legalData.boundaries_East) || this.legalData.boundaries_East === "")) {
          this.notify.showWarning("Please specify the East boundary");
          isFound = false;
        }

        if (isFound && ((!this.legalData.boundaries_West) || this.legalData.boundaries_West === "")) {
          this.notify.showWarning("Please specify the West boundary");
          isFound = false;
        }

        if (isFound && ((!this.legalData.boundaries_South) || this.legalData.boundaries_South === "")) {
          this.notify.showWarning("Please specify the South boundary");
          isFound = false;
        }
        if (isFound && ((!this.legalData.boundaries_North) || this.legalData.boundaries_North === "")) {
          this.notify.showWarning("Please specify the North boundary");
          isFound = false;
        }
        if (isFound && ((!this.legalData.credit_Remark) || this.legalData.credit_Remark === "")) {
          this.notify.showWarning("Please specify the credit remark");
          isFound = false;
        }
      }
    }

    if (this.legalData.legalDocumentsInfo.length >= -1 && this.legalData.vendorDocumentsInfo.length >= -1) {
      this.legalData.vendorDocumentsInfo.forEach((iItem, iIndex) => {
        let documentUploaded = this.legalData.legalDocumentsInfo.find(x => x.documentType === iItem.documentType)
        if (documentUploaded != null) {
          this.legalData.legalDocumentsInfo.forEach((item, index) => {
            if (item.documentType === iItem.documentType) {
              this.legalData.legalDocumentsInfo[index].uuid = "";
            }
          });
        }
      });
    }

    return isFound;
  }


  Submit1() {

    if (!this.Validate()) {
      return;
    }

    // let dataImageUpload = new ImageUploadModel();
    // let dataWithoutImageData = new ImageUploadWithoutImageDataModel();
    var legalDocuments = [];
    var vendorDocument = [];

    legalDocuments = this.legalData.legalDocumentsInfo.filter(x => x.uuid !== "" && x.uuid !== null);
    vendorDocument = this.legalData.vendorDocumentsInfo.filter(x => x.uuid !== "" && x.uuid !== null);
    legalDocuments.push(...vendorDocument);

    if (this.legalData.caseStatus === "Unassigned Cases") {
      this.legalData.caseStatus = "Inprogress with vendor";
      this.legalData.decision_Legal = "New";
    }

    if (this.legalData.caseStatus === "Legal vendor queries") {
      this.legalData.caseStatus = "Inprogress with vendor";
    }

    if (this.legalData.caseStatus === "Positive" || this.legalData.caseStatus === "Referred" || this.legalData.caseStatus === "Negative") {
      this.legalData.caseStatus = "Completed";
    }

    // const requestsArray = legalDocuments.map((x, idx) => {
    //   let dataImageUpload = new ImageUploadModel();
    //   let dataWithoutImageData = new ImageUploadWithoutImageDataModel();
    //   dataImageUpload.ApplicationNo= this.legalData.lan;
    //   dataImageUpload.FLO_Id="23";
    //   dataImageUpload.GL_Latitude="2";
    //   dataImageUpload.GL_Longitude="2";
    //   dataImageUpload.ImageType= x.documentType;
    //   dataImageUpload.ImageData= x.imageData;
    //   dataImageUpload.LeadID="2";
    //   dataImageUpload.Type="Legal";
    //   dataImageUpload.LoanAccountNumber=this.legalData.lan;
    //   dataImageUpload.DocTypeDescription='';
    //   dataImageUpload.ImageMIMEType='';
    //   dataImageUpload.Extension='';
    //   dataImageUpload.ModuleName='';
    //   dataImageUpload.Name='';
    //   dataImageUpload.BankDetailID='';



    //   dataWithoutImageData.ApplicationNo= this.legalData.lan;
    //   dataWithoutImageData.FLO_Id="23";
    //   dataWithoutImageData.GL_Latitude="2";
    //   dataWithoutImageData.GL_Longitude="2";
    //   dataWithoutImageData.ImageType= x.documentType;
    //   dataWithoutImageData.ImageData= '';
    //   dataWithoutImageData.LeadID="2";
    //   dataWithoutImageData.Type="Legal";
    //   dataWithoutImageData.LoanAccountNumber=this.legalData.lan;
    //   dataWithoutImageData.DocTypeDescription='';
    //   dataWithoutImageData.ImageMIMEType='';
    //   dataWithoutImageData.Extension='';
    //   dataWithoutImageData.ModuleName='';
    //   dataWithoutImageData.Name='';
    //   dataWithoutImageData.BankDetailID='';


    //   return this.http.httpPostWithouImageData<any>(dataImageUpload,'LAP_SaveImageUPL',dataWithoutImageData);

    // });

    //   this.legalData.legalDocumentsInfo.map((x, idx) => {
    //     x.imageData="";
    // });

    // this.legalData.vendorDocumentsInfo.map((x, idx) => {
    //   x.imageData="";
    // });


    // const anotherRequest = this.http.httpPost<ISubmitLegalAPI>((this.legalData), "LAP_SubmitLegalCaseDtl");

    // forkJoin([...requestsArray, anotherRequest]).subscribe(() => {
    //     this.notify.showSuccess("Saved Successfully","Legal");
    //     if(this.legalData.caseStatus==="Unassigned Queue" || this.legalData.caseStatus==="Legal vendor queries" || this.legalData.caseStatus==="Inprogress with vendor"){
    //       this.isEdit=false;
    //     }
    //     this.route.navigateByUrl("/legalcheck");
    // });

    this.http.httpPost(this.legalData, 'LAP_SubmitLegalCaseDtl').subscribe((res: any) => {

      if (res.errorcode !== "200")
        this.notify.showError(res.errorDescription, "Legal");
      else {
        this.notify.showSuccess("Saved Successfully", "Legal");

        this.legalApproveRejectFields = false;
        if (this.legalData.caseStatus === "Unassigned Queue" || this.legalData.caseStatus === "Legal vendor queries" || this.legalData.caseStatus === "Inprogress with vendor") {
          this.isEdit = false;
          this.vendorUploadEnable = false;
          this.isHideAddMore = true;
          this.getVendorName();
        }
        this.route.navigateByUrl("/legalcheck");
      }
    })

  }

  getVendorName() {
    if ((this.legalData.selectedLegalVendor) && this.legalData.selectedLegalVendor !== "") {
      let selectedVendoName = this.VendorData.find(x => x.value === this.legalData.selectedLegalVendor)
      this.vendorName = selectedVendoName?.displayName;
    }
  }

  Submit() {



    if (this.legalData.legalDocumentsInfo != undefined && this.legalData.legalDocumentsInfo.length != -1) {
      let dataImageUpload = new ImageUploadModel();
      let dataWithoutImageData = new ImageUploadWithoutImageDataModel();
      let uploadDocument = [];



      this.legalData.legalDocumentsInfo.forEach((item, array) => {

        dataImageUpload.ApplicationNo = this.legalData.lan;
        dataImageUpload.FLO_Id = "23";
        dataImageUpload.GL_Latitude = "2";
        dataImageUpload.GL_Longitude = "2";
        dataImageUpload.ImageType = item.documentType;
        dataImageUpload.ImageData = item.imageData;
        dataWithoutImageData.LoanAccountNumber = this.legalData.lan;
        dataWithoutImageData.DocTypeDescription = "";
        dataWithoutImageData.ImageMIMEType = "";
        dataWithoutImageData.Extension = "";
        dataWithoutImageData.ModuleName = "";
        dataWithoutImageData.Name = "";
        dataWithoutImageData.BankDetailID = "";
        dataImageUpload.LeadID = "2";
        dataImageUpload.Type = "Legal";

        dataWithoutImageData.ApplicationNo = this.legalData.lan;
        dataWithoutImageData.FLO_Id = "23";
        dataWithoutImageData.GL_Latitude = "2";
        dataWithoutImageData.GL_Longitude = "2";
        dataWithoutImageData.ImageType = item.documentType;
        dataWithoutImageData.ImageData = "";
        dataWithoutImageData.LoanAccountNumber = this.legalData.lan;
        dataWithoutImageData.DocTypeDescription = "";
        dataWithoutImageData.ImageMIMEType = "";
        dataWithoutImageData.Extension = "";
        dataWithoutImageData.ModuleName = "";
        dataWithoutImageData.Name = "";
        dataWithoutImageData.BankDetailID = "";
        dataWithoutImageData.LeadID = "2";
        dataWithoutImageData.Type = "Legal";

        if (item.imageData !== "") {
          this.http.httpPostWithouImageData<IResSaveImageUPL>((dataImageUpload), 'LAP_SaveImageUPL', dataWithoutImageData).subscribe((res: IResSaveImageUPL) => {
            if (res.Errorcode === "0") {
              this.legalData.legalDocumentsInfo[array].uuid = res.UniqueID;
              this.legalData.legalDocumentsInfo[array].imageData = "";
            }
          })
        }
      });
    }

    if (this.legalData.vendorDocumentsInfo != undefined && this.legalData.vendorDocumentsInfo.length != -1) {
      let dataImageUpload = new ImageUploadModel();
      let dataWithoutImageData = new ImageUploadWithoutImageDataModel();
      this.legalData.vendorDocumentsInfo.forEach((item, array) => {
        dataImageUpload.ApplicationNo = this.legalData.lan;
        dataImageUpload.FLO_Id = "";
        dataImageUpload.GL_Latitude = "";
        dataImageUpload.GL_Longitude = "";
        dataImageUpload.ImageType = item.documentType;
        dataImageUpload.ImageData = item.imageData;
        dataImageUpload.LeadID = "";
        dataImageUpload.Type = "Legal";

        dataWithoutImageData.ApplicationNo = this.legalData.lan;
        dataWithoutImageData.FLO_Id = "";
        dataWithoutImageData.GL_Latitude = "";
        dataWithoutImageData.GL_Longitude = "";
        dataWithoutImageData.ImageType = item.documentType;
        //dataWithoutImageData.ImageData= item.imageData;
        dataWithoutImageData.LeadID = "";
        dataWithoutImageData.Type = "Legal";

        //  const requestsArray = this.legalData.vendorDocumentsInfo.map((x, idx) => {

        //       dataImageUpload.ApplicationNo= this.legalData.lan;
        //       dataImageUpload.FLO_Id="";
        //       dataImageUpload.GL_Latitude="";
        //       dataImageUpload.GL_Longitude="";
        //       dataImageUpload.ImageType= x.documentType;
        //       dataImageUpload.ImageData= x.imageData;
        //       dataImageUpload.LeadID="";
        //       dataImageUpload.Type="Legal";

        //       dataWithoutImageData.ApplicationNo= this.legalData.lan;
        //       dataWithoutImageData.FLO_Id="";
        //       dataWithoutImageData.GL_Latitude="";
        //       dataWithoutImageData.GL_Longitude="";
        //       dataWithoutImageData.ImageType= x.documentType;
        //       //dataWithoutImageData.ImageData= item.imageData;
        //       dataWithoutImageData.LeadID="";
        //       dataWithoutImageData.Type="Legal";


        //       return this.http.httpPostWithouImageData(dataImageUpload,'MFI_LAP_SaveImageUPL',dataWithoutImageData);
        //   });

        //   const anotherRequest = this.http.httpPostWithouImageData(dataImageUpload,'MFI_LAP_SaveImageUPL',dataWithoutImageData);

        //   forkJoin([...requestsArray, anotherRequest]).subscribe(results => {
        //   });

        if (item.imageData != "") {
          this.http.httpPostWithouImageData<IResSaveImageUPL>((dataImageUpload), 'LAP_SaveImageUPL', dataWithoutImageData).subscribe((res: IResSaveImageUPL) => {
            if (res.Errorcode === "0") {
              this.legalData.vendorDocumentsInfo[array].uuid = res.UniqueID;
              this.legalData.vendorDocumentsInfo[array].imageData = "";
            }
          })
        }
      });
    }

    setTimeout(() => {                           // <<<---using ()=> syntax
      this.submitInterval = this.http.httpPost<ISubmitLegalAPI>((this.legalData), "LAP_SubmitLegalCaseDtl").subscribe((res: ISubmitLegalAPI) => {
        if (res.errorcode === "200") {
        }
      });
    }, 5000);
  }



  Download(uuid: any) {

    var data = {
      UUID: uuid
    }

    this.http.httpPost<IDownloadDocument>((data), 'LAP_DownloadDocument').subscribe((res: IDownloadDocument) => {

      if (res.imageData != "") {
        const downloadLink = document.createElement('a');
        const fileName = uuid + ".jpeg";

        downloadLink.href = res.imageData;
        downloadLink.download = fileName;
        downloadLink.click();
      }

    })
  }



  Reply(documentType: any) {

  }


}


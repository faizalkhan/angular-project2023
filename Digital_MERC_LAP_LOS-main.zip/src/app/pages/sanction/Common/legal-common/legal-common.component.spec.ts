import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LegalCommonComponent } from './legal-common.component';

describe('LegalCommonComponent', () => {
  let component: LegalCommonComponent;
  let fixture: ComponentFixture<LegalCommonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LegalCommonComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LegalCommonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

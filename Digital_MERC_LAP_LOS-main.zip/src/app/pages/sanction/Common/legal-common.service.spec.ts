import { TestBed } from '@angular/core/testing';

import { LegalCommonService } from './legal-common.service';

describe('LegalCommonServiceService', () => {
  let service: LegalCommonService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LegalCommonService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

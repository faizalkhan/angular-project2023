import { DatePipe } from "@angular/common";
import { Component, OnDestroy, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { Subscription } from "rxjs";
import { InfoServices } from "src/app/Injectable/info.services";
import { NotificationService } from "src/app/notification.service";
import { headerModel } from "src/app/shared/models/common/header-table";
import { ISanctionDashboardModel, SanctionDashboardModel } from "src/app/shared/models/sanction/dashboard";
import { ISearch } from "src/app/shared/models/sanction/search/search";
import { ConfigService } from "src/app/shared/services/common/http.services";
import { SanctionService } from "src/app/shared/services/sanction/sanction.service";
import { SearchService } from "src/app/shared/services/search/search.service";

@Component({
    selector: "app-sanctiondash",
    templateUrl: "./sanctiondash.component.html",
    styleUrls: ["./sanctiondash.component.css"],
    providers: [ConfigService, DatePipe]
})
export class SanctionDashComponent implements OnInit, OnDestroy {
    title: any = "Credit Sanction Dashboard"
    subcriptions!: Subscription;
    constructor(private http: ConfigService,
        private Info: InfoServices, private route: Router,
        private _searchService: SearchService,
        private _datePipe: DatePipe,
        private notify: NotificationService,
        private sanctionService: SanctionService) {

    }
    ngOnDestroy(): void {
        this.subcriptions.unsubscribe();
    }

    public get Data(): SanctionDashboardModel[] {
        return this.sanctionService.dashBoard;
    }

    public get Header(): headerModel[] {
        return [
            new headerModel('lan', 'LAN No.'),
            new headerModel('applicantName', 'Applicant Name'),
            new headerModel('sanctionStatus', 'Sanction Status'),
            new headerModel('rcuStatus', 'RCU Status'),
            new headerModel('legalStatus', 'Legal Evaluation Status'),
            new headerModel('technicalStatus', 'Technical Evaluation Status')
        ]
    }


    ngOnInit(): void {
        this.sanctionService.LanInfo = {} as SanctionDashboardModel;
        this.subcriptions = this._searchService.SearchData.subscribe((res: ISearch) => {
            this.sanctionService.GetLAPLOSCreditDasboard(res.toJson());
        })
    }

    row_click(event: ISanctionDashboardModel): void {
        let self = this;
        let callBackFN = () => {
            self.route.navigate(['/home']);
        }
        this.sanctionService.LanInfo = event;
        this.sanctionService.getDocumentCheck(callBackFN);

    }



}


import { Component, OnInit } from "@angular/core";
import { InfoServices } from "src/app/Injectable/info.services";
import { NotificationService } from "src/app/notification.service";
import { IDropdown } from "src/app/shared/models/common/control.model";
import { ISanctionDashboardModel, SanctionDashboardModel } from "src/app/shared/models/sanction/dashboard";
import { ConfigService } from "src/app/shared/services/common/http.services";
import { IModalCommon, ModalCommon, ModalService } from "src/app/shared/services/modal/modal.service";
import { ILoanDetails, IPersonalDetail, LoanDetails, PersonalDetail } from "./personaldetail.service";
import { saveAs } from 'file-saver';
import { SanctionService } from "src/app/shared/services/sanction/sanction.service";
import { EditSaveBtnGrpService } from "../../layout/button/edit-save-btn-grp/edit-save-btn-grp.service";
import { common } from "src/app/shared/models/common";
import { masterModuleDropdown } from "src/app/shared/models/sanction/masterDropdown";
@Component({
    selector: 'ltfs-personaldetail',
    templateUrl: './personaldetail.component.html',
    styleUrls: ['./personaldetail.component.css']
})
export class PersonalDetailComponent implements OnInit {

    documentId: any = "76151426"
    private _loanInfo: ILoanDetails = new LoanDetails();
    public get loanInfo(): ILoanDetails {
        return this._loanInfo;
    }
    public set loanInfo(value: ILoanDetails) {
        this._loanInfo = value;
    }
    PersonalisEdit: boolean = false;
    loanisEdit: boolean = false;
    isapplicantShow: boolean = false;
    isCoapplicantShow: boolean = false;
    ishousePhotoShow: boolean = false;
    CustomerType: IDropdown[] = masterModuleDropdown.CustomerType;
    PropertyType: IDropdown[] = masterModuleDropdown.PDPropertyType;
    private _termType: IDropdown[] = [];
    public get TermType(): IDropdown[] {
        return this._termType;
    }
    public set TermType(value: IDropdown[]) {
        this._termType = value;
    }
    LoanDetailsGroup: ILoanDetails[] = [];
    panelOpenState: boolean = false;
    _requestData: ISanctionDashboardModel = new SanctionDashboardModel();
    public get requestData(): any {
        return {
            "LoanApplicationNo": this._requestData.lan,
            "LeadID": this._requestData.leadId,
            "AssociateID": this._requestData.flopsid,
            "McCode": this._requestData.mcCode,
            "LoanAccountNumber": this._requestData.lan,

        };

    }
    public set requestData(value: ISanctionDashboardModel) {
        this._requestData = value;
    }
    ngOnInit(): void {

        this.requestData = this.info.LanInfo;
        this.GetPersonalDetails();
    }

    downloadFile(data: any, ctype: string, filename: string) {
        let response = this.base64ToArrayBuffer(data);
        const a = document.createElement('a')
        const blob = new Blob([response], { type: ctype });
        const url = window.URL.createObjectURL(blob);
        a.href = url
        a.download = filename;
        a.click();
        URL.revokeObjectURL(url);

    }
    base64ToArrayBuffer(base64: any): ArrayBuffer {
        var binary_string = window.atob(base64);
        var len = binary_string.length;
        var bytes = new Uint8Array(len);
        for (var i = 0; i < len; i++) {
            bytes[i] = binary_string.charCodeAt(i);
        }
        return bytes.buffer;
    }

    DownloadApplicantPhoto(data: any, filename: string) {
        saveAs.saveAs(data, `${filename}_${new Date().valueOf()}.jpeg`);
    }
    constructor(private http: ConfigService,
        private info: SanctionService,
        private notification: NotificationService,
        private modal: ModalService
    ) {

    }

    GetPersonalDetails() {
        this.http.httpPost<LoanDetails>(this.requestData, 'LAP_GetPersonalDeatils').subscribe((res: LoanDetails) => {
            if (res.errorcode == "0") {
                this.notification.showSuccess(res.errorDescription, "Personal")
                this.loanInfo = new LoanDetails(res);
                this.TermType = common.getTermType(this.loanInfo.appliedAmount);
            }
        })


    }
    getClass(data: IPersonalDetail) {
        return data.type == 'applicant' ? 'col-12' : 'col-6';
    }
    showModal(e: any) {
        let data = new ModalCommon({
            message: `<div class="w-100 text-center"> <img class="img-thumbnail" src="data:image/jpg;base64,${e}" /> </div>`,
            title: "Photo"
        } as IModalCommon);


        this.modal.ShowModal(data);
    }
    getTermType() {
        this.TermType = common.getTermType(this.loanInfo.appliedAmount);
    }
    Validate() {
        if (!this.loanInfo.appliedAmount || Number(this.loanInfo.appliedAmount) == 0) {
            this.notification.showWarning("Loan applied amount is required");
            return false;
        }
        else if (!this.loanInfo.term || Number(this.loanInfo.term) == 0) {
            this.notification.showWarning("Tenure(In Months)  is required");
            return false;
        }
        else if (this.loanInfo.appliedAmount < 100000) {
            this.notification.showWarning("Loan applied amount is requires");
            return false;
        }
        else if (this.loanInfo.appliedAmount > 1000000) {
            this.notification.showWarning("Loan applied amount cannot be greater than 10 lakhs");
            return false;
        }
        else {
            return true;
        }
    }
    SavePersonal(event: any) {
        if (this.Validate()) {
            this.loanisEdit = !this.loanisEdit;
        }
    }
    PersonalSubmit() {
        this.loanInfo.loanAccountNumber = this.info.LanInfo.lan;
        this.loanInfo.loanApplicationNo = this.info.LanInfo.lan;
        this.loanInfo.associateId = this.info.LanInfo.flopsid;
        this.loanInfo.leadId = this.info.LanInfo.leadId;
        this.loanInfo.mcCode = this.info.LanInfo.mcCode;
        this.http.httpPostWithouImageData(this.loanInfo.toJson(), 'LAP_SubmitPersonalDeatils', this.loanInfo.toJsonWithOutImage()).subscribe((res: any) => {
            if (res.errorcode == "0" || res.errorcode == "01") {
                this.notification.showSuccess(res.errorDescription);
            }
            else {
                this.notification.showError(res.errorDescription);
            }
        })

    }

    edit(event: any) {
        this.loanisEdit = event;

    }
    loanedit() {
        this.loanisEdit = !this.loanisEdit;
    }
    Cancel(event: any) {
        this.loanInfo = new LoanDetails(event);
        this.loanisEdit = !this.loanisEdit;
    }
}
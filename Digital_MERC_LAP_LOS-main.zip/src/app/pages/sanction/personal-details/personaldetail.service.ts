import { common } from "src/app/shared/models/common";

export interface IPersonalDetail {
  photo: any;
  applicationNo: any;
  applicantName: any;
  financial_status: any;
  mobileno: any;
  leadStatusId: any;
  salary_Status: any;
  type: any;
  rel_with_applicant: any;
  OnChange(event: any, data: any): void;
}

export class PersonalDetail implements IPersonalDetail {
  _photo: any = "";
  public get photo(): any {
    return this._photo;
  }
  public set photo(value: any) {
    this._photo = value;
  }
  _applicationNo: any = "";
  public get applicationNo(): any {
    return this._applicationNo;
  }
  public set applicationNo(value: any) {
    this._applicationNo = value;
  }
  _applicantName: any = "";
  public get applicantName(): any {
    return this._applicantName;
  }
  public set applicantName(value: any) {
    this._applicantName = value;
  }
  _financial_status: any = "";
  public get financial_status(): any {
    return this._financial_status;
  }
  public set financial_status(value: any) {
    this._financial_status = value;
  }
  _mobileno: any = "";
  public get mobileno(): any {
    return this._mobileno;
  }
  public set mobileno(value: any) {
    this._mobileno = value;
  }
  _leadStatusId: any = "";
  public get leadStatusId(): any {
    return this._leadStatusId;
  }
  public set leadStatusId(value: any) {
    this._leadStatusId = value;
  }
  _salary_Status: any = "";
  public get salary_Status(): any {
    return this._salary_Status != "" ? this._salary_Status : "Non financial";
  }
  public set salary_Status(value: any) {
    this._salary_Status = value;
  }
  _type: any = "";
  public get type(): any {
    return this._type;
  }
  public set type(value: any) {
    this._type = value;
  }
  _rel_with_applicant: any = "";
  public get rel_with_applicant(): any {
    return this._rel_with_applicant;
  }
  public set rel_with_applicant(value: any) {
    this._rel_with_applicant = value;
  }


  constructor(params?: IPersonalDetail) {
    if (params) {
      common.ObjectMapping(params, this)
    }
  }

  public OnChange(event: any, data: any) {
    data = event;
  }


}

export interface ILoanDetails {
  applicantImgMimeType: any;
  applicantImgExt: any;
  coAppImgMimeType: any;
  coAppImgExt: any;
  houseImgMimeType: any;
  houseImgExt: any;
  gL_Latitude: any;
  gL_Longitude: any;
  secondCoApplicantPhoto: any;
  secondCoAppImgMimeType: any;
  secondCoAppImgExt: any;
  thirdCoApplicantPhoto: any;
  thirdCoAppImgMimeType: any;
  thirdCoAppImgExt: any;
  fourthCoApplicantPhoto: any;
  fourthCoAppImgMimeType: any;
  fourthCoAppImgExt: any;
  associateId: any;
  mcCode: any;
  loanApplicationNo: any;
  leadId: any;
  term: any;
  ROI: number;
  monthlyEMI: any;
  appliedAmount: any;
  propertyType: any;
  applicantPhoto: any;
  coApplicantPhoto: any;
  housePhoto: any;

  smartPhoneAvailable: any;
  smartPhoneAvailable_YN: boolean;
  debitCardAndPinAvailable: any;
  debitCardAndPinAvailable_YN: boolean;
  netbankingAndIDPassword: any;
  netbankingAndIDPassword_YN: any;
  liveMobileNoWithBankAcc: any;
  liveMobileNoWithBankAcc_YN: boolean;
  aadharNumberLinkWithLiveBankAcc: any;
  aadharNumberLinkWithLiveBankAcc_YN: boolean;
  mobileNumRegWithAadharNumberIsLive: any;
  mobileNumRegWithAadharNumberIsLive_YN: boolean;
  detailList: IPersonalDetail[];
  errorcode: string;
  errorDescription: string;
  loanAccountNumber: any;
  emiCalc(): void;
  toJson(): any;
  toJsonWithOutImage(): any;
}

export class LoanDetails implements ILoanDetails {
  private _term: any = "";
  public get term(): any {
    return this._term;
  }
  public set term(value: any) {
    if (value != "") {
      this._term = value;
      this.emiCalc();
    }
  }
  _applicantImgMimeType: any;
  public get applicantImgMimeType(): any {
    return this._applicantImgMimeType;
  }
  public set applicantImgMimeType(value: any) {
    this._applicantImgMimeType = value;
  }
  _applicantImgExt: any;
  public get applicantImgExt(): any {
    return this._applicantImgExt;
  }
  public set applicantImgExt(value: any) {
    this._applicantImgExt = value;
  }
  _coAppImgMimeType: any;
  public get coAppImgMimeType(): any {
    return this._coAppImgMimeType;
  }
  public set coAppImgMimeType(value: any) {
    this._coAppImgMimeType = value;
  }
  _coAppImgExt: any;
  public get coAppImgExt(): any {
    return this._coAppImgExt;
  }
  public set coAppImgExt(value: any) {
    this._coAppImgExt = value;
  }
  _houseImgMimeType: any;
  public get houseImgMimeType(): any {
    return this._houseImgMimeType;
  }
  public set houseImgMimeType(value: any) {
    this._houseImgMimeType = value;
  }
  _houseImgExt: any;
  public get houseImgExt(): any {
    return this._houseImgExt;
  }
  public set houseImgExt(value: any) {
    this._houseImgExt = value;
  }
  _gL_Latitude: any;
  public get gL_Latitude(): any {
    return this._gL_Latitude;
  }
  public set gL_Latitude(value: any) {
    this._gL_Latitude = value;
  }
  _gL_Longitude: any;
  public get gL_Longitude(): any {
    return this._gL_Longitude;
  }
  public set gL_Longitude(value: any) {
    this._gL_Longitude = value;
  }
  _secondCoApplicantPhoto: any = "";
  public get secondCoApplicantPhoto(): any {
    return this._secondCoApplicantPhoto;
  }
  public set secondCoApplicantPhoto(value: any) {
    this._secondCoApplicantPhoto = value;
  }
  _secondCoAppImgMimeType: any;
  public get secondCoAppImgMimeType(): any {
    return this._secondCoAppImgMimeType;
  }
  public set secondCoAppImgMimeType(value: any) {
    this._secondCoAppImgMimeType = value;
  }
  _secondCoAppImgExt: any;
  public get secondCoAppImgExt(): any {
    return this._secondCoAppImgExt;
  }
  public set secondCoAppImgExt(value: any) {
    this._secondCoAppImgExt = value;
  }
  _thirdCoApplicantPhoto: string = "";
  public get thirdCoApplicantPhoto(): any {
    return this._thirdCoApplicantPhoto;
  }
  public set thirdCoApplicantPhoto(value: any) {
    this._thirdCoApplicantPhoto = value;
  }
  _thirdCoAppImgMimeType: any;
  public get thirdCoAppImgMimeType(): any {
    return this._thirdCoAppImgMimeType;
  }
  public set thirdCoAppImgMimeType(value: any) {
    this._thirdCoAppImgMimeType = value;
  }
  _thirdCoAppImgExt: any;
  public get thirdCoAppImgExt(): any {
    return this._thirdCoAppImgExt;
  }
  public set thirdCoAppImgExt(value: any) {
    this._thirdCoAppImgExt = value;
  }
  _fourthCoApplicantPhoto: any = "";
  public get fourthCoApplicantPhoto(): any {
    return this._fourthCoApplicantPhoto;
  }
  public set fourthCoApplicantPhoto(value: any) {
    this._fourthCoApplicantPhoto = value;
  }
  _fourthCoAppImgMimeType: any;
  public get fourthCoAppImgMimeType(): any {
    return this._fourthCoAppImgMimeType;
  }
  public set fourthCoAppImgMimeType(value: any) {
    this._fourthCoAppImgMimeType = value;
  }
  _fourthCoAppImgExt: any;
  public get fourthCoAppImgExt(): any {
    return this._fourthCoAppImgExt;
  }
  public set fourthCoAppImgExt(value: any) {
    this._fourthCoAppImgExt = value;
  }

  _monthlyEMI: any = "";
  public get monthlyEMI(): any {
    return this._monthlyEMI;
  }
  public set monthlyEMI(value: any) {
    this._monthlyEMI = value;
  }
  _appliedAmount: any = "";
  public get appliedAmount(): any {
    return this._appliedAmount;
  }
  public set appliedAmount(value: any) {
    if (value != "") {
      this._appliedAmount = value;
      this.term = undefined;
      this.monthlyEMI = "";

    }
  }
  _propertyType: any = "";
  public get propertyType(): any {
    return this._propertyType;
  }
  public set propertyType(value: any) {
    this._propertyType = value;
  }
  _applicantPhoto: any = "";
  public get applicantPhoto(): any {
    return this._applicantPhoto;
  }
  public set applicantPhoto(value: any) {
    this._applicantPhoto = value;
  }
  _coApplicantPhoto: any = "";
  public get coApplicantPhoto(): any {
    return this._coApplicantPhoto;
  }
  public set coApplicantPhoto(value: any) {
    this._coApplicantPhoto = value;
  }
  _housePhoto: any = "";
  public get housePhoto(): any {
    return this._housePhoto;
  }
  public set housePhoto(value: any) {
    this._housePhoto = value;
  }
  _smartPhoneAvailable: any = "";
  public get smartPhoneAvailable(): any {
    return this._smartPhoneAvailable;
  }
  public set smartPhoneAvailable(value: any) {
    this._smartPhoneAvailable = value;
    this.smartPhoneAvailable_YN = (value.toLowerCase().startsWith('y') ? true : false);
  }
  _debitCardAndPinAvailable: any = "";
  public get debitCardAndPinAvailable(): any {
    return this._debitCardAndPinAvailable;
  }
  public set debitCardAndPinAvailable(value: any) {
    this._debitCardAndPinAvailable = value;
    this.debitCardAndPinAvailable_YN = (value.toLowerCase().startsWith('y') ? true : false);
  }
  _netbankingAndIDPassword: any = "";
  public get netbankingAndIDPassword(): any {
    return this._netbankingAndIDPassword;
  }
  public set netbankingAndIDPassword(value: any) {
    this._netbankingAndIDPassword = value;
    this.netbankingAndIDPassword_YN = (value.toLowerCase().startsWith('y') ? true : false);
  }
  _liveMobileNoWithBankAcc: any = "";
  public get liveMobileNoWithBankAcc(): any {
    return this._liveMobileNoWithBankAcc;
  }
  public set liveMobileNoWithBankAcc(value: any) {
    this._liveMobileNoWithBankAcc = value;
    this.liveMobileNoWithBankAcc_YN = (value.toLowerCase().startsWith('y') ? true : false);
  }
  _aadharNumberLinkWithLiveBankAcc: any = "";
  public get aadharNumberLinkWithLiveBankAcc(): any {
    return this._aadharNumberLinkWithLiveBankAcc;
  }
  public set aadharNumberLinkWithLiveBankAcc(value: any) {
    this._aadharNumberLinkWithLiveBankAcc = value;
    this.aadharNumberLinkWithLiveBankAcc_YN = (value.toLowerCase().startsWith('y') ? true : false);
  }
  _mobileNumRegWithAadharNumberIsLive: any = "";
  public get mobileNumRegWithAadharNumberIsLive(): any {
    return this._mobileNumRegWithAadharNumberIsLive;
  }
  public set mobileNumRegWithAadharNumberIsLive(value: any) {
    this._mobileNumRegWithAadharNumberIsLive = value;
    this.mobileNumRegWithAadharNumberIsLive_YN = (value.toLowerCase().startsWith('y') ? true : false);
  }
  _detailList: IPersonalDetail[] = [new PersonalDetail()];
  public get detailList(): IPersonalDetail[] {
    return this._detailList;
  }
  public set detailList(value: IPersonalDetail[]) {
    this._detailList = value;
  }
  errorcode: string = "";
  errorDescription: string = "";

  constructor(params?: ILoanDetails) {

    if (params) {
      common.ObjectMapping(params, this);
      this.detailList = this.detailList.map((x, index) => {
        if (index == 0) {
          x.photo = this.applicantPhoto;
        }
        else if (index == 1) {
          x.photo = this.coApplicantPhoto;
        }
        else if (index == 2) {
          x.photo = this.secondCoApplicantPhoto;
        }
        else if (index == 3) {
          x.photo = this.thirdCoApplicantPhoto;
        }
        else if (index == 4) {
          x.photo = this.fourthCoApplicantPhoto;
        }
        return new PersonalDetail(x);
      });
      this.smartPhoneAvailable_YN = (this.smartPhoneAvailable.toLowerCase().startsWith('y') ? true : false);
      this.debitCardAndPinAvailable_YN = (this.debitCardAndPinAvailable.toLowerCase().startsWith('y') ? true : false);
      this.netbankingAndIDPassword_YN = (this.netbankingAndIDPassword.toLowerCase().startsWith('y') ? true : false);
      this.liveMobileNoWithBankAcc_YN = (this.liveMobileNoWithBankAcc.toLowerCase().startsWith('y') ? true : false);
      this.aadharNumberLinkWithLiveBankAcc_YN = (this.aadharNumberLinkWithLiveBankAcc.toLowerCase().startsWith('y') ? true : false);
      this.mobileNumRegWithAadharNumberIsLive_YN = (this.mobileNumRegWithAadharNumberIsLive.toLowerCase().startsWith('y') ? true : false);
    }
  }
  private _smartPhoneAvailable_YN: boolean = false;
  public get smartPhoneAvailable_YN(): boolean {
    return this._smartPhoneAvailable_YN;
  }
  public set smartPhoneAvailable_YN(value: boolean) {
    this._smartPhoneAvailable_YN = value;
  }
  private _debitCardAndPinAvailable_YN: boolean = false;
  public get debitCardAndPinAvailable_YN(): boolean {
    return this._debitCardAndPinAvailable_YN;
  }
  public set debitCardAndPinAvailable_YN(value: boolean) {
    this._debitCardAndPinAvailable_YN = value;
  }
  private _netbankingAndIDPassword_YN: any = false;
  public get netbankingAndIDPassword_YN(): any {
    return this._netbankingAndIDPassword_YN;
  }
  public set netbankingAndIDPassword_YN(value: any) {
    this._netbankingAndIDPassword_YN = value;
  }
  private _liveMobileNoWithBankAcc_YN: boolean = false;
  public get liveMobileNoWithBankAcc_YN(): boolean {
    return this._liveMobileNoWithBankAcc_YN;
  }
  public set liveMobileNoWithBankAcc_YN(value: boolean) {
    this._liveMobileNoWithBankAcc_YN = value;
  }
  private _aadharNumberLinkWithLiveBankAcc_YN: boolean = false;
  public get aadharNumberLinkWithLiveBankAcc_YN(): boolean {
    return this._aadharNumberLinkWithLiveBankAcc_YN;
  }
  public set aadharNumberLinkWithLiveBankAcc_YN(value: boolean) {
    this._aadharNumberLinkWithLiveBankAcc_YN = value;
  }
  private _mobileNumRegWithAadharNumberIsLive_YN: boolean = false;
  public get mobileNumRegWithAadharNumberIsLive_YN(): boolean {
    return this._mobileNumRegWithAadharNumberIsLive_YN;
  }
  public set mobileNumRegWithAadharNumberIsLive_YN(value: boolean) {
    this._mobileNumRegWithAadharNumberIsLive_YN = value;
  }
  _loanAccountNumber: any;
  public get loanAccountNumber(): any {
    return this._loanAccountNumber;
  }
  public set loanAccountNumber(value: any) {
    this._loanAccountNumber = value;
  }
  _associateId: any;
  public get associateId(): any {
    return this._associateId;
  }
  public set associateId(value: any) {
    this._associateId = value;
  }
  _mcCode: any;
  public get mcCode(): any {
    return this._mcCode;
  }
  public set mcCode(value: any) {
    this._mcCode = value;
  }
  _loanApplicationNo: any;
  public get loanApplicationNo(): any {
    return this._loanApplicationNo;
  }
  public set loanApplicationNo(value: any) {
    this._loanApplicationNo = value;
  }
  _leadId: any;
  public get leadId(): any {
    return this._leadId;
  }
  public set leadId(value: any) {
    this._leadId = value;
  }
  public get ROI(): number {
    if (this.appliedAmount <= 200000) {
      return 24;
    }
    else if (this.appliedAmount <= 500000) {
      return 22;
    }
    else if (this.appliedAmount <= 700000) {
      return 20;
    }
    else {
      return 18;
    }

  }


  emiCalc() {
    var inretestRate = this.ROI;
    inretestRate = (inretestRate / 100) / 12;

    this.monthlyEMI = Math.ceil(common.emiCalc(inretestRate, this.term, 0, 0, this.appliedAmount)).toFixed(2);
  }

  toJson() {
    return {
      "AssociateID": this.associateId,
      "MCCode": this.mcCode,
      "LoanApplicationNo": this.loanApplicationNo,
      "LeadId": this.leadId,
      "AppliedAmount": this.appliedAmount.toString(),
      "Tenure": this.term,
      "MonthlyEMI": this.monthlyEMI,
      "PropertyType": this.propertyType,
      "ApplicantPhoto": this.applicantPhoto == null ? "" : this.applicantPhoto,
      "ApplicantImgMimeType": this.applicantImgMimeType,
      "ApplicantImgExt": this.applicantImgExt,
      "CoApplicantPhoto": this.coApplicantPhoto == null ? "" : this.coApplicantPhoto,
      "CoAppImgMimeType": this.coAppImgMimeType,
      "CoAppImgExt": this.coAppImgExt,
      "HousePhoto": this.housePhoto == null ? "" : this.housePhoto,
      "HouseImgMimeType": this.houseImgMimeType,
      "HouseImgExt": this.houseImgExt,
      "GL_Latitude": this.gL_Latitude,
      "GL_Longitude": this.gL_Longitude,
      "smartPhoneAvailable": this.smartPhoneAvailable_YN ? 'Yes' : 'No',
      "DebitCardAndPinAvailable": this.debitCardAndPinAvailable_YN ? 'Yes' : 'No',
      "NetbankingAndIDPassword": this.netbankingAndIDPassword_YN ? 'Yes' : 'No',
      "LiveMobileNoWithBankAcc": this.liveMobileNoWithBankAcc_YN ? 'Yes' : 'No',
      "AadharNumberLinkWithLiveBankAcc": this.aadharNumberLinkWithLiveBankAcc_YN ? 'Yes' : 'No',
      "MobileNumRegWithAadharNumberIsLive": this.mobileNumRegWithAadharNumberIsLive_YN ? 'Yes' : 'No',
      "LoanAccountNumber": this.loanAccountNumber,
      "ApplicantNo": this.detailList[0]?.applicationNo,
      "CoApplicantNo": this.detailList[1]?.applicationNo,
      "SecondCoApplicantNo": this.detailList[2]?.applicationNo,
      "SecondCoApplicantPhoto": this.secondCoApplicantPhoto,
      "SecondCoAppImgMimeType": this.secondCoAppImgMimeType,
      "SecondCoAppImgExt": this.secondCoAppImgExt,
      "ThirdCoApplicantNo": this.detailList[3]?.applicationNo,
      "ThirdCoApplicantPhoto": this.thirdCoApplicantPhoto,
      "ThirdCoAppImgMimeType": this.thirdCoAppImgMimeType,
      "ThirdCoAppImgExt": this.thirdCoAppImgExt,
      "FourthCoApplicantNo": this.detailList[4]?.applicationNo,
      "FourthCoApplicantPhoto": this.fourthCoApplicantPhoto,
      "FourthCoAppImgMimeType": this.fourthCoAppImgMimeType,
      "FourthCoAppImgExt": this.fourthCoAppImgExt,
    };
  }
  toJsonWithOutImage() {
    return {
      "AssociateID": this.associateId,
      "MCCode": this.mcCode,
      "LoanApplicationNo": this.loanApplicationNo,
      "LeadId": this.leadId,
      "AppliedAmount": this.appliedAmount.toString(),
      "Tenure": this.term,
      "MonthlyEMI": this.monthlyEMI,
      "PropertyType": this.propertyType,
      "ApplicantImgMimeType": this.applicantImgMimeType,
      "ApplicantImgExt": this.applicantImgExt,
      "CoAppImgMimeType": this.coAppImgMimeType,
      "CoAppImgExt": this.coAppImgExt,
      "HouseImgMimeType": this.houseImgMimeType,
      "HouseImgExt": this.houseImgExt,
      "GL_Latitude": this.gL_Latitude,
      "GL_Longitude": this.gL_Longitude,
      "smartPhoneAvailable": this.smartPhoneAvailable,
      "DebitCardAndPinAvailable": this.debitCardAndPinAvailable,
      "NetbankingAndIDPassword": this.netbankingAndIDPassword,
      "LiveMobileNoWithBankAcc": this.liveMobileNoWithBankAcc,
      "AadharNumberLinkWithLiveBankAcc": this.aadharNumberLinkWithLiveBankAcc,
      "MobileNumRegWithAadharNumberIsLive": this.mobileNumRegWithAadharNumberIsLive,
      "LoanAccountNumber": this.loanAccountNumber,
      "ApplicantNo": this.detailList[0]?.applicationNo,
      "CoApplicantNo": this.detailList[1]?.applicationNo,
      "SecondCoApplicantNo": this.detailList[2]?.applicationNo,
      "SecondCoAppImgMimeType": this.secondCoAppImgMimeType,
      "SecondCoAppImgExt": this.secondCoAppImgExt,
      "ThirdCoApplicantNo": this.detailList[3]?.applicationNo,
      "ThirdCoAppImgMimeType": this.thirdCoAppImgMimeType,
      "ThirdCoAppImgExt": this.thirdCoAppImgExt,
      "FourthCoApplicantNo": this.detailList[4]?.applicationNo,
      "FourthCoAppImgMimeType": this.fourthCoAppImgMimeType,
      "FourthCoAppImgExt": this.fourthCoAppImgExt
    };
  }


}
import { Component } from '@angular/core';
import { ActivatedRoute } from "@angular/router";

@Component({ 
        selector: "app-stechnicalpage3",
        templateUrl: "./page3.component.html",
        styleUrls: ["./page3.component.css"]
     })
export class STechnicalPage3Component {
    applicationdetails = 
        {
            lannumber: 'ILAP345331', loanamount: '12121', loantype: 'Pending', addressoftheproperty: 'Approved', applicantname: 'Approved', vendorname: 'Approved',
            result:'test'     
        }

        audittrails = [
            { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
            { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
            { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
            { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
        ];
    }


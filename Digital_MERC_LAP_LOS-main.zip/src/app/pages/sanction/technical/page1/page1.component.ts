import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { InfoServices } from 'src/app/Injectable/info.services';

@Component({                   
        selector: "app-stechnicalpage1",
        templateUrl: "./page1.component.html",
        styleUrls: ["./page1.component.css"],
        providers:[ConfigService]
     })
export class STechnicalPage1Component implements OnInit {
    technicalRequestData:any;
   
    constructor(private http: ConfigService, private Info: InfoServices, private route: Router) {
        var data = this.Info.getItem('Technical_LanInfo');         
        
        if (data != '') {
            this.technicalRequestData = JSON.parse(data);
        }
        else {
            return;
        }
         
    }
    ngOnInit(): void {
      
    }
      
    
    }


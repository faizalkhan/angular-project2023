import { CustomRouteConfig } from "src/app/shared/models/common/route-config";
import { LegalVendorPageComponent } from "./legal-vendor-page/legal-vendor-page.component";
import { LegalVendordashboardsComponent } from "./legal-vendordashboards/legal-vendordashboards.component";

export const LegalModule = [LegalVendorPageComponent, LegalVendordashboardsComponent];

export const LegalRoute: CustomRouteConfig[] = [];

LegalRoute.push(new CustomRouteConfig({ menuName: "Legal Check", title: "Legal Check", path: "legalvendor", redirectTo: "/legalvendor", isActive: true }));

LegalRoute.push(new CustomRouteConfig({ path: "legalvendor", componentName: LegalVendordashboardsComponent, title: "Legal Check / Home", parentName: "Legal Check", menuName: "Home" }));
LegalRoute.push(new CustomRouteConfig({ path: "back", title: "Legal Check", parentName: "Legal Check", menuName: "Back", redirectTo: "/legalvendor" }));
LegalRoute.push(new CustomRouteConfig({ path: "legalvendorunassginedcases", componentName: LegalVendorPageComponent, title: "Legal Check / Legal Check", parentName: "Legal Check" }));
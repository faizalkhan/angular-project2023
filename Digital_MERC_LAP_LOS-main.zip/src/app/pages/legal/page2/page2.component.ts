import { Component } from '@angular/core';
import { ActivatedRoute } from "@angular/router";

@Component({ 
        selector: "app-legalpage2",
        templateUrl: "./page2.component.html",
        styleUrls: ["./page2.component.css"]
     })
export class LegalPage2Component {
    applicationDetails = 
        {
            lannumber: 'ILAP345331', appliedloanamount: 'Deepak Sahu', loadtype: 'Pending', addressoftheproperty: 'Approved',   
            applicantname:'test', geolocation: 'test'    
        }

        audittrails = [
            { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
            { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
            { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
            { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
        ];
        docrows: any = [{ remarks: '', addtionaldoc: '', filename: '' }]

        constructor() { }
        ngOnInit(): void {
            
        }
    
        addmore() {
            let row =  { remarks: '', addtionaldoc: '', filename: '' }
            this.docrows.push(row);
        }
    
    }



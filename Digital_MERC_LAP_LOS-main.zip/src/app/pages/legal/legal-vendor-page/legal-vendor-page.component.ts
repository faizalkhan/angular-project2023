import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InfoServices } from 'src/app/Injectable/info.services';
import { ConfigService } from 'src/app/shared/services/common/http.services';

@Component({
  selector: 'app-legal-vendor-page',
  templateUrl: './legal-vendor-page.component.html',
  styleUrls: ['./legal-vendor-page.component.css'],
  providers:[ConfigService]
})
export class LegalVendorPageComponent implements OnInit {

  legalRequestData:any;
   
  constructor(private http: ConfigService, private Info: InfoServices, private route: Router) {
      var data = this.Info.getItem('LegalVendor_LanInfo');         
      
      if (data != '') {
          this.legalRequestData = JSON.parse(data);
      }
      else {
          return;
      }
       
  }
  ngOnInit(): void {
    
  }
    


}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LegalVendorPageComponent } from './legal-vendor-page.component';

describe('LegalVendorPageComponent', () => {
  let component: LegalVendorPageComponent;
  let fixture: ComponentFixture<LegalVendorPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LegalVendorPageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LegalVendorPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

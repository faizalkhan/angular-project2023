import { Component } from '@angular/core';
import { ActivatedRoute } from "@angular/router";

@Component({ 
        selector: "app-legalpage1",
        templateUrl: "./page1.component.html",
        styleUrls: ["./page1.component.css"]
     })
export class LegalPage1Component {
    applicationDetails = 
        {
            lannumber: 'ILAP345331', appliedloanamount: 'Deepak Sahu', loadtype: 'Pending', addressoftheproperty: 'Approved',   
            applicantname:'test', geolocation: 'test'    
        }

        audittrails = [
            { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
            { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
            { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
            { chargedby: 'ACM2_Indore', chargedDate: '24-07-2022 8:15:00 (PM)', action: 'Deviation on Income Assessment' },
        ];
    }


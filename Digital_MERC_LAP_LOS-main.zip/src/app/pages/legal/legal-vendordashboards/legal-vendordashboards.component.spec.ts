import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LegalVendordashboardsComponent } from './legal-vendordashboards.component';

describe('LegalVendordashboardsComponent', () => {
  let component: LegalVendordashboardsComponent;
  let fixture: ComponentFixture<LegalVendordashboardsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LegalVendordashboardsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LegalVendordashboardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

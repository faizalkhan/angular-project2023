import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InfoServices } from 'src/app/Injectable/info.services';
import { IDropdown } from 'src/app/shared/models/common/control.model';
import { ILegalVendorDashboardResponseModel, ILegalVendorSearch, LegalVendorSearch } from 'src/app/shared/models/common/response.model';
import { LegalVendorDashboardModel } from 'src/app/shared/models/sanction/Legal/legalDashboard';
import { ISearch } from 'src/app/shared/models/sanction/search/search';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { SearchService } from 'src/app/shared/services/search/search.service';
import { MenuResponse } from '../../layout/login/login.service';

@Component({
  selector: 'app-legal-vendordashboards',
  templateUrl: './legal-vendordashboards.component.html',
  styleUrls: ['./legal-vendordashboards.component.css'],
  providers:[ConfigService]

})
export class LegalVendordashboardsComponent implements OnInit {
 
  param: any;
  ResponseData:any; 
  private _data: LegalVendordashboardsComponent[] = [];
  searchBy: IDropdown[] = [];   
  txtSearchValue:string='';
  fromDate:Date= new Date;
  toDate:Date=new Date;
  selectedValue:any='';
  selectedOption:string='';
  legalVendorSearch:LegalVendorSearch = new LegalVendorSearch();

  constructor(private http: ConfigService, private Info: InfoServices, private route: Router, 
    private _searchService: SearchService) {
       
  }

  public get Data(): any[] {
    return this._data;
  }
  public set Data(value: any[]) {
      this._data = value;
  }
  _userId:string='';

  ngOnInit(): void {
      this.GetSearchBy(); 

      var loggedInUserRole = JSON.parse(this.Info.getItem('menu')) as MenuResponse;
      //this.loggedInUserRoleId = loggedInUserRole.menuUserDetail.roleId; 
      this._userId=loggedInUserRole.menuUserDetail.userId;

      this._searchService.SearchData.subscribe((res: ISearch) => {
        //res.login_PS_ID=res.login_PS_ID; 
        this.legalVendorSearch.FromDate = res.fromDate;
        this.legalVendorSearch.toDate=res.toDate;
        this.legalVendorSearch.fieldName=res.fieldName;
        this.legalVendorSearch.role=loggedInUserRole.menuUserDetail.roleId;
        this.legalVendorSearch.fieldValue=res.fieldValue;      
        this.legalVendorSearch.login_PS_ID=this._userId;
        this.legalVendorSearch.selectedOption=this.selectedOption; 
        this.GetLAPLegalVendorDashboard(this.legalVendorSearch.toJson());
      });

      //this.GetLAPLegalVendorDashboard();
  }

 GetSearchBy(){
    this.searchBy =[
      { displayName: 'Select', selected: true, value: '' },
      { displayName: 'Branch', selected: false, value: 'test' } 
     ]
  }

  GetLAPLegalVendorDashboard(param:any){
    // this.param =  { 
    //     Login_PS_ID: "?20105989", 
    //     Role: "FLO",
    //     FromDate:new Date(),
    //     ToDate:new Date(),
    //     FieldName:"",
    //     FieldValue:""   
    // }

    this.http.httpPost<ILegalVendorDashboardResponseModel<LegalVendorDashboardModel[]>>(param, 'LAP_GetlLegalVendorDashboard').subscribe((res: ILegalVendorDashboardResponseModel<LegalVendorDashboardModel[]>) => {
        this.Data = res.vendorDashboardDetails;
    })
}

NavigateClick(item: any) {

    var data = {            
        "lan": item.lanid,
        "login_PS_ID": this._userId,
        "apiInvokeDateTime": "2022-09-15T05:03:52.964Z",
        "role": "FLO"
    }
    // var data = {
    //     "LoanAccountNumber": "123",
    //     "FLO_PsId": "23423",
    //     "CreatedON": "2022-08-04"
    // };
    this.Info.setItem('LegalVendor_LanInfo', JSON.stringify(data));
    
    
    switch (item.caseStatus) {
        case "New Cases": 
            this.Info.setItem('Screen_Type', "");
            this.route.navigateByUrl("/legalVendorunassginedcases");
            break;
        case "Referred": 
            this.Info.setItem('Screen_Type', "Refer Cases");
            this.route.navigateByUrl("/legalVendorunassginedcases");
            break;       
        default:             
            this.Info.setItem('Screen_Type', "");
            this.route.navigateByUrl("/legalVendorunassginedcases");
            break;
    }

  }

  onRadioChange(event:any,selectedItem:string){
      if(selectedItem==="NewCase"){
         this.selectedOption = event.currentTarget.checked ? "New" : "";
      }
      if(selectedItem==="SentBackCase"){
        this.selectedOption = event.currentTarget.checked ? "SentBack" : "";
     }

     if(this.selectedOption!=""){
      this.legalVendorSearch.selectedOption=this.selectedOption; 
      this.GetLAPLegalVendorDashboard(this.legalVendorSearch.toJson());
     }
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LayoutFormGroupComponent } from './layout-form-group.component';

describe('LayoutFormGroupComponent', () => {
  let component: LayoutFormGroupComponent;
  let fixture: ComponentFixture<LayoutFormGroupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LayoutFormGroupComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LayoutFormGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

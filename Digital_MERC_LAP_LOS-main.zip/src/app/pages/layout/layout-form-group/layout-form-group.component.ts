import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Observable } from 'rxjs';
import { formBase } from './form-group.model';


@Component({
  selector: 'app-formgroup',
  templateUrl: './layout-form-group.component.html'
})
export class LayoutFormGroupComponent  {
  
  @Input() question!: formBase<string>;
  @Input() form!: FormGroup;
  get isValid() { return  this.form.controls[this.question.key].valid; }


}
import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { of } from 'rxjs';
import { DropdownQuestion, formBase, TextboxQuestion } from './form-group.model';


@Injectable()
export class FormControlService {
  toFormGroup(questions: formBase<string>[]) {
    const group: any = {};

    questions.forEach(question => {
      let form: FormControl;
      let validate = question.required ? [Validators.required, ...question.Customevalidator.map(x => x.validate)] : [...question.Customevalidator.map(x => x.validate)];
      console.log(`${question.key}${validate.length}`);
      if (validate.length > 0) {
        form = new FormControl(question.value || '', [...validate]);
      }
      else
        form = question.required ? new FormControl(question.value || '', [Validators.required])
          : new FormControl(question.value || '');

      if (question.valueChange) {
        form.valueChanges.subscribe(res => {
          question.valueChange?.(res, form);
        })
      }
      form.updateValueAndValidity();
      group[question.key] = form;
    });


    return new FormGroup(group);
  }
}

import { AbstractControl, Validator, ValidatorFn } from "@angular/forms";

export class formBase<T> {
    value: T | undefined;
    key: string;
    label: string;
    required: boolean;
    order: number;
    controlType: string;
    type: string;
    options: { key: string, value: string }[];
    Customevalidator: Validator[] = [];
    valueChange: Function | undefined;
    constructor(options: {
        value?: T;
        key?: string;
        label?: string;
        required?: boolean;
        order?: number;
        controlType?: string;
        type?: string;
        options?: { key: string, value: string }[];
        Customevalidator?: Validator[];
        valueChange?: Function
    } = {}) {
        this.value = options.value;
        this.key = options.key || '';
        this.label = options.label || '';
        this.required = !!options.required;
        this.order = options.order === undefined ? 1 : options.order;
        this.controlType = options.controlType || '';
        this.type = options.type || '';
        this.options = options.options || [];
        this.Customevalidator = options.Customevalidator || [];
        this.valueChange = options.valueChange || undefined;
    }
}
export class TextboxQuestion extends formBase<string> {
    override controlType = 'textbox';
}
export class DropdownQuestion extends formBase<string> {
    override controlType = 'dropdown';
}
export class NumericWithDecimal extends formBase<Number> {
    override controlType = 'numericdecimal';
}
export class NumericOnly extends formBase<Number> {
    override controlType = 'numericonly';
}
export class Hidden extends formBase<Number> {
    override controlType = 'hidden';
}
export class TextArea extends formBase<string>
{
    override controlType = 'textarea';
}
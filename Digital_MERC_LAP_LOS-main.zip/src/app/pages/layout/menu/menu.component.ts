import { Component, EventEmitter, Input, NO_ERRORS_SCHEMA, OnInit, Output } from "@angular/core";
import { ActivatedRoute, NavigationEnd, Router } from "@angular/router";
import { filter } from "rxjs";
import { Menu } from "src/app/shared/models/common/menu.model";
import { MenuService } from "../header/menu-service.service";
import { SubMenuDetail } from "../login/login.service";

@Component({
    selector: "app-menu",
    templateUrl: "./menu.component.html",
    styleUrls: ["./menu.component.css"]
})

export class MenuComponent implements OnInit {
    @Input() menudata: Menu[] = [];
    @Input() isSubMenu: boolean = true;
    @Output() MenuEvent = new EventEmitter<Menu>();


    constructor(private route: Router, private menuService: MenuService) {

    }
    isExpanded = false;

    collapse() {
      this.isExpanded = false;
    }
  
    toggle() {
      this.isExpanded = !this.isExpanded;
    }
    ngOnInit(): void {
       
    }
    menuClick(value: Menu, event: any) {
        value.IsActive = true;
        this.MenuEvent.emit(value);
    }

    IsHeaderActive(item: Menu): boolean {
      return  this.menuService.HeaderIsActive(item);
    }
    IsSubActive(item: Menu): boolean {
        return  this.menuService.SubMenuIsActive(item);
      }

}
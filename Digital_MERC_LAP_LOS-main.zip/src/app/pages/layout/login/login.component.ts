import { Component, OnInit, Input } from "@angular/core";
import { Router } from "@angular/router";
import { InfoServices } from "src/app/Injectable/info.services";
import { NotificationService } from "src/app/notification.service";
import { ConfigService } from "src/app/shared/services/common/http.services";
import { MenuService } from "../header/menu-service.service";
import { MenuResponse } from "./login.service";



@Component(
    {
        selector: "app-login",
        templateUrl: "./login.component.html",
        styleUrls: ["./login.component.css"]
    }
)

export class LoginComponent implements OnInit {
    model: userModel = new userModel();
    public userRole: any;
    constructor(private router: Router,
        private _inforService: InfoServices,
        private http: ConfigService,
        private notify: NotificationService,
        private menuService: MenuService) {

    }
    ngOnInit(): void {
    }

    Login() {
        let data = {
            "userID": this.model.userName,
            "password": this.model.password
        };
        //let res = { "menuUserDetail": { "userId": "VEN04223", "roleId": "338", "sbuid": "45", "userName": "Satheesh", "company_Code": null, "email_Id": "satheeshthomas@ltfs.com" }, "menuStringDetail": [], "branchDetail": [{ "branch_ID": "-1", "branchName": "ALL My Scope" }], "sBUDetail": [], "subMenuDetail": [{ "menu_Id": "112", "subMenu_Id": "881", "subMenu_Desc": "Home", "menuLink": "/home", "priority_Order": 1 }, { "menu_Id": "116", "subMenu_Id": "894", "subMenu_Desc": "Home", "menuLink": "/dishome", "priority_Order": 1 }, { "menu_Id": "116", "subMenu_Id": "895", "subMenu_Desc": "Back", "menuLink": "/disback", "priority_Order": 2 }, { "menu_Id": "112", "subMenu_Id": "882", "subMenu_Desc": "Back to Dashboard", "menuLink": "/sanctiondash", "priority_Order": 2 }, { "menu_Id": "112", "subMenu_Id": "883", "subMenu_Desc": "Personal Details", "menuLink": "/perosnal", "priority_Order": 3 }, { "menu_Id": "116", "subMenu_Id": "896", "subMenu_Desc": "Pending For Action", "menuLink": "/dispendingforaction", "priority_Order": 3 }, { "menu_Id": "116", "subMenu_Id": "897", "subMenu_Desc": "RMC Documents", "menuLink": "/disrmcdocument", "priority_Order": 4 }, { "menu_Id": "112", "subMenu_Id": "884", "subMenu_Desc": "Business Details", "menuLink": "/business", "priority_Order": 4 }, { "menu_Id": "112", "subMenu_Id": "885", "subMenu_Desc": "Reference Details", "menuLink": "/reference", "priority_Order": 5 }, { "menu_Id": "112", "subMenu_Id": "886", "subMenu_Desc": "Household Assessment", "menuLink": "/householdassessment", "priority_Order": 6 }, { "menu_Id": "112", "subMenu_Id": "887", "subMenu_Desc": "Income Assessment", "menuLink": "/incomeassessment", "priority_Order": 7 }, { "menu_Id": "112", "subMenu_Id": "888", "subMenu_Desc": "Property Valuation", "menuLink": "/propertyvaluation\t", "priority_Order": 8 }, { "menu_Id": "112", "subMenu_Id": "889", "subMenu_Desc": "Banking Assessment", "menuLink": "/bankingassessment", "priority_Order": 9 }, { "menu_Id": "112", "subMenu_Id": "890", "subMenu_Desc": "Legal Check", "menuLink": "/legalcheck", "priority_Order": 10 }, { "menu_Id": "112", "subMenu_Id": "891", "subMenu_Desc": "Technical Check", "menuLink": "/technicalcheck", "priority_Order": 11 }, { "menu_Id": "112", "subMenu_Id": "892", "subMenu_Desc": "Income Eligibility", "menuLink": "/incomeeligibility", "priority_Order": 12 }, { "menu_Id": "112", "subMenu_Id": "893", "subMenu_Desc": "CAM Detail", "menuLink": "/camdetail", "priority_Order": 13 }], "parentMenuDetail": [{ "menu_Id": "112", "menu": "Credit Sanction", "parent_Id": "112", "order": 1 }, { "menu_Id": "116", "menu": "Disbursement Details", "parent_Id": "116", "order": 5 }], "resp": { "errorcode": "00", "errorDescription": "Logged in successful" }, "menuLinkDetails": [{ "menuId": "111", "menu": "Risk Control Unit", "menuLink": "/riskcontrolunitdash" }, { "menuId": "112", "menu": "Credit Sanction", "menuLink": "/sanctiondash" }, { "menuId": "113", "menu": "Legal-Vendor", "menuLink": "/legalvendor" }, { "menuId": "114", "menu": "Technical-Vendor", "menuLink": "/technicalvendor" }, { "menuId": "115", "menu": "Risk Control Unit", "menuLink": "/riskcontolunitdash" }, { "menuId": "116", "menu": "Disbursement Details", "menuLink": "/dishome" }] };
        //let res = { "menuUserDetail": {"userId":"VEN04223","roleId":"338","sbuid":"45","userName":"Satheesh","company_Code":null,"email_Id":"satheeshthomas@ltfs.com"},"menuStringDetail":[],"branchDetail":[{"branch_ID":"-1","branchName":"ALL My Scope"}],"sBUDetail":[],"subMenuDetail":[{"menu_Id":"112","subMenu_Id":"881","subMenu_Desc":"Home","menuLink":"/home","priority_Order":1},{"menu_Id":"115","subMenu_Id":"899","subMenu_Desc":"Dashboard","menuLink":"/riskcontolunitdash","priority_Order":1},{"menu_Id":"116","subMenu_Id":"894","subMenu_Desc":"Home","menuLink":"/dishome","priority_Order":1},{"menu_Id":"116","subMenu_Id":"895","subMenu_Desc":"Back","menuLink":"/disback","priority_Order":2},{"menu_Id":"115","subMenu_Id":"900","subMenu_Desc":"Pending for screening","menuLink":"/pendingscreen","priority_Order":2},{"menu_Id":"112","subMenu_Id":"882","subMenu_Desc":"Back to Dashboard","menuLink":"/sanctiondash","priority_Order":2},{"menu_Id":"112","subMenu_Id":"883","subMenu_Desc":"Personal Details","menuLink":"/perosnal","priority_Order":3},{"menu_Id":"115","subMenu_Id":"901","subMenu_Desc":"Pending for Sampling","menuLink":"/sampledcases","priority_Order":3},{"menu_Id":"116","subMenu_Id":"896","subMenu_Desc":"Pending For Action","menuLink":"/dispendingforaction","priority_Order":3},{"menu_Id":"116","subMenu_Id":"897","subMenu_Desc":"RMC Documents","menuLink":"/disrmcdocument","priority_Order":4},{"menu_Id":"115","subMenu_Id":"902","subMenu_Desc":"Closed cases","menuLink":"/closedcases","priority_Order":4},{"menu_Id":"112","subMenu_Id":"884","subMenu_Desc":"Business Details","menuLink":"/business","priority_Order":4},{"menu_Id":"112","subMenu_Id":"885","subMenu_Desc":"Reference Details","menuLink":"/reference","priority_Order":5},{"menu_Id":"115","subMenu_Id":"903","subMenu_Desc":"Reports","menuLink":"/rcureports","priority_Order":5},{"menu_Id":"115","subMenu_Id":"904","subMenu_Desc":"Risk Alert","menuLink":"/riskalertcases","priority_Order":6},{"menu_Id":"112","subMenu_Id":"886","subMenu_Desc":"Household Assessment","menuLink":"/householdassessment","priority_Order":6},{"menu_Id":"112","subMenu_Id":"887","subMenu_Desc":"Income Assessment","menuLink":"/incomeassessment","priority_Order":7},{"menu_Id":"112","subMenu_Id":"888","subMenu_Desc":"Property Valuation","menuLink":"/propertyvaluation\\t","priority_Order":8},{"menu_Id":"112","subMenu_Id":"889","subMenu_Desc":"Banking Assessment","menuLink":"/bankingassessment","priority_Order":9},{"menu_Id":"112","subMenu_Id":"890","subMenu_Desc":"Legal Check","menuLink":"/legalcheck","priority_Order":10},{"menu_Id":"112","subMenu_Id":"891","subMenu_Desc":"Technical Check","menuLink":"/technicalcheck","priority_Order":11},{"menu_Id":"112","subMenu_Id":"892","subMenu_Desc":"Income Eligibility","menuLink":"/incomeeligibility","priority_Order":12},{"menu_Id":"112","subMenu_Id":"893","subMenu_Desc":"CAM Detail","menuLink":"/camdetail","priority_Order":13}],"parentMenuDetail":[{"menu_Id":"112","menu":"Credit Sanction","parent_Id":"112","order":1},{"menu_Id":"115","menu":"Risk Control Unit","parent_Id":"115","order":4},{"menu_Id":"116","menu":"Disbursement Details","parent_Id":"116","order":5}],"resp":{"errorcode":"00","errorDescription":"Logged in successful"},"menuLinkDetails":[{"menuId":"111","menu":"Risk Control Unit","menuLink":"/riskcontrolunitdash"},{"menuId":"112","menu":"Credit Sanction","menuLink":"/sanctiondash"},{"menuId":"113","menu":"Legal-Vendor","menuLink":"/legalvendor"},{"menuId":"114","menu":"Technical-Vendor","menuLink":"/technicalvendor"},{"menuId":"115","menu":"Risk Control Unit","menuLink":"/riskcontolunitdash"},{"menuId":"116","menu":"Disbursement Details","menuLink":"/dishome"}],"roleDetails":[{"roleId":"338","roleName":"BCM"},{"roleId":"339","roleName":"ACM"},{"roleId":"340","roleName":"RCM"},{"roleId":"341","roleName":"ZCM"},{"roleId":"342","roleName":"ARM"},{"roleId":"343","roleName":"RRM-V"},{"roleId":"344","roleName":"RRM-I"},{"roleId":"345","roleName":"ZRM"},{"roleId":"346","roleName":"BSE"},{"roleId":"347","roleName":"RMBO"},{"roleId":"348","roleName":"HBO"},{"roleId":"349","roleName":"HCSBO"},{"roleId":"350","roleName":"FLO"},{"roleId":"351","roleName":"AM"},{"roleId":"352","roleName":"RM"},{"roleId":"353","roleName":"ZM"},{"roleId":"354","roleName":"HBD"}]}
        // this.menuService.localMenu = res;
        // this._inforService.setItem('menu', JSON.stringify(res));
        // this._inforService.setCookie('token', new Date().toDateString());
        // this._inforService.IsLogin(true);

        this.http.httpPost<MenuResponse>(data, "LAP_LOSAuthenticateUser").subscribe((res: MenuResponse) => {
            if (res.resp.errorcode == "00") {
                this.menuService.localMenu = res;
                this._inforService.setItem('menu', JSON.stringify(res));
                let userInfo = this.menuService.localMenu.menuUserDetail;
                userInfo.roleName = this.menuService.currentRole.roleName;
                this._inforService.setItem("userInfo", JSON.stringify(userInfo));
                this._inforService.setCookie('token', new Date().toDateString());
                this._inforService.IsLogin(true);
            }
            else {
                this.notify.showError(res.resp.errorDescription, "Failed")
            }
        })
    }
}

export class userModel {
    userName: any;
    password: any;
    constructor() {
        this.userName = "";
        this.password = "";
    }
}
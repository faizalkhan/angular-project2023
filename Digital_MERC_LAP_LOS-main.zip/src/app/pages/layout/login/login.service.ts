import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor() { }
}



export interface MenuUserDetail {
  userId: string;
  roleId: string;
  sbuid: string;
  userName: string;
  company_Code?: any;
  email_Id: string;
  roleName: string;
  readOnly: boolean;
}

export interface BranchDetail {
  branch_ID: string;
  branchName: string;
}

export interface SubMenuDetail {
  menu_Id: string;
  subMenu_Id: string;
  subMenu_Desc: string;
  menuLink: string;
  priority_Order: number;
}

export interface ParentMenuDetail {
  menu_Id: string;
  menu: string;
  parent_Id: string;
  order: number;
}

export interface Resp {
  errorcode: string;
  errorDescription?: any;
}

export interface MenuLinkDetail {
  menuId: string;
  menu: string;
  menuLink: string;
}

export interface RoleDetail {
  roleId: string;
  roleName: string;
}
export interface MenuResponse {
  menuUserDetail: MenuUserDetail;
  menuStringDetail: any[];
  branchDetail: BranchDetail[];
  sBUDetail: any[];
  subMenuDetail: SubMenuDetail[];
  parentMenuDetail: ParentMenuDetail[];
  resp: Resp;
  menuLinkDetails: MenuLinkDetail[];
  roleDetails: RoleDetail[];
}





import { MenuComponent } from './menu/menu.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboad/dashboard.component';
import {  ControlComponent } from './control/control.component';
import { functionModule } from './functional';
import { PersonalDiscussionComponent } from './functional/personal-discussion/personaldiscussion.component';
import { LegalCommonComponent } from '../sanction/Common/legal-common/legal-common.component';
import { TechnicalCommonComponent } from '../sanction/Common/technical-common/technical-common.component';
import { LegalVendorPageComponent } from '../legal/legal-vendor-page/legal-vendor-page.component';
import { LegalVendorCommonComponent } from '../sanction/Common/legal-vendor-common/legal-vendor-common.component';
import { SanctionDashComponent } from '../sanction/dashboard/sanctiondash.component';
import { TechnicalVendorPageComponent } from '../technical/technical-vendor-page/technical-vendor-page.component';
import { TechnicalVendorCommonComponent } from '../sanction/Common/technical-vendor-common/technical-vendor-common.component';
import { DisbursementPDashComponent } from '../disbursementdetails/dashboard/dashboard.compoent';
import { DisbursementHomeComponent } from '../disbursementdetails/home/home.component';
import { iaCustPointVerificationComponent } from './functional/custpointverification-ia/cpvia.component';
import { EditSaveBtnGrpComponent } from './button/edit-save-btn-grp/edit-save-btn-grp.component';
import { UploadViewDownloadComponent } from './button/upload-view-download/upload-view-download.component';
import { UploadViewDownloadService } from './button/upload-view-download/upload-view-download.service';
import { LayoutFormGroupComponent } from './layout-form-group/layout-form-group.component';
import { FormService } from './layout-form-group/form-service';
import { FormControlService } from './layout-form-group/form-group.service';
import { DynamicFormComponent } from './dynamic-form/dynamic-form.component';



export const LayoutModule = [HeaderComponent, MenuComponent, HomeComponent,
    LoginComponent, DashboardComponent, functionModule, SanctionDashComponent, ControlComponent, PersonalDiscussionComponent,
    LegalCommonComponent, TechnicalCommonComponent,
    LegalVendorPageComponent,
    LegalVendorCommonComponent, DisbursementPDashComponent, DisbursementHomeComponent, iaCustPointVerificationComponent,
    EditSaveBtnGrpComponent,
    UploadViewDownloadComponent,LayoutFormGroupComponent,DynamicFormComponent
];

export const LayoutRoute = [];

export const LayoutService = [UploadViewDownloadService,FormService,FormControlService];
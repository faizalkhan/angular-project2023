import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { headerModel } from "src/app/shared/models/common/header-table";
import { ConfigService } from "src/app/shared/services/common/http.services";

@Component({
    selector: "app-dashboard",
    templateUrl: "./dashboard.component.html",
    styleUrls: ["./dashboard.component.css"],
    providers: [ConfigService]
})
export class DashboardComponent implements OnInit {
    @Input() Header: headerModel[] = [];
    @Input() Data: any[] = [];
    @Input() CellClickName: any;
    @Output() RowEvent = new EventEmitter<any>();
    @Input() titleName: any;
    page: number = 1;
    PerPage: number = 5;
    ngOnInit(): void {
    }
    constructor(private config: ConfigService) { }

    RowClick(item: any) {
        this.RowEvent.emit(item);
    }
}
import { DatePipe } from "@angular/common";
import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { InfoServices } from "src/app/Injectable/info.services";
import { Menu } from "src/app/shared/models/common/menu.model";
import { Search } from "src/app/shared/models/sanction/search/search";
import { SanctionService } from "src/app/shared/services/sanction/sanction.service";
import { SearchService } from "src/app/shared/services/search/search.service";
import { GeoLocationService, PositionModel } from "./geo-location.service";
import { MenuService } from "./menu-service.service";
@Component(
    {
        selector: "app-layout",
        templateUrl: "./header.component.html",
        styleUrls: ["./header.component.css"],
        providers: [DatePipe]
    }
)
export class HeaderComponent implements OnInit {
    public get accountNumber(): string {
        return this.sanctionservice.LanInfo.lan
    }
    public get IsShow(): boolean {
        return this.menuService.IsShow;
    }
    public get headerMenu(): any {
        return this.menuService.headerMenu;
    }
    public get subMenu() {
        return this.menuService.subMenu;
    }
    public get userName() {
        return this.menuService?.localMenu?.menuUserDetail?.userName
    }
    public get position(): PositionModel {
        return this.geoLocation.position;
    }
    constructor(private route: Router,
        private info: InfoServices, private aciveRoute: ActivatedRoute,
        private searchService: SearchService,
        private menuService: MenuService,
        private datepipe: DatePipe,
        private geoLocation: GeoLocationService,
        private sanctionservice: SanctionService
    ) {


    }
    ngOnInit(): void {
        this.menuService.GetHeader();
        this.geoLocation.getLocation();

    }
    menuClick(event: Menu) {
        this.route.navigate([event.Path]);
    }
    SubmenuClick(event: Menu) {
        this.route.navigate([event.Path]);
    }
    private _search: Search = new Search();
    public get search(): any {
        if (this.searchService.data) {
            return this.searchService.data;
        }
        return new Search();
    }
    public set search(value: Search) {
        this._search = value;
    }

    Search() {
        this.search.fromDate = this.datepipe.transform(this.search.fromDate, "yyyy-MM-dd");
        this.search.toDate = this.datepipe.transform(this.search.toDate, "yyyy-MM-dd")
        this.searchService.data = this.search;
        this.searchService.sendSearch();
    }

    logout() {
        this.info.Clear();
        this.info.IsLogin(false);
    }

}
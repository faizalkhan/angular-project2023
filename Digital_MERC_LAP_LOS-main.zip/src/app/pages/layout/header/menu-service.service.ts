import { Injectable } from '@angular/core';
import { InfoServices } from 'src/app/Injectable/info.services';
import { Menu } from 'src/app/shared/models/common/menu.model';
import { MenuResponse, RoleDetail, SubMenuDetail } from '../login/login.service';

@Injectable({
  providedIn: 'any'
})
export class MenuService {
  private _localMenu: MenuResponse = {} as MenuResponse;
  IsShow: boolean = false;
  ActiveHeaderMenu: Menu = {} as Menu;
  activeSubMenu: SubMenuDetail = {} as SubMenuDetail;
  public get CurrentUserId() {
    let menu = JSON.parse(this.info.getItem('menu')) as MenuResponse;

    return menu.menuUserDetail?.userId;
  }
  public get currentRole(): RoleDetail {
    let roleInfo = this._localMenu?.roleDetails?.find(x => x.roleId == this._localMenu.menuUserDetail.roleId);
    return roleInfo ?? {} as RoleDetail;
  }

  public get localMenu(): MenuResponse {
    if (this.info.IsItem('menu')) {
      return JSON.parse(this.info.getItem('menu')) as MenuResponse;
    }
    else if (this._localMenu) {
      return this._localMenu;
    }
    else {
      return {} as MenuResponse;
    }
  }
  public set localMenu(value: MenuResponse) {
    this._localMenu = value;
  }
  public get headerMenu(): Menu[] {
    return this.localMenu?.parentMenuDetail?.map(x => {
      return new Menu(x.menu_Id, x.menu, this.localMenu.menuLinkDetails.find(y => y.menuId == x.menu_Id)?.menuLink.replace('\t', ''), "", false, this.getChild(x.menu_Id));
    });
  }
  public set headerMenu(value: Menu[]) {

  }

  public get subMenu(): Menu[] {

    let menu = this.ActiveHeaderMenu?.Child as Menu[];
    if (menu) {
      return menu;
    }
    else {
      return [];
    }
  }


  constructor(private info: InfoServices) { }

  GetHeader() {

  }

  getChild(data: any): Menu[] {

    let subMenu = this.localMenu.subMenuDetail.filter(x => x.menu_Id == data);
    return subMenu.map(x => {
      return new Menu(x.subMenu_Id, x.subMenu_Desc, x.menuLink.replace('\t', ''), "", false, x.menu_Id);
    });
  }

  activate(data: Menu) {

  }

  GetHeaderMenuByPath(event: string) {

    let hMenu = this.headerMenu.find(x => x.Path == event.trim())?.id;
    if (!hMenu) {
      let subMenu = this.localMenu.subMenuDetail.find(x => x.menuLink.replace('\t', '') == event) as SubMenuDetail;
      this.activeSubMenu = subMenu;
      if (subMenu) {
        hMenu = subMenu.menu_Id;
      }
    }
    if (hMenu) {
      this.headerMenu.forEach(x => {
        x.IsActive = x.id == hMenu;
        let childList = x.Child as Menu[];
        if (x.IsActive) {
          let child = childList.find(y => y.Path == event);
          if (child) {
            this.activeSubMenu = { menu_Id: hMenu, menuLink: child.Path, subMenu_Desc: child.Name, subMenu_Id: child.id } as SubMenuDetail;
          }
        }
      });
      this.ActiveHeaderMenu = this.headerMenu.find(x => x.id == hMenu) as Menu
    }
  }

  HeaderIsActive(item: Menu) {
    if (this.activeSubMenu) {
      return this.ActiveHeaderMenu.id == item.id;
    }
    else
      return false;
  }
  SubMenuIsActive(item: Menu) {
    if (this.activeSubMenu) {
      return this.activeSubMenu.subMenu_Id == item.id;
    }
    else
      return false;
  }
}



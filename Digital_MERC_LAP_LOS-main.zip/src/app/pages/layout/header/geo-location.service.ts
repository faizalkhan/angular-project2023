import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GeoLocationService {
  private _position: PositionModel = {} as PositionModel;
  public get position(): any {
    return this._position;
  }
  public set position(value: any) {
    this._position = value;
  }
  constructor() {

  }
  getLocation() {
    let self = this;
    let onSuccess = (position: any) => {
      self.position = position.coords;
    }
    navigator.geolocation.getCurrentPosition(onSuccess, this.onError);
  }
  onSuccess(position: any) {
    this.position = position.coords;
  }

  onError(error: any) {
  }

}
export interface PositionModel {
  accuracy: any;
  altitude: any;
  altitudeAccuracy: any;
  heading: any;
  latitude: any;
  longitude: any;
  speed: any;
}
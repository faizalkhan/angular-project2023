import { outputAst } from "@angular/compiler";
import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { NotificationService } from "src/app/notification.service";
import { HouseholdAssessmentService } from "src/app/pages/sanction/household-assessment/household-assessment.service";
import { Dropdown, IDropdown } from "src/app/shared/models/common/control.model";
import { IresponseModel } from "src/app/shared/models/common/response.model";
import { AccomodationAndComposition, IAccomodationAndComposition } from "src/app/shared/models/sanction/AccomodationAndComposition";
import { ConfigService } from "src/app/shared/services/common/http.services";
import { SanctionService } from "src/app/shared/services/sanction/sanction.service";

@Component(
    {
        selector: 'ltfs-haaccomadationcomposition',
        templateUrl: './haaccomadationcomposition.component.html',
        styleUrls: ['./haaccomadationcomposition.component.css']
    }
)
export class AccomadationCompositionComponent implements OnInit {
    @Input() AccomondationGroup: IAccomodationAndComposition = new AccomodationAndComposition();
    @Output() OnAccomondationGroupChange = new EventEmitter<IAccomodationAndComposition>();
    isEdit: boolean = false;
    ListOfProperty: IDropdown[] = [];
    ListOfHouseCategory: IDropdown[] = [];
    ListOfConstructionType: IDropdown[] = [];
    ListOfLocality: IDropdown[] = [];
    ListOf: IDropdown[] = [];
    SchoolType: IDropdown[] = [];
    readOnly: any;
    constructor(private http: ConfigService, private sanctionService: SanctionService, private notification: NotificationService, private haservice: HouseholdAssessmentService) {

    }
    ngOnInit(): void {
        this.readOnly = this.sanctionService.LanInfo.readOnly;

        this.ListOf = [

            { displayName: 'Yes', selected: false, value: 'Yes' },
            { displayName: 'No', selected: false, value: 'No' }]
        this.SchoolType = [

            { displayName: 'Public', selected: false, value: 'Public' },
            { displayName: 'Private', selected: false, value: 'Private' }]

        this.ListOfProperty = [

            new Dropdown({ displayName: "Self Owned" }),
            new Dropdown({ displayName: "Owned by Family" }),
            new Dropdown({ displayName: "Rented" })
        ]

        this.ListOfHouseCategory = [

            { displayName: 'Independent House', selected: false, value: 'Independent House' },
            { displayName: 'Flat', selected: false, value: 'Flat' }]

        this.ListOfConstructionType = [

            { displayName: 'Single floor', selected: false, value: 'Single floor' },
            { displayName: 'Multiple floor', selected: false, value: 'Multiple floor' },
            { displayName: 'Semi-Kaccha', selected: false, value: 'Semi-Kaccha' }]

        this.ListOfLocality = [

            { displayName: 'Developing area', selected: false, value: 'Developing area' },
            { displayName: 'Fully developed area', selected: false, value: 'Fully developed area' },
            { displayName: 'Under developed area', selected: false, value: 'Under developed area' },
            { displayName: 'Community dominated', selected: false, value: 'Community dominated' },
            { displayName: 'Slum area', selected: false, value: 'Slum area' }]

    }



    Submit() {
        let msg = this.AccomondationGroup.validation();
        if (msg.length > 0) {
            this.notification.showWarning(msg);
        }
        if (msg.length == 0) {

            this.http.httpPost(this.AccomondationGroup.toJson(), 'LAP_HA_AccomodationAndComposition').subscribe((res: any) => {
                if (res.errorcode == "00" || res.errorcode == "0" || res.errorcode == "01") {
                    this.isEdit = !this.isEdit;
                    this.notification.showSuccess(res.errorDescription);
                    this.OnAccomondationGroupChange.emit(this.AccomondationGroup);
                }
                else {
                    this.notification.showError(res.errorDescription);
                }
            });
        }
    }

    edit() {
        this.isEdit = !this.isEdit;
    }
    LocalityValue: any;
    OnchangeLocality() {
        if (this.AccomondationGroup.locality == "") {
            this.LocalityValue = true;
        }
        else {
            this.LocalityValue = false;
        }
    }
    constructionTypeValue: any;
    OnchangeconstructionType() {
        if (this.AccomondationGroup.constructionType == "") {
            this.constructionTypeValue = true;
        }
        else {
            this.constructionTypeValue = false;
        }
    }
    houseCategoryValue: any;
    OnchangehouseCategory() {
        if (this.AccomondationGroup.houseCategory == "") {
            this.houseCategoryValue = true;
        }
        else {
            this.houseCategoryValue = false;
        }
    }

    
    earningmember: any;
    OnchangeEarning() {
        this.earningmember = false;
        if (this.AccomondationGroup.earningMembers <= this.AccomondationGroup.adults) {
            this.AccomondationGroup.dependentMembers = this.AccomondationGroup.noOfFamilyMembers - this.AccomondationGroup.earningMembers
        }
        else {
            this.earningmember = true;
        }
    }
    NoChildren: any;
    PropLandArea: boolean = false;
    OnchangeChildrenGoingToSchool() {
        this.NoChildren = !(this.AccomondationGroup.noOfChildrenGoingToSchoolNCollege <= this.AccomondationGroup.children);

        this.PropLandArea = (!this.AccomondationGroup.noOfChildrenGoingToSchoolNCollege || this.AccomondationGroup.noOfChildrenGoingToSchoolNCollege == 0)
    }

    Cancel(event: IAccomodationAndComposition) {
        this.AccomondationGroup = new AccomodationAndComposition(event);
    }

}


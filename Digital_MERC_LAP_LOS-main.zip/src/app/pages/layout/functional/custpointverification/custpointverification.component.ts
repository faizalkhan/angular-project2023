import { Component, Input, OnInit } from "@angular/core";
import { CPVerification, ICPVerification } from "src/app/shared/models/common/cpv.model";
import { IresponseModel } from "src/app/shared/models/common/response.model";
import { ConfigService } from "src/app/shared/services/common/http.services";

@Component(
    {
        selector: "app-cpv",
        templateUrl: './custpointverification.component.html',
        styleUrls: ['./custpointverification.component.css'],
        providers: [ConfigService]
    }
)
export class CustPointVerificationComponent implements OnInit {

    @Input() Data: any = {
        "LoanAccountNumber": "1234",
        "FLO_PsId": "6677",
        "CreatedON": "2022-08-04"
    };
    // @Input() Url: any = 'GetLAP_IA_CustPointVerification';
    @Input() Url: any;
    CPVData: ICPVerification=new ICPVerification();
    constructor(private http: ConfigService) {

    }
    ngOnInit(): void {
        this.GetInfo();
    }

    GetInfo() {
        this.http.httpPost<IresponseModel<ICPVerification[]>>(this.Data, this.Url).subscribe((res: IresponseModel<ICPVerification[]>) => {
            this.CPVData=res.data[0];
        });
    }
}
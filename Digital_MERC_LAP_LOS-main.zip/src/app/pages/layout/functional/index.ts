import { AmenitiesLifestyleComponent } from "./amenities-lifestyle/amenitieslifestyle.component";
import { CustPointVerificationComponent } from "./custpointverification/custpointverification.component";
import { AccomadationCompositionComponent } from "./ha-accomadation-composition/haaccomadationcomposition.component";
import { SalariedComponent } from "./salaried/salaried.component";
import { ElectronicRepairComponent } from "./self-employed/electronic-repair/electronic-repair.component";
import { GenericComponent } from "./self-employed/generic/generic.component";
import { MilkPurchaseShopComponent } from "./self-employed/milk-purchase-shop/milk-purchase-shop.component";
import { MilkretailshopComponent } from "./self-employed/milk-retail-shop/milkretailshop.component";
import { MotorMechComponent } from "./self-employed/motor-mech/motor-mech.component";
import { SelfemployedComponent } from "./self-employed/selfemployed.component";
import { TailoringShopComponent } from "./self-employed/tailoring-shop/tailoring-shop.component";

export const functionModule = [
    CustPointVerificationComponent,
    SalariedComponent,
    SelfemployedComponent,
    AccomadationCompositionComponent,
    AmenitiesLifestyleComponent,
    MilkretailshopComponent,
    GenericComponent,
    MilkPurchaseShopComponent,
    MotorMechComponent,
    ElectronicRepairComponent,
    TailoringShopComponent,
    MotorMechComponent,
]
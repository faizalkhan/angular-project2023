import { Component, Input, OnInit } from "@angular/core";
import { IIACPVerification } from "src/app/shared/models/common/cpv.model";
import { IresponseModel } from "src/app/shared/models/common/response.model";
import { ConfigService } from "src/app/shared/services/common/http.services";

@Component(
    {
        selector: "ia-cpv",
        templateUrl: './cpvia.component.html',
        styleUrls: ['./cpvia.component.css'],
        providers: [ConfigService]
    }
)
export class iaCustPointVerificationComponent implements OnInit {

    @Input() Data: any = {
        "LoanAccountNumber": "1234",
        "FLO_PsId": "6677",
        "CreatedON": "2022-08-04"
    };
    @Input() Url: any = 'GetLAP_IA_CustPointVerification';
    CPVData: IIACPVerification = new IIACPVerification();
    constructor(private http: ConfigService) {

    }
    ngOnInit(): void {
        this.GetInfo();
    }

    GetInfo() {
        this.http.httpPost<IresponseModel<IIACPVerification[]>>(this.Data, this.Url).subscribe((res: IresponseModel<IIACPVerification[]>) => {
            this.CPVData = new IIACPVerification();

            if (res.errorcode == "00") {
                this.CPVData = res.data[0];
            }
        });
    }
}
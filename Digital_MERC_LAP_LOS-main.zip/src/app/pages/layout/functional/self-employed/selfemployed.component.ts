import { Component, Input, OnInit, ViewChild, ViewContainerRef } from "@angular/core";
import { IDropdown } from "src/app/shared/models/common/control.model";
import { IresponseModel } from "src/app/shared/models/common/response.model";
import { SanctionRequestData } from "src/app/shared/models/sanction/sanction.model";
import { SelfEmployedModel } from "src/app/pages/layout/functional/self-employed/SelfEmployedModel";
import { ElecronicAndRepairModel } from "src/app/shared/models/sanction/ElecronicAndRepairModel";
import { ConfigService } from "src/app/shared/services/common/http.services";
import { AppDynamicDirective } from "src/app/shared/directive/app-dynamic.directive";
import { BusinessLists } from "src/app/shared/models/sanction/Generic";
import { MotorMechComponent } from "./motor-mech/motor-mech.component";
import { MilkretailshopComponent } from "./milk-retail-shop/milkretailshop.component";
import { ElectronicRepairComponent } from "./electronic-repair/electronic-repair.component";
import { GenericComponent } from "./generic/generic.component";
import { TailoringShopComponent } from "./tailoring-shop/tailoring-shop.component";
import { SanctionService } from "src/app/shared/services/sanction/sanction.service";
import { incomeAssessmentService } from "src/app/pages/sanction/income-assessment/income-assessment.service";
import { masterModuleDropdown } from "src/app/shared/models/sanction/masterDropdown";
import { ISelfEmployedModel } from "./ISelfEmployedModel";
import { NotificationService } from "src/app/notification.service";
import { common } from "src/app/shared/models/common";


@Component({
    selector: 'ltfs-selfemployed',
    templateUrl: './selfemployed.component.html',
    styleUrls: ['./selfemployed.component.css'],
    providers: [ConfigService]
})
export class SelfemployedComponent implements OnInit {

    @ViewChild(AppDynamicDirective, { static: true }) embeddedContainer!: AppDynamicDirective;

    businessList: IDropdown[] = [
        { displayName: 'Kirana or General store', value: 'GetLAP_IA_Generic' }
        , { displayName: 'Dairy and allied', value: "GetLAP_IA_DairyAndAllied" }
        , { displayName: 'Animal husbandry', value: 'GetLAP_IA_Generic' }
        , { displayName: 'Poultry', value: 'GetLAP_IA_Generic' }
        , { displayName: 'Agri and Allied', value: 'GetLAP_IA_Generic' }
        , { displayName: 'Vegetables,Fruits or Flowers', value: 'GetLAP_IA_Generic' }
        , { displayName: 'Hotel, Restaurants or other eateries', value: 'GetLAP_IA_Generic' }
        , { displayName: 'Building & construction materials', value: 'GetLAP_IA_Generic' }
        , { displayName: 'Readymade garments and hosiery', value: 'GetLAP_IA_Generic' }
        , { displayName: 'Hardware and other equipments', value: 'GetLAP_IA_Generic' }
        , { displayName: 'Electronics & Furniture', value: 'GetLAP_IA_Generic' }
        , { displayName: 'Motor mechanic and garage services', value: 'GetLAP_IA_MotorMech' }
        , { displayName: 'Electronic and Mobile repair services', value: 'GetLAP_IA_ElecronicAndRepair' }
        , { displayName: 'Tailoring/Handloom services', value: 'GetLAP_IA_TailoringHandloom' }
        , { displayName: 'Others', value: 'GetLAP_IA_Generic' }
    ] as IDropdown[];
    SelfEmployed: ISelfEmployedModel = new SelfEmployedModel();
    electronicAndMobileRepairData!: ElecronicAndRepairModel;
    private _isEdit: boolean = false;
    public get isEdit(): boolean {
        return this._isEdit;
    }
    public set isEdit(value: boolean) {
        this._isEdit = value;
    }
    ElecronicAndRepair!: ElecronicAndRepairModel;
    ContionalDrop: IDropdown[] = masterModuleDropdown.Conditional;
    ITRListDrop: IDropdown[] = masterModuleDropdown.ITRList;
    end_UseOfFund: IDropdown[] = masterModuleDropdown.end_UseOfFund;
    readOnly: any;
    @Input() RequestData: SanctionRequestData = new SanctionRequestData();
    @Input() RequestDataWithLan: SanctionRequestData = new SanctionRequestData();
    @Input() mainLineOfBusiness: any;
    constructor(private http: ConfigService, private notify: NotificationService,
        private IAService: incomeAssessmentService, private sanctionService: SanctionService
    ) {

    }
    ngOnInit(): void {
        this.readOnly = this.sanctionService.LanInfo.readOnly;
        this.SelfEmployed.loanAccountNumber = this.sanctionService.LanInfo.lan;
        this.BusinessChange(this.SelfEmployed?.line_of_Business);
    }



    Submit() {
        if (this.validation()) {

            this.http.httpPost<any>(this.SelfEmployed.toJSON(), 'LAP_IA_SelfEmployed').subscribe((res: any) => {
                if (res.errorcode == "00" || res.errorcode == "01") {
                    this.isEdit = !this.isEdit;
                    this.notify.showSuccess(res.errorDescription);
                }
                else {
                    this.notify.showError(res.errorDescription);
                }
            })
        }


    }
    validation(): boolean {
        if ((this.SelfEmployed.udyam_Registration_YN && (this.SelfEmployed.udyam_Registration_YN.toLowerCase() == 'y' || this.SelfEmployed.udyam_Registration_YN.toLowerCase() == 'yes') && (!this.SelfEmployed.udyam_Reg_No || this.SelfEmployed.udyam_Reg_No == ""))) {
            this.notify.showWarning("Please enter Udyam Registration No.");
            return false
        }
        else if ((this.SelfEmployed.gsT_Registered_YN && (this.SelfEmployed.gsT_Registered_YN.toLowerCase() == 'y' || this.SelfEmployed.gsT_Registered_YN.toLowerCase() == 'yes') && (!this.SelfEmployed.gsT_Reg_No || this.SelfEmployed.gsT_Reg_No == ""))) {
            this.notify.showWarning("Please enter GST Registered No.");
            return false
        }
        else if ((this.SelfEmployed.businessShop_Reg_YN && (this.SelfEmployed.businessShop_Reg_YN.toLowerCase() == 'y' || this.SelfEmployed.businessShop_Reg_YN.toLowerCase() == 'yes') && (!this.SelfEmployed.businessShop_Reg_No || this.SelfEmployed.businessShop_Reg_No == ""))) {
            this.notify.showWarning("Please enter Business / Shop Registration no.");
            return false
        }
        //else if (!common.IsValid_Email(this.SelfEmployed.business_EmailId)) {
            // this.notify.showWarning("Please enter valid email id");
            // return false;
        //}
        else if ((this.SelfEmployed.business_PinCode.length < 6) || (this.SelfEmployed.business_PinCode.length > 6)) {
            this.notify.showWarning("Please enter valid pincode");
            return false
        }
        return true;
    }
    cancel(event: any) {
        this.SelfEmployed = new SelfEmployedModel(event);
        this.isEdit = !this.isEdit;
    }


    BusinessChange(event: any) {
        let componentRef = undefined;
        let viewConst = this.embeddedContainer.viewContainerRef;
        viewConst.clear();
        switch (event) {
            case BusinessLists.Motormechanicandgarageservices:
                componentRef = viewConst.createComponent<MotorMechComponent>(MotorMechComponent);
                componentRef.instance.RequestData = this.RequestData;
                break;
            case BusinessLists.Dairyandallied:
                componentRef = viewConst.createComponent<MilkretailshopComponent>(MilkretailshopComponent);
                componentRef.instance.RequestData = this.RequestData;
                componentRef.instance.RequestDataWithLan = this.RequestDataWithLan;
                break;
            case BusinessLists.TailoringHandloomservices:
                componentRef = viewConst.createComponent<TailoringShopComponent>(TailoringShopComponent);
                componentRef.instance.RequestData = this.RequestData;
                componentRef.instance.RequestDataWithLan = this.RequestDataWithLan;
                break;
            case BusinessLists.ElectronicandMobilerepairservices:
                componentRef = viewConst.createComponent<ElectronicRepairComponent>(ElectronicRepairComponent);
                componentRef.instance.RequestData = this.RequestData;
                componentRef.instance.RequestDataWithLan = this.RequestDataWithLan;
                break;
            default:
                componentRef = viewConst.createComponent<GenericComponent>(GenericComponent);
                componentRef.instance.RequestData = this.RequestData;
                componentRef.instance.RequestDataWithLan = this.RequestDataWithLan;
                componentRef.instance.mainLineOfBusiness = this.SelfEmployed?.line_of_Business;
                break;
        }
    }
    protertyValue: any;
    PropValue: any = false;
    ChangeCattleprovidingmilk() {
        this.PropValue = false;
        if (this.protertyValue >= 1 && this.protertyValue == 4) {
            //this.PropValue=true;
        }
        else {
            this.PropValue = true;
        }
    }

    CattleAccommodationValue: any;
    Cattleaccommodation: any = false;
    ChangeCattleAccommodation() {
        this.Cattleaccommodation = false;
        if (this.CattleAccommodationValue >= 100 && this.CattleAccommodationValue <= 2100) {
        }
        else
            this.Cattleaccommodation = true;
    }

    DailymilkProductionValue: any;
    Dailymilkproduction: any = false;
    ChangeDailyMilkProduction() {
        this.Dailymilkproduction = false;
        if (this.DailymilkProductionValue >= 1 && this.CattleAccommodationValue <= 10) {

        }
        else {
            this.Cattleaccommodation = true;
        }

    }
}

export interface ISelfEmployedModel {
    applicationNo: string;
    applicantCoappRef: string;
    line_of_Business: string;
    line_of_Business_Dtl_If_Others: string;
    udyam_Registration_YN: string;
    udyam_Reg_No: string;
    gsT_Registered_YN: string;
    gsT_Reg_No: string;
    itR_lst3yr_Conf: string;
    businessShop_Reg_YN: string;
    businessShop_Reg_No: string;
    end_UseOfFund: string;
    end_UseOfFund_Detail: string;
    business_Address: string;
    business_Landmark: string;
    business_Village: string;
    business_City: string;
    business_District: string;
    business_State: string;
    business_PinCode: string;
    business_EmailId: string;
    flO_PsId: string;
    sourceThrough: string;
    createdOn: string;
    loanAccountNumber:string;
    toJSON(): any;
}

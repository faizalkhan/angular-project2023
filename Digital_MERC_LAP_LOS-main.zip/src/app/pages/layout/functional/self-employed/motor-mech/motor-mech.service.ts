import { ThisReceiver } from '@angular/compiler';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MotorMechService {

  constructor() { }
}


export interface IMotorMech {
  applicationNo: string;
  applicantCoappRef: string;
  tW_YN: string;
  fW_YN: string;
  rickTempo_YN: string;
  hD_YN: string;
  others_YN: string;
  shopGarageName: string;
  number_Of_Years: string;
  ownership_Of_Premise: string;
  area_SqFt: string;
  numOfFam: number;
  numofPartners: number;
  profSharingRatio: string;
  profSharingRatio_Disable: boolean;
  numofEmplyrWorker: string;
  wageFrequency: string;
  locality: string;
  physical_Asset_Details: string;
  count_Of_Asset: string;
  upI_YN: string;
  numOfVehicle_TW: string;
  numOfJobInADay_TW: string;
  jobsInAMonth_TW: string;
  avgRevenuePerJob_TW: string;
  numOfVehicle_FW: string;
  numOfJobInADay_FW: string;
  jobsInAMonth_FW: string;
  avgRevenuePerJob_FW: string;
  numOfVehicle_RickTempo: string;
  numOfJobInADay_RickTempo: string;
  jobsInAMonth_RickTempo: string;
  avgRevenuePerJob_RickTempo: string;
  numOfVehicle_HD: string;
  numOfJobInADay_HD: string;
  jobsInAMonth_HD: string;
  avgRevenuePerJob_HD: string;
  numOfVehicle_Others: string;
  numOfJobInADay_Others: string;
  jobsInAMonth_Others: string;
  avgRevenuePerJob_Others: string;
  other_Net_Income: string;
  other_Net_IncomeDtl: string;
  exp_ShopGaragerent_Act: string;
  exp_Electricity_Act: string;
  exp_Consumable_Act: string;
  exp_SalaryLabourCost_Act: string;
  exp_Other_Act: string;
  exp_Act_Total: string;
  exp_ShopGaragerent_Calc: string;
  exp_Electricity_Calc: string;
  exp_Consumable_Calc: string;
  exp_SalaryLabourCost_Calc: string;
  exp_Other_Calc: string;
  exp_Calc_Total: string;
  toJson(): any;
}

export class MotorMech implements IMotorMech {
  //applicationNo: string = "";
  applicantCoappRef: string = "";
  tW_YN: string = "";
  fW_YN: string = "";
  rickTempo_YN: string = "";
  hD_YN: string = "";
  others_YN: string = "";

  private _applicationNo: string = "";
  public get applicationNo(): string {
    return this._applicationNo;
  }
  public set applicationNo(value: string) {
    this._applicationNo = value;
  }

  private _shopGarageName: string = "";
  public get shopGarageName(): string {
    return this._shopGarageName;
  }
  public set shopGarageName(value: string) {
    this._shopGarageName = value;
  }


  private _number_Of_Years: string = "";

  public get number_Of_Years(): string {
    return this._number_Of_Years;
  }
  public set number_Of_Years(value: string) {
    this._number_Of_Years = value;
  }

  private _ownership_Of_Premise: string = "";
  public get ownership_Of_Premise(): string {
    return this._ownership_Of_Premise;
  }
  public set ownership_Of_Premise(value: string) {
    this._ownership_Of_Premise = value;
  }

  private _area_SqFt: string = "";
  private _other_Net_IncomeDetail: string = "";

  public get area_SqFt(): string {
    return this._area_SqFt;
  }
  public set area_SqFt(value: string) {
    this._area_SqFt = value;
  }

  private _numOfFam: number = 0;
  public get numOfFam(): number {
    return this._numOfFam;
  }
  public set numOfFam(value: number) {
    this._numOfFam = value;
  }

  private _numofPartners: number = 0;
  public get numofPartners(): number {
    return this._numofPartners;
  }
  public set numofPartners(value: number) {
    this._numofPartners = ((value ?? "") == 0 ? Number(0) : Number(value));
    this.profSharingRatio_Disable = this._numofPartners == 0;
  }

  private _profSharingRatio_Disable: boolean = false;
  public get profSharingRatio_Disable(): boolean {
    return this._profSharingRatio_Disable;
  }
  public set profSharingRatio_Disable(value: boolean) {
    this._profSharingRatio_Disable = value;
    if (value == true)
      this._profSharingRatio = "0";
  }

  private _profSharingRatio: string = "";
  public get profSharingRatio(): string {
    return this._profSharingRatio;
  }
  public set profSharingRatio(value: string) {
    this._profSharingRatio = value;
  }

  private _numofEmplyrWorker: string = "";
  public get numofEmplyrWorker(): string {
    return this._numofEmplyrWorker;
  }
  public set numofEmplyrWorker(value: string) {
    this._numofEmplyrWorker = value;
  }

  private _wageFrequency: string = "";
  public get wageFrequency(): string {
    return this._wageFrequency;
  }
  public set wageFrequency(value: string) {
    this._wageFrequency = value;
  }

  private _locality: string = "";
  public get locality(): string {
    return this._locality;
  }
  public set locality(value: string) {
    this._locality = value;
  }

  private _physical_Asset_Details: string = "";
  public get physical_Asset_Details(): any {
    return this._physical_Asset_Details;
  }
  public set physical_Asset_Details(value: any) {
    this._physical_Asset_Details = value;
  }
  private _count_Of_Asset: string = "";
  public get count_Of_Asset(): string {
    return this._count_Of_Asset;
  }
  public set count_Of_Asset(value: string) {
    this._count_Of_Asset = value;
  }
  private _upI_YN: string = "";
  public get upI_YN(): any {
    return this._upI_YN;
  }
  public set upI_YN(value: any) {
    this._upI_YN = value == true || value == 'Y' ? 'Y' : 'N';
  }
  private _numOfVehicle_TW: string = "";
  public get numOfVehicle_TW(): string {
    return this._numOfVehicle_TW;
  }
  public set numOfVehicle_TW(value: string) {
    this._numOfVehicle_TW = value;
  }
  private _numOfJobInADay_TW: string = "";
  public get numOfJobInADay_TW(): string {
    return this._numOfJobInADay_TW;
  }
  public set numOfJobInADay_TW(value: string) {
    this._numOfJobInADay_TW = value;
  }
  private _jobsInAMonth_TW: string = "";
  public get jobsInAMonth_TW(): string {
    return this._jobsInAMonth_TW;
  }
  public set jobsInAMonth_TW(value: string) {
    this._jobsInAMonth_TW = value;
  }
  private _avgRevenuePerJob_TW: string = "";
  public get avgRevenuePerJob_TW(): string {
    return this._avgRevenuePerJob_TW;
  }
  public set avgRevenuePerJob_TW(value: string) {
    this._avgRevenuePerJob_TW = value;
  }
  private _numOfVehicle_FW: string = "";
  public get numOfVehicle_FW(): string {
    return this._numOfVehicle_FW;
  }
  public set numOfVehicle_FW(value: string) {
    this._numOfVehicle_FW = value;
  }
  private _numOfJobInADay_FW: string = "";
  public get numOfJobInADay_FW(): string {
    return this._numOfJobInADay_FW;
  }
  public set numOfJobInADay_FW(value: string) {
    this._numOfJobInADay_FW = value;
  }
  private _jobsInAMonth_FW: string = "";
  public get jobsInAMonth_FW(): string {
    return this._jobsInAMonth_FW;
  }
  public set jobsInAMonth_FW(value: string) {
    this._jobsInAMonth_FW = value;
  }
  private _avgRevenuePerJob_FW: string = "";
  public get avgRevenuePerJob_FW(): string {
    return this._avgRevenuePerJob_FW;
  }
  public set avgRevenuePerJob_FW(value: string) {
    this._avgRevenuePerJob_FW = value;
  }
  private _numOfVehicle_RickTempo: string = "";
  public get numOfVehicle_RickTempo(): string {
    return this._numOfVehicle_RickTempo;
  }
  public set numOfVehicle_RickTempo(value: string) {
    this._numOfVehicle_RickTempo = value;
  }
  private _numOfJobInADay_RickTempo: string = "";
  public get numOfJobInADay_RickTempo(): string {
    return this._numOfJobInADay_RickTempo;
  }
  public set numOfJobInADay_RickTempo(value: string) {
    this._numOfJobInADay_RickTempo = value;
  }
  private _jobsInAMonth_RickTempo: string = "";
  public get jobsInAMonth_RickTempo(): string {
    return this._jobsInAMonth_RickTempo;
  }
  public set jobsInAMonth_RickTempo(value: string) {
    this._jobsInAMonth_RickTempo = value;
  }
  private _avgRevenuePerJob_RickTempo: string = "";
  public get avgRevenuePerJob_RickTempo(): string {
    return this._avgRevenuePerJob_RickTempo;
  }
  public set avgRevenuePerJob_RickTempo(value: string) {
    this._avgRevenuePerJob_RickTempo = value;
  }
  private _numOfVehicle_HD: string = "";
  public get numOfVehicle_HD(): string {
    return this._numOfVehicle_HD;
  }
  public set numOfVehicle_HD(value: string) {
    this._numOfVehicle_HD = value;
  }
  private _numOfJobInADay_HD: string = "";
  public get numOfJobInADay_HD(): string {
    return this._numOfJobInADay_HD;
  }
  public set numOfJobInADay_HD(value: string) {
    this._numOfJobInADay_HD = value;
  }
  private _jobsInAMonth_HD: string = "";
  public get jobsInAMonth_HD(): string {
    return this._jobsInAMonth_HD;
  }
  public set jobsInAMonth_HD(value: string) {
    this._jobsInAMonth_HD = value;
  }
  private _avgRevenuePerJob_HD: string = "";
  public get avgRevenuePerJob_HD(): string {
    return this._avgRevenuePerJob_HD;
  }
  public set avgRevenuePerJob_HD(value: string) {
    this._avgRevenuePerJob_HD = value;
  }
  private _numOfVehicle_Others: string = "";
  public get numOfVehicle_Others(): string {
    return this._numOfVehicle_Others;
  }
  public set numOfVehicle_Others(value: string) {
    this._numOfVehicle_Others = value;
  }
  private _numOfJobInADay_Others: string = "";
  public get numOfJobInADay_Others(): string {
    return this._numOfJobInADay_Others;
  }
  public set numOfJobInADay_Others(value: string) {
    this._numOfJobInADay_Others = value;
  }
  private _jobsInAMonth_Others: string = "";
  public get jobsInAMonth_Others(): string {
    return this._jobsInAMonth_Others;
  }
  public set jobsInAMonth_Others(value: string) {
    this._jobsInAMonth_Others = value;
  }
  private _avgRevenuePerJob_Others: string = "";
  public get avgRevenuePerJob_Others(): string {
    return this._avgRevenuePerJob_Others;
  }
  public set avgRevenuePerJob_Others(value: string) {
    this._avgRevenuePerJob_Others = value;
  }
  private _other_Net_Income: string = "";
  public get other_Net_Income(): string {
    return this._other_Net_Income;
  }
  public set other_Net_Income(value: string) {
    this._other_Net_Income = value;
  }
  private _other_Net_IncomeDtl: string = "";
  public get other_Net_IncomeDtl(): string {
    return this._other_Net_IncomeDtl;
  }
  public set other_Net_IncomeDtl(value: string) {
    this._other_Net_IncomeDtl = value;
  }
  private _exp_ShopGaragerent_Act: string = "";
  public get exp_ShopGaragerent_Act(): string {
    return this._exp_ShopGaragerent_Act;
  }
  public set exp_ShopGaragerent_Act(value: string) {
    this._exp_ShopGaragerent_Act = value;

  }
  private _exp_Electricity_Act: string = "";
  public get exp_Electricity_Act(): string {
    return this._exp_Electricity_Act;
  }
  public set exp_Electricity_Act(value: string) {
    this._exp_Electricity_Act = value;

  }
  private _exp_Consumable_Act: string = "";
  public get exp_Consumable_Act(): string {
    return this._exp_Consumable_Act;
  }
  public set exp_Consumable_Act(value: string) {
    this._exp_Consumable_Act = value;

  }
  private _exp_SalaryLabourCost_Act: string = "";
  public get exp_SalaryLabourCost_Act(): string {
    return this._exp_SalaryLabourCost_Act;
  }
  public set exp_SalaryLabourCost_Act(value: string) {
    this._exp_SalaryLabourCost_Act = value;
    this.totalCalc();
  }
  private _exp_Other_Act: string = "";
  public get exp_Other_Act(): string {
    return this._exp_Other_Act;
  }
  public set exp_Other_Act(value: string) {
    this._exp_Other_Act = value;
  }
  private _exp_Act_Total: string = "";
  public get exp_Act_Total(): string {
    return this._exp_Act_Total;
  }
  public set exp_Act_Total(value: string) {
    this._exp_Act_Total = value;
  }
  private _exp_ShopGaragerent_Calc: string = "";
  public get exp_ShopGaragerent_Calc(): string {
    return this._exp_ShopGaragerent_Calc;
  }
  public set exp_ShopGaragerent_Calc(value: string) {
    this._exp_ShopGaragerent_Calc = value;
    this.totalCalc();
  }
  private _exp_Electricity_Calc: string = "";
  public get exp_Electricity_Calc(): string {
    return this._exp_Electricity_Calc;
  }
  public set exp_Electricity_Calc(value: string) {
    this._exp_Electricity_Calc = value;
    this.totalCalc();
  }
  private _exp_Consumable_Calc: string = "";
  public get exp_Consumable_Calc(): string {
    return this._exp_Consumable_Calc;
  }
  public set exp_Consumable_Calc(value: string) {
    this._exp_Consumable_Calc = value;
    this.totalCalc();
  }
  private _exp_SalaryLabourCost_Calc: string = "";
  public get exp_SalaryLabourCost_Calc(): string {
    return this._exp_SalaryLabourCost_Calc;
  }
  public set exp_SalaryLabourCost_Calc(value: string) {
    this._exp_SalaryLabourCost_Calc = value;
    this.totalCalc();
  }
  private _exp_Other_Calc: string = "";
  public get exp_Other_Calc(): string {
    return this._exp_Other_Calc;
  }
  public set exp_Other_Calc(value: string) {
    this._exp_Other_Calc = value;
    this.totalCalc();
  }

  private _exp_Calc_Total: string = "";
  public get exp_Calc_Total(): string {
    return this._exp_Calc_Total;
  }
  public set exp_Calc_Total(value: string) {
    this._exp_Calc_Total = value;
  }

  constructor(params?: IMotorMech) {
    if (params) {
      this.applicationNo = params.applicationNo;
      this.applicantCoappRef = params.applicantCoappRef;
      this.tW_YN = params.tW_YN;
      this.fW_YN = params.fW_YN;
      this.rickTempo_YN = params.rickTempo_YN;
      this.hD_YN = params.hD_YN;
      this.others_YN = params.others_YN;
      this.shopGarageName = params.shopGarageName;
      this.number_Of_Years = params.number_Of_Years;
      this.ownership_Of_Premise = params.ownership_Of_Premise;
      this.area_SqFt = params.area_SqFt;
      this.numOfFam = params.numOfFam;
      this.numofPartners = params.numofPartners;
      this.profSharingRatio = params.profSharingRatio;
      this.numofEmplyrWorker = params.numofEmplyrWorker;
      this.wageFrequency = params.wageFrequency;
      this.locality = params.locality;
      this.physical_Asset_Details = params.physical_Asset_Details;
      this.count_Of_Asset = params.count_Of_Asset;
      this.upI_YN = params.upI_YN;
      this.numOfVehicle_TW = params.numOfVehicle_TW;
      this.numOfJobInADay_TW = params.numOfJobInADay_TW;
      this.jobsInAMonth_TW = params.jobsInAMonth_TW;
      this.avgRevenuePerJob_TW = params.avgRevenuePerJob_TW;
      this.numOfVehicle_FW = params.numOfVehicle_FW;
      this.numOfJobInADay_FW = params.numOfJobInADay_FW;
      this.jobsInAMonth_FW = params.jobsInAMonth_FW;
      this.avgRevenuePerJob_FW = params.avgRevenuePerJob_FW;
      this.numOfVehicle_RickTempo = params.numOfVehicle_RickTempo;
      this.numOfJobInADay_RickTempo = params.numOfJobInADay_RickTempo;
      this.jobsInAMonth_RickTempo = params.jobsInAMonth_RickTempo;
      this.avgRevenuePerJob_RickTempo = params.avgRevenuePerJob_RickTempo;
      this.numOfVehicle_HD = params.numOfVehicle_HD;
      this.numOfJobInADay_HD = params.numOfJobInADay_HD;
      this.jobsInAMonth_HD = params.jobsInAMonth_HD;
      this.avgRevenuePerJob_HD = params.avgRevenuePerJob_HD;
      this.numOfVehicle_Others = params.numOfVehicle_Others;
      this.numOfJobInADay_Others = params.numOfJobInADay_Others;
      this.jobsInAMonth_Others = params.jobsInAMonth_Others;
      this.avgRevenuePerJob_Others = params.avgRevenuePerJob_Others;
      this.other_Net_Income = params.other_Net_Income;
      this.other_Net_IncomeDtl = params.other_Net_IncomeDtl;
      this.exp_ShopGaragerent_Act = params.exp_ShopGaragerent_Act;
      this.exp_Electricity_Act = params.exp_Electricity_Act;
      this.exp_Consumable_Act = params.exp_Consumable_Act;
      this.exp_SalaryLabourCost_Act = params.exp_SalaryLabourCost_Act;
      this.exp_Other_Act = params.exp_Other_Act;
      this.exp_Act_Total = params.exp_Act_Total;
      this.exp_ShopGaragerent_Calc = params.exp_ShopGaragerent_Calc;
      this.exp_Electricity_Calc = params.exp_Electricity_Calc;
      this.exp_Consumable_Calc = params.exp_Consumable_Calc;
      this.exp_SalaryLabourCost_Calc = params.exp_SalaryLabourCost_Calc;
      this.exp_Other_Calc = params.exp_Other_Calc;
      this.exp_Calc_Total = params.exp_Calc_Total;
    }
  }

  toJson(): any {
    return {
      "LoanAccountNumber": "",
      "ApplicationNo": this.applicationNo,
      "ApplicantCoappRef": this.applicantCoappRef,
      "TW_YN": this.tW_YN,
      "FW_YN": this.fW_YN,
      "RickTempo_YN": this.rickTempo_YN,
      "HD_YN": this.hD_YN,
      "Others_YN": this.others_YN,
      "ShopGarageName": this.shopGarageName,
      "Number_Of_Years": this.number_Of_Years,
      "Ownership_Of_Premise": this.ownership_Of_Premise,
      "Area_SqFt": this.area_SqFt,
      "NumOfFam": this.numOfFam,
      "NumofPartners": this.numofPartners,
      "ProfSharingRatio": this.profSharingRatio,
      "NumofEmplyrWorker": this.numofEmplyrWorker,
      "WageFrequency": this.wageFrequency,
      "Locality": this.locality,
      "Physical_Asset_Details": this.physical_Asset_Details,
      "Count_Of_Asset": this.count_Of_Asset,
      "UpI_YN": this.upI_YN,
      "NumOfVehicle_TW": this.tW_YN.toUpperCase() == 'N' ? 0 : this.numOfVehicle_TW != "" ? parseFloat(this.numOfVehicle_TW) : 0,
      "NumOfJobInADay_TW": this.tW_YN.toUpperCase() == 'N' ? 0 : this.numOfJobInADay_TW != "" ? parseFloat(this.numOfJobInADay_TW) : 0,
      "JobsInAMonth_TW": this.tW_YN.toUpperCase() == 'N' ? 0 : this.jobsInAMonth_TW != "" ? parseFloat(this.jobsInAMonth_TW) : 0,
      "AvgRevenuePerJob_TW": this.tW_YN.toUpperCase() == 'N' ? 0 : this.avgRevenuePerJob_TW != "" ? parseFloat(this.avgRevenuePerJob_TW) : 0,
      "NumOfVehicle_FW": this.fW_YN.toUpperCase() == 'N' ? 0 : this.numOfVehicle_FW != "" ? parseFloat(this.numOfVehicle_FW) : 0,
      "NumOfJobInADay_FW": this.fW_YN.toUpperCase() == 'N' ? 0 : this.numOfJobInADay_FW != "" ? parseFloat(this.numOfJobInADay_FW) : 0,
      "JobsInAMonth_FW": this.fW_YN.toUpperCase() == 'N' ? 0:this.jobsInAMonth_FW != "" ? parseFloat(this.jobsInAMonth_FW) : 0,
      "AvgRevenuePerJob_FW": this.fW_YN.toUpperCase() == 'N' ? 0 : this.avgRevenuePerJob_FW != "" ? parseFloat(this.avgRevenuePerJob_FW) : 0,
      "NumOfVehicle_RickTempo": this.rickTempo_YN.toUpperCase() == 'N' ? 0 : this.numOfVehicle_RickTempo != "" ? parseFloat(this.numOfVehicle_RickTempo) : 0,
      "NumOfJobInADay_RickTempo": this.rickTempo_YN.toUpperCase() == 'N' ? 0 : this.numOfJobInADay_RickTempo != "" ? parseFloat(this.numOfJobInADay_RickTempo) : 0,
      "JobsInAMonth_RickTempo": this.rickTempo_YN.toUpperCase() == 'N' ? 0 : this.jobsInAMonth_RickTempo != "" ? parseFloat(this.jobsInAMonth_RickTempo) : 0,
      "AvgRevenuePerJob_RickTempo": this.rickTempo_YN.toUpperCase() == 'N' ? 0 : this.avgRevenuePerJob_RickTempo != "" ? parseFloat(this.avgRevenuePerJob_RickTempo) : 0,
      "NumOfVehicle_HD": this.hD_YN.toUpperCase() == 'N' ? 0 : this.numOfVehicle_HD != "" ? parseFloat(this.numOfVehicle_HD) : 0,
      "NumOfJobInADay_HD": this.hD_YN.toUpperCase() == 'N' ? 0 : this.numOfJobInADay_HD != "" ? parseFloat(this.numOfJobInADay_HD) : 0,
      "JobsInAMonth_HD": this.hD_YN.toUpperCase() == 'N' ? 0 : this.jobsInAMonth_HD != "" ? parseFloat(this.jobsInAMonth_HD) : 0,
      "AvgRevenuePerJob_HD": this.hD_YN.toUpperCase() == 'N' ? 0 : this.avgRevenuePerJob_HD != "" ? parseFloat(this.avgRevenuePerJob_HD) : 0,
      "NumOfVehicle_Others": this.others_YN.toUpperCase() == 'N' ? 0 : this.numOfVehicle_Others != "" ? parseFloat(this.numOfVehicle_Others) : 0,
      "NumOfJobInADay_Others": this.others_YN.toUpperCase() == 'N' ? 0 :this.numOfJobInADay_Others != "" ? parseFloat(this.numOfJobInADay_Others) : 0,
      "JobsInAMonth_Others": this.others_YN.toUpperCase() == 'N' ? 0 :this.jobsInAMonth_Others != "" ? parseFloat(this.jobsInAMonth_Others) : 0,
      "AvgRevenuePerJob_Others": this.others_YN.toUpperCase() == 'N' ? 0 :this.avgRevenuePerJob_Others != "" ? parseFloat(this.avgRevenuePerJob_Others) : 0,
      "Other_Net_Income": this.other_Net_Income,
      "Other_Net_IncomeDtl": this.other_Net_IncomeDtl,
      "Exp_ShopGaragerent_Act": this.exp_ShopGaragerent_Act,
      "Exp_Electricity_Act": this.exp_Electricity_Act,
      "Exp_Consumable_Act": this.exp_Consumable_Act,
      "Exp_SalaryLabourCost_Act": this.exp_SalaryLabourCost_Act,
      "Exp_Other_Act": this.exp_Other_Act,
      "Exp_Act_Total": this.exp_Act_Total,
      "Exp_ShopGaragerent_Calc": this.exp_ShopGaragerent_Act,
      "Exp_Electricity_Calc": this.exp_Electricity_Calc,
      "Exp_Consumable_Calc": this.exp_Consumable_Calc,
      "Exp_SalaryLabourCost_Calc": this.exp_SalaryLabourCost_Calc,
      "Exp_Other_Calc": this.exp_Other_Act,
      "Exp_Calc_Total": this.exp_Calc_Total,
      "FlO_PsId": "",
      "SourceThrough": ""
      // "ApplicantCoappRef": this.applicantCoappRef,
      // "Area_SqFt": this.area_SqFt,
      // "AvgRevenuePerJob": 0,
      // "Count_Of_Asset": this.count_Of_Asset,
      // "Exp_Act_Total": this.exp_Act_Total,
      // "Exp_Calc_Total": this.exp_Calc_Total,
      // "Exp_Consumable_Act": this.exp_Consumable_Act,
      // "Exp_Consumable_Calc": this.exp_Consumable_Calc,
      // "Exp_Electricity_Act": this.exp_Electricity_Act,
      // "Exp_Electricity_Calc": this.exp_Electricity_Calc,
      // "Exp_Other_Act": this.exp_Other_Act,
      // "Exp_Other_Calc": this.exp_Other_Calc,
      // "Exp_SalaryLabourCost_Act": this.exp_SalaryLabourCost_Act,
      // "Exp_SalaryLabourCost_Calc": this.exp_SalaryLabourCost_Calc,
      // "Exp_ShopGaragerent_Act": this.exp_ShopGaragerent_Act,
      // "Exp_ShopGaragerent_Calc": this.exp_ShopGaragerent_Calc,
      // "FLO_PsId": "",
      // "FW_YN": this.fW_YN,
      // "HD_YN": this.hD_YN, 
      // "LoanAccountNumber": "1234",
      // "Locality": this.locality,
      // "Number_Of_Years": this.number_Of_Years,
      // "NumofEmplyrWorker": this.numofEmplyrWorker,
      // "NumOfFam": this.numOfFam, 
      // "NumofPartners": this.numofPartners, 
      // "Other_Net_Income": this.other_Net_Income,
      // "Other_Net_IncomeDtl": this.other_Net_IncomeDtl,
      // "Others_YN": this.others_YN,
      // "Ownership_Of_Premise": this.ownership_Of_Premise,
      // "Physical_Asset_Details": this.physical_Asset_Details,
      // "ProfSharingRatio": this.profSharingRatio,
      // "RickTempo_YN": this.rickTempo_YN,
      // "ShopGarageName": this.shopGarageName,
      // "SourceThrough": "LOS",
      // "TW_YN": this.tW_YN,
      // "UPI_YN": this.upI_YN,
      // "WageFrequency": this.wageFrequency
    };
  }

  totalCalc() {

    var shoprent = 0;
    var electricityCost = 0;
    var salaryExpenses = 0;
    var otherExpenses = 0;
    var salaryLabourCost = 0;
    var totalExpense = 0;
    shoprent = this.exp_ShopGaragerent_Calc != "" ? parseFloat(this.exp_ShopGaragerent_Calc) : 0;
    electricityCost = this.exp_Electricity_Calc != "" ? parseFloat(this.exp_Electricity_Calc) : 0;
    salaryExpenses = this.exp_Consumable_Calc != "" ? parseFloat(this.exp_Consumable_Calc) : 0;
    salaryLabourCost = this.exp_SalaryLabourCost_Calc != "" ? parseFloat(this.exp_SalaryLabourCost_Calc) : 0;
    otherExpenses = this.exp_Other_Calc != "" ? parseFloat(this.exp_Other_Calc) : 0;
    totalExpense = shoprent + electricityCost + salaryExpenses + otherExpenses + salaryLabourCost;
    this.exp_Calc_Total = totalExpense.toString();
  }


}


export interface IMotorMechConficValues {
  TypeOfVehicle: string;
  AreaRequiredPerVehicle: number;
  NoOfDaysRequired: number;
  MaxRevenue: number;
  Consumables: number;
  NoOfJobPerDay: number;
  LabourPerJob: number;
}

export class MotorMechConficValues implements IMotorMechConficValues {
  TypeOfVehicle: string = '';
  AreaRequiredPerVehicle: number = 0;
  NoOfDaysRequired: number = 0;
  MaxRevenue: number = 0;
  Consumables: number = 0;
  NoOfJobPerDay: number = 0;
  LabourPerJob: number = 0;
}
import { TestBed } from '@angular/core/testing';

import { MotorMechService } from './motor-mech.service';

describe('MotorMechService', () => {
  let service: MotorMechService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MotorMechService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

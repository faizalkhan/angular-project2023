import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MotorMechComponent } from './motor-mech.component';

describe('MotorMechComponent', () => {
  let component: MotorMechComponent;
  let fixture: ComponentFixture<MotorMechComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MotorMechComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MotorMechComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

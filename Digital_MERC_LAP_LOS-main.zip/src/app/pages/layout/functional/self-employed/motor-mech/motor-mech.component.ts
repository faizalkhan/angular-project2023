import { validateHorizontalPosition } from '@angular/cdk/overlay';
import { Component, Input, OnInit } from '@angular/core';
import { partition } from 'rxjs';
import { NotificationService } from 'src/app/notification.service';
import { Dropdown, IDropdown } from 'src/app/shared/models/common/control.model';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { IMotorMech, IMotorMechConficValues, MotorMech, MotorMechConficValues } from './motor-mech.service';

@Component({
  selector: 'app-motor-mech',
  templateUrl: './motor-mech.component.html',
  styleUrls: ['./motor-mech.component.css']
})
export class MotorMechComponent implements OnInit {
  VehicleList: IDropdown[] = [
    { displayName: "Two Wheeler", value: "Two Wheeler" },
    { displayName: "Four Wheeler", value: "Four Wheeler" },
    { displayName: "Rickshaw/Tempo", value: "Rickshaw/Tempo" },
    { displayName: "Heavy Vehicle", value: "Heavy Vehicle" },
    { displayName: "Others", value: "Others" }

  ];
  isEdit: boolean = false;
  errorTag: boolean = false;
  errorMsg: string = "";
  motorMech: IMotorMech = new MotorMech();
  @Input() RequestData: any;
  readOnly: any;


  vehicleConfigValues: MotorMechConficValues[] = [];

  vehicleConfigObj: MotorMechConficValues = new MotorMechConficValues();

  constructor(private http: ConfigService, private notification: NotificationService, private sanctionService: SanctionService) { }

  ngOnInit(): void {
    this.readOnly = this.sanctionService.LanInfo.readOnly;
    this.getAPI();
  }
  checkboxChange(event: any, itemType: any) {
    this.errorMsg = "";
    this.errorTag = false;
    var maxSelctedVType = 0;
    if (this.motorMech.tW_YN === "Y" && itemType != "two") {
      maxSelctedVType++;
    }
    if (this.motorMech.fW_YN === "Y" && itemType != "four") {
      maxSelctedVType++;
    }
    if (this.motorMech.hD_YN === "Y" && itemType != "hd") {
      maxSelctedVType++;
    }
    if (this.motorMech.rickTempo_YN === "Y" && itemType != "rick") {
      maxSelctedVType++;
    }
    if (this.motorMech.others_YN === "Y" && itemType != "others") {
      maxSelctedVType++;
    }

   

    if (itemType === "two") {
      this.motorMech.tW_YN = event.currentTarget.checked ? "Y" : "N";
    }

    if (itemType === "four") {
      this.motorMech.fW_YN = event.currentTarget.checked ? "Y" : "N";
    }

    if (itemType === "rick") {
      this.motorMech.rickTempo_YN = event.currentTarget.checked ? "Y" : "N";
    }

    if (itemType === "hd") {
      this.motorMech.hD_YN = event.currentTarget.checked ? "Y" : "N";
    }
    if (itemType === "others") {
      this.motorMech.others_YN = event.currentTarget.checked ? "Y" : "N";
    }
  }
  
  getAPI() {

    this.http.httpPost<any>(this.RequestData, "GetLAP_IA_MotorMech").subscribe((res: any) => {
      this.motorMech = new MotorMech();
      if (res.errorcode == "00")
        this.motorMech = new MotorMech(res.data[0]);
    });
  }
  Submit() {
    if (!this.validateMotarMech()) {
      return;
    }

    let electricyAmount: number = this.motorMech.exp_Electricity_Act === "" ? 0 : parseFloat(this.motorMech.exp_Electricity_Act);

    if (electricyAmount > 500) {
      this.motorMech.exp_Electricity_Calc = electricyAmount.toString();
    } else {
      this.motorMech.exp_Electricity_Calc = "500";
    }

    let consumableCostAct: number = this.motorMech.exp_Consumable_Act === "" ? 0 : parseFloat(this.motorMech.exp_Consumable_Act);
    let consumableCostCalc: number = this.motorMech.exp_Consumable_Calc === "" ? 0 : parseFloat(this.motorMech.exp_Consumable_Calc);
    if (consumableCostAct > consumableCostCalc) {
      this.motorMech.exp_Consumable_Calc = consumableCostAct.toString();
    }

    let labourCostAct: number = this.motorMech.exp_SalaryLabourCost_Act === "" ? 0 : parseFloat(this.motorMech.exp_SalaryLabourCost_Act);
    let labourCostCalc: number = this.motorMech.exp_SalaryLabourCost_Calc === "" ? 0 : parseFloat(this.motorMech.exp_SalaryLabourCost_Calc);
    if (labourCostAct > labourCostCalc) {
      this.motorMech.exp_SalaryLabourCost_Calc = labourCostAct.toString();
    }

    if (this.motorMech.applicationNo === "") {
      this.motorMech.applicationNo = this.RequestData.ApplicationNo;
    }
    this.http.httpPost<any>(this.motorMech.toJson(), "LAP_IA_MotorMech").subscribe((res: any) => {
      if (res.errorcode == "01" || res.errorcode == "02") {
        this.notification.showSuccess(res.errorDescription);
        this.isEdit = false;
        this.ngOnInit();
      }
      else {
        this.notification.showError(res.errorDescription);
      }
    });
  }

  edit() {
    this.isEdit = !this.isEdit;
  }

  validateMotarMech() {

    this.vehicleConfigValues = [
      {
        TypeOfVehicle: 'two',
        AreaRequiredPerVehicle: 30,
        NoOfDaysRequired: 1,
        MaxRevenue: 800,
        Consumables: 100,
        NoOfJobPerDay: 4,
        LabourPerJob: 500
      },
      {
        TypeOfVehicle: 'four',
        AreaRequiredPerVehicle: 200,
        NoOfDaysRequired: 2,
        MaxRevenue: 2000,
        Consumables: 200,
        NoOfJobPerDay: 2,
        LabourPerJob: 1000
      },
      {
        TypeOfVehicle: 'rick',
        AreaRequiredPerVehicle: 200,
        NoOfDaysRequired: 2,
        MaxRevenue: 2000,
        Consumables: 200,
        NoOfJobPerDay: 1,
        LabourPerJob: 1000
      },
      {
        TypeOfVehicle: 'hd',
        AreaRequiredPerVehicle: 900,
        NoOfDaysRequired: 4,
        MaxRevenue: 5000,
        Consumables: 800,
        NoOfJobPerDay: 0.25,
        LabourPerJob: 3000
      },
      {
        TypeOfVehicle: 'others',
        AreaRequiredPerVehicle: 200,
        NoOfDaysRequired: 2,
        MaxRevenue: 2000,
        Consumables: 200,
        NoOfJobPerDay: 0.5,
        LabourPerJob: 1000
      }];
    this.errorMsg = "";
    this.errorTag = false;
    let totalNumberOfVehicle: number = 0;
    let totalVehicleSqlFeet: number = 0;
    let totalAreaofGarage: number = 0;
    let maxNumberOfVehicleAllowed: number = 0;
    let remainingAvailabelGarageSpace: number = 0;
    let minJobDay: number = 0;
    let maxJobInAMonth: number = 0;
    let jobInAMonthByType: number = 0;
    let averageRevenuePerJob: number = 0;
    let consumableCost: number = 0;
    let otherCost: number = 0;
    let minJobInAMonth: number = 0;
    let labourJobCost: number = 0;
    let actConsumableCost: number = 0;
    let actLabourCost: number = 0;

    /* one type of vehicle selection is mandatory */
    if ((this.motorMech.tW_YN === "N" && this.motorMech.fW_YN === "N"
      && this.motorMech.rickTempo_YN === "N" && this.motorMech.hD_YN === "N" && this.motorMech.others_YN === "N") ||
      ((this.motorMech.tW_YN === "" && this.motorMech.fW_YN === ""
        && this.motorMech.rickTempo_YN === "" && this.motorMech.hD_YN === "" && this.motorMech.others_YN === ""))
    ) {
      this.errorTag = true;
      this.errorMsg = "Please select any one vehicle type";
      this.notification.showWarning(this.errorMsg);
      return false;
    }

    /**sharing ratio */
    if (this.motorMech.numofPartners != 0) {
      if (this.motorMech.profSharingRatio === "0" || this.motorMech.profSharingRatio.length == 0) {
        this.errorTag = true;
        this.errorMsg = "Please enter Profit sharing Ratio for customer in %";
        this.notification.showWarning(this.errorMsg);
        return false;
      }
    }

    /* Garage sq feet */
    if (this.motorMech.area_SqFt.trim() === "") {
      this.errorTag = true;
      this.errorMsg = "Please specify the total area of garage - in Sq Ft";
      this.notification.showWarning(this.errorMsg);
      return false;
    }

    /*Rent */
    if (this.motorMech.ownership_Of_Premise === 'Rented') {
      if (this.motorMech.exp_ShopGaragerent_Act.length === 0 || this.motorMech.exp_ShopGaragerent_Act === "" || this.motorMech.exp_ShopGaragerent_Act === "0") {
        this.errorTag = true;
        this.errorMsg = "Please specify the rent";
        this.notification.showWarning(this.errorMsg);
        return false;
      }
    }


    if (this.motorMech.area_SqFt.trim() !== "") {
      totalAreaofGarage = parseFloat(this.motorMech.area_SqFt);
      remainingAvailabelGarageSpace = totalAreaofGarage;
    }

    if (this.motorMech.tW_YN == 'Y') {
      let vehicleConfig = this.vehicleConfigValues.find(x => x.TypeOfVehicle == "two");
      if (!vehicleConfig) {
        this.errorTag = true;
        this.errorMsg = "Please contact admin. Configuration is missing";
        this.notification.showWarning(this.errorMsg);
        return false;
      }
      if (this.motorMech.numOfVehicle_TW.trim() !== "") {
        totalNumberOfVehicle = parseInt(this.motorMech.numOfVehicle_TW);
      }

      if (totalNumberOfVehicle === 0) {
        this.errorTag = true;
        this.errorMsg = "Please Specify No. of vehicle available in garage for service/repair";
        this.notification.showWarning(this.errorMsg);
        return false;
      }

      maxNumberOfVehicleAllowed = Math.round(totalAreaofGarage / vehicleConfig.AreaRequiredPerVehicle);
      if (totalNumberOfVehicle > 0 && totalNumberOfVehicle > maxNumberOfVehicleAllowed) {
        this.errorTag = true;
        this.errorMsg = "Maximum number of allowed two wheeler vehicle is " + maxNumberOfVehicleAllowed.toString();
        this.notification.showWarning(this.errorMsg);
        return false;
      }

      /* Min Job in a day */
      if (this.motorMech.numOfJobInADay_TW.trim() !== "") {
        minJobDay = parseInt(this.motorMech.numOfJobInADay_TW);
        if (minJobDay <= 0) {
          this.errorTag = true;
          this.errorMsg = "Two wheeler - Minimum number of job in a day should be 1 ";
          this.notification.showWarning(this.errorMsg);
          return false;
        }

        let twoMinJobDay = vehicleConfig.NoOfDaysRequired;
        if(minJobDay<twoMinJobDay){
            this.errorTag = true;
            this.errorMsg = "Two wheeler - Minimum number of job in a day should be 1 ";
            this.notification.showWarning(this.errorMsg);
            return false;
        }
      }  
      /* Job in a month */
      maxJobInAMonth = maxNumberOfVehicleAllowed * (25 / vehicleConfig.NoOfDaysRequired);
      if (this.motorMech.jobsInAMonth_TW.trim() !== "") {
        jobInAMonthByType = parseInt(this.motorMech.jobsInAMonth_TW);
        if (jobInAMonthByType > maxJobInAMonth) {
          this.errorTag = true;
          this.errorMsg = "Two wheeler - Maximum number of job in a month should be  " + maxJobInAMonth.toString();
          this.notification.showWarning(this.errorMsg);
          return false;
        }
      }

      /* Average revenue per job */

      if (this.motorMech.avgRevenuePerJob_FW.trim() !== "") {
        averageRevenuePerJob = parseInt(this.motorMech.avgRevenuePerJob_TW);
        if (averageRevenuePerJob > vehicleConfig.MaxRevenue) {
          this.errorTag = true;
          this.errorMsg = "Two wheeler - Maximum Average revenue per job should be 800 ";
          this.notification.showWarning(this.errorMsg);
          return false;
        }
      }

      if (jobInAMonthByType > maxJobInAMonth) {
        consumableCost = vehicleConfig.Consumables * maxJobInAMonth;
      }
      else {
        consumableCost = vehicleConfig.Consumables * jobInAMonthByType;
      }
      // Calulate the Other cost.
      otherCost = 25 * vehicleConfig.NoOfJobPerDay;

      if (maxJobInAMonth > otherCost) {
        if (jobInAMonthByType > maxJobInAMonth) {
          minJobInAMonth = maxJobInAMonth;
        }
        else {
          minJobInAMonth = jobInAMonthByType
        }
        labourJobCost = (minJobInAMonth - otherCost) * vehicleConfig.LabourPerJob;
      }
      totalVehicleSqlFeet = totalNumberOfVehicle * vehicleConfig.AreaRequiredPerVehicle;
      remainingAvailabelGarageSpace = totalAreaofGarage - totalVehicleSqlFeet;
    }
    if (this.motorMech.fW_YN == 'Y') {
      let vehicleConfig = this.vehicleConfigValues.find(x => x.TypeOfVehicle == "four");
      if (!vehicleConfig) {
        this.errorTag = true;
        this.errorMsg = "Please contact admin. Configuration is missing";
        this.notification.showWarning(this.errorMsg);
        return false;
      }
      if (this.motorMech.numOfVehicle_FW.trim() !== "") {
        totalNumberOfVehicle = parseInt(this.motorMech.numOfVehicle_FW);
      }

      if (totalNumberOfVehicle === 0) {
        this.errorTag = true;
        this.errorMsg = "Please Specify No. of vehicle available in garage for service/repair";
        this.notification.showWarning(this.errorMsg);
        return false;
      }


      maxNumberOfVehicleAllowed = Math.round(remainingAvailabelGarageSpace / vehicleConfig.AreaRequiredPerVehicle);
      if (totalNumberOfVehicle > 0 && totalNumberOfVehicle > maxNumberOfVehicleAllowed) {
        this.errorTag = true;
        this.errorMsg = "Maximum number of allowed four wheeler vehicle is " + maxNumberOfVehicleAllowed.toString();
        this.notification.showWarning(this.errorMsg);
        return false;
      }

      /* Min Job in a day */
      if (this.motorMech.numOfJobInADay_FW.trim() !== "") {
        minJobDay = parseInt(this.motorMech.numOfJobInADay_FW);
        if (minJobDay <= 0) {
          this.errorTag = true;
          this.errorMsg = "Four wheeler - Minimum number of job in a day should be 2 ";
          this.notification.showWarning(this.errorMsg);
          return false;
        }
      }

      let fwMinJobDay = vehicleConfig.NoOfDaysRequired;
      if(minJobDay<fwMinJobDay){
          this.errorTag = true;
          this.errorMsg = "Four wheeler - Minimum number of job in a day should be 2 ";
          this.notification.showWarning(this.errorMsg);
          return false;
      }

      /* Job in a month */
      maxJobInAMonth = maxNumberOfVehicleAllowed * (25 / vehicleConfig.NoOfDaysRequired);
      if (this.motorMech.jobsInAMonth_FW.trim() !== "") {
        jobInAMonthByType = parseInt(this.motorMech.jobsInAMonth_FW);
        if (jobInAMonthByType > maxJobInAMonth) {
          this.errorTag = true;
          this.errorMsg = "Four wheeler - Maximum number of job in a month should be  " + maxJobInAMonth.toString();
          this.notification.showWarning(this.errorMsg);
          return false;
        }
      }

      /* Average revenue per job */

      if (this.motorMech.avgRevenuePerJob_FW.trim() !== "") {
        averageRevenuePerJob = parseInt(this.motorMech.avgRevenuePerJob_FW);
        if (averageRevenuePerJob > vehicleConfig.MaxRevenue) {
          this.errorTag = true;
          this.errorMsg = "Four wheeler - Maximum Average revenue per job should be 2000 ";
          this.notification.showWarning(this.errorMsg);
          return false;
        }
      }

      if (jobInAMonthByType > maxJobInAMonth) {
        consumableCost = consumableCost + (vehicleConfig.Consumables * maxJobInAMonth);
      }
      else {
        consumableCost = consumableCost + (vehicleConfig.Consumables * jobInAMonthByType);
      }



      otherCost = 25 * vehicleConfig.NoOfDaysRequired;
      if (maxJobInAMonth > otherCost) {
        if (jobInAMonthByType > maxJobInAMonth) {
          minJobInAMonth = maxJobInAMonth;
        }
        else {
          minJobInAMonth = jobInAMonthByType
        }
        labourJobCost = labourJobCost + (minJobInAMonth - otherCost) * vehicleConfig.LabourPerJob;
      }


      totalVehicleSqlFeet = totalNumberOfVehicle * vehicleConfig.AreaRequiredPerVehicle;
      remainingAvailabelGarageSpace = remainingAvailabelGarageSpace - totalVehicleSqlFeet;
    }
    if (this.motorMech.rickTempo_YN == 'Y') {
      let vehicleConfig = this.vehicleConfigValues.find(x => x.TypeOfVehicle == "rick");
      if (!vehicleConfig) {
        this.errorTag = true;
        this.errorMsg = "Please contact admin. Configuration is missing";
        this.notification.showWarning(this.errorMsg);
        return false;
      }
      totalNumberOfVehicle = 0;

      if (this.motorMech.numOfVehicle_RickTempo.trim() !== "") {
        totalNumberOfVehicle = parseInt(this.motorMech.numOfVehicle_RickTempo);
      }

      if (totalNumberOfVehicle === 0) {
        this.errorTag = true;
        this.errorMsg = "Please Specify No. of vehicle available in garage for service/repair";
        this.notification.showWarning(this.errorMsg);
        return false;
      }


      maxNumberOfVehicleAllowed = Math.round(remainingAvailabelGarageSpace / vehicleConfig.AreaRequiredPerVehicle);
      if (totalNumberOfVehicle > 0 && totalNumberOfVehicle > maxNumberOfVehicleAllowed) {
        this.errorTag = true;
        this.errorMsg = "Maximum number of allowed rickshaw tempo vehicle is " + maxNumberOfVehicleAllowed.toString();
        this.notification.showWarning(this.errorMsg);
        return false;
      }

      /* Min Job in a day */
      if (this.motorMech.numOfJobInADay_RickTempo.trim() !== "") {
        minJobDay = parseInt(this.motorMech.numOfJobInADay_RickTempo);
        if (minJobDay <= 0) {
          this.errorTag = true;
          this.errorMsg = "Rickshaw tempo - Minimum number of job in a day should be 2 ";
          this.notification.showWarning(this.errorMsg);
          return false;
        }
      }
 
      let rtMinJobDay = vehicleConfig.NoOfDaysRequired;
      if(minJobDay<rtMinJobDay){
          this.errorTag = true;
          this.errorMsg = "Rickshaw tempo - Minimum number of job in a day should be 2 ";
          this.notification.showWarning(this.errorMsg);
          return false;
      }

      /* Job in a month */
      maxJobInAMonth = maxNumberOfVehicleAllowed * (25 / vehicleConfig.NoOfDaysRequired);
      if (this.motorMech.jobsInAMonth_RickTempo.trim() !== "") {
        jobInAMonthByType = parseInt(this.motorMech.jobsInAMonth_RickTempo);
        if (jobInAMonthByType > maxJobInAMonth) {
          this.errorTag = true;
          this.errorMsg = "Rickshaw tempo - Maximum number of job in a month should be  " + maxJobInAMonth.toString();
          this.notification.showWarning(this.errorMsg);
          return false;
        }
      }

      /* Average revenue per job */

      if (this.motorMech.avgRevenuePerJob_RickTempo.trim() !== "") {
        averageRevenuePerJob = parseInt(this.motorMech.avgRevenuePerJob_RickTempo);
        if (averageRevenuePerJob > vehicleConfig.MaxRevenue) {
          this.errorTag = true;
          this.errorMsg = "Rickshaw tempo - Maximum Average revenue per job should be 2000 ";
          this.notification.showWarning(this.errorMsg);
          return false;
        }
      }

      if (jobInAMonthByType > maxJobInAMonth) {
        consumableCost = consumableCost + (vehicleConfig.Consumables * maxJobInAMonth);
      }
      else {
        consumableCost = consumableCost + (vehicleConfig.Consumables * jobInAMonthByType);
      }
      //this.motorMech.exp_Consumable_Calc = consumableCost.toString();


      otherCost = 25 * 1;
      if (maxJobInAMonth > otherCost) {
        if (jobInAMonthByType > maxJobInAMonth) {
          minJobInAMonth = maxJobInAMonth;
        }
        else {
          minJobInAMonth = jobInAMonthByType
        }
        labourJobCost = labourJobCost + (minJobInAMonth - otherCost) * 1000;
      }


      totalVehicleSqlFeet = totalNumberOfVehicle * vehicleConfig.AreaRequiredPerVehicle;
      remainingAvailabelGarageSpace = remainingAvailabelGarageSpace - totalVehicleSqlFeet;
    }
    if (this.motorMech.hD_YN == 'Y') {
      
      let vehicleConfig = this.vehicleConfigValues.find(x => x.TypeOfVehicle == "hd");
      if (!vehicleConfig) {
        this.errorTag = true;
        this.errorMsg = "Please contact admin. Configuration is missing";
        this.notification.showWarning(this.errorMsg);
        return false;
      }
      totalNumberOfVehicle = 0;

      if (this.motorMech.numOfVehicle_HD.trim() !== "") {
        totalNumberOfVehicle = parseInt(this.motorMech.numOfVehicle_HD);
      }

      if (totalNumberOfVehicle === 0) {
        this.errorTag = true;
        this.errorMsg = "Please Specify No. of vehicle available in garage for service/repair";
        this.notification.showWarning(this.errorMsg);
        return false;
      }


      maxNumberOfVehicleAllowed = Math.round(remainingAvailabelGarageSpace / vehicleConfig.AreaRequiredPerVehicle);
      if (totalNumberOfVehicle > 0 && totalNumberOfVehicle > maxNumberOfVehicleAllowed) {
        this.errorTag = true;
        this.errorMsg = "Maximum number of allowed heavy duty vehicle is " + maxNumberOfVehicleAllowed.toString();
        this.notification.showWarning(this.errorMsg);
        return false;
      }

      /* Min Job in a day */
      if (this.motorMech.numOfJobInADay_HD.trim() !== "") {
        minJobDay = parseInt(this.motorMech.numOfJobInADay_HD);
        if (minJobDay <= 0) {
          this.errorTag = true;
          this.errorMsg = "Heavy duty vehicle - Minimum number of job in a day should be 4 ";
          this.notification.showWarning(this.errorMsg);
          return false;
        }
      }

      let hdMinJobDay = vehicleConfig.NoOfDaysRequired;
      if(minJobDay<hdMinJobDay){
          this.errorTag = true;
          this.errorMsg = "Heavy duty - Minimum number of job in a day should be 4 ";
          this.notification.showWarning(this.errorMsg);
          return false;
      }

      /* Job in a month */
      maxJobInAMonth = maxNumberOfVehicleAllowed * (25 / vehicleConfig.NoOfDaysRequired);
      if (this.motorMech.jobsInAMonth_HD.trim() !== "") {
        jobInAMonthByType = parseInt(this.motorMech.jobsInAMonth_HD);
        if (jobInAMonthByType > maxJobInAMonth) {
          this.errorTag = true;
          this.errorMsg = "Heavy duty vehicle - Maximum number of job in a month should be  " + maxJobInAMonth.toString();
          this.notification.showWarning(this.errorMsg);
          return false;
        }
      }

      /* Average revenue per job */

      if (this.motorMech.avgRevenuePerJob_HD.trim() !== "") {
        averageRevenuePerJob = parseInt(this.motorMech.avgRevenuePerJob_HD);
        if (averageRevenuePerJob > vehicleConfig.MaxRevenue) {
          this.errorTag = true;
          this.errorMsg = "Heavy duty vehicle - Maximum Average revenue per job should be " + vehicleConfig.MaxRevenue;
          this.notification.showWarning(this.errorMsg);
          return false;
        }
      }

      if (jobInAMonthByType > maxJobInAMonth) {
        consumableCost = consumableCost + (vehicleConfig.Consumables * maxJobInAMonth);
      }
      else {
        consumableCost = consumableCost + (vehicleConfig.Consumables * jobInAMonthByType);
      }
      // this.motorMech.exp_Consumable_Calc = consumableCost.toString();


      otherCost = 25 * 0.25;
      if (maxJobInAMonth > otherCost) {
        if (jobInAMonthByType > maxJobInAMonth) {
          minJobInAMonth = maxJobInAMonth;
        }
        else {
          minJobInAMonth = jobInAMonthByType
        }
        labourJobCost = labourJobCost + (minJobInAMonth - otherCost) * vehicleConfig.LabourPerJob;
      }



      totalVehicleSqlFeet = totalNumberOfVehicle * vehicleConfig.AreaRequiredPerVehicle;
      remainingAvailabelGarageSpace = remainingAvailabelGarageSpace - totalVehicleSqlFeet;
    }
    if (this.motorMech.others_YN == 'Y') {
      totalNumberOfVehicle = 0;
      totalNumberOfVehicle = 0;
      let vehicleConfig = this.vehicleConfigValues.find(x => x.TypeOfVehicle == "others");
      if (!vehicleConfig) {
        this.errorTag = true;
        this.errorMsg = "Please contact admin. Configuration is missing";
        this.notification.showWarning(this.errorMsg);
        return false;
      }
      if (this.motorMech.numOfVehicle_Others.trim() !== "") {
        totalNumberOfVehicle = parseInt(this.motorMech.numOfVehicle_Others);
      }

      if (totalNumberOfVehicle === 0) {
        this.errorTag = true;
        this.errorMsg = "Please Specify No. of vehicle available in garage for service/repair";
        this.notification.showWarning(this.errorMsg);
        return false;
      }


      maxNumberOfVehicleAllowed = Math.round(remainingAvailabelGarageSpace / vehicleConfig.AreaRequiredPerVehicle);
      if (totalNumberOfVehicle > 0 && totalNumberOfVehicle > maxNumberOfVehicleAllowed) {
        this.errorTag = true;
        this.errorMsg = "Maximum number of allowed other vehicle is " + maxNumberOfVehicleAllowed.toString();
        this.notification.showWarning(this.errorMsg);
        return false;
      }

      /* Min Job in a day */
      if (this.motorMech.numOfJobInADay_Others.trim() !== "") {
        minJobDay = parseInt(this.motorMech.numOfJobInADay_Others);
        if (minJobDay <= 0) {
          this.errorTag = true;
          this.errorMsg = "Other - Minimum number of job in a day should be " + vehicleConfig.NoOfDaysRequired.toString();
          this.notification.showWarning(this.errorMsg);
          return false;
        }
      }

      let otMinJobDay = vehicleConfig.NoOfDaysRequired;
      if(minJobDay<otMinJobDay){
          this.errorTag = true;
          this.errorMsg = "Other - Minimum number of job in a day should be "+ vehicleConfig.NoOfDaysRequired.toString();
          this.notification.showWarning(this.errorMsg);
          return false;
      }

      /* Job in a month */
      maxJobInAMonth = maxNumberOfVehicleAllowed * (25 / vehicleConfig.NoOfDaysRequired);
      if (this.motorMech.jobsInAMonth_Others.trim() !== "") {
        jobInAMonthByType = parseInt(this.motorMech.jobsInAMonth_Others);
        if (jobInAMonthByType > maxJobInAMonth) {
          this.errorTag = true;
          this.errorMsg = "Other - Maximum number of job in a month should be  " + maxJobInAMonth.toString();
          this.notification.showWarning(this.errorMsg);
          return false;
        }
      }

      /* Average revenue per job */

      if (this.motorMech.avgRevenuePerJob_Others.trim() !== "") {
        averageRevenuePerJob = parseInt(this.motorMech.avgRevenuePerJob_Others);
        if (averageRevenuePerJob > vehicleConfig.MaxRevenue) {
          this.errorTag = true;
          this.errorMsg = "Other - Maximum Average revenue per job should be " + vehicleConfig.MaxRevenue;
          this.notification.showWarning(this.errorMsg);
          return false;
        }
      }

      if (jobInAMonthByType > maxJobInAMonth) {
        consumableCost = consumableCost + (vehicleConfig.Consumables * maxJobInAMonth);
      }
      else {
        consumableCost = consumableCost + (vehicleConfig.Consumables * jobInAMonthByType);
      }

      otherCost = 25 * vehicleConfig.NoOfJobPerDay;
      if (maxJobInAMonth > otherCost) {
        if (jobInAMonthByType > maxJobInAMonth) {
          minJobInAMonth = maxJobInAMonth;
        }
        else {
          minJobInAMonth = jobInAMonthByType
        }
        labourJobCost = labourJobCost + (minJobInAMonth - otherCost) * vehicleConfig.LabourPerJob;
      }
      totalVehicleSqlFeet = totalNumberOfVehicle * vehicleConfig.AreaRequiredPerVehicle;
      remainingAvailabelGarageSpace = remainingAvailabelGarageSpace - totalVehicleSqlFeet;
    }
    // var electricityRate = parseInt(this.motorMech.exp_Electricity_Act);
    // if (electricityRate < 500) {
    //   this.errorTag = true;
    //   this.errorMsg = "Minimum electricity expense should be 500";
    //   this.notification.showWarning(this.errorMsg);
    //   return false;
    // }
    // if (this.motorMech.exp_Consumable_Act.trim() !== "") {
    //   actConsumableCost = parseFloat(this.motorMech.exp_Consumable_Act);
    //   if (actConsumableCost < consumableCost) {
    //     this.errorTag = true;
    //     this.errorMsg = "Consumable minimum cost should be " + consumableCost;
    //     this.notification.showWarning(this.errorMsg);
    //     return false;
    //   }
    // }
    // if (this.motorMech.exp_SalaryLabourCost_Act.trim() != "") {
    //   actLabourCost = parseFloat(this.motorMech.exp_SalaryLabourCost_Act);
    //   if (actLabourCost < labourJobCost) {
    //     this.errorTag = true;
    //     this.errorMsg = "Labour job minimum cost should be " + labourJobCost.toString();
    //     this.notification.showWarning(this.errorMsg);
    //     return false;
    //   }
    // }

    this.motorMech.exp_Consumable_Calc = consumableCost.toString();
    this.motorMech.exp_SalaryLabourCost_Calc = labourJobCost.toString();

    return true;
  }

  getPerVehicleSqlFeet(items: MotorMechConficValues[], key: any) {
    return 0;
  }

  PADChange(event: any) {
    this.motorMech.physical_Asset_Details = event.currentTarget.checked
  }

  upiChange(event: any) {
    this.motorMech.upI_YN = event.currentTarget.checked
  }

  //Dropdown values
  //Wages frequency of Employee/Worker
  LocalityList: IDropdown[] = [
    new Dropdown({ displayName: "Main market" }),
    new Dropdown({ displayName: "Near by market" }),
    new Dropdown({ displayName: "Outside area" }),
    new Dropdown({ displayName: "Others" })];

}

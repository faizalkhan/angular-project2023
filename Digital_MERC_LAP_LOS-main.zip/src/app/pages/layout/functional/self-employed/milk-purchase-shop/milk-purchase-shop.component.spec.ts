import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MilkPurchaseShopComponent } from './milk-purchase-shop.component';

describe('MilkPurchaseShopComponent', () => {
  let component: MilkPurchaseShopComponent;
  let fixture: ComponentFixture<MilkPurchaseShopComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MilkPurchaseShopComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MilkPurchaseShopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

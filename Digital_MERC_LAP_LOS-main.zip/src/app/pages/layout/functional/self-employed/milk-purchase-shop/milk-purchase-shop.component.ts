import { ThisReceiver } from '@angular/compiler';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NotificationService } from 'src/app/notification.service';
import { common } from 'src/app/shared/models/common';
import { DairyAndAlliedModel, IDairyAndAlliedModel, MilkPurchaseConfigValues } from 'src/app/shared/models/sanction/DairyAndAlliedModel';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { Ifile, IfileUpload } from '../../../button/upload-view-download/upload-view-download.service';

@Component({
  selector: 'app-milk-purchase-shop',
  templateUrl: './milk-purchase-shop.component.html',
  styleUrls: ['./milk-purchase-shop.component.css']
})
export class MilkPurchaseShopComponent implements OnInit {
  @Input() SelfEmployed: IDairyAndAlliedModel = new DairyAndAlliedModel();
  @Output("Submit") OnSubmit = new EventEmitter<IDairyAndAlliedModel>();
  @Output("Edit") OnEditable = new EventEmitter<boolean>();
  isEdit: boolean = false;
  errorTag: boolean = false;
  errorMsg: string = "";
  readOnly: any;
  milkPurchaseConfigValues: MilkPurchaseConfigValues[] = [];

  constructor(private notify: NotificationService, private sanctionService: SanctionService) { }

  ngOnInit(): void {
    this.readOnly = this.sanctionService.LanInfo.readOnly;
  }

  upload(event: IfileUpload): Ifile {
    return { extension: event.extension, file: event.imageData, filename: event.name, format: event.imageMIMEType } as Ifile;
  }
  StorageChange(event: any) {
    if (event.currentTarget.value == "Big")
      this.SelfEmployed.p_BigTank_YN = event.currentTarget.checked ? 'Y' : 'N';
    if (event.currentTarget.value == "Small")
      this.SelfEmployed.p_SmallTank_YN = event.currentTarget.checked ? 'Y' : 'N';
    if (event.currentTarget.value == "MixTank")
      this.SelfEmployed.p_MixTank_YN = event.currentTarget.checked ? 'Y' : 'N';
    if (event.currentTarget.value == "NonRefg")
      this.SelfEmployed.p_NonRefTAnk_YN = event.currentTarget.checked ? 'Y' : 'N';
  }

  ValidatePurchase() {

    this.milkPurchaseConfigValues = [
      new MilkPurchaseConfigValues({ tankType: "Small", quantity: 200, electricity: 800 }),
      new MilkPurchaseConfigValues({ tankType: "Big", quantity: 400, electricity: 1200 }),
      new MilkPurchaseConfigValues({ tankType: "Mix", quantity: 0, electricity: 250 }),
      new MilkPurchaseConfigValues({ tankType: "NonRefg", quantity: 150, electricity: 0 }),
    ]
    const pattern = /^[6-9][0-9]{0,10}$/;
    if (this.SelfEmployed.typeOfBusiness === "Purchase from milkman and sale") {
    if (this.SelfEmployed.p_NumOfPartness != 0) {
      if (this.SelfEmployed.p_ProfSharingRatio === "0" || this.SelfEmployed.p_ProfSharingRatio.length == 0) {
        this.errorTag = true;
        this.errorMsg = "Please enter Profit sharing Ratio for customer in %";
        this.notify.showWarning(this.errorMsg);
        return false;
      }
    }

    if (this.SelfEmployed.p_NumofMilkmanSupplier>0){
      if (this.SelfEmployed.p_Name_Top1 === "") {
        this.errorTag = true;
        this.errorMsg = "Please specify the top1 suppplier name";
        this.notify.showWarning(this.errorMsg);
        return false;
      }

      if (this.SelfEmployed.p_Contact_Top1 === "") {
        this.errorTag = true;
        this.errorMsg = "Please specify the top1 supplier contact details";
        this.notify.showWarning(this.errorMsg);
        return false;
      }

      if (!common.isValid_MobileNo(this.SelfEmployed.p_Contact_Top1)) {
        this.notify.showWarning("Please enter valid contact number for the top1 supplier")
      }

      // var value = this.SelfEmployed.p_Contact_Top1;
      // if (!pattern.test(value)) {
      //     //(this.ControlInput = value = '');
      //     this.notify.showWarning("Please enter valid contact number for the top1 supplier");
      //     return false;
      // }
 

      // if (this.SelfEmployed.p_Address_Top1 === "") {
      //   this.errorTag = true;
      //   this.errorMsg = "Please specify the top1 supplier address";
      //   this.notify.showWarning(this.errorMsg);
      //   return false;
      // }

      if (this.SelfEmployed.p_NumofMilkmanSupplier > 1) {

        if (this.SelfEmployed.p_Name_Top2 === "") {
          this.errorTag = true;
          this.errorMsg = "Please specify the top2 Supplier name";
          this.notify.showWarning(this.errorMsg);
          return false;
        }

        if (this.SelfEmployed.p_Contact_Top2 === "") {
          this.errorTag = true;
          this.errorMsg = "Please specify the top2 supplier contact details";
          this.notify.showWarning(this.errorMsg);
          return false;
        }

        if (!common.isValid_MobileNo(this.SelfEmployed.p_Contact_Top2)) {
      //  value = this.SelfEmployed.p_Contact_Top2;
      //   if (!pattern.test(value)) {
            //(this.ControlInput = value = '');
            this.notify.showWarning("Please enter valid contact number for the top2 supplier");
            return false;
        }

        // if (this.SelfEmployed.p_Address_Top2 === "") {
        //   this.errorTag = true;
        //   this.errorMsg = "Please specify the top2 supplier address";
        //   this.notify.showWarning(this.errorMsg);
        //   return false;
        // }
      }  

    } 
 
    if(this.SelfEmployed.p_Contact_Top1!==""){
      if (!common.isValid_MobileNo(this.SelfEmployed.p_Contact_Top1)) {
      // value = this.SelfEmployed.p_Contact_Top1;
      // if (!pattern.test(value)) {
          //(this.ControlInput = value = '');
          this.notify.showWarning("Please enter valid contact number for the top1 supplier");
          return false;
      }
    }

    if(this.SelfEmployed.p_Contact_Top2!==""){
      if (!common.isValid_MobileNo(this.SelfEmployed.p_Contact_Top2)) {
      // value = this.SelfEmployed.p_Contact_Top2;
      // if (!pattern.test(value)) {
          //(this.ControlInput = value = '');
          this.notify.showWarning("Please enter valid contact number for the top2 supplier");
          return false;
      }
    }
         

    let totalMilkPurchasedFromMilkMan: number = this.SelfEmployed.p_QtyOfMilkPurchase === "" ? 0 : parseInt(this.SelfEmployed.p_QtyOfMilkPurchase);
    if (totalMilkPurchasedFromMilkMan === 0) {
      this.errorTag = true;
      this.errorMsg = "Please speicify the Total quantity of milk purchased from milkman's - Daily";
      this.notify.showWarning(this.errorMsg);
      return false;
    }

    let totalQuntityConsumables = 0;
    let totalElectricty = 0; 
    if (this.SelfEmployed.p_BigTank_YN === 'Y') {
      let bigConfig = this.milkPurchaseConfigValues.find(x => x.tankType === "Big")
      if (bigConfig) {
        totalQuntityConsumables = totalQuntityConsumables + bigConfig.quantity;
        totalElectricty = totalElectricty + bigConfig.electricity;
      }
    }

    if (this.SelfEmployed.p_BigTank_YN === 'N' && this.SelfEmployed.p_SmallTank_YN === 'N' &&
      this.SelfEmployed.p_MixTank_YN === 'N' && this.SelfEmployed.p_NonRefTAnk_YN === "N") {
      this.errorTag = true;
      this.errorMsg = "Please select any one storage equipment";
      this.notify.showWarning(this.errorMsg);
      return false;
    }



    if (this.SelfEmployed.p_SmallTank_YN === 'Y') {
      let smallConfig = this.milkPurchaseConfigValues.find(x => x.tankType === "Small")
      if (smallConfig) {
        totalQuntityConsumables = totalQuntityConsumables + smallConfig.quantity;
        totalElectricty = totalElectricty + smallConfig.electricity;
      }
    }

    if (this.SelfEmployed.p_MixTank_YN === 'Y') {
      let mixConfig = this.milkPurchaseConfigValues.find(x => x.tankType === "Mix")
      if (mixConfig) {
        totalQuntityConsumables = totalQuntityConsumables + mixConfig.quantity;
        totalElectricty = totalElectricty + mixConfig.electricity;
      }
    }


    if (this.SelfEmployed.p_NonRefTAnk_YN === 'Y') {
      let NonRefgConfig = this.milkPurchaseConfigValues.find(x => x.tankType === "NonRefg")
      if (NonRefgConfig) {
        totalQuntityConsumables = totalQuntityConsumables + NonRefgConfig.quantity;
        totalElectricty = totalElectricty + NonRefgConfig.electricity;
      }
    }

    let totalQtyPurchasedFromMilkMan = this.SelfEmployed.p_QtyOfMilkPurchase === "" ? 0 : parseInt(this.SelfEmployed.p_QtyOfMilkPurchase);
    if (totalQtyPurchasedFromMilkMan === 0) {
      this.errorTag = true;
      this.errorMsg = "Please specify the Total quantity of milk purchased from milkman's - Daily";
      this.notify.showWarning(this.errorMsg);
      return false;
    }


    let remainingConsumableQty = totalQtyPurchasedFromMilkMan;
    if(totalQtyPurchasedFromMilkMan>totalQuntityConsumables){ 
      remainingConsumableQty =totalQuntityConsumables ;
    } 
    
    let p_Milk_Qty = this.SelfEmployed.p_Milk_Qty;
    if (parseFloat(p_Milk_Qty.toString()) > remainingConsumableQty) {
      this.errorTag = true;
      this.errorMsg = "Total quantity of milk should not exceed to " + remainingConsumableQty.toString();
      this.notify.showWarning(this.errorMsg);
      return false;
    }
    remainingConsumableQty = remainingConsumableQty - p_Milk_Qty;

    let p_Milk_Price = this.SelfEmployed.p_Milk_Price;
    if (p_Milk_Qty>0 &&  (p_Milk_Price <= 0 || p_Milk_Price > 50)) {
      this.errorTag = true;
      this.errorMsg = "Milk Price should be between 1 and 50";
      this.notify.showWarning(this.errorMsg);
      return false;
    }

    let p_Curd_Qty = this.SelfEmployed.p_Curd_Qty;
    let p_Curd_Qty_permisable = remainingConsumableQty / 1.3;
    if (p_Curd_Qty > p_Curd_Qty_permisable) {
      this.errorTag = true;
      this.errorMsg = "Total quantity of curd should not exceed to " + p_Curd_Qty_permisable.toString();
      this.notify.showWarning(this.errorMsg);
      return false;
    }
    remainingConsumableQty = remainingConsumableQty - (p_Curd_Qty * 1.3);

    let p_Curd_Price = this.SelfEmployed.p_Curd_Price;
    if (p_Curd_Qty>0 && (p_Curd_Price <= 0 || p_Curd_Price > 80)) {
      this.errorTag = true;
      this.errorMsg = "Curd Price should be between 1 and 80";
      this.notify.showWarning(this.errorMsg);
      return false;
    }

    let p_ghee_Qty = this.SelfEmployed.p_Ghee_Qty;
    let p_Ghee_Qty_permisable = remainingConsumableQty / 8;
    if (p_ghee_Qty > p_Ghee_Qty_permisable) {
      this.errorTag = true;
      this.errorMsg = "Total quantity of ghee should not exceed to " + p_Ghee_Qty_permisable.toString();
      this.notify.showWarning(this.errorMsg);
      return false;
    }
    remainingConsumableQty = remainingConsumableQty - (p_ghee_Qty * 8);

    let p_Ghee_Price = this.SelfEmployed.p_Ghee_Price;
    if (p_ghee_Qty>0 && (p_Ghee_Price <= 1 || p_Ghee_Price > 750)) {
      this.errorTag = true;
      this.errorMsg = "Ghee Price should be between 1 and 750";
      this.notify.showWarning(this.errorMsg);
      return false;
    }

    let p_paneer_Qty = this.SelfEmployed.p_Paneer_Qty;
    let p_Paneer_Qty_permisable = remainingConsumableQty / 4;
    if (p_paneer_Qty > p_Paneer_Qty_permisable) {
      this.errorTag = true;
      this.errorMsg = "Total quantity of paneer should not exceed to " + p_Paneer_Qty_permisable.toString();
      this.notify.showWarning(this.errorMsg);
      return false;
    }
    remainingConsumableQty = remainingConsumableQty - (p_paneer_Qty * 4);

    let p_Paneer_Price = this.SelfEmployed.p_Paneer_Price;
    if (p_paneer_Qty>0 && (p_Paneer_Price <= 0 || p_Paneer_Price > 450)) {
      this.errorTag = true;
      this.errorMsg = "Paneer Price should be between 1 and 450";
      this.notify.showWarning(this.errorMsg);
      return false;
    }

    let p_Other_Qty = this.SelfEmployed.p_Others_Qty;
    let p_Other_Qty_permisable = remainingConsumableQty / 2;
    if (p_Other_Qty > p_Other_Qty_permisable) {
      this.errorTag = true;
      this.errorMsg = "Total quantity of others should not exceed to " + p_Other_Qty_permisable.toString();
      this.notify.showWarning(this.errorMsg);
      return false;
    }
    remainingConsumableQty = remainingConsumableQty - (p_Other_Qty * 2);

    let p_Others_Price = this.SelfEmployed.p_Others_Price;
    if (p_Other_Qty>0 && (p_Others_Price <= 0 || p_Others_Price > 250)) {
      this.errorTag = true;
      this.errorMsg = "Others Price should be between 1 and 250";
      this.notify.showWarning(this.errorMsg);
      return false;
    }

    let numberOfEMployee = this.SelfEmployed.p_NumofEmplyrWorker;
    if (parseInt(numberOfEMployee.toString()) > 0) {
      let salaryCost = this.SelfEmployed.p_Exp_Salary_Act === "" ? 0 : parseFloat(this.SelfEmployed.p_Exp_Salary_Act)
      if (salaryCost === 0) {
        this.errorTag = true;
        this.errorMsg = "Please specify the salary cost";
        this.notify.showWarning(this.errorMsg);
        return false;
      }

    }

    if(this.SelfEmployed.p_PremiseOwnership==="Rented"){
      if(this.SelfEmployed.p_Exp_ShopRent_Act==="" || parseFloat(this.SelfEmployed.p_Exp_ShopRent_Act) <=0){
         this.notify.showWarning("Please specify the shop rent");
         return false;
      }
    }

    if(this.SelfEmployed.p_Exp_Electricity_Act==="" || parseFloat(this.SelfEmployed.p_Exp_Electricity_Act)<=0){
       this.notify.showWarning("Please specify the electricity expense");
       return false;
    }

    // if(parseFloat(this.SelfEmployed.p_Exp_Electricity_Act)<totalElectricty){
    //   this.notify.showWarning("Electricity expense should be greater than or equal to " + totalElectricty.toString());
    //   return false;
    // }

    let avgPrice: number = this.SelfEmployed.p_AvgPricePerLtr;
    let milKPurchaseCostMonthly = 0;
    let totalQuantity = this.SelfEmployed.p_QtyOfMilkPurchase === "" ? 0 :parseFloat(this.SelfEmployed.p_QtyOfMilkPurchase);

    if(totalQuantity>totalQuntityConsumables){ 
      totalQuantity =totalQuntityConsumables ;
    } 
    
    if (avgPrice < 30) {
      milKPurchaseCostMonthly = totalQuantity * avgPrice * 26;
    }
    else {
      milKPurchaseCostMonthly = totalQuantity * 30 * 26;
    } 
    
    this.SelfEmployed.p_Exp_MilkPurchase_Calc = milKPurchaseCostMonthly.toString();
    let milkPurchangeCostMonthlyAct = this.SelfEmployed.p_Exp_MilkPurchase_Act === "" ? 0 : parseFloat(this.SelfEmployed.p_Exp_MilkPurchase_Act);
    if (milkPurchangeCostMonthlyAct > milKPurchaseCostMonthly) {
      this.SelfEmployed.p_Exp_MilkPurchase_Calc = milkPurchangeCostMonthlyAct.toString();
      //this.SelfEmployed.p_Exp_MilkPurchase_Act = milkPurchangeCostMonthlyAct.toString();
    }

    let electricityCostAct = this.SelfEmployed.p_Exp_Electricity_Act === "" ? 0 : parseFloat(this.SelfEmployed.p_Exp_Electricity_Act); 4

    this.SelfEmployed.p_Exp_Electricity_Calc = totalElectricty.toString();
    if (electricityCostAct > totalElectricty) {
      this.SelfEmployed.p_Exp_Electricity_Calc = electricityCostAct.toString();
    }

    this.SelfEmployed.p_Exp_ShopRent_Calc = this.SelfEmployed.p_Exp_ShopRent_Act;
    this.SelfEmployed.p_Exp_Salary_Calc = this.SelfEmployed.p_Exp_Salary_Act;
    this.SelfEmployed.p_Exp_Transport_Calc = this.SelfEmployed.p_Exp_Transport_Act;
    this.SelfEmployed.p_Exp_Other_Calc = this.SelfEmployed.p_Exp_Other_Act;
  }

    return true;
  }
  Submit(event: IDairyAndAlliedModel) {

    if (!this.ValidatePurchase()) {
      return;
    }
    this.isEdit = !this.isEdit;
    this.OnSubmit.emit(event);
    //this.notify.showSuccess("Data saved successfully");
  }

  OnEdit(event:any){
    this.isEdit=!this.isEdit;
    this.OnEditable.emit(event);
  }
  OnChangeMobile(event: any) {
    if (!common.isValid_MobileNo(event)) {
      this.notify.showWarning("Please enter valid mobile number")
    }
  }

  CanCel(event: any) { 

    this.SelfEmployed = new DairyAndAlliedModel(event);
    this.isEdit = !this.isEdit;
  }

  UPIPaymentChange(event: any) {
    this.SelfEmployed.p_UPI_YN = event.currentTarget.checked === true ? "Y" : "N";
  }

}

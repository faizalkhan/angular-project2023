import { Component, OnInit } from '@angular/core';
import { encodeToBase64, endText } from 'pdf-lib';
import { NotificationService } from 'src/app/notification.service';
import { common } from 'src/app/shared/models/common';
import { Dropdown, IDropdown } from 'src/app/shared/models/common/control.model';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
import { DairyAndAlliedModel, IDairyAndAlliedModel } from 'src/app/shared/models/sanction/DairyAndAlliedModel';
import { SanctionRequestData } from 'src/app/shared/models/sanction/sanction.model';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { file, FileUpload, Ifile, IfileUpload, ResponseDownload, UploadViewDownloadService } from '../../../button/upload-view-download/upload-view-download.service';

@Component({
  selector: 'app-milkretailshop',
  templateUrl: './milkretailshop.component.html',
  styleUrls: ['./milkretailshop.component.css']
})
export class MilkretailshopComponent implements OnInit {

  errorTag: boolean = false;
  errorMsg: string = "";
  milkretailshop: IDairyAndAlliedModel = new DairyAndAlliedModel();
  isEdit: boolean = false;
  RequestData: SanctionRequestData = new SanctionRequestData();
  RequestDataWithLan: SanctionRequestData = new SanctionRequestData();
  DailymilkProductionValue: any;
  //OneCountofCattle:any;
  TotalQuantityPerDay: any;
  BalanceQuantityValue: any;
  Membership: any;
  TotalQuantitySold: any;
  fileUpload: IfileUpload = new FileUpload();
  fileUpload_MemberShip: IfileUpload = new FileUpload();
  showInsuranceField: boolean = false;
  readOnly: any;
  constructor(private http: ConfigService, private notify: NotificationService,
    private sanctionService: SanctionService, private download: UploadViewDownloadService) { }

  ngOnInit(): void {
    this.isEdit = false;
    this.readOnly = this.sanctionService.LanInfo.readOnly;
    this.download.uploadLoad = new FileUpload({
      flO_Id: "",
      loanAccountNumber: this.RequestData.LoanAccountNumber,
      moduleName: "LAP_IA_DairyAndAllied",
      applicationNo: this.RequestData.ApplicationNo,
      leadID: this.RequestData.ApplicationNo,
    } as IfileUpload);

    // this.fileUpload.loanAccountNumber = this.RequestData.LoanAccountNumber;
    // this.fileUpload.flO_Id = this.RequestData.FLO_PsId;
    // this.fileUpload.applicationNo = this.RequestData.ApplicationNo;
    // this.fileUpload.moduleName = "DairyAndAllied";
    // this.fileUpload.type = "MedicalReport";

    // this.fileUpload_MemberShip.loanAccountNumber = this.RequestData.LoanAccountNumber;
    // this.fileUpload_MemberShip.flO_Id = this.RequestData.FLO_PsId;
    // this.fileUpload_MemberShip.applicationNo = this.RequestData.ApplicationNo;
    // this.fileUpload_MemberShip.moduleName = "DairyAndAllied";
    // this.fileUpload_MemberShip.type = "MemberShip";
    this.getAPI();
  }

  LocalityList: IDropdown[] = [
    new Dropdown({ displayName: 'Main market' }),
    new Dropdown({ displayName: 'Near by market' }),
    new Dropdown({ displayName: 'others' }),
  ];
  upload(event: IfileUpload): Ifile {
    return { extension: event.extension, file: event.imageData, filename: event.name, format: event.imageMIMEType } as Ifile;
  }
  getAPI() {
    // var data = {
    //   "ApplicationNo": "CA01193243640",
    //   "FLO_PsId": "20150485",
    //   "CreatedON": "2022-08-27"
    // }
    this.http.httpPost<any>(this.RequestData, "GetLAP_IA_DairyAndAllied").subscribe((res: any) => {

      this.milkretailshop = new DairyAndAlliedModel();
      if (res.errorcode == "00") {
        this.milkretailshop = new DairyAndAlliedModel(res.data[0]);
        this.download.DownloadFromAPI(this.milkretailshop.l_MS_MembershipCard_Upload).subscribe((res: ResponseDownload) => {
          this.milkretailshop.MembershipCard_Upload = { extension: res.data[0].ext, file: res.data[0].fileStream, filename: res.data[0].fileName, format: res.data[0].mimeType } as Ifile;
        })
        this.milkretailshop.loanAccountNumber = this.RequestDataWithLan.LoanAccountNumber;
        this.OneCountofCattle = this.milkretailshop.l_CountofCattle;

        if (this.milkretailshop.l_CattleInsurance_YN === "Y")
          this.showInsuranceField = true;
      }
      else {
        this.notify.showError(res.errorDescription);
      }
    });
  }

  onRadioChange(event: any, type: string) {
    if (type === "Y" && event.currentTarget.checked) {
      this.milkretailshop.l_CattleInsurance_YN = "Y";
      this.showInsuranceField = true;
    }
    if (type === "N" && event.currentTarget.checked) {
      this.milkretailshop.l_CattleInsurance_YN = "N";
      this.showInsuranceField = false;
    }
  }

  change(event: any) {
    this.milkretailshop.typeOfBusiness = event.currentTarget.value == 1 ? 'Lactation of milk only and sale in open market' : 'Purchase from milkman and sale';
  }
  BusinessArragementChange(event: any) {
    if (event.currentTarget.value == "EC")
      this.milkretailshop.l_BusinessArrangement_EC_YN = event.currentTarget.checked ? 'Y' : 'N';
    if (event.currentTarget.value == "LR")
      this.milkretailshop.l_BusinessArrangement_LR_YN = event.currentTarget.checked ? 'Y' : 'N';
    if (event.currentTarget.value == "MS")
      this.milkretailshop.l_BusinessArrangement_MS_YN = event.currentTarget.checked ? 'Y' : 'N';
  }
  PropValue: any = false;
  OneCountofCattle: any = 0;
  ChangeCattleprovidingmilk() {

    this.PropValue = false;

    let sqFeet = parseInt(this.milkretailshop.l_AccomodationInSqFt);

    // if(sqFeet >=100  && sqFeet <=){
    //   if (parseInt(this.milkretailshop.l_CountofCattle) >= 1 && parseInt(this.milkretailshop.l_CountofCattle) <= 4) {

    //   }
    // }


    if (parseInt(this.milkretailshop.l_CountofCattle) >= 1 && parseInt(this.milkretailshop.l_CountofCattle) <= 4) {
      this.ChangeTotalQuantityPerDay();
      this.ChangeCattleUnderInsurance();
      this.BalanceQuantity();
    }
    else {
      this.PropValue = true;
    }
  }

  CattleAccommodationValue: any;
  Cattleaccommodation: any = false;
  ChangeCattleAccommodation() {
    this.Cattleaccommodation = false;
    if (parseInt(this.milkretailshop.l_AccomodationInSqFt) >= 100 && parseInt(this.milkretailshop.l_AccomodationInSqFt) <= 2100) {

    }
    else
      this.Cattleaccommodation = true;
  }


  Dailymilkproduction: any = false;
  ChangeDailyMilkProduction() {
    this.Dailymilkproduction = false;
    if (parseInt(this.milkretailshop.l_PerCattleProd) >= 1 && parseInt(this.milkretailshop.l_PerCattleProd) <= 10) {
      this.ChangeTotalQuantityPerDay();
    }
    else {
      this.Dailymilkproduction = true;
    }

  }
  CattleUnderInsuranceValue: any;
  CattleUnderInsurance: any = false;
  ChangeCattleUnderInsurance() {
    this.CattleUnderInsurance = false;
    this.CattleUnderInsuranceValue = this.OneCountofCattle
  }

  ChangeTotalQuantityPerDay() {
    this.TotalQuantityPerDay = parseInt(this.milkretailshop.l_CountofCattle) * parseInt(this.milkretailshop.l_PerCattleProd);
  }

  BalanceQuantity() {

    //this.BalanceQuantityValue=this.milkretailshop.l_BalQty
    this.BalanceQuantityValue = this.TotalQuantityPerDay
  }

  MembershipAggregator() {
    this.BalanceQuantityValue = (this.BalanceQuantityValue) - parseInt(this.milkretailshop.l_MS_MilkSold_Daily_Ltrs)
  }

  // TotalQuantitySoldDaily(event: any) {
  //   this.milkretailshop.l_LR_NumOfRetailers = event;
  //   this.BalanceQuantityValue = (this.BalanceQuantityValue) - parseInt(this.milkretailshop.l_LR_NumOfRetailers)
  // }
  MilkValue: any;
  MilkType: any = false;
  Milk(event: any) {
    this.milkretailshop.l_EC_Milk_Qty = event;
    if (parseInt(this.milkretailshop.l_EC_Milk_Qty) > 0 && parseInt(this.milkretailshop.l_EC_Milk_Qty) <= 12) {
      this.MilkType = false;
    }
    else {
      this.MilkType = true;
    }
  }
  MilkPriceValue: any;
  MilkPriceType: any = false;
  MilkPrice(event: any) {
    this.milkretailshop.l_EC_Milk_Price = event;
    if (parseInt(this.milkretailshop.l_EC_Milk_Price.toString()) > 0 && parseInt(this.milkretailshop.l_EC_Milk_Price.toString()) <= 42) {
      this.MilkPriceType = false;
    }
    else {
      this.MilkPriceType = true;
    }
  }

  CurdValue: any;
  CurdType: any = false;
  Curd(event: any) {
    this.milkretailshop.l_EC_Curd_Qty = event;
    if (parseInt(this.milkretailshop.l_EC_Curd_Qty) > 0 && parseInt(this.milkretailshop.l_EC_Curd_Qty) <= 8) {
      this.CurdType = false;
    }
    else {
      this.CurdType = true;
    }
  }

  CurdPriceValue: any;
  CurdPriceType: any = false;
  CurdPrice(event: any) {
    this.milkretailshop.l_EC_Curd_Price = event;
    if (parseInt(this.milkretailshop.l_EC_Curd_Price.toString()) > 0 && parseInt(this.milkretailshop.l_EC_Curd_Price.toString()) <= 80) {
      this.CurdPriceType = false;
    }
    else {
      this.CurdPriceType = true;
    }
  }

  GheeValue: any;
  GheeType: any = false;
  Ghee(event: any) {
    this.milkretailshop.l_EC_Ghee_Qty = event;
    if (parseInt(this.milkretailshop.l_EC_Ghee_Qty) > 0 && parseInt(this.milkretailshop.l_EC_Ghee_Qty) <= 2) {
      this.GheeType = false;
    }
    else {
      this.GheeType = true;
    }
  }

  GheePriceValue: any;
  GheePriceType: any = false;
  GheePrice(event: any) {
    this.milkretailshop.l_EC_Ghee_Price = event;
    if (parseInt(this.milkretailshop.l_EC_Ghee_Price.toString()) > 0 && parseInt(this.milkretailshop.l_EC_Ghee_Price.toString()) <= 500) {
      this.GheePriceType = false;
    }
    else {
      this.GheePriceType = true;
    }
  }

  PaneerType: any = false;
  Paneer(event: any) {
    this.milkretailshop.l_EC_Paneer_Qty = event;
    if (parseInt(this.milkretailshop.l_EC_Paneer_Qty) > 0 && parseInt(this.milkretailshop.l_EC_Paneer_Qty) <= 3) {
      this.PaneerType = false;
    }
    else {
      this.PaneerType = true;
    }
  }

  PaneerPriceType: any = false;
  PaneerPrice(event: any) {
    this.milkretailshop.l_EC_Paneer_Price = event;
    if (parseInt(this.milkretailshop.l_EC_Paneer_Price.toString()) > 0 && parseInt(this.milkretailshop.l_EC_Paneer_Price.toString()) <= 300) {
      this.PaneerPriceType = false;
    }
    else {
      this.PaneerPriceType = true;
    }
  }

  OthersType: any = false;
  Others(event: any) {
    this.milkretailshop.l_EC_Others_Qty = event;
    if (parseInt(this.milkretailshop.l_EC_Others_Qty) > 0 && parseInt(this.milkretailshop.l_EC_Others_Qty) <= 6) {
      this.OthersType = false;
    }
    else {
      this.OthersType = true;
    }
  }

  OthersPriceType: any = false;
  OthersPrice(event: any) {
    this.milkretailshop.l_EC_Others_Price = event;
    if (parseInt(this.milkretailshop.l_EC_Others_Price.toString()) > 0 && parseInt(this.milkretailshop.l_EC_Others_Price.toString()) <= 100) {
      this.OthersPriceType = false;
    }
    else {
      this.OthersPriceType = true;
    }

  }

  UPIPaymentChange(event: any) {
    this.milkretailshop.l_EC_UPI_YN = event.currentTarget.checked === true ? "Y" : "N";
  }

  BankNormChange(event: any) {
    this.milkretailshop.l_MS_Bank_BankingNorm_YN = event.currentTarget.checked === true ? "Y" : "N";
  }

  validate() {
    this.errorTag = false;
    this.errorMsg = "";
    const pattern = /^[6-9][0-9]{0,10}$/;

    if (this.milkretailshop.typeOfBusiness === "Lactation of milk only and sale in open market") {

      let sqFeet = (this.milkretailshop.l_AccomodationInSqFt === "" ? 0 : parseFloat(this.milkretailshop.l_AccomodationInSqFt));
      let numberOfCattleProvidingMilk = this.milkretailshop.l_CountofCattle === "" ? 0 : parseInt(this.milkretailshop.l_CountofCattle);


      if (numberOfCattleProvidingMilk < 2 || numberOfCattleProvidingMilk > 15) {
        this.errorTag = true;
        this.errorMsg = "Please specify the No of Cattle between 2 and 15";
        this.notify.showWarning(this.errorMsg);
        return false;
      }

      if (sqFeet === 0) {
        this.errorTag = true;
        this.errorMsg = "Please specify the Total Area for cattle accommodation- In Sq. feet";
        this.notify.showWarning(this.errorMsg);
        return false;
      }

      if (sqFeet < 200 || sqFeet > 5000) {
        this.errorTag = true;
        this.errorMsg = "Please specify the Total Area for cattle accommodation- In Sq. feet between 200 and 5000";
        this.notify.showWarning(this.errorMsg);
        return false;
      }


      let maxNumberOfCattleAllowed = 0;
      maxNumberOfCattleAllowed = numberOfCattleProvidingMilk; //Math.round(sqFeet / 30);

      if (numberOfCattleProvidingMilk === 0) {
        this.errorTag = true;
        this.errorMsg = "Please specify the No of Cattle providing milk";
        this.notify.showWarning(this.errorMsg);
        return false;
      }



      if (numberOfCattleProvidingMilk > maxNumberOfCattleAllowed) {
        this.errorTag = true;
        this.errorMsg = "No of Cattle providing milk should be " + maxNumberOfCattleAllowed.toString();
        this.notify.showWarning(this.errorMsg);
        return false;
      }

      let perCattleProd = this.milkretailshop.l_PerCattleProd === "" ? 0 : parseInt(this.milkretailshop.l_PerCattleProd);
      if (perCattleProd < 1 || perCattleProd > 10) {
        this.errorTag = true;
        this.errorMsg = "Daily milk production per cattle should be between 1 and 10";
        this.notify.showWarning(this.errorMsg);
        return false;
      }

      let haveCattleInsurance = this.milkretailshop.l_CattleInsurance_YN;
      let noOfCattleCoveredIns = this.milkretailshop.l_NumOfCattleInsured === "" ? 0 : parseInt(this.milkretailshop.l_NumOfCattleInsured);

      if (haveCattleInsurance === "Y") {
        if (noOfCattleCoveredIns === 0) {
          this.errorTag = true;
          this.errorMsg = "Please specify the No of cattle covered under insurance";
          this.notify.showWarning(this.errorMsg);
          return false;
        }


        if (noOfCattleCoveredIns > maxNumberOfCattleAllowed) {
          this.errorTag = true;
          this.errorMsg = "No of cattle covered under insurance should be less than " + maxNumberOfCattleAllowed.toString();
          this.notify.showWarning(this.errorMsg);
          return false;
        }

        if (this.milkretailshop.l_MedReport_Remark === "") {
          this.errorTag = true;
          this.errorMsg = "Please speicify the last medical report remark";
          this.notify.showWarning(this.errorMsg);
          return false;
        }

        if (this.milkretailshop.l_MedReport_Upload === "") {
          this.errorTag = true;
          this.errorMsg = "Please upload the medical report";
          this.notify.showWarning(this.errorMsg);
          return false;
        }
      }

      if (this.milkretailshop.l_NumofPartners != 0) {
        if (this.milkretailshop.l_ProfSharingRatio === "0" || this.milkretailshop.l_ProfSharingRatio.length == 0) {
          this.errorTag = true;
          this.errorMsg = "Please enter Profit sharing Ratio for customer in %";
          this.notify.showWarning(this.errorMsg);
          return false;
        }
      }

      let numOfRetailers = this.milkretailshop.l_LR_NumOfRetailers === "" ? 0 : parseInt(this.milkretailshop.l_LR_NumOfRetailers)

      if (numOfRetailers > 0) {
        if (this.milkretailshop.l_LR_Name_Top1 === "") {
          this.errorTag = true;
          this.errorMsg = "Please specify the top1 buyer name";
          this.notify.showWarning(this.errorMsg);
          return false;
        }

        if (this.milkretailshop.l_LR_Contact_Top1 === "") {
          this.errorTag = true;
          this.errorMsg = "Please specify the top1 buyer contact details";
          this.notify.showWarning(this.errorMsg);
          return false;
        }


        var value = this.milkretailshop.l_LR_Contact_Top1;
        // if (!pattern.test(value)) {
        if (!common.isValid_MobileNo(this.milkretailshop.l_LR_Contact_Top1)) {
          //(this.ControlInput = value = '');
          this.notify.showWarning("Please enter valid contact number for the top1 buyer");
          return false;
        }


        // if (this.milkretailshop.l_LR_Address_Top1 === "") {
        //   this.errorTag = true;
        //   this.errorMsg = "Please specify the top1 buyer address";
        //   this.notify.showWarning(this.errorMsg);
        //   return false;
        // }

        if (numOfRetailers > 1) {

          if (this.milkretailshop.l_LR_Name_Top2 === "") {
            this.errorTag = true;
            this.errorMsg = "Please specify the name for the top2 buyer";
            this.notify.showWarning(this.errorMsg);
            return false;
          }
          // if (this.milkretailshop.l_LR_Address_Top2 === "") {
          //   this.errorTag = true;
          //   this.errorMsg = "Please specify the Total Area for cattle accommodation- In Sq. feet between 200 and 5000";
          //   this.notify.showWarning(this.errorMsg);
          //   return false;
          // } 
          //value = this.milkretailshop.l_LR_Contact_Top2;
          if (!common.isValid_MobileNo(this.milkretailshop.l_LR_Contact_Top2)) {
            // if (!pattern.test(value)) {
            //(this.ControlInput = value = '');
            this.notify.showWarning("Please enter valid contact number for the top2 buyer");
            return false;
          }
        }
      }

      value = this.milkretailshop.l_LR_Contact_Top1;
      if (value !== "") {
       // if (!pattern.test(value)) {
        if (!common.isValid_MobileNo(this.milkretailshop.l_LR_Contact_Top1)) {
          //(this.ControlInput = value = '');
          this.notify.showWarning("Please enter valid contact number for the top1 buyer");
          return false;
        }
      }

      value = this.milkretailshop.l_LR_Contact_Top2;
      if (value !== "") {
        //if (!pattern.test(value)) {
          if (!common.isValid_MobileNo(this.milkretailshop.l_LR_Contact_Top2)) {
          //(this.ControlInput = value = '');
          this.notify.showWarning("Please enter valid contact number for the top2 buyer");
          return false;
        }
      }

      let remainingQuantityPerDay = 0;
      let perCattleProduction: number = 0;
      perCattleProduction = this.milkretailshop.l_PerCattleProd === "" ? 0 : parseInt(this.milkretailshop.l_PerCattleProd);
      let totalQuantityPerDay = numberOfCattleProvidingMilk * perCattleProduction;
      remainingQuantityPerDay = totalQuantityPerDay;

      if (this.milkretailshop.l_PermissibleQty > totalQuantityPerDay) {
        this.errorTag = true;
        this.errorMsg = "Total quantity per day - In litre should be " + totalQuantityPerDay.toString();
        this.notify.showWarning(this.errorMsg);
        return false;
      }

      if (this.milkretailshop.l_BusinessArrangement_MS_YN === "Y") {

        if (this.milkretailshop.l_MS_MilkSold_Daily_Ltrs === "") {
          this.notify.showWarning("Total litre of Milk Sold cannot be zero");
          return false;
        }

        if (parseInt(this.milkretailshop.l_MS_MilkSold_Daily_Ltrs) <= 0) {
          this.notify.showWarning("Please input the value of total litre of milk sold");
          return false;
        }

        let soldToSocietyOrAggregator = this.milkretailshop.l_MS_MilkSold_Daily_Ltrs === "" ? 0 : parseInt(this.milkretailshop.l_MS_MilkSold_Daily_Ltrs);

        if (soldToSocietyOrAggregator <= 0) {
          this.errorTag = true;
          this.errorMsg = "Minimum litre of milk sold to milk society/aggregator- Daily should be 1 ";
          this.notify.showWarning(this.errorMsg);
          return false;
        }

        if (soldToSocietyOrAggregator > remainingQuantityPerDay) {
          this.errorTag = true;
          this.errorMsg = "Total litre of milk sold to milk society/aggregator- Daily should be less than or equal to " + remainingQuantityPerDay.toString();
          this.notify.showWarning(this.errorMsg);
          return false;
        }         

        remainingQuantityPerDay = remainingQuantityPerDay - soldToSocietyOrAggregator;

        let l_MS_AgreedPrice_perltr = this.milkretailshop.l_MS_AgreedPrice_perltr === "" ? 0 : parseInt(this.milkretailshop.l_MS_AgreedPrice_perltr);
        if (l_MS_AgreedPrice_perltr < 25 || l_MS_AgreedPrice_perltr > 45) {
          this.errorTag = true;
          this.errorMsg = "Agreed price per litre should be between 25 and 45";
          this.notify.showWarning(this.errorMsg);
          return false;
        }

        if (!this.milkretailshop.l_MS_BankName || this.milkretailshop.l_MS_BankName == '') {
          this.errorTag = true;
          this.errorMsg = "Please enter the Bank name";
          this.notify.showWarning(this.errorMsg);
          return false;
        }
        if (!this.milkretailshop.l_MS_BankNum || this.milkretailshop.l_MS_BankNum == '') {
          this.errorTag = true;
          this.errorMsg = "Please enter the Bank Account Number";
          this.notify.showWarning(this.errorMsg);
          return false;
        }

        if (this.milkretailshop.l_MS_BankNum.length < 9 || this.milkretailshop.l_MS_BankNum.length > 18) {
          this.notify.showWarning("Please enter valid account number");
          return false;
        }

        if (!this.milkretailshop.l_MS_BankIFSC || this.milkretailshop.l_MS_BankIFSC == '') {
          this.errorTag = true;
          this.errorMsg = "Please enter the IFSC";
          this.notify.showWarning(this.errorMsg);
          return false;
        } 

        if (!common.isValid_IFSC_Code(this.milkretailshop.l_MS_BankIFSC)) {
          this.errorTag = true;
          this.errorMsg = "Please enter valid IFSC";
          this.notify.showWarning(this.errorMsg);
          return false;
        } 
      }

      if (this.milkretailshop.l_BusinessArrangement_LR_YN === "Y") {

        if (this.milkretailshop.l_LR_QtyDaily <= 0) {
          this.errorTag = true;
          this.errorMsg = "Minimum total quantity sold daily - In litre should be 1 ";
          this.notify.showWarning(this.errorMsg);
          return false;
        }


        if (this.milkretailshop.l_LR_QtyDaily > 0) {
          if (this.milkretailshop.l_LR_QtyDaily > remainingQuantityPerDay) {
            this.errorTag = true;
            this.errorMsg = "Total quantity sold daily - In litre should be less than or equal to " + remainingQuantityPerDay.toString();
            this.notify.showWarning(this.errorMsg);
            return false;
          }
        }
        remainingQuantityPerDay = remainingQuantityPerDay - this.milkretailshop.l_LR_QtyDaily;

        if (this.milkretailshop.l_LR_QtyDaily > 0 && this.milkretailshop.l_BusinessArrangement_LR_YN == 'Y' && (this.milkretailshop.l_LR_Avg_priceperLtr < 25 || this.milkretailshop.l_LR_Avg_priceperLtr > 45)) {
          this.errorTag = true;
          this.errorMsg = "Average price per litre should be between 25 and 45";
          this.notify.showWarning(this.errorMsg);
          return false;
        }
      }

      if (this.milkretailshop.l_BusinessArrangement_EC_YN === "Y") {

        if (this.milkretailshop.l_EC_ShopName === "") {

          this.errorTag = true;
          this.errorMsg = "Please specify the shop name";
          this.notify.showWarning(this.errorMsg);
          return false;
        }

        if (this.milkretailshop.l_EC_Locality === "") {

          this.errorTag = true;
          this.errorMsg = "Please specify the locality";
          this.notify.showWarning(this.errorMsg);
          return false;
        }



        let l_EC_Milk_Qty = this.milkretailshop.l_EC_Milk_Qty === "" ? 0 : parseInt(this.milkretailshop.l_EC_Milk_Qty);
        if (l_EC_Milk_Qty > 0 && l_EC_Milk_Qty > remainingQuantityPerDay) {
          this.errorTag = true;
          this.errorMsg = "Available remaining quantity of milk is " + remainingQuantityPerDay.toString();
          this.notify.showWarning(this.errorMsg);
          return false;
        }
        remainingQuantityPerDay = remainingQuantityPerDay - l_EC_Milk_Qty;

        if (l_EC_Milk_Qty > 0 && (this.milkretailshop.l_EC_Milk_Price < 25 || this.milkretailshop.l_EC_Milk_Price > 50)) {
          this.errorTag = true;
          this.errorMsg = "Average milk price per litre should be between 25 and 50";
          this.notify.showWarning(this.errorMsg);
          return false;
        }

        let l_EC_Curd_Qty = this.milkretailshop.l_EC_Curd_Qty === "" ? 0 : parseInt(this.milkretailshop.l_EC_Curd_Qty);
        let curdQunatity = remainingQuantityPerDay / 1.4;
        if (l_EC_Curd_Qty > 0 && l_EC_Curd_Qty > curdQunatity) {
          this.errorTag = true;
          this.errorMsg = "Available remaining quantity of curd is " + curdQunatity.toString();
          this.notify.showWarning(this.errorMsg);
          return false;
        }
        remainingQuantityPerDay = remainingQuantityPerDay - (l_EC_Curd_Qty * 1.4);

        if (l_EC_Curd_Qty > 0 && (this.milkretailshop.l_EC_Curd_Price < 60 || this.milkretailshop.l_EC_Curd_Price > 80)) {
          this.errorTag = true;
          this.errorMsg = "Average curd price per litre should be between 60 and 80";
          this.notify.showWarning(this.errorMsg);
          return false;
        }


        let l_EC_Ghee_Qty = this.milkretailshop.l_EC_Ghee_Qty === "" ? 0 : parseInt(this.milkretailshop.l_EC_Ghee_Qty);
        let gheeQunatity = remainingQuantityPerDay / 8;
        if (l_EC_Ghee_Qty > 0 && l_EC_Ghee_Qty > gheeQunatity) {
          this.errorTag = true;
          this.errorMsg = "Available remaining quantity of ghee is " + gheeQunatity.toString();
          this.notify.showWarning(this.errorMsg);
          return false;
        }
        remainingQuantityPerDay = remainingQuantityPerDay - (l_EC_Ghee_Qty * 8);

        if (l_EC_Ghee_Qty > 0 && (this.milkretailshop.l_EC_Ghee_Price < 500 || this.milkretailshop.l_EC_Ghee_Price > 750)) {
          this.errorTag = true;
          this.errorMsg = "Average Ghee price per litre should be between 500 and 750";
          this.notify.showWarning(this.errorMsg);
          return false;
        }

        let l_EC_Paneer_Qty = this.milkretailshop.l_EC_Paneer_Qty === "" ? 0 : parseInt(this.milkretailshop.l_EC_Paneer_Qty);
        let paneerQunatity = remainingQuantityPerDay / 4;
        if (l_EC_Paneer_Qty > 0 && l_EC_Paneer_Qty > paneerQunatity) {
          this.errorTag = true;
          this.errorMsg = "Available remaining quantity of paneer is " + paneerQunatity.toString();
          this.notify.showWarning(this.errorMsg);
          return false;
        }
        remainingQuantityPerDay = remainingQuantityPerDay - (l_EC_Paneer_Qty * 4);

        if (l_EC_Paneer_Qty > 0 && (this.milkretailshop.l_EC_Paneer_Price < 300 || this.milkretailshop.l_EC_Paneer_Price > 450)) {
          this.errorTag = true;
          this.errorMsg = "Paneer price per litre should be between 300 and 450";
          this.notify.showWarning(this.errorMsg);
          return false;
        }


        let l_EC_Others_Qty = this.milkretailshop.l_EC_Others_Qty === "" ? 0 : parseInt(this.milkretailshop.l_EC_Others_Qty);
        let othersQunatity = remainingQuantityPerDay / 2;
        if (l_EC_Others_Qty > 0 && l_EC_Others_Qty > othersQunatity) {
          this.errorTag = true;
          this.errorMsg = "Available remaining quantity of other is " + othersQunatity.toString();
          this.notify.showWarning(this.errorMsg);
          return false;
        }
        remainingQuantityPerDay = remainingQuantityPerDay - (l_EC_Others_Qty * 2);

        if (l_EC_Others_Qty > 0 && (this.milkretailshop.l_EC_Others_Price < 25 || this.milkretailshop.l_EC_Others_Price > 250)) {
          this.errorTag = true;
          this.errorMsg = "Others price per litre should be between 25 and 250";
          this.notify.showWarning(this.errorMsg);
          return false;
        }

        if (numberOfCattleProvidingMilk > 0 && perCattleProd > 0) {
          if (l_EC_Curd_Qty === 0 && l_EC_Milk_Qty === 0 && l_EC_Ghee_Qty === 0 && l_EC_Paneer_Qty === 0 && l_EC_Others_Qty === 0) {
            this.errorMsg = "Please enter product details (Business Engagement : Sale to End Customer directly)";
            this.notify.showWarning(this.errorMsg);
            return false;
          }
        }
      }

      let l_Exp_CAttleFeed_Act = this.milkretailshop.l_Exp_CAttleFeed_Act === "" ? 0 : parseInt(this.milkretailshop.l_Exp_CAttleFeed_Act);
      let l_Exp_CAttleFeed_Calc = this.milkretailshop.l_Exp_CAttleFeed_Calc === "" ? 0 : parseInt(this.milkretailshop.l_Exp_CAttleFeed_Calc);

      l_Exp_CAttleFeed_Calc = numberOfCattleProvidingMilk * 1500;
      this.milkretailshop.l_Exp_CAttleFeed_Calc = l_Exp_CAttleFeed_Calc.toString();
      if (l_Exp_CAttleFeed_Act > l_Exp_CAttleFeed_Calc) {
        this.milkretailshop.l_Exp_CAttleFeed_Calc = l_Exp_CAttleFeed_Act.toString();
      }



      let l_Exp_Electricity_Act = this.milkretailshop.l_Exp_Electricity_Act === "" ? 0 : parseInt(this.milkretailshop.l_Exp_Electricity_Act);
      let l_Exp_Electricity_Calc = this.milkretailshop.l_Exp_Electricity_Calc === "" ? 0 : parseInt(this.milkretailshop.l_Exp_Electricity_Calc);

      l_Exp_Electricity_Calc = numberOfCattleProvidingMilk * 30;
      this.milkretailshop.l_Exp_Electricity_Calc = l_Exp_Electricity_Calc.toString();
      if (l_Exp_Electricity_Act > l_Exp_Electricity_Calc) {
        this.milkretailshop.l_Exp_Electricity_Calc = l_Exp_Electricity_Act.toString();
      }

      let insuarnceExpense: number = numberOfCattleProvidingMilk * 350;
      this.milkretailshop.l_Exp_Insurance_Calc = insuarnceExpense.toString()
      let l_Exp_Insurance_Act = this.milkretailshop.l_Exp_Insurance_Act === "" ? 0 : parseInt(this.milkretailshop.l_Exp_Insurance_Act);
      //this.milkretailshop.l_Exp_Insurance_Calc = insuarnceExpense.toString();
      if (l_Exp_Insurance_Act > insuarnceExpense) {
        this.milkretailshop.l_Exp_Insurance_Calc = l_Exp_Insurance_Act.toString();
      }

      let locationExpenseAct = this.milkretailshop.l_Exp_Lactation_Act === "" ? 0 : parseInt(this.milkretailshop.l_Exp_Lactation_Act);
      // if (numberOfCattleProvidingMilk > 10) {
      //   let locationExpense = numberOfCattleProvidingMilk * 1200;
      //   this.milkretailshop.l_Exp_Lactation_Calc = locationExpense.toString();
      //   if (locationExpenseAct > locationExpense)
          this.milkretailshop.l_Exp_Lactation_Calc = locationExpenseAct.toString();
      //}

      this.milkretailshop.l_Exp_Others_Calc = this.milkretailshop.l_Exp_Others_Act;

      let actTotal = parseInt(this.milkretailshop.l_Exp_CAttleFeed_Act) + parseInt(this.milkretailshop.l_Exp_Electricity_Act) + parseInt(this.milkretailshop.l_Exp_Insurance_Act) + parseInt(this.milkretailshop.l_Exp_Others_Act) + parseInt(this.milkretailshop.l_Exp_Lactation_Act);
      this.milkretailshop.l_Exp_Act_Total = actTotal.toString();

      let calcTotal = parseInt(this.milkretailshop.l_Exp_CAttleFeed_Calc) + parseInt(this.milkretailshop.l_Exp_Electricity_Calc) + parseInt(this.milkretailshop.l_Exp_Insurance_Calc) + parseInt(this.milkretailshop.l_Exp_Others_Calc) + parseInt(this.milkretailshop.l_Exp_Lactation_Calc);
      this.milkretailshop.l_Exp_Cal_Total = calcTotal.toString();

      let totalQuantityPurchasedFromMilkMan = this.milkretailshop.p_Milk_Qty

    }
    return true;
  }
  CanCel(event: any) {
    this.milkretailshop = new DairyAndAlliedModel(event);
    this.isEdit = !this.isEdit;
  }
  Submit(event: IDairyAndAlliedModel) {

    if (event.typeOfBusiness === "Purchase from milkman and sale") {
      event.l_AccomodationInSqFt = "";
      event.l_BalQty = 0;
      event.l_BusinessArrangement_EC_YN = "N";
      event.l_BusinessArrangement_LR_YN = "N";
      event.l_BusinessArrangement_MS_YN = "N";
      event.l_CattleInsurance_YN = "N";
      event.l_CountofCattle = "0";
      event.l_EC_Curd_Price = 0;
      event.l_EC_Curd_Qty = "0";
      event.l_EC_Ghee_Price = 0;
      event.l_EC_Ghee_Qty = "0";
      event.l_EC_Locality = "0";
      event.l_EC_Milk_Price = 0;
      event.l_EC_Milk_Qty = "0";
      event.l_EC_Others_Price = 0;
      event.l_EC_Others_Qty = "0";
      event.l_EC_Paneer_Price = 0;
      event.l_EC_Paneer_Qty = "0";
      event.l_EC_ShopName = "";
      event.l_EC_UPI_YN = "N";
      event.l_Exp_Act_Total = "0";
      event.l_Exp_Cal_Total = "0";
      event.l_Exp_CAttleFeed_Act = "0";
      event.l_Exp_CAttleFeed_Calc = "0";
      event.l_Exp_Electricity_Calc = "0";
      event.l_Exp_Electricity_Act = "0";
      event.l_Exp_Insurance_Act = "0";
      event.l_Exp_Insurance_Calc = "0";
      event.l_Exp_Lactation_Act = "0";
      event.l_Exp_Lactation_Calc = "0";
      event.l_Exp_Others_Act = "0";
      event.l_Exp_Others_Calc = "0";
      event.l_LR_Address_Top1 = "";
      event.l_LR_Address_Top2 = "";
      event.l_LR_Avg_priceperLtr = 0;
      event.l_LR_Contact_Top1 = "";
      event.l_LR_Contact_Top2 = "";
      event.l_LR_Name_Top1 = "";
      event.l_LR_Name_Top2 = "";
      event.l_LR_NumOfRetailers = "";
      event.l_LR_QtyDaily = 0;
      event.l_LR_Relation_Years = 0;
      event.l_MS_AgreedPrice_perltr = "0";
      event.l_MS_BankIFSC = "";
      event.l_MS_BankName = "";
      event.l_MS_BankNum = "";
      event.l_MS_Bank_BankingNorm_YN = "N";
      event.l_MS_MembershipCard_Upload = "";
      event.l_MS_Membership_Num = 0;
      event.l_MS_MilkSold_Daily_Ltrs = "0";
      event.l_MS_NameofMilkSociety = "";
      event.l_MS_OtherArrangement = "";
      event.l_MS_Vintage = "";
      event.l_MedReport_Remark = "";
      event.l_MedReport_Title = "";
      event.l_MedReport_Upload = "";
      event.l_NumOfCattleInsured = "0";
      event.l_NumofEmplyrWorker = 0;
      event.l_NumofPartners = 0;
      event.l_PerCattleProd = "0";
      event.l_PermissibleQty = 0;
      event.l_ProfSharingRatio = "";
      event.l_profSharingRatio_Disable = false;
    }

    if (event.typeOfBusiness === 'Lactation of milk only and sale in open market') {
      event.p_ShopBusinessName = "";
      event.p_Address_Top1 = "";
      event.p_Address_Top2 = "";
      event.p_AvgPricePerLtr = 0;
      event.p_BalQty = 0;
      event.p_BigTank_YN = "N";
      event.p_Contact_Top1 = "";
      event.p_Contact_Top2 = "";
      event.p_Curd_Price = 0;
      event.p_Curd_Qty = 0;
      event.p_Exp_Act_Total = "0";
      event.p_Exp_Calc_Total = "0";
      event.p_Exp_Electricity_Act = "0";
      event.p_Exp_Electricity_Calc = "0";
      event.p_Exp_MilkPurchase_Act = "0";
      event.p_Exp_MilkPurchase_Calc = "0";
      event.p_Exp_Other_Act = "0";
      event.p_Exp_Other_Calc = "0";
      event.p_Exp_ShopRent_Act = "0";
      event.p_Exp_ShopRent_Calc = "0";
      event.p_Exp_Salary_Act = "0";
      event.p_Exp_Salary_Calc = "0";
      event.p_Exp_Transport_Act = "0";
      event.p_Exp_Transport_Calc = "0";
      event.p_Ghee_Price = 0;
      event.p_Ghee_Qty = 0;
      event.p_Locality = "";
      event.p_Milk_Price = 0;
      event.p_Milk_Qty = 0;
      event.p_MixTank_YN = "N";
      event.p_Name_Top1 = "";
      event.p_Name_Top2 = "";
      event.p_NonRefTAnk_YN = "N";
      event.p_NumOfFamily = 0;
      event.p_NumOfPartness = 0;
      event.p_NumofEmplyrWorker = 0;
      event.p_NumofMilkmanSupplier = 0;
      event.p_Others_Price = 0;
      event.p_Others_Qty = 0;
      event.p_OtherProds = "";
      event.p_Paneer_Price = 0;
      event.p_Paneer_Qty = 0;
      event.p_PermissibleQty = 0;
      event.p_PremiseOwnership = "";
      event.p_QtyOfMilkPurchase = "0";

      if (event.l_BusinessArrangement_LR_YN === "N") {
        event.l_LR_Address_Top1 = "";
        event.l_LR_Address_Top2 = "";
        event.l_LR_Name_Top2 = "";
        event.l_LR_Contact_Top1 = "";
        event.l_LR_Contact_Top2 = "";
        event.l_LR_Name_Top1 = "";
        event.l_LR_NumOfRetailers = "0";
        event.l_LR_QtyDaily = 0;
        event.l_LR_Relation_Years = 0;
        event.l_LR_Avg_priceperLtr = 0;
      }

      if (event.l_BusinessArrangement_MS_YN === "N") {
        event.l_MS_Membership_Num = 0;
        event.l_MS_AgreedPrice_perltr = "0";
        event.l_MS_BankIFSC = "";
        event.l_MS_BankName = "";
        event.l_MS_BankNum = "";
        event.l_MS_Bank_BankingNorm_YN = "N";
        event.l_MS_MembershipCard_Upload = "";
        event.l_MS_MilkSold_Daily_Ltrs = "0";
        event.l_MS_NameofMilkSociety = "";
        event.l_MS_OtherArrangement = "";
        event.l_MS_Vintage = "";
      }
      if (event.l_BusinessArrangement_EC_YN === "N") {
        event.l_EC_Curd_Price = 0;
        event.l_EC_Curd_Qty = "0";
        event.l_EC_Ghee_Price = 0;
        event.l_EC_Ghee_Qty = "0";
        event.l_EC_Paneer_Price = 0;
        event.l_EC_Paneer_Qty = "0";
        event.l_EC_Milk_Price = 0;
        event.l_EC_Milk_Qty = "0";
        event.l_EC_Locality = "";
        event.l_EC_ShopName = "";
        event.l_EC_Locality = "";
        event.l_EC_Others_Qty = "0";
        event.l_EC_Others_Price = 0;
        event.l_EC_UPI_YN = "N";
      }

    }

    if (!this.validate()) {
      // this.isEdit=true; 
      return;
    }


    this.http.httpPostWithouImageData<IresponseModel<any>>(event.toJson(), "LAP_IA_DairyAndAllied", event.toJsonwithOutImage()).
      subscribe((res: IresponseModel<any>) => {
        this.isEdit = !this.isEdit;
        this.errorTag = false;
        this.errorMsg = "";
        this.ngOnInit();
        if (res.errorcode == "00" || res.errorcode == "01") {

          this.notify.showSuccess(res.errorDescription, "Sucess");
        }
        else {
          this.notify.showError(res.errorDescription, "Failed");
        }
      });
  }


  MedReportUploadChange(event: IfileUpload) {
    if (event !== null) {
      this.milkretailshop.l_MedReport_Upload = event.imageData;
      this.milkretailshop.l_MedReport_UploadMimeType = event.imageMIMEType;
      this.milkretailshop.l_MedReport_UploadExtension = event.extension;
      this.notify.showSuccess("Document added successfully");
    }
  }

  MemberShipUploadChange(event: IfileUpload) {
    if (event !== null) {
      this.milkretailshop.l_MS_MembershipCard_Upload = event.imageData;
      this.milkretailshop.l_MS_MembershipCardMimeType = event.imageMIMEType;
      this.milkretailshop.l_MS_MemCardExtension = event.extension;
      this.notify.showSuccess("Document added successfully");
    }
  }
}

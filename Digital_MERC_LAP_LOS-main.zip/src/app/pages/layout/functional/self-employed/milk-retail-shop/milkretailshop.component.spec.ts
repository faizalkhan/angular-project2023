import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MilkretailshopComponent } from './milkretailshop.component';

describe('MilkretailshopComponent', () => {
  let component: MilkretailshopComponent;
  let fixture: ComponentFixture<MilkretailshopComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MilkretailshopComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MilkretailshopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

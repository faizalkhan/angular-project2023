import { common } from "src/app/shared/models/common";
import { ISelfEmployedModel } from "./ISelfEmployedModel";


export class SelfEmployedModel implements ISelfEmployedModel {
    private _applicationNo: string = "";
    public get applicationNo(): string {
        return this._applicationNo;
    }
    public set applicationNo(value: string) {
        this._applicationNo = value;
    }
    private _applicantCoappRef: string = "";
    public get applicantCoappRef(): string {
        return this._applicantCoappRef;
    }
    public set applicantCoappRef(value: string) {
        this._applicantCoappRef = value;
    }
    private _line_of_Business: string = "";
    public get line_of_Business(): string {
        return this._line_of_Business;
    }
    public set line_of_Business(value: string) {
        this._line_of_Business = value;
    }
    private _line_of_Business_Dtl_If_Others: string = "";
    public get line_of_Business_Dtl_If_Others(): string {
        return this._line_of_Business_Dtl_If_Others;
    }
    public set line_of_Business_Dtl_If_Others(value: string) {
        this._line_of_Business_Dtl_If_Others = value;
    }
    private _udyam_Registration_YN: string = "";
    public get udyam_Registration_YN(): string {
        return this._udyam_Registration_YN;
    }
    public set udyam_Registration_YN(value: string) {
        this._udyam_Registration_YN = value;
        if (value.toLowerCase() == 'n' || value.toLowerCase() == 'no') {
            this.udyam_Reg_No = "";
        }
    }
    private _udyam_Reg_No: string = "";
    public get udyam_Reg_No(): string {
        return this._udyam_Reg_No;
    }
    public set udyam_Reg_No(value: string) {
        this._udyam_Reg_No = value;
    }
    private _gsT_Registered_YN: string = "";
    public get gsT_Registered_YN(): string {
        return this._gsT_Registered_YN;
    }
    public set gsT_Registered_YN(value: string) {
        this._gsT_Registered_YN = value;
        if (value.toLowerCase() == 'n' || value.toLowerCase() == 'no') {
            this.gsT_Reg_No = "";
        }
    }
    private _gsT_Reg_No: string = "";
    public get gsT_Reg_No(): string {
        return this._gsT_Reg_No;
    }
    public set gsT_Reg_No(value: string) {
        this._gsT_Reg_No = value;
    }
    private _itR_lst3yr_Conf: string = "";
    public get itR_lst3yr_Conf(): string {
        return this._itR_lst3yr_Conf;
    }
    public set itR_lst3yr_Conf(value: string) {
        this._itR_lst3yr_Conf = value;
    }
    private _businessShop_Reg_YN: string = "";
    public get businessShop_Reg_YN(): string {
        return this._businessShop_Reg_YN;
    }
    public set businessShop_Reg_YN(value: string) {
        this._businessShop_Reg_YN = value;
        if (value.toLowerCase() == 'n' || value.toLowerCase() == 'no') {
            this.businessShop_Reg_No = "";
        }
    }
    private _businessShop_Reg_No: string = "";
    public get businessShop_Reg_No(): string {
        return this._businessShop_Reg_No;
    }
    public set businessShop_Reg_No(value: string) {
        this._businessShop_Reg_No = value;
    }
    private _end_UseOfFund: string = "";
    public get end_UseOfFund(): string {
        return this._end_UseOfFund;
    }
    public set end_UseOfFund(value: string) {
        this._end_UseOfFund = value;
    }
    private _end_UseOfFund_Detail: string = "";
    public get end_UseOfFund_Detail(): string {
        return this._end_UseOfFund_Detail;
    }
    public set end_UseOfFund_Detail(value: string) {
        this._end_UseOfFund_Detail = value;
    }
    // address begin
    private _business_Address: string = "";
    public get business_Address(): string {
        return this._business_Address;
    }
    public set business_Address(value: string) {
        this._business_Address = value;
    }
    private _business_Landmark: string = "";
    public get business_Landmark(): string {
        return this._business_Landmark;
    }
    public set business_Landmark(value: string) {
        this._business_Landmark = value;
    }
    private _business_Village: string = "";
    public get business_Village(): string {
        return this._business_Village;
    }
    public set business_Village(value: string) {
        this._business_Village = value;
    }
    private _business_City: string = "";
    public get business_City(): string {
        return this._business_City;
    }
    public set business_City(value: string) {
        this._business_City = value;
    }
    private _business_District: string = "";
    public get business_District(): string {
        return this._business_District;
    }
    public set business_District(value: string) {
        this._business_District = value;
    }
    private _business_State: string = "";
    public get business_State(): string {
        return this._business_State;
    }
    public set business_State(value: string) {
        this._business_State = value;
    }
    private _business_PinCode: string = "";
    public get business_PinCode(): string {
        return this._business_PinCode;
    }
    public set business_PinCode(value: string) {
        this._business_PinCode = value;
    }
    private _business_EmailId: string = "";
    public get business_EmailId(): string {
        return this._business_EmailId;
    }
    public set business_EmailId(value: string) {
        this._business_EmailId = value;
    }
    // address end
    private _flO_PsId: string = "";
    public get flO_PsId(): string {
        return this._flO_PsId;
    }
    public set flO_PsId(value: string) {
        this._flO_PsId = value;
    }
    private _loanAccountNumber: any = "";
    public get loanAccountNumber(): any {
        return this._loanAccountNumber;
    }
    public set loanAccountNumber(value: any) {
        this._loanAccountNumber = value;
    }

    constructor(params?: ISelfEmployedModel) {
        if (params) {
            common.ObjectMapping(params, this)
        }
    }
    sourceThrough: string = "LOS";
    createdOn: string = (new Date()).toDateString();

    toJSON(): any {
        return {
            "ApplicantCoappRef": this.applicantCoappRef,
            "Business_Address": this.business_Address,
            "Business_City": this.business_City,
            "Business_District": this.business_District,
            "Business_EmailId": this.business_EmailId,
            "Business_Landmark": this.business_Landmark,
            "Business_PinCode": this.business_PinCode,
            "BusinessShop_Reg_No": this.businessShop_Reg_No,
            "BusinessShop_Reg_YN": this.businessShop_Reg_YN,
            "Business_State": this.business_State,
            "Business_Village": this.business_Village,
            "End_UseOfFund": this.end_UseOfFund,
            "End_UseOfFund_Detail": this.end_UseOfFund_Detail,
            "FLO_PsId": this.flO_PsId,
            "GST_Reg_No": this.gsT_Reg_No,
            "GST_Registered_YN": this.gsT_Registered_YN,
            "ITR_lst3yr_Conf": this.itR_lst3yr_Conf,
            "Line_of_Business": this.line_of_Business,
            "Line_of_Business_Dtl_If_Others": this.line_of_Business_Dtl_If_Others,
            "ApplicationNo": this.applicationNo,
            "SourceThrough": "LOS",
            "Udyam_Reg_No": this.udyam_Reg_No,
            "Udyam_Registration_YN": this.udyam_Registration_YN,
            "LoanAccountNumber": this.loanAccountNumber
        }
    }
}

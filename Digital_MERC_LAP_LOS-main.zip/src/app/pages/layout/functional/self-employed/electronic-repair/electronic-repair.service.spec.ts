import { TestBed } from '@angular/core/testing';

import { ElectronicRepairService } from './electronic-repair.service';

describe('ElectronicRepairService', () => {
  let service: ElectronicRepairService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ElectronicRepairService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ElectronicRepairComponent } from './electronic-repair.component';

describe('ElectronicRepairComponent', () => {
  let component: ElectronicRepairComponent;
  let fixture: ComponentFixture<ElectronicRepairComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ElectronicRepairComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ElectronicRepairComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

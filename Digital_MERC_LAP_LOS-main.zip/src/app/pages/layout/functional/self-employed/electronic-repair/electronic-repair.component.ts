import { Component, Input, OnInit } from '@angular/core';
import { NotificationService } from 'src/app/notification.service';
import { Dropdown, IDropdown } from 'src/app/shared/models/common/control.model';
import { ElecronicAndRepairModel, IElecronicAndRepairModel } from 'src/app/shared/models/sanction/ElecronicAndRepairModel';
import { masterModuleDropdown } from 'src/app/shared/models/sanction/masterDropdown';
import { SanctionRequestData } from 'src/app/shared/models/sanction/sanction.model';
import { ConfigService } from 'src/app/shared/services/common/http.services';

@Component({
  selector: 'app-electronic-repair',
  templateUrl: './electronic-repair.component.html',
  styleUrls: ['./electronic-repair.component.css']
})
export class ElectronicRepairComponent implements OnInit {
  isEdit: boolean = false;
  errorTag: boolean = false;
  errorMsg: string = "";
  ElecronicAndRepair: IElecronicAndRepairModel = new ElecronicAndRepairModel();
  @Input() RequestData: any;
  RequestDataWithLan: any;
  constructor(private http: ConfigService, private notification: NotificationService) { }
  Locality: IDropdown[] = masterModuleDropdown.locality;
  ngOnInit(): void {
    this.getAPI();
  }

  Submit() {

    
    if (!this.validateElectronicAndMobileService()) {
      return;
    }


    let electricyAmount: number = this.ElecronicAndRepair.exp_Electricity_Act === "" ? 0 : parseFloat(this.ElecronicAndRepair.exp_Electricity_Act);

    this.ElecronicAndRepair.exp_Electricity_Calc =500;
    if (electricyAmount > 500) {
      this.ElecronicAndRepair.exp_Electricity_Calc = electricyAmount;
    }

    this.http.httpPost<any>(this.ElecronicAndRepair.toJSON(), "LAP_IA_ElecronicAndRepair").subscribe((res: any) => {
      if (res.errorcode == "00" || res.errorcode == "01") {
        this.notification.showSuccess(res.errorDescription, "Generic");
        this.isEdit = !this.isEdit;
      }
      else {
        this.notification.showError(res.errorDescription, "Generic");
      }
    });
  }

  radioChange(event: any) {
    this.ElecronicAndRepair.electronicItem_YN = "N";
    this.ElecronicAndRepair.computer_YN = "N";
    this.ElecronicAndRepair.mobile_YN = "N";
    this.ElecronicAndRepair.other_YN = "N";
    switch (event.target.value) {
      case "ElectronicItem":
        this.ElecronicAndRepair.electronicItem_YN = "Y";
        break;
      case "Laptop":
        this.ElecronicAndRepair.computer_YN = "Y";
        break;
      case "Mobile":
        this.ElecronicAndRepair.mobile_YN = "Y";
        break;
      case "Others":
        this.ElecronicAndRepair.other_YN = "Y";
        break;
      default: {
        break;
      }
    }
  }

  radioUPIChange(event: any) {
    this.ElecronicAndRepair.upI_YN = event.target.value;
  }

  OnChange(event: any) {
    // var shoprent =0;
    // var electricityCost=0;
    // var salaryExpenses =0;
    // var otherExpenses =0;
    // shoprent = parseFloat(this.ElecronicAndRepair.exp_Shoprent_Act);
    // electricityCost = parseFloat(this.ElecronicAndRepair.exp_Electricity_Act);
    // salaryExpenses = parseFloat(this.ElecronicAndRepair.exp_SalaryLabourCost_Act);
    // otherExpenses =parseFloat(this.ElecronicAndRepair.exp_Other_Act);
    // this.ElecronicAndRepair.exp_Calc_Total =  shoprent + electricityCost + salaryExpenses+otherExpenses;  

  }

  validateElectronicAndMobileService() {

    this.errorTag = false;
    this.errorMsg = "";
    if ((this.ElecronicAndRepair.computer_YN === "N" && this.ElecronicAndRepair.electronicItem_YN === "N"
      && this.ElecronicAndRepair.other_YN === "N" && this.ElecronicAndRepair.mobile_YN === "N") ||
      ((this.ElecronicAndRepair.computer_YN === "" && this.ElecronicAndRepair.electronicItem_YN === ""
        && this.ElecronicAndRepair.other_YN === "" && this.ElecronicAndRepair.mobile_YN === ""))
    ) {
      this.errorTag = true;
      this.errorMsg = "Please select any on product type";
      this.notification.showWarning(this.errorMsg, "Electronic and Mobile repair services");
      return false;
    }

    if (this.ElecronicAndRepair.numofPartners != 0) {
      if (this.ElecronicAndRepair.profSharingRatio === "0" || this.ElecronicAndRepair.profSharingRatio.length == 0) {
        this.errorTag = true;
        this.errorMsg = "Please enter Profit sharing Ratio for customer in %";
        this.notification.showWarning(this.errorMsg, "Electronic and Mobile repair services");
        return false;
      }
    }

    if (this.ElecronicAndRepair.electronicItem_YN === "Y") {
      if (this.ElecronicAndRepair.jobsInAMonth > 50) {
        this.errorTag = true;
        this.errorMsg = "Total jobs in a month should be less than or equal to 50";
        this.notification.showWarning(this.errorMsg, "Electronic and Mobile repair services");
        return false;
      }

      if (this.ElecronicAndRepair.avgRevenuePerJob > 1000) {
        this.errorTag = true;
        this.errorMsg = "Average Revenue per job should be less than Rs 1000";
        this.notification.showWarning(this.errorMsg, "Electronic and Mobile repair services");
        return false;
      }
    }


    if (this.ElecronicAndRepair.other_YN === "Y") {
      if (this.ElecronicAndRepair.jobsInAMonth > 125) {
        this.errorTag = true;
        this.errorMsg = "Total jobs in a month should be less than or equal to 125";
        this.notification.showWarning(this.errorMsg, "Electronic and Mobile repair services");
        return false;
      }

      if (this.ElecronicAndRepair.avgRevenuePerJob > 200) {
        this.errorTag = true;
        this.errorMsg = "Average Revenue per job should be less than Rs 200";
        this.notification.showWarning(this.errorMsg, "Electronic and Mobile repair services");
        return false;
      }

    }

    if (this.ElecronicAndRepair.computer_YN === "Y") {
      if (this.ElecronicAndRepair.jobsInAMonth > 75) {
        this.errorTag = true;
        this.errorMsg = "Total jobs in a month should be less than or equal to 75";
        this.notification.showWarning(this.errorMsg, "Electronic and Mobile repair services");
        return false;
      }

      if (this.ElecronicAndRepair.avgRevenuePerJob > 600) {
        this.errorTag = true;
        this.errorMsg = "Average Revenue per job should be less than Rs 600";
        this.notification.showWarning(this.errorMsg, "Electronic and Mobile repair services");
        return false;
      }
    }

    if (this.ElecronicAndRepair.mobile_YN === "Y") {
      if (this.ElecronicAndRepair.jobsInAMonth > 200) {
        this.errorTag = true;
        this.errorMsg = "Total jobs in a month should be less than or equal to 200";
        this.notification.showWarning(this.errorMsg, "Electronic and Mobile repair services");
        return false;
      }

      if (this.ElecronicAndRepair.avgRevenuePerJob > 200) {
        this.errorTag = true;
        this.errorMsg = "Average Revenue per job should be less than Rs 200";
        this.notification.showWarning(this.errorMsg, "Electronic and Mobile repair services");
        return false;
      }
    }



    if (this.ElecronicAndRepair.ownership_Of_Premise === 'Rented' && (!this.ElecronicAndRepair.exp_Shoprent_Act || this.ElecronicAndRepair.exp_Shoprent_Act == '')) {
      this.errorTag = true;
      this.notification.showWarning("Please enter shop rent");
      return false;
    }
    if (this.ElecronicAndRepair.ownership_Of_Premise === 'Rented' && (this.ElecronicAndRepair.exp_Shoprent_Act && Number(this.ElecronicAndRepair.exp_Shoprent_Act) == 0)) {
      this.errorTag = true;
      this.notification.showWarning("Please enter shop rent");
      return false;
    }

    // if (this.ElecronicAndRepair.exp_Electricity_Calc > 500) {
    //   this.errorTag = true;
    //   this.errorMsg = "Electricity value should be less than 500";
    //   this.notification.showWarning(this.errorMsg,"Electronic and Repair");
    //   return false;
    // }
    
    if (this.ElecronicAndRepair.numofEmplyrWorker &&   Number(this.ElecronicAndRepair.numofEmplyrWorker)>0) {
      if (!this.ElecronicAndRepair.exp_SalaryLabourCost_Act || this.ElecronicAndRepair.exp_SalaryLabourCost_Act === "" || parseFloat(this.ElecronicAndRepair.exp_SalaryLabourCost_Act) === 0) {
        this.errorTag = true;
        this.errorMsg = "Please specify the salary expense";
        this.notification.showWarning(this.errorMsg, "Electronic and Mobile repair services");
        return false;
      }
    }


    return true;
  }

  edit() {
    this.isEdit = !this.isEdit;
  }
  getAPI() {
    this.http.httpPost<any>(this.RequestData, "GetLAP_IA_ElecronicAndRepair").subscribe((res: any) => {
      this.ElecronicAndRepair = new ElecronicAndRepairModel();
      if (res.errorcode == "00")
        this.ElecronicAndRepair = new ElecronicAndRepairModel(res.data[0]);
      this.ElecronicAndRepair.loanAccountNumber = this.RequestDataWithLan.LoanAccountNumber;
    });
  }

  //Dropdown values

  //Wages frequency of Employee/Worker
  WageFrequencyList: IDropdown[] = [
    new Dropdown({ displayName: "Daily" }),
    new Dropdown({ displayName: "Weekly" }),
    new Dropdown({ displayName: "Monthly" }),
    new Dropdown({ displayName: "Job-work basis" }),
    new Dropdown({ displayName: "Other" }),
  ];

}

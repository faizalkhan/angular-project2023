import { Component, OnInit } from '@angular/core';
import { SelfEmployedModel } from "src/app/pages/layout/functional/self-employed/SelfEmployedModel";
import { NotificationService } from 'src/app/notification.service';
import { Generic, GenericConfig, IGeneric, IGenericConfig } from 'src/app/shared/models/sanction/Generic';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { Dropdown, IDropdown } from 'src/app/shared/models/common/control.model';
import { FileUpload, IfileUpload, UploadViewDownloadService } from '../../../button/upload-view-download/upload-view-download.service';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { masterModuleDropdown } from 'src/app/shared/models/sanction/masterDropdown';
import { ISelfEmployedModel } from '../ISelfEmployedModel';
import { incomeAssessmentService } from 'src/app/pages/sanction/income-assessment/income-assessment.service';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
import { common } from 'src/app/shared/models/common';

@Component({
  selector: 'app-generic',
  templateUrl: './generic.component.html',
  styleUrls: ['./generic.component.css']
})

export class GenericComponent implements OnInit {
  generic: IGeneric = new Generic();
  busines: ISelfEmployedModel = new SelfEmployedModel();
  genericParam: GenericConfig[] = [];
  RequestData: any;
  RequestDataWithLan: any;
  mainLineOfBusiness: any;
  isEdit: boolean = false;
  Ownership_Of_Premise: IDropdown[] = masterModuleDropdown.Ownership_Of_Premise;
  locality: IDropdown[] = masterModuleDropdown.locality;
  readOnly: any;
  isCashDisable: boolean = false;
  deadStockIsAny: IDropdown[] = masterModuleDropdown.Conditional;
  constructor(private http: ConfigService, private notification: NotificationService,
    private download: UploadViewDownloadService, private iaService: incomeAssessmentService, private info: SanctionService) { }



  ngOnInit(): void {
    this.readOnly = this.info.LanInfo.readOnly;
    this.download.uploadLoad = new FileUpload({
      flO_Id: "",
      loanAccountNumber: this.info.LanInfo.lan,
      moduleName: "IA_Generic",
      applicationNo: this.RequestData.ApplicationNo,
      leadID: this.info.LanInfo.leadId


    } as IfileUpload);

    this.getAPI();



  }

  getAPI() {

    this.http.httpPost<IresponseModel<Generic[]>>(this.RequestData, "GetLAP_IA_Generic").subscribe((res: IresponseModel<Generic[]>) => {
      //this.generic = new Generic();
      if (res.errorcode == "00") {
        let CurrentTrade = res.data.find((x: Generic) => x.lineOfBusiness.toLowerCase() == this.iaService.currentTrade.toLowerCase());
        if (CurrentTrade) {
          CurrentTrade.loanAccountNumber = this.RequestDataWithLan.LoanAccountNumber;
          this.generic = new Generic(CurrentTrade);
        }
      }

    });
  }
  TradeUnionChange(event: any) {
    this.generic.tradeUnionMem_YN = event.target.checked ? 'Y' : 'N';
  }
  fnValidate() {
    this.genericParam = [
      {
        businessType: 'Kirana or General store',
        gpMargin: 20,
        maxCustomerWalkInADay: 25,
        maxSalesPerCustomer: 2000
      },
      {
        businessType: 'Dairy and allied',
        gpMargin: 0,
        maxCustomerWalkInADay: 0,
        maxSalesPerCustomer: 0
      },
      {
        businessType: 'Animal husbandry',
        gpMargin: 20,
        maxCustomerWalkInADay: 10,
        maxSalesPerCustomer: 4000
      },
      {
        businessType: 'Poultry',
        gpMargin: 20,
        maxCustomerWalkInADay: 100,
        maxSalesPerCustomer: 200
      },
      {
        businessType: 'Agri and Allied',
        gpMargin: 20,
        maxCustomerWalkInADay: 10,
        maxSalesPerCustomer: 4000
      },
      {
        businessType: 'Vegetables; Fruits; Flowers',
        gpMargin: 30,
        maxCustomerWalkInADay: 100,
        maxSalesPerCustomer: 200
      },
      {
        businessType: 'Hotel; Restaurants or other eateries',
        gpMargin: 35,
        maxCustomerWalkInADay: 50,
        maxSalesPerCustomer: 500
      },
      {
        businessType: 'Building & construction materials',
        gpMargin: 10,
        maxCustomerWalkInADay: 5,
        maxSalesPerCustomer: 20000
      },
      {
        businessType: 'Readymade garments and hosiery',
        gpMargin: 30,
        maxCustomerWalkInADay: 10,
        maxSalesPerCustomer: 2000
      },
      {
        businessType: `Hardware and other equipment's`,
        gpMargin: 20,
        maxCustomerWalkInADay: 10,
        maxSalesPerCustomer: 5000
      },
      {
        businessType: 'Electronics & Furniture',
        gpMargin: 20,
        maxCustomerWalkInADay: 5,
        maxSalesPerCustomer: 20000
      },
      {
        businessType: 'Motor mechanic and garage services',
        gpMargin: 0,
        maxCustomerWalkInADay: 0,
        maxSalesPerCustomer: 0
      },
      {
        businessType: 'Electronic and Mobile repair services',
        gpMargin: 0,
        maxCustomerWalkInADay: 0,
        maxSalesPerCustomer: 0
      },
      {
        businessType: 'Tailoring/Handloom services',
        gpMargin: 0,
        maxCustomerWalkInADay: 0,
        maxSalesPerCustomer: 0
      },
      {
        businessType: 'Others',
        gpMargin: 15,
        maxCustomerWalkInADay: 25,
        maxSalesPerCustomer: 3000
      }
    ]
    let electricityExpense = this.generic.exp_Electricity_Act === "" ? 0 : parseFloat(this.generic.exp_Electricity_Act);
    // if (!this.generic.numofEmplyrWorker) {
    //   this.notification.showWarning("No. of worker required");
    //   return false;
    // }
    if(this.generic.numofEmplyrWorker && this.generic.numofEmplyrWorker>0){
      if (!this.generic.exp_SalaryLabourCost_Act || this.generic.exp_SalaryLabourCost_Act == '') {
        this.notification.showWarning("Salary expense is required");
        return false;
      }
    }

    if (this.generic.ownership_Of_Premise === "Rented") {
      let shopRent = this.generic.exp_Shoprent_Act === "" ? 0 : parseFloat(this.generic.exp_Shoprent_Act);
      if (shopRent < 1500) {
        this.notification.showWarning("Shop rent should not be less than 1500");
        return false;
      }
    }
    if (electricityExpense < 500) {
      this.notification.showWarning("Electricity expense should not be less than 500");
      return false;
    }
    let noOfEmployeeWorkers = this.generic.numofEmplyrWorker;
    let salaryExpenseCal = noOfEmployeeWorkers * 6000;
    let salaryExpense = this.generic.exp_SalaryLabourCost_Act === "" ? 0 : parseFloat(this.generic.exp_SalaryLabourCost_Act);
    if (salaryExpense < salaryExpenseCal) {
      this.notification.showWarning("Salary expense should not be less than " + salaryExpenseCal.toString());
      return false;
    }

    let config = this.genericParam.find(x => x.businessType.toLowerCase() === this.mainLineOfBusiness.toLowerCase());

    let maxCustomerWalkInADay = this.generic.walkInCust == "" ? 0 : parseFloat(this.generic.walkInCust);
    let salesPerDay = this.generic.avgRevPerCust == "" ? 0 : parseFloat(this.generic.avgRevPerCust);

    if (!config) {
      this.notification.showWarning("Config is missing please contact administrator");
      return false;
    }

    if (maxCustomerWalkInADay > config.maxCustomerWalkInADay) {
      this.notification.showWarning("No. of customers walk-in in a day should be less than or equal to " + config.maxCustomerWalkInADay.toString());
      return false;
    }

    if (maxCustomerWalkInADay < 1) {
      this.notification.showWarning("No. of customers walk-in in a day cannot be less than 1");
      return false;
    }

    if (this.generic.deadStock_YN === null || this.generic.deadStock_YN === undefined) {
      this.generic.deadStock_YN = "N";
    }

    if (this.generic.deadStock_YN === "N") {
      if (this.generic.deadStock !== "" && parseFloat(this.generic.deadStock) > 0) {
        this.notification.showWarning("Dead stock should be zero");
        return false;
      }
    }

    if (this.generic.deadStock_YN === "Y") {
      if (this.generic.deadStock === "") {
        this.notification.showWarning("Dead stock should not be blank");
        return false;
      }

      if (parseFloat(this.generic.deadStock) <= 0) {
        this.notification.showWarning("Dead stock should not be zero");
        return false;
      }
    }

    if (salesPerDay > config.maxSalesPerCustomer) {
      this.notification.showWarning("Sales per customer should be less than or equal to " + config.maxSalesPerCustomer.toString());
      return false;
    }

    if (salesPerDay < 1) {
      this.notification.showWarning("Sales per customer cannot be less than 1");
      return false;
    }

    let purchaseCostPerMon = this.generic.purchaseCostPerMon == "" ? 0 : parseFloat(this.generic.purchaseCostPerMon);
    if (purchaseCostPerMon < 1) {
      this.notification.showWarning("Total Purchase/cost associate to sales- Per Month cannot be less than 1");
      return false;
    }
    if (this.generic.tradeUnionContact && this.generic.tradeUnionContact != "" && !common.isValid_MobileNo(this.generic.tradeUnionContact)) {
      this.notification.showWarning("Please enter valid Trade Union contact");
      return false;
    }
    if (this.generic.supp_Contact_Top1 && this.generic.supp_Contact_Top1 != "" && !common.isValid_MobileNo(this.generic.supp_Contact_Top1)) {
      this.notification.showWarning("Please enter valid Supplier 1 Contact");
      return false;
    }
    if (this.generic.supp_Contact_Top2 && this.generic.supp_Contact_Top2 != "" && !common.isValid_MobileNo(this.generic.supp_Contact_Top2)) {
      this.notification.showWarning("Please enter valid Supplier 2 Contact");
      return false;
    }
    let monthlyTurnOver = this.generic.monthlyTurnOver == "" ? 0 : parseFloat(this.generic.monthlyTurnOver);
    if (monthlyTurnOver < 1) {
      this.notification.showWarning("Total sales/revenue/gross turnover - Monthly cannot be less than 1");
      return false;
    }
    if (this.generic.business_Number_Of_Months && !common.IsValidMonth(this.generic.business_Number_Of_Months)) {
      this.notification.showWarning("Please enter valid No. of years in business - months cannot be greater than 11");
      return false;
    }
    if(this.generic.seasonableBusiness_YN.toLowerCase()=='y' && (!this.generic.seasonableBusiness_Name || this.generic.seasonableBusiness_Name==''))
    {
      this.notification.showWarning("Please enter Specify business/Sources");
      return false;
    }
    if(this.generic.seasonableBusiness_YN.toLowerCase()=='y' && (!this.generic.seasonableBusinessIncome || this.generic.seasonableBusinessIncome==''))
    {
      this.notification.showWarning("Please enter Income from seasonable or other business/source");
      return false;
    }

    if(this.generic.tradeUnionMem_YN==="Y"){
       if(this.generic.memberShip_Lic_Num===""){
         this.notification.showWarning("Please specify the membership license number");
         return false;
       }

       if(this.generic.tradeUnionName===""){
        this.notification.showWarning("Please specify the trade union name");
        return false;
      }

      if(this.generic.tradeUnionContact===""){
        this.notification.showWarning("Please specify the trade union contact");
        return false;
      }

      if(this.generic.membershipCardUpload===""){
        this.notification.showWarning("Please upload the membership card document");
        return false;
      } 
    }
    return true;
  }

  RadioTradeUnion(event: any, itemType: string) {

    if (event.currentTarget.checked)
      this.generic.tradeUnionMem_YN = itemType;



  }

  RadioWareHouseChange(event: any, itemType: string) {

    if (event.currentTarget.checked)
      this.generic.warehouse_YN = itemType;

    // if (itemType === "Y")
    //   this.generic.warehouse_YN = event.currentTarget.checked ? "Y" : "N";

    // if (itemType === "N")
    //   this.generic.warehouse_YN = event.currentTarget.checked ? "Y" : "N";

  }

  RadioSellingModeChange(event: any, itemType: string) {

    if (event.currentTarget.checked)
      this.generic.sellingMode = itemType;

    if (itemType === "Cash only") {
      this.isCashDisable = false;
    } else {
      this.isCashDisable = true;
    }
    // if (itemType === "C")
    //   this.generic.sellingMode = event.currentTarget.checked ? "C" : "CC";

    // if (itemType === "CC")
    //   this.generic.sellingMode = event.currentTarget.checked ? "CC" : "C";

  }

  RadioUPIPaymentChange(event: any, itemType: string) {
    // if (itemType === "Y")
    //   this.generic.upI_YN = event.currentTarget.checked ? "Y" : "N";

    // if (itemType === "N")
    //   this.generic.upI_YN = event.currentTarget.checked ? "Y" : "N";
    if (event.currentTarget.checked)
      this.generic.upI_YN = itemType;

  }
  RadioSeasonableBusinessChange(event: any, itemType: string) {
    if (event.currentTarget.checked)
      this.generic.seasonableBusiness_YN = itemType;

    // if (itemType === "N" && event.currentTarget.checked)
    //   this.generic.seasonableBusiness_YN = "N";

  }
  //Wages frequency of Employee/Worker
  WageFrequencyList: IDropdown[] = [
    new Dropdown({ displayName: "Daily" }),
    new Dropdown({ displayName: "Weekly" }),
    new Dropdown({ displayName: "Monthly" }),
    // new Dropdown({ displayName: "Job-Work basis" }),
    // new Dropdown({ displayName: "Other" }),
  ];

  Submit() {
    if (!this.fnValidate())
      return

    this.http.httpPostWithouImageData<any>(this.generic.toJSON(), "LAP_IA_Generic", this.generic.toJSONwithoutImageData()).subscribe((res: any) => {
      if (res.errorcode == "00") {
        this.notification.showSuccess(res.errorDescription, "Generic");
        this.isEdit = false;
      }
      else {
        this.notification.showError(res.errorDescription, "Generic");
      }
    });

  }

  uploadChange(event: IfileUpload) {
    this.generic.membershipCardUpload = event.imageData;
    this.generic.memCardUploadExtension = event.extension;
    this.generic.memCardUploadMimeType = event.imageMIMEType;
  }

  edit() {
    this.isEdit = !this.isEdit;
  }
  cancel(event: any) {
    this.generic = new Generic(event);
  }
}

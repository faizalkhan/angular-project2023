import { HttpParams } from "@angular/common/http";
import { ThisReceiver } from "@angular/compiler";
import { common } from "src/app/shared/models/common";
import { Ifile } from "../../../button/upload-view-download/upload-view-download.service";


export interface ITailoringShop {
  loanAccountNumber: string;
  applicationNo: string;
  applicantCoappRef: string;
  core_Handloom_YN: string;
  core_Tailoring_YN: string;
  businessPremise: string;
  shopName: string;
  number_Of_Years: number;
  ownership_Of_Premise: string;
  numOfFam: number;
  numofPartners: number;
  profSharingRatio: string;
  profSharingRatio_Disable: boolean;
  numofEmplyrWorker: number;
  sewing_YN: string;
  embroidery_YN: string;
  handloom_YN: string;
  powerloom_YN: string;
  numOfMachines: string;
  bA_OI_Total_Institution: string;
  bA_OI_Name_Top1: string;
  bA_OI_Contact_Top1: string;
  bA_OI_Address_Top1: string;
  bA_OI_Name_Top2: string;
  bA_OI_Contact_Top2: string;
  bA_OI_Address_Top2: string;
  bA_OI_MonthlyVol: string;
  bA_OI_RevPerUnit: number;
  bA_OI_ExpPerUnit: number;
  bA_OI_JobsInHand: number;
  bA_OI_NumOfMonths: number;
  bA_OI_Receivable: number;
  bA_OI_Payable: number;
  MembershipCard_Upload: Ifile;
  bA_OI_MembershipLicUpload_YN: string;
  bA_OI_MembershipLicUpload: string;
  bA_RC_MonthlyVol: string;
  bA_RC_RevPerUnit: number;
  bA_RC_ExpPerUnit: number;
  bA_RC_JobsInHand: number;
  bA_RC_NumOfMonths: number;
  bA_RC_Receivable: number;
  bA_RC_Payable: number;
  bA_M_JobsInHand: number;
  bA_M_JobsInMonth_Cap: number;
  bA_M_ItemsInStock: number;
  bA_M_ItemsMade: string;
  bA_M_MonthlyPurchase: number;
  bA_M_RevenuePerUnit: number;
  bA_M_CostPerUnit: number;
  bA_M_ProdCycle: number;
  bA_M_Receivable: number;
  bA_M_Payable: number;
  other_Net_Income: number;
  other_Net_IncomeDetail: string;
  exp_Shoprent_Act: string;
  exp_Electricity_Act: string;
  exp_Consumable_Act: string;
  exp_SalaryLabourCost_Act: string;
  exp_Other_Act: string;
  exp_Act_Total: string;
  exp_Shoprent_Calc: string;
  exp_Electricity_Calc: string;
  exp_Consumable_Calc: string;
  exp_SalaryLabourCost_Calc: string;
  exp_Other_Calc: string;
  exp_Calc_Total: string;
  flO_PsId: string;
  typeOfMachine: any[];
  //typeofProduct: any[];
  isBussinessArrangement_EndCustomer: string;
  locality_Business: string;
  jobWorkType: string;
  workType_OI: string;
  workType_RC: string;
  workType_Manufacturer: string;
  upI_YN: string;
  toJSON(header?: boolean): any;
}

export class TailoringShop implements ITailoringShop {

  private _loanAccountNumber: string = '';
  public get loanAccountNumber(): string {
    return this._loanAccountNumber;
  }
  public set loanAccountNumber(value: string) {
    this._loanAccountNumber = value;
  }
  private _applicationNo: string = "";
  public get applicationNo(): string {
    return this._applicationNo;
  }
  public set applicationNo(value: string) {
    this._applicationNo = value;
  }

  private _applicantCoappRef: string = "";
  public get applicantCoappRef(): string {
    return this._applicantCoappRef;
  }
  public set applicantCoappRef(value: string) {
    this._applicantCoappRef = value;
  }

  private _core_Handloom_YN: string = "";
  public get core_Handloom_YN(): string {
    return this._core_Handloom_YN;
  }
  public set core_Handloom_YN(value: string) {
    this._core_Handloom_YN = value;
  }

  private _core_Tailoring_YN: string = "N";

  public get core_Tailoring_YN(): string {
    return this._core_Tailoring_YN;
  }
  public set core_Tailoring_YN(value: string) {
    this._core_Tailoring_YN = value;
  }

  private _businessPremise: string = "";
  public get businessPremise(): string {
    return this._businessPremise;
  }
  public set businessPremise(value: string) {
    this._businessPremise = value;
  }

  private _shopName: string = "";
  public get shopName(): string {
    return this._shopName;
  }
  public set shopName(value: string) {
    this._shopName = value;
  }

  private _number_Of_Years: number = 0;
  public get number_Of_Years(): number {
    return this._number_Of_Years;
  }
  public set number_Of_Years(value: number) {
    this._number_Of_Years = value;
  }

  private _ownership_Of_Premise: string = "";
  public get ownership_Of_Premise(): string {
    return this._ownership_Of_Premise;
  }
  public set ownership_Of_Premise(value: string) {
    this._ownership_Of_Premise = value;
  }

  private _numOfFam: number = 0;
  public get numOfFam(): number {
    return this._numOfFam;
  }
  public set numOfFam(value: number) {
    this._numOfFam = value;
  }

  private _numofPartners: number = 0;
  public get numofPartners(): number {
    return this._numofPartners;
  }
  public set numofPartners(value: number) {
    this._numofPartners = ((value ?? "") == 0 ? Number(0) : Number(value));
    this.profSharingRatio_Disable = this._numofPartners == 0;
  }

  private _profSharingRatio_Disable: boolean = false;
  public get profSharingRatio_Disable(): boolean {
    return this._profSharingRatio_Disable;
  }
  public set profSharingRatio_Disable(value: boolean) {
    this._profSharingRatio_Disable = value;
    if (value == true)
      this._profSharingRatio = "0";
  }

  private _profSharingRatio: string = "";
  public get profSharingRatio(): string {
    return this._profSharingRatio;
  }
  public set profSharingRatio(value: string) {
    this._profSharingRatio = value;
  }

  private _numofEmplyrWorker: number = 0;
  public get numofEmplyrWorker(): number {
    return this._numofEmplyrWorker;
  }
  public set numofEmplyrWorker(value: number) {
    this._numofEmplyrWorker = value;
  }

  private _sewing_YN: string = "";
  public get sewing_YN(): string {
    return this._sewing_YN;
  }
  public set sewing_YN(value: string) {
    this._sewing_YN = value;
  }

  private _embroidery_YN: string = "";
  public get embroidery_YN(): string {
    return this._embroidery_YN;
  }
  public set embroidery_YN(value: string) {
    this._embroidery_YN = value;
  }

  private _handloom_YN: string = "";
  public get handloom_YN(): string {
    return this._handloom_YN;
  }
  public set handloom_YN(value: string) {
    this._handloom_YN = value;
  }

  private _powerloom_YN: string = "";
  public get powerloom_YN(): string {
    return this._powerloom_YN;
  }
  public set powerloom_YN(value: string) {
    this._powerloom_YN = value;
  }

  private _numOfMachines: string = "";
  public get numOfMachines(): string {
    return this._numOfMachines;
  }
  public set numOfMachines(value: string) {
    this._numOfMachines = value;
  }

  private _bA_OI_Total_Institution: string = "";
  public get bA_OI_Total_Institution(): string {
    return this._bA_OI_Total_Institution;
  }
  public set bA_OI_Total_Institution(value: string) {
    this._bA_OI_Total_Institution = value;
  }

  private _bA_OI_Name_Top1: string = "";
  public get bA_OI_Name_Top1(): string {
    return this._bA_OI_Name_Top1;
  }
  public set bA_OI_Name_Top1(value: string) {
    this._bA_OI_Name_Top1 = value;
  }

  private _bA_OI_Contact_Top1: string = "";
  public get bA_OI_Contact_Top1(): string {
    return this._bA_OI_Contact_Top1;
  }
  public set bA_OI_Contact_Top1(value: string) {
    this._bA_OI_Contact_Top1 = value;
  }

  private _bA_OI_Address_Top1: string = "";
  public get bA_OI_Address_Top1(): string {
    return this._bA_OI_Address_Top1;
  }
  public set bA_OI_Address_Top1(value: string) {
    this._bA_OI_Address_Top1 = value;
  }

  private _bA_OI_Name_Top2: string = "";
  public get bA_OI_Name_Top2(): string {
    return this._bA_OI_Name_Top2;
  }
  public set bA_OI_Name_Top2(value: string) {
    this._bA_OI_Name_Top2 = value;
  }

  private _bA_OI_Contact_Top2: string = "";
  public get bA_OI_Contact_Top2(): string {
    return this._bA_OI_Contact_Top2;
  }
  public set bA_OI_Contact_Top2(value: string) {
    this._bA_OI_Contact_Top2 = value;
  }

  private _bA_OI_Address_Top2: string = "";
  public get bA_OI_Address_Top2(): string {
    return this._bA_OI_Address_Top2;
  }
  public set bA_OI_Address_Top2(value: string) {
    this._bA_OI_Address_Top2 = value;
  }

  private _bA_OI_MonthlyVol: string = "";
  public get bA_OI_MonthlyVol(): string {
    return this._bA_OI_MonthlyVol;
  }
  public set bA_OI_MonthlyVol(value: string) {
    this._bA_OI_MonthlyVol = value;
  }

  private _bA_OI_RevPerUnit: number = 0;
  public get bA_OI_RevPerUnit(): number {
    return this._bA_OI_RevPerUnit;
  }
  public set bA_OI_RevPerUnit(value: number) {
    this._bA_OI_RevPerUnit = value;
  }

  private _bA_OI_ExpPerUnit: number = 0;
  public get bA_OI_ExpPerUnit(): number {
    return this._bA_OI_ExpPerUnit;
  }
  public set bA_OI_ExpPerUnit(value: number) {
    this._bA_OI_ExpPerUnit = value;
  }

  private _bA_OI_JobsInHand: number = 0;
  public get bA_OI_JobsInHand(): number {
    return this._bA_OI_JobsInHand;
  }
  public set bA_OI_JobsInHand(value: number) {
    this._bA_OI_JobsInHand = value;
  }

  private _bA_OI_NumOfMonths: number = 0;
  public get bA_OI_NumOfMonths(): number {
    return this._bA_OI_NumOfMonths;
  }
  public set bA_OI_NumOfMonths(value: number) {
    this._bA_OI_NumOfMonths = value;
  }

  private _bA_OI_Receivable: number = 0;
  public get bA_OI_Receivable(): number {
    return this._bA_OI_Receivable;
  }
  public set bA_OI_Receivable(value: number) {
    this._bA_OI_Receivable = value;
  }

  private _bA_OI_Payable: number = 0;
  public get bA_OI_Payable(): number {
    return this._bA_OI_Payable;
  }
  public set bA_OI_Payable(value: number) {
    this._bA_OI_Payable = value;
  }
  private _bA_OI_MembershipLicUpload_YN: string = "";
  public get bA_OI_MembershipLicUpload_YN(): string {
    return this._bA_OI_MembershipLicUpload_YN;
  }
  public set bA_OI_MembershipLicUpload_YN(value: string) {
    this._bA_OI_MembershipLicUpload_YN = value;
  }

  private _bA_OI_MembershipLicUpload: string = "";
  public get bA_OI_MembershipLicUpload(): string {
    return this._bA_OI_MembershipLicUpload;
  }
  public set bA_OI_MembershipLicUpload(value: string) {
    this._bA_OI_MembershipLicUpload = value;
  }

  private _bA_RC_MonthlyVol: string = "";
  public get bA_RC_MonthlyVol(): string {
    return this._bA_RC_MonthlyVol;
  }
  public set bA_RC_MonthlyVol(value: string) {
    this._bA_RC_MonthlyVol = value;
  }

  private _bA_RC_RevPerUnit: number = 0;
  public get bA_RC_RevPerUnit(): number {
    return this._bA_RC_RevPerUnit;
  }
  public set bA_RC_RevPerUnit(value: number) {
    this._bA_RC_RevPerUnit = value;
  }

  private _bA_RC_ExpPerUnit: number = 0
  public get bA_RC_ExpPerUnit(): number {
    return this._bA_RC_ExpPerUnit;
  }
  public set bA_RC_ExpPerUnit(value: number) {
    this._bA_RC_ExpPerUnit = value;
  }

  private _bA_RC_JobsInHand: number = 0;
  public get bA_RC_JobsInHand(): number {
    return this._bA_RC_JobsInHand;
  }
  public set bA_RC_JobsInHand(value: number) {
    this._bA_RC_JobsInHand = value;
  }


  private _bA_RC_NumOfMonths: number = 0;
  public get bA_RC_NumOfMonths(): number {
    return this._bA_RC_NumOfMonths;
  }
  public set bA_RC_NumOfMonths(value: number) {
    this._bA_RC_NumOfMonths = value;
  }

  private _bA_RC_Receivable: number = 0;
  public get bA_RC_Receivable(): number {
    return this._bA_RC_Receivable;
  }
  public set bA_RC_Receivable(value: number) {
    this._bA_RC_Receivable = value;
  }

  private _bA_RC_Payable: number = 0;
  public get bA_RC_Payable(): number {
    return this._bA_RC_Payable;
  }
  public set bA_RC_Payable(value: number) {
    this._bA_RC_Payable = value;
  }

  private _bA_M_JobsInHand: number = 0;
  public get bA_M_JobsInHand(): number {
    return this._bA_M_JobsInHand;
  }
  public set bA_M_JobsInHand(value: number) {
    this._bA_M_JobsInHand = value;
  }

  private _bA_M_JobsInMonth_Cap: number = 0;
  public get bA_M_JobsInMonth_Cap(): number {
    return this._bA_M_JobsInMonth_Cap;
  }
  public set bA_M_JobsInMonth_Cap(value: number) {
    this._bA_M_JobsInMonth_Cap = value;
  }

  private _bA_M_ItemsInStock: number = 0;
  public get bA_M_ItemsInStock(): number {
    return this._bA_M_ItemsInStock;
  }
  public set bA_M_ItemsInStock(value: number) {
    this._bA_M_ItemsInStock = value;
  }

  private _bA_M_ItemsMade: string = "";
  public get bA_M_ItemsMade(): string {
    return this._bA_M_ItemsMade;
  }
  public set bA_M_ItemsMade(value: string) {
    this._bA_M_ItemsMade = value;
  }

  private _bA_M_MonthlyPurchase: number = 0;
  public get bA_M_MonthlyPurchase(): number {
    return this._bA_M_MonthlyPurchase;
  }
  public set bA_M_MonthlyPurchase(value: number) {
    this._bA_M_MonthlyPurchase = value;
  }

  private _bA_M_RevenuePerUnit: number = 0;
  public get bA_M_RevenuePerUnit(): number {
    return this._bA_M_RevenuePerUnit;
  }
  public set bA_M_RevenuePerUnit(value: number) {
    this._bA_M_RevenuePerUnit = value;
  }

  private _bA_M_CostPerUnit: number = 0;
  public get bA_M_CostPerUnit(): number {
    return this._bA_M_CostPerUnit;
  }
  public set bA_M_CostPerUnit(value: number) {
    this._bA_M_CostPerUnit = value;
  }

  private _bA_M_ProdCycle: number = 0;
  public get bA_M_ProdCycle(): number {
    return this._bA_M_ProdCycle;
  }
  public set bA_M_ProdCycle(value: number) {
    this._bA_M_ProdCycle = value;
  }

  private _bA_M_Receivable: number = 0;
  public get bA_M_Receivable(): number {
    return this._bA_M_Receivable;
  }
  public set bA_M_Receivable(value: number) {
    this._bA_M_Receivable = value;
  }

  private _bA_M_Payable: number = 0;
  public get bA_M_Payable(): number {
    return this._bA_M_Payable;
  }
  public set bA_M_Payable(value: number) {
    this._bA_M_Payable = value;
  }

  private _other_Net_Income: number = 0;
  public get other_Net_Income(): number {
    return this._other_Net_Income;
  }
  public set other_Net_Income(value: number) {
    this._other_Net_Income = value;
  }

  private _other_Net_IncomeDetail: string = "";
  public get other_Net_IncomeDetail(): string {
    return this._other_Net_IncomeDetail;
  }
  public set other_Net_IncomeDetail(value: string) {
    this._other_Net_IncomeDetail = value;
  }

  private _exp_Shoprent_Act: string = "";
  public get exp_Shoprent_Act(): string {
    return this._exp_Shoprent_Act;
  }
  public set exp_Shoprent_Act(value: string) {
    this._exp_Shoprent_Act = value;
  }

  private _exp_Electricity_Act: string = "";
  public get exp_Electricity_Act(): string {
    return this._exp_Electricity_Act;
  }
  public set exp_Electricity_Act(value: string) {
    this._exp_Electricity_Act = value;
  }

  private _exp_Consumable_Act: string = "";
  public get exp_Consumable_Act(): string {
    return this._exp_Consumable_Act;
  }
  public set exp_Consumable_Act(value: string) {
    this._exp_Consumable_Act = value;
  }

  private _exp_SalaryLabourCost_Act: string = "";
  public get exp_SalaryLabourCost_Act(): string {
    return this._exp_SalaryLabourCost_Act;
  }
  public set exp_SalaryLabourCost_Act(value: string) {
    this._exp_SalaryLabourCost_Act = value;
  }

  private _exp_Other_Act: string = "";
  public get exp_Other_Act(): string {
    return this._exp_Other_Act;
  }
  public set exp_Other_Act(value: string) {
    this._exp_Other_Act = value;
  }

  private _exp_Act_Total: string = "";
  public get exp_Act_Total(): string {
    return this._exp_Act_Total;
  }
  public set exp_Act_Total(value: string) {
    this._exp_Act_Total = value;
  }

  private _exp_Shoprent_Calc: string = "";
  public get exp_Shoprent_Calc(): string {
    return this._exp_Shoprent_Calc;
  }
  public set exp_Shoprent_Calc(value: string) {
    this._exp_Shoprent_Calc = value;
    this.totalCalcTailoring();
  }

  private _exp_Electricity_Calc: string = "";
  public get exp_Electricity_Calc(): string {
    return this._exp_Electricity_Calc;
  }
  public set exp_Electricity_Calc(value: string) {
    this._exp_Electricity_Calc = value;
    this.totalCalcTailoring();
  }

  private _exp_Consumable_Calc: string = "";
  public get exp_Consumable_Calc(): string {
    return this._exp_Consumable_Calc;
  }
  public set exp_Consumable_Calc(value: string) {
    this._exp_Consumable_Calc = value;
    this.totalCalcTailoring()
  }

  private _exp_SalaryLabourCost_Calc: string = "";
  public get exp_SalaryLabourCost_Calc(): string {
    return this._exp_SalaryLabourCost_Calc;
  }
  public set exp_SalaryLabourCost_Calc(value: string) {
    this._exp_SalaryLabourCost_Calc = value;
    this.totalCalcTailoring();
  }

  private _exp_Other_Calc: string = "";
  public get exp_Other_Calc(): string {
    return this._exp_Other_Calc;
  }
  public set exp_Other_Calc(value: string) {
    this._exp_Other_Calc = value;
    this.totalCalcTailoring();
  }

  private _exp_Calc_Total: string = "";
  public get exp_Calc_Total(): string {
    return this._exp_Calc_Total;
  }
  public set exp_Calc_Total(value: string) {
    this._exp_Calc_Total = value;
  }
  private _flO_PsId: string = "";
  public get flO_PsId(): any {
    return this._flO_PsId;
  }
  public set flO_PsId(value: any) {
    this._flO_PsId = value;
  }
  // private _typeofProduct: any[] = [
  //   { name: "Tailoring", selected: false },
  //   { name: "Handlooms", selected: false }
  // ];
  // public get typeofProduct(): any[] {
  // //return this._typeofProduct;

  // let product =this;
  // return  [{ name: "Tailoring", selected: product.core_Tailoring_YN.toUpperCase()==="Y" },
  //          { name: "Handlooms", selected: product.handloom_YN.toUpperCase()==="Y" }]
  //}
  // public set typeofProduct(value: any[]) {
  //   this._typeofProduct = value;
  // }

  public get typeOfMachine(): any[] {
    let self = this;
    return [
      { name: "Sewing Machine", selected: self.sewing_YN.toUpperCase() == "Y" },
      { name: "Embroidery Machine", selected: self.embroidery_YN.toUpperCase() == "Y" },
      { name: "Handloom", selected: self.handloom_YN.toUpperCase() == "Y" },
      { name: "Powerloom", selected: self.powerloom_YN.toUpperCase() == "Y" }
    ]
  }
  private _locality: string = "";
  public get locality_Business(): string {
    return this._locality;
  }
  public set locality_Business(value: string) {
    this._locality = value;
  }

  private _jobWorkType: string = "";
  public get jobWorkType(): string {
    return this._jobWorkType;
  }
  public set jobWorkType(value: string) {
    this._jobWorkType = value;
  }

  private _isBussinessArrangement_EndCustomer: string = "";
  public get isBussinessArrangement_EndCustomer(): string {
    return this._isBussinessArrangement_EndCustomer;
  }
  public set isBussinessArrangement_EndCustomer(value: string) {
    this._isBussinessArrangement_EndCustomer = value;
  }

  private _workType_OI: string = "";
  public get workType_OI(): string {
    return this._workType_OI;
  }
  public set workType_OI(value: string) {
    this._workType_OI = value;
  }

  private _workType_RC: string = "";
  public get workType_RC(): string {
    return this._workType_RC;
  }
  public set workType_RC(value: string) {
    this._workType_RC = value;
  }

  private _workType_Manufacturer: string = "";
  public get workType_Manufacturer(): string {
    return this._workType_Manufacturer;
  }
  public set workType_Manufacturer(value: string) {
    this._workType_Manufacturer = value;
  }

  private _UPI_YN: string = "";
  public get upI_YN(): string {
    return this._UPI_YN;
  }
  public set upI_YN(value: string) {
    this._UPI_YN = value;
  }
  private _bA_OI_LicUplMimeType: string = "";
  public get bA_OI_LicUplMimeType(): string {
    return this._bA_OI_LicUplMimeType;
  }
  public set bA_OI_LicUplMimeType(value: string) {
    this._bA_OI_LicUplMimeType = value;
  }
  private _bA_OI_LicUplExtension: string = "";
  public get bA_OI_LicUplExtension(): string {
    return this._bA_OI_LicUplExtension;
  }
  public set bA_OI_LicUplExtension(value: string) {
    this._bA_OI_LicUplExtension = value;
  }
  constructor(params?: ITailoringShop) {
    if (params) {
      common.ObjectMapping(params, this);
    }
  }
  private _MembershipCard_Upload: Ifile = {} as Ifile;
  public get MembershipCard_Upload(): Ifile {
    return this._MembershipCard_Upload;
  }
  public set MembershipCard_Upload(value: Ifile) {
    this._MembershipCard_Upload = value;
  }
  toJSON(header: boolean = false): any {
    return {

      "LoanAccountNumber": this.loanAccountNumber,
      "ApplicationNo": this.applicationNo,
      "ApplicantCoappRef": this.applicantCoappRef,
      "Core_Handloom_YN": this.core_Handloom_YN,
      "Core_Tailoring_YN": this.core_Tailoring_YN,
      "BusinessPremise": this.businessPremise,
      "ShopName": this.shopName,
      "Number_Of_Years": this.number_Of_Years,
      "Ownership_Of_Premise": this.ownership_Of_Premise,
      "NumOfFam": this.numOfFam,
      "NumofPartners": this.numofPartners,
      "ProfSharingRatio": this.profSharingRatio,
      "NumofEmplyrWorker": this.numofEmplyrWorker,
      "Sewing_YN": this.sewing_YN,
      "Embroidery_YN": this.embroidery_YN,
      "Handloom_YN": this.handloom_YN,
      "Powerloom_YN": this.powerloom_YN,
      "NumOfMachines": this.numOfMachines,
      "BA_OI_Total_Institution": this.bA_OI_Total_Institution,
      "BA_OI_Name_Top1": this.bA_OI_Name_Top1,
      "BA_OI_Contact_Top1": this.bA_OI_Contact_Top1,
      "BA_OI_Address_Top1": this.bA_OI_Address_Top1,
      "BA_OI_Name_Top2": this.bA_OI_Name_Top2,
      "BA_OI_Contact_Top2": this.bA_OI_Contact_Top2,
      "BA_OI_Address_Top2": this.bA_OI_Address_Top2,
      "BA_OI_MonthlyVol": this.bA_OI_MonthlyVol,
      "BA_OI_RevPerUnit": this.bA_OI_RevPerUnit.toString(),
      "BA_OI_ExpPerUnit": this.bA_OI_ExpPerUnit.toString(),
      "BA_OI_JobsInHand": this.bA_OI_JobsInHand,
      "BA_OI_NumOfMonths": this.bA_OI_NumOfMonths,
      "BA_OI_Receivable": this.bA_OI_Receivable.toString(),
      "BA_OI_Payable": this.bA_OI_Payable.toString(),
      "BA_OI_MembershipLicUpload_YN": this.bA_OI_MembershipLicUpload_YN,
      "BA_OI_MembershipLicUpload": header ? "" : this.MembershipCard_Upload?.file,
      "BA_OI_LicUplMimeType": this.MembershipCard_Upload?.format,
      "BA_OI_LicUplExtension": this.MembershipCard_Upload?.extension,
      "BA_RC_MonthlyVol": this.bA_RC_MonthlyVol,
      "BA_RC_RevPerUnit": this.bA_RC_RevPerUnit.toString(),
      "BA_RC_ExpPerUnit": this.bA_RC_ExpPerUnit.toString(),
      "BA_RC_JobsInHand": this.bA_RC_JobsInHand,
      "BA_RC_NumOfMonths": this.bA_RC_NumOfMonths,
      "BA_RC_Receivable": this.bA_RC_Receivable.toString(),
      "BA_RC_Payable": this.bA_RC_Payable.toString(),
      "BA_M_JobsInHand": this.bA_M_JobsInHand,
      "BA_M_JobsInMonth_Cap": this.bA_M_JobsInMonth_Cap.toString(),
      "BA_M_ItemsInStock": this.bA_M_ItemsInStock.toString(),
      "BA_M_ItemsMade": this.bA_M_ItemsMade,
      "BA_M_MonthlyPurchase": this.bA_M_MonthlyPurchase.toString(),
      "BA_M_RevenuePerUnit": this.bA_M_RevenuePerUnit.toString(),
      "BA_M_CostPerUnit": this.bA_M_CostPerUnit.toString(),
      "BA_M_ProdCycle": this.bA_M_ProdCycle.toString(),
      "BA_M_Receivable": this.bA_M_Receivable.toString(),
      "BA_M_Payable": this.bA_M_Payable.toString(),
      "Other_Net_Income": this.other_Net_Income.toString(),
      "Other_Net_IncomeDetail": this.other_Net_IncomeDetail,
      "Exp_Shoprent_Act": this.exp_Shoprent_Act,
      "Exp_Electricity_Act": this.exp_Electricity_Act,
      "Exp_Consumable_Act": this.exp_Consumable_Act,
      "Exp_SalaryLabourCost_Act": this.exp_SalaryLabourCost_Act,
      "Exp_Other_Act": this.exp_Other_Act,
      "Exp_Act_Total": this.exp_Act_Total,
      "Exp_Shoprent_Calc": this.exp_Shoprent_Act,
      "Exp_Electricity_Calc": this.exp_Electricity_Calc,
      "Exp_Consumable_Calc": this.exp_Consumable_Act,
      "Exp_SalaryLabourCost_Calc": this.exp_SalaryLabourCost_Act,
      "Exp_Other_Calc": this.exp_Other_Act,
      "Exp_Calc_Total": this.exp_Calc_Total,
      "FlO_PsId": this.flO_PsId,
      "SourceThrough": "LOS",
      "Locality_Business": this.locality_Business,
      "ISBussinessArrangement_EndCustomer": this.isBussinessArrangement_EndCustomer,
      "WorkType_OI": this.workType_OI,
      "WorkType_RC": this.workType_RC === undefined ? "N" : this.workType_RC,
      "WorkType_Manufacturer": this.workType_Manufacturer,
      "UPI_YN": this.upI_YN
    }
  }

  totalCalcTailoring() {

    var shoprent = 0;
    var electricityCost = 0;
    var salaryExpenses = 0;
    var otherExpenses = 0;
    var consumableCost = 0;
    var totalCost = 0;
    shoprent = this.exp_Shoprent_Calc != "" ? parseFloat(this.exp_Shoprent_Calc) : 0;
    electricityCost = this.exp_Electricity_Calc != "" ? parseFloat(this.exp_Electricity_Calc) : 0;
    salaryExpenses = this.exp_SalaryLabourCost_Calc != "" ? parseFloat(this.exp_SalaryLabourCost_Calc) : 0;
    otherExpenses = this.exp_Other_Calc != "" ? parseFloat(this.exp_Other_Calc) : 0;
    consumableCost = this.exp_Consumable_Calc != "" ? parseFloat(this.exp_Consumable_Calc) : 0;
    totalCost = shoprent + electricityCost + salaryExpenses + otherExpenses + consumableCost;
    this.exp_Calc_Total = totalCost.toString();
  }



}

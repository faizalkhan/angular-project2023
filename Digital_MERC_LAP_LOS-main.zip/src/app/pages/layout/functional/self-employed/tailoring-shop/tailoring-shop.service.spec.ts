import { TestBed } from '@angular/core/testing';

import { TailoringShopService } from './tailoring-shop.service';

describe('TailoringShopService', () => {
  let service: TailoringShopService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TailoringShopService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

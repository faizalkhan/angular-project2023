import { Component, OnInit } from '@angular/core';
import { NotificationService } from 'src/app/notification.service';
import { common } from 'src/app/shared/models/common';
import { Dropdown, IDropdown } from 'src/app/shared/models/common/control.model';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { FileUpload, Ifile, IfileUpload, ResponseDownload, UploadViewDownloadService } from '../../../button/upload-view-download/upload-view-download.service';
import { ITailoringShop, TailoringShop } from './tailoringshop';

@Component({
  selector: 'app-tailoring-shop',
  templateUrl: './tailoring-shop.component.html',
  styleUrls: ['./tailoring-shop.component.css']
})
export class TailoringShopComponent implements OnInit {
  SelfEmployed: ITailoringShop = new TailoringShop();
  fileUpload: IfileUpload = new FileUpload();
  isEdit: boolean = false;
  RequestData: any;
  RequestDataWithLan: any;
  errorTag: boolean = false;
  errorMsg: string = "";
  readOnly: any;


  constructor(private http: ConfigService, private notify: NotificationService, private sanctionService: SanctionService,
    private download: UploadViewDownloadService) { }

  ngOnInit(): void {
    this.readOnly = this.sanctionService.LanInfo.readOnly;
    this.fileUpload.loanAccountNumber = this.RequestDataWithLan.LoanAccountNumber;
    this.fileUpload.flO_Id = this.RequestDataWithLan.flopsid;
    this.fileUpload.applicationNo = this.RequestData.application;
    this.fileUpload.moduleName = "TailoringHanloom";
    this.fileUpload.type = "";

    this.download.uploadLoad = new FileUpload({
      flO_Id: this.RequestDataWithLan.FLO_PsId,
      loanAccountNumber: this.RequestDataWithLan.LoanAccountNumber,
      moduleName: "IA_TailoringHandloom",
      applicationNo: this.RequestData.ApplicationNo,
      leadID: this.RequestData.ApplicationNo
    } as IfileUpload);

    this.getAPI();
  }

  typeOfMachineChange(child: any, event: any) {

    switch (child.name.toUpperCase()) {
      case "SEWING MACHINE":
        this.SelfEmployed.sewing_YN = event.currentTarget.checked == true ? 'Y' : 'N';
        break;
      case "EMBROIDERY MACHINE":
        this.SelfEmployed.embroidery_YN = event.currentTarget.checked == true ? 'Y' : 'N';
        break;
      case "HANDLOOM":
        this.SelfEmployed.handloom_YN = event.currentTarget.checked == true ? 'Y' : 'N';
        break;
      case "POWERLOOM":
        this.SelfEmployed.powerloom_YN = event.currentTarget.checked == true ? 'Y' : 'N';
        break;
    }
  }

  checkboxChange(event: any, itemType: any) {



    if (itemType === "OI") {
      this.SelfEmployed.workType_OI = event.currentTarget.checked ? "Y" : "N";

    }

    if (itemType === "RC") {
      this.SelfEmployed.workType_RC = event.currentTarget.checked ? "Y" : "N";
    }

    if (itemType === "Manufacturer") {
      this.SelfEmployed.workType_Manufacturer = event.currentTarget.checked ? "Y" : "N";
    }

    this.SelfEmployed.isBussinessArrangement_EndCustomer = "N";

    if (this.SelfEmployed.workType_OI === "Y" || this.SelfEmployed.workType_RC === "Y" || this.SelfEmployed.workType_Manufacturer === "Y") {
      this.SelfEmployed.isBussinessArrangement_EndCustomer = "Y";
    }
  }


  chkBusiness(event: any) {

    this.SelfEmployed.isBussinessArrangement_EndCustomer = event.currentTarget.checked === true ? "Y" : "N";
    if (event.currentTarget.checked === false) {
      this.SelfEmployed.workType_OI = "N";
      this.SelfEmployed.workType_RC = "N"
      this.SelfEmployed.workType_Manufacturer = "N";
    }

  }

  chkUPIPaymentChange(event: any) {
    this.SelfEmployed.upI_YN = event.currentTarget.checked === true ? "Y" : "N";
  }

  getAPI() {

    this.http.httpPost<any>(this.RequestData, "GetLAP_IA_TailoringHandloom").subscribe((res: any) => {
      this.SelfEmployed = new TailoringShop();
      if (res.errorcode == "00")
        this.SelfEmployed = new TailoringShop(res.data[0]);
      this.download.DownloadFromAPI(this.SelfEmployed.bA_OI_MembershipLicUpload).subscribe((res: ResponseDownload) => {
        this.SelfEmployed.MembershipCard_Upload = { extension: res.data[0].ext, file: res.data[0].fileStream, filename: res.data[0].fileName, format: res.data[0].mimeType } as Ifile;
      })
      this.SelfEmployed.loanAccountNumber = this.RequestDataWithLan.LoanAccountNumber;
      //this.SelfEmployed.loanAccountNumber=this.RequestData.LoanAccountNumber;
    })
  }
  upload(event: IfileUpload): Ifile {
    return { extension: event.extension, file: event.imageData, filename: event.name, format: event.imageMIMEType } as Ifile;
  }
  Submit() {

    if (this.SelfEmployed.workType_OI !== 'Y') {
      this.SelfEmployed.bA_OI_Total_Institution = "";
      this.SelfEmployed.bA_OI_Name_Top1 = "";
      this.SelfEmployed.bA_OI_Contact_Top1 = "";
      this.SelfEmployed.bA_OI_Address_Top1 = "";
      this.SelfEmployed.bA_OI_Name_Top2 = "";
      this.SelfEmployed.bA_OI_Contact_Top2 = "";
      this.SelfEmployed.bA_OI_Address_Top2 = "";
      this.SelfEmployed.bA_OI_MonthlyVol = "";
      this.SelfEmployed.bA_OI_RevPerUnit = 0;
      this.SelfEmployed.bA_OI_ExpPerUnit = 0;
      this.SelfEmployed.bA_OI_JobsInHand = 0;
      this.SelfEmployed.bA_OI_NumOfMonths = 0;
      this.SelfEmployed.bA_OI_Receivable = 0;
      this.SelfEmployed.bA_OI_Payable = 0;
      this.SelfEmployed.bA_OI_MembershipLicUpload = "";
    }

    if (this.SelfEmployed.workType_RC !== 'Y') {
      this.SelfEmployed.bA_RC_MonthlyVol = "";
      this.SelfEmployed.bA_RC_RevPerUnit = 0;
      this.SelfEmployed.bA_RC_ExpPerUnit = 0;
      this.SelfEmployed.bA_RC_NumOfMonths = 0;
      this.SelfEmployed.bA_RC_JobsInHand = 0;
      this.SelfEmployed.bA_RC_Receivable = 0;
      this.SelfEmployed.bA_RC_Payable = 0;
    }

    if (this.SelfEmployed.workType_Manufacturer !== 'Y') {
      this.SelfEmployed.bA_M_JobsInHand = 0;
      this.SelfEmployed.bA_M_JobsInMonth_Cap = 0;
      this.SelfEmployed.bA_M_ItemsInStock = 0;
      this.SelfEmployed.bA_M_MonthlyPurchase = 0;
      this.SelfEmployed.bA_M_ItemsMade = "";
      this.SelfEmployed.bA_M_RevenuePerUnit = 0;
      this.SelfEmployed.bA_M_CostPerUnit = 0;
      this.SelfEmployed.bA_M_ProdCycle = 0;
      this.SelfEmployed.bA_M_Receivable = 0;
      this.SelfEmployed.bA_M_Payable = 0;
    }

    if (!this.ValidateTailoringHandloom()) {
      return;
    }

    let electricyAmount: number = this.SelfEmployed.exp_Electricity_Act === "" ? 0 : parseFloat(this.SelfEmployed.exp_Electricity_Act);

    if (electricyAmount > 500) {
      this.SelfEmployed.exp_Electricity_Calc = electricyAmount.toString();
    } else {
      this.SelfEmployed.exp_Electricity_Calc = "500";
    }

    if (this.SelfEmployed.applicationNo === "") {
      this.SelfEmployed.applicationNo = this.RequestData.ApplicationNo;
    }

    this.http.httpPostWithouImageData<any>(this.SelfEmployed.toJSON(), "LAP_IA_TailoringHandloom", this.SelfEmployed.toJSON(true)).subscribe((res: any) => {

      if (res.errorcode === "01" || res.errorcode === "00") {
        this.notify.showSuccess(res.errorDescription, "Success");
        this.errorMsg = "";
        this.errorTag = false;
        this.isEdit = false;
      }
      else {
        this.notify.showError(res.errorDescription, "Failed");
      }
    });
  }

  ValidateTailoringHandloom() {

    let noOfMonthsInAYear = 0;
    const pattern = /^[6-9][0-9]{0,10}$/;
    var value;

    if (this.SelfEmployed.core_Tailoring_YN !== "Y" && this.SelfEmployed.handloom_YN !== "Y") {
      this.errorTag = false;
      this.errorMsg = "Please select any one type of product";
      this.notify.showWarning(this.errorMsg, "Tailoring & Handloom")
      return false;
    }

    /**sharing ratio */
    if (this.SelfEmployed.numofPartners != 0) {
      if (this.SelfEmployed.profSharingRatio === "0" || this.SelfEmployed.profSharingRatio.length == 0) {
        this.errorTag = true;
        this.errorMsg = "Please enter Profit sharing Ratio for customer in %";
        this.notify.showWarning(this.errorMsg);
        return false;
      }
    }

    if ((this.SelfEmployed.sewing_YN !== "Y" && this.SelfEmployed.embroidery_YN !== "Y"
      && this.SelfEmployed.handloom_YN !== "Y" && this.SelfEmployed.powerloom_YN !== "Y")) {
      this.errorTag = false;
      this.errorMsg = "Please select any one type of machine";
      this.notify.showWarning(this.errorMsg, "Tailoring & Handloom")
      return false;
    }

    let numbOfMachine = this.SelfEmployed.numOfMachines.trim() === "" ? 0 : parseInt(this.SelfEmployed.numOfMachines);
    if (parseInt(this.SelfEmployed.numOfMachines) < 1 || this.SelfEmployed.numOfMachines.length == 0) {
      this.errorTag = true;
      this.errorMsg = "Please specify the number of machines";
      this.notify.showWarning(this.errorMsg, "Tailoring & Handloom")
      return false;
    }

    /*Rent */
    if (this.SelfEmployed.ownership_Of_Premise === 'Rented') {
      if (this.SelfEmployed.exp_Shoprent_Act.trim() === "" || parseInt(this.SelfEmployed.exp_Shoprent_Act) === 0) {
        this.errorTag = true;
        this.errorMsg = "Please specify the rent";
        this.notify.showWarning(this.errorMsg, "Tailoring & Handloom")
        return false;
      }
    }


    if (this.SelfEmployed.workType_OI === "Y") {
      let bA_OI_Total_Institution = this.SelfEmployed.bA_OI_Total_Institution === "" ? 0 : parseInt(this.SelfEmployed.bA_OI_Total_Institution);

      if (bA_OI_Total_Institution > 0) {
        if (this.SelfEmployed.bA_OI_Name_Top1 === "") {
          this.errorTag = true;
          this.errorMsg = "Please specify the top-1 entity name";
          this.notify.showWarning(this.errorMsg, "Tailoring & Handloom")
          return false
        }

        if (this.SelfEmployed.bA_OI_Contact_Top1 === "") {
          this.errorTag = true;
          this.errorMsg = "Please specify the top-1 entity contact";
          this.notify.showWarning(this.errorMsg, "Tailoring & Handloom")
          return false
        }

        if (this.SelfEmployed.bA_OI_Address_Top1 === "") {
          this.errorTag = true;
          this.errorMsg = "Please specify the top-1 entity address";
          this.notify.showWarning(this.errorMsg, "Tailoring & Handloom")
          return false
        }

        if (bA_OI_Total_Institution > 1) {
          if (this.SelfEmployed.bA_OI_Name_Top2 === "") {
            this.errorTag = true;
            this.errorMsg = "Please specify the top-2 entity name";
            this.notify.showWarning(this.errorMsg, "Tailoring & Handloom")
            return false
          }

          if (this.SelfEmployed.bA_OI_Contact_Top2 === "") {
            this.errorTag = true;
            this.errorMsg = "Please specify the top-2 entity contact details";
            this.notify.showWarning(this.errorMsg, "Tailoring & Handloom")
            return false
          }

          if (this.SelfEmployed.bA_OI_Address_Top2 === "") {
            this.errorTag = true;
            this.errorMsg = "Please specify the top-2 entity address";
            this.notify.showWarning(this.errorMsg, "Tailoring & Handloom")
            return false
          }
        }
      }

      if (this.SelfEmployed.bA_OI_Contact_Top1 !== "") {
        // value = this.SelfEmployed.bA_OI_Contact_Top1!;
        // if (!pattern.test(value)) {
        if (!common.isValid_MobileNo(this.SelfEmployed.bA_OI_Contact_Top1)) {
          //(this.ControlInput = value = '');
          this.notify.showWarning("Please enter valid contact number for the top1 Entity");
          return false;
        }
      }


      if (this.SelfEmployed.bA_OI_Contact_Top2 !== "") {
        // value = this.SelfEmployed.bA_OI_Contact_Top2;
        // if (!pattern.test(value)) {
        if (!common.isValid_MobileNo(this.SelfEmployed.bA_OI_Contact_Top2)) {
          //(this.ControlInput = value = '');
          this.notify.showWarning("Please enter valid contact number for the top2 Entity");
          return false;
        }
      }


      noOfMonthsInAYear = this.SelfEmployed.bA_OI_NumOfMonths;
      if (noOfMonthsInAYear > 12) {
        this.errorTag = true;
        this.errorMsg = "As a Job worker for other institutions - Total number of months working in a year should not be greater than 12";
        this.notify.showWarning(this.errorMsg, "Tailoring & Handloom")
        return false
      }
    }

    if (this.SelfEmployed.workType_RC === "Y") {
      noOfMonthsInAYear = this.SelfEmployed.bA_RC_NumOfMonths;
      if (noOfMonthsInAYear > 12) {
        this.errorTag = true;
        this.errorMsg = "As a job worker for Retail customers - Total number of months working in a year should not be greater than 12";
        this.notify.showWarning(this.errorMsg, "Tailoring & Handloom")
        return false
      }
    }


    // var electricityRate = parseInt(this.SelfEmployed.exp_Electricity_Act);
    // if (electricityRate < 500) {
    //   this.errorTag = true;
    //   this.errorMsg = "Minimum electricity charge should be 500";
    //   this.notify.showWarning(this.errorMsg,"Tailoring & Handloom")
    //   return false;
    // }



    return true;
  }

  edit() {
    this.isEdit = !this.isEdit;
  }
  typeOfProductChange(event: any, child: string) {
    switch (child.toUpperCase()) {
      case "TAILORING": {
        event.currentTarget.checked ? this.SelfEmployed.core_Tailoring_YN = 'Y' : this.SelfEmployed.core_Tailoring_YN = 'N';
        //this.SelfEmployed.core_Handloom_YN = 'N'
        //this.SelfEmployed.core_Tailoring_YN = child.selected == true ? 'Y' : 'N';      
        break;
      }
      case "HANDLOOMS":
        {
          event.currentTarget.checked ? this.SelfEmployed.core_Handloom_YN = 'Y' : this.SelfEmployed.core_Handloom_YN = 'N';
          // this.SelfEmployed.core_Handloom_YN = 'Y';
          // this.SelfEmployed.core_Tailoring_YN = 'N';
          //this.SelfEmployed.core_Handloom_YN = child.selected == true ? 'Y' : 'N';
          break;
        }
    }
  }
  cancel(event: any) {
    this.SelfEmployed = new TailoringShop(event);
    this.isEdit = !this.edit;
  }
  OnChangeMobile(event: any) {
    if (!common.isValid_MobileNo(event)) {
      this.notify.showWarning("Please enter valid mobile number")
    }
  }
  BusinessPremises: IDropdown[] = [
    new Dropdown({ displayName: "House" }),
    new Dropdown({ displayName: "Shop" }),
    new Dropdown({ displayName: "Other" })
  ]
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TailoringShopComponent } from './tailoring-shop.component';

describe('TailoringShopComponent', () => {
  let component: TailoringShopComponent;
  let fixture: ComponentFixture<TailoringShopComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TailoringShopComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TailoringShopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, Input, OnInit } from "@angular/core";
import { FormControl, FormGroup } from "@angular/forms";
import { InfoServices } from "src/app/Injectable/info.services";
import { NotificationService } from "src/app/notification.service";
import { Dropdown, IDropdown } from "src/app/shared/models/common/control.model";
import { IresponseModel } from "src/app/shared/models/common/response.model";
import { SanctionDashboardModel } from "src/app/shared/models/sanction/dashboard";
import { ApplicantDetail, SanctionResponse } from "src/app/shared/models/sanction/lap-sanctionapplicationdetails";
import { IPhysicalDiscussion, PhysicalDiscussion } from "src/app/shared/models/sanction/physical-discussion/physicaldiscussion";
import { SanctionRequestData } from "src/app/shared/models/sanction/sanction.model";
import { ConfigService } from "src/app/shared/services/common/http.services";
import { SanctionService } from "src/app/shared/services/sanction/sanction.service";

@Component({
    selector: "ltfs-personaldiscussion",
    templateUrl: './personaldiscussion.component.html',
    styleUrls: ['./personaldiscussion.component.css'],
    providers: [ConfigService]
})
export class PersonalDiscussionComponent implements OnInit {
    isEdit: boolean = false;
    @Input() requestData!: any;
    @Input() URL: any = 'LAP_HA_PhysicalDiscussion';
    personal: IPhysicalDiscussion = new PhysicalDiscussion();
    private _logDate: string = "";
    public get logDate(): string {
        return this._logDate;
    }
    public set logDate(value: string) {
        this._logDate = value;
    }
    desgination: IDropdown[] = [];
    readOnly: any;
    MeetWithWhomsFinancial: IDropdown[] = [];
    constructor(private http: ConfigService, private storage: InfoServices, private sanctionService: SanctionService, private notification: NotificationService) {

    }

    ngOnInit(): void {
        this.readOnly = this.sanctionService.LanInfo.readOnly;
        this.MeetWithWhomsFinancial = this.sanctionService.GetMeetWithWhomFinancial();
        this.GetPersonalDiscusssion();

        this.desgination = [
            { displayName: "ACM", value: "ACM", selected: false },
            { displayName: "ZCM", value: "ZCM", selected: false },
            { displayName: "NCM", value: "NCM", selected: false },
            { displayName: "BCM", value: "BCM", selected: false }
        ];
    }
    GetPersonalDiscusssion() {
        this.http.httpPost<IresponseModel<IPhysicalDiscussion[]>>(this.requestData, `Get${this.URL}`).subscribe((res: IresponseModel<IPhysicalDiscussion[]>) => {
            this.personal = new PhysicalDiscussion(res.data[0]);
            this.logDate = this.personal.createdOn;
        })
    }

    Submit() {
        if (this.personal.sales_FLO_PSID.length > 8 || this.personal.sales_FLO_PSID.length < 5) {
            this.notification.showWarning("Please enter valid PS ID");
        } else if (this.personal.creditOfcr_PSID.length > 8 || this.personal.creditOfcr_PSID.length < 5) {
            this.notification.showWarning("Please enter valid PS ID");
        } else {
            this.http.httpPost<any>(this.personal.toJSON(), this.URL).subscribe((res: any) => {
                this.isEdit = !this.isEdit;
                this.notification.showSuccess("Data saved successfully");
            });
        }
    }


    cancel(event: any) {
        this.isEdit = !this.isEdit;
        this.personal = new PhysicalDiscussion(event);
    }
    Designation: any = false;
    OnchangeDesignation() {
        if (this.personal.creditOfcr_Designation == "ACM" || this.personal.creditOfcr_Designation == "ZCM"
            || this.personal.creditOfcr_Designation == "NCM" || this.personal.creditOfcr_Designation == "BCM") {
            this.Designation = false;
        }
        else {
            this.Designation = true;
        }
    }

}
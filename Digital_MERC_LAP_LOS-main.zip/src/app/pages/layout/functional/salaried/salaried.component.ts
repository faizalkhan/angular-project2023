import { Component, Input, OnInit } from "@angular/core";
import { IresponseModel } from "src/app/shared/models/common/response.model";
import { SanctionRequestData } from "src/app/shared/models/sanction/sanction.model";
import { ISalaried, IUploadDoc, SalariedModel } from "src/app/shared/models/sanction/SalariedModel";
import { ConfigService } from "src/app/shared/services/common/http.services";
import { masterModuleDropdown } from "src/app/shared/models/sanction/masterDropdown";
import { IDropdown } from "src/app/shared/models/common/control.model";
import { NotificationService } from "src/app/notification.service";
import { SanctionService } from "src/app/shared/services/sanction/sanction.service";
import { common } from "src/app/shared/models/common";
import { FileUpload, IfileUpload, UploadViewDownloadService } from "../../button/upload-view-download/upload-view-download.service";
@Component({
    selector: "app-salaried",
    templateUrl: './salaried.component.html',
    styleUrls: ['./salaried.component.css'],
    providers: [ConfigService]
})
export class SalariedComponent implements OnInit {
    isEdit: boolean = false;
    @Input() requestData: SanctionRequestData = new SanctionRequestData();
    SalariedForm: SalariedModel = new SalariedModel();
    HighestEducation: IDropdown[] = masterModuleDropdown.HighestEducation;
    Conditional: IDropdown[] = masterModuleDropdown.Conditional;
    SalaryMode: IDropdown[] = masterModuleDropdown.SalaryMode;
    UploadModel: any = { ref_No: "", description: "" };
    MonthList: IDropdown[] = masterModuleDropdown.MonthList;
    readonly: any;
    upload_img_description: string = "";
    DocumentType: IDropdown[] = [];
    isHideAddMore: boolean = true;
    requiredFields: any[] = [];
    constructor(private http: ConfigService, private notify: NotificationService,
        private sanctionService: SanctionService, private download: UploadViewDownloadService,) {

    }

    ngOnInit(): void {
        this.isEdit = false;
        this.readonly = this.sanctionService.LanInfo.readOnly;

        this.DocumentType = [
            { displayName: 'Select', selected: true, value: '0' },
            { displayName: 'Salary Slips', selected: false, value: 'Salary Slips' },
            { displayName: 'Offer letter', selected: false, value: 'Offer letter' },
            { displayName: 'Appraisal letter', selected: false, value: 'Appraisal letter' },
            { displayName: 'Others', selected: false, value: 'Others' }]

        this.download.uploadLoad = new FileUpload({
            flO_Id: "",
            loanAccountNumber: this.requestData.LoanAccountNumber,
            moduleName: "SALARIED",
            applicationNo: this.requestData.ApplicationNo,
            leadID: this.requestData.LoanAccountNumber
        } as IfileUpload);

        this.GetSalariedInfo();
    }

    GetSalariedInfo() {
        let data = {
            ApplicationNo: this.requestData.ApplicationNo,
            CreatedON: this.requestData.CreatedON,
            FLO_PsId: this.requestData.FLO_PsId,
            LoanAccountNumber: this.requestData.LoanAccountNumber
        };


        this.http.httpPost<IresponseModel<ISalaried[]>>(data, 'GetLAP_IA_Salaried').subscribe((res: IresponseModel<ISalaried[]>) => {
            this.SalariedForm = new SalariedModel();
            if (res.errorcode == "00" || res.errorcode == "01") {
                this.SalariedForm = new SalariedModel(res.data[0]);
                this.SalariedForm.loanAccountNumber = this.requestData.LoanAccountNumber
            }
        });
    }
    OnChangeMobile(event: any) {
        if (!common.isValid_MobileNo(event)) {
            this.notify.showWarning("Please enter valid mobile number")
        }
    }
    Submit() {
        if (this.Validation()) {
            this.http.httpPostWithouImageData<any>(this.SalariedForm.toJson(), 'LAP_IA_Salaried', this.SalariedForm.toJsonWithoutImage()).subscribe((res: any) => {
                if (res.errorcode == "00" || res.errorcode == "01") {
                    this.notify.showSuccess(res.errorDescription);
                    this.ngOnInit();
                }
                else {
                    this.notify.showError(res.errorDescription);
                }
            });
        }
    }
    SourceChange(event: any) {
        this.SalariedForm.other_Source = event;
        this.SalariedForm.source_Details = "";
    }
    edit() {
        this.isEdit = !this.isEdit;
    }

    Validation(): boolean {
        let val: boolean = false;
        if (!common.IsRequired(this.SalariedForm.serviceDuration_Years)) {
            this.notify.showWarning("Required No of year service years & month ")
        }
        else if ((!this.SalariedForm.workExp_Total_Years || this.SalariedForm.workExp_Total_Years == "") && (!this.SalariedForm.workExp_Total_Months || this.SalariedForm.workExp_Total_Months == "")) {
            this.notify.showWarning("Required Total work experience ")
        }
        else if (this.SalariedForm.serviceYear > this.SalariedForm.workedYear) {
            this.notify.showWarning("No. of years of Service (Current Job) is cannot be greater than Total work experience")
        }
        else if (!this.SalariedForm.isPreviousExp && (!this.SalariedForm.prev_Emplyr_Name || this.SalariedForm.prev_Emplyr_Name == "")) {
            this.notify.showWarning("Required previous employer name ")
        }
        else if (!this.SalariedForm.isPreviousExp && (!this.SalariedForm.prev_Emplyr_Address || this.SalariedForm.prev_Emplyr_Address == "")) {
            this.notify.showWarning("Required previous employer address ")
        }
        else if (!this.SalariedForm.isPreviousExp && (!this.SalariedForm.prev_Emplyr_Contact || this.SalariedForm.prev_Emplyr_Contact == "")) {
            this.notify.showWarning("Required previous employer contact ")
        }
        else if (this.SalariedForm.emplyr_PinCode.length !== 6) {
            this.notify.showWarning("Please enter valid pincode");
        } else if (!common.isValid_MobileNo(this.SalariedForm.emplyr_Mob1) || (this.SalariedForm.emplyr_Mob1.length !== 10)) {
            this.notify.showWarning("Please enter valid primary contact number");
        } else if (!common.isValid_MobileNo(this.SalariedForm.emplyr_Mob2) || (this.SalariedForm.emplyr_Mob2.length !== 10)) {
            this.notify.showWarning("Please enter valid alternative contact number");
        }
        else {
            val = true;
        }
        return val;
    }

    uploadChange(event: IfileUpload, iCount: number) {
        if (iCount === 1) {
            this.SalariedForm.upload_Doc_1 = event.imageData;
            this.SalariedForm.upload_Doc_1_DocType = this.upload_img_description;
            this.SalariedForm.upload_Doc1_MimeType = event.imageMIMEType;
            this.SalariedForm.upload_Doc1ImgExtension = event.extension;
        }

        if (iCount === 2) {
            this.SalariedForm.upload_Doc_2 = event.imageData;
            this.SalariedForm.upload_Doc_2_DocType = this.upload_img_description;
            this.SalariedForm.upload_Doc2_MimeType = event.imageMIMEType;
            this.SalariedForm.upload_Doc2ImgExtension = event.extension;
        }

        if (iCount === 3) {
            this.SalariedForm.upload_Doc_3 = event.imageData;
            this.SalariedForm.upload_Doc_3_DocType = this.upload_img_description;
            this.SalariedForm.upload_Doc3_MimeType = event.imageMIMEType;
            this.SalariedForm.upload_Doc3ImgExtension = event.extension;
        }

        if (iCount === 4) {
            this.SalariedForm.upload_Doc_4 = event.imageData;
            this.SalariedForm.upload_Doc_4_DocType = this.upload_img_description;
            this.SalariedForm.upload_Doc4_MimeType = event.imageMIMEType;
            this.SalariedForm.upload_Doc4ImgExtension = event.extension;
        }

        if (iCount === 5) {
            this.SalariedForm.upload_Doc_5 = event.imageData;
            this.SalariedForm.upload_Doc_5_DocType = this.upload_img_description;
            this.SalariedForm.upload_Doc5_MimeType = event.imageMIMEType;
            this.SalariedForm.upload_Doc5ImgExtension = event.extension;
        }

    }
    SetDocumentValue(item: IUploadDoc, index: number) {
        let description = item.description ?? "";
        let other = item.other ?? "";
        if (index === 0) {
            this.SalariedForm.upload_Doc_1_DocType = (`${description} ${other}`).trim();
            this.SalariedForm.upload_Doc_1 = item.ref_No;
        }

        if (index === 1) {
            this.SalariedForm.upload_Doc_2_DocType = (`${description} ${other}`).trim();
            this.SalariedForm.upload_Doc_2 = item.ref_No;
        }

        if (index === 2) {
            this.SalariedForm.upload_Doc_3_DocType = (`${description} ${other}`).trim();
            this.SalariedForm.upload_Doc_3 = item.ref_No;
        }

        if (index === 3) {
            this.SalariedForm.upload_Doc_4_DocType = (`${description} ${other}`).trim();
            this.SalariedForm.upload_Doc_4 = item.ref_No;
        }

        if (index === 4) {
            this.SalariedForm.upload_Doc_5_DocType = (`${description} ${other}`).trim();
            this.SalariedForm.upload_Doc_5 = item.ref_No;
        }
        this.download.uploadLoad.docTypeDescription = (`${description} ${other}`).trim();
    }
    documentTypeChange(event: any, index: number) {

        let iCount = 0;
        this.SalariedForm.upload_Docs.forEach((item, index) => {

            if (item.description === event.target.value) {
                iCount = iCount + 1;
                let selectedDocumentType = this.DocumentType.find(x => x.value === event.target.value);
                if (selectedDocumentType) {
                    this.SalariedForm.upload_Docs[index].description = selectedDocumentType.displayName;
                }
            }
            if (iCount > 1) {

                this.SalariedForm.upload_Docs[index].description = '';
                event.target.value = '';
                this.notify.showWarning("The same document type has been selected. Please select someother document type");
                return;
            }
            //return true;
        })
    }

    RemoveDocument(event: any, index: number) {
        if (index === 0) {
            this.SalariedForm.upload_Doc_1 = "";
            this.SalariedForm.upload_Doc_1_DocType = "";
            this.SalariedForm.upload_Doc1_MimeType = "";
            this.SalariedForm.upload_Doc1ImgExtension = "";
        }

        if (index === 1) {
            this.SalariedForm.upload_Doc_2 = "";
            this.SalariedForm.upload_Doc_2_DocType = "";
            this.SalariedForm.upload_Doc2_MimeType = "";
            this.SalariedForm.upload_Doc2ImgExtension = "";
        }

        if (index === 2) {
            this.SalariedForm.upload_Doc_3 = "";
            this.SalariedForm.upload_Doc_3_DocType = "";
            this.SalariedForm.upload_Doc3_MimeType = "";
            this.SalariedForm.upload_Doc3ImgExtension = "";
        }

        if (index === 3) {
            this.SalariedForm.upload_Doc_4 = "";
            this.SalariedForm.upload_Doc_4_DocType = "";
            this.SalariedForm.upload_Doc4_MimeType = "";
            this.SalariedForm.upload_Doc4ImgExtension = "";
        }

        if (index === 4) {
            this.SalariedForm.upload_Doc_5 = "";
            this.SalariedForm.upload_Doc_5_DocType = "";
            this.SalariedForm.upload_Doc5_MimeType = "";
            this.SalariedForm.upload_Doc5ImgExtension = "";
        }


        if (this.SalariedForm.upload_Docs.length !== -1) {
            this.SalariedForm.upload_Docs.splice(index, 1);
        }
    }

    addmore() {
        this.UploadModel = { ref_No: "", description: "", other: "" };
        this.SalariedForm.upload_Docs.push(this.UploadModel);
    }
}
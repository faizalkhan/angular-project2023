import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { NotificationService } from "src/app/notification.service";
import { HouseholdAssessmentService } from "src/app/pages/sanction/household-assessment/household-assessment.service";
import { IresponseModel } from "src/app/shared/models/common/response.model";
import { AmenitiesAndLifestyle, IAmenitiesAndLifeStyle, vehicleDetail } from "src/app/shared/models/sanction/amenities-life-style/amenitieslifestyle";
import { ConfigService } from "src/app/shared/services/common/http.services";
import { SanctionService } from "src/app/shared/services/sanction/sanction.service";

@Component({
    selector: 'lfts-amenitieslifestyle',
    templateUrl: './amenitieslifestyle.component.html',
    styleUrls: ['./amenitieslifestyle.component.css'],
    providers: [ConfigService, HouseholdAssessmentService]
})
export class AmenitiesLifestyleComponent implements OnInit {
    @Input() AmenitiesAndLifestyle: IAmenitiesAndLifeStyle = new AmenitiesAndLifestyle();
    @Output() OnAmenitiesLifestyleChange = new EventEmitter<IAmenitiesAndLifeStyle>();
    addMore: vehicleDetail = new vehicleDetail();
    isEdit: boolean = false;
    readonly: any;
    isEditable: boolean = false;
    constructor(private http: ConfigService, private sanctionService: SanctionService, private notification: NotificationService, private HAService: HouseholdAssessmentService) { }
    ngOnInit(): void {
        this.readonly = this.sanctionService.LanInfo.readOnly;
    }

    onChange() {

        if (this.AmenitiesAndLifestyle.shop === "No") {
            this.isEditable = true;
            this.AmenitiesAndLifestyle.shopType = "";
        } else {
            this.isEditable = false;
            this.AmenitiesAndLifestyle.shopType = "";
        }
    }
    Submit() {
        if (this.validation()) {
            this.http.httpPost(this.AmenitiesAndLifestyle.toJSON(), 'LAP_HA_AmenitiesAndLifestyle').subscribe((res: any) => {
                this.isEdit = !this.isEdit;
                this.notification.showSuccess("Data saved successfully");
                this.OnAmenitiesLifestyleChange.emit(this.AmenitiesAndLifestyle)
            });
        }
    }
    validation() {
        let valid = true;
        if (this.AmenitiesAndLifestyle.shop === "Yes" && this.AmenitiesAndLifestyle.shopType === "") {
            this.notification.showWarning("Please select shop type");
            valid = false;
        }
        else if (this.AmenitiesAndLifestyle.vehicle.length > 0 && this.AmenitiesAndLifestyle.vehicle.filter(x => (!x.numberOfVechicle || x.numberOfVechicle == '')).length > 0) {
            this.notification.showWarning("Blank not allowed in number for vehicles!");
            valid = false;
        }

        return valid;
    }
    edit() {
        this.isEdit = !this.isEdit;
    }

    vehicleChange(event: any) {
        this.addMore.vehicleName = event.currentTarget.value;
        this.addMore.loanAccountNumber = this.AmenitiesAndLifestyle.loanAccountNumber;
    }

    add() {
        if (this.addMore.vehicleName == "")
            return;

        this.AmenitiesAndLifestyle.vehicle.push(this.addMore);

        this.addMore = new vehicleDetail();
    }
    remove(i: number) {

        this.AmenitiesAndLifestyle.vehicle.splice(i, 1);
    }
    Cancel(event: IAmenitiesAndLifeStyle) {
        this.AmenitiesAndLifestyle = new AmenitiesAndLifestyle(event);
    }
}
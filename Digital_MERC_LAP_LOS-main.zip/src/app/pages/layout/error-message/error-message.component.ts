import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-message',
  templateUrl: './error-message.component.html',
  styleUrls: ['./error-message.component.css']
})
export class ErrorMessageComponent implements OnInit {

 @Input() valid: IValidation = {} as IValidation;
  constructor() { }

  ngOnInit(): void {
  }



}

export interface IValidation {
  errorMessage?: string;
}

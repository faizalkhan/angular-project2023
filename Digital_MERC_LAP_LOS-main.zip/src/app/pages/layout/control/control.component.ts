import { DatePipe } from "@angular/common";
import { Component, Input, Output, OnInit, EventEmitter, ViewChild, ElementRef, AfterViewInit } from "@angular/core";
import { NotificationService } from "src/app/notification.service";
import { Controls, IDropdown } from "src/app/shared/models/common/control.model";
@Component(
    {
        selector: "inp-controls",
        templateUrl: './control.component.html',
        styleUrls: ['./control.component.css'],
        providers: [DatePipe],
     
    }
)
export class ControlComponent implements OnInit, AfterViewInit {
    @Input() isEdit: boolean = false;
    @Input() ControlInput: any;
    @Input() PropertyName: any;
    @Input() CustomCss: any;
    @Input() ControlType: Controls = 1;
    @Input() ListOf: IDropdown[] = [];
    @Input() disabled: boolean = false;
    @Input() minlength: number = 0;
    @Input() maxlength: number = 100;
    private _name: string = (new Date).valueOf().toString();
    public get name(): string {
        return this._name;
    }
    public set name(value: string) {
        this._name = value;
    }
    @ViewChild('control')
    CointrolId!: ElementRef;
    currentDate: Date = new Date();
    maxdate: Date = new Date();
    mindate: Date = new Date();
    public get labelControlInput(): any {
        if (this.ControlInput) {
            if (this.ControlType == 2) {
                let data = this.ListOf.find(x => (x.value && x.value?.toString().toLowerCase() == this.ControlInput?.toString().toLowerCase()) || x.selected);
                console.debug(data);
                return data ? data?.displayName : this.ControlInput;
            }
            else if (this.ControlType == 3)
                return this.datepipe.transform(this.ControlInput, "dd-MM-yyyy");
            else if (this.ControlType == 5) {
                return (typeof (this.ControlInput) != "boolean" && this.ControlInput.toLowerCase().startsWith('y')) || (typeof (this.ControlInput) == "boolean" && this.ControlInput == true);
            }
            else
                return this.ControlInput;
        }
        return "";
    }

    public get _ControlInput(): any {
        return this.ControlInput;
    }
    public set _ControlInput(value: any) {
        this.ControlInput = value;
    }


    @Output() ControlChange = new EventEmitter<any>();
    data: any;
    constructor(private datepipe: DatePipe, private notify: NotificationService) {
    }
    ngAfterViewInit(): void {
    }

    ngOnInit(): void {
        const current = new Date();
        this.mindate = new Date(new Date().setDate(current.getDate() - 30));
    }


    OnChange() {
        this.ControlChange.emit(this.ControlInput);
    }
    OnKeyUp() {
        this.ControlChange.emit(this.ControlInput);
    }
    radiChange(item: IDropdown, event: any) {
        let data = { 'item': item, 'event': event };
        this.ControlChange.emit(data);
    }

    ShowCheckBox(ControlType: any): boolean {
        return ControlType == 4;
    }

    toggleChange(event: any) {

        this.ControlInput = event.currentTarget.checked ? "Yes" : "No";

        this.ControlChange.emit(this.ControlInput);

    }
    keyPressNumbers(event: any) {
        var charCode = (event.which) ? event.which : event.keyCode;
        // Only Numbers 0-9
        if ((charCode < 48 || charCode > 57)) {
            event.preventDefault();
            return false;
        } else {
            return true;
        }
    }
    textAreaAdjust(element: any) {
        element.style.height = "1px";
        element.style.height = (25 + element.scrollHeight) + "px";
    }
}

export interface IAttributes {
    class: any;
    maxLength: any;
    minLength: any;
    type: any;
    format: any;
    disabled: any;
    name: any;
}
export class Attributes implements IAttributes {
    class: any;
    maxLength: any;
    minLength: any;
    type: any;
    format: any;
    disabled: any;
    constructor(params?: IAttributes) {
        if (params) {
            this.class = params.class;
            this.maxLength = params.maxLength;
            this.minLength = params.minLength;
            this.type = params.type;
            this.format = params.format;
            this.name = params.name;
        }
    }
    name: any;
}

import { TestBed } from '@angular/core/testing';

import { UploadViewDownloadService } from './upload-view-download.service';

describe('UploadViewDownloadService', () => {
  let service: UploadViewDownloadService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UploadViewDownloadService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

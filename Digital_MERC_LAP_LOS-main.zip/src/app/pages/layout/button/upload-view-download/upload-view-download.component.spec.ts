import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadViewDownloadComponent } from './upload-view-download.component';

describe('UploadViewDownloadComponent', () => {
  let component: UploadViewDownloadComponent;
  let fixture: ComponentFixture<UploadViewDownloadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UploadViewDownloadComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UploadViewDownloadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

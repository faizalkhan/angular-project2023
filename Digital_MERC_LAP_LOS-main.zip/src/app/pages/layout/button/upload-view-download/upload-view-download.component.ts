import { Component, ElementRef, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CreateOptions, PDFDocument } from 'pdf-lib';
import { Observable, ReplaySubject } from 'rxjs';
import { NotificationService } from 'src/app/notification.service';
import { IModalCommon, ModalCommon, ModalService } from 'src/app/shared/services/modal/modal.service';
import { Ifile, IfileUpload, ResponseUpload, UploadViewDownloadService } from './upload-view-download.service';

@Component({
  selector: 'app-upload-view-download',
  templateUrl: './upload-view-download.component.html',
  styleUrls: ['./upload-view-download.component.css']
})
export class UploadViewDownloadComponent implements OnInit {
  SupportedDocuments: any[] = ['pdf', 'png', 'jpeg', 'jpg'];

  @Input() ReferenceNo: any = "";
  @Input() DocType: any;
  @Input() IsEdit: boolean = true;
  @Output("Change") ChangeEvent = new EventEmitter<any>();
  @Input() CurrentFile: Ifile | undefined;
  @Input() IsLocal: boolean = false;
  @Input() ModuleName: string = "";
  @Input() applicationNo: string = "";
  @Input() BankDetailId: string = "";
  @Input() DocTypeDescriptions: string = "";
  @Input() viewOnly: boolean = false;
  @Input() hideUpload: boolean = false;
  @Input() ConvertPDF: boolean = false;
  @Input() IsAddMore: boolean = false;
  public get UploadData(): IfileUpload {
    if (this.ModuleName && this.ModuleName != "")
      this._uploadViewDownloadService.uploadLoad.moduleName = this.ModuleName;
    if (this.applicationNo && this.applicationNo != "")
      this._uploadViewDownloadService.uploadLoad.applicationNo = this.applicationNo;
    if (this.BankDetailId && this.BankDetailId != "")
      this._uploadViewDownloadService.uploadLoad.bankDetailID = this.BankDetailId;
    this.DocTypeDescriptions = this.DocTypeDescriptions;
    if (this.DocType && this.DocType != '') {
      this._uploadViewDownloadService.uploadLoad.docTypeDescription = this.DocType
    }
    return this._uploadViewDownloadService.uploadLoad;

  }

  constructor(private _uploadViewDownloadService: UploadViewDownloadService,
    private _notification: NotificationService, private notify: NotificationService, private modalService: ModalService) {


  }

  ngOnInit(): void {

  }
  private _ConfimationAddMore: boolean = false;
  public get ConfimationAddMore(): boolean {
    return this._ConfimationAddMore;
  }
  public set ConfimationAddMore(value: boolean) {
    this._ConfimationAddMore = value;
  }
  browse(fileInput: HTMLInputElement) {
    let sAction: Function = () => {
      this.ConfimationAddMore = false;
      fileInput.click();
    }
    let AdditionalButtonAction: Function = () => {
      this.ConfimationAddMore = true;
      fileInput.click();
    }
    if (this.isFileAvailabe() && this.IsAddMore) {
      let modal: IModalCommon = new ModalCommon({
        cActionShow: true,
        sActionShow: true,
        sActionText: 'Add New Document',
        sAction: sAction,
        AdditionalButtonShow: true,
        AdditionalButtonAction: AdditionalButtonAction,
        AdditionalButtonText: 'Overwrite Existing Document',
        title: 'upload document',
        message: '<h5>Do you want to add a new document or overwrite the already uploaded document?</h5>'
      } as IModalCommon);
      this.modalService.ShowModal(modal)
    }
    else {
      fileInput.click();
    }

  }

  upload(event: any): any {
    if (event.target.files && event.target.files[0]) {
      // Size Filter Bytes
      let file = event.target.files[0] as File;
      const max_size = 2097152;
      if (event.target.files[0].size > max_size) {
        this._notification.showWarning('Maximum size allowed is ' + max_size / 1048576 + 'Mb');
        return false;
      }
      else if (this.SupportedDocuments.find(x => x.toLowerCase() == file.name.split('.').pop()?.toLowerCase()) === undefined) {
        this._notification.showWarning('File format is not supported, Please upload pdf/jpeg/jpg/png');
        return false;
      }



      this.convertFile(file).subscribe(base64 => {
        this.UploadData.imageData = base64;
        this.UploadData.imageMIMEType = file.type;
        this.UploadData.name = file.name;
        this.UploadData.uuid = "LOS";
        this.UploadData.imageType = this.UploadData.docTypeDescription;
        this.UploadData.extension = file.name.split('.').pop();
        if (this.ConvertPDF && this.UploadData.extension != 'pdf') {
          file.arrayBuffer().then(res => {
            this._uploadViewDownloadService.ConvertIntoPDF(res, this.UploadData.extension).then((res) => {
              this.UploadData.imageData = res;
              this.UploadData.imageMIMEType = 'application/pdf';
              this.UploadData.extension = 'pdf';
              this.EmitEvent(file, this.ConfimationAddMore);
            }).catch((error) => {
              this.notify.showError(error);
              return;
            });
          })
        }
        else {
          this.EmitEvent(file, this.ConfimationAddMore);
        }
      });

    }
  }

  private EmitEvent(file: File, addMore: boolean = false) {
    let self = this;
    if (addMore) {
      this._uploadViewDownloadService.DownloadFromAPI(this.ReferenceNo).subscribe((res) => {
        this._uploadViewDownloadService.PDFMerge(res.data[0].fileStream, this.UploadData.imageData).then((res) => {
          self.UploadData.imageData = res;
          self.EmitEvent(file);
        })
      })
    }
    else if (this.IsLocal) {
      this.ChangeEvent.emit(this.UploadData);
    }
    else {
      this._uploadViewDownloadService.uploadAPI(this.UploadData).subscribe((res: ResponseUpload) => {
        if (res.errorcode == 0) {
          this.notify.showSuccess("Document uploaded successfully");
          this.ReferenceNo = res.uniqueID;
          this._uploadViewDownloadService.remove(this.ReferenceNo);
          this.ChangeEvent.emit(this.ReferenceNo);
        }
        else {
          if (file.name.split('.').pop()?.toLocaleLowerCase() === "pdf" || file.name.split('.').pop()?.toLocaleLowerCase() === "jpg") {
            this.notify.showError(res.errorDescription);
          }
          else {
            this.notify.showError("File format is not supported, Please upload pdf/jpg");
          }
        }
      });
    }
  }

  convertFile(file: File): Observable<string> {
    const result = new ReplaySubject<string>(1);
    const reader = new FileReader();
    reader.readAsBinaryString(file);
    reader.onload = (event: any) => result.next(btoa(event.target.result.toString()));
    return result;
  }
  view(event: any) {
    if (this.ReferenceNo && this.ReferenceNo != "") {
      this._uploadViewDownloadService.showModal(this.ReferenceNo);
    }
    else if (this.CurrentFile && this.CurrentFile?.file) {
      this._uploadViewDownloadService.ShowFile(this.CurrentFile);
    }
    else {
      this.notify.showWarning(`There no document / image`);
    }
  }
  download(event: any) {
    if (this.ReferenceNo && this.ReferenceNo != "") {
      this._uploadViewDownloadService.Download(this.ReferenceNo);
    }
    else if (this.CurrentFile && this.CurrentFile?.file) {
      let fileName = this.CurrentFile.filename != "" ? `${this.CurrentFile.filename}.${this.CurrentFile.extension}` : `${new Date().valueOf()}.${this.CurrentFile.extension}`;
      this._uploadViewDownloadService.downloadFile(this.CurrentFile.file, this.CurrentFile.format, fileName);
    }

  }

  isFileAvailabe(): boolean {
    if (this.ReferenceNo && this.ReferenceNo != "") {
      return true;
    }
    else if (this.CurrentFile && this.CurrentFile?.file) {
      return true;
    }
    else {
      return false;
    }
  }
}

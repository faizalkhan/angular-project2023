import { Injectable } from '@angular/core';
import { PDFDocument, PDFImage, PDFPage } from 'pdf-lib';
import { Observable, ReplaySubject } from 'rxjs';
import { InfoServices } from 'src/app/Injectable/info.services';
import { NotificationService } from 'src/app/notification.service';
import { SanctionDashboardModel } from 'src/app/shared/models/sanction/dashboard';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { IModalCommon, ModalCommon, ModalService } from 'src/app/shared/services/modal/modal.service';
import { environment } from 'src/environments/environment.development';

@Injectable({
  providedIn: 'any'
})
export class UploadViewDownloadService {
  private _isLocal!: boolean;
  public get isLocal(): boolean {
    return this._isLocal;
  }
  public set isLocal(value: boolean) {
    this._isLocal = value;
  }
  uploadLoad: IfileUpload = new FileUpload();
  public get lanInfo(): SanctionDashboardModel {
    if (this.info.IsItem("LanInfo")) {
      return JSON.parse(this.info.getItem("LanInfo")) as SanctionDashboardModel;
    }
    return {} as SanctionDashboardModel;
  }
  files: Ifile[] = [];
  constructor(private http: ConfigService
    , private info: InfoServices,
    private notify: NotificationService,
    private modal: ModalService
  ) {

  }
  uploadAPI(item: IfileUpload): Observable<any> {

    return this.http.httpPostWithouImageData<ResponseUpload>(item.toJSON(), "LAP_SaveImageUPL", item.toJSONwithOut());

  }
  remove(referenceNo: any) {
    let findIndex = this.files.findIndex(x => x.referenceNo == referenceNo);
    if (findIndex != -1) {
      this.files.splice(findIndex, 1);
    }
  }
  fileToBase64(fileInput: any, item: Ifile) {
    var selectFile = fileInput.target.files;
    let files: FileList = fileInput.target.files;
    let file: File = files[0];
    if (fileInput.target.files && fileInput.target.files[0]) {
      // Size Filter Bytes
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const imgBase64Path = e.target.result as string;
        item.file = imgBase64Path.replace((imgBase64Path.substring(0, imgBase64Path.indexOf(",") + 1)), '');
        item.format = fileInput.target.files[0].type;
        item.extension = fileInput.target.files[0].name.split('.').pop().toLowerCase();
        item.filename = fileInput.target.files[0].name;
        console.debug(imgBase64Path);
        return true;
      };

      reader.readAsDataURL(fileInput.target.files[0]);


    }
    return true;
  }

  DownloadFromAPI(id: any): Observable<ResponseDownload> {
    let params = { "uuid": id };
    return this.http.httpPost<ResponseDownload>(params, environment.downloadEndPoints);
  }

  getFile(id: any): Ifile {
    return this.files.find(x => x.referenceNo == id) as Ifile;
  }
  showModal(id: any) {

    let data = this.files.find(x => x.referenceNo == id) as Ifile
    if (!data) {
      let params = { "uuid": id };

      this.http.httpPost<ResponseDownload>(params, environment.downloadEndPoints).subscribe((res: ResponseDownload) => {
        if (res.errorcode == 0 || res.errorcode == "") {
          console.debug(res.errorDescription);
          let _file = { extension: res.data[0].ext, file: res.data[0].fileStream, format: res.data[0].mimeType, referenceNo: id, filename: res.data[0].fileName } as Ifile;
          this.files.push(_file);
          this.ShowFile(_file);
        }
        else {
          console.debug(res.errorDescription);
          this.notify.showWarning(`There no document / image`);
        }
      });


    }
    else {
      this.ShowFile(data);
    }
  }
  Download(Id: any) {
    let file = this.getFile(Id);
    if (file) {
      this.downloadFile(file.file, file.format, file.filename);
    }
    else {
      this.DownloadFromAPI(Id).subscribe(res => {
        if (res.errorcode == 0 || res.errorcode == "") {
          console.debug(res.errorDescription);
          file = { extension: res.data[0].ext, file: res.data[0].fileStream, format: res.data[0].mimeType, referenceNo: res.data[0].parentUuid, filename: res.data[0].fileName } as Ifile
          this.files.push(file)
          this.downloadFile(file.file, file.format, file.filename);
        }
        else {
          console.debug(res.errorDescription);
        }
      });
    }


  }
  ShowFile(_file: Ifile) {
    if (_file && _file.extension) {
      switch (_file.extension?.toLowerCase()) {
        case "pdf":
          let objbuilder = '';
          objbuilder += ('<object width="100%" height="100%" data = "data:application/pdf;base64,');
          objbuilder += (_file.file);
          objbuilder += ('" type="application/pdf" class="internal">');
          objbuilder += ('<embed src="data:application/pdf;base64,');
          objbuilder += (_file.file);
          objbuilder += ('" type="application/pdf"  />');
          objbuilder += ('</object>');
          var win = window.open("#", "_blank");
          var title = _file.filename;
          win?.document.write('<html><title>' + title + '</title><body style="margin-top: 0px; margin - left: 0px; margin - right: 0px; margin - bottom: 0px; ">');
          win?.document.write(objbuilder);
          win?.document.write('</body></html>');
          break;
        default:
          let data = new ModalCommon({
            message: `<div class="w-100 text-center"> <img class="img-thumbnail" src="data:${_file.format};base64,${_file.file}" /> </div>`,
            file: _file,
            title: "Photo"
          } as IModalCommon);
          this.modal.ShowModal(data);
          break;
      }
    }
    else {
      this.notify.showWarning(`There no document / image`);
    }
  }

  downloadFile(data: any, ctype: string, filename: string) {

    let response = this.base64ToArrayBuffer(data);
    const a = document.createElement('a')
    const blob = new Blob([response], { type: ctype });
    const url = window.URL.createObjectURL(blob);
    a.href = url
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);

  }

  base64ToArrayBuffer(base64: any): ArrayBuffer {
    var binary_string = window.atob(base64);
    var len = binary_string.length;
    var bytes = new Uint8Array(len);
    for (var i = 0; i < len; i++) {
      bytes[i] = binary_string.charCodeAt(i);
    }
    return bytes.buffer;
  }


  convertFile(file: File): Observable<string> {
    const result = new ReplaySubject<string>(1);
    const reader = new FileReader();
    reader.readAsBinaryString(file);
    reader.onload = (event: any) => result.next(btoa(event.target.result.toString()));
    return result;
  }


  GetCommonForm(applicationNo?: any, loanNumber?: any, docType?: any): Observable<any> {
    let data = {
      "ApplicationNo": applicationNo ?? "",
      "DocType": docType ?? "",
      "FLCode": "",
      "LoanAccountNumber": loanNumber ?? ""
    };
    return this.http.httpCommondownload(data, 'LAP_GetDownloadDocs');
  }
  GetOtherCommonForm(loanAccountNo: any, docType: any): Observable<any> {
    let data = {
      "ApplicationNo": "",
      "DocType": docType,
      "FLCode": "",
      "LoanAccountNumber": loanAccountNo
    };
    return this.http.httpCommondownload(data, 'LAP_GetDownloadDocs');
  }
  arrayBufferToBase64(buffer: Iterable<number>) {
    var binary = '';
    var bytes = new Uint8Array(buffer);
    var len = bytes.byteLength;
    for (var i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }
  async ConvertIntoPDF(file: any, fileName: any) {

    const pdfDoc = await PDFDocument.create()
    let americanFlag: PDFImage;
    let americanFlagDims: any;
    let page: PDFPage;
    if (fileName != 'png') {
      americanFlag = await pdfDoc.embedJpg(file);
      americanFlagDims = americanFlag.scale(0.5);
      page = pdfDoc.addPage();
      page.drawImage(americanFlag, {
        x: page.getWidth() / 2 - americanFlagDims.width / 2,
        y: page.getHeight() / 2 - americanFlagDims.height + 250,
        width: americanFlagDims.width,
        height: americanFlagDims.height,
      })
      // Draw the JPG image in the center of the page

    }
    else {
      americanFlag = await pdfDoc.embedPng(file);
      americanFlagDims = americanFlag.scale(0.2)
      page = pdfDoc.addPage();
      page.drawImage(americanFlag, {
        x: page.getWidth() / 2 - americanFlagDims.width / 2,
        y: page.getHeight() / 2 - americanFlagDims.height / 2 + 250,
        width: americanFlagDims.width,
        height: americanFlagDims.height,
      })
    }
    // Serialize the PDFDocument to bytes (a Uint8Array)
    const pdfBytes = await pdfDoc.saveAsBase64()

    return pdfBytes
  }
  async PDFMerge(file1: any, file2: any) {
    let mergedPdf = await PDFDocument.create();

    let pdf1 = await PDFDocument.load(file1);

    let pdf2 = await PDFDocument.load(file2);

    // Create a new PDFDocument

    const copiedPagesA = await mergedPdf.copyPages(pdf1, pdf1.getPageIndices());

    copiedPagesA.forEach((page) => mergedPdf.addPage(page));

    const copiedPagesB = await mergedPdf.copyPages(pdf2, pdf2.getPageIndices());

    copiedPagesB.forEach((page) => mergedPdf.addPage(page));


    // pdf1.getPages().forEach((res) => {
    //   mergedPdf.addPage(res);
    // })

    // pdf2.getPages().forEach((res) => {
    //   mergedPdf.addPage(res);
    // })

    return await mergedPdf.saveAsBase64();

  }

}



export interface Ifile {
  filename: string;
  extension: string;
  format: string;
  file: string;
  referenceNo: string;
  url: string;
}
export interface fileDownload {
  ext: string;
  parentFolderName: string;
  fileName: string;
  mimeType: string;
  parentUuid: string;
  fileStream: string;
}
export interface ResponseUpload {
  data: fileDownload[];
  errorcode: number;
  errorDescription?: any;
  uniqueID: any;
}
export interface ResponseDownload {
  data: fileDownload[];
  errorcode: any;
  errorDescription?: any;
  status: number;
}
export interface IfileUpload {
  loanAccountNumber?: any;
  applicationNo?: any;
  flO_Id?: any;
  leadID?: any;
  imageType?: any;
  uuid?: any;
  type?: any;
  imageData?: any;
  docTypeDescription?: any;
  imageMIMEType?: any;
  extension?: any;
  moduleName?: any;
  gL_Latitude?: any;
  gL_Longitude?: any;
  name?: any;
  bankDetailID?: any;
  toJSON(): any;
  toJSONwithOut(): any;
}
export class FileUpload implements IfileUpload {
  loanAccountNumber: string = "";
  applicationNo: string = "";
  flO_Id: string = "";
  leadID: string = "";
  imageType: string = "";
  uuid: string = "";
  type: string = "";
  imageData: string = "";
  docTypeDescription: string = "";
  imageMIMEType: string = "";
  extension: string = "";
  moduleName: string = "";
  gL_Latitude: string = "";
  gL_Longitude: string = "";
  name: string = "";
  bankDetailID: string = "";

  constructor(params?: IfileUpload) {
    if (params) {
      this.loanAccountNumber = params.loanAccountNumber ?? "";
      this.applicationNo = params.applicationNo ?? "";
      this.flO_Id = params.flO_Id ?? "";
      this.leadID = params.leadID ?? "";
      this.imageType = params.imageType ?? params.loanAccountNumber;
      this.uuid = params.uuid ?? "";
      this.type = params.type ?? "";
      this.imageData = params.imageData ?? "";
      this.docTypeDescription = params.docTypeDescription ?? "";
      this.imageMIMEType = params.imageMIMEType ?? "";
      this.extension = params.extension ?? "";
      this.moduleName = params.moduleName ?? "";
      this.gL_Latitude = params.gL_Latitude ?? "";
      this.gL_Longitude = params.gL_Longitude ?? "";
      this.name = params.name ?? "";
      this.bankDetailID = params.bankDetailID ?? "";

    }
  }

  toJSON(): any {
    return {
      "LoanAccountNumber": this.loanAccountNumber,
      "ApplicationNo": this.applicationNo,
      "FLO_Id": this.flO_Id,
      "LeadID": this.leadID,
      "ImageType": this.imageType,
      "UUID": this.uuid ?? "",
      "Type": this.type,
      "ImageData": this.imageData.replace((this.imageData.substring(0, this.imageData.indexOf(",") + 1)), ''),
      "DocTypeDescription": this.docTypeDescription,
      "ImageMIMEType": this.imageMIMEType,
      "Extension": this.extension,
      "ModuleName": this.moduleName,
      "GL_Latitude": this.gL_Latitude,
      "GL_Longitude": this.gL_Longitude,
      "Name": this.name,
      "BankDetailID": this.bankDetailID,

    };
  }
  toJSONwithOut(): any {
    return {
      "LoanAccountNumber": this.loanAccountNumber,
      "ApplicationNo": this.applicationNo,
      "FLO_Id": this.flO_Id,
      "LeadID": this.leadID,
      "ImageType": this.imageType,
      "UUID": this.uuid ?? "",
      "Type": this.type,
      "DocTypeDescription": this.docTypeDescription,
      "ImageMIMEType": this.imageMIMEType,
      "Extension": this.extension,
      "ModuleName": this.moduleName,
      "GL_Latitude": this.gL_Latitude,
      "GL_Longitude": this.gL_Longitude,
      "Name": this.name,
      "BankDetailID": this.bankDetailID,

    };
  }
}
export class file implements Ifile {
  public get extension(): string {
    let value = "";
    switch (this._format.toLowerCase()) {
      case "application/pdf":
        value = "pdf";
        break;
      default:
        value = "jpg";
        break;
    }
    return value;
  }

  private _format: string = "application/pdf";
  public get format(): string {
    return this._format == "" ? `application/${this.extension}` : this._format;
  }
  public set format(value: string) {
    this._format = value;
  }
  file: string = "";
  referenceNo: string = "";

  constructor() {

  }
  url: string = "";
  filename: string = "";

  getFile() {
    return `data:${this.format};base64,${this.file}`;
  }
  getRaw() {
    return this.file;
  }

}




import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { InfoServices } from 'src/app/Injectable/info.services';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { EditSaveBtnGrpService } from './edit-save-btn-grp.service';

@Component({
  selector: 'app-edit-save-btn-grp',
  templateUrl: './edit-save-btn-grp.component.html',
  styleUrls: ['./edit-save-btn-grp.component.css']
})
export class EditSaveBtnGrpComponent implements OnInit {
  @Input() IsEdit: boolean = false;
  @Input() disabled: boolean = false;
  @Input() currentEdit: any;
  @Output("editCallback") edit = new EventEmitter<boolean>();
  @Output("submitCallBack") submit = new EventEmitter<any>();
  @Output("CanCelCallBack") CanCel = new EventEmitter<any>();
  constructor(private info: InfoServices, private editService: EditSaveBtnGrpService, private sanctionService: SanctionService) { }

  ngOnInit(): void {
  }
  public get readonly(): boolean {
    return this.sanctionService.LanInfo.readOnly;
  }
  editCallBack(): void {
    this.editService.currentEdit = JSON.stringify(this.currentEdit);
    this.IsEdit = !this.IsEdit;
    this.edit.emit(this.IsEdit);
  }
  submitCallBack(event: any) {
    this.submit.emit(event);
  }

  cancel(event: any) {
    if (this.editService.currentEdit && this.editService.currentEdit != "") {
      let current = JSON.parse(this.editService.currentEdit);
      this.editService.currentEdit = "";
      if (current) {
        this.CanCel.emit(current);

      } else {
        this.CanCel.emit(true);
      }
    }
    else {
      this.CanCel.emit(true);
    }
  }

}

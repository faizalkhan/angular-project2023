import { TestBed } from '@angular/core/testing';

import { EditSaveBtnGrpService } from './edit-save-btn-grp.service';

describe('EditSaveBtnGrpService', () => {
  let service: EditSaveBtnGrpService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EditSaveBtnGrpService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditSaveBtnGrpComponent } from './edit-save-btn-grp.component';

describe('EditSaveBtnGrpComponent', () => {
  let component: EditSaveBtnGrpComponent;
  let fixture: ComponentFixture<EditSaveBtnGrpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditSaveBtnGrpComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditSaveBtnGrpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EditSaveBtnGrpService {
  private _currentEdit: any;
  public get currentEdit(): any {
    return this._currentEdit;
  }
  public set currentEdit(value: any) {
    this._currentEdit = value;
  }
  
  constructor() { }
}

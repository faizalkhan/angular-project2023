import { outputAst } from '@angular/compiler';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { formBase } from '../layout-form-group/form-group.model';
import { FormControlService } from '../layout-form-group/form-group.service';


@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  providers: [FormControlService]
})
export class DynamicFormComponent implements OnInit {

  @Input() questions: formBase<string>[] | null = [];
  form!: FormGroup;
  payLoad = '';
  @Output() Onsubmit = new EventEmitter<FormGroup>();
  constructor(private qcs: FormControlService) { }

  ngOnInit() {
    this.form = this.qcs.toFormGroup(this.questions as formBase<string>[]);
  }

  onSubmit() {
    this.form.updateValueAndValidity();
    this.Onsubmit.emit(this.form);
  }
}
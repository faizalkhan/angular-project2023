import { Component, OnInit } from '@angular/core';
import { InfoServices } from 'src/app/Injectable/info.services';
import { NotificationService } from 'src/app/notification.service';
import { IDropdown } from 'src/app/shared/models/common/control.model';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
import { masterModuleDropdown } from 'src/app/shared/models/sanction/masterDropdown';
import { requestmodel } from 'src/app/shared/models/sanction/request.model';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { IModalCommon, ModalCommon, ModalService } from 'src/app/shared/services/modal/modal.service';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { FileUpload, IfileUpload, UploadViewDownloadService, Ifile } from '../../layout/button/upload-view-download/upload-view-download.service';
import { IInterActionDetail, InterActionDetail } from '../../riskcontrolunit/RCU.Model';
import { OpsAgreement } from '../dashboard/dashboard.service';
import IMaker, { ApplicantDetail, IApplicantDetail, IOpsLandDocCheckResponse, IOpsLANDisbDtl, IOtherDocuments, IUploadDocument, MakerSanctionInfo, MakersDetails, OpsLandDocCheckResponse, OpsLANDisbDtl, UploadDocument } from './makers.service';
import { ToWords } from 'to-words';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-makers',
  templateUrl: './makers.component.html',
  styleUrls: ['./makers.component.css']
})
export class MakersComponent implements OnInit {
  maker: IMaker = new MakersDetails();
  disbursementdetail: IOpsLANDisbDtl = new OpsLANDisbDtl();
  bankEdit: boolean = false;
  propertyEdit: boolean = false;
  isAdded: boolean = false;
  documentEdit: boolean = false;
  isDownloaded: boolean = false;
  isNachEnable: boolean = false;
  reject: any;
  PendingRejectData: any;
  RejectNach: any;
  rejncip: any;
  disbInfo: OpsAgreement = {} as OpsAgreement;
  isdisabledAddiCharges: boolean = false;
  PropValue: boolean = false;
  Generatelinkvalue: boolean = false;
  statusshow: boolean = false;
  physicalstatusshow: boolean = false;
  errstatusshow: boolean = false;
  Generetelinks: any;
  GetStatusId: any;
  IsDisb_Portal: boolean = false;
  checkersQueryReason: any;
  userName: any = "Test01";
  psId: any = "500836";
  IncomeAssesment: any;
  selectFile: any = null;
  isEnable: boolean = false;
  isEnachEnable: boolean = false;
  LandDocCheckResponse: IOpsLandDocCheckResponse = new OpsLandDocCheckResponse();
  Conditional: IDropdown[] = masterModuleDropdown.Conditional;
  private _rcuQueriesModel: InterActionDetail[] = [];
  selectedFile: any;
  hideEdit: boolean = true;
  ROIChange: boolean = false;
  bankDetails: any;
  public get rcuQueriesModel(): InterActionDetail[] {
    return this._rcuQueriesModel;
  }

  public set rcuQueriesModel(value: InterActionDetail[]) {
    this._rcuQueriesModel = value;
  }

  constructor(private http: ConfigService, private downloadUpload: UploadViewDownloadService,
    private modal: ModalService, private _notification: NotificationService, private info: InfoServices,
    private sanction: SanctionService, private datePipe: DatePipe) { }

  getAppDetails(): any {
    const request = new requestmodel();
    request.LoanAccountNumber = this.disbInfo.loanAccountNumber;
    request.CreatedON = "2022-10-05";
    request.FLO_PsId = this.sanction.userInfo.userId;
    request.RoleName = this.sanction.userInfo.roleName;
    return this.http.httpPost(request.OpsApptoJSON(), 'GetOpsAgreementDtl')

  }
  getOpsLanDocCheckResponse(): any {
    const request = new requestmodel();
    request.LoanAccountNumber = this.disbInfo.loanAccountNumber;
    return this.http.httpPost(request.OpsLanDoctoJSON(), 'LAP_OpsLandDocCheckResponse')
  }
  getOpsLANDisbDtl(): any {
    const request = new requestmodel();
    request.LoanAccountNumber = this.disbInfo.loanAccountNumber;
    request.CreatedON = "2022-09-13";
    request.FLO_PsId = this.sanction.userInfo.userId;
    request.RoleName = this.sanction.userInfo.roleName;
    return this.http.httpPost(request.OpsValtoJSON(), 'GetOpsLANDisbDtl')
  }
  getAgreementList(): any {
    const current = new Date();     
    let fromDate:any = new Date(new Date().setDate(current.getDate() - 150));
    let fromDateNew:any = this.datePipe.transform(fromDate, 'yyyy-MM-dd')?.toString();
    let toDate:any = this.datePipe.transform(current, 'yyyy-MM-dd');
    const request = new requestmodel();
    request.FromDate = fromDateNew;
    request.ToDate = toDate;
    request.FLO_PsId = this.sanction.userInfo.userId;
    request.RoleName = this.sanction.userInfo.roleName;
    request.CaseType = "";
    request.FieldName = "LAN";
    request.FieldValue = this.disbInfo.loanAccountNumber;
    return this.http.httpPost(request.OpsDashboardtoJSON(), 'GetLAP_OpsAgreementList');
  }
  RegisterBank() {
    let IFSCCode = this.disbursementdetail.disbursementInfo.ifsC_Code.substring(0, 4);
    this.http.httpPost<IresponseModel<any>>('', 'GetLAP_nach_banks').subscribe((res: IresponseModel<any>) => {
      this.IncomeAssesment = res?.data?.data?.filter((x: any) => x.id === IFSCCode)
      if (this.IncomeAssesment.length > 0) {
        this.isNachEnable = true;
      }
      else {
        this.isEnable = true;
      }
      if (this.IncomeAssesment = res?.data?.data?.filter((x: any) => x.id === IFSCCode) && (this.maker.applicationDetails[0].errorReason == 'submitted')) {
        this.isNachEnable = false;
      }
      else if (this.IncomeAssesment = res?.data?.data?.filter((x: any) => x.id === IFSCCode) && (this.maker.applicationDetails[0].errorReason == 'pending')) {
        this.RejectNach = "";
        this.rejncip = "";
        this.errstatusshow = true;
        //this.reject=res?.fetchSourcedata[0]?.redirect.response.mndtAccptResp.undrlygAccptncDtls.accptncRslt;
        this.PendingRejectData = this.maker.applicationDetails[0].errorDescs;
        //this.reject=res?.fetchSourcedata[0]?.redirect.response.mndtAccptResp.undrlygAccptncDtls.accptncRslt;
        this.statusshow = false;
        this.isEnable = true;
        this.isNachEnable = true;
      }
    });
  }
  RegisterEnach() {
    let amount = parseInt(this.disbursementdetail.disbursementInfo.emI_Amount) * 3 * 100;
    let totalAmount = JSON.stringify(amount);
    let date = new Date();
    let todayDate = this.datePipe.transform(date, 'yyyy-MM-dd');
    var data = {
      "type": "nach_debit",
      "nach_debit": {
        "amount_maximum": totalAmount,
        "category_code": "L001",
        "creditor_agent_code": "SCBL",
        "creditor_utility_code": "HDFC01436000011490",
        "date_first_collection": todayDate,
        "debtor_account_name": this.disbursementdetail.disbursementInfo.applicant_Name,
        "debtor_account_number": this.disbursementdetail.disbursementInfo.account_Number,
        "debtor_account_type": "savings",
        "debtor_agent_code": this.disbursementdetail.disbursementInfo.ifsC_Code.substring(0, 4),
        "debtor_email": this.maker.applicantDetails[0].emailId,
        "debtor_mobile": this.maker.applicantDetails[0].contact_Number,
        "debtor_phone": "8793769263",
        "frequency": "MNTH",
        "reference1": this.maker.loanAccountNo,
        "reference2": ""
      }
    }
    this.http.httpPost<IresponseModel<any>>(data, 'LAP_CreateEMandate').subscribe((res: IresponseModel<any>) => {
      if (res?.errorDescription == "The remote server returned an error: (429) Too Many Requests.") {
        this._notification.showWarning("Please wait few minutes link is generating...");
      } else if (res?.errorDescription == "Data fetched successfully !") {
        this._notification.showSuccess("Link is generated.");
        this.Generetelinks = res?.emandateRoot[0].redirect.url;
        this.GetStatusId = res?.emandateRoot[0].id;
        if (res?.emandateRoot[0].redirect.url.length > 0) {
          this.Generatelinkvalue = false;
        }
        else {
          this.Generatelinkvalue = true;
        }
      }
    });
  }
  GetStatus() {
    let data = {
      "lanid": this.disbInfo.loanAccountNumber,
      "id": this.GetStatusId
    }
    this.http.httpPost<IresponseModel<any>>(data, 'GetLAP_FetchSource').subscribe((res: IresponseModel<any>) => {
      if ((res?.fetchSourcedata[0]?.status == "submitted") && (res?.fetchSourcedata[0]?.redirect?.response_code == "000")) {
        this.statusshow = true;
        this.isEnable = false;
        this.reject = "";
        this.rejncip = "";
        this.RejectNach = "";
        this.PendingRejectData = "";
        this.isNachEnable = false;
        this.errstatusshow = false;
        this._notification.showSuccess("Your Registration is successful");
      }

      else if ((res?.fetchSourcedata[0]?.status == "pending") && (res?.fetchSourcedata[0]?.redirect?.response?.mndtAccptResp == null) && (res?.fetchSourcedata[0]?.redirect?.response?.mndtRejResp == null)) {
        this._notification.showWarning("Enach registration is pending, please complete the registration");
      }
      else if ((res?.fetchSourcedata[0]?.status == "pending") && (res?.fetchSourcedata[0]?.redirect?.response_code == "AP05")) {
        this.RejectNach = "";
        this.rejncip = "";
        this.errstatusshow = true;
        this.reject = res?.fetchSourcedata[0]?.redirect.response.mndtAccptResp.undrlygAccptncDtls.accptncRslt;
        this.statusshow = false;
        this.isEnable = true;
        this.isNachEnable = true;
        this._notification.showWarning("NACH registration has been failed-Reason :" + this.reject['rjctRsn']['reasonCode'] + "-" + this.reject['rjctRsn']['reasonDesc']);
      } else if ((res?.fetchSourcedata[0]?.status == "pending") && (res?.fetchSourcedata[0]?.redirect?.response_code == "185,182")) {
        this.PendingRejectData = "";
        this.RejectNach = "";
        this.reject = "";
        this.rejncip = res?.fetchSourcedata['0']?.redirect.response.mndtRejResp;
        this.errstatusshow = true;
        this.statusshow = false;
        this.isEnable = false;
        this.isNachEnable = true;
        this._notification.showError("Rejected by NPCI :" + this.rejncip['mndtErrorDtls']['errorCode'] + "-" + this.rejncip['mndtErrorDtls']['errorDesc']);
      }

    })
  }
  DownloadPhysicalMadate(event: any) {
    let amount = parseInt(this.disbursementdetail.disbursementInfo.emI_Amount) * 3;
    let totalAmount = JSON.stringify(amount);
    const toWords = new ToWords();
    let amountInWords = toWords.convert(amount);
    let disbDate = this.datePipe.transform(this.disbursementdetail.disbursementInfo.disbDate, 'dd/MM/yyyy');
    let repaymentDate = this.datePipe.transform(this.disbursementdetail.disbursementInfo.repaymentDate, 'dd/MM/yyyy');
    let data = {
      "logo": "1001",
      "UMRN": " ",
      "sponsorCode": "SCBL0036001",
      "utilityCode": "HDFC01436000011490",
      "bankName": this.disbursementdetail.disbursementInfo.bank_name,
      "IFSCCode": this.disbursementdetail.disbursementInfo.ifsC_Code,
      "accountHolder": this.disbursementdetail.disbursementInfo.account_Holder_Name,
      "startDate": repaymentDate,
      "nachDate": disbDate,
      "debitType": "maximumAmount",
      "amountInNumber": totalAmount,
      "amountInWords": amountInWords,
      "NACHType": "create",
      "frequency": "monthly",
      "accountType": "SB",
      "untilCanceled": "true",
      "companyName": "L&T FINANCE LTD",
      "accountNumber": this.disbursementdetail.disbursementInfo.account_Number,
      "reference1": this.disbInfo.loanAccountNumber
    }
    this.http.httpPost<IresponseModel<any>>(data, 'LAP_PopulateNach').subscribe((res: IresponseModel<any>) => {
      this.downloadUpload.downloadFile(res?.result?.outputImage, 'application/pdf', `${event}.pdf`);
    });
  }
  onFileSelected(event: any) {
    this.selectFile = event.target.files[0].type;
    this.selectedFile = event.target.files[0];
    if ((this.selectFile == "application/pdf") || (this.selectFile == "application/doc") || (this.selectFile == "text/plain") || (this.selectFile == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") || (this.selectFile == "application/vnd.openxmlformats-officedocument.wordprocessingml.document")) {
      this._notification.showError("Please upload only jpg/jpeg/png format");
      return false;
    } else {
      this._notification.showSuccess("Data piked successfully");
      return true;
    }
  }
  onUpload() {
    let data = {
      "lanid": this.disbInfo.loanAccountNumber,
      "formpath": "",
      "clientid": this.disbInfo.leadId,
      "IFSCCode": this.disbursementdetail.disbursementInfo.ifsC_Code,
      "accountNumber": this.disbursementdetail.disbursementInfo.account_Number,
      "image": this.selectedFile
    }
    let fd = new FormData();
    fd.append("lanid", this.disbInfo.loanAccountNumber);
    fd.append("clientid", this.disbInfo.leadId);
    fd.append("IFSCCode", this.disbursementdetail.disbursementInfo.ifsC_Code);
    fd.append("accountNumber", this.disbursementdetail.disbursementInfo.account_Number);

    fd.append('image', this.selectedFile);
    if ((data.lanid === this.disbInfo.loanAccountNumber) && (data.IFSCCode === this.disbursementdetail.disbursementInfo.ifsC_Code) && (data.accountNumber == this.disbursementdetail.disbursementInfo.account_Number)) {
      this.http.httpPost<IresponseModel<any>>(fd, 'LAP_ReadNach').subscribe((res: IresponseModel<any>) => {
        if (res.status == "MATCH") {
          this._notification.showSuccess("Nach Registration is successfully uploaded");
          this.physicalstatusshow = true;
          this.isEnable = false;
        }
        else {
          this._notification.showError("Data mismatch please upload correct nach document");
        }

      });
    }
    else {
      this._notification.showError("Data mismatch please upload correct nach document");
    }

  }

  getOtherDoc(item: IUploadDocument, docType: any): any {
    this.downloadUpload.GetCommonForm(item.applicationNo, item.loanAccountNumber, docType).subscribe(res => {
      if (res.Errorcode == "00" || res.Errorcode == "0") {
        item.prevFormDownload = true;
        this.downloadUpload.downloadFile(res.PdfDoc, 'application/pdf', `${item?.applicationNo}_${docType}.pdf`);
      }
      else {
        this._notification.showError(res.ErrorDescription);
      }
    });
  }
  IsDownload(item?: IUploadDocument) {
    return (item && !item.prevFormDownload) == true;
  }
  setDocTypeDescription(event: any) {
    this.downloadUpload.uploadLoad.docTypeDescription = event;
  }
  ngOnInit(): void {
    this.documentEdit = false;
    this.disbInfo = JSON.parse(this.info.getItem('disbInfo'));

    this.EnableDisableControls();

    this.getAgreementList().subscribe((res:any) => {
      if((res.data[0].caseStatus == "Pending with checker") || (res.data[0].caseStatus == "Sent back to credit") || 
        (res.data[0].caseStatus == "Rejected") || (res.data[0].caseStatus == "Approved") || (res.data[0].caseStatus == "Completed")) {
        this.hideEdit = false;
      }
    });

    this.downloadUpload.uploadLoad = new FileUpload({
      flO_Id: this.sanction.LanInfo.flopsid,
      loanAccountNumber: this.disbInfo.loanAccountNumber,
      applicationNo: "",
      leadID: this.disbInfo.leadId,
      moduleName: "OPS_Makers",

    } as IfileUpload);


    this.getAppDetails().subscribe((res: IMaker) => {
      if (res.errorcode == "00") {
        this.maker = new MakersDetails(res);
        this.maker.loanAccountNo = this.disbInfo.loanAccountNumber;
        this.maker.flo_PSID = this.sanction.LanInfo.flopsid;
        this.getOpsLanDocCheckResponse().subscribe((res: OpsLandDocCheckResponse) => {
          if (res.errorcode == "00") {
            this.maker.OpsLandDocCheckResponse = new OpsLandDocCheckResponse(res);

          }
          else {
            this.maker.OpsLandDocCheckResponse = new OpsLandDocCheckResponse();
          }

          this.getOpsLANDisbDtl().subscribe((resOpsLANDisbDtl: OpsLANDisbDtl) => {
            if (resOpsLANDisbDtl.errorcode == "00") {

              this.disbursementdetail = new OpsLANDisbDtl(resOpsLANDisbDtl);
              this.bankDetails = this.disbursementdetail.allBankList.filter(x => x.accountNumber == this.disbursementdetail.disbursementInfo.account_Number);
              this.disbursementdetail.disbursementInfo.documents = res.opsLandDocCheck.map(x => { return { applicationNo: x.applicationNo, loanAccountNumber: x.loanAccountNumber, docRef: x.dmS_UUID, docType: x.docType, opsMakerVerificationStatus: x.opsMakerVerificationStatus, opsCheckerVerificationStatus: x.opsCheckerVerificationStatus, description: x.docTypeDescription } as IUploadDocument })
            }

          });
        });

        var queriesParam = {
          "LoanAccountNumber": this.disbInfo.loanAccountNumber,
          "Source": "OPS"
        }

        // if(this.roleId==="ARM" && this.SelectedRow.subStage==="Postsanction"){
        this.getQueries(queriesParam);
        //}

        if (this.maker.applicationDetails[0].match == 'Y') {
          this.isEnable = false;
          this.physicalstatusshow = true;
        }
        if (this.maker.applicationDetails[0].errorReason == 'submitted') {
          this.isNachEnable = false;
          this.statusshow = true;
          this.RejectNach = "";
        }
        else if (this.maker.applicationDetails[0].errorDescs == 'pending') {
          this.isNachEnable = true;
          this.errstatusshow = true;
          this.RejectNach = this.maker.applicationDetails[0].errorReason;
        }
      }
      else {
        this.maker = new MakersDetails();
      }
    });
  }

  EnableDisableControls() {
    if (this.disbInfo.caseStatus === "Pending with checker" || this.disbInfo.caseStatus === "Sent back to credit"
      || this.disbInfo.caseStatus === "Rejected" || this.disbInfo.caseStatus === "Approved"
      || this.disbInfo.caseStatus === "Completed" || this.disbInfo.caseStatus === "Hold"
      || this.maker.reqType === 'Approved' || this.maker.reqType === 'Rejected' || this.maker.reqType === 'SentbackToCredit') {
      this.hideEdit = false;
      this.isNachEnable = false;
      this.isEnable = false;
    }
  }
  getQueries(param: any) {
    this.http.httpPost<IresponseModel<InterActionDetail[]>>(param, 'GetOpsCreditInteractionDtl').subscribe((res: IresponseModel<InterActionDetail[]>) => {
      if (res !== null) {
        this._notification.showSuccess("Queries retrived successfully", "Application");
        this.rcuQueriesModel = res.creditInteractionDtl.map((x: IInterActionDetail) => {
          return new InterActionDetail(x);
        });

      } else {
        this._notification.showError("Something went wrong", "Application");
      }
    });
  }

  remove(index: any) {
    this.maker?.OtherDocs.splice(index, 1);
  }
  addMore() {
    let data = this.maker.otherAddMore();
    let find = data[this.maker.OtherDocs.length];
    find.description = find.doc_Ref = "";
    this.maker.OtherDocs.push(find);
  }

  submit(ReqType: any, item: any, dis: any) {
    this.maker.reqType = ReqType;
    if (this.validation()) {
        this.http.httpPost<IresponseModel<any>>(this.maker.toJson(item, dis), 'LAP_OpsSubmitAgreementDtl').subscribe((res: IresponseModel<any>) => {
          if (res.errorcode == "00") {
            this._notification.showSuccess(res.errorDescription);
            this.ngOnInit();
          }
          else {
            this._notification.showError(res.errorDescription);
          }
        });
      }
  }
    

  OnROIChange() {
    this._notification.showWarning("Please upload the ROI change approval document");
    this.bankEdit = true;
    this.ROIChange = true;
  }

  validation() {
    let date = new Date();
    let modtDate = new Date(this.disbursementdetail.disbursementInfo.modTdate);
    if(this.maker.reqType == "BankDetails_Update_Portal") {
      if((this.disbursementdetail.disbursementInfo.spdC1_NO == this.disbursementdetail.disbursementInfo.spdC2_NO) || (this.disbursementdetail.disbursementInfo.spdC1_NO == this.disbursementdetail.disbursementInfo.spdC3_NO) || (this.disbursementdetail.disbursementInfo.spdC2_NO == this.disbursementdetail.disbursementInfo.spdC3_NO)) {
        this._notification.showWarning("SPDC number should be different from other SPDC numbers");
        this.bankEdit = !this.bankEdit;
        return false;
      }
    }
    if(this.ROIChange == true) {
      this._notification.showWarning("Please upload the ROI change approval document");
      this.ROIChange = false;
      this.bankEdit = !this.bankEdit;
      return false;
    }
    if (modtDate > date) {
      this._notification.showWarning("Please enter current date or past date");
      return false;
    }
    if (this.maker.OtherDocs.filter(x => x.description == "")?.length > 0) {
      this._notification.showWarning("Please enter document description");
      this.propertyEdit = !this.propertyEdit;
      this.isAdded = this.isAdded;
      return false;
    }
    if (this.maker.OtherDocs.filter(x => x.doc_Ref == "")?.length > 0) {
      this._notification.showWarning("Please upload the document");
      this.propertyEdit = !this.propertyEdit;
      this.isAdded = this.isAdded;
      return false;
    } 

    return true;
  }

  cancel(event: any, section:any) {
    if(section === "prop") {
      let data = event.filter(function (el:any) {
        return el.description != "";
      });
      this.maker.OtherDocs = data;
    } else {
      this.disbursementdetail.disbursementInfo = new MakerSanctionInfo(event);
    }
  }

  FinalSave(a: any, msg: any) {
    this.maker.reqType = a;
    if(this.FinalSaveValidation()) {
      let Action: Function = () => {
        this.http.httpPost<IresponseModel<any>>(this.maker.toJson(undefined, this.disbursementdetail.disbursementInfo), 'LAP_OpsSubmitAgreementDtl').subscribe((res: IresponseModel<any>) => {
          if (res.errorcode == "00") {
            this._notification.showSuccess(res.errorDescription);
            this.ngOnInit();
          }
          else {
            this._notification.showError(res.errorDescription);
          }
        });
      }
      let modal = new ModalCommon({
        title: "Confirmation",
        message: `Are you sure you want to ${msg}? Please confirm to proceed.?`,
        sAction: Action,
        sActionText: 'Confirm',
        sActionShow: true
      } as IModalCommon);
      this.modal.ShowModal(modal);
    }
  }

  FinalSaveValidation() {
    let data = this.maker.toJson(undefined, this.disbursementdetail.disbursementInfo);
    if((data.PropertTitleDoc_YN == "N" || data.PropertTitleDoc_YN == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("Property Title Document should not be blank");
      return false;
    } else if((data.TechnicalRpt_YN == "N" || data.TechnicalRpt_YN == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("Technical Report Document should not be blank");
      return false;
    } else if((data.Mutuation_YN == "N" || data.Mutuation_YN == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("Mutation Document should not be blank");
      return false;
    } else if((data.MODTDoc_YN == "N" || data.MODTDoc_YN == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("MODT Document should not be blank");
      return false;
    } else if((data.PropTaxRecpt_YN == "N" || data.PropTaxRecpt_YN == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("Property Tax Receipt Document should not be blank");
      return false;
    } else if((data.ChainDoc_YN == "N" || data.ChainDoc_YN == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("Chain Document should not be blank");
      return false;
    } else if((data.LegalRpt_YN == "N" || data.LegalRpt_YN == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("Legal Report Document should not be blank");
      return false;
    } else if((data.MODTDocNo == "" || data.MODTdate == "" || data.MODTplace == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("MODT Details should not be blank");
      return false;
    } else if((data.SPDC1_YN == "N" || data.SPDC1_YN == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("SPDC1 Document should not be blank");
      return false;
    } else if((data.SPDC2_YN == "N" || data.SPDC2_YN == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("SPDC2 Document should not be blank");
      return false;
    } else if((data.SPDC3_YN == "N" || data.SPDC3_YN == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("SPDC3 Document should not be blank");
      return false;
    } else if(((data.SPDC1_NO == "" || data.SPDC1_NO == "0") || (data.SPDC2_NO == "" || data.SPDC2_NO == "0") || (data.SPDC3_NO == "" || data.SPDC3_NO == "0")) && this.maker.reqType == 'Approved') {
      this._notification.showWarning("SPDC's Number should not be blank");
      return false;
    } else if((data.ROIChangeApproval_YN == "N" || data.ROIChangeApproval_YN == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("ROI Change Approval Document should not be blank");
      return false;
    } else if((this.maker.DisbursementRequestLetter.docRef == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("Customer Request Letter for Disbursement Document should not be blank");
      return false;
    } else if((this.maker.LoanAgreement.docRef == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("Loan Agreement Document should not be blank");
      return false;
    } else if((this.maker.LoanOfferLetter.docRef == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("Sanction Letter Document should not be blank");
      return false;
    } else if(data.NomineeName == '' || data.NomineeDOB == '' || data.RelWithNominee == '') {
      this._notification.showWarning("Nominee details should not be blank");
      return false;
    } else if((this.maker.clI_Charge.docRef == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("CLI Charge Document should not be blank");
      return false;
    } else if((this.maker.property_insurance.docRef == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("Property Insurance Document should not be blank");
      return false;
    } else if((this.maker.applicationDetails[0].errorReason == "") && this.maker.reqType == 'Approved') {
      this._notification.showWarning("Mandate Registration is mandatory");
      return false;
    } else if (this.maker.reqType.toLowerCase() != "approved" && (!this.disbursementdetail.disbursementInfo.maker_Remarks || this.disbursementdetail.disbursementInfo.maker_Remarks == '')) {
      this._notification.showWarning('Remark is required');
      return false;
    }
    return true;
  }

}

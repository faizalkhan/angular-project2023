import { common } from "src/app/shared/models/common";
import { Dropdown, IDropdown } from "src/app/shared/models/common/control.model";
import { fileDownload, Ifile } from "../../layout/button/upload-view-download/upload-view-download.service";

export class MakersDetails implements IMaker {
    Other_Doc_1_YN: string = "";
    private _Other_Doc_Desc_1: string = "";
    public get Other_Doc_Desc_1(): string {
        return this._Other_Doc_Desc_1;
    }
    public set Other_Doc_Desc_1(value: string) {
        this._Other_Doc_Desc_1 = value;
    }
    Other_Doc_2_YN: string = "";
    private _Other_Doc_Desc_2: string = "";
    public get Other_Doc_Desc_2(): string {
        return this._Other_Doc_Desc_2;
    }
    public set Other_Doc_Desc_2(value: string) {
        this._Other_Doc_Desc_2 = value;
    }
    Other_Doc_3_YN: string = "";
    private _Other_Doc_Desc_3: string = "";
    public get Other_Doc_Desc_3(): string {
        return this._Other_Doc_Desc_3;
    }
    public set Other_Doc_Desc_3(value: string) {
        this._Other_Doc_Desc_3 = value;
    }
    Other_Doc_4_YN: string = "";
    private _Other_Doc_Desc_4: string = "";
    public get Other_Doc_Desc_4(): string {
        return this._Other_Doc_Desc_4;
    }
    public set Other_Doc_Desc_4(value: string) {
        this._Other_Doc_Desc_4 = value;
    }
    Other_Doc_5_YN: string = "";
    private _Other_Doc_Desc_5: string = "";
    public get Other_Doc_Desc_5(): string {
        return this._Other_Doc_Desc_5;
    }
    public set Other_Doc_Desc_5(value: string) {
        this._Other_Doc_Desc_5 = value;
    }
    Other_Doc_6_YN: string = "";
    private _Other_Doc_Desc_6: string = "";
    public get Other_Doc_Desc_6(): string {
        return this._Other_Doc_Desc_6;
    }
    public set Other_Doc_Desc_6(value: string) {
        this._Other_Doc_Desc_6 = value;
    }
    Other_Doc_7_YN: string = "";
    private _Other_Doc_Desc_7: string = "";
    public get Other_Doc_Desc_7(): string {
        return this._Other_Doc_Desc_7;
    }
    public set Other_Doc_Desc_7(value: string) {
        this._Other_Doc_Desc_7 = value;
    }
    propDoc1_Ref: IUploadDocument = new UploadDocument;
    propDoc2_Ref: IUploadDocument = new UploadDocument;
    propDoc3_Ref: IUploadDocument = new UploadDocument;
    propDoc4_Ref: IUploadDocument = new UploadDocument;
    propDoc5_Ref: IUploadDocument = new UploadDocument;
    propDoc6_Ref: IUploadDocument = new UploadDocument;
    propDoc7_Ref: IUploadDocument = new UploadDocument;

    errorcode: string = "";
    errorDescription: string = "";
    applicantDetails: ApplicantDetail[] = [];
    applicationDetails: ApplicationDetail[] = [];
    coAppDetails: CoAppDetail[] = [];
    private _PropertyDocments: IUploadDocument[] = [];
    public get PropertyDocments(): IUploadDocument[] {
        return this._PropertyDocments;
    }
    public set PropertyDocments(value: IUploadDocument[]) {
        this._PropertyDocments = value;
        if (this._PropertyDocments.length > 0) {
            this.setDocuments();
        }
    }
    reqType: string = "";
    loanAccountNo: string = "";
    flo_PSID: string = "";
    private _disbursementdetail: IOpsLANDisbDtl = new OpsLANDisbDtl();
    public get disbursementdetail(): IOpsLANDisbDtl {
        return this._disbursementdetail;
    }
    public set disbursementdetail(value: IOpsLANDisbDtl) {
        this._disbursementdetail = value;
    }
    private _CombinapplicantDetail: ApplicantDetail[] = [];
    public get CombinapplicantDetail(): ApplicantDetail[] {
        return this._CombinapplicantDetail;
    }
    public set CombinapplicantDetail(value: any[]) {
        this._CombinapplicantDetail = value;
    }


    constructor(param?: IMaker) {
        if (param) {
            this.applicantDetails = param.applicantDetails;
            this.applicationDetails = param.applicationDetails;
            this.coAppDetails = param.coAppDetails;
            this.CombinapplicantDetail = [...this.applicantDetails, ...this.coAppDetails].map(x => { x = new ApplicantDetail(x); return this.getDocments(x) });
        }
    }
    private _OtherDocs: IOtherDocuments[] = [];
    public get OtherDocs(): IOtherDocuments[] {
        return this._OtherDocs;
    }
    public set OtherDocs(value: IOtherDocuments[]) {
        this._OtherDocs = value;
    }

    private _disbursementRequestLetter: IUploadDocument = new UploadDocument();
    public get DisbursementRequestLetter(): IUploadDocument {
        return this._disbursementRequestLetter;
    }
    public set DisbursementRequestLetter(value: IUploadDocument) {
        this._disbursementRequestLetter = value;
    }
    private _LoanAgreement: IUploadDocument = new UploadDocument();
    public get LoanAgreement(): IUploadDocument {
        return this._LoanAgreement;
    }
    public set LoanAgreement(value: IUploadDocument) {
        this._LoanAgreement = value;
    }
    private _LoanOfferLetter: IUploadDocument = new UploadDocument();
    public get LoanOfferLetter(): IUploadDocument {
        return this._LoanOfferLetter;
    }
    private _clI_Charge: IUploadDocument = new UploadDocument();
    public get clI_Charge(): IUploadDocument {
        return this._clI_Charge;
    }
    public set clI_Charge(value: IUploadDocument) {
        this._clI_Charge = value;
    }
    private _property_insurance: IUploadDocument = new UploadDocument();
    public get property_insurance(): IUploadDocument {
        return this._property_insurance;
    }
    public set property_insurance(value: IUploadDocument) {
        this._property_insurance = value;
    }
    public set LoanOfferLetter(value: IUploadDocument) {
        this._LoanOfferLetter = value;
    }
    private _OpsLandDocCheckResponse: OpsLandDocCheckResponse = new OpsLandDocCheckResponse();
    public get OpsLandDocCheckResponse(): OpsLandDocCheckResponse {
        return this._OpsLandDocCheckResponse;
    }
    public set OpsLandDocCheckResponse(value: OpsLandDocCheckResponse) {
        this._OpsLandDocCheckResponse = value;
        this.CombinapplicantDetail.forEach(x => { x = this.getDocments(x); });
        this.PropertyDocments = value.opsLandDocCheck.map(x => { return new UploadDocument({ applicationNo: x.applicationNo, loanAccountNumber: x.loanAccountNumber, docRef: x.dmS_UUID, docType: x.docType, opsCheckerVerificationStatus: x.opsCheckerVerificationStatus, opsMakerVerificationStatus: x.opsMakerVerificationStatus, description: x.docTypeDescription } as IUploadDocument) })
        this._OtherDocs = this.getOtherDocs().filter((x: any) => ((x.description != "" || x.doc_Ref != "") || x.doc_visible));
    }
    private _ROIApproval: IUploadDocument = new UploadDocument();
    public get ROIApproval(): IUploadDocument {
        return this._ROIApproval;
    }
    public set ROIApproval(value: IUploadDocument) {
        this._ROIApproval = value;
    }
    setDocuments() {
        this.DisbursementRequestLetter = this.getDocumentObject('DisbursementRequestLetter');
        this.LoanAgreement = this.getDocumentObject('LoanAgreement');
        this.LoanOfferLetter = this.getDocumentObject('LoanOfferLetter');
        this.property_insurance = this.getDocumentObject('PropertyInsurance');
        this.clI_Charge = this.getDocumentObject('CLIForm');
        this.ROIApproval = this.getDocumentObject('ROIApproval');
        this.propDoc1_Ref = this.getDocumentObject('OTHER_DOC_ONE');
        this.propDoc2_Ref = this.getDocumentObject('OTHER_DOC_TWO');
        this.propDoc3_Ref = this.getDocumentObject('OTHER_DOC_THREE');
        this.propDoc4_Ref = this.getDocumentObject('OTHER_DOC_FOUR');
        this.propDoc5_Ref = this.getDocumentObject('OTHER_DOC_FIVE');
        this.propDoc6_Ref = this.getDocumentObject('OTHER_DOC_SIX');
        this.propDoc7_Ref = this.getDocumentObject('OTHER_DOC_SEVEN');
    }
    GetVerifiedDoc() {
        let data: IUploadDocument[] = [];
        this.CombinapplicantDetail.forEach(x => {
            if (x.ApplicantImg.docType != '')
                data.push(x.ApplicantImg.toJSON());
            if (x.HouseImg.docType != '')
                data.push(x.HouseImg.toJSON());
            if (x.KYC.docType != '')
                data.push(x.KYC.toJSON());
            if (x.KA2_FRONT.docType != '')
                data.push(x.KA2_FRONT.toJSON());
            if (x.KA2_BACK.docType != '')
                data.push(x.KA2_BACK.toJSON());        
            if (x.PAN.docType != '')
                data.push(x.PAN.toJSON());
            if (x.FORM60.docType != '')
                data.push(x.FORM60.toJSON());
            if (x.KA1_BACK.docType != '')
                data.push(x.KA1_BACK.toJSON());
            if (x.KA1_FRONT.docType != '')
                data.push(x.KA1_FRONT.toJSON());
        });
        return data;
    }
    findByDocumentType(name: any): IOtherDocuments | undefined {
        return this.OtherDocs.find((x: IOtherDocuments) => x.doc_Type.toLowerCase() == name.toLowerCase()) ?? undefined;
    }
    getOtherDocs() {
        let data: IOtherDocuments[] = [];
        data.push({ description: this.propDoc1_Ref.description, doc_Ref: this.propDoc1_Ref.docRef, doc_Ref_YN: this.Other_Doc_1_YN, doc_Type: "OTHER_DOC_ONE" } as IOtherDocuments);
        data.push({ description: this.propDoc2_Ref.description, doc_Ref: this.propDoc2_Ref.docRef, doc_Ref_YN: this.Other_Doc_2_YN, doc_Type: "OTHER_DOC_TWO" } as IOtherDocuments);
        data.push({ description: this.propDoc3_Ref.description, doc_Ref: this.propDoc3_Ref.docRef, doc_Ref_YN: this.Other_Doc_3_YN, doc_Type: "OTHER_DOC_THREE" } as IOtherDocuments);
        data.push({ description: this.propDoc4_Ref.description, doc_Ref: this.propDoc4_Ref.docRef, doc_Ref_YN: this.Other_Doc_4_YN, doc_Type: "OTHER_DOC_FOUR" } as IOtherDocuments);
        data.push({ description: this.propDoc5_Ref.description, doc_Ref: this.propDoc5_Ref.docRef, doc_Ref_YN: this.Other_Doc_5_YN, doc_Type: "OTHER_DOC_FIVE" } as IOtherDocuments);
        data.push({ description: this.propDoc6_Ref.description, doc_Ref: this.propDoc6_Ref.docRef, doc_Ref_YN: this.Other_Doc_6_YN, doc_Type: "OTHER_DOC_SIX" } as IOtherDocuments);
        data.push({ description: this.propDoc7_Ref.description, doc_Ref: this.propDoc7_Ref.docRef, doc_Ref_YN: this.Other_Doc_7_YN, doc_Type: "OTHER_DOC_SEVEN" } as IOtherDocuments);
        return data;
    }
    otherAddMore() {
        let data = this.getOtherDocs();
        let find = data[this.OtherDocs.length];
        find.description = find.doc_Ref = "";
        this.OtherDocs.push(find);
    }
    getDocumentObject(docType: any): IUploadDocument {
        let _obj = this.PropertyDocments.find(x => x.docType.toLowerCase() == docType.toLowerCase());
        if (_obj)
            return _obj;
        else
            return new UploadDocument({ loanAccountNumber: this.loanAccountNo, applicationNo: '', docType: docType, docRef: '', description: '' } as IUploadDocument)
    }
    getDocments(app: any): ApplicantDetail {
        app.documents = this.OpsLandDocCheckResponse.opsLandDocCheck.filter(x => x.applicationNo == app.applicationNo).map(x => { return new UploadDocument({ applicationNo: x.applicationNo, loanAccountNumber: x.loanAccountNumber, docRef: x.dmS_UUID, docType: x.docType, opsCheckerVerificationStatus: x.opsCheckerVerificationStatus, opsMakerVerificationStatus: x.opsMakerVerificationStatus } as IUploadDocument) });


        return app;
    }
    getPropertyRef(name: any): string {
        let item = this.PropertyDocments.find(x => x.docType.toLowerCase() == name.toLowerCase());
        if (item) {
            return item.docRef;
        }
        else {
            return "";
        }
    }
    toJson(applicant?: ApplicantDetail, disbursment?: MakerSanctionInfo, makerDoc?: MakersDetails) {
        return {
            "ApplicationNo": applicant?.applicationNo,
            "Account_Holder_Type": disbursment?.account_Holder_Type,
            "Account_Type": disbursment?.account_Type,
            "Account_Category": disbursment?.account_Category,
            "BankAccountHolderName": disbursment?.account_Holder_Name,
            "BankAccountNumber": disbursment?.account_Number,
            "BankName": disbursment?.bank_name,
            "ChainDoc_YN": disbursment?.OPS_ChainDoc_Ref.docRef != "" ? 'Y' : 'N',
            "Checker_Case_Status": disbursment?.checker_Case_Status,
            "Checker_Remarks": disbursment?.checker_Remarks,
            "CustL_Disbursement_YN": makerDoc?.DisbursementRequestLetter.docRef != "" ? 'Y' : 'N',
            "Property_Insurance_YN": makerDoc?.property_insurance.docRef != "" ? 'Y' : 'N',
            "Cli_Form_YN": makerDoc?.clI_Charge.docRef != "" ? 'Y' : 'N',
            "DisbAcctChange_YN": disbursment?.account_Number,
            "FLO_PsId": this.flo_PSID,
            "Hold_Status": disbursment?.hold_Status,
            "Hold_Status_Dtl": disbursment?.Hold_Status_Dtl,
            "IfscCode": disbursment?.ifsC_Code,
            "LegalRpt_YN": disbursment?.OPS_LegalReport_Ref.docRef != "" ? 'Y' : 'N',
            "Loan_agreement_set_YN": makerDoc?.LoanAgreement.docRef != "" ? 'Y' : 'N',
            "LoanAccountNumber": this.loanAccountNo,
            "Maker_Case_Status": disbursment?.maker_Case_Status,
            "Maker_Remarks": disbursment?.maker_Remarks,
            "Mandate_Type": disbursment?.mandate_Type_Selection,
            "MODTdate": disbursment?.modTdate,
            "MODTDoc_YN": disbursment?.OPS_MODTDoc_Ref.docRef != "" ? 'Y' : 'N',
            "MODTDocNo": disbursment?.modtDocNo,
            "MODTplace": disbursment?.modTplace,
            "Mutuation_YN": disbursment?.OPS_MutationDoc_Ref.docRef != "" ? 'Y' : 'N',
            "NomineeDOB": disbursment?.nominee_DOB,
            "NomineeName": disbursment?.nominee_Name,
            "OpsDisbAcct": "",
            "OtherPropDoc_YN": disbursment?.OPS_OtherPropertyDoc_Ref.docRef != "" ? 'Y' : 'N',
            "PropertTitleDoc_YN": disbursment?.OPS_PropertyTitle_Ref.docRef != "" ? 'Y' : 'N',
            "PropTaxRecpt_YN": disbursment?.OPS_PropertyTaxReceipt_Ref.docRef != "" ? 'Y' : 'N',
            "RelWithNominee": disbursment?.relation_with_Nominee,
            "rejection_reason": disbursment?.rejection_reason,
            "repaymentDate": makerDoc?.reqType == "C_Approved" ? disbursment?.repaymentDate : '',
            "ReqType": this.reqType,
            "ROI": disbursment?.roi,
            "ROIChangeApproval_YN": disbursment?.roI_Change_Approval_Ref != "" ? 'Y' : 'N',
            "Sanction_letter_YN": makerDoc?.LoanOfferLetter.docRef != "" ? 'Y' : 'N',
            "SPDC1_YN": disbursment?.spdC_1.docRef != "" ? 'Y' : 'N',
            "SPDC2_YN": disbursment?.spdC_2.docRef != "" ? 'Y' : 'N',
            "SPDC3_YN": disbursment?.spdC_3.docRef != "" ? 'Y' : 'N',
            "SPDC1_NO": disbursment?.spdC1_NO,
            "SPDC2_NO": disbursment?.spdC2_NO,
            "SPDC3_NO": disbursment?.spdC3_NO,
            "TechnicalRpt_YN": disbursment?.OPS_TechnicalReport_Ref.docRef != "" ? 'Y' : 'N',

            "Other_Doc_Desc_1": this.findByDocumentType('OTHER_DOC_ONE')?.description ?? "",
            "Other_Doc_1": this.findByDocumentType('OTHER_DOC_ONE')?.doc_Ref != "" ? 'Y' : 'N',
            "Other_Doc_Desc_2": this.findByDocumentType('OTHER_DOC_TWO')?.description ?? "",
            "Other_Doc_2": this.findByDocumentType('OTHER_DOC_TWO')?.doc_Ref != "" ? 'Y' : 'N',
            "Other_Doc_Desc_3": this.findByDocumentType('OTHER_DOC_THREE')?.description ?? "",
            "Other_Doc_3": this.findByDocumentType('OTHER_DOC_THREE')?.doc_Ref != "" ? 'Y' : 'N',
            "Other_Doc_Desc_4": this.findByDocumentType('OTHER_DOC_FOUR')?.description ?? "",
            "Other_Doc_4": this.findByDocumentType('OTHER_DOC_FOUR')?.doc_Ref != "" ? 'Y' : 'N',
            "Other_Doc_Desc_5": this.findByDocumentType('OTHER_DOC_FIVE')?.description ?? "",
            "Other_Doc_5": this.findByDocumentType('OTHER_DOC_FIVE')?.doc_Ref != "" ? 'Y' : 'N',
            "Other_Doc_Desc_6": this.findByDocumentType('OTHER_DOC_SIX')?.description ?? "",
            "Other_Doc_6": this.findByDocumentType('OTHER_DOC_SIX')?.doc_Ref != "" ? 'Y' : 'N',
            "Other_Doc_Desc_7": this.findByDocumentType('OTHER_DOC_SEVEN')?.description ?? "",
            "Other_Doc_7": this.findByDocumentType('OTHER_DOC_SEVEN')?.doc_Ref != "" ? 'Y' : 'N',

            "UpdateAddress": [{
                "ApplicationNo": applicant?.applicationNo,
                "Address1": applicant?.address1,
                "Address2": applicant?.address2
            }],
            "UpdateKycDocs": this.GetVerifiedDoc()
        }
    }
}


export interface ApplicationDetail {
    applicationNo: string;
    applicantName: string;
    productType: string;
    match: string;
    errorDescs: string;
    errorReason: string;
}

export interface IApplicantDetail {
    firstName: string;
    lastName: string;
    dob: string;
    address1: string;
    address2: string;
    financialStatus: string;
    permanentAddress: string;
    applicationNo: string;
    pan: string;
    kyC1_Details: string;
    kyC2_Details: string;
    addressProof: string;
    type_of_Applicant: string;
    panStatus: string;
    isForm60_Disable: boolean;
}
export class ApplicantDetail implements IApplicantDetail, CoAppDetail {
    private _contact_Number: string = "";
    public get contact_Number(): string {
        return this._contact_Number;
    }
    public set contact_Number(value: string) {
        this._contact_Number = value;
    }
    private _panStatus: string = "";
    public get panStatus(): string {
        return this._panStatus;
    }
    public set panStatus(value: string) {
        this._panStatus = value;
    }
    public get isForm60_Disable(): boolean {
        return this.pan == "" || this.pan.toLowerCase() == "Not Available";
    }

    private _permanent_Address: string = "";
    public get permanent_Address(): string {
        return this._permanent_Address;
    }
    public set permanent_Address(value: string) {
        this._permanent_Address = value;
    }
    private _financial_Status: string = "";
    public get financial_Status(): string {
        return this._financial_Status;
    }
    public set financial_Status(value: string) {
        this._financial_Status = value;
    }
    private _type_of_Applicant: string = "A";
    public get type_of_Applicant(): string {
        return this._type_of_Applicant;
    }
    public set type_of_Applicant(value: string) {
        this._type_of_Applicant = value;
    }
    private _occupation_Status: string = "";
    public get occupation_Status(): string {
        return this._occupation_Status;
    }
    public set occupation_Status(value: string) {
        this._occupation_Status = value;
    }
    private _relation_With_Applicant: string = "";
    public get relation_With_Applicant(): string {
        return this._relation_With_Applicant;
    }
    public set relation_With_Applicant(value: string) {
        this._relation_With_Applicant = value;
    }
    private _gender: string = "";
    public get gender(): string {
        return this._gender;
    }
    public set gender(value: string) {
        this._gender = value;
    }
    private _emailId: string = "";
    public get emailId(): string {
        return this._emailId;
    }
    public set emailId(value: string) {
        this._emailId = value;
    }
    private _category: string = "";
    public get category(): string {
        return this._category;
    }
    public set category(value: string) {
        this._category = value;
    }
    private _kyC1_Type: string = "";
    public get kyC1_Type(): string {
        return this._kyC1_Type;
    }
    public set kyC1_Type(value: string) {
        this._kyC1_Type = value;
    }
    private _kyC2_Type: string = "";
    public get kyC2_Type(): string {
        return this._kyC2_Type;
    }
    public set kyC2_Type(value: string) {
        this._kyC2_Type = value;
    }
    private _kyC1_Status: string = "";
    public get kyC1_Status(): string {
        return this._kyC1_Status;
    }
    public set kyC1_Status(value: string) {
        this._kyC1_Status = value;
    }
    private _kyC2_Status: string = "";
    public get kyC2_Status(): string {
        return this._kyC2_Status;
    }
    public set kyC2_Status(value: string) {
        this._kyC2_Status = value;
    }
    private _firstName: string = "";
    public get firstName(): string {
        return this._firstName;
    }
    public set firstName(value: string) {
        this._firstName = value;
    }
    private _lastName: string = "";
    public get lastName(): string {
        return this._lastName;
    }
    public set lastName(value: string) {
        this._lastName = value;
    }
    private _dob: string = "";
    public get dob(): string {
        return this._dob;
    }
    public set dob(value: string) {
        this._dob = value;
    }
    private _address1: string = "";
    public get address1(): string {
        return this._address1;
    }
    public set address1(value: string) {
        this._address1 = value;
    }
    private _address2: string = "";
    public get address2(): string {
        return this._address2;
    }
    public set address2(value: string) {
        this._address2 = value;
    }
    private _financialStatus: string = "";
    public get financialStatus(): string {
        return this._financialStatus;
    }
    public set financialStatus(value: string) {
        this._financialStatus = value;
    }
    private _permanentAddress: string = "";
    public get permanentAddress(): string {
        return this._permanentAddress;
    }
    public set permanentAddress(value: string) {
        this._permanentAddress = value;
    }
    private _applicationNo: string = "";
    public get applicationNo(): string {
        return this._applicationNo;
    }
    public set applicationNo(value: string) {
        this._applicationNo = value;
    }
    private _pan: string = "";
    public get pan(): string {
        return this._pan;
    }
    public set pan(value: string) {
        this._pan = value;
    }
    private _kyC1_Details: string = "";
    public get kyC1_Details(): string {
        return this._kyC1_Details;
    }
    public set kyC1_Details(value: string) {
        this._kyC1_Details = value;
    }
    private _kyC2_Details: string = "";
    public get kyC2_Details(): string {
        return this._kyC2_Details;
    }
    public set kyC2_Details(value: string) {
        this._kyC2_Details = value;
    }
    private _addressProof: string = "";
    public get addressProof(): string {
        return this._addressProof;
    }
    public set addressProof(value: string) {
        this._addressProof = value;
    }
    private _IsEdit: boolean = false;
    public get IsEdit(): boolean {
        return this._IsEdit;
    }
    public set IsEdit(value: boolean) {
        this._IsEdit = value;
    }
    //Document
    private _KA1_FRONT: IUploadDocument = new UploadDocument();
    public get KA1_FRONT(): IUploadDocument {
        return (!this._KA1_FRONT || this._KA1_FRONT?.applicationNo == '') ? new UploadDocument({ applicationNo: this.applicationNo, docType: 'KA1_FRONT' } as IUploadDocument) : this._KA1_FRONT;
    }
    public set KA1_FRONT(value: IUploadDocument) {
        this._KA1_FRONT = value;
    }

    private _KA1_BACK: IUploadDocument = new UploadDocument();
    public get KA1_BACK(): IUploadDocument {
        return this._KA1_BACK ?? new UploadDocument({ applicationNo: this.applicationNo, docType: 'KA1_BACK' } as IUploadDocument);
    }
    public set KA1_BACK(value: IUploadDocument) {
        this._KA1_BACK = value;
    }

    private _KA2_FRONT: IUploadDocument = new UploadDocument();
    public get KA2_FRONT(): IUploadDocument {
        return this._KA2_FRONT ?? new UploadDocument({ applicationNo: this.applicationNo, docType: 'KA2_FRONT' } as IUploadDocument);
    }
    public set KA2_FRONT(value: IUploadDocument) {
        this._KA2_FRONT = value;
    }
    private _KA2_BACK: IUploadDocument = new UploadDocument();
    public get KA2_BACK(): IUploadDocument {
        return this._KA2_BACK ?? new UploadDocument({ applicationNo: this.applicationNo, docType: 'KA2_BACK' } as IUploadDocument);
    }
    public set KA2_BACK(value: IUploadDocument) {
        this._KA2_BACK = value;
    }

    private _PAN: IUploadDocument = new UploadDocument();
    public get PAN(): IUploadDocument {
        return this._PAN ?? new UploadDocument({ applicationNo: this.applicationNo, docType: 'PAN' } as IUploadDocument);
    }
    public set PAN(value: IUploadDocument) {
        this._PAN = value;
    }
    FORM60_file: Ifile = {} as Ifile;
    private _FORM60: IUploadDocument = new UploadDocument();
    public get FORM60(): IUploadDocument {
        if (!this._FORM60 || this._FORM60?.applicationNo == '') {

            this._FORM60 = new UploadDocument({ applicationNo: this.applicationNo, docType: 'Form60' } as IUploadDocument)
        }
        return this._FORM60;
    }
    public set FORM60(value: IUploadDocument) {
        this._FORM60 = value;
    }
    ;
    private _KYC: IUploadDocument = new UploadDocument();
    public get KYC(): IUploadDocument {
        return this._KYC ?? new UploadDocument({ applicationNo: this.applicationNo, docType: 'KYC' } as IUploadDocument);
    }
    public set KYC(value: IUploadDocument) {
        this._KYC = value;
    }
    private _HouseImg: IUploadDocument = new UploadDocument();
    public get HouseImg(): IUploadDocument {
        return this._HouseImg ?? new UploadDocument({ applicationNo: this.applicationNo, docType: 'ADDRESS_PROOF' } as IUploadDocument);
    }
    public set HouseImg(value: IUploadDocument) {
        this._HouseImg = value;
    }
    private _ApplicantImg: IUploadDocument = new UploadDocument();
    public get ApplicantImg(): IUploadDocument {
        return this._ApplicantImg ?? new UploadDocument({ applicationNo: this.applicationNo, docType: 'ApplicantImg' } as IUploadDocument);
    }
    public set ApplicantImg(value: IUploadDocument) {
        this._ApplicantImg = value;
    }
    private _documents: IUploadDocument[] = [];
    public get documents(): IUploadDocument[] {
        return this._documents;
    }
    public set documents(value: IUploadDocument[]) {
        this._documents = value;
        this.SetDocuments();
    }
    constructor(params?: any) {
        if (params) {
            common.ObjectMapping(params, this);
            this.SetDocuments();
        }
    }
    SetDocuments() {
        if (this.documents) {
            this.documents.forEach(x => {
                if (x.docType == "KA1_FRONT") {
                    this.KA1_FRONT = x;
                }
                else if (x.docType == "KA1_BACK") {
                    this.KA1_BACK = x;
                }
                else if (x.docType == "PAN") {
                    this.PAN = x;
                }
                else if (x.docType == "FORM60") {
                    this.FORM60 = x;
                }
                else if (x.docType == "KYC") {
                    this.KYC = x;
                }
                else if(x.docType == "KA2_FRONT") {
                    this.KA2_FRONT = x;
                }
                else if(x.docType == "KA2_BACK") {
                    this.KA2_BACK = x;
                }
                else if (x.docType == "ADDRESS_PROOF") {
                    this.HouseImg = x;
                }
                else if (x.docType == "Applicant") {
                    this.ApplicantImg = x;
                }
                else if (x.docType == "CoAppImg") {
                    this.ApplicantImg = x;
                }
                else if (x.docType == "SecondCoAppImg") {
                    this.ApplicantImg = x;
                }
            })
        }
    }
    toJSON(): any {
        return {
            "ApplicationNo": this.applicationNo
        };
    }

}

export interface CoAppDetail {
    applicationNo: string;
    firstName: string;
    lastName: string;
    contact_Number: string;
    address1: string;
    address2: string;
    permanent_Address: string;
    financial_Status: string;
    type_of_Applicant: string;
    occupation_Status: string;
    dob: string;
    relation_With_Applicant: string;
    gender: string;
    emailId: string;
    category?: any;
    kyC1_Details: string;
    kyC2_Details: string;
    kyC1_Type: string;
    kyC2_Type: string;
    kyC1_Status: string;
    kyC2_Status: string;
    pan: string;
    addressProof: string;
    IsEdit: boolean;
    panStatus: string;
    isForm60_Disable: boolean;
}
export interface IUploadDocument {
    docType: string;
    docRef: string;
    loanAccountNumber: string;
    applicationNo: string;
    opsCheckerVerificationStatus: string;
    opsMakerVerificationStatus: string;
    prevFormDownload: boolean;
    description: string;
    toJSON(): any;
}
export interface IOtherDocuments {
    description: string;
    doc_Ref: string;
    doc_Ref_YN: string;
    doc_Type: string;
    doc_visible?: boolean;
    disabled?: boolean;
}

export class UploadDocument implements IUploadDocument {
    private _description: string = "";
    public get description(): string {
        return this._description;
    }
    public set description(value: string) {
        this._description = value;
    }
    private _docType: string = "";
    public get docType(): string {
        return this._docType;
    }
    public set docType(value: string) {
        this._docType = value;
    }
    private _docRef: string = "";
    public get docRef(): string {
        return this._docRef;
    }
    public set docRef(value: string) {
        this._docRef = value;
    }
    private _loanAccountNumber: string = "";
    public get loanAccountNumber(): string {
        return this._loanAccountNumber;
    }
    public set loanAccountNumber(value: string) {
        this._loanAccountNumber = value;
    }
    private _applicationNo: string = "";
    public get applicationNo(): string {
        return this._applicationNo;
    }
    public set applicationNo(value: string) {
        this._applicationNo = value;
    }
    private _opsCheckerVerificationStatus: string = "";
    public get opsCheckerVerificationStatus(): string {
        return this._opsCheckerVerificationStatus;
    }
    public set opsCheckerVerificationStatus(value: string) {
        this._opsCheckerVerificationStatus = value;
    }
    private _opsMakerVerificationStatus: string = "";
    public get opsMakerVerificationStatus(): string {
        return this._opsMakerVerificationStatus;
    }
    public set opsMakerVerificationStatus(value: string) {
        this._opsMakerVerificationStatus = value;
    }
    private _prevFormDownload: boolean | undefined;
    public get prevFormDownload(): boolean {
        return this._prevFormDownload ?? false;
    }
    public set prevFormDownload(value: boolean) {
        this._prevFormDownload = value;
    }

    constructor(params?: IUploadDocument) {
        if (params) {
            common.ObjectMapping(params, this);
        }
        this.prevFormDownload = (params?.docRef && params?.docRef != '') == true;
    }

    toJSON() {
        return {
            "docType": this.docType,
            "docRef": this.docRef,
            "loanAccountNumber": this.loanAccountNumber,
            "applicationNo": this.applicationNo,
            "opsCheckerVerificationStatus": this.opsCheckerVerificationStatus,
            "opsMakerVerificationStatus": this.opsMakerVerificationStatus,
            "prevFormDownload": this.prevFormDownload,
            "description": this.description
        }
    }
}
export default interface IMaker {
    errorcode: string;
    errorDescription: string;
    applicationDetails: ApplicationDetail[];
    applicantDetails: ApplicantDetail[];
    coAppDetails: CoAppDetail[];
    CombinapplicantDetail: ApplicantDetail[];
    OpsLandDocCheckResponse: OpsLandDocCheckResponse;
    OtherDocs: IOtherDocuments[];
    reqType: string;
    loanAccountNo: string;
    flo_PSID: string;
    getPropertyRef(name: any): string;
    toJson(applicant?: ApplicantDetail, disbursment?: MakerSanctionInfo): any;
    otherAddMore(): any;
    DisbursementRequestLetter: IUploadDocument;
    LoanAgreement: IUploadDocument;
    LoanOfferLetter: IUploadDocument;
    property_insurance: IUploadDocument;
    clI_Charge: IUploadDocument;
    ROIApproval: IUploadDocument;
}

export interface IMakerSanctionInfo {
    disbAcctChange_YN: any;
    sanction_Amount: string;
    net_Disbursement_Amount: string;
    loan_Tenure: string;
    payment_Mode: string;
    account_Number: string;
    bank_name: string;
    account_Holder_Name: string;
    account_Holder_Type: string;
    account_Type: string;
    account_Category: string;
    ifsC_Code: string;
    all_BankDtl?: any;
    penny_Check_Status: string;
    penny_Fail_Reason: string;
    fuzzy_Check_Status: string;
    penny_Reverse_Feed_Name: string;
    spdC_1: IUploadDocument;
    spdC_2: IUploadDocument;
    spdC_3: IUploadDocument;
    roi: string;
    roI_Change_Approval_Ref: string;
    emI_Amount: string;
    request_Letter_For_Disbursement_Ref: string;
    property_insurance_Ref: string;
    loan_agreement_set_Ref: string;
    sanction_letter_ref: string;
    processing_Fee: string;
    application_Charge: string;
    clI_Charge: string;
    property_Insurance: string;
    applicant_Name: string;
    applicant_DOB: string;
    nominee_Name: string;
    nominee_DOB: string;
    relation_with_Nominee: string;
    bpi: string;
    mandate_Type_Selection: string;
    mandate_Registration_Response: string;
    maker_Case_Status: string;
    checker_Case_Status: string;
    hold_Status: string;
    Hold_Status_Dtl: string;
    maker_Remarks: string;
    checker_Remarks: string;
    rejection_reason: string;
    disbDate: string;
    effectiveDate: string;
    repaymentDate: string;
    spdC1_NO: string;
    spdC2_NO: string;
    spdC3_NO: string;
    modtDoc_YN: string;
    ROIChangeApproval_YN: string;
    modtDocNo: string;
    modTdate: string;
    modTplace: string;

    OPS_PropertyTitle_Ref: IUploadDocument;
    OPS_TechnicalReport_Ref: IUploadDocument;
    OPS_MutationDoc_Ref: IUploadDocument;
    OPS_MODTDoc_Ref: IUploadDocument;
    OPS_PropertyTaxReceipt: IUploadDocument;
    OPS_ChainDoc_Ref: IUploadDocument;
    OPS_OtherPropertyDoc_Ref: IUploadDocument;
    OPS_LegalReport_Ref: IUploadDocument;
    OPS_PropertyTaxReceipt_Ref: IUploadDocument;
}
export class MakerSanctionInfo implements IMakerSanctionInfo {
    disbAcctChange_YN: any = 'N';
    private _sanction_Amount: string = "";
    public get sanction_Amount(): string {
        return this._sanction_Amount;
    }
    public set sanction_Amount(value: string) {
        this._sanction_Amount = value;
    }
    private _net_Disbursement_Amount: string = "";
    public get net_Disbursement_Amount(): string {
        return this._net_Disbursement_Amount;
    }
    public set net_Disbursement_Amount(value: string) {
        this._net_Disbursement_Amount = value;
    }
    private _loan_Tenure: string = "";
    public get loan_Tenure(): string {
        return this._loan_Tenure;
    }
    public set loan_Tenure(value: string) {
        this._loan_Tenure = value;
    }
    private _payment_Mode: string = "";
    public get payment_Mode(): string {
        return this._payment_Mode;
    }
    public set payment_Mode(value: string) {
        this._payment_Mode = value;
    }
    private _account_Number: string = "";
    public get account_Number(): string {
        return this._account_Number;
    }
    public set account_Number(value: string) {
        this._account_Number = value;
    }
    private _bank_name: string = "";
    public get bank_name(): string {
        return this._bank_name;
    }
    public set bank_name(value: string) {
        this._bank_name = value;
    }
    private _account_Holder_Name: string = "";
    public get account_Holder_Name(): string {
        return this._account_Holder_Name;
    }
    public set account_Holder_Name(value: string) {
        this._account_Holder_Name = value;
    }
    private _account_Holder_Type: string = "";
    public get account_Holder_Type(): string {
        return this._account_Holder_Type;
    }
    public set account_Holder_Type(value: string) {
        this._account_Holder_Type = value;
    }
    private _account_Type: string = "";
    public get account_Type(): string {
        return this._account_Type;
    }
    public set account_Type(value: string) {
        this._account_Type = value;
    }
    private _account_Category: string = "";
    public get account_Category(): string {
        return this._account_Category;
    }
    public set account_Category(value: string) {
        this._account_Category = value;
    }
    private _ifsC_Code: string = "";
    public get ifsC_Code(): string {
        return this._ifsC_Code;
    }
    public set ifsC_Code(value: string) {
        this._ifsC_Code = value;
    }
    private _all_BankDtl?: any;
    public get all_BankDtl(): any {
        return this._all_BankDtl;
    }
    public set all_BankDtl(value: any) {
        this._all_BankDtl = value;
    }
    private _penny_Check_Status: string = "";
    public get penny_Check_Status(): string {
        return this._penny_Check_Status;
    }
    public set penny_Check_Status(value: string) {
        this._penny_Check_Status = value;
    }
    private _penny_Fail_Reason: string = "";
    public get penny_Fail_Reason(): string {
        return this._penny_Fail_Reason;
    }
    public set penny_Fail_Reason(value: string) {
        this._penny_Fail_Reason = value;
    }
    private _fuzzy_Check_Status: string = "";
    public get fuzzy_Check_Status(): string {
        return this._fuzzy_Check_Status;
    }
    public set fuzzy_Check_Status(value: string) {
        this._fuzzy_Check_Status = value;
    }
    private _penny_Reverse_Feed_Name: string = "";
    public get penny_Reverse_Feed_Name(): string {
        return this._penny_Reverse_Feed_Name;
    }
    public set penny_Reverse_Feed_Name(value: string) {
        this._penny_Reverse_Feed_Name = value;
    }
    private _spdC_1: IUploadDocument = new UploadDocument();
    public get spdC_1(): IUploadDocument {
        return this._spdC_1;
    }
    public set spdC_1(value: IUploadDocument) {
        this._spdC_1 = value;
    }
    private _spdC_2: IUploadDocument = new UploadDocument();
    public get spdC_2(): IUploadDocument {
        return this._spdC_2;
    }
    public set spdC_2(value: IUploadDocument) {
        this._spdC_2 = value;
    }
    private _spdC_3: IUploadDocument = new UploadDocument();
    public get spdC_3(): IUploadDocument {
        return this._spdC_3;
    }
    public set spdC_3(value: IUploadDocument) {
        this._spdC_3 = value;
    }
    private _roi: string = "";
    public get roi(): string {
        return this._roi;
    }
    public set roi(value: string) {
        this._roi = value;
    }
    private _roI_Change_Approval_Ref: string = "";
    public get roI_Change_Approval_Ref(): string {
        return this._roI_Change_Approval_Ref;
    }
    public set roI_Change_Approval_Ref(value: string) {
        this._roI_Change_Approval_Ref = value;
    }
    private _emI_Amount: string = "";
    public get emI_Amount(): string {
        return this._emI_Amount;
    }
    public set emI_Amount(value: string) {
        this._emI_Amount = value;
    }
    private _property_insurance_Ref: string = "";
    public get property_insurance_Ref(): string {
        return this._property_insurance_Ref;
    }
    public set property_insurance_Ref(value: string) {
        this._property_insurance_Ref = value;
    }
    private _request_Letter_For_Disbursement_Ref: string = "";
    public get request_Letter_For_Disbursement_Ref(): string {
        return this._request_Letter_For_Disbursement_Ref;
    }
    public set request_Letter_For_Disbursement_Ref(value: string) {
        this._request_Letter_For_Disbursement_Ref = value;
    }
    private _loan_agreement_set_Ref: string = "";
    public get loan_agreement_set_Ref(): string {
        return this._loan_agreement_set_Ref;
    }
    public set loan_agreement_set_Ref(value: string) {
        this._loan_agreement_set_Ref = value;
    }
    private _sanction_letter_ref: string = "";
    public get sanction_letter_ref(): string {
        return this._sanction_letter_ref;
    }
    public set sanction_letter_ref(value: string) {
        this._sanction_letter_ref = value;
    }
    private _processing_Fee: string = "";
    public get processing_Fee(): string {
        return this._processing_Fee;
    }
    public set processing_Fee(value: string) {
        this._processing_Fee = value;
    }
    _application_Charge: string = "";
    public get application_Charge() { return this._application_Charge; }
    public set application_Charge(value: any) { this._application_Charge = value; }
    _clI_Charge: string = "";
    public get clI_Charge() { return this._clI_Charge; }
    public set clI_Charge(value: any) { this._clI_Charge = value; }
    _property_Insurance: string = "";
    public get property_Insurance() { return this._property_Insurance; }
    public set property_Insurance(value: any) { this._property_Insurance = value; }
    _applicant_Name: string = "";
    public get applicant_Name() { return this._applicant_Name; }
    public set applicant_Name(value: any) { this._applicant_Name = value; }
    _applicant_DOB: string = "";
    public get applicant_DOB() { return this._applicant_DOB; }
    public set applicant_DOB(value: any) { this._applicant_DOB = value; }
    _nominee_Name: string = "";
    public get nominee_Name() { return this._nominee_Name; }
    public set nominee_Name(value: any) { this._nominee_Name = value; }
    _nominee_DOB: string = "";
    public get nominee_DOB() { return this._nominee_DOB; }
    public set nominee_DOB(value: any) { this._nominee_DOB = value; }
    _relation_with_Nominee: string = "";
    public get relation_with_Nominee() { return this._relation_with_Nominee; }
    public set relation_with_Nominee(value: any) { this._relation_with_Nominee = value; }
    _bpi: string = "";
    public get bpi() { return this._bpi; }
    public set bpi(value: any) { this._bpi = value; }
    _mandate_Type_Selection: string = "";
    public get mandate_Type_Selection() { return this._mandate_Type_Selection; }
    public set mandate_Type_Selection(value: any) { this._mandate_Type_Selection = value; }
    _mandate_Registration_Response: string = "";
    public get mandate_Registration_Response() { return this._mandate_Registration_Response; }
    public set mandate_Registration_Response(value: any) { this._mandate_Registration_Response = value; }
    _maker_Case_Status: string = "";
    public get maker_Case_Status() { return this._maker_Case_Status; }
    public set maker_Case_Status(value: any) { this._maker_Case_Status = value; }
    _checker_Case_Status: string = "";
    public get checker_Case_Status() { return this._checker_Case_Status; }
    public set checker_Case_Status(value: any) { this._checker_Case_Status = value; }
    _hold_Status: string = "";
    public get hold_Status() { return this._hold_Status; }
    public set hold_Status(value: any) { this._hold_Status = value; }
    private _Hold_Status_Dtl: string = "";
    public get Hold_Status_Dtl(): string {
        return this._Hold_Status_Dtl;
    }
    public set Hold_Status_Dtl(value: string) {
        this._Hold_Status_Dtl = value;
    }
    _maker_Remarks: string = "";
    public get maker_Remarks() { return this._maker_Remarks; }
    public set maker_Remarks(value: any) { this._maker_Remarks = value; }
    _checker_Remarks: string = "";
    public get checker_Remarks() { return this._checker_Remarks; }
    public set checker_Remarks(value: any) {
        this._checker_Remarks = value;
        if(value){
            this.rejection_reason = "";
            this.hold_Status = "";
            this.Hold_Status_Dtl = "";
        }
    }
    _rejection_reason: string = "";
    public get rejection_reason(): string {
        return this._rejection_reason;
    }
    public set rejection_reason(value: string) {
        this._rejection_reason = value;
    }

    _disbDate: string = "";
    public get disbDate() { return this._disbDate; }
    public set disbDate(value: any) { this._disbDate = value; }
    _effectiveDate: string = "";
    public get effectiveDate() { return this._effectiveDate; }
    public set effectiveDate(value: any) { this._effectiveDate = value; }
    _repaymentDate: string = "";
    public get repaymentDate() { return this._repaymentDate; }
    public set repaymentDate(value: any) { this._repaymentDate = value; }
    _spdC1_NO: string = "";
    public get spdC1_NO() { return this._spdC1_NO; }
    public set spdC1_NO(value: any) { this._spdC1_NO = value; }
    _spdC2_NO: string = "";
    public get spdC2_NO() { return this._spdC2_NO; }
    public set spdC2_NO(value: any) { this._spdC2_NO = value; }
    _spdC3_NO: string = "";
    public get spdC3_NO() { return this._spdC3_NO; }
    public set spdC3_NO(value: any) { this._spdC3_NO = value; }
    _modtDoc_YN: string = "";
    public get modtDoc_YN() { return this._modtDoc_YN; }
    public set modtDoc_YN(value: any) { this._modtDoc_YN = value; }
    private _ROIChangeApproval_YN: string = "";
    public get ROIChangeApproval_YN(): string {
        return this._ROIChangeApproval_YN;
    }
    public set ROIChangeApproval_YN(value: string) {
        this._ROIChangeApproval_YN = value;
    }
    _modtDocNo: string = "";
    public get modtDocNo() { return this._modtDocNo; }
    public set modtDocNo(value: any) { this._modtDocNo = value; }
    _modTdate: string = "";
    public get modTdate() { return this._modTdate; }
    public set modTdate(value: any) { this._modTdate = value; }
    _modTplace: string = "";
    public get modTplace() { return this._modTplace; }
    public set modTplace(value: any) { this._modTplace = value; }


    private _documents: IUploadDocument[] = [];
    public get documents(): IUploadDocument[] {
        return this._documents;
    }
    public set documents(value: IUploadDocument[]) {
        this._documents = value;

        this.SetDocuments();
    }
    constructor(params?: IMakerSanctionInfo) {
        if (params) {
            params = common.ObjectMapping(params, this);
            this.SetDocuments();
        }
    }
    private _OPS_PropertyTitle_Ref: IUploadDocument = new UploadDocument();
    public get OPS_PropertyTitle_Ref(): IUploadDocument {
        return this._OPS_PropertyTitle_Ref;
    }
    public set OPS_PropertyTitle_Ref(value: IUploadDocument) {
        this._OPS_PropertyTitle_Ref = value;
    }
    private _OPS_TechnicalReport_Ref: IUploadDocument = new UploadDocument();
    public get OPS_TechnicalReport_Ref(): IUploadDocument {
        return this._OPS_TechnicalReport_Ref;
    }
    public set OPS_TechnicalReport_Ref(value: IUploadDocument) {
        this._OPS_TechnicalReport_Ref = value;
    }
    private _OPS_MutationDoc_Ref: IUploadDocument = new UploadDocument();
    public get OPS_MutationDoc_Ref(): IUploadDocument {
        return this._OPS_MutationDoc_Ref;
    }
    public set OPS_MutationDoc_Ref(value: IUploadDocument) {
        this._OPS_MutationDoc_Ref = value;
    }
    private _OPS_MODTDoc_Ref: IUploadDocument = new UploadDocument();
    public get OPS_MODTDoc_Ref(): IUploadDocument {
        return this._OPS_MODTDoc_Ref;
    }
    public set OPS_MODTDoc_Ref(value: IUploadDocument) {
        this._OPS_MODTDoc_Ref = value;
    }
    private _OPS_PropertyTaxReceipt: IUploadDocument = new UploadDocument();
    public get OPS_PropertyTaxReceipt(): IUploadDocument {
        return this._OPS_PropertyTaxReceipt;
    }
    public set OPS_PropertyTaxReceipt(value: IUploadDocument) {
        this._OPS_PropertyTaxReceipt = value;
    }
    private _OPS_ChainDoc_Ref: IUploadDocument = new UploadDocument();
    public get OPS_ChainDoc_Ref(): IUploadDocument {
        return this._OPS_ChainDoc_Ref;
    }
    public set OPS_ChainDoc_Ref(value: IUploadDocument) {
        this._OPS_ChainDoc_Ref = value;
    }
    private _OPS_OtherPropertyDoc_Ref: IUploadDocument = new UploadDocument();
    public get OPS_OtherPropertyDoc_Ref(): IUploadDocument {
        return this._OPS_OtherPropertyDoc_Ref;
    }
    public set OPS_OtherPropertyDoc_Ref(value: IUploadDocument) {
        this._OPS_OtherPropertyDoc_Ref = value;
    }
    private _OPS_LegalReport_Ref: IUploadDocument = new UploadDocument();
    public get OPS_LegalReport_Ref(): IUploadDocument {
        return this._OPS_LegalReport_Ref;
    }
    public set OPS_LegalReport_Ref(value: IUploadDocument) {
        this._OPS_LegalReport_Ref = value;
    }
    private _OPS_PropertyTaxReceipt_Ref: IUploadDocument = new UploadDocument();
    public get OPS_PropertyTaxReceipt_Ref(): IUploadDocument {
        return this._OPS_PropertyTaxReceipt_Ref;
    }
    public set OPS_PropertyTaxReceipt_Ref(value: IUploadDocument) {
        this._OPS_PropertyTaxReceipt_Ref = value;
    }

    SetDocuments() {
        if (this.documents) {
            this.documents.forEach(x => {
                if (x.docType == "SPDC1") {
                    this.spdC_1 = x;
                }
                else if (x.docType == "SPDC2") {
                    this.spdC_2 = x;
                }
                else if (x.docType == "SPDC3") {
                    this.spdC_3 = x;
                }
                else if (x.docType == "OPS_PropertyTitle") {
                    this.OPS_PropertyTitle_Ref = x;
                }
                else if (x.docType == "OPS_TechnicalReport") {
                    this.OPS_TechnicalReport_Ref = x;
                }
                else if (x.docType == "OPS_MutationDoc") {
                    this.OPS_MutationDoc_Ref = x;
                }
                else if (x.docType == "OPS_MODTDoc") {
                    this.OPS_MODTDoc_Ref = x;
                }
                else if (x.docType == "OPS_PropertyTaxReceipt") {
                    this.OPS_PropertyTaxReceipt_Ref = x;
                }
                else if (x.docType == "OPS_ChainDoc") {
                    this.OPS_ChainDoc_Ref = x;
                }
                else if (x.docType == "OPS_LegalReport") {
                    this.OPS_LegalReport_Ref = x;
                }
            });

        }
    }

}
export interface AllBankList {
    accountNumber: string;
    bankName: string;
    accountHolderName: string;
    accountCategory: string;
    accountType: string;
    ifscCode: string;
    refnumberofstatements: string;
    account_Holder_Type: string;
}

export interface IOpsLANDisbDtl {
    errorcode: string;
    errorDescription: string;
    data: MakerSanctionInfo[];
    allBankList: AllBankList[];
    disbursementInfo: MakerSanctionInfo;
    bankList: IDropdown[];
    roiList: IDropdown[];
    ROIChange(event: any): void;
    ChangeBank(event: any): void;
    roiChanged: boolean;
}

export class OpsLANDisbDtl implements IOpsLANDisbDtl {
    roiChanged: boolean = false;
    private _roiList: any[] = [];
    public get roiList(): any[] {
        return this._roiList;
    }
    public set roiList(value: any[]) {
        this._roiList = value;
    }



    constructor(params?: IOpsLANDisbDtl) {
        if (params) {
            this.data = params.data;
            this.allBankList = params.allBankList;
            this.disbursementInfo = params.data.length > 0 ? new MakerSanctionInfo(this.data[0]) : {} as MakerSanctionInfo;
            this.bankList = params.allBankList.map(x => { return new Dropdown({ displayName: x.accountNumber }) })
            this.roiList = this.GetROIList().map(x => new Dropdown({ displayName: x.toString() }));
        }
    }
    errorcode: string = "";
    errorDescription: string = "";
    data: MakerSanctionInfo[] = [];
    allBankList: AllBankList[] = [];
    disbursementInfo: MakerSanctionInfo = new MakerSanctionInfo();
    bankList: IDropdown[] = [];
    ChangeBank(event: any) {
        let bank = this.allBankList.find(x => x.accountNumber == event);
        if (bank) {
            this.disbursementInfo.bank_name = bank.bankName;
            this.disbursementInfo.account_Number = bank.accountNumber;
            this.disbursementInfo.account_Holder_Name = bank.accountHolderName;
            this.disbursementInfo.account_Holder_Type = bank.account_Holder_Type;
            this.disbursementInfo.account_Type = bank.accountType;
            this.disbursementInfo.account_Category = bank.accountCategory;
            this.disbursementInfo.ifsC_Code = bank.ifscCode;
            this.disbursementInfo.disbAcctChange_YN = 'Y';
        }
    }
    GetROIList() {
        if (this.disbursementInfo) {
            let roi = (!this.disbursementInfo.roi || this.disbursementInfo.roi == '') ? 0 : Number(this.disbursementInfo.roi);
            return [roi, roi - 0.5, roi - 1, roi - 2]
        }
        else
            return [];
    }
    ROIChange(event: any) {
        this.roiChanged = true;
        var inretestRate = event;
        inretestRate = (inretestRate / 100) / 12;
        this.disbursementInfo.emI_Amount = common.emiCalc(inretestRate, this.disbursementInfo.loan_Tenure, 0, 0, this.disbursementInfo.sanction_Amount).toFixed(2);

    }
}

export interface OpsLandDocCheck {
    loanAccountNumber: string;
    applicationNo: string;
    leadId: string;
    docType: string;
    docTypeDescription: string;
    imageMIMEType: string;
    module: string;
    dmS_FileName: string;
    dmS_UUID: string;
    lat: string;
    lng: string;
    bankDetailID: string;
    methodName: string;
    rcuMakerVerificationStatus: string;
    rcuMakerDiscrepantReason: string;
    rcuMakerDiscrepantSubReason: string;
    rcuCheckerVerificationStatus: string;
    isDiscrepant: string;
    rcuMakerRemark: string;
    rcuCheckerRemark: string;
    opsMakerVerificationStatus: string;
    opsMakerRemarks: string;
    opsCheckerVerificationStatus: string;
    opsCheckerRemarks: string;
    rmC_Status: string;
    applicantType: string;
}

export interface IOpsLandDocCheckResponse {
    errorcode: string;
    errorDescription: string;
    opsLandDocCheck: OpsLandDocCheck[];
}

export class OpsLandDocCheckResponse implements IOpsLandDocCheckResponse {
    errorcode: string = "";
    errorDescription: string = "";
    opsLandDocCheck: OpsLandDocCheck[] = [];
    constructor(params?: IOpsLandDocCheckResponse) {
        if (params) {
            this.opsLandDocCheck = params.opsLandDocCheck.filter(x => (x.module == 'SOURCING' && x.docType == 'FORM60') == false);
        }
    }
}
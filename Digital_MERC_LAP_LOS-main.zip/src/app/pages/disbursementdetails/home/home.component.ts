import { Component, OnInit } from "@angular/core";
import { headerModel } from "src/app/shared/models/common/header-table";
import { ConfigService } from "src/app/shared/services/common/http.services";

@Component({
    selector: "app-dishome",
    templateUrl: "./home.component.html",
    styleUrls: ["./home.component.css"],
    providers: [ConfigService]
})
export class DisbursementHomeComponent {
}
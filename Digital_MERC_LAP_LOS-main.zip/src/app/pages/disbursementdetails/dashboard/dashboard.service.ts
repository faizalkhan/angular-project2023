
export interface ILoanDisbursementDetail {
    ifscCode?: any;
}
export class LoanDisbursementDetail implements ILoanDisbursementDetail {
    ifscCode?: any = "";
    constructor(params?: ILoanDisbursementDetail) {
        if (params) {
            this.ifscCode = params.ifscCode;
        }
    }
}
export interface IApplicationBankingDetail {
    loanDisbursementDetail: ILoanDisbursementDetail;
}
export class ApplicationBankingDetail implements IApplicationBankingDetail {
    loanDisbursementDetail: ILoanDisbursementDetail = new LoanDisbursementDetail();
    constructor(params?: IApplicationBankingDetail) {
        if (params) {
            this.loanDisbursementDetail = new LoanDisbursementDetail(params.loanDisbursementDetail);
        }
    }
}
export interface ICamDetail {
    applicationBankingDetail: IApplicationBankingDetail;
    toJson(): any;
}
export class CamDetail implements ICamDetail {
    applicationBankingDetail: IApplicationBankingDetail = new ApplicationBankingDetail();
    constructor(params?: ICamDetail) {
        if (params) {
            this.applicationBankingDetail = params.applicationBankingDetail;
        }
    }
    toJson() {
    }
}


//khushboo code
export interface IAddresses {
    applicationNo: string;
    address1: string;
    address2: string;
}
export class Addresses implements IAddresses {
    applicationNo: any = "";
    address1: any = "";
    address2: any = "";
    constructor(params?: IAddresses) {
        if (params) {
            this.applicationNo = params.applicationNo;
            this.address1 = params.address1;
            this.address2 = params.address2;
        }
    }
}
export interface IDocs {
    applicationNo: string;
    docType: string;
    opsCheckerVerificationStatus: string;
    opsMakerVerificationStatus: string;
}
export class Docs implements IDocs {
    applicationNo: any = "";
    docType: any = "";
    opsCheckerVerificationStatus: any = "";
    opsMakerVerificationStatus: any = "";
    constructor(params?: IDocs) {
        if (params) {
            this.applicationNo = params.applicationNo;
            this.docType = params.docType;
            this.opsCheckerVerificationStatus = params.opsCheckerVerificationStatus;
            this.opsMakerVerificationStatus = params.opsMakerVerificationStatus;
        }
    }
}
export interface IAgreementDetails {
  reqType: any;
  loanAccountNumber: string;
  applicationNo: string;
  modtDoc_YN: string;
  modtDocNo: string;
  modTdate: string;
  modTplace: string;
  disbAcctChange_YN: string;
  opsDisbAcct: string;
  spdC1_YN: string;
  spdC2_YN: string;
  spdC3_YN: string;
  roi: string;
  roiChangeApproval_YN: string;
  custL_Disbursement_YN: string;
  loan_agreement_set_YN: string;
  sanction_letter_YN: string;
  mandate_Type: string;
  maker_Case_Status: string;
  checker_Case_Status: string;
  hold_Status: string;
  maker_Remarks: string;
  checker_Remarks: string;
  flO_PsId: string;
  propertTitleDoc_YN: string;
  technicalRpt_YN: string;
  mutuation_YN: string;
  propTaxRecpt_YN: string;
  chainDoc_YN: string;
  otherPropDoc_YN: string;
  legalRpt_YN: string;
  bankAccountNumber: string;
  bankName: string;
  account_Holder_Type: string;
  bankAccountHolderName: string;
  account_Type: string;
  ifscCode: string;
  nomineeName: string;
  nomineeDOB: string;
  relWithNominee: string;
  updateAddress: IAddresses[];
  updateKycDocs: IDocs[];
}
export class AgreementDetails implements IAgreementDetails {
    reqType: any = "";
    loanAccountNumber: any = "";
    applicationNo: any = "";
    modtDoc_YN: any = "";
    modtDocNo: any = "";
    modTdate: any = "";
    modTplace: any = "";
    disbAcctChange_YN: any = "";
    opsDisbAcct: any = "";
    spdC1_YN: any = "";
    spdC2_YN: any = "";
    spdC3_YN: any = "";
    roi: any = "";
    roiChangeApproval_YN: any = "";
    custL_Disbursement_YN: any = "";
    loan_agreement_set_YN: any = "";
    sanction_letter_YN: any = "";
    mandate_Type: any = "";
    maker_Case_Status: any = "";
    checker_Case_Status: any = "";
    hold_Status: any = "";
    maker_Remarks: any = "";
    checker_Remarks: any = "";
    flO_PsId: any = "";
    propertTitleDoc_YN: any = "";
    technicalRpt_YN: any = "";
    mutuation_YN: any = "";
    propTaxRecpt_YN: any = "";
    chainDoc_YN: any = "";
    otherPropDoc_YN: any = "";
    legalRpt_YN: any = "";
    bankAccountNumber: any = "";
    bankName: any = "";
    account_Holder_Type: any = "";
    bankAccountHolderName: any = "";
    account_Type: any = "";
    ifscCode: any = "";
    nomineeName: any = "";
    nomineeDOB: any = "";
    relWithNominee: any = "";
    updateAddress: IAddresses[] = [new Addresses()];
    updateKycDocs: IDocs[] = [new Docs()];
    constructor(params?: IAgreementDetails) {
        if(params) {
            this.loanAccountNumber = params.loanAccountNumber;
        }
    }
}

export interface CoApplicant {
    name: string;
}

export interface OpsAgreement {
    loanAccountNumber: string;
    name: string;
    state: string;
    mcCode: string;
    mC_Name: string;
    mobileno: string;
    triggeredDate: string;
    ageing: string;
    category: string;
    coApplicants: CoApplicant[];
    leadId: string;
    caseStatus:string;
}

export interface OpsAgrementResonse {
    errorcode: string;
    errorDescription: string;
    data: OpsAgreement[];
}

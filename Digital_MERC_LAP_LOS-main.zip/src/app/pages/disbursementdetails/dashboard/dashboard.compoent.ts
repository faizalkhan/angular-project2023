import { Component, OnInit, Output, EventEmitter, Input } from "@angular/core";
import { headerModel } from "src/app/shared/models/common/header-table";
import { ConfigService } from "src/app/shared/services/common/http.services";
import { AgreementDetails, CamDetail, IAgreementDetails, ICamDetail, OpsAgrementResonse } from "./dashboard.service";
import { requestmodel } from "src/app/shared/models/sanction/request.model";
import { FileUpload, IfileUpload, Ifile, UploadViewDownloadService } from "../../layout/button/upload-view-download/upload-view-download.service";
import { NotificationService } from "src/app/notification.service";
import { Observable, ReplaySubject } from "rxjs";
import { InfoServices } from "src/app/Injectable/info.services";
import { IModalCommon, ModalCommon, ModalService } from "src/app/shared/services/modal/modal.service";
import { Router } from "@angular/router";
import { SanctionService } from "src/app/shared/services/sanction/sanction.service";
import { SearchService } from "src/app/shared/services/search/search.service";
import { ISearch } from "src/app/shared/models/sanction/search/search";

@Component({
  selector: "app-disdash",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.css"],
  providers: [ConfigService]
})
export class DisbursementPDashComponent implements OnInit {
  _CamDetail: ICamDetail = new CamDetail();
  title1: any = "Pending For Screening Dashboard"
  isDashboard: Boolean = true;
  public nullData: boolean = true;
  page: number = 1;
  PerPage: number = 5;
  private _header: any[] = [];
  private _data: any[] = [];
  public LoanAccountNumber: any;

  public get Data(): any[] {
    return this._data;
  }
  public set Data(value: any[]) {
    this._data = value;
  }

  public get Header(): any[] {
    return this._header;
  }
  public set Header(value: any[]) {
    this._header = value;
  }
  currentDateTime: any = new Date();
  constructor(private http: ConfigService,
    private route: Router,
    private sanctionService: SanctionService,
    private infoService: InfoServices,
    private _searchService: SearchService) {
  }

  row_click(event: string): void {
    this.isDashboard = false;
    this.LoanAccountNumber = event;
    this.infoService.setItem("disbInfo", JSON.stringify(event));
    if (this.sanctionService.userInfo.roleName.toUpperCase() == 'OPS MAKER') {
      this.route.navigateByUrl('/maker');
    }
    else if (this.sanctionService.userInfo.roleName.toUpperCase() == 'OPS CHK') {
      this.route.navigateByUrl('/checker');
    }
    else {
      this.route.navigateByUrl('/login');
    }
  }

  getDashboardlist(request:any): any { 
   
      return this.http.httpPost<OpsAgrementResonse>(request.OpsDashboardtoJSON(), 'GetLAP_OpsAgreementList').subscribe((res: OpsAgrementResonse) => {
        if (res?.data == null) {
          this.nullData = true;
          this.isDashboard = true;
        }
        else {
          this.Data = res.data ?? res.data;
          this.nullData = false;
          this.isDashboard = true;
        }
      });
    } 
  

  ngOnInit(): void {
    this._header = [
      new headerModel('lannumber', 'Lan no.'),
      new headerModel('applicantname', 'Name'),
      new headerModel('coapplicant', 'Co-Applicants'),
      new headerModel('state', 'State'),
      new headerModel('mccode', 'MC Code'),
      new headerModel('mcname', 'MC Name'),
      new headerModel('mobilenumber', 'Mobile Number of Applicant'),
      new headerModel('triggereddate', 'Triggered Date'),
      new headerModel('ageing', 'Ageing'),
      new headerModel('CaseStatus', 'Status'),
    ]; 
    const request = new requestmodel();
    if (!this._searchService.SearchData.observed) {
 
      this._searchService.SearchData.subscribe((res: ISearch) => { 
        request.FromDate = res.fromDate.toString();
        request.ToDate = res.toDate.toString();;
        request.FLO_PsId = res.login_PS_ID;
        request.RoleName = this.sanctionService.userInfo.roleName.toUpperCase();
        request.CaseType = "";
        request.FieldName = res.fieldName;
        request.FieldValue = res.fieldValue;
        this.getDashboardlist(request);
      });  
     
    }else{
      request.FromDate ="";
      request.ToDate = "";
      request.FLO_PsId = this.sanctionService.userInfo.userId;
      request.RoleName = this.sanctionService.userInfo.roleName.toUpperCase();
      request.CaseType = "";
      request.FieldName = "";
      request.FieldValue = "";
      this.getDashboardlist(request);
    }
  }
  getCoApplicantName(event: any) { 
      return event.coApplicants.map((x:any) => x.name).join(',');
    
  }
}
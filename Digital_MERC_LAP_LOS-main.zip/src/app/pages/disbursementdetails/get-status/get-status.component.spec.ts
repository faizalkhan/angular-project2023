import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetStatusComponent } from './get-status.component';

describe('GetStatusComponent', () => {
  let component: GetStatusComponent;
  let fixture: ComponentFixture<GetStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetStatusComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

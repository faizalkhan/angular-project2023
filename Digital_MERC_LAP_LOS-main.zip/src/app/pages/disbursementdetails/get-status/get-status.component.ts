import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-status',
  templateUrl: './get-status.component.html',
  styleUrls: ['./get-status.component.css']
})
export class GetStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { InfoServices } from 'src/app/Injectable/info.services';
import { NotificationService } from 'src/app/notification.service';
import { IDropdown } from 'src/app/shared/models/common/control.model';
import { IresponseModel } from 'src/app/shared/models/common/response.model';
import { masterModuleDropdown } from 'src/app/shared/models/sanction/masterDropdown';
import { requestmodel } from 'src/app/shared/models/sanction/request.model';
import { ConfigService } from 'src/app/shared/services/common/http.services';
import { IModalCommon, ModalCommon, ModalService } from 'src/app/shared/services/modal/modal.service';
import { SanctionService } from 'src/app/shared/services/sanction/sanction.service';
import { FileUpload, IfileUpload, UploadViewDownloadService, Ifile } from '../../layout/button/upload-view-download/upload-view-download.service';
import { IInterActionDetail, InterActionDetail } from '../../riskcontrolunit/RCU.Model';
import { OpsAgreement } from '../dashboard/dashboard.service';
import IMaker, { IOpsLandDocCheckResponse, IOpsLANDisbDtl, IUploadDocument, MakersDetails, OpsLandDocCheckResponse, OpsLANDisbDtl } from '../makers/makers.service';

@Component({
  selector: 'app-makers',
  templateUrl: './checker.component.html',
  styleUrls: ['./checker.component.css']
})
export class CheckerComponent implements OnInit {
  maker: IMaker = new MakersDetails();
  disbursementdetail: IOpsLANDisbDtl = new OpsLANDisbDtl();
  bankEdit: boolean = false;
  isNachEnable: boolean=false;
  physicalstatusshow: boolean = false;
  isEnable: boolean = false;
  RejectNach:any;
  propertyEdit: boolean = false;
  disbInfo!: OpsAgreement;
  isdisabledAddiCharges: boolean = false;
  PropValue: boolean = false;
  Generatelinkvalue: boolean = false;
  statusshow: boolean = false;
  errstatusshow: boolean = false;
  Generetelinks: boolean = false;
  IsDisb_Portal: boolean = false;
  checkersQueryReason: any;
  userName: any = "Test01";
  psId: any = "500836";
  LandDocCheckResponse: IOpsLandDocCheckResponse = new OpsLandDocCheckResponse();
  holdRemarks: IDropdown[] = masterModuleDropdown.Ops_Remarks;
  Conditional: IDropdown[] = masterModuleDropdown.Conditional;
  private _rcuQueriesModel: InterActionDetail[] = [];
  hideEdit:boolean=true;
  isSendBackDtl: boolean = false;
  bankDetails: any;
  public get rcuQueriesModel(): InterActionDetail[]{
    return this._rcuQueriesModel;
  }

  public set rcuQueriesModel(value: InterActionDetail[]) {
    this._rcuQueriesModel =value ;
  } 
  constructor(private http: ConfigService, private downloadUpload: UploadViewDownloadService, private modal: ModalService, private _notification: NotificationService, private info: InfoServices, private sanction: SanctionService,
    private datePipe: DatePipe) { }

  getAppDetails(): any {
    const request = new requestmodel();
    request.LoanAccountNumber = this.disbInfo.loanAccountNumber;
    request.CreatedON = "2022-10-05";
    request.FLO_PsId = "50008860";
    request.RoleName = "FLO"
    return this.http.httpPost(request.OpsApptoJSON(), 'GetOpsAgreementDtl')
  }
  getOpsLanDocCheckResponse(): any {
    const request = new requestmodel();
    request.LoanAccountNumber = this.disbInfo.loanAccountNumber;
    return this.http.httpPost(request.OpsLanDoctoJSON(), 'LAP_OpsLandDocCheckResponse')
  }
  getOpsLANDisbDtl(): any {
    const request = new requestmodel();
    request.LoanAccountNumber = this.disbInfo.loanAccountNumber;
    request.CreatedON = "2022-09-13";
    request.FLO_PsId = "20133106";
    request.RoleName = "BCM"
    return this.http.httpPost(request.OpsValtoJSON(), 'GetOpsLANDisbDtl')
  }
  getAgreementList(): any {
    const current = new Date();     
    let fromDate:any = new Date(new Date().setDate(current.getDate() - 150));
    let fromDateNew:any = this.datePipe.transform(fromDate, 'yyyy-MM-dd')?.toString();
    let toDate:any = this.datePipe.transform(current, 'yyyy-MM-dd');
    const request = new requestmodel();
    request.FromDate = fromDateNew;
    request.ToDate = toDate;
    request.FLO_PsId = this.sanction.userInfo.userId;
    request.RoleName = this.sanction.userInfo.roleName;
    request.CaseType = "";
    request.FieldName = "LAN";
    request.FieldValue = this.disbInfo.loanAccountNumber;
    return this.http.httpPost(request.OpsDashboardtoJSON(), 'GetLAP_OpsAgreementList');
  }
  ngOnInit(): void {
    this.disbInfo = JSON.parse(this.info.getItem('disbInfo'));
    this.EnableDisableControls();

    this.getAgreementList().subscribe((res:any) => {
      console.log(res);
      if((res.data[0].caseStatus == "Completed") || (res.data[0].caseStatus == "Rejected") || (res.data[0].caseStatus == "Sent back to Maker")) {
        this.hideEdit = false;
      }
    });

    this.downloadUpload.uploadLoad = new FileUpload({
      flO_Id: this.sanction.LanInfo.flopsid,
      loanAccountNumber: this.disbInfo.loanAccountNumber,
      applicationNo: "",
      leadID: this.disbInfo.leadId,
      moduleName: "OPS_Makers",

    } as IfileUpload);
    this.getAppDetails().subscribe((res: IMaker) => {
      if (res.errorcode == "00") {
        this.maker = new MakersDetails(res);
        this.maker.loanAccountNo = this.disbInfo.loanAccountNumber;
        this.maker.flo_PSID = this.sanction.LanInfo.flopsid;
        this.maker.CombinapplicantDetail.forEach(x => {



        });
        this.getOpsLanDocCheckResponse().subscribe((res: any) => {
          if (res.errorcode == "00") {
            this.maker.OpsLandDocCheckResponse = new OpsLandDocCheckResponse(res);

          }
          else {
            this.maker.OpsLandDocCheckResponse = new OpsLandDocCheckResponse();
          }
          this.getOpsLANDisbDtl().subscribe((resOpsLANDisbDtl: OpsLANDisbDtl) => {
            if (resOpsLANDisbDtl.errorcode == "00") {

              this.disbursementdetail = new OpsLANDisbDtl(resOpsLANDisbDtl);
              this.bankDetails = this.disbursementdetail.allBankList.filter(x => x.accountNumber == this.disbursementdetail.disbursementInfo.account_Number);
              this.disbursementdetail.disbursementInfo.documents = res.opsLandDocCheck.map((x:any) => { return { applicationNo: x.applicationNo, loanAccountNumber: x.loanAccountNumber, docRef: x.dmS_UUID, docType: x.docType, opsMakerVerificationStatus: x.opsMakerVerificationStatus, opsCheckerVerificationStatus: x.opsCheckerVerificationStatus } as IUploadDocument })
              if(this.disbursementdetail.disbursementInfo.hold_Status == "Others") {
                this.isSendBackDtl = true;
              } else {
                this.isSendBackDtl = false;
              }
            }
          });
          
        });
        if(this.maker.applicationDetails[0].match=='Y'){
          this.isEnable=false;
          this.physicalstatusshow=true;
        }
        if(this.maker.applicationDetails[0].errorReason=='submitted'){
          this.isNachEnable=false;
          this.statusshow=true;
          this.RejectNach="";
        }
        else if(this.maker.applicationDetails[0].errorReason=='pending'){
         
          this.isNachEnable=true;
          this.errstatusshow=true;
          this.RejectNach=this.maker.applicationDetails[0].errorReason;
        }
      }
      else {
        this.maker = new MakersDetails();
      }
    });

    var queriesParam ={
      "LoanAccountNumber" : this.disbInfo.loanAccountNumber,
      "Source":"OPS"
    }

   // if(this.roleId==="ARM" && this.SelectedRow.subStage==="Postsanction"){
      this.getQueries(queriesParam);
    //}

  }

  EnableDisableControls(){ 
   
    if(this.disbInfo.caseStatus==="Completed" || this.disbInfo.caseStatus==="Rejected" 
      || this.disbInfo.caseStatus==="Sent back to Maker" || this.maker.reqType==="C_Approved"
      || this.maker.reqType==="CRejected" || this.maker.reqType==="SentbackToMaker" || this.maker.reqType==="Hold"){
        this.hideEdit=false;
        this.isNachEnable=false; 
        this.isEnable=false;
        this.propertyEdit=false;
        this.bankEdit=false;
        this.IsDisb_Portal=false;
        this.isdisabledAddiCharges=false;
    }
  }

  getQueries(param:any) {
    this.http.httpPost<IresponseModel<InterActionDetail[]>>(param, 'GetOpsCreditInteractionDtl').subscribe((res: IresponseModel<InterActionDetail[]>) => { 
        if( res!==null){ 
          this._notification.showSuccess("Queries retrived successfully", "Application"); 
          this.rcuQueriesModel = res.creditInteractionDtl.map((x: IInterActionDetail) => {
            return new InterActionDetail(x);
        });  
         
        } else{
          this._notification.showError("Something went wrong", "Application");
        }
      });
    }

  submit(ReqType: any, item: any, dis: any) {
    this.maker.reqType = ReqType;
    this.http.httpPost<IresponseModel<any>>(this.maker.toJson(item, dis), 'LAP_OpsSubmitAgreementDtl').subscribe((res: IresponseModel<any>) => {
      if (res.errorcode == "00") {
        this._notification.showSuccess(res.errorDescription);
        this.ngOnInit();

       

      }
      else {
        this._notification.showError(res.errorDescription);
      }
    })
  }

  onSendBackReason(event: any) {
    if(event == "Others") {
        this.isSendBackDtl = true;
    } else {
      this.isSendBackDtl = false;
    }
  }

  FinalSave(a: any, msg: any) { 
    this.maker.reqType = a;
    if(this.FinalSaveValidation()) {
      let Action: Function = () => {
        this.http.httpPost<IresponseModel<any>>(this.maker.toJson(undefined, this.disbursementdetail.disbursementInfo), 'LAP_OpsSubmitAgreementDtl').subscribe((res: IresponseModel<any>) => {
          if (res.errorcode == "00") {
            this._notification.showSuccess(res.errorDescription);
            this.ngOnInit();
          }
          else {
            this._notification.showError(res.errorDescription);
          }
        })
      }

      let modal = new ModalCommon({
        title: "Confirmation",
        message: `Are you sure you want to ${msg}? Please confirm to proceed.?`,
        sAction: Action,
        sActionText: 'Confirm',
        sActionShow: true
      } as IModalCommon);

      this.modal.ShowModal(modal);
    }
  }

  FinalSaveValidation() {
    if((this.maker.reqType == "C_Approved") && (!this.disbursementdetail.disbursementInfo.checker_Remarks || this.disbursementdetail.disbursementInfo.checker_Remarks == '')) {
      this._notification.showWarning('Remark is required');
      return false;
    }
    else if((this.maker.reqType == "CRejected") && (!this.disbursementdetail.disbursementInfo.rejection_reason || this.disbursementdetail.disbursementInfo.rejection_reason == '')) {
      this._notification.showWarning('Rejection reason is required');
      return false;
    }
    else if((this.maker.reqType == "SentbackToMaker") && (!this.disbursementdetail.disbursementInfo.hold_Status || this.disbursementdetail.disbursementInfo.hold_Status == '')) {
      this._notification.showWarning('Send Back Reason is required');
      return false;
    }
    else if((this.disbursementdetail.disbursementInfo.hold_Status == "Others") && (!this.disbursementdetail.disbursementInfo.Hold_Status_Dtl || this.disbursementdetail.disbursementInfo.Hold_Status_Dtl == '')) {
      this._notification.showWarning('Send Back Details is required');
      return false;
    } 
    return true;
  }

}

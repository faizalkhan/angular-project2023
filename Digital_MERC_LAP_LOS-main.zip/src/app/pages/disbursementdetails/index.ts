import { CustomRouteConfig } from "src/app/shared/models/common/route-config";
import { DisbursementPDashComponent } from "src/app/pages/disbursementdetails/dashboard/dashboard.compoent";
import { DisbursementHomeComponent } from "src/app/pages/disbursementdetails/home/home.component"; 
import { RegisterEnachComponent } from "src/app/pages/disbursementdetails/register-enach/register-enach.component";
import { GenereteLinkComponent } from "./generete-link/generete-link.component";
import { GetStatusComponent } from "./get-status/get-status.component";
import { MakersComponent } from "./makers/makers.component";
import { CheckerComponent } from "./checker/checker.component";
import { RMCDocumentComponent } from "../rmcdocument/rmc-pending/rmc.component";
// import {RegisterEnachComponent } from "src/app/pages/disbursementdetails/register-enach/register-enach.component";

export const DisbursementDetailsModule = [DisbursementPDashComponent, RMCDocumentComponent, DisbursementHomeComponent, RegisterEnachComponent, GenereteLinkComponent, GetStatusComponent,MakersComponent,CheckerComponent]
export const DisbursementDetailsRoute: CustomRouteConfig[] = [];

DisbursementDetailsRoute.push(new CustomRouteConfig({ menuName: "Disbursement Details", componentName: DisbursementHomeComponent, title: "Disbursement Details", path: "dishome", redirectTo: "/dishome" }))

//DisbursementDetailsRoute.push(new CustomRouteConfig({ path: "disbursementdash", componentName: DisbursementPDashComponent, title: "Disbursement Details / Dashboard", parentName: "Disbursement Details" }));
//child menu
DisbursementDetailsRoute.push(new CustomRouteConfig({ path: "dishome", componentName: DisbursementHomeComponent, title: "Disbursement Details / Home", parentName: "Disbursement Details", menuName: "Home" }));
DisbursementDetailsRoute.push(new CustomRouteConfig({ path: "disback", title: "Disbursement Details / Back", parentName: "Disbursement Details", redirectTo: "/dishome", menuName: "Back" }));
DisbursementDetailsRoute.push(new CustomRouteConfig({ path: "dispendingforaction", componentName: DisbursementPDashComponent, title: "Disbursement Details / PendingforAction", parentName: "Disbursement Details", menuName: "Pending For Action" }));
// DisbursementDetailsRoute.push(new CustomRouteConfig({ path: "disrmcdocument", componentName: RMCDocumentComponent, title: "Disbursement Details / RMCDocuments", parentName: "Disbursement Details", menuName: "RMC Documents" }));
DisbursementDetailsRoute.push(new CustomRouteConfig({ path: "maker", componentName: MakersComponent, title: "Disbursement Details / Marker", parentName: "Disbursement Details" }));
DisbursementDetailsRoute.push(new CustomRouteConfig({ path: "checker", componentName: CheckerComponent, title: "Disbursement Details / checker", parentName: "Disbursement Details" }));
//DisbursementDetailsRoute.push(new CustomRouteConfig({ path: "disrmcdocument", componentName: RMCDocumentComponent, title: "Disbursement Details / RMCDocuments", parentName: "Disbursement Details", menuName: "RMC Documents" }));

// DisbursementDetailsRoute.push(new CustomRouteConfig({ path: "registerenach",componentName:RegisterEnachComponent, title: "Disbursement Details / RegisterEnach", parentName: "Disbursement Details",menuName: "Register Enach" }));
// DisbursementDetailsRoute.push(new CustomRouteConfig({ path: "generatelink",componentName:GenereteLinkComponent, title: "Disbursement Details / GenerateLink", parentName: "Disbursement Details",menuName: "Generate Link" }));
// DisbursementDetailsRoute.push(new CustomRouteConfig({ path: "getstatus",componentName:GetStatusComponent, title: "Disbursement Details / GetStatus", parentName: "Disbursement Details",menuName: "Get Status" }));






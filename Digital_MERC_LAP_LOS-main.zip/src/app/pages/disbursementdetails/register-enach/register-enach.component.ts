import { Component, OnInit } from '@angular/core';
import { ConfigService } from "src/app/shared/services/common/http.services";

@Component({
  selector: 'app-register-enach',
  templateUrl: './register-enach.component.html',
  styleUrls: ['./register-enach.component.css']
})
export class RegisterEnachComponent implements OnInit {

  constructor(private http: ConfigService) { }

  ngOnInit(): void {
    this.RegisterEnach();
  }

  RegisterEnach() {
    var data = {
      
        "type": "nach_debit",
        "nach_debit": {
            "amount_maximum": "600400",
            "category_code": "L001",
            "creditor_agent_code": "SCBL",
            "creditor_utility_code": "HDFC01436000011490",
            "date_first_collection": "2022-11-03",
            "debtor_account_name": "RJ Jain",
            "debtor_account_number": "123450006789876",
            "debtor_account_type": "savings",
            "debtor_agent_code": "HDFC",
            "debtor_email": "rajat.jain@ltfs.com",
            "debtor_mobile": "8793769263",
            "debtor_phone": "8793769263",
            "frequency": "MNTH",
            "reference1": "T15703050820010642",
            "reference2": ""
        
    }
    }

    this.http.httpPost<any>(data, 'sources').subscribe((res: any) => {
       
    })
}

}

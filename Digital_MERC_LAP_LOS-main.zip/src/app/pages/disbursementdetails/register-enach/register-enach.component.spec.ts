import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterEnachComponent } from './register-enach.component';

describe('RegisterEnachComponent', () => {
  let component: RegisterEnachComponent;
  let fixture: ComponentFixture<RegisterEnachComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisterEnachComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RegisterEnachComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GenereteLinkComponent } from './generete-link.component';

describe('GenereteLinkComponent', () => {
  let component: GenereteLinkComponent;
  let fixture: ComponentFixture<GenereteLinkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GenereteLinkComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GenereteLinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

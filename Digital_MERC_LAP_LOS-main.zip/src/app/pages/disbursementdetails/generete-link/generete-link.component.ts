import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-generete-link',
  templateUrl: './generete-link.component.html',
  styleUrls: ['./generete-link.component.css']
})
export class GenereteLinkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import * as CryptoJS from 'crypto-js'
import { CookieOptions, CookieService, SameSite } from "ngx-cookie-service"
import { Subject } from "rxjs";
@Injectable({
    providedIn: 'root'
})
export class InfoServices {
    options!: CookieOptions;
    private _currentEdit: any;
    public get currentEdit(): any {
        return this._currentEdit;
    }
    public set currentEdit(value: any) {
        this._currentEdit = value;
    }
    private _loginService = new Subject<boolean>();
    public get loginService() {
        return this._loginService.asObservable();
    }

    constructor(private _cookieService: CookieService) {

    }
    ClearCurrentEdit() {
        this.currentEdit = {} as any;
    }
    IsLogin(value: boolean) {
        this._loginService.next(value);
    }
    checkCookie(name: string): boolean {
        return this._cookieService.check(name);
    }
    getCookie(name: string): string {
        return this.decrypt(this._cookieService.get(name));
    }
    setCookie(name: string, value: string): void {
        this._cookieService.set(name, this.encrypt(value), this.options);
    }
    deleteCookie(name: string): void {
        this._cookieService.delete(name);
    }
    public IsItem(name: any): boolean {
        return this.getItem(name) != '';
    }
    public getItem(name: any): any {
        var val = localStorage.getItem(name);
        if (val != null)
            return this.decrypt(val);
        else
            return '';
    }
    public setItem(name: any, value: any) {
        if (typeof value == 'boolean') {
            debugger;
        }
        return localStorage.setItem(name, this.encrypt(value));
    }
    public removeItem(key: string) {
        localStorage.removeItem(key);
    }
    public Clear() {
        localStorage.clear();
    }
    private encrypt(txt: string): string {
        return CryptoJS.AES.encrypt(txt, environment.AES_ENCRYPTION_KEY).toString();
    }
    private decrypt(txtToDecrypt: string) {
        return CryptoJS.AES.decrypt(txtToDecrypt, environment.AES_ENCRYPTION_KEY).toString(CryptoJS.enc.Utf8);
    }

}
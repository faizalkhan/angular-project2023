import { RemarkReasonService } from "src/app/pages/riskcontrolunit/RCU.service";
import { LegalTechnicalService } from "src/app/pages/sanction/Common/Legal-Technical.service";
import { ConfigService } from "./common/http.services";
import { ModalService } from "./modal/modal.service";
import { SanctionService } from "./sanction/sanction.service";
import { SearchService } from "./search/search.service";

export const ServiceModule = [SearchService, ConfigService,ModalService,SanctionService,RemarkReasonService,LegalTechnicalService]
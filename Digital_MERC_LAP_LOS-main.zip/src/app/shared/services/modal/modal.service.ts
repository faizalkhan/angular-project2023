import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { Ifile } from 'src/app/pages/layout/button/upload-view-download/upload-view-download.service';
import { common } from '../../models/common';

@Injectable({
  providedIn: 'root'
})
export class ModalService {
  data: Subject<IModalCommon> = new Subject<IModalCommon>();
  get Data(): Observable<IModalCommon> {
    return this.data.asObservable();
  }
  constructor() { }

  ShowModal(Modal: IModalCommon) {
    this.data.next(Modal);
  }

}

export interface IModalCommon {
  title: string;
  message: string;
  sAction: Function;
  cAction: Function;
  sActionShow: boolean;
  cActionShow: boolean;
  cssClass: string;
  file: Ifile;
  fileObject: any;
  sActionText: any;
  AdditionalButtonShow: boolean;
  AdditionalButtonText: string;
  AdditionalButtonAction: Function;
}

export class ModalCommon implements IModalCommon {
  private _title: string = "";
  public get title(): string {
    return this._title;
  }
  public set title(value: string) {
    this._title = value;
  }
  private _message: string = "";
  public get message(): string {
    return this._message;
  }
  public set message(value: string) {
    this._message = value;
  }
  private _file: Ifile = {} as Ifile;
  public get file(): Ifile {
    return this._file;
  }
  public set file(value: Ifile) {
    this._file = value;
  }
  get fileObject(): any {
    return `data:${this.file.format};base64;${this.file.file}`

  }
  private _sActionText: any = "Save Changes";
  public get sActionText(): any {
    return this._sActionText;
  }
  public set sActionText(value: any) {
    this._sActionText = value;
  }
  private _sAction: Function = (event: any) => {
  };
  public get sAction(): Function {
    return this._sAction;
  }
  public set sAction(value: Function) {
    this._sAction = value;
  }
  private _cAction: Function = (event: any) => {
  };
  public get cAction(): Function {
    return this._cAction;
  }
  public set cAction(value: Function) {
    this._cAction = value;
  }
  private _sActionShow: boolean = false;
  public get sActionShow(): boolean {
    return this._sActionShow;
  }
  public set sActionShow(value: boolean) {
    this._sActionShow = value;
  }
  private _cActionShow: boolean = false;
  public get cActionShow(): boolean {
    return this._cActionShow;
  }
  public set cActionShow(value: boolean) {
    this._cActionShow = value;
  }
  private _cssClass: string = "modal-dialog-centered modal-sm";
  public get cssClass(): string {
    return this._cssClass;
  }
  public set cssClass(value: string) {
    this._cssClass = value;
  }

  //Additional Button
  private _AdditionalButtonShow: boolean = false;
  public get AdditionalButtonShow(): boolean {
    return this._AdditionalButtonShow;
  }
  public set AdditionalButtonShow(value: boolean) {
    this._AdditionalButtonShow = value;
  }
  private _AdditionalButtonText: string = "";
  public get AdditionalButtonText(): string {
    return this._AdditionalButtonText;
  }
  public set AdditionalButtonText(value: string) {
    this._AdditionalButtonText = value;
  }
  private _AdditionalButtonAction: Function = (event: any) => {
  };
  public get AdditionalButtonAction(): Function {
    return this._AdditionalButtonAction;
  }
  public set AdditionalButtonAction(value: Function) {
    this._AdditionalButtonAction = value;
  }
  constructor(params?: IModalCommon) {
    if (params) {
      common.ObjectMapping(params, this);
    }

  }

}

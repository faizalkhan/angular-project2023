import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { InfoServices } from 'src/app/Injectable/info.services';
import { OpsLandDocCheck, OpsLandDocCheckResponse } from 'src/app/pages/disbursementdetails/makers/makers.service';
import { MenuUserDetail } from 'src/app/pages/layout/login/login.service';
import { read } from 'xlsx';
import { IDropdown } from '../../models/common/control.model';
import { IresponseModel } from '../../models/common/response.model';
import { ISanctionDashboardModel, SanctionDashboardModel } from '../../models/sanction/dashboard';
import { IApplicantDetail, SanctionResponse } from '../../models/sanction/lap-sanctionapplicationdetails';
import { requestmodel } from '../../models/sanction/request.model';
import { ConfigService } from '../common/http.services';

@Injectable({
  providedIn: 'any'
})
export class SanctionService {
  private _LanInfo?: ISanctionDashboardModel;
  public get LanInfo(): ISanctionDashboardModel {
    if (this._LanInfo)
      return this._LanInfo;
    else if (this.info.IsItem('LanInfo')) {
      this._LanInfo = JSON.parse(this.info.getItem("LanInfo")) as ISanctionDashboardModel;
      return this._LanInfo;
    }
    else {
      this._LanInfo = undefined;
      return new SanctionDashboardModel();
    }

  }
  private _OpsLandDocCheck: OpsLandDocCheck[] = [];
  public get OpsLandDocCheck(): OpsLandDocCheck[] {
    return this._OpsLandDocCheck;
  }
  public set OpsLandDocCheck(value: OpsLandDocCheck[]) {
    this._OpsLandDocCheck = value;
  }
  readonlySubject: Subject<boolean> = new Subject<boolean>();
  private _readonly: boolean = false;
  public get readonly(): boolean {
    return this._readonly;
  }
  public set readonly(value: boolean) {
    this._readonly = value;
    this.LanInfo.readOnly = value;
    this.info.setItem('LanInfo',JSON.stringify(this.LanInfo));
  }
  public set LanInfo(value: ISanctionDashboardModel) {
    this._LanInfo = value;
    this.info.setItem('LanInfo',JSON.stringify(this.LanInfo));
  }
  private _dashBoard: ISanctionDashboardModel[] = [];
  public get dashBoard(): ISanctionDashboardModel[] {
    if (this._dashBoard)
      return this._dashBoard;
    else {
      return [];
    }
  }

  public set dashBoard(value: ISanctionDashboardModel[]) {
    this._dashBoard = value;
  }
  constructor(private http: ConfigService, private info: InfoServices) {


  }
  private _userInfo: MenuUserDetail = {} as MenuUserDetail;
  public get userInfo(): MenuUserDetail {
    if (this.info.IsItem('userInfo')) {
      this._userInfo = JSON.parse(this.info.getItem('userInfo'));
      return this._userInfo;
    }
    else {
      return {} as MenuUserDetail;
    }
  }
  public set userInfo(value: MenuUserDetail) {
    value.readOnly = value.roleName != 'BCM';
    this.info.setItem("userInfo", JSON.stringify(value))
  }
  private _SanctionApplicationDetails: SanctionResponse | undefined;

  public get SanctionApplicationDetails(): SanctionResponse {
    if (this._SanctionApplicationDetails)
      return this._SanctionApplicationDetails;
    else if (this.info.IsItem('LAP_SanctionApplicationDetails')) {
      return JSON.parse(this.info.getItem('LAP_SanctionApplicationDetails')) as SanctionResponse;
    }
    else {
      return new SanctionResponse();
    }
  }

  public set SanctionApplicationDetails(value: SanctionResponse) {
    this._SanctionApplicationDetails = value;
  }
  getDocumentCheck(callBack: Function) {
    const request = new requestmodel();
    request.LoanAccountNumber = this.LanInfo.lan;
    return this.http.httpPost<OpsLandDocCheckResponse>(request.OpsLanDoctoJSON(), 'LAP_OpsLandDocCheckResponse').subscribe((res: OpsLandDocCheckResponse) => {
      this.OpsLandDocCheck = res.opsLandDocCheck;
      callBack();
    })
  }

  getApplicationDoc(applicationNo: string, docType: string): OpsLandDocCheck {
    return this.OpsLandDocCheck?.find(x => x.applicationNo == applicationNo && x.docType == docType) ?? {} as OpsLandDocCheck;
  }
  GetFinacialRecord(): IApplicantDetail[] {
    return this.SanctionApplicationDetails.applicantDetails.filter(x => x.salary_Status != "") as IApplicantDetail[];
  }

  GetMeetWithWhomFinancial(): IDropdown[] {
    return this.SanctionApplicationDetails.applicantDetails.filter(x => x.financial_status == "Financial").map(x => { return { displayName: `${x.applicantName} (${x.type})`, value: x.applicationNo } as IDropdown; });
  }


  LoadSanctionApplicationDetail() {
    let data = {
      "FLO_Id": this.userInfo.userId,
      "McCode": this.LanInfo.mcCode,
      "LeadId": this.LanInfo.leadId,
      "LoanAccountNumber": this.LanInfo.lan
    }
    this.http.httpPost<SanctionResponse>(data, "LAP_SanctionApplicationDetails").subscribe((res: SanctionResponse) => {
      if (res.errorcode == "0") {
        this.info.setItem("LAP_SanctionApplicationDetails", JSON.stringify(res));
      }
    })
  }

  GetLAPLOSCreditDasboard(data: any) {
    this.dashBoard = [];
    this.http.httpPost<IresponseModel<SanctionDashboardModel[]>>(data, 'GetLAP_LOS_CreditDasboard').subscribe((res: IresponseModel<SanctionDashboardModel[]>) => {
      if (res.errorcode == "00") {
        this.dashBoard = res.data.map((x: ISanctionDashboardModel) => {
          return new SanctionDashboardModel(x);
        });
        this.info.setItem("dashBoard", JSON.stringify(this.dashBoard));

      }
    })
  }
}

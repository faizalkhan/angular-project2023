import { Injectable, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs'
import { MenuService } from 'src/app/pages/layout/header/menu-service.service';
import { ISearch, Search } from '../../models/sanction/search/search';
import { SanctionService } from '../sanction/sanction.service';

@Injectable({
  providedIn: 'any'
})
export class SearchService implements OnDestroy  {
  public data: ISearch ;
  public SearchData = new Subject<ISearch>();
  public homeData = new Subject<any>();
  constructor(private menuService: SanctionService) {
    this.data = new Search();
  }
  ngOnDestroy(): void {
    throw new Error('Method not implemented.');
  }

  sendSearch() {
    this.data.login_PS_ID = this.menuService.userInfo.userId;
    this.data.role = this.menuService.userInfo.roleName
    this.SearchData.next(this.data);
  }

  setHomeData() {
    this.homeData.next(this.data);
    
  }

  destroy() {
    this.SearchData.complete();
  }
}

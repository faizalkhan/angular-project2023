import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment.development';
import * as CryptoJS from 'crypto-js'
const httpOptions = {
    headers: new HttpHeaders()
};
@Injectable()
export class ConfigService {

    constructor(private http: HttpClient) {

    }


    httpPost<Type>(data: any, url: string): Observable<Type> {
        return this.http.post<Type>(`${environment.api}/${url}`, data, {
            headers: {
                'hashString': this.encryptUsingAES128(JSON.stringify(data)),
                'X-IBM-Client-Secret': 'E4eW1yA0bU2nU5gI1kV6lS0lK5nN8sF5dA4wE6aD8nE0dE2iG7',
                'X-IBM-Client-Id': '5b80efab-ab01-412d-bf04-2a141ea3ff0c'
            }
        });
    }
    
    httpPostWithouImageData<Type>(data: any, url: string, headerString: any): Observable<Type> {
        return this.http.post<Type>(`${environment.api}/${url}`, data, {
            headers: {
                'hashString': this.encryptUsingAES128(JSON.stringify(headerString)),
                'X-IBM-Client-Secret': 'E4eW1yA0bU2nU5gI1kV6lS0lK5nN8sF5dA4wE6aD8nE0dE2iG7',
                'X-IBM-Client-Id': '5b80efab-ab01-412d-bf04-2a141ea3ff0c'
            }
        });
    }
    httpCommondownload<Type>(data: any, url: string): Observable<Type> {
        return this.http.post<Type>(`${environment.commonDownload}/${url}`, data, {
            headers: {
                'hashString': this.encryptUsingAES128(JSON.stringify(data)),
                'X-IBM-Client-Secret': 'E4eW1yA0bU2nU5gI1kV6lS0lK5nN8sF5dA4wE6aD8nE0dE2iG7',
                'X-IBM-Client-Id': '5b80efab-ab01-412d-bf04-2a141ea3ff0c'
            }
        });
    }

    private encryptUsingAES128(data: any) {
        if (environment.AES_ENCRYPTION_KEY !== undefined) {
            const key = String(environment.AES_ENCRYPTION_KEY);
            const encryptionKey = CryptoJS.enc.Utf8.parse(key);
            const iv = CryptoJS.enc.Utf8.parse(key);
            const encrypted = CryptoJS.AES.encrypt(
                CryptoJS.enc.Utf8.parse(data),
                encryptionKey,
                {
                    keySize: 16,
                    iv: iv,
                    mode: CryptoJS.mode.CBC,
                    padding: CryptoJS.pad.Pkcs7,
                },
            );
            return encrypted.toString();
        }
        return "";
    }

    skipBase64Props(data: any) {
        var FilteredData: any;
        var stringifyData = JSON.stringify(data);
        if (stringifyData.indexOf('base64') != -1) {
            Object.keys(data).forEach((value: any) => {
                if (data[value].indexOf('base64') == -1) {
                    FilteredData[value] = data[value];
                }
            });
        }
        return (FilteredData) ? FilteredData : data;
    }

    httpPostUpload<Type>(data: any, url: string, headerString: any): Observable<Type> {
        // 
        return this.http.post<Type>(`${environment.api}/${url}`, data, {
            headers: {
                'hashString': this.encryptUsingAES128(JSON.stringify(headerString)),
                'X-IBM-Client-Secret': 'E4eW1yA0bU2nU5gI1kV6lS0lK5nN8sF5dA4wE6aD8nE0dE2iG7',
                'X-IBM-Client-Id': '5b80efab-ab01-412d-bf04-2a141ea3ff0c'
            }
        });
    }
}






import { Directive, ViewContainerRef } from '@angular/core';


@Directive({
  selector: '[appDynamic]'
})
export class AppDynamicDirective {

  constructor(public viewContainerRef:ViewContainerRef) { }

}

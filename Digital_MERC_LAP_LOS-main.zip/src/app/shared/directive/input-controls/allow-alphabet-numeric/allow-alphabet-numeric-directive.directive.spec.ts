import { AllowAlphabetNumericDirective } from './allow-alphabet-numeric-directive.directive';

describe('AllowAlphabetNumericDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new AllowAlphabetNumericDirective();
    expect(directive).toBeTruthy();
  });
});

import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[AllowAlphabetNumeric]'
})
export class AllowAlphabetNumericDirective {
  private regex: RegExp = new RegExp(/^[a-z0-9]+$/i);
  private specialKeys: Array<string> = ['Backspace', 'Shift', 'Space', 'Tab', 'End', 'Home'];

  constructor() { }

  @HostListener('keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    if (this.specialKeys.indexOf(event.key) !== -1) {
      return true;
    }
    else if (this.specialKeys.indexOf(event.code) !== -1) {
      return true;
    }
    if (event.key && !String(event.key).match(this.regex)) {
      event.preventDefault();
      return false;
    }
    return true;
  }

}

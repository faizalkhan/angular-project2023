import { NumberDirective } from './numeric-only.directive';

describe('NumericOnlyDirective', () => {
  it('should create an instance', () => {
    let p: any;
    const directive = new NumberDirective(p);
    expect(directive).toBeTruthy();
  });
});

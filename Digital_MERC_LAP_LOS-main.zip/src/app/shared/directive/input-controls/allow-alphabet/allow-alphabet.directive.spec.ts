import { AllowAlphabetDirective } from './allow-alphabet.directive';

describe('AllowAlphabetDirective', () => {
  it('should create an instance', () => {
    const directive = new AllowAlphabetDirective();
    expect(directive).toBeTruthy();
  });
});

import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[Numericwithdecimal]'
})
export class NumericwithdecimalDirective {

  constructor() { }
  key: any;
  @HostListener('keypress', ['$event']) onKeydown(event: any) {
    var keyCode = event.which ? event.which : event.keyCode
    let val = event?.target.value as string;
    if (val.length > 0 && keyCode == 46 && val.indexOf(".") != -1) {
      event.preventDefault();
      return false;
    }
    else if (keyCode != 46 && (((keyCode >= 48 && keyCode <= 57) == false))) {
      event.preventDefault();
      return false;
    }
    return true;
  }
}

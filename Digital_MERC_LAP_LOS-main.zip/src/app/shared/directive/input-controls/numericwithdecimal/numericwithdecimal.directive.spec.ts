import { NumericwithdecimalDirective } from './numericwithdecimal.directive';

describe('NumericwithdecimalDirective', () => {
  it('should create an instance', () => {
    const directive = new NumericwithdecimalDirective();
    expect(directive).toBeTruthy();
  });
});

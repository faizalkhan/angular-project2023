import { Ifile, IfileUpload } from "src/app/pages/layout/button/upload-view-download/upload-view-download.service";

export class common {
  static ObjectMapping(source: any, target: any): any {
    let _sourceKeys = Object.keys(source).map(x => {
      if (x.startsWith('_')) {
        return { name: `${x.toLowerCase()}`, key: x }
      }
      else {
        return { name: `_${x.toLowerCase()}`, key: x }
      }
    });

    let _target = Object.keys(target).map(x => { return { name: x.toLowerCase(), key: x, type: typeof (target[x]) } });

    _sourceKeys.forEach(x => {
      let _exists = _target.find(y => y.name == x.name);
      if (_exists) {
        target[_exists.key] = source[x.key];
      }
    });
  }
  static emiCalc(ir: any, np: any, fv: any, type: any, pv: any) {
    /*
     * ir   - interest rate per month
     * np   - number of periods (months)
     * pv   - present value
     * fv   - future value
     * type - when the payments are due:
     *        0: end of the period, e.g. end of month (default)
     *        1: beginning of period
     */
    var pmt, pvif;

    fv || (fv = 0);
    type || (type = 0);

    if (ir === 0)
      return -(pv + fv) / np;

    pvif = Math.pow(1.00 + ir, np);
    pmt = - ir * (pv * pvif + fv) / (pvif - 1.00);

    if (type === 1)
      pmt /= (1.00 + ir);

    return -pmt;
  }
  // static toJSON(target: any) {
  //     let data = Object.keys(target).map(x => { return { name: x, type: typeof (target[x]) } });

  //     // let _json = JSON.stringify(target);

  //     // return JSON.parse(_json);
  // }
  static toFindDuplicates(arry: any, key: any) {
    const uniqueElements = new Set(arry.map((x: any) => x[key]));
    const filteredElements = arry.filter((item: any) => {
      if (uniqueElements.has(item[key])) {
        uniqueElements.delete(item[key]);
      } else {
        return item;
      }
    });

    return filteredElements;
  }
  static getTermType(appliedAmount: number) {
    let TermType: any[] = [];
    if (appliedAmount >= 100000 && appliedAmount <= 300000) {
      TermType = [{ displayName: '36', value: '36' },
      { displayName: '48', value: '48' }];
    }
    else if (appliedAmount > 300000 && appliedAmount <= 600000) {
      TermType = [{ displayName: '48', value: '48' },
      { displayName: '60', value: '60' },
      { displayName: '72', value: '72' }]
    }
    else if (appliedAmount > 600000) {
      TermType = [{ displayName: '60', value: '60' },
      { displayName: '72', value: '72' },
      { displayName: '84', value: '84' },
      { displayName: '96', value: '96' }]
    }
    else {
      TermType = [];
    }
    return TermType;
  }
  // Javascript program to validate
  // IFSC (Indian Financial System) Code using Regular Expression

  // Function to validate the
  // IFSC_Code 
  static isValid_IFSC_Code(ifsc_Code: any) {

    // Regex to check valid
    // ifsc_Code 
    let regex = new RegExp(/^[A-Z]{4}0[A-Z0-9]{6}$/);

    // if ifsc_Code
    // is empty return false
    if (ifsc_Code == null) {
      return false;
    }

    // Return true if the ifsc_Code
    // matched the ReGex
    return regex.test(ifsc_Code);

  }
  static IsValid_Email(emailId: any) {
    let regex = new RegExp("[a-z0-9._%+-]+@[a-z]+.[a-z]{2,3}$")

    // if ifsc_Code
    // is empty return false
    if (!emailId || emailId == null) {
      return false;
    }

    // Return true if the ifsc_Code
    // matched the ReGex
    return regex.test(emailId);
  }
  static range(arr: any[], startAt: number = 0): any[] {



    let data = arr.map((val: any, i: number) => {
      if (i >= startAt)
        return val;
    })

    return data.filter(x => (x && x != ""))
  }

  static isValid_MobileNo(MobNumber: any) {
   
    let regex = new RegExp("[6-9]{1}[0-9]{9}");
    //let regex= new RegExp("/^(\+\d{1,3}[- ]?)?\d{10}$/");
    //let regex= new RegExp("/^[6-9][0-9]{0,10}$/;");
    if (!MobNumber || MobNumber == null || MobNumber.length>10) {
      return false;
    }
    return regex.test(MobNumber);
  }

  static IsValidMonth(month: any) {
    let regex = new RegExp("^(0?[0-9]|1[011])$");
    if (!month || month == null) {
      return false;
    }
    return regex.test(month);
  }

  static IsValidYear(year: any) {
    let regex = new RegExp("^(?:(?:18|19|20|21)[0-9]{2})$");
    if (!year || year == null) {
      return false;
    }
    return regex.test(year);
  }


  static sort(a: any, b: any, key: any) {
    if (a[key] < b[key]) {
      return -1;
    }
    if (a[key] > b[key]) {
      return 1;
    }
    return 0;
  }

  static IsRequired(props: any): boolean {
    if (props === undefined || (typeof props == 'string' && props == "")) {
      return false;
    }
    return true;
  }

  static upload(event: IfileUpload): Ifile {
    return { extension: event.extension, file: event.imageData, filename: event.name, format: event.imageMIMEType } as Ifile;
  }
  private static _readonly: any;
  public static get readonly(): any {
    return common._readonly;
  }
  public static set readonly(value: any) {
    common._readonly = value;
  }


}
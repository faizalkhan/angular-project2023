import { common } from "../../common";

export interface IPhysicalDiscussion {
    loanAccountNumber: string;
    point_of_Contact: string;
    sales_FLO_Name: string;
    sales_FLO_PSID: string;
    creditOfcr_Name: string;
    creditOfcr_Designation: string;
    creditOfcr_PSID: string;
    meetwith: string;
    flO_PsId: string;
    pD_Freefield_1: string;
    pD_Freefield_2: string;
    pD_Freefield_3: string;
    pD_Freefield_4: string;
    sourceThrough: string;
    createdOn: string;
    toJSON(): any;
}

export class PhysicalDiscussion implements IPhysicalDiscussion {
    constructor(params?: IPhysicalDiscussion) {
        if (params)
            common.ObjectMapping(params, this);
    }
    private _loanAccountNumber: string = "";
    public get loanAccountNumber(): string {
        return this._loanAccountNumber;
    }
    public set loanAccountNumber(value: string) {
        this._loanAccountNumber = value;
    }
    private _point_of_Contact: string = "";
    public get point_of_Contact(): string {
        return this._point_of_Contact;
    }
    public set point_of_Contact(value: string) {
        this._point_of_Contact = value;
    }
    private _sales_FLO_Name: string = "";
    public get sales_FLO_Name(): string {
        return this._sales_FLO_Name;
    }
    public set sales_FLO_Name(value: string) {
        this._sales_FLO_Name = value;
    }
    private _sales_FLO_PSID: string = "";
    public get sales_FLO_PSID(): string {
        return this._sales_FLO_PSID;
    }
    public set sales_FLO_PSID(value: string) {
        this._sales_FLO_PSID = value;
    }
    private _creditOfcr_Name: string = "";
    public get creditOfcr_Name(): string {
        return this._creditOfcr_Name;
    }
    public set creditOfcr_Name(value: string) {
        this._creditOfcr_Name = value;
    }
    private _creditOfcr_Designation: string = "";
    public get creditOfcr_Designation(): string {
        return this._creditOfcr_Designation;
    }
    public set creditOfcr_Designation(value: string) {
        this._creditOfcr_Designation = value;
    }
    private _creditOfcr_PSID: string = "";
    public get creditOfcr_PSID(): string {
        return this._creditOfcr_PSID;
    }
    public set creditOfcr_PSID(value: string) {
        this._creditOfcr_PSID = value;
    }
    private _meetwith: string = "";
    public get meetwith(): string {
        return this._meetwith;
    }
    public set meetwith(value: string) {
        this._meetwith = value;
    }
    private _flO_PsId: string = "";
    public get flO_PsId(): string {
        return this._flO_PsId;
    }
    public set flO_PsId(value: string) {
        this._flO_PsId = value;
    }
    private _pD_Freefield_1: string = "";
    public get pD_Freefield_1(): string {
        return this._pD_Freefield_1;
    }
    public set pD_Freefield_1(value: string) {
        this._pD_Freefield_1 = value;
    }
    private _pD_Freefield_2: string = "";
    public get pD_Freefield_2(): string {
        return this._pD_Freefield_2;
    }
    public set pD_Freefield_2(value: string) {
        this._pD_Freefield_2 = value;
    }
    private _pD_Freefield_3: string = "";
    public get pD_Freefield_3(): string {
        return this._pD_Freefield_3;
    }
    public set pD_Freefield_3(value: string) {
        this._pD_Freefield_3 = value;
    }
    private _pD_Freefield_4: string = "";
    public get pD_Freefield_4(): string {
        return this._pD_Freefield_4;
    }
    public set pD_Freefield_4(value: string) {
        this._pD_Freefield_4 = value;
    }
    private _createdOn: Date = new Date();
    public get createdOn(): any {
        return this._createdOn;
    }
    public set createdOn(value: any) {
        this._createdOn = value;
    }
    public get sourceThrough(): any {
        return "LOS";
    }


    toJSON(): any {
        return {
            "CreditOfcr_Designation": this.creditOfcr_Designation,
            "CreditOfcr_Name": this.creditOfcr_Name,
            "CreditOfcr_PSID": this.creditOfcr_PSID,
            "FLO_PsId": this.flO_PsId,
            "LoanAccountNumber": this.loanAccountNumber,
            "PD_Freefield_1": this.pD_Freefield_1,
            "PD_Freefield_2": this.pD_Freefield_2,
            "PD_Freefield_3": this.pD_Freefield_3,
            "PD_Freefield_4": this.pD_Freefield_4,
            "Point_of_Contact": this.point_of_Contact,
            "Sales_FLO_Name": this.sales_FLO_Name,
            "Sales_FLO_PSID": this.sales_FLO_PSID,
            "SourceThrough": this.sourceThrough
        }
    }

}


export interface FinancialApplicantDetail {
    financialApplicantName: string;
    applicationNo: string;
    financial_status: string;
    occupation: string;
    isDairyAndAllied: string;
    isMotorMech: string;
    isTailoringHandloom: string;
    isElecronicAndRepair: string;
    isOthersBusiness: string;
    dairyAndAllied?: any;
    motorMech?: any;
    tailoringHandloom?: any;
    elecronicAndRepair?: any;
    othersDetails: OthersDetail[];
}

export interface OthersDetail {
    applicationNo: string;
    applicantCoappRef: string;
    nameOfBusiness: string;
    business_Number_Of_Years: number;
    business_Number_Of_Months: number;
    ownership_Of_Premise: string;
    numOfFam: number;
    numofPartners: number;
    numofEmplyrWorker: number;
    wageFrequency: number;
    locality: string;
    tradeUnionMem_YN: string;
    memberShip_Lic_Num: string;
    tradeUnionName: string;
    tradeUnionAdd: string;
    tradeUnionContact: string;
    membershipCardUpload_YN: string;
    membershipCardUpload: string;
    topSellingProd: string;
    ownerFund: string;
    exp_Shoprent_Act: string;
    exp_Electricity_Act: string;
    exp_SalaryLabourCost_Act: string;
    exp_Other_Act: string;
    walkInCust: string;
    avgRevPerCust: string;
    purchaseCostPerMon: string;
    prodCycle: string;
    inventoryVal: number;
    warehouse_YN: string;
    stockVal: string;
    deadStock: string;
    sellingMode: string;
    creditSales: string;
    avgCreditPeriod: string;
    supp_Name_Top1: string;
    supp_Contact_Top1: string;
    supp_Address_Top1: string;
    supp_Name_Top2: string;
    supp_Contact_Top2: string;
    supp_Address_Top2: string;
    supp_ValofTxn_Top1: string;
    supp_ValofTxn_Top2: string;
    monthlyTurnOver: number;
    grossProfitMargin: number;
    upI_YN: string;
    seasonableBusiness_YN: string;
    seasonableBusinessIncome: number;
    receivables: string;
    payables: string;
    flO_PsId: string;
    sourceThrough: string;
    leadId?: any;
    createdOn: string;
}

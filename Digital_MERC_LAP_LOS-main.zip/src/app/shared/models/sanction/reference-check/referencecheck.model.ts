import { common } from "../../common";
import { Dropdown, IDropdown } from "../../common/control.model";

export interface IReferenceCheck {
    loanAccountNumber: any;
    flO_PsId: any;
    name: any;
    mobileNo: any;
    type: any;
    relationship: any;
    checkResult: any;
    remark: any;
    createdOn: any;
    Id: number;
    ReferenceType: IDropdown[];
    ReferenceRelationShip: IDropdown[];
    isTradeSelected: boolean;
}

export class ReferenceCheck implements IReferenceCheck {
    private _loanAccountNumber: any = "";
    public get loanAccountNumber(): any {
        return this._loanAccountNumber;
    }
    public set loanAccountNumber(value: any) {
        this._loanAccountNumber = value;
    }
    private _flO_PsId: any = "";
    public get flO_PsId(): any {
        return this._flO_PsId;
    }
    public set flO_PsId(value: any) {
        this._flO_PsId = value;
    }
    private _name: any = "";
    public get name(): any {
        return this._name;
    }
    public set name(value: any) {
        this._name = value;
    }
    private _mobileNo: any = "";
    public get mobileNo(): any {
        return this._mobileNo;
    }
    public set mobileNo(value: any) {
        this._mobileNo = value;
    }
    private _type: any = "";
    public get type(): any {
        return this._type;
    }
    private _isTradeSelected: boolean = false;
    public get isTradeSelected(): boolean {
        return this._isTradeSelected;
    }
    public set isTradeSelected(value: boolean) {
        this._isTradeSelected = value;
    }
    public set type(value: any) {
        this._type = value;
        if (value != '' && value == "Residence Neighbour Reference") {
            this._ReferenceRelationShip = [];
            this._relationship = "";
            this.isTradeSelected = false;
        }
        else {
            this._ReferenceRelationShip = [new Dropdown({ displayName: "Supplier" }), new Dropdown({ displayName: "Customer" }), new Dropdown({ displayName: "Business Neighbour" })]
            this.isTradeSelected = true;
        }
    }
    private _relationship: any = "";
    public get relationship(): any {
        return this._relationship;
    }
    public set relationship(value: any) {
        console.debug(value);
        this._relationship = value;
    }
    private _checkResult: any = "";
    public get checkResult(): any {
        return this._checkResult;
    }
    public set checkResult(value: any) {
        this._checkResult = value;
    }
    private _remark: any = "";
    public get remark(): any {
        return this._remark;
    }
    public set remark(value: any) {
        this._remark = value;
    }
    private _createdOn: any = "";
    public get createdOn(): any {
        return this._createdOn;
    }
    public set createdOn(value: any) {
        this._createdOn = value;
    }
    private _isEdit: boolean = false;
    public get isEdit(): boolean {
        return this._isEdit;
    }
    public set isEdit(value: boolean) {
        this._isEdit = value;
    }
    private _Id: number = 0;
    public get Id(): number {
        return this._Id;
    }
    public set Id(value: number) {
        this._Id = value;
    }

    constructor(params?: IReferenceCheck) {
        if (params) {
            common.ObjectMapping(params, this);
        }
    }
    ReferenceType: IDropdown[] = [new Dropdown({ displayName: "Trade Reference" }), new Dropdown({ displayName: "Residence Neighbour Reference" })];
    private _ReferenceRelationShip: IDropdown[] = [];
    public get ReferenceRelationShip(): IDropdown[] {
        return this._ReferenceRelationShip;

    }
    public set ReferenceRelationShip(value: IDropdown[]) {
        this._ReferenceRelationShip = value;
    }

}
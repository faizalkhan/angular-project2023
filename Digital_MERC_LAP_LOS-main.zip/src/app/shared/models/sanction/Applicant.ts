import { common } from "../common";
import { IApplicant } from "./IApplicant";


export class Applicant implements IApplicant {
    private _name: string = "";
    public get name(): string {
        return this._name;
    }
    public set name(value: string) {
        this._name = value;
    }
    private _contact_Number: string = "";
    public get contact_Number(): string {
        return this._contact_Number;
    }
    public set contact_Number(value: string) {
        this._contact_Number = value;
    }
    private _financial_Status: string = "";
    public get financial_Status(): string {
        return this._financial_Status;
    }
    public set financial_Status(value: string) {
        this._financial_Status = value;
    }
    private _type_of_Applicant: string = "";
    public get type_of_Applicant(): string {
        return this._type_of_Applicant;
    }
    public set type_of_Applicant(value: string) {
        this._type_of_Applicant = value;
    }
    private _salary_Occupation_Status: string = "";
    public get salary_Occupation_Status(): string {
        return this._salary_Occupation_Status;
    }
    public set salary_Occupation_Status(value: string) {
        this._salary_Occupation_Status = value;
    }
    private _date_of_Birth: string = "";
    public get date_of_Birth(): string {
        return this._date_of_Birth;
    }
    public set date_of_Birth(value: string) {
        this._date_of_Birth = value;
    }
    private _relationship_with_applicant: string = "";
    public get relationship_with_applicant(): string {
        return this._relationship_with_applicant;
    }
    public set relationship_with_applicant(value: string) {
        this._relationship_with_applicant = value;
    }
    private _gender: string = "";
    public get gender(): string {
        return this._gender;
    }
    public set gender(value: string) {
        this._gender = value;
    }
    private _email_id: string = "";
    public get email_id(): string {
        return this._email_id;
    }
    public set email_id(value: string) {
        this._email_id = value;
    }
    private _kyC_1_Type: string = "";
    public get kyC_1_Type(): string {
        return this._kyC_1_Type;
    }
    public set kyC_1_Type(value: string) {
        this._kyC_1_Type = value;
    }
    private _kyC_1_Details: string = "";
    public get kyC_1_Details(): string {
        return this._kyC_1_Details;
    }
    public set kyC_1_Details(value: string) {
        this._kyC_1_Details = value;
    }
    private _kyC_1_Status: string = "";
    public get kyC_1_Status(): string {
        return this._kyC_1_Status;
    }
    public set kyC_1_Status(value: string) {
        this._kyC_1_Status = value;
    }
    private _kyC_2_Type: string = "";
    public get kyC_2_Type(): string {
        return this._kyC_2_Type;
    }
    public set kyC_2_Type(value: string) {
        this._kyC_2_Type = value;
    }
    private _kyC_2_Details: string = "";
    public get kyC_2_Details(): string {
        return this._kyC_2_Details;
    }
    public set kyC_2_Details(value: string) {
        this._kyC_2_Details = value;
    }
    private _kyC_2_Status: string = "";
    public get kyC_2_Status(): string {
        return this._kyC_2_Status;
    }
    public set kyC_2_Status(value: string) {
        this._kyC_2_Status = value;
    }
    private _isapplicant: string = "";
    public get isapplicant(): string {
        return this._isapplicant;
    }
    public set isapplicant(value: string) {
        this._isapplicant = value;
    }

    constructor(params?: IApplicant
    ) {
        if (params) {
            common.ObjectMapping(params, this);
        }

    }
    private _applicationNo: string = "";
    public get applicationNo(): string {
        return this._applicationNo;
    }
    public set applicationNo(value: string) {
        this._applicationNo = value;
    }
    private _kyC_1_Image: string = "";
    public get kyC_1_Image(): string {
        return this._kyC_1_Image;
    }
    public set kyC_1_Image(value: string) {
        this._kyC_1_Image = value;
    }
    private _kyC_2_Image: string = "";
    public get kyC_2_Image(): string {
        return this._kyC_2_Image;
    }
    public set kyC_2_Image(value: string) {
        this._kyC_2_Image = value;
    }
    private _currentAddress: string = "";
    public get currentAddress(): string {
        return this._currentAddress;
    }
    public set currentAddress(value: string) {
        this._currentAddress = value;
    }
    private _permanentAddress: string = "";
    public get permanentAddress(): string {
        return this._permanentAddress;
    }
    public set permanentAddress(value: string) {
        this._permanentAddress = value;
    }

    private _form60_Ref: string = "";
    public get form60_Ref(): string {
        return this._form60_Ref;
    }
    public set form60_Ref(value: string) {
        this._form60_Ref = value;
    }
    private _address_Ref: string = "";
    public get address_Ref(): string {
        return this._address_Ref;
    }
    public set address_Ref(value: string) {
        this._address_Ref = value;
    }
    private _Ka1_Front_Ref: string = "";
    public get Ka1_Front_Ref(): string {
        return this._Ka1_Front_Ref;
    }
    public set Ka1_Front_Ref(value: string) {
        this._Ka1_Front_Ref = value;
    }
    private _Ka1_Back_Ref: string = "";
    public get Ka1_Back_Ref(): string {
        return this._Ka1_Back_Ref;
    }
    public set Ka1_Back_Ref(value: string) {
        this._Ka1_Back_Ref = value;
    }
    private _PAN_Ref: string = "";
    public get PAN_Ref(): string {
        return this._PAN_Ref;
    }
    public set PAN_Ref(value: string) {
        this._PAN_Ref = value;
    }


}

import { responseModel } from "../common/response.model";
import { Applicant } from "./Applicant";
import { IApplicant } from "./IApplicant";


export interface ISanctionRequestData {
    LoanAccountNumber: string;
    ApplicationNo: string;
    FLO_PsId: string;
    CreatedON: string;
}

export class SanctionRequestData implements ISanctionRequestData {
    LoanAccountNumber: string = "";
    ApplicationNo: string = "";
    FLO_PsId: string = "";
    CreatedON: string = "";

}


export interface IProgressData {
    personal_Details: string;
    income_Assessment: string;
    business_Details: string;
    banking_Assessment: string;
    reference_details: string;
    property_valuation: string;
    household_Assessment: string;
    caM_sheet: string;
    legal_Check: string;
    technical_Check: string;
    income_Eligibility: string;

}

export interface IApplicationDetail {
    applicantName: string;
    loginDate: string;
    contactNo: number;
    product: string;
    district: string;
    schema: string;
    appliedTenure: string;
    state: string;
    branchName: string;
    pinCode: number;
    appliedLoanAmount: number;
    loanAccountNumber: string;
}
export interface IApplicationProcess {
    personaldetails: string;
    incomeassessment: string;
    businessdetails: string;
    bankingassessment: string;
    referencedetails: string;
    propertyvalution: string;
    householdassessment: string;
    camsheer: string;
}

export class AppProcess implements IApplicationProcess {
    personaldetails: string = "";;;
    incomeassessment: string = "";;;
    businessdetails: string = "";;;
    bankingassessment: string = "";;;
    referencedetails: string = "";;;
    propertyvalution: string = "";;;
    householdassessment: string = "";;;
    camsheer: string = "";;;

    constructor(params?: IApplicationProcess) {
        if (params) {
            this.personaldetails = params.personaldetails;
            this.incomeassessment = params.incomeassessment;
            this.businessdetails = params.businessdetails;
            this.bankingassessment = params.bankingassessment;
            this.referencedetails = params.referencedetails;
            this.propertyvalution = params.propertyvalution;
            this.householdassessment = params.householdassessment;
            this.camsheer = params.camsheer;
        }
    }

}
export interface ISanctionApplication {
    applicantDetailsData: IApplicant[];
    appProgressData: IProgressData[];
    applicationDetails: IApplicationDetail[];
    applicationProgress: IApplicationProcess;
    loanAccountNumber: any;
}
export class SanctionApplication implements ISanctionApplication, responseModel {
    loanAccountNumber: any;
    applicantDetailsData: IApplicant[] = [new Applicant()];
    appProgressData: IProgressData[] = [new ProgressData()];
    applicationDetails: IApplicationDetail[] = [new ApplicationDetails()];
    applicationProgress: IApplicationProcess = new AppProcess();

    constructor(param?: ISanctionApplication) {
        if (param) {
            if (param.applicantDetailsData) {
                this.applicantDetailsData = param.applicantDetailsData;
            }
            if (param.appProgressData) {
                this.appProgressData = param.appProgressData;
            }
            if (param.applicationDetails) {
                this.applicationDetails = param.applicationDetails;
            }
            if (param.applicationProgress) {
                this.applicationProgress = param.applicationProgress;
            }
        }
    }
    errorcode: any;
    errorDescription: any;
}
export class ApplicationDetails implements IApplicationDetail {
    applicantName: string = "";
    loginDate: string = "";
    contactNo: number = 0;
    appliedTenure: string = "";
    product: string = "";
    district: string = "";
    schema: string = "";
    state: string = "";
    branchName: string = "";
    pinCode: number = 0;
    appliedLoanAmount: number = 0;

    constructor(params?: IApplicationDetail) {
        if (params) {
            this.applicantName = params.applicantName;
            this.loginDate = params.loginDate;
            this.contactNo = params.contactNo;
            this.product = params.product;
            this.district = params.district;
            this.schema = params.schema;
            this.state = params.state;
            this.branchName = params.branchName;
            this.pinCode = params.pinCode;
            this.appliedTenure = params.appliedTenure;
            this.appliedLoanAmount = params.appliedLoanAmount;
        }

    }
    loanAccountNumber: string = "";

}

export class ProgressData implements IProgressData {
    personal_Details: string = "";
    income_Assessment: string = "";
    business_Details: string = "";
    banking_Assessment: string = "";
    reference_details: string = "";
    property_valuation: string = "";
    household_Assessment: string = "";
    caM_sheet: string = "";
    legal_Check: string = "";
    technical_Check: string = "";
    income_Eligibility: string = "";


    constructor(params?: IProgressData
    ) {
        if (params) {
            this.personal_Details = params.personal_Details;
            this.income_Assessment = params.income_Assessment;
            this.business_Details = params.business_Details;
            this.banking_Assessment = params.banking_Assessment;
            this.reference_details = params.reference_details;
            this.property_valuation = params.property_valuation;
            this.household_Assessment = params.household_Assessment;
            this.caM_sheet = params.caM_sheet;
            this.legal_Check = params.legal_Check;
            this.technical_Check = params.technical_Check;
            this.income_Eligibility = params.income_Eligibility;
        }

    }

}


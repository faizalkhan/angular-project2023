import { Observable } from "rxjs";

export interface ISearch {
    fromDate: Date;
    toDate: Date;
    fieldName: string;
    role: string;
    fieldValue: string;
    login_PS_ID: string;

    toJson(): any;

    Validate(): boolean;
}

export class Search implements ISearch {
    currentDate = new Date();
    firstDay = new Date(this.currentDate.getFullYear(), this.currentDate.getMonth(), 1);
    lastDay = new Date(this.currentDate.getFullYear(), this.currentDate.getMonth() + 1, 0);
    fromDate: any = this.firstDay;
    public get FromDate(): any {
        return this.fromDate;
    }
    toDate: any = this.lastDay;
    public get ToDate(): any {
        return this.toDate;
    }
    public set ToDate(value: Date) {
        this.toDate = value;
    }
    fieldName: string = "Branch";
    role: string = "";
    fieldValue: string = "T0318";
    login_PS_ID: string = "";

    constructor(params?: ISearch) {
        if (params) {
            this.fromDate = new Date(params.fromDate);
            this.toDate = new Date(params.toDate);
            this.fieldName = params.fieldName;
            this.fieldValue = params.fieldValue;
            this.role = params.role;
        }
    }


    toJson(): any {

        return {
            "FromDate": this.FromDate,
            "ToDate": this.ToDate,
            "FieldName": this.fieldName,
            "Role": this.role,
            "FieldValue": this.fieldValue,
            "Login_PS_ID": this.login_PS_ID
        };
    }



    Validate(): boolean {
        return true;
    }


}




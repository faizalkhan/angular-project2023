export interface IRequestModel {
    fLO_PsId: any;
    createdON: any;
    userID?: any;
    mcCode?: any;
    leadId?: any;
}

export class requestmodel {
    private loanAccountNumber: any;
    private fLO_PsId: any;
    private createdON: any;
    private userID: any;
    private roleName: any;
    private casetype: any;
    private fieldName: any;
    private fieldValue: any;
    private fromDate: any;
    private toDate: any;
    private leadId: any;
    private role: any;
    private screentype: any;

    public get UserID(): any {
        return this.userID;
    }
    public set UserID(value: any) {
        this.userID = value;
    }
    private mcCode: any;
    public get McCode(): any {
        return this.mcCode;
    }
    public set McCode(value: any) {
        this.mcCode = value;
    }
    public get CreatedON(): any {
        return this.createdON;
    }
    public set CreatedON(value: any) {
        this.createdON = value;
    }
    public get FLO_PsId(): any {
        return this.fLO_PsId;
    }
    public set FLO_PsId(value: any) {
        this.fLO_PsId = value;
    }
    public get LoanAccountNumber(): string {
        return this.loanAccountNumber;
    }
    public set LoanAccountNumber(value: string) {
        this.loanAccountNumber = value;
    }
    public get RoleName(): string {
        return this.roleName;
    }
    public set RoleName(value: string) {
        this.roleName = value;
    }

    public get Role(): string {
        return this.role;
    }
    public set Role(value: string) {
        this.role = value;
    }


    public get CaseType(): string {
        return this.casetype;
    }
    public set CaseType(value: string) {
        this.casetype = value;
    }

    public get FieldName(): string {
        return this.fieldName;
    }
    public set FieldName(value: string) {
        this.fieldName = value;
    }

    public get FieldValue(): string {
        return this.fieldValue;
    }
    public set FieldValue(value: string) {
        this.fieldValue = value;
    }

    public get FromDate(): string {
        return this.fromDate;
    }
    public set FromDate(value: string) {
        this.fromDate = value;
    }

    public get ToDate(): string {
        return this.toDate;
    }
    public set ToDate(value: string) {
        this.toDate = value;
    }

    public get LeadId(): string {
        return this.leadId;
    }
    public set LeadId(value: string) {
        this.leadId = value;
    }


    public get ScreenType(): string {
        return this.screentype;
    }
    public set ScreenType(value: string) {
        this.screentype = value;
    }

    constructor(params?: IRequestModel) {
        if (params) {
            this.fLO_PsId = params.fLO_PsId;
            this.createdON = params.createdON;
            this.userID = params.userID;
            this.mcCode = params.mcCode;
        }
    }




    RCUPendingActiontoJSON(): any {
        return {
            "UserID": this.userID,
            "FieldName": this.FieldName,
            "ScreenType": this.ScreenType,
            "Role": this.Role,
            "FieldValue": this.FieldValue,
            "FromDate": this.FromDate,
            "ToDate": this.ToDate
        };
    }

    RCUAppDetailstoJSON(): any {
        return {
            "UserID": this.UserID,
            "LoanAccountNumber": this.LoanAccountNumber
        };
    }
    OpsDashboardtoJSON(): any {
        return {
            "CaseType": this.CaseType,
            "FieldName": this.FieldName,
            "FLO_PsId": this.FLO_PsId,
            "RoleName": this.RoleName,
            "FieldValue": this.FieldValue,
            "FromDate": this.FromDate,
            "ToDate": this.ToDate
        };
    }
    OpsApptoJSON(): any {
        return {
            "LoanAccountNumber": this.LoanAccountNumber,
            "CreatedON": this.CreatedON,
            "FLO_PsId": this.FLO_PsId,
            "RoleName": this.RoleName
            
        };
    }
    OpsValtoJSON(): any {
        return {
            "LoanAccountNumber": this.LoanAccountNumber,
            "CreatedON": this.CreatedON,
            "FLO_PsId": this.FLO_PsId,
            "RoleName": this.RoleName
        };
    }
    OpsLanDoctoJSON(): any {
        return {
            "LoanAccountNumber": this.LoanAccountNumber,
        };
    }
}


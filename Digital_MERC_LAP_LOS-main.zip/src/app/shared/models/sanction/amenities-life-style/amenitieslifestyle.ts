import { common } from "../../common";

export interface IAmenitiesAndLifeStyle {
    loanAccountNumber: string;
    toilet: string;
    electricity: string;
    water: string;
    sewage: string;
    gasConnection: string;
    houseOtherThanWhereResiding: string;
    shop: string;
    vehicle: vehicleDetail[];
    householdBasicAmenities: string;
    cooler: string;
    fridge: string;
    shopType: string;
    washingMachine: string;
    airConditioner: string;
    otherHouseholdEquipments: string;
    flO_PsId: string;
    sourceThrough: string;
    createdOn: string;
    getVehicleList(): vehicleDetail[];
    toJSON():any;
}

export class vehicleDetail {
    loanAccountNumber: string = '';
    vehicleName: string = '';
    numberOfVechicle: string = '';
}

export class AmenitiesAndLifestyle implements IAmenitiesAndLifeStyle {

    private _loanAccountNumber: string = "";
    public get loanAccountNumber(): string {
        return this._loanAccountNumber;
    }
    public set loanAccountNumber(value: string) {
        this._loanAccountNumber = value;
    }
    private _toilet: string = "";
    public get toilet(): string {
        return this._toilet;
    }
    public set toilet(value: string) {
        this._toilet = value;
    }
    private _electricity: string = "";
    public get electricity(): string {
        return this._electricity;
    }
    public set electricity(value: string) {
        this._electricity = value;
    }
    private _water: string = "";
    public get water(): string {
        return this._water;
    }
    public set water(value: string) {
        this._water = value;
    }
    private _sewage: string = "";
    public get sewage(): string {
        return this._sewage;
    }
    public set sewage(value: string) {
        this._sewage = value;
    }
    private _gasConnection: string = "";
    public get gasConnection(): string {
        return this._gasConnection;
    }
    public set gasConnection(value: string) {
        this._gasConnection = value;
    }
    private _houseOtherThanWhereResiding: string = "";
    public get houseOtherThanWhereResiding(): string {
        return this._houseOtherThanWhereResiding;
    }
    public set houseOtherThanWhereResiding(value: string) {
        this._houseOtherThanWhereResiding = value;
    }
    private _shop: string = "";
    public get shop(): string {
        return this._shop;
    }
    public set shop(value: string) {
        this._shop = value;
    }
    private _vehicle: vehicleDetail[] = [];
    public get vehicle(): vehicleDetail[] {
        return this._vehicle;
    }
    public set vehicle(value: vehicleDetail[]) {
        this._vehicle = value;
    }
    private _householdBasicAmenities: string = "";
    public get householdBasicAmenities(): string {
        return this._householdBasicAmenities;
    }
    public set householdBasicAmenities(value: string) {
        this._householdBasicAmenities = value;
    }
    private _cooler: string = "";
    public get cooler(): string {
        return this._cooler;
    }
    public set cooler(value: string) {
        this._cooler = value;
    }
    private _fridge: string = "";
    public get fridge(): string {
        return this._fridge;
    }
    public set fridge(value: string) {
        this._fridge = value;
    }
    private _shopType: string = "";
    public get shopType(): string {
        return this._shopType;
    }
    public set shopType(value: string) {
        this._shopType = value;
    }
    private _washingMachine: string = "";
    public get washingMachine(): string {
        return this._washingMachine;
    }
    public set washingMachine(value: string) {
        this._washingMachine = value;
    }
    private _airConditioner: string = "";
    public get airConditioner(): string {
        return this._airConditioner;
    }
    public set airConditioner(value: string) {
        this._airConditioner = value;
    }
    private _otherHouseholdEquipments: string = "";
    public get otherHouseholdEquipments(): string {
        return this._otherHouseholdEquipments;
    }
    public set otherHouseholdEquipments(value: string) {
        this._otherHouseholdEquipments = value;
    }
    private _flO_PsId: string = "";
    public get flO_PsId(): string {
        return this._flO_PsId;
    }
    public set flO_PsId(value: string) {
        this._flO_PsId = value;
    }
    public get sourceThrough(): string {
        return "LOS";
    }

    private _createdOn: string = "";
    public get createdOn(): string {
        return this._createdOn;
    }
    public set createdOn(value: string) {
        this._createdOn = value;
    }

    constructor(params?: IAmenitiesAndLifeStyle) {
        if (params) {
            common.ObjectMapping(params, this);
        }

    }

    getVehicleList(): vehicleDetail[] {
        let addMoreList: vehicleDetail[] = [];
        let list = ["Cycle", "Two Wheeler", "Three Wheeler", "Four Wheeler", "Tractor"];
        list.forEach((val: any, index: any, arr: any) => {
            let _veh = this.vehicle?.find(x => x.vehicleName == val);
            if (!_veh) {
                addMoreList.push({ loanAccountNumber: this.loanAccountNumber, numberOfVechicle: "", vehicleName: val })
            }
        })
        return addMoreList;
    }
    toJSON() {
        return {
            "AirConditioner": this.airConditioner,
            "Cooler": this.cooler,
            "Electricity": this.electricity,
            "FLO_PsId": this.flO_PsId,
            "Fridge": this.fridge,
            "GasConnection": this.gasConnection,
            "HouseholdBasicAmenities": this.householdBasicAmenities,
            "HouseOtherThanWhereResiding": this.houseOtherThanWhereResiding,
            "LoanAccountNumber": this.loanAccountNumber,
            "OtherHouseholdEquipments": this.otherHouseholdEquipments,
            "Sewage": this.sewage,
            "Shop": this.shop,
            "ShopType": this.shopType,
            "SourceThrough": "LOS",
            "Toilet": this.toilet,
            "Vehicle": this.vehicle,
            "WashingMachine": this.washingMachine,
            "Water": this.water
        };
    }
}
import { IUploadDocument, UploadDocument } from "src/app/pages/disbursementdetails/makers/makers.service";
import { file, FileUpload, Ifile, IfileUpload } from "src/app/pages/layout/button/upload-view-download/upload-view-download.service";
import { common } from "../common";

export interface IDairyAndAlliedModel {
    loanAccountNumber: string;
    applicationNo: string;
    applicantCoappRef: string;
    typeOfBusiness: string;
    l_CountofCattle: string;
    l_AccomodationInSqFt: string;
    l_PerCattleProd: string;
    l_CattleInsurance_YN: string;
    l_NumOfCattleInsured: string;
    l_MedReport_Remark: string;
    l_MedReport_Title: string;
    l_MedReport_Upload: string;
    l_MedReport_UploadMimeType: string;
    l_MedReport_UploadExtension: string;
    l_NumofPartners: number;
    l_ProfSharingRatio: string;
    l_profSharingRatio_Disable: boolean;
    l_NumofEmplyrWorker: number;
    l_PermissibleQty: number;
    l_BalQty: number;
    l_BusinessArrangement_EC_YN: string;
    l_BusinessArrangement_LR_YN: string;
    l_BusinessArrangement_MS_YN: string;
    l_MS_Membership_Num: number;
    l_MS_NameofMilkSociety: string;
    l_MS_Vintage: string;
    MembershipCard_Upload: Ifile;
    l_MS_MembershipCard_Upload: string;
    l_MS_MembershipCardMimeType: string;
    l_MS_MemCardExtension: string;
    l_MS_MilkSold_Daily_Ltrs: string;
    l_MS_AgreedPrice_perltr: string;
    l_MS_OtherArrangement: string;
    l_MS_BankName: string;
    l_MS_BankNum: string;
    l_MS_BankIFSC: string;
    l_MS_Bank_BankingNorm_YN: string;
    l_LR_NumOfRetailers: string;
    l_LR_Relation_Years: number;
    l_LR_Name_Top1: string;
    l_LR_Contact_Top1: string;
    l_LR_Address_Top1: string;
    l_LR_Name_Top2: string;
    l_LR_Contact_Top2: string;
    l_LR_Address_Top2: string;
    l_LR_QtyDaily: number;
    l_LR_Avg_priceperLtr: number;
    l_EC_ShopName: string;
    l_EC_Locality: string;
    l_EC_UPI_YN: string;
    l_EC_Milk_Qty: string;
    l_EC_Curd_Qty: string;
    l_EC_Ghee_Qty: string;
    l_EC_Paneer_Qty: string;
    l_EC_Others_Qty: string;
    l_EC_Milk_Price: number;
    l_EC_Curd_Price: number;
    l_EC_Ghee_Price: number;
    l_EC_Paneer_Price: number;
    l_EC_Others_Price: number;
    l_Exp_CAttleFeed_Act: string;
    l_Exp_Electricity_Act: string;
    l_Exp_Insurance_Act: string;
    l_Exp_Lactation_Act: string;
    l_Exp_Others_Act: string;
    l_Exp_Act_Total: string;
    l_Exp_CAttleFeed_Calc: string;
    l_Exp_Electricity_Calc: string;
    l_Exp_Insurance_Calc: string;
    l_Exp_Lactation_Calc: string;
    l_Exp_Others_Calc: string;
    l_Exp_Cal_Total: string;
    p_ShopBusinessName: string;
    p_Locality: string;
    p_NumOfFamily: number;
    p_NumOfPartness: number;
    p_ProfSharingRatio: string;
    profSharingRatio_Disable: boolean;
    p_NumofEmplyrWorker: number;
    p_PremiseOwnership: string;
    p_NumofMilkmanSupplier: number;
    p_Name_Top1: string;
    p_Contact_Top1: string;
    p_Address_Top1: string;
    p_Name_Top2: string;
    p_Contact_Top2: string;
    p_Address_Top2: string;
    p_QtyOfMilkPurchase: string;
    p_AvgPricePerLtr: number;
    p_BigTank_YN: string;
    p_SmallTank_YN: string;
    p_MixTank_YN: string;
    p_NonRefTAnk_YN: string;
    p_UPI_YN: string;
    p_OtherProds: string;
    p_PermissibleQty: number;
    p_BalQty: number;
    p_Milk_Qty: number;
    p_Curd_Qty: number;
    p_Ghee_Qty: number;
    p_Paneer_Qty: number;
    p_Others_Qty: number;
    p_Milk_Price: number;
    p_Curd_Price: number;
    p_Ghee_Price: number;
    p_Paneer_Price: number;
    p_Others_Price: number;
    p_Exp_MilkPurchase_Act: string;
    p_Exp_Electricity_Act: string;
    p_Exp_ShopRent_Act: string;
    p_Exp_Salary_Act: string;
    p_Exp_Transport_Act: string;
    p_Exp_Other_Act: string;
    p_Exp_Act_Total: string;
    p_Exp_MilkPurchase_Calc: string;
    p_Exp_Electricity_Calc: string;
    p_Exp_ShopRent_Calc: string;
    p_Exp_Salary_Calc: string;
    p_Exp_Transport_Calc: string;
    p_Exp_Other_Calc: string;
    p_Exp_Calc_Total: string;
    other_Net_Income: number;
    other_Net_IncomeDetail: string;
    flO_PsId: string;

    toJson(): any;
    toJsonwithOutImage(): any;
}
export class DairyAndAlliedModel implements IDairyAndAlliedModel {
    private _applicationNo: string = "";
    public get applicationNo(): string {
        return this._applicationNo;
    }
    public set applicationNo(value: string) {
        this._applicationNo = value;
    }
    private _applicantCoappRef: string = "";
    public get applicantCoappRef(): string {
        return this._applicantCoappRef;
    }
    public set applicantCoappRef(value: string) {
        this._applicantCoappRef = value;
    }
    private _typeOfBusiness: string = "";
    public get typeOfBusiness(): string {
        return this._typeOfBusiness;
    }
    public set typeOfBusiness(value: string) {
        this._typeOfBusiness = value;
    }
    private _l_CountofCattle: string = "";
    public get l_CountofCattle(): string {
        return this._l_CountofCattle;
    }
    public set l_CountofCattle(value: string) {
        this._l_CountofCattle = value;
    }
    private _l_AccomodationInSqFt: string = "";
    public get l_AccomodationInSqFt(): string {
        return this._l_AccomodationInSqFt;
    }
    public set l_AccomodationInSqFt(value: string) {
        this._l_AccomodationInSqFt = value;
    }
    private _l_PerCattleProd: string = "";
    public get l_PerCattleProd(): string {
        return this._l_PerCattleProd;
    }
    public set l_PerCattleProd(value: string) {
        this._l_PerCattleProd = value;
    }
    private _l_CattleInsurance_YN: string = "";
    public get l_CattleInsurance_YN(): string {
        return this._l_CattleInsurance_YN;
    }
    public set l_CattleInsurance_YN(value: string) {
        this._l_CattleInsurance_YN = value;
    }
    private _l_NumOfCattleInsured: string = "";
    public get l_NumOfCattleInsured(): string {
        return this._l_NumOfCattleInsured;
    }
    public set l_NumOfCattleInsured(value: string) {
        this._l_NumOfCattleInsured = value;
    }
    private _l_MedReport_Remark: string = "";
    public get l_MedReport_Remark(): string {
        return this._l_MedReport_Remark;
    }
    public set l_MedReport_Remark(value: string) {
        this._l_MedReport_Remark = value;
    }
    private _l_MedReport_Title: string = "";
    public get l_MedReport_Title(): string {
        return this._l_MedReport_Title;
    }
    public set l_MedReport_Title(value: string) {
        this._l_MedReport_Title = value;
    }
    private _l_MedReport_Upload: string = "";
    public get l_MedReport_Upload(): string {
        return this._l_MedReport_Upload;
    }
    public set l_MedReport_Upload(value: string) {
        this._l_MedReport_Upload = value;
    }
    private _l_MedReport_UploadMimeType: string = "";
    public get l_MedReport_UploadMimeType(): string {
        return this._l_MedReport_UploadMimeType;
    }
    public set l_MedReport_UploadMimeType(value: string) {
        this._l_MedReport_UploadMimeType = value;
    }
    private _l_MedReport_UploadExtension: string = "";
    public get l_MedReport_UploadExtension(): string {
        return this._l_MedReport_UploadExtension;
    }
    public set l_MedReport_UploadExtension(value: string) {
        this._l_MedReport_UploadExtension = value;
    }
    private _l_NumofPartners: number = 0;
    public get l_NumofPartners(): number {
        return this._l_NumofPartners;
    }
    public set l_NumofPartners(value: number) {
        this._l_NumofPartners = ((value ?? "") == 0 ? Number(0) : Number(value));
        this.l_profSharingRatio_Disable = this._l_NumofPartners == 0;
    }
    private _l_profSharingRatio_Disable: boolean = false;
    public get l_profSharingRatio_Disable(): boolean {
        return this._l_profSharingRatio_Disable;
    }
    public set l_profSharingRatio_Disable(value: boolean) {
        this._l_profSharingRatio_Disable = value;
        if (value == true)
            this._l_ProfSharingRatio = "0";
    }
    private _l_ProfSharingRatio: string = "";
    public get l_ProfSharingRatio(): string {
        return this._l_ProfSharingRatio;
    }
    public set l_ProfSharingRatio(value: string) {
        this._l_ProfSharingRatio = value;
    }
    private _l_NumofEmplyrWorker: number = 0;
    public get l_NumofEmplyrWorker(): number {
        return this._l_NumofEmplyrWorker;
    }
    public set l_NumofEmplyrWorker(value: number) {
        this._l_NumofEmplyrWorker = value;
    }
    private _l_PermissibleQty: number = 0;
    public get l_PermissibleQty(): number {
        return this._l_PermissibleQty;
    }
    public set l_PermissibleQty(value: number) {
        this._l_PermissibleQty = value;
    }
    private _l_BalQty: number = 0;
    public get l_BalQty(): number {
        return this._l_BalQty;
    }
    public set l_BalQty(value: number) {
        this._l_BalQty = value;
    }
    private _l_BusinessArrangement_EC_YN: string = "";
    public get l_BusinessArrangement_EC_YN(): string {
        return this._l_BusinessArrangement_EC_YN;
    }
    public set l_BusinessArrangement_EC_YN(value: string) {
        this._l_BusinessArrangement_EC_YN = value;
    }
    private _l_BusinessArrangement_LR_YN: string = "";
    public get l_BusinessArrangement_LR_YN(): string {
        return this._l_BusinessArrangement_LR_YN;
    }
    public set l_BusinessArrangement_LR_YN(value: string) {
        this._l_BusinessArrangement_LR_YN = value;
    }
    private _l_BusinessArrangement_MS_YN: string = "";
    public get l_BusinessArrangement_MS_YN(): string {
        return this._l_BusinessArrangement_MS_YN;
    }
    public set l_BusinessArrangement_MS_YN(value: string) {
        this._l_BusinessArrangement_MS_YN = value;
    }
    private _l_MS_Membership_Num: number = 0;
    public get l_MS_Membership_Num(): number {
        return this._l_MS_Membership_Num;
    }
    public set l_MS_Membership_Num(value: number) {
        this._l_MS_Membership_Num = value;
    }
    private _l_MS_NameofMilkSociety: string = "";
    public get l_MS_NameofMilkSociety(): string {
        return this._l_MS_NameofMilkSociety;
    }
    public set l_MS_NameofMilkSociety(value: string) {
        this._l_MS_NameofMilkSociety = value;
    }
    private _l_MS_Vintage: string = "";
    public get l_MS_Vintage(): string {
        return this._l_MS_Vintage;
    }
    public set l_MS_Vintage(value: string) {
        this._l_MS_Vintage = value;
    }
    private _l_MS_MembershipCard_Upload: string = "";
    public get l_MS_MembershipCard_Upload(): string {
        return this._l_MS_MembershipCard_Upload;
    }
    public set l_MS_MembershipCard_Upload(value: string) {
        this._l_MS_MembershipCard_Upload = value;


    }
    private _l_MS_MembershipCardMimeType: string = "";
    public get l_MS_MembershipCardMimeType(): string {
        return this._l_MS_MembershipCardMimeType;
    }
    public set l_MS_MembershipCardMimeType(value: string) {
        this._l_MS_MembershipCardMimeType = value;
    }
    private _l_MS_MemCardExtension: string = "";
    public get l_MS_MemCardExtension(): string {
        return this._l_MS_MemCardExtension;
    }
    public set l_MS_MemCardExtension(value: string) {
        this._l_MS_MemCardExtension = value;
    }
    private _l_MS_MilkSold_Daily_Ltrs: string = "";
    public get l_MS_MilkSold_Daily_Ltrs(): string {
        return this._l_MS_MilkSold_Daily_Ltrs;
    }
    public set l_MS_MilkSold_Daily_Ltrs(value: string) {
        this._l_MS_MilkSold_Daily_Ltrs = value;
    }
    private _l_MS_AgreedPrice_perltr: string = "";
    public get l_MS_AgreedPrice_perltr(): string {
        return this._l_MS_AgreedPrice_perltr;
    }
    public set l_MS_AgreedPrice_perltr(value: string) {
        this._l_MS_AgreedPrice_perltr = value;
    }
    private _l_MS_OtherArrangement: string = "";
    public get l_MS_OtherArrangement(): string {
        return this._l_MS_OtherArrangement;
    }
    public set l_MS_OtherArrangement(value: string) {
        this._l_MS_OtherArrangement = value;
    }
    private _l_MS_BankName: string = "";
    public get l_MS_BankName(): string {
        return this._l_MS_BankName;
    }
    public set l_MS_BankName(value: string) {
        this._l_MS_BankName = value;
    }
    private _l_MS_BankNum: string = "";
    public get l_MS_BankNum(): string {
        return this._l_MS_BankNum;
    }
    public set l_MS_BankNum(value: string) {
        this._l_MS_BankNum = value;
    }
    private _l_MS_BankIFSC: string = "";
    public get l_MS_BankIFSC(): string {
        return this._l_MS_BankIFSC;
    }
    public set l_MS_BankIFSC(value: string) {
        this._l_MS_BankIFSC = value;
    }
    private _l_MS_Bank_BankingNorm_YN: string = "";
    public get l_MS_Bank_BankingNorm_YN(): string {
        return this._l_MS_Bank_BankingNorm_YN;
    }
    public set l_MS_Bank_BankingNorm_YN(value: string) {
        this._l_MS_Bank_BankingNorm_YN = value;
    }
    private _l_LR_NumOfRetailers: string = "";
    public get l_LR_NumOfRetailers(): string {
        return this._l_LR_NumOfRetailers;
    }
    public set l_LR_NumOfRetailers(value: string) {
        this._l_LR_NumOfRetailers = value;
    }
    private _l_LR_Relation_Years: number = 0;
    public get l_LR_Relation_Years(): number {
        return this._l_LR_Relation_Years;
    }
    public set l_LR_Relation_Years(value: number) {
        this._l_LR_Relation_Years = value;
    }
    private _l_LR_Name_Top1: string = "";
    public get l_LR_Name_Top1(): string {
        return this._l_LR_Name_Top1;
    }
    public set l_LR_Name_Top1(value: string) {
        this._l_LR_Name_Top1 = value;
    }
    private _l_LR_Contact_Top1: string = "";
    public get l_LR_Contact_Top1(): string {
        return this._l_LR_Contact_Top1;
    }
    public set l_LR_Contact_Top1(value: string) {
        this._l_LR_Contact_Top1 = value;
    }
    private _l_LR_Address_Top1: string = "";
    public get l_LR_Address_Top1(): string {
        return this._l_LR_Address_Top1;
    }
    public set l_LR_Address_Top1(value: string) {
        this._l_LR_Address_Top1 = value;
    }
    private _l_LR_Name_Top2: string = "";
    public get l_LR_Name_Top2(): string {
        return this._l_LR_Name_Top2;
    }
    public set l_LR_Name_Top2(value: string) {
        this._l_LR_Name_Top2 = value;
    }
    private _l_LR_Contact_Top2: string = "";
    public get l_LR_Contact_Top2(): string {
        return this._l_LR_Contact_Top2;
    }
    public set l_LR_Contact_Top2(value: string) {
        this._l_LR_Contact_Top2 = value;
    }
    private _l_LR_Address_Top2: string = "";
    public get l_LR_Address_Top2(): string {
        return this._l_LR_Address_Top2;
    }
    public set l_LR_Address_Top2(value: string) {
        this._l_LR_Address_Top2 = value;
    }
    private _l_LR_QtyDaily: number = 0;
    public get l_LR_QtyDaily(): number {
        return this._l_LR_QtyDaily;
    }
    public set l_LR_QtyDaily(value: number) {
        this._l_LR_QtyDaily = value;
    }
    private _l_LR_Avg_priceperLtr: number = 0;
    public get l_LR_Avg_priceperLtr(): number {
        return this._l_LR_Avg_priceperLtr;
    }
    public set l_LR_Avg_priceperLtr(value: number) {
        this._l_LR_Avg_priceperLtr = value;
    }
    private _l_EC_ShopName: string = "";
    public get l_EC_ShopName(): string {
        return this._l_EC_ShopName;
    }
    public set l_EC_ShopName(value: string) {
        this._l_EC_ShopName = value;
    }
    private _l_EC_Locality: string = "";
    public get l_EC_Locality(): string {
        return this._l_EC_Locality;
    }
    public set l_EC_Locality(value: string) {
        this._l_EC_Locality = value;
    }
    private _l_EC_UPI_YN: string = "";
    public get l_EC_UPI_YN(): string {
        return this._l_EC_UPI_YN;
    }
    public set l_EC_UPI_YN(value: string) {
        this._l_EC_UPI_YN = value;
    }
    private _l_EC_Milk_Qty: string = "";
    public get l_EC_Milk_Qty(): string {
        return this._l_EC_Milk_Qty;
    }
    public set l_EC_Milk_Qty(value: string) {
        this._l_EC_Milk_Qty = value;
    }
    private _l_EC_Curd_Qty: string = "";
    public get l_EC_Curd_Qty(): string {
        return this._l_EC_Curd_Qty;
    }
    public set l_EC_Curd_Qty(value: string) {
        this._l_EC_Curd_Qty = value;
    }
    private _l_EC_Ghee_Qty: string = "";
    public get l_EC_Ghee_Qty(): string {
        return this._l_EC_Ghee_Qty;
    }
    public set l_EC_Ghee_Qty(value: string) {
        this._l_EC_Ghee_Qty = value;
    }
    private _l_EC_Paneer_Qty: string = "";
    public get l_EC_Paneer_Qty(): string {
        return this._l_EC_Paneer_Qty;
    }
    public set l_EC_Paneer_Qty(value: string) {
        this._l_EC_Paneer_Qty = value;
    }
    private _l_EC_Others_Qty: string = "";
    public get l_EC_Others_Qty(): string {
        return this._l_EC_Others_Qty;
    }
    public set l_EC_Others_Qty(value: string) {
        this._l_EC_Others_Qty = value;
    }
    private _l_EC_Milk_Price: number = 0;
    public get l_EC_Milk_Price(): number {
        return this._l_EC_Milk_Price;
    }
    public set l_EC_Milk_Price(value: number) {
        this._l_EC_Milk_Price = value;
    }
    private _l_EC_Curd_Price: number = 0;
    public get l_EC_Curd_Price(): number {
        return this._l_EC_Curd_Price;
    }
    public set l_EC_Curd_Price(value: number) {
        this._l_EC_Curd_Price = value;
    }
    private _l_EC_Ghee_Price: number = 0;
    public get l_EC_Ghee_Price(): number {
        return this._l_EC_Ghee_Price;
    }
    public set l_EC_Ghee_Price(value: number) {
        this._l_EC_Ghee_Price = value;
    }
    private _l_EC_Paneer_Price: number = 0;
    public get l_EC_Paneer_Price(): number {
        return this._l_EC_Paneer_Price;
    }
    public set l_EC_Paneer_Price(value: number) {
        this._l_EC_Paneer_Price = value;
    }
    private _l_EC_Others_Price: number = 0;
    public get l_EC_Others_Price(): number {
        return this._l_EC_Others_Price;
    }
    public set l_EC_Others_Price(value: number) {
        this._l_EC_Others_Price = value;
    }
    private _l_Exp_CAttleFeed_Act: string = "";
    public get l_Exp_CAttleFeed_Act(): string {
        return this._l_Exp_CAttleFeed_Act;
    }
    public set l_Exp_CAttleFeed_Act(value: string) {
        this._l_Exp_CAttleFeed_Act = value;
    }
    private _l_Exp_Electricity_Act: string = "";
    public get l_Exp_Electricity_Act(): string {
        return this._l_Exp_Electricity_Act;
    }
    public set l_Exp_Electricity_Act(value: string) {
        this._l_Exp_Electricity_Act = value;
    }
    private _l_Exp_Insurance_Act: string = "";
    public get l_Exp_Insurance_Act(): string {
        return this._l_Exp_Insurance_Act;
    }
    public set l_Exp_Insurance_Act(value: string) {
        this._l_Exp_Insurance_Act = value;
    }
    private _l_Exp_Lactation_Act: string = "";
    public get l_Exp_Lactation_Act(): string {
        return this._l_Exp_Lactation_Act;
    }
    public set l_Exp_Lactation_Act(value: string) {
        this._l_Exp_Lactation_Act = value;
    }
    private _l_Exp_Others_Act: string = "";
    public get l_Exp_Others_Act(): string {
        return this._l_Exp_Others_Act;
    }
    public set l_Exp_Others_Act(value: string) {
        this._l_Exp_Others_Act = value;
    }
    private _l_Exp_Act_Total: string = "";
    public get l_Exp_Act_Total(): string {
        return this._l_Exp_Act_Total;
    }
    public set l_Exp_Act_Total(value: string) {
        this._l_Exp_Act_Total = value;
    }
    private _l_Exp_CAttleFeed_Calc: string = "";
    public get l_Exp_CAttleFeed_Calc(): string {
        return this._l_Exp_CAttleFeed_Calc;
    }
    public set l_Exp_CAttleFeed_Calc(value: string) {
        this._l_Exp_CAttleFeed_Calc = value;
    }
    private _l_Exp_Electricity_Calc: string = "";
    public get l_Exp_Electricity_Calc(): string {
        return this._l_Exp_Electricity_Calc;
    }
    public set l_Exp_Electricity_Calc(value: string) {
        this._l_Exp_Electricity_Calc = value;
    }
    private _l_Exp_Insurance_Calc: string = "";
    public get l_Exp_Insurance_Calc(): string {
        return this._l_Exp_Insurance_Calc;
    }
    public set l_Exp_Insurance_Calc(value: string) {
        this._l_Exp_Insurance_Calc = value;
    }
    private _l_Exp_Lactation_Calc: string = "";
    public get l_Exp_Lactation_Calc(): string {
        return this._l_Exp_Lactation_Calc;
    }
    public set l_Exp_Lactation_Calc(value: string) {
        this._l_Exp_Lactation_Calc = value;
    }
    private _l_Exp_Others_Calc: string = "";
    public get l_Exp_Others_Calc(): string {
        return this._l_Exp_Others_Calc;
    }
    public set l_Exp_Others_Calc(value: string) {
        this._l_Exp_Others_Calc = value;
    }
    private _l_Exp_Cal_Total: string = "";
    public get l_Exp_Cal_Total(): string {
        return this._l_Exp_Cal_Total;
    }
    public set l_Exp_Cal_Total(value: string) {
        this._l_Exp_Cal_Total = value;
    }
    private _p_ShopBusinessName: string = "";
    public get p_ShopBusinessName(): string {
        return this._p_ShopBusinessName;
    }
    public set p_ShopBusinessName(value: string) {
        this._p_ShopBusinessName = value;
    }
    private _p_Locality: string = "";
    public get p_Locality(): string {
        return this._p_Locality;
    }
    public set p_Locality(value: string) {
        this._p_Locality = value;
    }
    private _p_NumOfFamily: number = 0;
    public get p_NumOfFamily(): number {
        return this._p_NumOfFamily;
    }
    public set p_NumOfFamily(value: number) {
        this._p_NumOfFamily = value;
    }
    private _p_NumOfPartness: number = 0;
    public get p_NumOfPartness(): number {
        return this._p_NumOfPartness;
    }
    public set p_NumOfPartness(value: number) {
        this._p_NumOfPartness = ((value ?? "") == 0 ? Number(0) : Number(value));
        this.profSharingRatio_Disable = this._p_NumOfPartness == 0;
    }
    private _profSharingRatio_Disable: boolean = false;
    public get profSharingRatio_Disable(): boolean {
        return this._profSharingRatio_Disable;
    }
    public set profSharingRatio_Disable(value: boolean) {
        this._profSharingRatio_Disable = value;
        if (value == true)
            this._p_ProfSharingRatio = "0";
    }
    private _p_ProfSharingRatio: string = "";
    public get p_ProfSharingRatio(): string {
        return this._p_ProfSharingRatio;
    }
    public set p_ProfSharingRatio(value: string) {
        this._p_ProfSharingRatio = value;
    }
    private _p_NumofEmplyrWorker: number = 0;
    public get p_NumofEmplyrWorker(): number {
        return this._p_NumofEmplyrWorker;
    }
    public set p_NumofEmplyrWorker(value: number) {
        this._p_NumofEmplyrWorker = value;
    }
    private _p_PremiseOwnership: string = "";
    public get p_PremiseOwnership(): string {
        return this._p_PremiseOwnership;
    }
    public set p_PremiseOwnership(value: string) {
        this._p_PremiseOwnership = value;
    }
    private _p_NumofMilkmanSupplier: number = 0;
    public get p_NumofMilkmanSupplier(): number {
        return this._p_NumofMilkmanSupplier;
    }
    public set p_NumofMilkmanSupplier(value: number) {
        this._p_NumofMilkmanSupplier = value;
    }
    private _p_Name_Top1: string = "";
    public get p_Name_Top1(): string {
        return this._p_Name_Top1;
    }
    public set p_Name_Top1(value: string) {
        this._p_Name_Top1 = value;
    }
    private _p_Contact_Top1: string = "";
    public get p_Contact_Top1(): string {
        return this._p_Contact_Top1;
    }
    public set p_Contact_Top1(value: string) {
        this._p_Contact_Top1 = value;
    }
    private _p_Address_Top1: string = "";
    public get p_Address_Top1(): string {
        return this._p_Address_Top1;
    }
    public set p_Address_Top1(value: string) {
        this._p_Address_Top1 = value;
    }
    private _p_Name_Top2: string = "";
    public get p_Name_Top2(): string {
        return this._p_Name_Top2;
    }
    public set p_Name_Top2(value: string) {
        this._p_Name_Top2 = value;
    }
    private _p_Contact_Top2: string = "";
    public get p_Contact_Top2(): string {
        return this._p_Contact_Top2;
    }
    public set p_Contact_Top2(value: string) {
        this._p_Contact_Top2 = value;
    }
    private _p_Address_Top2: string = "";
    public get p_Address_Top2(): string {
        return this._p_Address_Top2;
    }
    public set p_Address_Top2(value: string) {
        this._p_Address_Top2 = value;
    }
    private _p_QtyOfMilkPurchase: string = "";
    public get p_QtyOfMilkPurchase(): string {
        return this._p_QtyOfMilkPurchase;
    }
    public set p_QtyOfMilkPurchase(value: string) {
        if(value===""){
            value="0";
        }
        this._p_QtyOfMilkPurchase = value;
    }
    private _p_AvgPricePerLtr: number = 0;
    public get p_AvgPricePerLtr(): number {
        return this._p_AvgPricePerLtr;
    }
    public set p_AvgPricePerLtr(value: number) {
        this._p_AvgPricePerLtr = value;
    }
    private _p_BigTank_YN: string = "";
    public get p_BigTank_YN(): string {
        return this._p_BigTank_YN;
    }
    public set p_BigTank_YN(value: string) {
        this._p_BigTank_YN = value;
    }
    private _p_SmallTank_YN: string = "";
    public get p_SmallTank_YN(): string {
        return this._p_SmallTank_YN;
    }
    public set p_SmallTank_YN(value: string) {
        this._p_SmallTank_YN = value;
    }
    private _p_MixTank_YN: string = "";
    public get p_MixTank_YN(): string {
        return this._p_MixTank_YN;
    }
    public set p_MixTank_YN(value: string) {
        this._p_MixTank_YN = value;
    }
    private _p_NonRefTAnk_YN: string = "";
    public get p_NonRefTAnk_YN(): string {
        return this._p_NonRefTAnk_YN;
    }
    public set p_NonRefTAnk_YN(value: string) {
        this._p_NonRefTAnk_YN = value;
    }
    private _p_UPI_YN: string = "";
    public get p_UPI_YN(): string {
        return this._p_UPI_YN;
    }
    public set p_UPI_YN(value: string) {
        this._p_UPI_YN = value;
    }
    private _p_OtherProds: string = "";
    public get p_OtherProds(): string {
        return this._p_OtherProds;
    }
    public set p_OtherProds(value: string) {
        this._p_OtherProds = value;
    }
    private _p_PermissibleQty: number = 0;
    public get p_PermissibleQty(): number {
        return this._p_PermissibleQty;
    }
    public set p_PermissibleQty(value: number) {
        this._p_PermissibleQty = value;
    }
    private _p_BalQty: number = 0;
    public get p_BalQty(): number {
        return this._p_BalQty;
    }
    public set p_BalQty(value: number) {
        this._p_BalQty = value;
    }
    private _p_Milk_Qty: number = 0;
    public get p_Milk_Qty(): number {
        return this._p_Milk_Qty;
    }
    public set p_Milk_Qty(value: number) {
        if(value.toString()===""){
            value=0;
        }
        this._p_Milk_Qty = value;
    }
    private _p_Curd_Qty: number = 0;
    public get p_Curd_Qty(): number {        
        return this._p_Curd_Qty;
    }
    public set p_Curd_Qty(value: number) {
        if(value.toString()===""){
           value=0;
        }
        this._p_Curd_Qty = value;
    }
    private _p_Ghee_Qty: number = 0;
    public get p_Ghee_Qty(): number {
        return this._p_Ghee_Qty;
    }
    public set p_Ghee_Qty(value: number) {
        if(value.toString()===""){
           value=0;
        }
        this._p_Ghee_Qty = value;
    }
    private _p_Paneer_Qty: number = 0;
    public get p_Paneer_Qty(): number {
        return this._p_Paneer_Qty;
    }
    public set p_Paneer_Qty(value: number) {
        if(value.toString()===""){
            value=0;
         }
        this._p_Paneer_Qty = value;
    }
    private _p_Others_Qty: number = 0;
    public get p_Others_Qty(): number {
        return this._p_Others_Qty;
    }
    public set p_Others_Qty(value: number) {
        if(value.toString()===""){
            value=0;
         }
        this._p_Others_Qty = value;
    }
    private _p_Milk_Price: number = 0;
    public get p_Milk_Price(): number {
        return this._p_Milk_Price;
    }
    public set p_Milk_Price(value: number) {
        if(value.toString()===""){
            value=0;
         }
        this._p_Milk_Price = value;
    }
    private _p_Curd_Price: number = 0;
    public get p_Curd_Price(): number {
        return this._p_Curd_Price;
    }
    public set p_Curd_Price(value: number) {
        if(value.toString()===""){
            value=0;
         }
        this._p_Curd_Price = value;
    }
    private _p_Ghee_Price: number = 0;
    public get p_Ghee_Price(): number {
        return this._p_Ghee_Price;
    }
    public set p_Ghee_Price(value: number) {
        if(value.toString()===""){
            value=0;
         }
        this._p_Ghee_Price = value;
    }
    private _p_Paneer_Price: number = 0;
    public get p_Paneer_Price(): number {
        return this._p_Paneer_Price;
    }
    public set p_Paneer_Price(value: number) {
        if(value.toString()===""){
            value=0;
         }
        this._p_Paneer_Price = value;
    }
    private _p_Others_Price: number = 0;
    public get p_Others_Price(): number {
        return this._p_Others_Price;
    }
    public set p_Others_Price(value: number) {
        if(value.toString()===""){
            value=0;
         }
        this._p_Others_Price = value;
    }
    private _p_Exp_MilkPurchase_Act: string = "";
    public get p_Exp_MilkPurchase_Act(): string {
        return this._p_Exp_MilkPurchase_Act;
    }
    public set p_Exp_MilkPurchase_Act(value: string) {
        this._p_Exp_MilkPurchase_Act = value;
    }
    private _p_Exp_Electricity_Act: string = "";
    public get p_Exp_Electricity_Act(): string {
        return this._p_Exp_Electricity_Act;
    }
    public set p_Exp_Electricity_Act(value: string) {
        this._p_Exp_Electricity_Act = value;
    }
    private _p_Exp_ShopRent_Act: string = "";
    public get p_Exp_ShopRent_Act(): string {
        return this._p_Exp_ShopRent_Act;
    }
    public set p_Exp_ShopRent_Act(value: string) {
        this._p_Exp_ShopRent_Act = value;
    }
    private _p_Exp_Salary_Act: string = "";
    public get p_Exp_Salary_Act(): string {
        return this._p_Exp_Salary_Act;
    }
    public set p_Exp_Salary_Act(value: string) {
        this._p_Exp_Salary_Act = value;
    }
    private _p_Exp_Transport_Act: string = "";
    public get p_Exp_Transport_Act(): string {
        return this._p_Exp_Transport_Act;
    }
    public set p_Exp_Transport_Act(value: string) {
        this._p_Exp_Transport_Act = value;
    }
    private _p_Exp_Other_Act: string = "";
    public get p_Exp_Other_Act(): string {
        return this._p_Exp_Other_Act;
    }
    public set p_Exp_Other_Act(value: string) {
        this._p_Exp_Other_Act = value;
    }
    private _p_Exp_Act_Total: string = "";
    public get p_Exp_Act_Total(): string {
        return this._p_Exp_Act_Total;
    }
    public set p_Exp_Act_Total(value: string) {
        this._p_Exp_Act_Total = value;
    }
    private _p_Exp_MilkPurchase_Calc: string = "";
    public get p_Exp_MilkPurchase_Calc(): string {
        return this._p_Exp_MilkPurchase_Calc;
    }
    public set p_Exp_MilkPurchase_Calc(value: string) {
        this._p_Exp_MilkPurchase_Calc = value;
    }
    private _p_Exp_Electricity_Calc: string = "";
    public get p_Exp_Electricity_Calc(): string {
        return this._p_Exp_Electricity_Calc;
    }
    public set p_Exp_Electricity_Calc(value: string) {
        this._p_Exp_Electricity_Calc = value;
    }
    private _p_Exp_ShopRent_Calc: string = "";
    public get p_Exp_ShopRent_Calc(): string {
        return this._p_Exp_ShopRent_Calc;
    }
    public set p_Exp_ShopRent_Calc(value: string) {
        this._p_Exp_ShopRent_Calc = value;
    }
    private _p_Exp_Salary_Calc: string = "";
    public get p_Exp_Salary_Calc(): string {
        return this._p_Exp_Salary_Calc;
    }
    public set p_Exp_Salary_Calc(value: string) {
        this._p_Exp_Salary_Calc = value;
    }
    private _p_Exp_Transport_Calc: string = "";
    public get p_Exp_Transport_Calc(): string {
        return this._p_Exp_Transport_Calc;
    }
    public set p_Exp_Transport_Calc(value: string) {
        this._p_Exp_Transport_Calc = value;
    }
    private _p_Exp_Other_Calc: string = "";
    public get p_Exp_Other_Calc(): string {
        return this._p_Exp_Other_Calc;
    }
    public set p_Exp_Other_Calc(value: string) {
        this._p_Exp_Other_Calc = value;
    }
    private _p_Exp_Calc_Total: string = "";
    public get p_Exp_Calc_Total(): string {
        return this._p_Exp_Calc_Total;
    }
    public set p_Exp_Calc_Total(value: string) {
        this._p_Exp_Calc_Total = value;
    }
    private _other_Net_Income: number = 0;
    public get other_Net_Income(): number {
        return this._other_Net_Income;
    }
    public set other_Net_Income(value: number) {
        if(value.toString()===""){
            value=0;
         }
        this._other_Net_Income = value;
    }
    private _other_Net_IncomeDetail: string = "";
    public get other_Net_IncomeDetail(): string {
        return this._other_Net_IncomeDetail;
    }
    public set other_Net_IncomeDetail(value: string) {
        this._other_Net_IncomeDetail = value;
    }
    private _flO_PsId: string = "";
    public get flO_PsId(): string {
        return this._flO_PsId;
    }
    public set flO_PsId(value: string) {
        this._flO_PsId = value;
    }

    constructor(params?: IDairyAndAlliedModel) {
        if (params) {
            common.ObjectMapping(params, this);
            this.loanAccountNumber = params.loanAccountNumber;
            this.MembershipCard_Upload = {
                extension: this._l_MS_MemCardExtension,
                format: this._l_MS_MembershipCardMimeType,
                file: this._l_MS_MembershipCard_Upload,
                referenceNo: this._l_MS_MembershipCard_Upload
            } as Ifile;
        }
    }
    private _MembershipCard_Upload: Ifile = new file();
    public get MembershipCard_Upload(): Ifile {
        return this._MembershipCard_Upload;
    }
    public set MembershipCard_Upload(value: Ifile) {
        this._MembershipCard_Upload = value;
        this.l_MS_MembershipCard_Upload = value.file;
        this.l_MS_MemCardExtension = value.extension;
        this.l_MS_MembershipCardMimeType = value.format;
    }
    loanAccountNumber: string = "";

    toJson() {
        return {
            "LoanAccountNumber": this.loanAccountNumber,
            "ApplicantCoappRef": this.applicantCoappRef,
            "ApplicationNo": this.applicationNo,
            "FLO_PsId": this.flO_PsId,
            "L_AccomodationInSqFt": this.l_AccomodationInSqFt,
            "L_BalQty": this.l_BalQty,
            "L_BusinessArrangement_EC_YN": this.l_BusinessArrangement_EC_YN,
            "L_BusinessArrangement_LR_YN": this.l_BusinessArrangement_LR_YN,
            "L_BusinessArrangement_MS_YN": this.l_BusinessArrangement_MS_YN,
            "L_CattleInsurance_YN": this.l_CattleInsurance_YN,
            "L_CountofCattle": this.l_CountofCattle,
            "L_EC_Curd_Price": this.l_EC_Curd_Price,
            "L_EC_Curd_Qty": this.l_EC_Curd_Qty,
            "L_EC_Ghee_Price": this.l_EC_Ghee_Price,
            "L_EC_Ghee_Qty": this.l_EC_Ghee_Qty,
            "L_EC_Locality": this.l_EC_Locality,
            "L_EC_Milk_Price": this.l_EC_Milk_Price,
            "L_EC_Milk_Qty": this.l_EC_Milk_Qty,
            "L_EC_Others_Price": this.l_EC_Others_Price,
            "L_EC_Others_Qty": this.l_EC_Others_Qty,
            "L_EC_Paneer_Price": this.l_EC_Paneer_Price,
            "L_EC_Paneer_Qty": this.l_EC_Paneer_Qty,
            "L_EC_ShopName": this.l_EC_ShopName,
            "L_EC_UPI_YN": this.l_EC_UPI_YN,
            "L_Exp_Act_Total": this.l_Exp_Act_Total,
            "L_Exp_CAttleFeed_Act": this.l_Exp_CAttleFeed_Act,
            "L_Exp_CAttleFeed_Calc": this.l_Exp_CAttleFeed_Calc,
            "L_Exp_Cal_Total": this.l_Exp_Cal_Total,
            "L_Exp_Electricity_Act": this.l_Exp_Electricity_Act,
            "L_Exp_Electricity_Calc": this.l_Exp_Electricity_Calc,
            "L_Exp_Insurance_Act": this.l_Exp_Insurance_Act,
            "L_Exp_Insurance_Calc": this.l_Exp_Insurance_Calc,
            "L_Exp_Lactation_Act": this.l_Exp_Lactation_Act,
            "L_Exp_Lactation_Calc": this.l_Exp_Lactation_Calc,
            "L_Exp_Others_Act": this.l_Exp_Others_Act,
            "L_Exp_Others_Calc": this.l_Exp_Others_Calc,
            "L_LR_Address_Top1": this.l_LR_Address_Top1,
            "L_LR_Address_Top2": this.l_LR_Address_Top2,
            "L_LR_Avg_priceperLtr": this.l_LR_Avg_priceperLtr,
            "L_LR_Contact_Top1": this.l_LR_Contact_Top1,
            "L_LR_Contact_Top2": this.l_LR_Contact_Top2,
            "L_LR_Name_Top1": this.l_LR_Name_Top1,
            "L_LR_Name_Top2": this.l_LR_Name_Top2,
            "L_LR_NumOfRetailers": this.l_LR_NumOfRetailers,
            "L_LR_QtyDaily": this.l_LR_QtyDaily,
            "L_LR_Relation_Years": this.l_LR_Relation_Years,
            "L_MS_AgreedPrice_perltr": this.l_MS_AgreedPrice_perltr,
            "L_MS_BankIFSC": this.l_MS_BankIFSC,
            "L_MS_BankName": this.l_MS_BankName,
            "L_MS_BankNum": this.l_MS_BankNum,
            "L_MS_Bank_BankingNorm_YN": this.l_MS_Bank_BankingNorm_YN,
            "L_MS_MembershipCard_Upload": this.l_MS_MembershipCard_Upload,
            "L_MS_MembershipCardMimeType": this.l_MS_MembershipCardMimeType,
            "L_MS_MemCardExtension": this.l_MS_MemCardExtension,
            "L_MS_Membership_Num": this.l_MS_Membership_Num,
            "L_MS_MilkSold_Daily_Ltrs": this.l_MS_MilkSold_Daily_Ltrs,
            "L_MS_NameofMilkSociety": this.l_MS_NameofMilkSociety,
            "L_MS_OtherArrangement": this.l_MS_OtherArrangement,
            "L_MS_Vintage": this.l_MS_Vintage,
            "L_MedReport_Remark": this.l_MedReport_Remark,
            "L_MedReport_Title": this.l_MedReport_Title,
            "L_MedReport_Upload": this.l_MedReport_Upload,
            "L_MedReport_UploadMimeType": this.l_MedReport_UploadMimeType,
            "L_MedReport_UploadExtension": this.l_MedReport_UploadExtension,
            "L_NumOfCattleInsured": this.l_NumOfCattleInsured,
            "L_NumofEmplyrWorker": this.l_NumofEmplyrWorker,
            "L_NumofPartners": this.l_NumofPartners,
            "L_PerCattleProd": this.l_PerCattleProd,
            "L_PermissibleQty": this.l_PermissibleQty,
            "L_ProfSharingRatio": this.l_ProfSharingRatio,
            "Other_Net_Income": this.other_Net_Income.toString() === "" ? "0" : this.other_Net_Income,
            "Other_Net_IncomeDetail": this.other_Net_IncomeDetail,
            "P_Address_Top1": this.p_Address_Top1,
            "P_Address_Top2": this.p_Address_Top2,
            "P_AvgPricePerLtr": this.p_AvgPricePerLtr,
            "P_BalQty": this.p_BalQty,
            "P_BigTank_YN": this.p_BigTank_YN,
            "P_Contact_Top1": this.p_Contact_Top1,
            "P_Contact_Top2": this.p_Contact_Top2,
            "P_Curd_Price": this.p_Curd_Price,
            "P_Curd_Qty": this.p_Curd_Qty,
            "P_Exp_Act_Total": this.p_Exp_Act_Total,
            "P_Exp_Calc_Total": this.p_Exp_Calc_Total,
            "P_Exp_Electricity_Act": this.p_Exp_Electricity_Act,
            "P_Exp_Electricity_Calc": this.p_Exp_Electricity_Calc,
            "P_Exp_MilkPurchase_Act": this.p_Exp_MilkPurchase_Act,
            "P_Exp_MilkPurchase_Calc": this.p_Exp_MilkPurchase_Calc,
            "P_Exp_Other_Act": this.p_Exp_Other_Act,
            "P_Exp_Other_Calc": this.p_Exp_Other_Calc,
            "P_Exp_Salary_Act": this.p_Exp_Salary_Act,
            "P_Exp_Salary_Calc": this.p_Exp_Salary_Calc,
            "P_Exp_ShopRent_Act": this.p_Exp_ShopRent_Act,
            "P_Exp_ShopRent_Calc": this.p_Exp_ShopRent_Calc,
            "P_Exp_Transport_Act": this.p_Exp_Transport_Act,
            "P_Exp_Transport_Calc": this.p_Exp_Transport_Calc,
            "P_Ghee_Price": this.p_Ghee_Price,
            "P_Ghee_Qty": this.p_Ghee_Qty,
            "P_Locality": this.p_Locality,
            "P_Milk_Price": this.p_Milk_Price,
            "P_Milk_Qty": this.p_Milk_Qty,
            "P_MixTank_YN": this.p_MixTank_YN,
            "P_Name_Top1": this.p_Name_Top1,
            "P_Name_Top2": this.p_Name_Top2,
            "P_NonRefTAnk_YN": this.p_NonRefTAnk_YN,
            "P_NumOfFamily": this.p_NumOfFamily,
            "P_NumOfPartness": this.p_NumOfPartness,
            "P_NumofEmplyrWorker": this.p_NumofEmplyrWorker,
            "P_NumofMilkmanSupplier": this.p_NumofMilkmanSupplier,
            "P_OtherProds": this.p_OtherProds,
            "P_Others_Price": this.p_Others_Price,
            "P_Others_Qty": this.p_Others_Qty,
            "P_Paneer_Price": this.p_Paneer_Price,
            "P_Paneer_Qty": this.p_Paneer_Qty,
            "P_PermissibleQty": this.p_PermissibleQty,
            "P_PremiseOwnership": this.p_PremiseOwnership,
            "P_ProfSharingRatio": this.p_ProfSharingRatio,
            "P_QtyOfMilkPurchase": this.p_QtyOfMilkPurchase,
            "P_ShopBusinessName": this.p_ShopBusinessName,
            "P_SmallTank_YN": this.p_SmallTank_YN,
            "P_UPI_YN": this.p_UPI_YN,
            "SourceThrough": "LOS",
            "TypeOfBusiness": this.typeOfBusiness


        }
    }

    toJsonwithOutImage() {
        return {
            "LoanAccountNumber": this.loanAccountNumber,
            "ApplicantCoappRef": this.applicantCoappRef,
            "ApplicationNo": this.applicationNo,
            "FLO_PsId": this.flO_PsId,
            "L_AccomodationInSqFt": this.l_AccomodationInSqFt,
            "L_BalQty": this.l_BalQty,
            "L_BusinessArrangement_EC_YN": this.l_BusinessArrangement_EC_YN,
            "L_BusinessArrangement_LR_YN": this.l_BusinessArrangement_LR_YN,
            "L_BusinessArrangement_MS_YN": this.l_BusinessArrangement_MS_YN,
            "L_CattleInsurance_YN": this.l_CattleInsurance_YN,
            "L_CountofCattle": this.l_CountofCattle,
            "L_EC_Curd_Price": this.l_EC_Curd_Price,
            "L_EC_Curd_Qty": this.l_EC_Curd_Qty,
            "L_EC_Ghee_Price": this.l_EC_Ghee_Price,
            "L_EC_Ghee_Qty": this.l_EC_Ghee_Qty,
            "L_EC_Locality": this.l_EC_Locality,
            "L_EC_Milk_Price": this.l_EC_Milk_Price,
            "L_EC_Milk_Qty": this.l_EC_Milk_Qty,
            "L_EC_Others_Price": this.l_EC_Others_Price,
            "L_EC_Others_Qty": this.l_EC_Others_Qty,
            "L_EC_Paneer_Price": this.l_EC_Paneer_Price,
            "L_EC_Paneer_Qty": this.l_EC_Paneer_Qty,
            "L_EC_ShopName": this.l_EC_ShopName,
            "L_EC_UPI_YN": this.l_EC_UPI_YN,
            "L_Exp_Act_Total": this.l_Exp_Act_Total,
            "L_Exp_CAttleFeed_Act": this.l_Exp_CAttleFeed_Act,
            "L_Exp_CAttleFeed_Calc": this.l_Exp_CAttleFeed_Calc,
            "L_Exp_Cal_Total": this.l_Exp_Cal_Total,
            "L_Exp_Electricity_Act": this.l_Exp_Electricity_Act,
            "L_Exp_Electricity_Calc": this.l_Exp_Electricity_Calc,
            "L_Exp_Insurance_Act": this.l_Exp_Insurance_Act,
            "L_Exp_Insurance_Calc": this.l_Exp_Insurance_Calc,
            "L_Exp_Lactation_Act": this.l_Exp_Lactation_Act,
            "L_Exp_Lactation_Calc": this.l_Exp_Lactation_Calc,
            "L_Exp_Others_Act": this.l_Exp_Others_Act,
            "L_Exp_Others_Calc": this.l_Exp_Others_Calc,
            "L_LR_Address_Top1": this.l_LR_Address_Top1,
            "L_LR_Address_Top2": this.l_LR_Address_Top2,
            "L_LR_Avg_priceperLtr": this.l_LR_Avg_priceperLtr,
            "L_LR_Contact_Top1": this.l_LR_Contact_Top1,
            "L_LR_Contact_Top2": this.l_LR_Contact_Top2,
            "L_LR_Name_Top1": this.l_LR_Name_Top1,
            "L_LR_Name_Top2": this.l_LR_Name_Top2,
            "L_LR_NumOfRetailers": this.l_LR_NumOfRetailers,
            "L_LR_QtyDaily": this.l_LR_QtyDaily,
            "L_LR_Relation_Years": this.l_LR_Relation_Years,
            "L_MS_AgreedPrice_perltr": this.l_MS_AgreedPrice_perltr,
            "L_MS_BankIFSC": this.l_MS_BankIFSC,
            "L_MS_BankName": this.l_MS_BankName,
            "L_MS_BankNum": this.l_MS_BankNum,
            "L_MS_Bank_BankingNorm_YN": this.l_MS_Bank_BankingNorm_YN,
            "L_MS_Membership_Num": this.l_MS_Membership_Num,
            "L_MS_MilkSold_Daily_Ltrs": this.l_MS_MilkSold_Daily_Ltrs,
            "L_MS_NameofMilkSociety": this.l_MS_NameofMilkSociety,
            "L_MS_OtherArrangement": this.l_MS_OtherArrangement,
            "L_MS_Vintage": this.l_MS_Vintage,
            "L_MedReport_Remark": this.l_MedReport_Remark,
            "L_MedReport_UploadMimeType": this.l_MedReport_UploadMimeType,
            "L_MedReport_UploadExtension": this.l_MedReport_UploadExtension,
            "L_MS_MembershipCardMimeType": this.l_MS_MembershipCardMimeType,
            "L_MS_MemCardExtension": this.l_MS_MemCardExtension,
            "L_MedReport_Title": this.l_MedReport_Title,
            "L_NumOfCattleInsured": this.l_NumOfCattleInsured,
            "L_NumofEmplyrWorker": this.l_NumofEmplyrWorker,
            "L_NumofPartners": this.l_NumofPartners,
            "L_PerCattleProd": this.l_PerCattleProd,
            "L_PermissibleQty": this.l_PermissibleQty,
            "L_ProfSharingRatio": this.l_ProfSharingRatio,
            "Other_Net_Income": this.other_Net_Income.toString() === "" ? "0" : this.other_Net_Income,
            "Other_Net_IncomeDetail": this.other_Net_IncomeDetail,
            "P_Address_Top1": this.p_Address_Top1,
            "P_Address_Top2": this.p_Address_Top2,
            "P_AvgPricePerLtr": this.p_AvgPricePerLtr,
            "P_BalQty": this.p_BalQty,
            "P_BigTank_YN": this.p_BigTank_YN,
            "P_Contact_Top1": this.p_Contact_Top1,
            "P_Contact_Top2": this.p_Contact_Top2,
            "P_Curd_Price": this.p_Curd_Price,
            "P_Curd_Qty": this.p_Curd_Qty,
            "P_Exp_Act_Total": this.p_Exp_Act_Total,
            "P_Exp_Calc_Total": this.p_Exp_Calc_Total,
            "P_Exp_Electricity_Act": this.p_Exp_Electricity_Act,
            "P_Exp_Electricity_Calc": this.p_Exp_Electricity_Calc,
            "P_Exp_MilkPurchase_Act": this.p_Exp_MilkPurchase_Act,
            "P_Exp_MilkPurchase_Calc": this.p_Exp_MilkPurchase_Calc,
            "P_Exp_Other_Act": this.p_Exp_Other_Act,
            "P_Exp_Other_Calc": this.p_Exp_Other_Calc,
            "P_Exp_Salary_Act": this.p_Exp_Salary_Act,
            "P_Exp_Salary_Calc": this.p_Exp_Salary_Calc,
            "P_Exp_ShopRent_Act": this.p_Exp_ShopRent_Act,
            "P_Exp_ShopRent_Calc": this.p_Exp_ShopRent_Calc,
            "P_Exp_Transport_Act": this.p_Exp_Transport_Act,
            "P_Exp_Transport_Calc": this.p_Exp_Transport_Calc,
            "P_Ghee_Price": this.p_Ghee_Price,
            "P_Ghee_Qty": this.p_Ghee_Qty,
            "P_Locality": this.p_Locality,
            "P_Milk_Price": this.p_Milk_Price,
            "P_Milk_Qty": this.p_Milk_Qty,
            "P_MixTank_YN": this.p_MixTank_YN,
            "P_Name_Top1": this.p_Name_Top1,
            "P_Name_Top2": this.p_Name_Top2,
            "P_NonRefTAnk_YN": this.p_NonRefTAnk_YN,
            "P_NumOfFamily": this.p_NumOfFamily,
            "P_NumOfPartness": this.p_NumOfPartness,
            "P_NumofEmplyrWorker": this.p_NumofEmplyrWorker,
            "P_NumofMilkmanSupplier": this.p_NumofMilkmanSupplier,
            "P_OtherProds": this.p_OtherProds,
            "P_Others_Price": this.p_Others_Price,
            "P_Others_Qty": this.p_Others_Qty,
            "P_Paneer_Price": this.p_Paneer_Price,
            "P_Paneer_Qty": this.p_Paneer_Qty,
            "P_PermissibleQty": this.p_PermissibleQty,
            "P_PremiseOwnership": this.p_PremiseOwnership,
            "P_ProfSharingRatio": this.p_ProfSharingRatio,
            "P_QtyOfMilkPurchase": this.p_QtyOfMilkPurchase,
            "P_ShopBusinessName": this.p_ShopBusinessName,
            "P_SmallTank_YN": this.p_SmallTank_YN,
            "P_UPI_YN": this.p_UPI_YN,
            "SourceThrough": "LOS",
            "TypeOfBusiness": this.typeOfBusiness


        }
    }

}

export interface IMilkPurchaseConfigValues {
    tankType: string;
    quantity: number;
    electricity: number;
}

export class MilkPurchaseConfigValues implements IMilkPurchaseConfigValues {

    tankType: string = '';
    quantity: number = 0;
    electricity: number = 0;

    /**
     *
     */
    constructor(param: IMilkPurchaseConfigValues) {
        if (param) {
            this.electricity = param.electricity;
            this.quantity = param.quantity;
            this.tankType = param.tankType;
        }

    }

}
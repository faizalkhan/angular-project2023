export interface ILegalDashboardModel {
    lanid: string;
    primaryApplicantName: string; 
    loanType:string;
    mcCode:string;
    assignedDate:Date;
    caseStatus:string;
}

export class LegalDashboardModel implements ILegalDashboardModel {
    lanid: string='';
    primaryApplicantName: string=''; 
    loanType:string='';
    mcCode:string='';
    assignedDate:Date=new Date();
    caseStatus:string='';

    /**
     *
     */
    constructor(param?:ILegalDashboardModel) {
        if(param){
        this.lanid=param.lanid;
        this.primaryApplicantName=param.primaryApplicantName;
        this.loanType=param.loanType;
        this.mcCode=param.mcCode;
        this.assignedDate=param.assignedDate;
        this.caseStatus=param.caseStatus;

        }
        
    }
}


export interface LegalVendorDashboardModel {
    lanid: string;
    primaryApplicantName: string; 
    loanType:string;
    mcCode:string;
    assignedDate:Date;
    caseStatus:string;
}

export interface TechnicalVendorDashboardModel {
    lanid: string;
    primaryApplicantName: string; 
    loanType:string;
    mcCode:string;
    assignedDate:Date;
    caseStatus:string;
}
export interface ILegalVendordParamModel {
    mcCode:string;
    category:string;
}

export interface LegalRequestParam{
    lan:string;
    loginPSID:string;
    apiInvokeDateTime:Date;
    role:string;
  }

  export interface TechnicalRequestParam{
    lan:string;
    loginPSID:string;
    apiInvokeDateTime:Date;
    role:string;
  }

export interface ILegalCasedModel {
    lan: string;
    loginPSID: string; 
    role:string;    
    caseStatus:string;    
    mcCode:string;    
    mcName:string;    
    loanType:string;    
    geoLocation:string;    
    applicantName:string;    
    appliedAmount:number;    
    addressOfProperty:string;      
    selectedLegalVendor:string;    
    assignment_DateTime:Date;    
    legalDocumentsInfo:DocumentInfo[];
    vendorDocumentsInfo:DocumentInfo[];
    bcM_Remark:string;    
    legal_Remark:string;    
    legal_Report_YN:string;    
    legal_Report_Ref:string;    
    title_Report_YN:string;    
    title_Report_Ref:string;    
    bcmLegalCaseSummary:string;    
    decision_Legal:string;
    decision_LegalBCM:string;     
    isAgreed:boolean;    
    eligibleLegalVendors:string;
    property_OwnerName:string;
    property_Address:string;
    chainFlow:string;
    boundaries_East:string;
    boundaries_West:string;
    boundaries_South:string;
    boundaries_North:string;
    credit_Remark:string;
    sendBackNotes:string;
}

export class LegalCasedModel implements ILegalCasedModel{
     constructor(param:ILegalCasedModel) {
        this.lan=param.lan;
        this.loginPSID=param.loginPSID;
        this.role=param.role;
        this.caseStatus=param.caseStatus;
        this.mcCode=param.mcCode;
        this.mcName=param.mcName;
        this.loanType=param.loanType;
        this.geoLocation=param.geoLocation;
        this.applicantName=param.applicantName;
        this.appliedAmount=param.appliedAmount;
        this.addressOfProperty=param.addressOfProperty;
        this.selectedLegalVendor=param.selectedLegalVendor;
        this.assignment_DateTime=param.assignment_DateTime;
        this.legalDocumentsInfo=param.legalDocumentsInfo;
        this.vendorDocumentsInfo=param.vendorDocumentsInfo;
        this.bcM_Remark=param.bcM_Remark;
        this.legal_Remark=param.legal_Remark;
        this.legal_Report_YN=param.legal_Report_YN;
        this.legal_Report_Ref=param.legal_Report_Ref;
        this.title_Report_YN=param.title_Report_YN;
        this.title_Report_Ref=param.title_Report_Ref;
        this.bcmLegalCaseSummary=param.bcmLegalCaseSummary;
        this.decision_Legal=param.decision_Legal;         
        this.decision_LegalBCM=param.decision_LegalBCM;
        this.isAgreed=param.isAgreed;
        this.eligibleLegalVendors=param.eligibleLegalVendors;
        this.property_OwnerName=param.property_OwnerName;
        this.property_Address=param.property_Address;
        this.chainFlow=param.chainFlow;
        this.boundaries_East=param.boundaries_East;
        this.boundaries_West=param.boundaries_West;
        this.boundaries_South=param.boundaries_South;
        this.boundaries_North=param.boundaries_North;
        this.credit_Remark=param.credit_Remark;
        this.sendBackNotes=param.sendBackNotes
    }
    lan: string;
    loginPSID: string; 
    role:string;    
    caseStatus:string;    
    mcCode:string;    
    mcName:string;    
    loanType:string;    
    geoLocation:string;    
    applicantName:string;    
    appliedAmount:number;    
    addressOfProperty:string;      
    selectedLegalVendor:string;    
    assignment_DateTime:Date;    
    legalDocumentsInfo:DocumentInfo[];
    vendorDocumentsInfo:DocumentInfo[];
    bcM_Remark:string;    
    legal_Remark:string;    
    legal_Report_YN:string;    
    legal_Report_Ref:string;    
    title_Report_YN:string;    
    title_Report_Ref:string;    
    bcmLegalCaseSummary:string;    
    decision_Legal:string;
    decision_LegalBCM:string;    
    isAgreed:boolean; 
    eligibleLegalVendors:string;

    private _propertyOwnerName:string='';
    public get property_OwnerName(): string {
        return this._propertyOwnerName;
    }
    public set property_OwnerName(value: string) {  
        this._propertyOwnerName = value;       
    }

    private _propertyAddress:string='';
    public get property_Address(): string {
        return this._propertyAddress;
    }
    public set property_Address(value: string) {  
        this._propertyAddress = value;       
    }

    private _chainFlow:string='';
    public get chainFlow(): string {
        return this._chainFlow;
    }
    public set chainFlow(value: string) {  
        this._chainFlow = value;       
    }

    private _boundariesEast:string='';
    public get boundaries_East(): string {
        return this._boundariesEast;
    }
    public set boundaries_East(value: string) {  
        this._boundariesEast = value;       
    }

    private _boundariesWest:string='';
    public get boundaries_West(): string {
        return this._boundariesWest;
    }
    public set boundaries_West(value: string) {  
        this._boundariesWest = value;       
    }

    private _boundariesSouth:string='';
    public get boundaries_South(): string {
        return this._boundariesSouth;
    }
    public set boundaries_South(value: string) {  
        this._boundariesSouth = value;       
    }

    private _boundariesNorth:string='';
    public get boundaries_North(): string {
        return this._boundariesNorth;
    }
    public set boundaries_North(value: string) {  
        this._boundariesNorth = value;       
    } 

    private _creditRemark:string='';
    public get credit_Remark(): string {
        return this._boundariesNorth;
    }
    public set credit_Remark(value: string) {  
        this._creditRemark = value;       
    } 
     
    sendBackNotes:string;


    toJSON(): any {
        return {

            "lan": this.lan,
            "loginPSID": this.loginPSID,
            "role":this.role,
            "caseStatus":this.caseStatus,
            "mcCode":this.mcCode,  
            "mcName":this.mcName,
            "loanType":this.loanType,  
            "geoLocation":this.geoLocation,  
            "applicantName":this.applicantName,
            "appliedAmount": this.appliedAmount,    
            "addressOfProperty":this.addressOfProperty,    
            "selectedLegalVendor":this.selectedLegalVendor,
            "assignment_DateTime:Date":this.assignment_DateTime,    
            "legalDocumentsInfo": this.legalDocumentsInfo,
            "vendorDocumentsInfo": this.vendorDocumentsInfo,
            "bcM_Remark":this.bcM_Remark,    
            "legal_Remark":this.legal_Remark,    
            "legal_Report_YN":this.legal_Report_YN,    
            "legal_Report_Ref":this.legal_Report_Ref,
            "title_Report_YN":this.title_Report_YN,    
            "title_Report_Ref":this.title_Report_Ref,    
            "bcmLegalCaseSummary":this.bcmLegalCaseSummary,    
            "decision_Legal":this.decision_Legal,    
            "decision_LegalBCM":this.decision_LegalBCM,    
            "isAgreed":this.isAgreed, 
            "eligibleLegalVendors":this.eligibleLegalVendors, 
            "property_OwnerName":this.property_OwnerName,
            "property_Address":this.property_Address,
            "chainFlow":this.chainFlow,
            "boundaries_West":this.boundaries_West,
            "boundaries_East":this.boundaries_East,
            "boundaries_North":this.boundaries_North,
            "boundaries_South": this.boundaries_South,
            "credit_Remark":this.credit_Remark,
            "sendBackNotes":this.sendBackNotes
        }
    }
}


export interface IDocumentInfo {
     documentType:string;
     uuid:string;
     doc_Source:string;
     doc_SourceScreen:string;
     remarkBy:string;
     remark:string;
     legalRemark:string;
     bcmResponse:string;
     remarkResponseBy:string;
     remarkOn:Date;
     remarkResponseOn:Date;
     imageData:string;
     source:string;
     
}
 
export class DocumentInfo{
    constructor(){
    
    }
    public documentType:string='';  
    public uuid:string='';
    public doc_Source:string='';
    public doc_SourceScreen:string='';
    public remarkBy:string='';
    public remark:string='';
    public legalRemark:string='';
    public bcmResponse:string='';
    public remarkResponseBy:string='';
    public remarkOn:Date= new Date();
    public remarkResponseOn:Date= new Date();
    public imageData:string='';   
    public uniqueId : string =''; 
    public documentTypeDesc:string='';
    public creditResponseOn:Date = new Date();
}

export interface IVendorList{
    mcCode:string;
    vendorId:string;
    vendorDesc:string;
    createdBy:string;
    createdOn:string;
    modifiedOn:string;
    modifiedBy:string;
}

export class VendorList{
   public mcCode:string='';
   public vendorId:string='';
   public vendorDesc:string='';
   public createdBy:string='';
   public createdOn:string='';
   public modifiedOn:string='';
   public modifiedBy:string='';
}

export interface IDownloadDocument{
      imageData:string,
     errorCode:string,
     errorDescription:string
}


export interface IVendorCasedModel {
    lan: string;
    loginPSID: string; 
    role:string;    
    caseStatus:string;    
    mcCode:string;    
    mcName:string;    
    loanType:string;    
    geoLocation:string;    
    applicantName:string;    
    appliedAmount:number;    
    addressOfProperty:string;      
    selectedLegalVendor:string;    
    assignment_DateTime:Date;    
    legalDocumentsInfo:DocumentInfo[];
    vendorDocumentsInfo:DocumentInfo[];
    bcM_Remark:string;    
    legal_Remark:string;    
    technical_Report_YN:string;    
    technical_Report_Ref:string;    
    title_Report_YN:string;    
    title_Report_Ref:string;    
    bcmLegalCaseSummary:string;    
    decision_Legal:string;    
    decision_LegalBCM:string;    
    isAgreed:boolean;    
    eligibleLegalVendors:string;
    typeOfHouse:number;
    propertyType:number;
    yearOfConstruction:number;
    unitDetails:string;
    materialsUsedLookOfWalls:number;
    materialsUsedInRoofs:number;
    materialsUsedInFloors:number;
    plot_Area:string;
   plot_CircleRate:number;
    plot_MarketRate:number;
    builtUp_Area:string;
   builtUp_CircleRate:number;
    builtUp_MarketRate:number;
    bcM_TEchValuation:string;  
    sendBackNotes:string;
}
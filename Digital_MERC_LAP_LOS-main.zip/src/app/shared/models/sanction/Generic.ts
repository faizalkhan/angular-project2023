import { common } from "../common";

export interface IGeneric {
    applicationNo: string;
    applicantCoappRef: string;
    nameOfBusiness: string;
    business_Number_Of_Years: number;
    business_Number_Of_Months: number;
    ownership_Of_Premise: string;
    numOfFam: number;
    numofPartners: number;
    numofEmplyrWorker: number;
    wageFrequency: number;
    locality: string;
    tradeUnionMem_YN: string;
    memberShip_Lic_Num: string;
    tradeUnionName: string;
    tradeUnionAdd: string;
    tradeUnionContact: string;
    membershipCardUpload_YN: string;
    membershipCardUpload: string;
    topSellingProd: string;
    ownerFund: string;
    exp_Shoprent_Act: string;
    exp_Electricity_Act: string;
    exp_SalaryLabourCost_Act: string;
    exp_Other_Act: string;
    walkInCust: string;
    avgRevPerCust: string;
    purchaseCostPerMon: string;
    prodCycle: string;
    inventoryVal: string;
    warehouse_YN: string;
    stockVal: string;
    deadStock: string;
    deadStock_YN: string;
    sellingMode: string;
    creditSales: string;
    avgCreditPeriod: string;
    supp_Name_Top1: string;
    supp_Contact_Top1: string;
    supp_Address_Top1: string;
    supp_Name_Top2: string;
    supp_Contact_Top2: string;
    supp_Address_Top2: string;
    supp_ValofTxn_Top1: string;
    supp_ValofTxn_Top2: string;
    monthlyTurnOver: string;
    grossProfitMargin: string;
    upI_YN: string;
    seasonableBusiness_YN: string;
    seasonableBusinessIncome: string;
    receivables: string;
    payables: string;
    flO_PsId: string;
    sourceThrough: string;
    leadId?: any;
    createdOn: string;
    lineOfBusiness: string;
    lineOfBusinessDtlIfOthers: string;
    loanAccountNumber: string;
    seasonableBusiness_Name: string;
    memCardUploadMimeType: string;
    memCardUploadExtension: string;
    toJSON(): any;
    toJSONwithoutImageData(): any;
}

export class Generic implements IGeneric {
    private _loanAccountNumber: string = "";
    public get loanAccountNumber(): string {
        return this._loanAccountNumber;
    }
    public set loanAccountNumber(value: string) {
        this._loanAccountNumber = value;
    }
    private _applicationNo: string = "";
    public get applicationNo(): string {
        return this._applicationNo;
    }
    public set applicationNo(value: string) {
        this._applicationNo = value;
    }
    private _applicantCoappRef: string = "";
    public get applicantCoappRef(): string {
        return this._applicantCoappRef;
    }
    public set applicantCoappRef(value: string) {
        this._applicantCoappRef = value;
    }
    private _nameOfBusiness: string = "";
    public get nameOfBusiness(): string {
        return this._nameOfBusiness;
    }
    public set nameOfBusiness(value: string) {
        this._nameOfBusiness = value;
    }
    private _business_Number_Of_Years: number = 0;
    public get business_Number_Of_Years(): number {
        return this._business_Number_Of_Years;
    }
    public set business_Number_Of_Years(value: number) {
        this._business_Number_Of_Years = value;
    }
    private _business_Number_Of_Months: number = 0;
    public get business_Number_Of_Months(): number {
        return this._business_Number_Of_Months;
    }
    public set business_Number_Of_Months(value: number) {
        this._business_Number_Of_Months = value;
    }
    private _ownership_Of_Premise: string = "";
    public get ownership_Of_Premise(): string {
        return this._ownership_Of_Premise;
    }
    public set ownership_Of_Premise(value: string) {
        this._ownership_Of_Premise = value;
    }
    private _numOfFam: number = 0;
    public get numOfFam(): number {
        return this._numOfFam;
    }
    public set numOfFam(value: number) {
        this._numOfFam = value;
    }
    private _numofPartners: number = 0;
    public get numofPartners(): number {
        return this._numofPartners;
    }
    public set numofPartners(value: number) {
        this._numofPartners = value;
    }
    private _numofEmplyrWorker: number = 0;
    public get numofEmplyrWorker(): number {
        return this._numofEmplyrWorker;
    }
    public set numofEmplyrWorker(value: number) {
        this._numofEmplyrWorker = value;
    }
    private _wageFrequency: number = 0;
    public get wageFrequency(): number {
        return this._wageFrequency;
    }
    public set wageFrequency(value: number) {
        this._wageFrequency = value;
    }
    private _locality: string = "";
    public get locality(): string {
        return this._locality;
    }
    public set locality(value: string) {
        this._locality = value;
    }
    private _tradeUnionMem_YN: string = "";
    public get tradeUnionMem_YN(): string {
        return this._tradeUnionMem_YN;
    }
    public set tradeUnionMem_YN(value: string) {
        this._tradeUnionMem_YN = value;
        if (value && value.toLowerCase() == 'n') {
            this.tradeUnionAdd = this.tradeUnionContact = this.tradeUnionName = "";
            this.membershipCardUpload_YN = 'N';
            this.membershipCardUpload = "";
            this.memberShip_Lic_Num = "";
            this.tradeUnionContact = "";
        }
    }
    private _memberShip_Lic_Num: string = "";
    public get memberShip_Lic_Num(): string {
        return this._memberShip_Lic_Num;
    }
    public set memberShip_Lic_Num(value: string) {
        this._memberShip_Lic_Num = value;
    }
    private _tradeUnionName: string = "";
    public get tradeUnionName(): string {
        return this._tradeUnionName;
    }
    public set tradeUnionName(value: string) {
        this._tradeUnionName = value;
    }
    private _tradeUnionAdd: string = "";
    public get tradeUnionAdd(): string {
        return this._tradeUnionAdd;
    }
    public set tradeUnionAdd(value: string) {
        this._tradeUnionAdd = value;
    }
    private _tradeUnionContact: string = "";
    public get tradeUnionContact(): string {
        return this._tradeUnionContact;
    }
    public set tradeUnionContact(value: string) {
        this._tradeUnionContact = value;
    }
    private _membershipCardUpload_YN: string = "";
    public get membershipCardUpload_YN(): string {
        return this._membershipCardUpload_YN;
    }
    public set membershipCardUpload_YN(value: string) {
        this._membershipCardUpload_YN = value;
    }
    private _membershipCardUpload: string = "";
    public get membershipCardUpload(): string {
        return this._membershipCardUpload;
    }
    public set membershipCardUpload(value: string) {
        this._membershipCardUpload = value;
    }
    private _topSellingProd: string = "";
    public get topSellingProd(): string {
        return this._topSellingProd;
    }
    public set topSellingProd(value: string) {
        this._topSellingProd = value;
    }
    private _ownerFund: string = "";
    public get ownerFund(): string {
        return this._ownerFund;
    }
    public set ownerFund(value: string) {
        this._ownerFund = value;
    }
    private _exp_Shoprent_Act: string = "";
    public get exp_Shoprent_Act(): string {
        return this._exp_Shoprent_Act;
    }
    public set exp_Shoprent_Act(value: string) {
        this._exp_Shoprent_Act = value;
    }
    private _exp_Electricity_Act: string = "";
    public get exp_Electricity_Act(): string {
        return this._exp_Electricity_Act;
    }
    public set exp_Electricity_Act(value: string) {
        this._exp_Electricity_Act = value;
    }
    private _exp_SalaryLabourCost_Act: string = "";
    public get exp_SalaryLabourCost_Act(): string {
        return this._exp_SalaryLabourCost_Act;
    }
    public set exp_SalaryLabourCost_Act(value: string) {
        this._exp_SalaryLabourCost_Act = value;
    }
    private _exp_Other_Act: string = "";
    public get exp_Other_Act(): string {
        return this._exp_Other_Act;
    }
    public set exp_Other_Act(value: string) {
        this._exp_Other_Act = value;
    }
    private _walkInCust: string = "";
    public get walkInCust(): string {
        return this._walkInCust;
    }
    public set walkInCust(value: string) {
        this._walkInCust = value;
        this.CalcMonthlyTurnOver();
    }
    private _avgRevPerCust: string = "";
    public get avgRevPerCust(): string {
        return this._avgRevPerCust;
    }
    public set avgRevPerCust(value: string) {
        this._avgRevPerCust = value;
        this.CalcMonthlyTurnOver();
    }
    private _purchaseCostPerMon: string = "";
    public get purchaseCostPerMon(): string {
        return this._purchaseCostPerMon;
    }
    public set purchaseCostPerMon(value: string) {
        this._purchaseCostPerMon = value;
    }
    private _prodCycle: string = "";
    public get prodCycle(): string {
        return this._prodCycle;
    }
    public set prodCycle(value: string) {
        this._prodCycle = value;
    }
    private _inventoryVal: string = "";
    public get inventoryVal(): string {
        return this._inventoryVal;
    }
    public set inventoryVal(value: string) {
        this._inventoryVal = value;
    }
    private _warehouse_YN: string = "";
    public get warehouse_YN(): string {
        return this._warehouse_YN;
    }
    public set warehouse_YN(value: string) {
        this._warehouse_YN = value;
        if (value && value.toLowerCase() == 'n') {
            this.stockVal = "";
        }
    }
    private _stockVal: string = "";
    public get stockVal(): string {
        return this._stockVal;
    }
    public set stockVal(value: string) {
        this._stockVal = value;
    }
    private _deadStock: string = "";
    public get deadStock(): string {
        return this._deadStock;
    }
    public set deadStock(value: string) {
        this._deadStock = value;
    }
    private _sellingMode: string = "";
    public get sellingMode(): string {
        return this._sellingMode;
    }
    public set sellingMode(value: string) {
        this._sellingMode = value;
        if (value && value.toLowerCase() == "cash only") {
            this.creditSales = "";
        }
    }
    private _creditSales: string = "";
    public get creditSales(): string {
        return this._creditSales;
    }
    public set creditSales(value: string) {
        this._creditSales = value;
    }
    private _avgCreditPeriod: string = "";
    public get avgCreditPeriod(): string {
        return this._avgCreditPeriod;
    }
    public set avgCreditPeriod(value: string) {
        this._avgCreditPeriod = value;
    }
    private _supp_Name_Top1: string = "";
    public get supp_Name_Top1(): string {
        return this._supp_Name_Top1;
    }
    public set supp_Name_Top1(value: string) {
        this._supp_Name_Top1 = value;
    }
    private _supp_Contact_Top1: string = "";
    public get supp_Contact_Top1(): string {
        return this._supp_Contact_Top1;
    }
    public set supp_Contact_Top1(value: string) {
        this._supp_Contact_Top1 = value;
    }
    private _supp_Address_Top1: string = "";
    public get supp_Address_Top1(): string {
        return this._supp_Address_Top1;
    }
    public set supp_Address_Top1(value: string) {
        this._supp_Address_Top1 = value;
    }
    private _supp_Name_Top2: string = "";
    public get supp_Name_Top2(): string {
        return this._supp_Name_Top2;
    }
    public set supp_Name_Top2(value: string) {
        this._supp_Name_Top2 = value;
    }
    private _supp_Contact_Top2: string = "";
    public get supp_Contact_Top2(): string {
        return this._supp_Contact_Top2;
    }
    public set supp_Contact_Top2(value: string) {
        this._supp_Contact_Top2 = value;
    }
    private _supp_Address_Top2: string = "";
    public get supp_Address_Top2(): string {
        return this._supp_Address_Top2;
    }
    public set supp_Address_Top2(value: string) {
        this._supp_Address_Top2 = value;
    }
    private _supp_ValofTxn_Top1: string = "";
    public get supp_ValofTxn_Top1(): string {
        return this._supp_ValofTxn_Top1;
    }
    public set supp_ValofTxn_Top1(value: string) {
        this._supp_ValofTxn_Top1 = value;
    }
    private _supp_ValofTxn_Top2: string = "";
    public get supp_ValofTxn_Top2(): string {
        return this._supp_ValofTxn_Top2;
    }
    public set supp_ValofTxn_Top2(value: string) {
        this._supp_ValofTxn_Top2 = value;
    }
    private _monthlyTurnOver: string = "";
    public get monthlyTurnOver(): string {
        return this._monthlyTurnOver;
    }
    public set monthlyTurnOver(value: string) {
        this._monthlyTurnOver = value;
    }

    private _grossProfitMargin: string = "";
    public get grossProfitMargin(): string {
        return this._grossProfitMargin;
    }
    public set grossProfitMargin(value: string) {
        this._grossProfitMargin = value;
    }
    private _upI_YN: string = "";
    public get upI_YN(): string {
        return this._upI_YN;
    }
    public set upI_YN(value: string) {
        this._upI_YN = value;
    }
    private _seasonableBusiness_YN: string = "";
    public get seasonableBusiness_YN(): string {
        return this._seasonableBusiness_YN;
    }
    public set seasonableBusiness_YN(value: string) {
        this._seasonableBusiness_YN = value;
        if (value && value.toLowerCase() == "n") {
            this.seasonableBusinessIncome = "";
            this.seasonableBusiness_Name = "";
        }
    }
    private _seasonableBusinessIncome: string = "";
    public get seasonableBusinessIncome(): string {
        return this._seasonableBusinessIncome;
    }
    public set seasonableBusinessIncome(value: string) {
        this._seasonableBusinessIncome = value;
    }
    private _receivables: string = "";
    public get receivables(): string {
        return this._receivables;
    }
    public set receivables(value: string) {
        this._receivables = value;
    }
    private _payables: string = "";
    public get payables(): string {
        return this._payables;
    }
    public set payables(value: string) {
        this._payables = value;
    }
    private _flO_PsId: string = "";
    public get flO_PsId(): string {
        return this._flO_PsId;
    }
    public set flO_PsId(value: string) {
        this._flO_PsId = value;
    }
    private _sourceThrough: string = "";
    public get sourceThrough(): string {
        return this._sourceThrough;
    }
    public set sourceThrough(value: string) {
        this._sourceThrough = value;
    }
    private _leadId?: any = "";
    public get leadId(): any {
        return this._leadId;
    }
    public set leadId(value: any) {
        this._leadId = value;
    }
    private _createdOn: string = "";
    public get createdOn(): string {
        return this._createdOn;
    }
    public set createdOn(value: string) {
        this._createdOn = value;
    }
    private _lineOfBusiness: string = "";
    public get lineOfBusiness(): string {
        return this._lineOfBusiness;
    }
    public set lineOfBusiness(value: string) {
        this._lineOfBusiness = value;
    }
    private _lineOfBusinessDtlIfOthers: string = "";
    public get lineOfBusinessDtlIfOthers(): string {
        return this._lineOfBusinessDtlIfOthers;
    }
    public set lineOfBusinessDtlIfOthers(value: string) {
        this._lineOfBusinessDtlIfOthers = value;
    }
    private _seasonableBusiness_Name: string = "";
    public get seasonableBusiness_Name(): string {
        return this._seasonableBusiness_Name;
    }
    public set seasonableBusiness_Name(value: string) {
        this._seasonableBusiness_Name = value;
    }
    CalcMonthlyTurnOver(): any {

        if (this.walkInCust && this.walkInCust != "") {
            let walkInCust = Number(this.walkInCust);

            let average = (this.avgRevPerCust && this.avgRevPerCust != "") ? Number(this.avgRevPerCust) : 0;

            this.monthlyTurnOver = (walkInCust * average * 26).toFixed();
        }
        else
            this.monthlyTurnOver = "";
    }
    constructor(params?: IGeneric) {
        if (params) {
            common.ObjectMapping(params, this);
            this.CalcMonthlyTurnOver();
        }
    }
    private _deadStock_YN: string = "";
    public get deadStock_YN(): string {
        return this._deadStock_YN;
    }
    public set deadStock_YN(value: string) {
        this._deadStock_YN = value;
        if ((value && value.toLowerCase().startsWith('y') == false)) {
            this.deadStock = "";
        }
    }
    private _memCardUploadMimeType: string = "";
    public get memCardUploadMimeType(): string {
        return this._memCardUploadMimeType;
    }
    public set memCardUploadMimeType(value: string) {
        this._memCardUploadMimeType = value;
    }
    private _memCardUploadExtension: string = "";
    public get memCardUploadExtension(): string {
        return this._memCardUploadExtension;
    }
    public set memCardUploadExtension(value: string) {
        this._memCardUploadExtension = value;
    }

    toJSON(): any {
        return {
            "loanAccountNumber": this.loanAccountNumber,
            "applicationNo": this.applicationNo,
            "applicantCoappRef": this.applicantCoappRef,
            "nameOfBusiness": this.nameOfBusiness,
            "business_Number_Of_Years": this.business_Number_Of_Years,
            "business_Number_Of_Months": this.business_Number_Of_Months,
            "ownership_Of_Premise": this.ownership_Of_Premise,
            "numOfFam": this.numOfFam,
            "numofPartners": this.numofPartners,
            "numofEmplyrWorker": !this.numofEmplyrWorker?0:this.numofEmplyrWorker,
            "wageFrequency": this.wageFrequency,
            "locality": this.locality,
            "tradeUnionMem_YN": this.tradeUnionMem_YN,
            "memberShip_Lic_Num": this.memberShip_Lic_Num,
            "tradeUnionName": this.tradeUnionName,
            "tradeUnionAdd": this.tradeUnionAdd,
            "tradeUnionContact": this.tradeUnionContact,
            "membershipCardUpload_YN": this.membershipCardUpload_YN,
            "membershipCardUpload": this.membershipCardUpload,
            "topSellingProd": this.topSellingProd,
            "ownerFund": this.ownerFund,
            "exp_Shoprent_Act": this.exp_Shoprent_Act,
            "exp_Electricity_Act": this.exp_Electricity_Act,
            "exp_SalaryLabourCost_Act": this.exp_SalaryLabourCost_Act,
            "exp_Other_Act": this.exp_Other_Act,
            "walkInCust": this.walkInCust,
            "avgRevPerCust": this.avgRevPerCust,
            "purchaseCostPerMon": this.purchaseCostPerMon,
            "prodCycle": this.prodCycle,
            "inventoryVal": this.inventoryVal.toString(),
            "warehouse_YN": this.warehouse_YN,
            "stockVal": this.stockVal,
            "deadStock": this.deadStock,
            "deadStock_YN": this.deadStock_YN,
            "sellingMode": this.sellingMode,
            "creditSales": this.creditSales,
            "avgCreditPeriod": this.avgCreditPeriod,
            "supp_Name_Top1": this.supp_Name_Top1,
            "supp_Contact_Top1": this.supp_Contact_Top1,
            "supp_Address_Top1": this.supp_Address_Top1,
            "supp_Name_Top2": this.supp_Name_Top2,
            "supp_Contact_Top2": this.supp_Contact_Top2,
            "supp_Address_Top2": this.supp_Address_Top2,
            "supp_ValofTxn_Top1": this.supp_ValofTxn_Top1,
            "supp_ValofTxn_Top2": this.supp_ValofTxn_Top2,
            "monthlyTurnOver": this.monthlyTurnOver.toString(),
            "grossProfitMargin": this.grossProfitMargin.toString(),
            "upI_YN": this.upI_YN,
            "seasonableBusiness_YN": this.seasonableBusiness_YN,
            "seasonableBusinessIncome": this.seasonableBusinessIncome.toString(),
            "receivables": this.receivables,
            "payables": this.payables,
            "flO_PsId": this.flO_PsId,
            "sourceThrough": this.sourceThrough,
            "leadId": this.leadId,
            "createdOn": this.createdOn,
            "lineOfBusiness": this.lineOfBusiness,
            "lineOfBusinessDtlIfOthers": this.lineOfBusinessDtlIfOthers,
            "seasonableBusiness_Name": this.seasonableBusiness_Name,
            "memCardUploadMimeType": this.memCardUploadMimeType,
            "memCardUploadExtension": this.memCardUploadExtension
        };
    }

    toJSONwithoutImageData(): any {
        return {
            "loanAccountNumber": this.loanAccountNumber,
            "applicationNo": this.applicationNo,
            "applicantCoappRef": this.applicantCoappRef,
            "nameOfBusiness": this.nameOfBusiness,
            "business_Number_Of_Years": this.business_Number_Of_Years,
            "business_Number_Of_Months": this.business_Number_Of_Months,
            "ownership_Of_Premise": this.ownership_Of_Premise,
            "numOfFam": this.numOfFam,
            "numofPartners": this.numofPartners,
            "numofEmplyrWorker": !this.numofEmplyrWorker?0:this.numofEmplyrWorker,
            "wageFrequency": this.wageFrequency,
            "locality": this.locality,
            "tradeUnionMem_YN": this.tradeUnionMem_YN,
            "memberShip_Lic_Num": this.memberShip_Lic_Num,
            "tradeUnionName": this.tradeUnionName,
            "tradeUnionAdd": this.tradeUnionAdd,
            "tradeUnionContact": this.tradeUnionContact,
            "membershipCardUpload_YN": this.membershipCardUpload_YN,
            "topSellingProd": this.topSellingProd,
            "ownerFund": this.ownerFund,
            "exp_Shoprent_Act": this.exp_Shoprent_Act,
            "exp_Electricity_Act": this.exp_Electricity_Act,
            "exp_SalaryLabourCost_Act": this.exp_SalaryLabourCost_Act,
            "exp_Other_Act": this.exp_Other_Act,
            "walkInCust": this.walkInCust,
            "avgRevPerCust": this.avgRevPerCust,
            "purchaseCostPerMon": this.purchaseCostPerMon,
            "prodCycle": this.prodCycle,
            "inventoryVal": this.inventoryVal.toString(),
            "warehouse_YN": this.warehouse_YN,
            "stockVal": this.stockVal,
            "deadStock": this.deadStock,
            "deadStock_YN": this.deadStock_YN,
            "sellingMode": this.sellingMode,
            "creditSales": this.creditSales,
            "avgCreditPeriod": this.avgCreditPeriod,
            "supp_Name_Top1": this.supp_Name_Top1,
            "supp_Contact_Top1": this.supp_Contact_Top1,
            "supp_Address_Top1": this.supp_Address_Top1,
            "supp_Name_Top2": this.supp_Name_Top2,
            "supp_Contact_Top2": this.supp_Contact_Top2,
            "supp_Address_Top2": this.supp_Address_Top2,
            "supp_ValofTxn_Top1": this.supp_ValofTxn_Top1,
            "supp_ValofTxn_Top2": this.supp_ValofTxn_Top2,
            "monthlyTurnOver": this.monthlyTurnOver.toString(),
            "grossProfitMargin": this.grossProfitMargin.toString(),
            "upI_YN": this.upI_YN,
            "seasonableBusiness_YN": this.seasonableBusiness_YN,
            "seasonableBusinessIncome": this.seasonableBusinessIncome.toString(),
            "receivables": this.receivables,
            "payables": this.payables,
            "flO_PsId": this.flO_PsId,
            "sourceThrough": this.sourceThrough,
            "leadId": this.leadId,
            "createdOn": this.createdOn,
            "lineOfBusiness": this.lineOfBusiness,
            "lineOfBusinessDtlIfOthers": this.lineOfBusinessDtlIfOthers,
            "seasonableBusiness_Name": this.seasonableBusiness_Name,
            "memCardUploadMimeType": this.memCardUploadMimeType,
            "memCardUploadExtension": this.memCardUploadExtension
        };
    }

}

export enum BusinessLists {
    KiranaorGeneralstore = "Kirana or General store",
    Dairyandallied = "Dairy and Allied",
    Animalhusbandry = "Animal husbandry",
    Poultry = "Poultry",
    AgriandAllied = "Agri and Allied",
    VegetablesFruitsorFlowers = "Vegetables,Fruits or Flowers",
    HotelRestaurantsorothereateries = "Hotel, Restaurants or other eateries",
    Buildingconstructionmaterials = "Building & construction materials",
    Readymadegarmentsandhosiery = "Readymade garments and hosiery",
    Hardwareandotherequipments = "Hardware and other equipments",
    ElectronicsFurniture = "Electronics & Furniture",
    Motormechanicandgarageservices = "Motor mechanic and garage services",
    ElectronicandMobilerepairservices = "Electronic and Mobile repair services",
    TailoringHandloomservices = "Tailoring/Handloom services",
    Others = "Others"
}

export interface IGenericConfig {
    businessType: string;
    gpMargin: number;
    maxCustomerWalkInADay: number;
    maxSalesPerCustomer: number;
}

export class GenericConfig implements IGenericConfig {
    businessType: string = '';
    gpMargin: number = 0;
    maxCustomerWalkInADay: number = 0;
    maxSalesPerCustomer: number = 0;
    constructor(param?: IGenericConfig) {
        if (param) {
            this.businessType = param.businessType;
            this.gpMargin = param.gpMargin;
            this.maxCustomerWalkInADay = param.maxCustomerWalkInADay;
            this.maxSalesPerCustomer = param.maxSalesPerCustomer;
        }
    }
}
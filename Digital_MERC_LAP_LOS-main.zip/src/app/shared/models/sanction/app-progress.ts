export class ApplicationProgress {  
    constructor(  
        public personaldetails: string,  
        public incomeassessment: string,  
        public businessdetails: string,
        public bankingassessment: string,  
        public referencedetails: string, 
        public propertyvalution: string, 
        public householdassessment: string,   
        public camsheer: string

    ){}  
}  
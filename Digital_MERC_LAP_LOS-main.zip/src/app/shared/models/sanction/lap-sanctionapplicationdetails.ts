
export interface IApplicantDetail {
    applicationNo: string;
    applicantName: string;
    financial_status: string;
    mobileno: string;
    leadStatusId: string;
    salary_Status: string;
    type: string;
    rel_with_applicant: string;
    sanctionDetConfirm_YN: string;
    selected: boolean;
}
export class ApplicantDetail implements IApplicantDetail {
    applicationNo: string = "";
    applicantName: string = "";
    financial_status: string = "";
    mobileno: string = "";
    leadStatusId: string = "";
    salary_Status: string = "";
    type: string = "";
    rel_with_applicant: string = "";
    sanctionDetConfirm_YN: string = "";
    selected: boolean = false;
    constructor(params?: IApplicantDetail) {
        if (params) {

        }
    }
}

export interface ISanctionResponse {
    errorcode: string;
    errorDescription: string;
    applicantDetails: IApplicantDetail[];
    personalDetailsCompleted: string;
    businessDetailsCompleted: string;
    referenceChecked_YN: string;
    householdAssesment_YN: string;
    incomeAssesment_YN: string;
    propertyValuation_YN: string;
    documentChecked_YN: string;
    loanAppliedAmount: string;
    productType: string;
    loanAccountNumber: string;
}

export class SanctionResponse implements ISanctionResponse {
    errorcode: string = "";
    errorDescription: string = "";
    applicantDetails: IApplicantDetail[] = [];
    personalDetailsCompleted: string = "";
    businessDetailsCompleted: string = "";
    referenceChecked_YN: string = "";
    householdAssesment_YN: string = "";
    incomeAssesment_YN: string = "";
    propertyValuation_YN: string = "";
    documentChecked_YN: string = "";
    loanAppliedAmount: string = "";
    productType: string = "";
    loanAccountNumber: string = "";

    constructor() {

    }

}



import { Dropdown, IDropdown } from "../common/control.model";

export class masterModuleDropdown {
    /**PROPERTY VALUATION Dropdowns */
    static CERSAIReportCheck: IDropdown[] = [
        new Dropdown({ displayName: "Positive" }),
        new Dropdown({ displayName: "Negative" })
    ];
    static ResidenceProofType: IDropdown[] = [
        new Dropdown({ displayName: "Utility Bills" }),
        new Dropdown({ displayName: "Property Tax Recipt" }),
        new Dropdown({ displayName: "Copy of Deed page" }),
    ];
    static PropertyUsageType: IDropdown[] = [
        new Dropdown({ displayName: "Residential" }),
        new Dropdown({ displayName: "Commercial" }),
        new Dropdown({ displayName: "Both" })
    ];
    static TypeofLandApproval: IDropdown[] = [
        new Dropdown({ displayName: "Gram Panchayat" }),
        new Dropdown({ displayName: "Town Panchayat" }),
        new Dropdown({ displayName: "Nagar Palika" }),
        new Dropdown({ displayName: "Municipal Corporation" })
    ];
    static LandType: IDropdown[] = [
        new Dropdown({ displayName: "Freehold" }),
        new Dropdown({ displayName: "Leasehold" }),
        new Dropdown({ displayName: "Gramtal" }),
        new Dropdown({ displayName: "Gaothan Freehold" })
    ];
    static HouseType: IDropdown[] = [
        new Dropdown({ displayName: "Flat" }),
        new Dropdown({ displayName: "Independent House" }),
        new Dropdown({ displayName: "Villa" }),
        new Dropdown({ displayName: "Continuous housing" }),
    ];
    static ApproachedRoadType: IDropdown[] = [
        new Dropdown({ displayName: "Concrete" }),
        new Dropdown({ displayName: "Bitumen Road" }),
        new Dropdown({ displayName: "Pakka Road" }),
        new Dropdown({ displayName: "Red sand (Kaccha Road)" })
    ];
    static SurroundingArea: IDropdown[] = [
        new Dropdown({ displayName: "Slum" }),
        new Dropdown({ displayName: "Shop" }),
        new Dropdown({ displayName: "Residential Area" }),
        new Dropdown({ displayName: "Vacant site" }),
        new Dropdown({ displayName: "Commercial Area" })
    ];
    static TypeofLocality: IDropdown[] = [
        new Dropdown({ displayName: "Developed" }),
        new Dropdown({ displayName: "Developing" }),
        new Dropdown({ displayName: "Under developed" })
    ];
    static ConstructionQuality: IDropdown[] = [
        new Dropdown({ displayName: "Good" }),
        new Dropdown({ displayName: "Moderate" }),
        new Dropdown({ displayName: "Poor" })
    ];
    static PropertyType: IDropdown[] = [
        new Dropdown({ displayName: "Load Bearing" }),
        new Dropdown({ displayName: "Mixed Structure" }),
        new Dropdown({ displayName: "RCC Structure" })
    ];
    static ConstructionType: IDropdown[] = [
        new Dropdown({ displayName: "Type 1" }),
        new Dropdown({ displayName: "Type 2" }),
        new Dropdown({ displayName: "Type 3" })

    ];
    static ConstructionYear: IDropdown[] = [
        new Dropdown({ displayName: "<5 years" }),
        new Dropdown({ displayName: "5–10 years" }),
        new Dropdown({ displayName: ">10 years" })
    ];
    static UnitDetail: IDropdown[] = [
        new Dropdown({ displayName: "Flat" }),
        new Dropdown({ displayName: "Other than flat" })
    ];
    static MaterialsUsedinWall: IDropdown[] = [
        new Dropdown({ displayName: "Fully Painted" }),
        new Dropdown({ displayName: "Brick and plaster" }),
        new Dropdown({ displayName: "RCC" }),
        new Dropdown({ displayName: "Bricks" })
    ];
    static MaterialsUsedinFloors: IDropdown[] = [
        new Dropdown({ displayName: "Granite" }),
        new Dropdown({ displayName: "Marble" }),
        new Dropdown({ displayName: "Tiles" }),
        new Dropdown({ displayName: "Mozaic" }),
        new Dropdown({ displayName: "Cement" }),
    ]
    static MaterialsUsedinRoofs: IDropdown[] = [
        new Dropdown({ displayName: "RCC" }),
        new Dropdown({ displayName: "Stone & Beam" }),
        new Dropdown({ displayName: "Mangalorian Tiles" }),
        new Dropdown({ displayName: "Cement sheet" }),
        new Dropdown({ displayName: "Tin sheet" })
    ]
    static HighestEducation: IDropdown[] = [
        new Dropdown({ displayName: "Illiterate" }),
        new Dropdown({ displayName: "Primary" }),
        new Dropdown({ displayName: "Middle" }),
        new Dropdown({ displayName: "Secondary" }),
        new Dropdown({ displayName: "Graduate/Postgraduate" })

    ]
    static Conditional: IDropdown[] = [
        new Dropdown({ displayName: "Yes", value: "Y" }),
        new Dropdown({ displayName: "No", value: "N" })
    ];
    static ITRList: IDropdown[] = [
        new Dropdown({ displayName: "Yes", value: "Yes" }),
        new Dropdown({ displayName: "No", value: "No" })
    ];
    static SalaryMode: IDropdown[] = [new Dropdown({ displayName: "Cash" }),
    new Dropdown({ displayName: "Bank" }),
    new Dropdown({ displayName: "Both" })
    ];
    static CreditDesicionForL1: IDropdown[] = [new Dropdown({ displayName: "Approved" }), new Dropdown({ displayName: "Referred" }),new Dropdown({ displayName: "Rejected" })];
    static CreditDesicionForL2: IDropdown[] = [new Dropdown({ displayName: "Approved" }), new Dropdown({ displayName: "Referred" }),new Dropdown({ displayName: "Rejected" }), new Dropdown({ displayName: "Send Back" })];

    static MonthList: IDropdown[] = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map(x => new Dropdown({ displayName: x.toString() }));

    static Ownership_Of_Premise: IDropdown[] = [
        new Dropdown({ displayName: 'Rented' }),
        new Dropdown({ displayName: 'Owned' }),
        new Dropdown({ displayName: 'Owned by Family' }),
    ];

    static locality: IDropdown[] = [
        new Dropdown({ displayName: 'Main market' }),
        new Dropdown({ displayName: 'Near by market' }),
        new Dropdown({ displayName: 'others' }),
    ];

    static Roles: any[] = [
        { RoleName: "BCM", Type: "L1" },
        { RoleName: "ACM", Type: "L2" },
        { RoleName: "RCM", Type: "L3" },
        { RoleName: "ZCM", Type: "L4" }
    ];
    static RejectOption: IDropdown[] = [
        new Dropdown({
            displayName: "Rejection reason 1"
        }),
        new Dropdown({
            displayName: "Rejection reason 2"
        }),
        new Dropdown({
            displayName: "Rejection reason 3"
        }),
        new Dropdown({
            displayName: "Others"
        })
    ];
    static BusinessType: IDropdown[] = [
        new Dropdown({ displayName: 'Retailer' }),
        new Dropdown({ displayName: 'Wholesale' }),
        new Dropdown({ displayName: 'Manufacturing' }),
        new Dropdown({ displayName: 'Trader' }),
        new Dropdown({ displayName: 'Service Industry' }),
        new Dropdown({ displayName: 'Salaried' }),
        new Dropdown({ displayName: 'Others' }),

    ];


    static PDPropertyType: IDropdown[] = [
        { displayName: 'Self Occupied Residential', value: 'Self Occupied Residential' },
        { displayName: 'Self Occupied Commercial', value: 'Self Occupied Commercial' },
        { displayName: 'Both', value: 'Both' }];

    static CustomerType: IDropdown[] = [{ displayName: 'Applicant', value: 'Applicant' }, { displayName: 'Co-Applicant', value: 'Co-Applicant' }, { displayName: 'Primary Co-Applicant', value: 'Primary Co-Applicant' }]


    static end_UseOfFund: IDropdown[] = [new Dropdown({ displayName: 'Business expansion' }),
    new Dropdown({ displayName: 'Working capital' }),
    new Dropdown({ displayName: 'Renovation of business premises' }),
    new Dropdown({ displayName: 'Other business purpose' }),
    ]

    static Ops_Remarks: IDropdown[] = [
        new Dropdown({ displayName: 'Bank A/c Number mismatch' }),
        new Dropdown({ displayName: 'IFSC Code mismatch' }),
        new Dropdown({ displayName: 'A/C Holder name mismatch' }),
        new Dropdown({ displayName: 'Bank name mismatch' }),
        new Dropdown({ displayName: "Others" })
    ];
}
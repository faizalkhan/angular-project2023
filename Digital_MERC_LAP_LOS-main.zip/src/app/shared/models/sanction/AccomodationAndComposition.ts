import { common } from "../common";

export interface IAccomodationAndComposition {
    loanAccountNumber: string;
    locality: string;
    constructionType: string;
    houseCategory: string;
    propertyType: string;
    noOfFamilyMembers: number;
    adults: number;
    earningMembers: number;
    dependentMembers: number;
    children: number;
    noOfChildrenGoingToSchoolNCollege: number;
    flO_PsId: string;
    sourceThrough: string;
    typeOfSchoolCollege: string;
    createdOn: string;
    noOfYearsResidingInTheSameProperty: string;
    toJson(): any;
    validation(): string;
}
export class AccomodationAndComposition implements IAccomodationAndComposition {
    private _loanAccountNumber: string = "";
    public get loanAccountNumber(): string {
        return this._loanAccountNumber;
    }
    public set loanAccountNumber(value: string) {
        this._loanAccountNumber = value;
    }
    private _locality: string = "";
    public get locality(): string {
        return this._locality;
    }
    public set locality(value: string) {
        this._locality = value;
    }
    private _constructionType: string = "";
    public get constructionType(): string {
        return this._constructionType;
    }
    public set constructionType(value: string) {
        this._constructionType = value;
    }
    private _houseCategory: string = "";
    public get houseCategory(): string {
        return this._houseCategory;
    }
    public set houseCategory(value: string) {
        this._houseCategory = value;
    }
    private _propertyType: string = "";
    public get propertyType(): string {
        return this._propertyType;
    }
    public set propertyType(value: string) {
        this._propertyType = value;
    }


    private _adults: number = 0;
    public get adults(): number {
        return this._adults;
    }
    public set adults(value: number) {
        this._adults = value;
    }
    private _earningMembers: number = 0;
    public get earningMembers(): number {
        return this._earningMembers;
    }
    public set earningMembers(value: number) {
        this._earningMembers = value;
    }
    public get dependentMembers(): number {
        let noOfFamilyMembers = this.noOfFamilyMembers ?? 0;
        let earningMembers = this.earningMembers ?? 0;

        return (noOfFamilyMembers - earningMembers);
    }

    public get children(): number {
        let noOfFamilyMembers = this.noOfFamilyMembers ?? 0;
        let adults = this.adults ?? 0;
        return (noOfFamilyMembers - adults);
    }

    private _noOfChildrenGoingToSchoolNCollege: number = 0;
    public get noOfChildrenGoingToSchoolNCollege(): number {
        return this._noOfChildrenGoingToSchoolNCollege ?? 0;
    }
    public set noOfChildrenGoingToSchoolNCollege(value: number) {
        this._noOfChildrenGoingToSchoolNCollege = value;
    }
    private _flO_PsId: string = "";
    public get flO_PsId(): string {
        return this._flO_PsId;
    }
    public set flO_PsId(value: string) {
        this._flO_PsId = value;
    }
    public get sourceThrough(): string {
        return "LOS";
    }

    private _typeOfSchoolCollege: string = "";
    public get typeOfSchoolCollege(): string {
        return this._typeOfSchoolCollege;
    }
    public set typeOfSchoolCollege(value: string) {
        this._typeOfSchoolCollege = value;
    }
    private _createdOn: string = "";
    public get createdOn(): string {
        return this._createdOn;
    }
    public set createdOn(value: string) {
        this._createdOn = value;
    }

    constructor(params?: IAccomodationAndComposition) {
        if (params) {
            common.ObjectMapping(params, this);
        }
    }
    private _noOfFamilyMembers: number = 0;
    public get noOfFamilyMembers(): number {
        return this._noOfFamilyMembers;
    }
    public set noOfFamilyMembers(value: number) {
        this._noOfFamilyMembers = value;
    }
    private _noOfYearsResidingInTheSameProperty: string = "";
    public get noOfYearsResidingInTheSameProperty(): string {
        return this._noOfYearsResidingInTheSameProperty;
    }
    public set noOfYearsResidingInTheSameProperty(value: string) {
        this._noOfYearsResidingInTheSameProperty = value;
    }
    validation(): string {
        /// Required validate
        if (!this.noOfYearsResidingInTheSameProperty || this.noOfYearsResidingInTheSameProperty == "") {
            return "Please enter no. of years residing in the same property";
        }
        else if (!this.noOfFamilyMembers || Number(this.noOfFamilyMembers) == 0) {
            return "Please Enter total No of Family Members";
        }
        else if (Number(this.noOfFamilyMembers) > 15) {
            return "Family members can not be more than 15";
        }
        else if (!this.adults || Number(this.adults) == 0) {
            return "Please enter no. of adult members in the family! Minimum 1 adult is mandatory";
        }
        else if (this.adults && Number(this.adults) > Number(this.noOfFamilyMembers)) {
            return "Number of adults can not be greater than total family members";
        }
        else if (!this.earningMembers || Number(this.earningMembers) == 0) {
            return "Please enter no. of earning members in the family! Minimum 1 earning member is mandatory.";
        }
        else if (this.earningMembers && Number(this.earningMembers) > Number(this.adults)) {
            return "Earning members cannot be more than no. of adults";
        }
        else if (this.noOfChildrenGoingToSchoolNCollege && Number(this.noOfChildrenGoingToSchoolNCollege) > (Number(this.children))) {
            return "Children going to school/college should be less than number of children";
        }
        else if ((this.noOfChildrenGoingToSchoolNCollege && Number(this.noOfChildrenGoingToSchoolNCollege) > 0 && (!this.typeOfSchoolCollege || this.typeOfSchoolCollege == ""))) {
            return "Children going to school/college is required";
        }
        else {
            return "";
        }
    }

    toJson(): any {
        return {
            "Adults": Number(this.adults),
            "Children": this.children,
            "ConstructionType": this.constructionType,
            "DependentMembers": this.dependentMembers,
            "EarningMembers": Number(this.earningMembers),
            "FLO_PsId": this.flO_PsId,
            "HouseCategory": this.houseCategory,
            "LoanAccountNumber": this.loanAccountNumber,
            "Locality": this.locality,
            "NoOfChildrenGoingToSchoolNCollege": Number(this.noOfChildrenGoingToSchoolNCollege ?? 0),
            "NoOfFamilyMembers":Number(this.noOfFamilyMembers),
            "PropertyType": this.propertyType,
            "SourceThrough": "LOS",
            "TypeOfSchoolCollege": this.noOfChildrenGoingToSchoolNCollege == 0 ? "" : this.typeOfSchoolCollege,
            "NoOfYearsResidingInTheSameProperty": this.noOfYearsResidingInTheSameProperty
        };
    }
}

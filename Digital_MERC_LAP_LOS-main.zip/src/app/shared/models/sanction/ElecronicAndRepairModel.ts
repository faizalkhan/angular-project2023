export interface IElecronicAndRepairModel {
    applicationNo: string;
    loanAccountNumber: string;
    applicantCoappRef: string;
    electronicItem_YN: string;
    computer_YN: string;
    mobile_YN: string;
    other_YN: string;
    shopName: string;
    number_Of_Years: number;
    ownership_Of_Premise: string;
    numOfFam: number;
    numofPartners: number;
    profSharingRatio: string;
    profSharingRatio_Disable: boolean;
    numofEmplyrWorker: number;
    wageFrequency: string;
    locality: string;
    physicalAsset_Details: string;
    countOfAsset: number;
    upI_YN: string;
    numOfJobInADay: number;
    jobsInAMonth: number;
    avgRevenuePerJob: number;
    other_Net_Income: number;
    other_Net_IncomeDetail: string;
    exp_Shoprent_Act: string;
    exp_Electricity_Act: string;
    exp_Consumable_Act: string;
    exp_SalaryLabourCost_Act: string;
    exp_Other_Act: string;
    exp_Act_Total: string;
    exp_Shoprent_Calc: number;
    exp_Electricity_Calc: number;
    exp_Consumable_Calc: number;
    exp_SalaryLabourCost_Calc: number;
    exp_Other_Calc: number;
    exp_Calc_Total: number;
    flO_PsId: string;
    sourceThrough: string;
    createdOn: string;
    toJSON(): any;

}
export class ElecronicAndRepairModel implements IElecronicAndRepairModel {
    applicationNo: string = "";
    applicantCoappRef: string = "";
    electronicItem_YN: string = "";
    computer_YN: string = "";
    mobile_YN: string = "";
    other_YN: string = "";
    shopName: string = "";
    loanAccountNumber: string = "";
    number_Of_Years: number = 0;
    private _ownership_Of_Premise: string = "";

    public get ownership_Of_Premise(): string {
        return this._ownership_Of_Premise;
    }
    public set ownership_Of_Premise(value: string) {
        this._ownership_Of_Premise = value;
    }

    numOfFam: number = 0;

    public get numofPartners(): number {
        return this._numofPartners;
    }
    public set numofPartners(value: any) {
        this._numofPartners = ((value ?? "") == "" ? Number(0) : Number(value));
        this.profSharingRatio_Disable = this._numofPartners == 0;
    }

    private _profSharingRatio_Disable: boolean = false;
    public get profSharingRatio_Disable(): boolean {
        return this._profSharingRatio_Disable;
    }
    public set profSharingRatio_Disable(value: boolean) {
        this._profSharingRatio_Disable = value;
        if (value == true)
            this._profSharingRatio = "0";
    }

    public get profSharingRatio(): string {
        return this._profSharingRatio;
    }
    public set profSharingRatio(value: string) {
        this._profSharingRatio = value;
    }

    private _profSharingRatio: string = "";
    numofEmplyrWorker: number = 0;
    wageFrequency: string = "";
    locality: string = "";
    physicalAsset_Details: string = "";
    countOfAsset: number = 0;
    upI_YN: string = "";

    public get numOfJobInADay(): number {
        return this._numOfJobInADay;
    }
    public set numOfJobInADay(value: number) {
        if(value.toString()===""){
            value=0;
         }
        this._numOfJobInADay = value;
    }
    private _numOfJobInADay: number = 0;
    private _jobsInAMonth: number = 0;

    public get jobsInAMonth(): number {
        return this._jobsInAMonth;
    }
    public set jobsInAMonth(value: number) {
        if(value.toString()===""){
            value=0;
         }
        this._jobsInAMonth = value;
    }

    private _avgRevenuePerJob: number = 0;

    public get avgRevenuePerJob(): number {
        return this._avgRevenuePerJob;
    }
    public set avgRevenuePerJob(value: number) {
        if(value.toString()===""){
            value=0;
         }
        this._avgRevenuePerJob = value;
    }

    private _other_Net_Income: number = 0;
    public get other_Net_Income(): number {
        return this._other_Net_Income;
    }
    public set other_Net_Income(value: number) {
        if(value.toString()===""){
            value=0;
         }
        this._other_Net_Income = value;
    }


    private _other_Net_IncomeDetail: string = "";

    public get other_Net_IncomeDetail(): string {
        return this._other_Net_IncomeDetail;
    }
    public set other_Net_IncomeDetail(value: string) {
        this._other_Net_IncomeDetail = value;
    }

    private _numofPartners: number = 0;
    private _exp_Shoprent_Act: string = "";
    public get exp_Shoprent_Act(): string {
        return this._exp_Shoprent_Act;
    }
    public set exp_Shoprent_Act(value: string) {
        this._exp_Shoprent_Act = value;
        this.totalCalc();
    }
    private _exp_Electricity_Act: string = "";
    public get exp_Electricity_Act(): string {
        return this._exp_Electricity_Act;
    }
    public set exp_Electricity_Act(value: string) {
        this._exp_Electricity_Act = value;
        this.totalCalc();
    }
    private _exp_Consumable_Act: string = "";
    public get exp_Consumable_Act(): string {
        return this._exp_Consumable_Act;
    }
    public set exp_Consumable_Act(value: string) {
        this._exp_Consumable_Act = value;
    }
    private _exp_SalaryLabourCost_Act: string = "";
    public get exp_SalaryLabourCost_Act(): string {
        return this._exp_SalaryLabourCost_Act;
    }
    public set exp_SalaryLabourCost_Act(value: string) {
        this._exp_SalaryLabourCost_Act = value;
        this.totalCalc();
    }
    private _exp_Other_Act: string = "";
    public get exp_Other_Act(): string {
        return this._exp_Other_Act;
    }
    public set exp_Other_Act(value: string) {
        this._exp_Other_Act = value;
        this.totalCalc();
    }
    exp_Act_Total: string = "";
    exp_Shoprent_Calc: number = 0;


    private _exp_Electricity_Calc: number = 0;
    public get exp_Electricity_Calc(): number {
        return this._exp_Electricity_Calc;
    }
    public set exp_Electricity_Calc(value: number) {
        if(value.toString()===""){
            value=0;
         }
        this._exp_Electricity_Calc = value;
        this.totalCalc();
    }

    //exp_Electricity_Calc: number = 0;
    exp_Consumable_Calc: number = 0;
    exp_SalaryLabourCost_Calc: number = 0;
    exp_Other_Calc: number = 0;
    exp_Calc_Total: number = 0;
    flO_PsId: string = "";
    sourceThrough: string = "LOS";
    createdOn: string = "";

    constructor(params?: IElecronicAndRepairModel) {
        if (params) {
            this.applicationNo = params.applicationNo;
            this.loanAccountNumber = params.loanAccountNumber;
            this.applicantCoappRef = params.applicantCoappRef;
            this.electronicItem_YN = params.electronicItem_YN;
            this.computer_YN = params.computer_YN;
            this.mobile_YN = params.mobile_YN;
            this.other_YN = params.other_YN;
              this.shopName = params.shopName;
            this.number_Of_Years = params.number_Of_Years;
            this.ownership_Of_Premise = params.ownership_Of_Premise;
            this.numOfFam = params.numOfFam;
            this.numofPartners = params.numofPartners;
            this.profSharingRatio = params.profSharingRatio;
            this.numofEmplyrWorker = params.numofEmplyrWorker;
            this.wageFrequency = params.wageFrequency;
            this.locality = params.locality;
            this.physicalAsset_Details = params.physicalAsset_Details;
            this.countOfAsset = params.countOfAsset;
            this.upI_YN = params.upI_YN;
            this.numOfJobInADay = params.numOfJobInADay;
            this.jobsInAMonth = params.jobsInAMonth;
            this.avgRevenuePerJob = params.avgRevenuePerJob;
            this.other_Net_Income = params.other_Net_Income;
            this.other_Net_IncomeDetail = params.other_Net_IncomeDetail;
            this.exp_Shoprent_Act = params.exp_Shoprent_Act;
            this.exp_Electricity_Act = params.exp_Electricity_Act;
            this.exp_Consumable_Act = params.exp_Consumable_Act;
            this.exp_SalaryLabourCost_Act = params.exp_SalaryLabourCost_Act;
            this.exp_Other_Act = params.exp_Other_Act;
            this.exp_Act_Total = params.exp_Act_Total;
            this.exp_Shoprent_Calc = params.exp_Shoprent_Calc;
            this.exp_Electricity_Calc = params.exp_Electricity_Calc;
            this.exp_Consumable_Calc = params.exp_Consumable_Calc;
            this.exp_SalaryLabourCost_Calc = params.exp_SalaryLabourCost_Calc;
            this.exp_Other_Calc = params.exp_Other_Calc;
            this.exp_Calc_Total = params.exp_Calc_Total;
            this.flO_PsId = params.flO_PsId;
            this.sourceThrough = params.sourceThrough;
            this.createdOn = params.createdOn;

        }
    }

    totalCalc() {

        var shoprent = 0;
        var electricityCost = 0;
        var salaryExpenses = 0;
        var otherExpenses = 0;
        var consumableExpense = 0;
        shoprent = this.exp_Shoprent_Act != "" ? parseFloat(this.exp_Shoprent_Act) : 0;
        electricityCost = this.exp_Electricity_Calc.toString() != "" ? parseFloat(this.exp_Electricity_Calc.toString()) : 0;
        salaryExpenses = this.exp_SalaryLabourCost_Act != "" ? parseFloat(this.exp_SalaryLabourCost_Act) : 0;
        otherExpenses = this.exp_Other_Act != "" ? parseFloat(this.exp_Other_Act) : 0;
        consumableExpense = this.exp_Consumable_Act != "" ? parseFloat(this.exp_Consumable_Act) : 0;
        this.exp_Calc_Total = shoprent + electricityCost + salaryExpenses + otherExpenses + consumableExpense;
    }

    toJSON(): any {
        return {

            "LoanAccountNumber": this.loanAccountNumber,
            "ApplicationNo": this.applicationNo,
            "ApplicantCoappRef": this.applicantCoappRef,
            "ElectronicItem_YN": this.electronicItem_YN,
            "Computer_YN": this.computer_YN,
            "Mobile_YN": this.mobile_YN,
            "Other_YN": this.other_YN,
            "ShopName": this.shopName,
            "Number_Of_Years": this.number_Of_Years,
            "Ownership_Of_Premise": this.ownership_Of_Premise,
            "NumOfFam": this.numOfFam,
            "NumofPartners": this.numofPartners,
            "ProfSharingRatio": this.profSharingRatio,
            "NumofEmplyrWorker": this.numofEmplyrWorker.toString() === "" ? 0 : this.numofEmplyrWorker,
            "WageFrequency": this.wageFrequency,
            "Locality": this.locality,
            "PhysicalAsset_Details": this.physicalAsset_Details,
            "CountOfAsset": this.countOfAsset,
            "UPI_YN": this.upI_YN,
            "NumOfJobInADay": this.numOfJobInADay,
            "JobsInAMonth": this.jobsInAMonth,
            "AvgRevenuePerJob": this.avgRevenuePerJob,
            "Other_Net_Income": this.other_Net_Income,
            "Other_Net_IncomeDetail": this.other_Net_IncomeDetail,
            "Exp_Shoprent_Act": this.exp_Shoprent_Act == "" ? "0" : this.exp_Shoprent_Act,
            "Exp_Electricity_Act": this.exp_Electricity_Act,
            "Exp_Consumable_Act": this.exp_Consumable_Act,
            "Exp_SalaryLabourCost_Act": this.exp_SalaryLabourCost_Act == "" ? "0" : this.exp_SalaryLabourCost_Act,
            "Exp_Other_Act": this.exp_Other_Act,
            "Exp_Act_Total": this.exp_Act_Total,
            "Exp_Shoprent_Calc": this.exp_Shoprent_Act == "" ? "0" : this.exp_Shoprent_Act,
            "Exp_Electricity_Calc": this.exp_Electricity_Calc,
            "Exp_Consumable_Calc": (!this.exp_Consumable_Act || this.exp_Consumable_Act == '') ? 0 : this.exp_Consumable_Act,
            "Exp_SalaryLabourCost_Calc": this.exp_SalaryLabourCost_Act == "" ? "0" : this.exp_SalaryLabourCost_Act,
            "Exp_Other_Calc": this.exp_Other_Act == "" ? "0" : this.exp_Other_Act,
            "Exp_Calc_Total": this.exp_Calc_Total,
            "FlO_PsId": this.flO_PsId,
            "SourceThrough": this.sourceThrough
        }

    }

}

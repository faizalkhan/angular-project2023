import { common } from "../common";

export interface ISalaried {
    loanAccountNumber: string;
    applicationNo: string;
    employerName: string;
    emplyr_Add: string;
    emplyr_PinCode: string;
    emplyr_Village: string;
    emplyr_District: string;
    emplyr_State: string;
    emplyr_Mob1: string;
    emplyr_Mob2: string;
    emplyr_Industry: string;
    emplyr_Related: string;
    emplyr_Relation: string;
    emplyr_partofLoan_conf: string;
    serviceDuration_Years: number;
    serviceDuration_Months: number;
    highestEducation: string;
    workExp_Total_Years: number;
    workExp_Total_Months: number;
    prev_Emplyr_Name: string;
    prev_Emplyr_Address: string;
    prev_Emplyr_Contact: string;
    salaryMode: string;
    bank_Name: string;
    bank_Acct_Num: string;
    bank_IFSC: string;
    bank_Conf_BankingNorms: string;
    grossSal_Annual: number;
    sal_LastMnth: number;
    sal_2ndLastMnth: number;
    sal_3rdLastMnth: number;
    var_Pay: number;
    sal_Doc_Confirmation: string;
    upload_Doc_1: string;
    upload_Doc_1_DocType: string;
    upload_Doc1_MimeType: string;
    upload_Doc1ImgExtension: string;
    upload_Doc2_MimeType: string;
    upload_Doc2ImgExtension: string;
    upload_Doc3_MimeType: string;
    upload_Doc3ImgExtension: string;
    upload_Doc4_MimeType: string;
    upload_Doc4ImgExtension: string;
    upload_Doc5_MimeType: string;
    upload_Doc5ImgExtension: string;
    upload_Doc_2: string;
    upload_Doc_2_DocType: string;
    upload_Doc_3: string;
    upload_Doc_3_DocType: string;
    upload_Doc_4: string;
    upload_Doc_4_DocType: string;
    upload_Doc_5: string;
    upload_Doc_5_DocType: string;
    other_Source: string;
    source_Details: string;
    net_Other_Income: number;
    applicantCoappRef: string;
    flO_PsId: string;
    sourceThrough: string;
    createdOn: string;
    assessed_income: number;
    growth_Rate: number;
    monthly_Sal_income: number;
    monthly_variables: number;
    monthly_other_source: number;

    toJson(): any;
}
export interface IUploadDoc {
    ref_No: string;
    description: string;
    other: string;
    otherDescriptions: string;
}
export class UploadDoc implements IUploadDoc {
    private _ref_No: string = "";
    public get ref_No(): string {
        return this._ref_No;
    }
    public set ref_No(value: string) {
        this._ref_No = value;
    }
    private _description: string = "";
    public get description(): string {
        return this._description;
    }
    public set description(value: string) {
        this._description = value;
    }
    private _other: string = "";
    public get other(): string {
        return this._other;
    }
    public set other(value: string) {
        this._other = value;
        if (value && value != "") {
            this.otherDescriptions = `${this.description} ${this.other}`;
        }
    }
    private _otherDescriptions: string = "";
    public get otherDescriptions(): string {
        return this._otherDescriptions;
    }
    public set otherDescriptions(value: string) {
        this._otherDescriptions = value;
    }
    // public get otherDescriptions(): string {
    //     if (this.description && this.other) {
    //         return `${this.description} ${this.other}`;
    //     }
    //     else
    //         return '';
    // }
    constructor(params?: IUploadDoc) {
        if (params) {
            common.ObjectMapping(params, this);
            this.other = this.description.toLowerCase().indexOf('others') != -1 ? this.description.replace('Others ', '') : '';
            this.description = this.description.toLowerCase().indexOf('others') != -1 ? 'Others' : this.description;
        }
    }

}
export class SalariedModel implements ISalaried {
    constructor(params?: ISalaried) {
        if (params) {
            this.applicationNo = params.applicationNo;
            this.employerName = params.employerName;
            this.emplyr_Add = params.emplyr_Add;
            this.emplyr_PinCode = params.emplyr_PinCode;
            this.emplyr_Village = params.emplyr_Village;
            this.emplyr_District = params.emplyr_District;
            this.emplyr_State = params.emplyr_State;
            this.emplyr_Mob1 = params.emplyr_Mob1;
            this.emplyr_Mob2 = params.emplyr_Mob2;
            this.emplyr_Industry = params.emplyr_Industry;
            this.emplyr_Related = params.emplyr_Related;
            this.emplyr_Relation = params.emplyr_Relation;
            this.emplyr_partofLoan_conf = params.emplyr_partofLoan_conf;
            this.serviceDuration_Years = params.serviceDuration_Years;
            this.serviceDuration_Months = params.serviceDuration_Months;
            this.highestEducation = params.highestEducation;
            this.workExp_Total_Years = params.workExp_Total_Years;
            this.workExp_Total_Months = params.workExp_Total_Months;
            this.prev_Emplyr_Name = params.prev_Emplyr_Name;
            this.prev_Emplyr_Address = params.prev_Emplyr_Address;
            this.prev_Emplyr_Contact = params.prev_Emplyr_Contact;
            this.salaryMode = params.salaryMode;
            this.bank_Name = params.bank_Name;
            this.bank_Acct_Num = params.bank_Acct_Num;
            this.bank_IFSC = params.bank_IFSC;
            this.bank_Conf_BankingNorms = params.bank_Conf_BankingNorms;
            this.grossSal_Annual = params.grossSal_Annual;
            this.sal_LastMnth = params.sal_LastMnth;
            this.sal_2ndLastMnth = params.sal_2ndLastMnth;
            this.sal_3rdLastMnth = params.sal_3rdLastMnth;
            this.var_Pay = params.var_Pay;
            this.sal_Doc_Confirmation = params.sal_Doc_Confirmation;
            this.upload_Doc_1 = params.upload_Doc_1;
            this.upload_Doc_1_DocType = params.upload_Doc_1_DocType;
            this.upload_Doc_2 = params.upload_Doc_2;
            this.upload_Doc_2_DocType = params.upload_Doc_2_DocType;
            this.upload_Doc_3 = params.upload_Doc_3;
            this.upload_Doc_3_DocType = params.upload_Doc_3_DocType;
            this.upload_Doc_4 = params.upload_Doc_4;
            this.upload_Doc_4_DocType = params.upload_Doc_4_DocType;
            this.upload_Doc_5 = params.upload_Doc_5;
            this.upload_Doc_5_DocType = params.upload_Doc_5_DocType;
            this.upload_Doc1_MimeType = params.upload_Doc1_MimeType;
            this.upload_Doc1ImgExtension = params.upload_Doc1ImgExtension;
            this.upload_Doc2_MimeType = params.upload_Doc2_MimeType;
            this.upload_Doc2ImgExtension = params.upload_Doc2ImgExtension;
            this.upload_Doc3_MimeType = params.upload_Doc3_MimeType;
            this.upload_Doc3ImgExtension = params.upload_Doc3ImgExtension;
            this.upload_Doc4_MimeType = params.upload_Doc4_MimeType;
            this.upload_Doc4ImgExtension = params.upload_Doc4ImgExtension;
            this.upload_Doc5_MimeType = params.upload_Doc5_MimeType;
            this.upload_Doc5ImgExtension = params.upload_Doc5ImgExtension;
            this.other_Source = params.other_Source;
            this.source_Details = params.source_Details;
            this.net_Other_Income = params.net_Other_Income;
            this.applicantCoappRef = params.applicantCoappRef;
            this.flO_PsId = params.flO_PsId;
            this.assessed_income = params.assessed_income;
            this.growth_Rate = params.growth_Rate;
            this.monthly_Sal_income = params.monthly_Sal_income;
            this.monthly_variables = params.monthly_variables;
            this.monthly_other_source = params.monthly_other_source;
            this.loanAccountNumber = params.loanAccountNumber;
            this.upload_Docs = this.GetUploadDocs()
        }

        this.Calculation();
    }
    GetUploadDocs(): IUploadDoc[] {
        let datas: IUploadDoc[] = [];
        let data: IUploadDoc;
        if (this.upload_Doc_1 && this.upload_Doc_1 != "") {
            data = new UploadDoc({ ref_No: this.upload_Doc_1, description: this.upload_Doc_1_DocType } as IUploadDoc);
            datas.push(data);
        }
        if (this.upload_Doc_2 && this.upload_Doc_2 != "") {
            data = new UploadDoc({ ref_No: this.upload_Doc_2, description: this.upload_Doc_2_DocType } as IUploadDoc);
            datas.push(data);
        }
        if (this.upload_Doc_3 && this.upload_Doc_3 != "") {
            data = new UploadDoc({ ref_No: this.upload_Doc_3, description: this.upload_Doc_3_DocType } as IUploadDoc);
            datas.push(data);
        }
        if (this.upload_Doc_4 && this.upload_Doc_4 != "") {
            data = new UploadDoc({ ref_No: this.upload_Doc_4, description: this.upload_Doc_4_DocType } as IUploadDoc);
            datas.push(data);
        }
        if (this.upload_Doc_5 && this.upload_Doc_5 != "") {
            data = new UploadDoc({ ref_No: this.upload_Doc_5, description: this.upload_Doc_5_DocType } as IUploadDoc);
            datas.push(data);
        }

        return datas;
    }

    loanAccountNumber: string = "";
    applicationNo: string = "";
    //Employer info
    employerName: string = "";
    emplyr_Add: string = "";
    emplyr_PinCode: string = "";
    emplyr_Village: string = "";
    emplyr_District: string = "";
    emplyr_State: string = "";
    emplyr_Mob1: string = "";
    emplyr_Mob2: string = "";
    emplyr_Industry: string = "";
    private _emplyr_Related: string = "";
    public get emplyr_Related(): string {
        return this._emplyr_Related;
    }
    public set emplyr_Related(value: string) {
        this._emplyr_Related = value;
        if (value && value.toLowerCase() == 'n') {
            this.emplyr_Relation = "";
            this.emplyr_partofLoan_conf = "";
        }
    }
    private _emplyr_Relation: string = "";
    public get emplyr_Relation(): string {
        return this._emplyr_Relation;
    }
    public set emplyr_Relation(value: string) {
        this._emplyr_Relation = value;
    }
    private _emplyr_partofLoan_conf: string = "";
    public get emplyr_partofLoan_conf(): string {
        return this._emplyr_partofLoan_conf;
    }
    public set emplyr_partofLoan_conf(value: string) {
        this._emplyr_partofLoan_conf = value;
    }
    //Experience
    serviceDuration_Years: any = 0;
    serviceDuration_Months: any = 0;
    highestEducation: string = "";
    workExp_Total_Years: any = 0;
    workExp_Total_Months: any = 0;
    get serviceYear(): any {
        let serviceYear = (this.serviceDuration_Years != "" ? Number(this.serviceDuration_Years ?? 0) : 0) * 12;
        let serviceMonth = this.serviceDuration_Months != "" ? Number(this.serviceDuration_Months ?? 0) : 0;
        return (serviceYear + serviceMonth);
    }
    get workedYear(): any {
        let workedYear = (this.workExp_Total_Years != "" ? Number(this.workExp_Total_Years ?? 0) : 0) * 12;
        let workedMonth = this.workExp_Total_Months != "" ? Number(this.workExp_Total_Months ?? 0) : 0;
        return (workedYear + workedMonth);
    }
    get isPreviousExp(): boolean {
        return this.serviceYear < this.workedYear == false;
    }
    private _prev_Emplyr_Name: string = "";
    public get prev_Emplyr_Name(): string {
        return this.isPreviousExp ? "" : this._prev_Emplyr_Name;
    }
    public set prev_Emplyr_Name(value: string) {
        this._prev_Emplyr_Name = value;
    }
    private _prev_Emplyr_Address: string = "";
    public get prev_Emplyr_Address(): string {
        return this.isPreviousExp ? "" : this._prev_Emplyr_Address;
    }
    public set prev_Emplyr_Address(value: string) {
        this._prev_Emplyr_Address = value;
    }
    private _prev_Emplyr_Contact: string = "";
    public get prev_Emplyr_Contact(): string {
        return this.isPreviousExp ? "" : this._prev_Emplyr_Contact;
    }
    public set prev_Emplyr_Contact(value: string) {
        this._prev_Emplyr_Contact = value;
    }
    //Bank detail
    salaryMode: string = "";
    bank_Name: string = "";
    bank_Acct_Num: string = "";
    bank_IFSC: string = "";
    bank_Conf_BankingNorms: string = "";

    private _grossSal_Annual: number = 0;
    public get grossSal_Annual(): number {
        return this._grossSal_Annual;
    }
    public set grossSal_Annual(value: any) {
        this._grossSal_Annual = value != "" ? Number.parseFloat(value) : 0;
        this.Calculation();
    }
    private _sal_LastMnth: number = 0;
    public get sal_LastMnth(): number {
        return this._sal_LastMnth;
    }
    public set sal_LastMnth(value: any) {
        this._sal_LastMnth = value != "" ? Number.parseFloat(value) : 0;
        this.Calculation();
    }
    private _sal_2ndLastMnth: number = 0;
    public get sal_2ndLastMnth(): number {
        return this._sal_2ndLastMnth;
    }
    public set sal_2ndLastMnth(value: any) {
        this._sal_2ndLastMnth = value != "" ? Number.parseFloat(value) : 0;
        this.Calculation();
    }
    private _sal_3rdLastMnth: number = 0;
    public get sal_3rdLastMnth(): number {
        return this._sal_3rdLastMnth;
    }
    public set sal_3rdLastMnth(value: any) {
        this._sal_3rdLastMnth = value != "" ? Number.parseFloat(value) : 0;
        this.Calculation();
    }
    private _var_Pay: number = 0;
    public get var_Pay(): number {
        return this._var_Pay;
    }
    public set var_Pay(value: any) {
        this._var_Pay = value != "" ? Number.parseFloat(value) : 0;
        this.Calculation();
    }

    sal_Doc_Confirmation: string = "";
    upload_Doc_1: string = "";
    upload_Doc_1_DocType: string = "";
    upload_Doc_2: string = "";
    upload_Doc_2_DocType: string = "";
    upload_Doc_3: string = "";
    upload_Doc_3_DocType: string = "";
    upload_Doc_4: string = "";
    upload_Doc_4_DocType: string = "";
    upload_Doc_5: string = "";
    upload_Doc_5_DocType: string = "";

    upload_Doc1_MimeType: string = "";
    upload_Doc1ImgExtension: string = "";
    upload_Doc2_MimeType: string = "";
    upload_Doc2ImgExtension: string = "";
    upload_Doc3_MimeType: string = "";
    upload_Doc3ImgExtension: string = "";
    upload_Doc4_MimeType: string = "";
    upload_Doc4ImgExtension: string = "";
    upload_Doc5_MimeType: string = "";
    upload_Doc5ImgExtension: string = "";

    private _upload_Docs: IUploadDoc[] = [];
    public get upload_Docs(): IUploadDoc[] {
        return this._upload_Docs;
    }
    public set upload_Docs(value: IUploadDoc[]) {
        this._upload_Docs = value;
    }
    other_Source: string = "";
    source_Details: string = "";
    private _net_Other_Income: number = 0;
    public get net_Other_Income(): number {
        return this._net_Other_Income;
    }
    public set net_Other_Income(value: any) {
        this._net_Other_Income = value != "" ? Number.parseFloat(value) : 0;
        this.Calculation();
    }
    applicantCoappRef: string = "";
    flO_PsId: string = "";

    public get sourceThrough(): string {
        return "LOS";
    }
    public get createdOn(): string {
        let date = new Date();
        return `${date.getFullYear()}-${date.getMonth()}-${date.getDay()}`
    }

    //calculation part
    private _assessed_income: number = 0;
    public get assessed_income(): number {
        return this._assessed_income;
    }
    public set assessed_income(value: any) {
        this._assessed_income = value != "" ? Number.parseFloat(value) : 0;
    }
    private _growth_Rate: number = 0;
    public get growth_Rate(): number {
        return this._growth_Rate;
    }
    public set growth_Rate(value: any) {
        this._growth_Rate = value != "" ? Number.parseFloat(value) : 0;
    }
    private _monthly_Sal_income: number = 0;
    public get monthly_Sal_income(): number {
        return this._monthly_Sal_income;
    }
    public set monthly_Sal_income(value: any) {
        this._monthly_Sal_income = value != "" ? Number.parseFloat(value) : 0;
    }
    monthly_variables: number = 0;
    monthly_other_source: number = 0;



    Calculation() {

        //Growth Rate
        this.growth_Rate = 0;
        if (this.sal_LastMnth && this.sal_2ndLastMnth && this.sal_3rdLastMnth) {
            this.growth_Rate = ((((this.sal_LastMnth ?? 0) - (this.sal_3rdLastMnth ?? 0)) / (this.sal_3rdLastMnth ?? 0)) * 100).toFixed();
        }
        //monthly salary income.
        this.monthly_Sal_income = 0;
        if (this.growth_Rate <= 10) {
            this.monthly_Sal_income = this.sal_LastMnth;
        }
        else {
            this.monthly_Sal_income = (((this.sal_LastMnth ?? 0) + (this.sal_2ndLastMnth ?? 0) + (this.sal_3rdLastMnth ?? 0)) / 3).toFixed(2);
        }
        //monthly_variables
        if (this.var_Pay ?? 0 <= (0.4 * (this.grossSal_Annual / 12))) {
            this.monthly_variables = this.var_Pay ?? 0;
        }
        else {
            this.monthly_variables = (0.4 * (this.grossSal_Annual / 12));
        }

        //monthly_other_source
        if (this.other_Source ?? 0 <= (0.4 * (this.grossSal_Annual / 12))) {
            this.monthly_other_source = this.var_Pay ?? 0;
        }
        else {
            this.monthly_other_source = (0.4 * (this.grossSal_Annual / 12));
        }

        //Assessed Income
        this.assessed_income = ((this.monthly_Sal_income ?? 0) + (this.monthly_variables ?? 0) + (this.monthly_other_source ?? 0)).toFixed(2);

    }
    toJsonWithoutImage() {
        return {
            "ApplicationNo": this.applicationNo,
            "EmployerName": this.employerName,
            "Emplyr_Add": this.emplyr_Add,
            "Emplyr_PinCode": this.emplyr_PinCode,
            "Emplyr_Village": this.emplyr_Village,
            "Emplyr_District": this.emplyr_District,
            "Emplyr_State": this.emplyr_State,
            "Emplyr_Mob1": this.emplyr_Mob1,
            "Emplyr_Mob2": this.emplyr_Mob2,
            "Emplyr_Industry": this.emplyr_Industry,
            "Emplyr_Related": this.emplyr_Related,
            "Emplyr_Relation": this.emplyr_Relation,
            "Emplyr_partofLoan_conf": this.emplyr_partofLoan_conf,
            "ServiceDuration_Years": this.serviceDuration_Years,
            "ServiceDuration_Months": this.serviceDuration_Months,
            "HighestEducation": this.highestEducation,
            "WorkExp_Total_Years": this.workExp_Total_Years,
            "WorkExp_Total_Months": this.workExp_Total_Months,
            "Prev_Emplyr_Name": this.prev_Emplyr_Name,
            "Prev_Emplyr_Address": this.prev_Emplyr_Address,
            "Prev_Emplyr_Contact": this.prev_Emplyr_Contact,
            "SalaryMode": this.salaryMode,
            "Bank_Name": this.bank_Name,
            "Bank_Acct_Num": this.bank_Acct_Num,
            "Bank_IFSC": this.bank_IFSC,
            "Bank_Conf_BankingNorms": this.bank_Conf_BankingNorms,
            "GrossSal_Annual": this.grossSal_Annual.toFixed(2),
            "Sal_LastMnth": this.sal_LastMnth.toFixed(2),
            "Sal_2ndLastMnth": this.sal_2ndLastMnth.toFixed(2),
            "Sal_3rdLastMnth": this.sal_3rdLastMnth.toFixed(2),
            "Var_Pay": this.var_Pay.toFixed(2),
            "Sal_Doc_Confirmation": this.sal_Doc_Confirmation,
            "Upload_Doc_1_DocType": this.upload_Doc_1_DocType,
            "Upload_Doc_2_DocType": this.upload_Doc_2_DocType,
            "Upload_Doc_3_DocType": this.upload_Doc_3_DocType,
            "Upload_Doc_4_DocType": this.upload_Doc_4_DocType,
            "Upload_Doc_5_DocType": this.upload_Doc_5_DocType,
            "Upload_Doc1_MimeType": this.upload_Doc1_MimeType,
            "Upload_Doc1ImgExtension": this.upload_Doc1ImgExtension,
            "Upload_Doc2_MimeType": this.upload_Doc2_MimeType,
            "Upload_Doc2ImgExtension": this.upload_Doc2ImgExtension,
            "Upload_Doc3_MimeType": this.upload_Doc3_MimeType,
            "Upload_Doc3ImgExtension": this.upload_Doc3ImgExtension,
            "Upload_Doc4_MimeType": this.upload_Doc4_MimeType,
            "Upload_Doc4ImgExtension": this.upload_Doc4ImgExtension,
            "Upload_Doc5_MimeType": this.upload_Doc5_MimeType,
            "Upload_Doc5ImgExtension": this.upload_Doc5ImgExtension,
            "Other_Source": this.other_Source,
            "Source_Details": this.source_Details,
            "Net_Other_Income": this.net_Other_Income.toFixed(2),
            "ApplicantCoappRef": this.applicantCoappRef,
            "FLO_PsId": this.flO_PsId,
            "SourceThrough": "LOS",
            "LoanAccountNumber": this.loanAccountNumber,
        };
    }
    toJson() {
        return {
            "ApplicationNo": this.applicationNo,
            "EmployerName": this.employerName,
            "Emplyr_Add": this.emplyr_Add,
            "Emplyr_PinCode": this.emplyr_PinCode,
            "Emplyr_Village": this.emplyr_Village,
            "Emplyr_District": this.emplyr_District,
            "Emplyr_State": this.emplyr_State,
            "Emplyr_Mob1": this.emplyr_Mob1,
            "Emplyr_Mob2": this.emplyr_Mob2,
            "Emplyr_Industry": this.emplyr_Industry,
            "Emplyr_Related": this.emplyr_Related,
            "Emplyr_Relation": this.emplyr_Relation,
            "Emplyr_partofLoan_conf": this.emplyr_partofLoan_conf,
            "ServiceDuration_Years": this.serviceDuration_Years,
            "ServiceDuration_Months": this.serviceDuration_Months,
            "HighestEducation": this.highestEducation,
            "WorkExp_Total_Years": this.workExp_Total_Years,
            "WorkExp_Total_Months": this.workExp_Total_Months,
            "Prev_Emplyr_Name": this.prev_Emplyr_Name,
            "Prev_Emplyr_Address": this.prev_Emplyr_Address,
            "Prev_Emplyr_Contact": this.prev_Emplyr_Contact,
            "SalaryMode": this.salaryMode,
            "Bank_Name": this.bank_Name,
            "Bank_Acct_Num": this.bank_Acct_Num,
            "Bank_IFSC": this.bank_IFSC,
            "Bank_Conf_BankingNorms": this.bank_Conf_BankingNorms,
            "GrossSal_Annual": this.grossSal_Annual.toFixed(2),
            "Sal_LastMnth": this.sal_LastMnth.toFixed(2),
            "Sal_2ndLastMnth": this.sal_2ndLastMnth.toFixed(2),
            "Sal_3rdLastMnth": this.sal_3rdLastMnth.toFixed(2),
            "Var_Pay": this.var_Pay.toFixed(2),
            "Sal_Doc_Confirmation": this.sal_Doc_Confirmation,
            "Upload_Doc_1": this.upload_Doc_1,
            "Upload_Doc_1_DocType": this.upload_Doc_1_DocType,
            "Upload_Doc_2": this.upload_Doc_2,
            "Upload_Doc_2_DocType": this.upload_Doc_2_DocType,
            "Upload_Doc_3": this.upload_Doc_3,
            "Upload_Doc_3_DocType": this.upload_Doc_3_DocType,
            "Upload_Doc_4": this.upload_Doc_4,
            "Upload_Doc_4_DocType": this.upload_Doc_4_DocType,
            "Upload_Doc_5": this.upload_Doc_5,
            "Upload_Doc_5_DocType": this.upload_Doc_5_DocType,
            "Upload_Doc1_MimeType": this.upload_Doc1_MimeType,
            "Upload_Doc1ImgExtension": this.upload_Doc1ImgExtension,
            "Upload_Doc2_MimeType": this.upload_Doc2_MimeType,
            "Upload_Doc2ImgExtension": this.upload_Doc2ImgExtension,
            "Upload_Doc3_MimeType": this.upload_Doc3_MimeType,
            "Upload_Doc3ImgExtension": this.upload_Doc3ImgExtension,
            "Upload_Doc4_MimeType": this.upload_Doc4_MimeType,
            "Upload_Doc4ImgExtension": this.upload_Doc4ImgExtension,
            "Upload_Doc5_MimeType": this.upload_Doc5_MimeType,
            "Upload_Doc5ImgExtension": this.upload_Doc5ImgExtension,
            "Other_Source": this.other_Source,
            "Source_Details": this.source_Details,
            "Net_Other_Income": this.net_Other_Income.toFixed(2),
            "ApplicantCoappRef": this.applicantCoappRef,
            "FLO_PsId": this.flO_PsId,
            "SourceThrough": "LOS",
            "LoanAccountNumber": this.loanAccountNumber,
        };
    }
}

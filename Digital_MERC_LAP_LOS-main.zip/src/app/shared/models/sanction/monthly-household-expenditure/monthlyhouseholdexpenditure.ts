import { DecimalPipe } from "@angular/common";
import { common } from "../../common";

export interface IMonthlyHouseholdExpenditure {
    loanAccountNumber: any;
    rent: number;
    electricityWaterGas: number;
    otherUtilities: number;
    transportAndOtherConveyanceExp: number;
    schoolCollegeFees: number;
    foodNOtherHouseholdExp: number;
    insuranceMediclaimPremium: number;
    otherMonthlyExpenses: number;
    entertainmentReligiousExpensesMonthly: number;
    totalExpenses: number;
    flO_PsId: any;
    sourceThrough: any;
    createdOn: any;
    isError: boolean;
    errorMessage: string;
    toJSON(): any;
    Validation(): any;
}
export class MonthlyHouseholdExpenditure implements IMonthlyHouseholdExpenditure {
    constructor(params?: IMonthlyHouseholdExpenditure) {
        if (params) {
            common.ObjectMapping(params, this);
        }
    }
    private _isError: boolean = false;
    public get isError(): boolean {
        return this._isError;
    }
    public set isError(value: boolean) {
        this._isError = value;
    }
    private _errorMessage: string = "";
    public get errorMessage(): string {
        return this._errorMessage;
    }
    public set errorMessage(value: string) {
        this._errorMessage = value;
    }
    private _loanAccountNumber: any = "";
    public get loanAccountNumber(): any {
        return this._loanAccountNumber;
    }
    public set loanAccountNumber(value: any) {
        this._loanAccountNumber = value;
    }
    private _rent: number = 0;
    public get rent(): number {
        return this._rent;
    }
    public set rent(value: number) {
        this._rent = value;
    }
    private _electricityWaterGas: number = 0;
    public get electricityWaterGas(): number {
        return this._electricityWaterGas;
    }
    public set electricityWaterGas(value: number) {
        this._electricityWaterGas = value;
    }
    private _otherUtilities: number = 0;
    public get otherUtilities(): number {
        return this._otherUtilities;
    }
    public set otherUtilities(value: number) {
        this._otherUtilities = value;
    }
    private _transportAndOtherConveyanceExp: number = 0;
    public get transportAndOtherConveyanceExp(): number {
        return this._transportAndOtherConveyanceExp;
    }
    public set transportAndOtherConveyanceExp(value: number) {
        this._transportAndOtherConveyanceExp = value;
    }
    private _schoolCollegeFees: number = 0;
    public get schoolCollegeFees(): number {
        return this._schoolCollegeFees;
    }
    public set schoolCollegeFees(value: number) {
        this._schoolCollegeFees = value;
    }
    private _foodNOtherHouseholdExp: number = 0;
    public get foodNOtherHouseholdExp(): number {
        return this._foodNOtherHouseholdExp;
    }
    public set foodNOtherHouseholdExp(value: number) {
        this._foodNOtherHouseholdExp = value;
    }
    private _insuranceMediclaimPremium: number = 0;
    public get insuranceMediclaimPremium(): number {
        return this._insuranceMediclaimPremium;
    }
    public set insuranceMediclaimPremium(value: number) {
        this._insuranceMediclaimPremium = value;
    }
    private _otherMonthlyExpenses: number = 0;
    public get otherMonthlyExpenses(): number {
        return this._otherMonthlyExpenses;
    }
    public set otherMonthlyExpenses(value: number) {
        this._otherMonthlyExpenses = value;
    }
    private _entertainmentReligiousExpensesMonthly: number = 0;
    public get entertainmentReligiousExpensesMonthly(): number {
        return this._entertainmentReligiousExpensesMonthly;
    }
    public set entertainmentReligiousExpensesMonthly(value: number) {
        this._entertainmentReligiousExpensesMonthly = value;
    }
    private _flO_PsId: any="";
    public get flO_PsId(): any {
        return this._flO_PsId;
    }
    public set flO_PsId(value: any) {
        this._flO_PsId = value;
    }
    private _sourceThrough: any="";
    public get sourceThrough(): any {
        return this._sourceThrough;
    }
    public set sourceThrough(value: any) {
        this._sourceThrough = value;
    }
    private _createdOn: any;
    public get createdOn(): any {
        return this._createdOn;
    }
    public set createdOn(value: any) {
        this._createdOn = value;
    }


    public get totalExpenses(): number {
        var totalExp = 0;
        if (this.insuranceMediclaimPremium)
            totalExp += Number(this.insuranceMediclaimPremium);
        if (this.transportAndOtherConveyanceExp)
            totalExp += Number(this.transportAndOtherConveyanceExp);
        if (this.schoolCollegeFees)
            totalExp += Number(this.schoolCollegeFees);
        if (this.foodNOtherHouseholdExp)
            totalExp += Number(this.foodNOtherHouseholdExp);
        if (this.otherMonthlyExpenses)
            totalExp += Number(this.otherMonthlyExpenses);
        if (this.entertainmentReligiousExpensesMonthly)
            totalExp += Number(this.entertainmentReligiousExpensesMonthly);
        if (this.rent)
            totalExp += Number(this.rent);
        if (this.electricityWaterGas)
            totalExp += Number(this.electricityWaterGas);
        if (this.otherUtilities)
            totalExp += Number(this.otherUtilities);
        return totalExp;
    }

    toJSON() {
        return {
            "ElectricityWaterGas": String(this.electricityWaterGas),
            "EntertainmentReligiousExpensesMonthly": String(this.entertainmentReligiousExpensesMonthly),
            "FLO_PsId": this.flO_PsId,
            "FoodNOtherHouseholdExp": String(this.foodNOtherHouseholdExp),
            "InsuranceMediclaimPremium": String(this.insuranceMediclaimPremium),
            "LoanAccountNumber": String(this.loanAccountNumber),
            "OtherMonthlyExpenses": String(this.otherMonthlyExpenses),
            "OtherUtilities": String(this.otherUtilities),
            "Rent": String(this.rent),
            "SchoolCollegeFees": String(this.schoolCollegeFees),
            "SourceThrough": "LOS",
            "TotalExpenses": String(this.totalExpenses),
            "TransportAndOtherConveyanceExp": String(this.transportAndOtherConveyanceExp)
        };
    }

    Validation() {
        this.isError = false;
        if (this.rent.toString() == "") {
            this.isError = true;
            this.errorMessage = "Rent is required";
        }
        else if (this.foodNOtherHouseholdExp.toString() == "") {
            this.isError = true;
            this.errorMessage = "Food and other household expenses is required";
        }
        else if (this.electricityWaterGas.toString() == "") {
            this.isError = true;
            this.errorMessage = "Electricity/Water/Gas is required";
        }
        else if (this.insuranceMediclaimPremium.toString() == "") {
            this.isError = true;
            this.errorMessage = "Insurance/Mediclaim premium is required";
        }
        else if (this.otherUtilities.toString() == "") {
            this.isError = true;
            this.errorMessage = "Other utillities(Mobile/Data/Cable etc) is required";
        }
        else if (this.otherMonthlyExpenses.toString() == "") {
            this.isError = true;
            this.errorMessage = "Other Monthly Expenses is required";
        }
        else if (this.transportAndOtherConveyanceExp.toString() == "") {
            this.isError = true;
            this.errorMessage = "Transport and other conveyance expenses is required";
        }
        else if (this.entertainmentReligiousExpensesMonthly.toString() == "") {
            this.isError = true;
            this.errorMessage = "Entertainment/ Religious Expenses Monthly is required";
        }
        else if (this.schoolCollegeFees.toString() == "") {
            this.isError = true;
            this.errorMessage = "School/Collage fees is required";
        }
    }

}
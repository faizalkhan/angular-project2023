

export interface IApplicant {
    name: string;
    contact_Number: string;
    financial_Status: string;
    type_of_Applicant: string;
    salary_Occupation_Status: string;
    date_of_Birth: string;
    relationship_with_applicant: string;
    gender: string;
    email_id: string;
    kyC_1_Type: string;
    kyC_1_Details: string;
    kyC_1_Status: string;
    kyC_1_Image: string;
    kyC_2_Type: string;
    kyC_2_Details: string;
    kyC_2_Status: string;
    kyC_2_Image: string;
    isapplicant: string;
    currentAddress: string;
    permanentAddress: string;
    applicationNo: string;
    form60_Ref: string;
    address_Ref:string;
    Ka1_Front_Ref:string;
    Ka1_Back_Ref:string;
    PAN_Ref:string;
}

export interface ISanctionDashboardModel {
    lan: string;
    applicantName: string;
    contactNo: string;
    loginDate: string;
    scheme: string;
    appliedTenure: string;
    pinCode: string;
    appliedLoanAmount: string;
    technical_Check: string;
    sanctionStatus: string;
    rcuStatus: string;
    legalStatus: string;
    technicalStatus: string;
    dateSourced: Date;
    flopsid: string;
    branch: string;
    leadId: string;
    mcCode: string;
    readOnly: boolean;
}

export class SanctionDashboardModel implements ISanctionDashboardModel {
    lan: string = "";
    applicantName: string = "";
    contactNo: string = "";
    loginDate: string = "";
    scheme: string = "";
    appliedTenure: string = "";
    pinCode: string = "";
    appliedLoanAmount: string = "";
    technical_Check: string = "";
    sanctionStatus: string = "";
    rcuStatus: string = "";
    legalStatus: string = "";
    technicalStatus: string = "";
    dateSourced: Date = new Date();
    flopsid: string = "";
    branch: string = "";
    leadId: string = "";
    mcCode: string = "";
    readOnly: boolean = false;

    constructor(params?: ISanctionDashboardModel) {
        if (params) {
            this.lan = params.lan;
            this.applicantName = params.applicantName;
            this.contactNo = params.contactNo;
            this.loginDate = params.loginDate;
            this.technical_Check = params.technical_Check;
            this.sanctionStatus = params.sanctionStatus;
            this.rcuStatus = params.rcuStatus;
            this.legalStatus = params.legalStatus;
            this.technicalStatus = params.technicalStatus;
            this.dateSourced = params.dateSourced;
            this.flopsid = params.flopsid;
            this.branch = params.branch;
            this.readOnly = params.readOnly;
            this.leadId = params.leadId;
        }
        this.mcCode = "MC919";
    }




}
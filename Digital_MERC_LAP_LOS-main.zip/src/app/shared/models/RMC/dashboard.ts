// export interface RMCApplicationDashboardModel{
    
//         lan: string;
//         applicantName: string;
//         technical_Check: string;
//         sanctionStatus: string;
//         rcuStatus: string;
//         legalStatus: string;
//         technicalStatus: string;
//         dateSourced: Date;
//         flopsid: string;
//         branch: string; 
// }


export interface IRMCApplicationDashboardModel {
        applicationNo: string;
        name: string;  
        state:string;
        executive_ID:string;
        executive_Name:string;
        mobileNo: string; 
        ageing: string;   
        category: string;
        loanAccountNumber:string; 
        leadID:string;
        type:string; 
        status:string;   
    }

    
    export class RMCApplicationDashboardModel implements IRMCApplicationDashboardModel {
        applicationNo: string="";
        name: string=""; 
        state:string="";
        executive_ID:string="";
        executive_Name:string="";
        mobileNo: string="";       
        ageing: string="";        
        category: string="";
        loanAccountNumber:string=""; 
        leadID: string="";
        type: string="";
        status:string='';        
        constructor(params?: IRMCApplicationDashboardModel) {
            if (params) {
               
                this.name= params.name;  
                this.state=params.state;
                this.executive_ID=params.executive_ID;
                this.executive_Name=params.executive_Name;
                this.mobileNo=params.mobileNo; 
                this.ageing=params.ageing;  
                this.category=params.category;       
                this.applicationNo = params.applicationNo;
                this.loanAccountNumber = params.loanAccountNumber;
                this.leadID = params.leadID;
                this.type=params.type; 
                this.status=params.status; 
            }  
        } 
    }
    

export interface IRMCApplicationModel{
        rmcData : RMCData;
        docs : RMCDocumentInfo[];
        invalidPropertyDocEntry: boolean;
        invalidMutationDocEntry: boolean;
        invalidPropertyTaxRecDocEntry: boolean;
        invalidChainDocDocEntry: boolean;
        invalidOtherPropertyDocEntry: boolean;
        invalidLegalReportDocEntry: boolean;
        invalidTechnicalReportDocEntry: boolean;
        invalidMODTDocEntry: boolean;
        invalidSPDC1DocEntry: boolean;
        invalidSPDC2DocEntry: boolean;
        invalidSPDC3DocEntry: boolean;
        invalidPhysicalMandateDocEntry: boolean;
}

export class RMCData{
        lan: string='';
        userID: string='';
        barcode_File: string='';
        barcode_Pouch: string='';
        poD_Number: number=0;
        poD_Date: Date= new Date();
        createdBy: string='';
        createdOn: Date=new Date();
        modifiedBy: string='';
        modifiedOn: Date= new Date();
        courierName: string='';
        courierDate: Date=new Date('');
        officeBoyName: string='';
        officeBoyMobileNo: string='';
        status:string='';
}

export class RMCApplicationModel implements IRMCApplicationModel{

        /**
         *
         */
        invalidPropertyDocEntry: boolean = false;
        invalidMutationDocEntry: boolean = false;
        invalidPropertyTaxRecDocEntry: boolean = false;
        invalidChainDocDocEntry: boolean = false;
        invalidOtherPropertyDocEntry: boolean = false;
        invalidLegalReportDocEntry: boolean = false;
        invalidTechnicalReportDocEntry: boolean = false;
        invalidMODTDocEntry: boolean = false;
        invalidSPDC1DocEntry: boolean = false;
        invalidSPDC2DocEntry: boolean = false;
        invalidSPDC3DocEntry: boolean = false;
        invalidPhysicalMandateDocEntry: boolean = false;
        constructor(params?:IRMCApplicationModel) {
                if(params){
                this.rmcData.lan = params.rmcData.lan;
                this.rmcData.userID=params.rmcData.userID;
                this.rmcData.barcode_File=params.rmcData.barcode_File;
                this.rmcData.barcode_Pouch=params.rmcData.barcode_Pouch;
                this.rmcData.poD_Number=params.rmcData.poD_Number;
                this.rmcData.poD_Date=params.rmcData.poD_Date;
                this.rmcData.createdBy=params.rmcData.createdBy;
                this.rmcData.createdOn=params.rmcData.createdOn;
                this.rmcData.modifiedBy=params.rmcData.modifiedBy;
                this.rmcData.courierDate=params.rmcData.courierDate;
                this.rmcData.courierName=params.rmcData.courierName;
                this.rmcData.officeBoyName=params.rmcData.officeBoyName;
                this.rmcData.officeBoyMobileNo=params.rmcData.officeBoyMobileNo;
                this.docs=params.docs;
                this.rmcData.status=params.rmcData.status;
                this.invalidPropertyDocEntry = params.invalidPropertyDocEntry;
                this.invalidMutationDocEntry = params.invalidMutationDocEntry;
                this.invalidPropertyTaxRecDocEntry = params.invalidPropertyTaxRecDocEntry;
                this.invalidChainDocDocEntry = params.invalidChainDocDocEntry;
                this.invalidOtherPropertyDocEntry = params.invalidOtherPropertyDocEntry;
                this.invalidLegalReportDocEntry = params.invalidLegalReportDocEntry;
                this.invalidTechnicalReportDocEntry = params.invalidTechnicalReportDocEntry;
                this.invalidMODTDocEntry = params.invalidMODTDocEntry;
                this.invalidSPDC1DocEntry = params.invalidSPDC1DocEntry;
                this.invalidSPDC2DocEntry = params.invalidSPDC2DocEntry;
                this.invalidSPDC3DocEntry = params.invalidSPDC3DocEntry;
                this.invalidPhysicalMandateDocEntry = params.invalidPhysicalMandateDocEntry;
                }
        }
      
        rmcData: RMCData=new RMCData();
        docs : RMCDocumentInfo[]=[];


        toJSON(): any {
                return {
                    "rmcData":this.rmcData,
                    "docs":this.docs
                }
            }
}

export class RMCDocumentInfo{
      id:number=0;
      lan : string='';
      docType: string='';
      doc_Source: string='RMC';
      imgData: string='';
      uuid:  string='';
      remark: string='';
      createdBy: string='';
      createdOn: Date= new Date();
      modifiedBy: string='';
      modifiedOn: Date=new Date();
}

export interface IRMCDashboardSearch{
        userID: string;
        role: string;
       // screenType: string;
        fieldName: string;
        fieldValue: string;
        fromDate: Date;
        toDate: Date;
        toJson(): any;
}

export class RMCDashboardSearch{
     userID: string='';
    role: string='';
    //screenType: string='';
    fieldName: string='';
    fieldValue: string='';
    private _fromDate: Date= new Date();
    public get fromDate():Date{
        return this._fromDate;
    }
    public set fromDate(value:Date){
        this._fromDate=value;
    }

    private _toDate: Date= new Date();
    public get toDate():Date{
        return this._toDate;
    }
    public set toDate(value:Date){
        this._toDate=value;
    } 

    /**
     *
     */
    constructor(param?:RMCDashboardSearch) {
        if(param){
            this.userID = param.userID;
            this.role= param.role;
            //this.screenType=param.screenType;
            this.fieldName=param.fieldName;
            this.fieldValue=param.fieldValue;
            this.fromDate=param.fromDate;
            this.toDate=param.toDate;
        }
    }

    
    toJson(): any {

        return {
            "FromDate": this.fromDate,
            "ToDate": this.toDate,
            "FieldName": this.fieldName,
            "Role": this.role,
            "FieldValue": this.fieldValue,
            "Login_PS_ID": this.userID
        };
    }
}

export interface IRMCReport{
        content:string;
        commonResponse:RMCCommonResponse
    }

    export class RMCReport{
        content:string='';
        commonResponse : RMCCommonResponse=new RMCCommonResponse();

        /**
         *
         */
        constructor(param?:IRMCReport) {
            if(param){
                this.content=param.content;
                this.commonResponse=param.commonResponse;
            }
        }
    }


    export interface IRMCCommonResponse{
        errorcode: string;
        errorDescription: string;
        loanaccountnumber: string;
    }
    export class RMCCommonResponse{
        errorcode: string='';
        errorDescription: string=''; 
        loanaccountnumber: string='';
        constructor(param?:IRMCCommonResponse) {
        if(param){
                this.errorcode=param.errorcode;
                this.errorDescription=param.errorDescription;
                this.loanaccountnumber=param.loanaccountnumber;

        } 
        }
    }
 
//Cust points verification
export class IOperationalQueries {
    loanAccountNumber: any;
    QueriedBy: any;
    InteractionId: any;
    Query: any;
    Response: any;
    Upload: any;
    Download: any;
    Date: any;
     
}
export class OperationalQueries {
    loanAccountNumber: any;
    QueriedBy: any;
    InteractionId: any;
    Query: any;
    Response: any;
    Upload: any;
    Download: any;
    Date: any;

    constructor(params?: IOperationalQueries) {
        
    } 
}

export interface IOperationalQueriesDashboard{
    loanAccountNumber: string;
    name: string;
    mobileNo: string;
    dateOfQueryRaised: string;
    state: string;
    executive_ID: string;
    executive_Name: string;
    ageing: string;
    source: string;
    applicationNo:string;
    leadId:string;
    status:string;
}

export class OperationalQueriesDashboardModel implements IOperationalQueriesDashboard{
    loanAccountNumber: string='';
    name: string='';
    mobileNo: string='';
    dateOfQueryRaised: string='';
    state: string='';
    executive_ID: string='';
    executive_Name: string='';
    ageing: string='';
    source: string='';
    applicationNo:string='';
    leadId:string='';
    status:string='';
    constructor(param?:IOperationalQueriesDashboard) {
       if(param){
        this.loanAccountNumber=param.loanAccountNumber;
        this.name=param.name;
        this.mobileNo=param.mobileNo;
        this.dateOfQueryRaised=param.dateOfQueryRaised;
        this.state=param.state;
        this.executive_ID=param.executive_ID;
        this.executive_Name=param.executive_Name;
        this.ageing=param.ageing;
        this.source=param.source;
        this.applicationNo=param.applicationNo;
        this.leadId=param.leadId;
        this.status=param.status;
       }        
    } 
}


export interface IOPSRCUQueriesSearch{
  userID: string;
  role: string;
  screenType: string;
  fieldName: string;
  fieldValue: string;
  fromDate: Date;
  toDate: Date;
  toJson(): any;
}

export class OPSRCUQueriesSearch implements IOPSRCUQueriesSearch{
    userID: string='';
    role: string='';
    screenType: string='';
    fieldName: string='';
    fieldValue: string='';
    private _fromDate: Date= new Date();
    public get fromDate():Date{
        return this._fromDate;
    }
    public set fromDate(value:Date){
        this._fromDate=value;
    }

    private _toDate: Date= new Date();
    public get toDate():Date{
        return this._toDate;
    }
    public set toDate(value:Date){
        this._toDate=value;
    } 

    /**
     *
     */
    constructor(param?:IOPSRCUQueriesSearch) {
        if(param){
            this.userID = param.userID;
            this.role= param.role;
            this.screenType=param.screenType;
            this.fieldName=param.fieldName;
            this.fieldValue=param.fieldValue;
            this.fromDate=param.fromDate;
            this.toDate=param.toDate;
        }
    }

    
    toJson(): any {

        return {
            "FromDate": this.fromDate,
            "ToDate": this.toDate,
            "FieldName": this.fieldName,
            "Role": this.role,
            "FieldValue": this.fieldValue,
            "UserID": this.userID,
            "ScreenType":this.screenType
        };
    }
}

 export interface IOPSRCUSubmitModel{
    loanAccountNumber: string;
    sender: string;
    sender_Remarks: string;
    sender_Doc1: string;
    sender_Doc2: string;
    receiver: string;
    receiver_Remarks: string;
    receiver_Doc1: string;
    receiver_Doc2: string;
    status: string;
    flO_PsId: string;
    sender_Role: string;
    receiver_Doc3: string;
    receiver_Doc4: string;
    source: string;
    receiver_Role: string;
    sender_Doc3: string;
    sender_Doc4: string;
    receiverDoc1_UUID: string;
    receiverDoc2_UUID: string;
    receiverDoc3_UUID: string;
    receiverDoc4_UUID: string;
    senderDoc1_UUID: string;
    senderDoc2_UUID: string;
    senderDoc3_UUID: string;
    senderDoc4_UUID: string;
    receiver_Remarks_Date: string;
    toJSON():any;
  }

  export class OPSRCUSubmitModel implements IOPSRCUSubmitModel{
      loanAccountNumber: string='';
      sender: string='';
      sender_Remarks: string='';
      sender_Doc1: string='';
      sender_Doc2: string='';
      receiver: string='';
      receiver_Remarks: string='';
      receiver_Doc1: string='';
      receiver_Doc2: string='';
      status: string='';
      flO_PsId: string='';
      sender_Role: string='';
      receiver_Doc3: string='';
      receiver_Doc4: string='';
      source: string='';
      receiver_Role: string='';
      sender_Doc3: string='';
      sender_Doc4: string='';
      receiverDoc1_UUID: string='';
      receiverDoc2_UUID: string='';
      receiverDoc3_UUID: string='';
      receiverDoc4_UUID: string='';
      senderDoc1_UUID: string='';
      senderDoc2_UUID: string='';
      senderDoc3_UUID: string='';
      senderDoc4_UUID: string='';
      receiver_Remarks_Date: string='';
 
      constructor(param?:IOPSRCUSubmitModel) {
         if(param){
            this.loanAccountNumber=param.loanAccountNumber;
            this.sender=param.sender;
            this.sender_Remarks=param.sender_Remarks;
            this.sender_Doc1=param.sender_Doc1;
            this.sender_Doc2=param.sender_Doc2;
            this.receiver=param.receiver;
            this.receiver_Remarks=param.receiver_Remarks;
            this.receiver_Doc1=param.receiver_Doc1;
            this.receiver_Doc2=param.receiver_Doc2;
            this.status=param.status;
            this.flO_PsId=param.flO_PsId;
            this.sender_Role=param.sender_Role;
            this.receiver_Doc3=param.receiver_Doc3;
            this.receiver_Doc4=param.receiver_Doc4;
            this.source=param.source;
            this.receiver_Role=param.receiver_Role;
            this.sender_Doc3=param.sender_Doc3;
            this.sender_Doc4=param.sender_Doc4;
            this.receiverDoc1_UUID=param.receiverDoc1_UUID;
            this.receiverDoc2_UUID=param.receiverDoc2_UUID;
            this.receiverDoc3_UUID=param.receiverDoc3_UUID;
            this.receiverDoc4_UUID=param.receiverDoc4_UUID;
            this.senderDoc1_UUID=param.senderDoc1_UUID;
            this.senderDoc2_UUID=param.senderDoc2_UUID;
            this.senderDoc3_UUID=param.senderDoc3_UUID;
            this.senderDoc4_UUID=param.senderDoc4_UUID;
            this.receiver_Remarks_Date=param.receiver_Remarks_Date;
         } 
      }

      toJSON():any {
          return{
            "LoanAccountNumber": this.loanAccountNumber,
            "Receiver": this.receiver,
            "Receiver_Remarks": this.receiver_Remarks,
            "Receiver_Doc1": this.receiver_Doc1,
            "Receiver_Doc2": this.receiver_Doc2,
            "Status": this.status,
            "Receiver_Doc3":this.receiver_Doc3,
            "Receiver_Doc4": this.receiver_Doc4,
            "Source": this.source,
            "Receiver_Role":this.receiver_Role,
            "ReceiverDoc1_UUID": this.receiverDoc1_UUID,
            "ReceiverDoc2_UUID": this.receiverDoc2_UUID,
            "ReceiverDoc3_UUID": this.receiverDoc3_UUID,
            "ReceiverDoc4_UUID": this.receiverDoc4_UUID
          }
      }

  }
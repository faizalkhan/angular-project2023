export interface responseModel {
    errorcode: any;
    errorDescription: any;
}
export class IresponseModel<T> implements responseModel {
    errorcode: any;
    errorCode: any;
    errorDescription: any;
    vehicle: any
    data!: T;
    rcuDashboardSummaryResult!: T;
    rcuPendingActionList!: T;
    rcuApplicationResult!: T;
    rcuLoanResult!: T;
    rcuLandDocCheckResult!: T;
    rcuLandBankResult!: T;
    rcuSanction!: T;
    rcuPropertyValuation!: T;
    creditInteractionDtl!: T;
    creditInteractionDashboard!: T;
    dashboardDetails!: T;
    content!: T;
    status!: T;
    result!: T;
    fetchSourcedata!: T;
    emandateRoot!: T;
    PdfDoc!: T;

}
export interface ILegalDashboardResponseModel<T> {
    resp: any;
    vendorDashboardDetails: T;
    legalDashboardDetails: T;
}

export interface ILegalVendorSearch {
    fromDate: Date;
    toDate: Date;
    fieldName: string;
    role: string;
    fieldValue: string;
    login_PS_ID: string;
    selectedOption: string;
    toJson(): any;
}

export class LegalVendorSearch implements ILegalVendorSearch {
    currentDate = new Date();
    firstDay = new Date(this.currentDate.getFullYear(), this.currentDate.getMonth(), 1);
    lastDay = new Date(this.currentDate.getFullYear(), this.currentDate.getMonth() + 1, 0);
    fromDate: Date = this.firstDay;
    public get FromDate(): Date {
        return this.fromDate;
    }
    public set FromDate(value: Date) {
        this.fromDate = value;
    }
    toDate: Date = this.lastDay;
    public get ToDate(): Date {
        return this.toDate;
    }
    public set ToDate(value: Date) {
        this.toDate = value;
    }
    fieldName: string = "Branch";
    role: string = "BCM";
    fieldValue: string = "T0318";
    login_PS_ID: string = "50008860";
    selectedOption: string = '';

    constructor(params?: ILegalVendorSearch) {
        if (params) {
            this.fromDate = new Date(params.fromDate);
            this.toDate = new Date(params.toDate);
            this.fieldName = params.fieldName;
            this.fieldValue = params.fieldValue;
            this.selectedOption = params.selectedOption;
        }
    }


    toJson(): any {
        //`${this.FromDate.getFullYear()}-${this.FromDate.getMonth()}-${this.FromDate.getDay()}`,
        return {
            "FromDate": this.FromDate,
            "ToDate": this.ToDate,
            "FieldName": this.fieldName,
            "Role": this.role,
            "FieldValue": this.fieldValue,
            "Login_PS_ID": this.login_PS_ID,
            "SelectedOption": this.selectedOption
        };
    }
}


export interface ILegalVendorDashboardResponseModel<T> {
    resp: any;
    vendorDashboardDetails: T;
}

export interface ITechnicalVendorDashboardResponseModel<T> {
    resp: any;
    vendorDashboardDetails: T;
    technicalVendorDashboardDetails: T;
}
export interface IVendorDashboardResponseModel<T> {
    resp: any;
    technicalVendorDashboardDetails: T;
}

export interface ILegalCaseResponseModel {
    resp: any;
}



export class LFTSRouteInterface {
    path: any;
    title: any;
    parentName: any;
    redirectTo: any;
    componentName: any;
    isMenu: any;
    menuName: any;
    isActive: any;
}

export class CustomRouteConfig {

    private routeConfig: LFTSRouteInterface = {
        path: undefined,
        title: undefined,
        parentName: "",
        redirectTo: undefined,
        componentName: undefined,
        isMenu: true,
        menuName: "",
        isActive: false
    };
    public get RouteConfig(): LFTSRouteInterface {
        return this.routeConfig;
    }
    public set RouteConfig(value: LFTSRouteInterface) {
        this.routeConfig = value;
    }
    public get IsParent(): boolean {
        return this.routeConfig?.parentName == undefined || this.routeConfig?.parentName == "";
    }
    public get IsMenu(): boolean {
        return !(this.routeConfig?.menuName == undefined);
    }
    constructor(routeInterface: any) {
        this.routeConfig = routeInterface;
    }

    getRoute(): any {
        if (this.IsParent) {
            return { 'path': this.routeConfig.path, 'redirectTo': this.routeConfig.redirectTo, 'title': this.routeConfig.title };
        }
        else {
            return { 'path': this.routeConfig.path, 'component': this.routeConfig.componentName, 'redirectTo': this.routeConfig.redirectTo, 'title': this.routeConfig.title, 'data': {} };
        }
    }
    getMenu(): any {
        if (this.IsMenu) {
            return this.routeConfig;
        }
    }
}


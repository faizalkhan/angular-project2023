
export interface IImageUploadModel
{
	ApplicationNo:string;
	FLO_Id:string;
	GL_Latitude:string;
	GL_Longitude:string;
	ImageType:string;
    ImageData:string;
	LeadID:string;
	Type:string;
	UUID:string;
}

export class ImageUploadModel{
     
    public ApplicationNo:string='';
	public FLO_Id:string='';
	public GL_Latitude:string='';
	public GL_Longitude:string='';
	public ImageType:string='';
    public ImageData:string='';
	public LeadID:string='';
	public Type:string='';
	public UUID:string=''; 	
	public  LoanAccountNumber:string='';
	public DocTypeDescription:string='';
	public ImageMIMEType:string='';
	public Extension:string='';
	public ModuleName:string ='';
	public Name:string=''
	public BankDetailID:string=''
	  
}

export class ImageUploadWithoutImageDataModel{
     
    public ApplicationNo:string='';
	public FLO_Id:string='';
	public GL_Latitude:string='';
	public GL_Longitude:string='';
	public ImageType:string=''; 
	public ImageData:string='';   
	public LeadID:string='';
	public Type:string='';
	public UUID:string='';  
	public  LoanAccountNumber:string='';
	public DocTypeDescription:string='';
	public ImageMIMEType:string='';
	public Extension:string='';
	public ModuleName:string ='';
	public Name:string='';
	public BankDetailID:string='';
	 
}

export interface IResSaveImageUPL{
    Errorcode:string;
    ErrorDescription:string;
    UniqueID:string; 
}

export interface ISubmitLegalAPI{
    errorcode:string;
    errorDescription:string; 
}

export interface ISubmitTechnicalAPI{
    errorcode:string;
    errorDescription:string; 
}
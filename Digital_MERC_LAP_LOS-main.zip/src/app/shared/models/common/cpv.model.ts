//Cust points verification
export class ICPVerification {
    loanAccountNumber: any;
    hA_CPV_Lat: any;
    hA_CPV_Long: any;
    hA_CPV_Area: any;
    hA_CPV_Dist: any;
    hA_CPV_Pincode: any;
    hA_CPV_State: any;
    hA_CPV_City: any;
    flO_PsId: any;
    freeField1: any;
    freeField2: any;
    freeField3: any;
    freeField4: any;
    sourceThrough: any;
    createdOn: any
}
export class CPVerification implements ICPVerification {
    loanAccountNumber: any;
    hA_CPV_Lat: any;
    hA_CPV_Long: any;
    hA_CPV_Area: any;
    hA_CPV_Dist: any;
    hA_CPV_Pincode: any;
    hA_CPV_State: any;
    hA_CPV_City: any;
    flO_PsId: any;
    freeField1: any;
    freeField2: any;
    freeField3: any;
    freeField4: any;
    sourceThrough: any;
    createdOn: any;

    constructor(params: ICPVerification) {
        this.loanAccountNumber = params;
        this.hA_CPV_Lat = params.hA_CPV_Lat;
        this.hA_CPV_Long = params.hA_CPV_Long;
        this.hA_CPV_Area = params.hA_CPV_Area;
        this.hA_CPV_Dist = params.hA_CPV_Dist;
        this.hA_CPV_Pincode = params.hA_CPV_Pincode;
        this.hA_CPV_State = params.hA_CPV_State;
        this.hA_CPV_City = params.hA_CPV_City;
        this.flO_PsId = params.flO_PsId;
        this.freeField1 = params.freeField1;
        this.freeField2 = params.freeField2;
        this.freeField3 = params.freeField3;
        this.freeField4 = params.freeField4;
        this.createdOn = params.createdOn;
    }

}

export class IHACustPointVerification {
    loanAccountNumber: any;
    hA_CPV_Lat: any;
    hA_CPV_Long: any;
    hA_CPV_Area: any;
    hA_CPV_Dist: any;
    hA_CPV_Pincode: any;
    hA_CPV_State: any;
    hA_CPV_City: any;
    flO_PsId: any;
    freeField1: any;
    freeField2: any;
    freeField3: any;
    freeField4: any;
    createdOn: any
}
export class HACustPointVerification implements IHACustPointVerification {
    loanAccountNumber: any;
    hA_CPV_Lat: any;
    hA_CPV_Long: any;
    hA_CPV_Area: any;
    hA_CPV_Dist: any;
    hA_CPV_Pincode: any;
    hA_CPV_State: any;
    hA_CPV_City: any;
    flO_PsId: any;
    freeField1: any;
    freeField2: any;
    freeField3: any;
    freeField4: any;
    createdOn: any;

    constructor(params: IHACustPointVerification) {
        this.loanAccountNumber = params;
        this.hA_CPV_Lat = params.hA_CPV_Lat;
        this.hA_CPV_Long = params.hA_CPV_Long;
        this.hA_CPV_Area = params.hA_CPV_Area;
        this.hA_CPV_Dist = params.hA_CPV_Dist;
        this.hA_CPV_Pincode = params.hA_CPV_Pincode;
        this.hA_CPV_State = params.hA_CPV_State;
        this.hA_CPV_City = params.hA_CPV_City;
        this.flO_PsId = params.flO_PsId;
        this.freeField1 = params.freeField1;
        this.freeField2 = params.freeField2;
        this.freeField3 = params.freeField3;
        this.freeField4 = params.freeField4;
        this.createdOn = params.createdOn;
    }

}


export class IIACPVerification {
    loanAccountNumber: any;
    iA_CPV_Lat: any;
    iA_CPV_Long: any;
    iA_CPV_Area: any;
    iA_CPV_Dist: any;
    iA_CPV_Pincode: any;
    iA_CPV_State: any;
    iA_CPV_City: any;
    flO_PsId: any;
    freeField1: any;
    freeField2: any;
    freeField3: any;
    freeField4: any;
    sourceThrough: any;
    createdOn: any
}
export class IACPVerification implements IIACPVerification {
    loanAccountNumber: any;
    iA_CPV_Lat: any;
    iA_CPV_Long: any;
    iA_CPV_Area: any;
    iA_CPV_Dist: any;
    iA_CPV_Pincode: any;
    iA_CPV_State: any;
    iA_CPV_City: any;
    flO_PsId: any;
    freeField1: any;
    freeField2: any;
    freeField3: any;
    freeField4: any;
    sourceThrough: any;
    createdOn: any;

    constructor(params: IIACPVerification) {
        this.loanAccountNumber = params;
        this.iA_CPV_Lat = params.iA_CPV_Lat;
        this.iA_CPV_Long = params.iA_CPV_Long;
        this.iA_CPV_Area = params.iA_CPV_Area;
        this.iA_CPV_Dist = params.iA_CPV_Dist;
        this.iA_CPV_Pincode = params.iA_CPV_Pincode;
        this.iA_CPV_State = params.iA_CPV_State;
        this.iA_CPV_City = params.iA_CPV_City;
        this.flO_PsId = params.flO_PsId;
        this.freeField1 = params.freeField1;
        this.freeField2 = params.freeField2;
        this.freeField3 = params.freeField3;
        this.freeField4 = params.freeField4;
        this.createdOn = params.createdOn;
    }

}

 
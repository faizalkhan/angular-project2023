export class Menu {
    private _id: any;
    public get id(): any {
        return this._id;
    }
    public set id(value: any) {
        this._id = value;
    }
    private _parentId: any;
    public get parentId(): any {
        return this._parentId;
    }
    public set parentId(value: any) {
        this._parentId = value;
    }
    private _name: string = "";
    private _path: string = "";
    private _icon: string = "";
    private _isActive: boolean = false;
    private _isEnabled: boolean = true;
    private _orderNo: number = 0;
    public get isEnabled(): boolean {
        return this._isEnabled;
    }
    public set isEnabled(value: boolean) {
        this._isEnabled = value;
    }

    private _child: any;
    public get Child(): any[] {
        return this._child;
    }
    public set Child(value: any[]) {
        this._child = value;
    }
    public get IsActive(): boolean {
        return this._isActive;
    }
    public set IsActive(value: boolean) {
        this._isActive = value;
    }
    public get Icon(): string {
        return this._icon;
    }
    public set Icon(value: string) {
        this._icon = value;
    }
    public get Path(): string {
        return this._path;
    }
    public set Path(value: string) {
        this._path = value;
    }
    public get Name(): string {
        return this._name;
    }
    public set Name(value: string) {
        this._name = value;
    }


    constructor(id: any, Name: string, Path?: string, Icon?: string, IsActive?: boolean, Child?: any, parentId?: any) {
        this.Name = Name;
        this.Path = Path ?? "";
        this.Icon = Icon ?? "";
        this.IsActive = IsActive ?? false;
        this.Child = Child;
        this.id = id;
        this.parentId = parentId;
    }

    public getChild(path: any) {
        
        if (this.Child) {
            return this.Child.findIndex((x: Menu) => {
                return path.indexOf(x.Path) != -1;
            }) != -1
        }
        else {
            return false;
        }
    }

}
export enum MenuTypes {
    MainMenu, SubMenu
}

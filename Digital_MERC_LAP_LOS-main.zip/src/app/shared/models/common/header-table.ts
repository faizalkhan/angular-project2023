export class headerModel {
    private _fieldName: any;
    private _displayName: any;

    public get displayName(): any {
        return this._displayName;
    }
    public set displayName(value: any) {
        this._displayName = value;
    }

    public get fieldName(): string {
        return this._fieldName;
    }
    public set fieldName(value: string) {
        this._fieldName = value;
    }

  

    constructor(fieldName: any, displayName: any) {
        this.displayName = displayName;
        this.fieldName = fieldName;

    }
}
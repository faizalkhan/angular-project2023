
export interface IControlModel<T> {
    data: T;
    controlType: Controls;
}
export enum Controls {
    TEXTBOX=1, SELECT,DATE, RADIO, CHECKBOX,NUMERICONLY,TEXTAREA
}

export interface IDropdown {
    value?: any;
    displayName: string;
    selected?: boolean;
}

export class Dropdown implements IDropdown {
    private _value: any;
    public get value(): any {
        this._value= (this._value) ? this._value : this.displayName;
        return this._value;
    }
    public set value(value: any) {
        this._value = (value) ? value : this.displayName;
    }
    displayName: string;
    private _selected: boolean = false;
    public get selected(): boolean {
        return this._selected;
    }
    public set selected(value: boolean) {
        this._selected = value;
    }

    constructor(params: IDropdown) {
        this.displayName = params.displayName;
        this.value = params.value ;
        this.selected = false;
    }
}

export interface IDropdownWithNumberValue {
    value: number;
    displayName: string;
    selected: boolean;
}

export class DropdownWithIntValue implements IDropdownWithNumberValue {
    value: number;
    displayName: string;
    selected: boolean;

    constructor(params: IDropdownWithNumberValue) {
        this.value = params.value;
        this.displayName = params.displayName;
        this.selected = false;
    }

}
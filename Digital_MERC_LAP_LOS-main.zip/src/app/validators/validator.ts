import { AbstractControl, FormGroup, ValidationErrors, Validator } from '@angular/forms';
import { common } from '../shared/models/common';
export class MobileValidate implements Validator {
    validate(control: AbstractControl<any, any>): ValidationErrors | null {
        debugger;
        if (control.value.length > 0 && !common.isValid_MobileNo(control.value)) {
            return { 'errorMessage': "Enter valid Mobile No." };
        }
        else
            return null;
    }
    registerOnValidatorChange?(fn: () => void): void {
        debugger;
    }
}


export class ContidionBasedValidate implements Validator {
    validate(control: AbstractControl<any, any>): ValidationErrors | null {
        let parentForm = control.root as FormGroup;
        if(parentForm.value['emiToObligate']!="" && (parentForm.value['emiToObligate']!='Yes' || parentForm.value['emiToObligate']!='Y') && control.value=="")
        {
            return { 'errorMessage': "Remarks is Required" };
        }
        return null;
        // let controls = parentForm.controls as FormControl;
    }
    registerOnValidatorChange?(fn: () => void): void {
        throw new Error('Method not implemented.');
    }

}
























import { Routes } from "@angular/router";
import { Menu } from "./shared/models/common/menu.model";

export const routes: Routes = [
];

import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser'
import { filter } from 'rxjs';
import { InfoServices } from './Injectable/info.services';
import { MenuService } from './pages/layout/header/menu-service.service';
import { IModalCommon, ModalCommon, ModalService } from './shared/services/modal/modal.service';
import { SearchService } from './shared/services/search/search.service';
import { SanctionService } from './shared/services/sanction/sanction.service';
import { SanctionDashboardModel } from './shared/models/sanction/dashboard';
import { common } from './shared/models/common';
export const LTFS_Component: any = {};
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  Modal: IModalCommon = new ModalCommon();
  displayStyle: string = "none";
  isLogin: boolean = false;
  @ViewChild('btnModal')
  btnModal!: ElementRef;
  constructor(private route: Router, private modalService: ModalService, private _search: SearchService,
    private _infoService: InfoServices,
    private menuService: MenuService,
    private sanctionService: SanctionService) {
  }

  ngOnInit(): void {

    this.isLogin = this._infoService.checkCookie('token');
    this._infoService.loginService.subscribe((res: boolean) => {
      this.isLogin = res;
      this.sanctionService.dashBoard = [];
      if (res) {
        let _pmenu = this.menuService.localMenu.parentMenuDetail[0];
        let menu = this.menuService.localMenu.menuLinkDetails.find(x => x.menuId === _pmenu.menu_Id);
        this.route.navigateByUrl(`${menu?.menuLink}`);
      }
      else {
        this._infoService.deleteCookie('token');
        this.route.navigateByUrl('/login');
      }
    });

    this.route.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe((res: any) => {
      if (res.url == "/login" && !this._infoService.checkCookie('token')) {
        this._infoService.IsLogin(false);
      }
      else if (res.url == "/login" && this._infoService.checkCookie('token')) {

        return;
      }
      else if (!this._infoService.checkCookie('token')) {
        this.menuService.GetHeaderMenuByPath(res.url);
        this._infoService.IsLogin(false);
      }
      else if (res.url == '/') {
        this.menuService.GetHeaderMenuByPath(res.url);
        this._infoService.IsLogin(false);
      }
      else {
        this.menuService.GetHeaderMenuByPath(res.url);
        this.menuService.IsShow = (res.url == "/sanctiondash" || res.urlAfterRedirects == "/sanctiondash")
          || (res.urlAfterRedirects == '/technicalvendor') || (res.urlAfterRedirects == '/legalvendor')
          || (res.urlAfterRedirects == '/dispendingforaction') || (res.urlAfterRedirects == '/dispendingforaction')
          || (res.urlAfterRedirects == "/opsrcuhome") || (res.urlAfterRedirects == "/rmcdash")
          || (res.urlAfterRedirects == "/pendingscreen") || (res.urlAfterRedirects == "/sampledcases")
          || (res.urlAfterRedirects == "/closedcases") || (res.urlAfterRedirects == "/pendingscreenback")
          || (res.urlAfterRedirects == "/riskcontolunitdashpage") || (res.urlAfterRedirects == "/rmchome")
          || (res.urlAfterRedirects == "/riskalertcases");

        if (this.menuService.IsShow)
          this.sanctionService.LanInfo = {} as SanctionDashboardModel;

      }


    });
    this.modalService.Data.subscribe((res: IModalCommon) => {
      this.displayStyle = "block";
      this.Modal = res;
      this.btnModal.nativeElement.click();
    });

    this.sanctionService.readonlySubject.subscribe((res: boolean) => {
      this.sanctionService.readonly = res;
    })
  }

  Close(event: any) {
    this.displayStyle = "none";
  }
  sAction() {
    this.displayStyle = "none";
    this.Modal.sAction();
  }
  AdditionalAction() {
    this.displayStyle = "none";
    this.Modal.AdditionalButtonAction();
  }
}

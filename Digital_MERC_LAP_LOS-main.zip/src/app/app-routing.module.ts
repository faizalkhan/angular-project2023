import { NgModule } from '@angular/core';
import { Route, RouterModule, ROUTES } from '@angular/router';
import { FinalRoute } from './pages';
import { LoginComponent } from './pages/layout/login/login.component';
import { routes } from './route';
@NgModule({
  imports: [RouterModule.forRoot([])],
  exports: [RouterModule],
  providers: [{
    provide: ROUTES,
    useFactory: () => {
      var _finalRoute = FinalRoute.map(x => x.getRoute());
      _finalRoute.push({ path: "login", component: LoginComponent } as Route)
      return _finalRoute;
    },
    multi: true
  }]
})
export class AppRoutingModule {

  constructor() {
  }


}

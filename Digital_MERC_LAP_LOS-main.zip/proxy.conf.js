const PROXY_CONFIG = {

    "/proxy": {
        "target": "https://miflowappuat.ltferp.com",
        "changeOrigin": true,
        "secure": false,
        "logLevel": "info",
        "pathRewrite": { '^/proxy': "https://miflowappuat.ltferp.com" },
        "onProxyReq": function(pr, req, res) {
            pr.setHeader('origin', 'miflowappuat.ltferp.com')
            pr.setHeader('host', 'miflowappuat.ltferp.com')
        }
    },
    "/local": {
        "target": "https://localhost:44374",
        "changeOrigin": true,
        "secure": false,
        "logLevel": "info",
        "pathRewrite": { '^/local': "https://localhost:44374" },
        "onProxyReq": function(pr, req, res) {}
    }
};
module.exports = PROXY_CONFIG;
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AutoCompleteComponent } from './auto-complete/auto-complete.component';
import { AppMaterialModule } from '../material/material.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CustomInputComponent } from './custom-input/custom-input.component';
import { CustomDatepickerComponent } from './custom-datepicker/custom-datepicker.component';
import { MultiSelectSearchComponent } from './multi-select-search/multi-select-search.component';



@NgModule({
  declarations: [AutoCompleteComponent,CustomInputComponent, CustomDatepickerComponent, MultiSelectSearchComponent],
  imports: [
    CommonModule,
    AppMaterialModule,
    ReactiveFormsModule,
    FormsModule
  ],
  exports:[AutoCompleteComponent,CustomInputComponent, CustomDatepickerComponent,ReactiveFormsModule,MultiSelectSearchComponent,
    FormsModule]
})
export class CustomFormsModule { }

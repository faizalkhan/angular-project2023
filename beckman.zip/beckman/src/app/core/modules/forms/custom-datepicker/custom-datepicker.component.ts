import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { AbstractControl } from '@angular/forms';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { MAT_DATE_FORMATS, DateAdapter, MAT_DATE_LOCALE } from '@angular/material';
 import { MomentDateAdapter } from '@angular/material-moment-adapter';
 
const DATE_FORMATS = {
  parse : {
    dateInput: 'DD/MM/yyyy',
  },
  display: {
    dateInput: 'DD/MM/yyyy',
    monthYearLabel: 'MMM YYYY'
  },
};


@Component({
  selector: 'app-custom-datepicker',
  templateUrl: './custom-datepicker.component.html',
  styleUrls: ['./custom-datepicker.component.css'],
  encapsulation:ViewEncapsulation.None,
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: DATE_FORMATS },
  ],

})
export class CustomDatepickerComponent implements OnInit {

  constructor(private _MomentService : MomentService) { }
 

  @Input() formInnerControlName;
  @Input() parentForm;
  @Input() type;
  @Input() label;
  @Input() placeholder;
  @Input() endDateLabel;
  @Input() minDate;
  @Input() maxDate;
  @Input() ActiveValue;

  isActive: boolean= true;

  ngOnInit(): void {
    if(this.ActiveValue == 1){
     this.isActive = true; 
     this.minDate = this.minDate ? this.minDate : this._MomentService.deceedYear(new Date(), 20);
    this.maxDate = this.maxDate ? this.maxDate : this._MomentService.exceedYear(new Date(), 20);
    }
    else if(this.ActiveValue == 0){
      this.isActive = false;
      this.minDate = 0
    this.maxDate = 0
    this.parentForm.get(this.formInnerControlName).setValidators(null);
    }
  else{
    
    this.minDate = this.minDate ? this.minDate : this._MomentService.deceedYear(new Date(), 20);
    this.maxDate = this.maxDate ? this.maxDate : this._MomentService.exceedYear(new Date(), 20);
    
  }
  }
 

  get validator() {
    const validator = this.parentForm.get(this.formInnerControlName).validator ? this.parentForm.get(this.formInnerControlName).validator({} as AbstractControl) : '';
    if (validator && validator.required) {
      return true;
    }
  }


  restrictCharacters(event){
    if (event.keyCode == 32 || (event.keyCode >=65 && event.keyCode <=90)) {
      event.preventDefault();}
    
  }

}

import { Component, OnInit, EventEmitter, ViewChild, Output, Input, ViewEncapsulation, OnDestroy, OnChanges, ElementRef,ChangeDetectorRef } from '@angular/core';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete/typings/autocomplete';
import {Subject, Observable, BehaviorSubject } from 'rxjs';
import { takeUntil, startWith, map, debounceTime, distinctUntilChanged, filter } from 'rxjs/operators';
import { AbstractControl, FormBuilder, FormControl, FormGroup,ReactiveFormsModule,FormsModule } from '@angular/forms';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material/chips';
import { AsyncPipe } from '@angular/common';

@Component({
  selector: 'app-multi-select-search',
  templateUrl: './multi-select-search.component.html',
  styleUrls: ['./multi-select-search.component.css'],
  providers:[AsyncPipe]
})
export class MultiSelectSearchComponent implements OnInit {
  @ViewChild('search',{static:false}) searchTextBox: any;
  @ViewChild('search',{static:false}) searchTextBoxCtrl: ElementRef;
  @Output() selectChange: EventEmitter<any> = new EventEmitter<any>();

  @Input() formInnerControlName;
  @Input() parentForm:FormGroup;
  @Input() label;
  @Input() options;
  @Input() key;
  @Input () displayKey;
  @Input () relatedKey;
  @Input() inlineOptionalField = false;
  @Input() formName;
  @Input() setAlert;

  selectedValues = [];
  searchCtrl = new FormControl();
  currentOptions: Observable<any[]> ;
  private destroy = new Subject();
  public optionsList = [];
  
  separatorKeysCodes: number[] = [ENTER, COMMA];
  tagCtrl = new FormControl();
  constructor(private formbuilder:FormBuilder,private cdRef:ChangeDetectorRef,private asyncPipe : AsyncPipe) {
  }
  ngOnChanges(value){
    this.setValues();    
  }
  
  ngOnInit() {
   //this.setValues();   
   this.selectedValues = this.parentForm.get(this.formInnerControlName).value ? this.parentForm.get(this.formInnerControlName).value : [];
   this.filterData()
   this.parentForm.get(this.formInnerControlName).valueChanges.subscribe(x => {
    this.selectedValues =this.parentForm.get(this.formInnerControlName).value? this.parentForm.get(this.formInnerControlName).value : [];      
    
  })
  }
  filterData(){
    this.selectedValues.forEach((elevalue:any)=>{
      this.options = this.options.filter(o => o != elevalue);
      this.options = this.options ? this.options : [];
      this.currentOptions =  this.currentOptions.pipe(filter(o=>o!=elevalue))
    })
  }
   public setValues(){
    this.currentOptions = this.searchCtrl!.valueChanges.pipe(
      takeUntil(this.destroy),
      distinctUntilChanged(),
      startWith(''),
      map((value: any) =>{ return typeof value === 'string' ? value : value[this.key]}),
      map((name: any) => name ? this._filterArray(name,this.options,this.key) : this.options.slice())
    );    
   }
   private _filterArray(value: any,arr:any=[],key:any): string[] {
    const filterValue = value.toLowerCase();    
    this.setSelectedValues();
    this.parentForm.get(this.formInnerControlName).patchValue(this.selectedValues);
    return arr.filter((tag: any) => tag[key].toLowerCase().includes(filterValue));
  }
  onBlurChanges(value){
    if (typeof value == 'string' && value.trim() == '') this.parentForm.get(this.formInnerControlName).setValue('')
  }
  setSelectedValues() {
    if (this.parentForm.get(this.formInnerControlName).value && this.parentForm.get(this.formInnerControlName).value.length > 0) {
      this.parentForm.get(this.formInnerControlName).value.forEach((e) => {
        if (this.selectedValues.indexOf(e) == -1) {
          this.selectedValues.push(e);
        }
      });
    }
  }
  selectedValue() {
    this.parentForm.get(this.formInnerControlName).setValue(this.selectedValues)
    console.log(this.selectedValues);
    
    this.selectChange.emit(this.selectedValues);
  }

  displayValue(value): string {
    return value && value[this.key] ? value[this.key] : ' ';
  }

  onKeyTab($event){
    if ($event.target.value && this.optionsList.length && typeof this.parentForm.get(this.formInnerControlName).value !== 'object') {
      this.parentForm.get(this.formInnerControlName).setValue(this.optionsList[0]);
      this.selectChange.emit(this.selectedValues);
     }
  }

  get validator() {
    const validator = this.parentForm.get(this.formInnerControlName).validator ? this.parentForm.get(this.formInnerControlName).validator({} as AbstractControl) : '';
    if (validator && validator.required) {
      return true;
    }
  }
  //unsubscribe
  ngOnDestroy(){
    this.destroy.next();
    this.destroy.complete();
  }
  openedChange(e) {
    this.searchTextBox.value='';
    if (e == true) {
     // this.searchTextBoxCtrl.nativeElement.focus();
    }
  }
  ngAfterViewInit(){
    this.cdRef.detectChanges()
  }
  removeTag(tag: any): void {
    const index =  this.selectedValues.indexOf(tag);
    if (index >= 0) {
      this.selectedValues.splice(index,1)
    }
    this.options.push(tag) 
    this.currentOptions = this.currentOptions.pipe(filter(o=> o !=tag));
    this.searchCtrl.setValue('');
    this.selectedValue();
  }
  selected(evt:any,input:any){
    const elevalue = evt.option.value ;
    this.searchCtrl.setValue('');
    input.value='';
    this.selectedValues.push(elevalue)
    this.options = this.options.filter(o => o != elevalue);
    this.options = this.options ? this.options :[]
    this.currentOptions = this.currentOptions.pipe(filter(o=> o !=elevalue));
  }
}


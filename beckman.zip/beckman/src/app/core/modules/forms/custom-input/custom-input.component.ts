import { Component, OnInit, EventEmitter, Output, Input, ViewEncapsulation } from '@angular/core';
import { AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-custom-input',
  templateUrl: './custom-input.component.html',
  styleUrls: ['./custom-input.component.css'],
  encapsulation:ViewEncapsulation.None
})
export class CustomInputComponent implements OnInit {
  @Output() valueChanges: EventEmitter<any> = new EventEmitter<any>();
  @Output() focusOut: EventEmitter<any> = new EventEmitter<any>();


  @Input() formInnerControlName;
  @Input() parentForm;
  @Input() type;
  @Input() label;
  @Input() placeholder;
  @Input() max;
  @Input() min;
  @Input() readonly;
  @Input() fieldMaxLength;
  @Input() inputValue;
  @Input() opfValue;
  currentValue: any;
  opfLength: any;
  difference: any
  constructor() { }
  ngOnInit(): void {
   
    this.min = this.min ? this.min : 0;
    if(this.inputValue){
      this.currentValue = this.inputValue;
    }
    if(this.opfValue){
      this.opfLength = this.opfValue+1;
      this.difference = Math.abs(36-this.opfLength);
      this.fieldMaxLength = this.difference;
    }
    if (this.valueChanges.observers.length > 0){
      this.parentForm.get(this.formInnerControlName).valueChanges.subscribe((response) => { 
        this.valueChanges.emit(response);
       })
    }

  }

  onBlurChanges(value){
    this.focusOut.emit(value)
   
  }
  get validator() {
    const validator = this.parentForm.get(this.formInnerControlName).validator ? this.parentForm.get(this.formInnerControlName).validator({} as AbstractControl) : '';
    if (validator && validator.required) {
      return true;
    }
  }

}

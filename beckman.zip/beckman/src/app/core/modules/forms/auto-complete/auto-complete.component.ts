import { Component, OnInit, EventEmitter, ViewChild, Output, Input, ViewEncapsulation, OnDestroy, OnChanges, ElementRef } from '@angular/core';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete/typings/autocomplete';
import {Subject, Observable, BehaviorSubject } from 'rxjs';
import { takeUntil, startWith, map, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-auto-complete',
  templateUrl: './auto-complete.component.html',
  styleUrls: ['./auto-complete.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AutoCompleteComponent implements OnInit ,OnDestroy,OnChanges{
  @Output() selectChange: EventEmitter<any> = new EventEmitter<any>();

  @Input() formInnerControlName;
  @Input() parentForm;
  @Input() label;
  @Input() options;
  @Input() key;
  @Input () displayKey;
  @Input () relatedKey;
  @Input() inlineOptionalField = false;
  @Input() formName;
  @Input() setAlert;

  currentOptions: Observable<any[]> ;
  private destroy = new Subject();
  public optionsList = [];
  constructor() {
  }
  ngOnChanges(value){
    this.setValues();
  }
  
  ngOnInit() {
   this.setValues();
  }


   public setValues(){
    this.currentOptions =  this.parentForm.get(this.formInnerControlName).valueChanges.pipe(
      takeUntil(this.destroy),
      distinctUntilChanged(),
      startWith(''),
      map(value =>  {
        let name= value ?  (typeof value === 'string' ? value : value[this.key]) : '';
        name = name ? name.trim() : '';
        if (name){
          this.optionsList = this._filter(name);
          return this._filter(name) 
        }else{
         
          return this.options.slice(0,20);
        }
      })
    ) 
   }

  private _filter(value): any {
    return  this.options.filter(option => {
      if(this.displayKey) return  this.displayKey.find((key)=>option[key].toLowerCase().indexOf(value.toLowerCase()) > -1); //Previous > -1 for search results
      return option[this.key].toLowerCase().indexOf(value.toLowerCase()) > -1 //Previous > -1 for search results
      });
  }
  onBlurChanges(value){
    if (typeof value == 'string' && value.trim() == '') this.parentForm.get(this.formInnerControlName).setValue('')
  }
  selectedValue(e: MatAutocompleteSelectedEvent) {
   //localStorage.setItem('filtervalue',JSON.stringify(e.option['value']));
   if(this.formName == 'bookingOpfForm') {
      localStorage.setItem('opfSetvalue', JSON.stringify(e.option['value']));
    }
    this.selectChange.emit(this.parentForm.get(this.formInnerControlName).value);
  
  }

  displayValue(value): string {
    return value && value[this.key] ? value[this.key] : ' ';
  }

  onKeyTab($event){
    if ($event.target.value && this.optionsList.length && typeof this.parentForm.get(this.formInnerControlName).value !== 'object') {
      this.parentForm.get(this.formInnerControlName).setValue(this.optionsList[0]);
      this.selectChange.emit(this.parentForm.get(this.formInnerControlName).value);
     }
  }

  get validator() {
    const validator = this.parentForm.get(this.formInnerControlName).validator ? this.parentForm.get(this.formInnerControlName).validator({} as AbstractControl) : '';
    if (validator && validator.required) {
      return true;
    }
  }
  //unsubscribe
  ngOnDestroy(){
    this.destroy.next();
    this.destroy.complete();
  }
}



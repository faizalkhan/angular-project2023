import { Component, OnInit } from '@angular/core';
import { StorageService } from '../../services/storage/storage.service';

@Component({
  selector: 'app-not-found',
  templateUrl: './not-found.component.html',
  styleUrls: ['./not-found.component.css']
})
export class NotFoundComponent implements OnInit {

  constructor(private _storage: StorageService ) { }

  ngOnInit() {
  }

  redirect() {
    const currentUser = this._storage.getUserDetails();
    this._storage.redirectBasedonRoles(currentUser);
  }
}

import { Injectable } from '@angular/core';
import { InputDialogComponent } from './input-dialog.component';
import { MatDialog } from '@angular/material';

@Injectable({
  providedIn: 'root'
})
export class InputDialogService {

  constructor(public _dialog: MatDialog) { }

   openDialog(config,closeCallback){
    const dialogRef = this._dialog.open(InputDialogComponent, {
      width: '500px',
      data: config
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result){
        closeCallback(result);
      }
    });
   }
}
 
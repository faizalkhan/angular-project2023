import { Component, OnInit, Input } from '@angular/core';
import { NoticeService } from 'src/app/core/services/utils/notice.service';
import { Subject, Observable, BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-notice',
  templateUrl: './notice.component.html',
  styleUrls: ['./notice.component.css']
})
export class NoticeComponent{

isBannerDetails = new BehaviorSubject<{siteId: String, dlExpiry: string}[]>([]);

constructor(public _NoticeService: NoticeService){
  this._NoticeService.bannerDetails.subscribe(value =>{
    if (value && value.find(res => Number(res.dlExpiry) <=  90)){
      this.isBannerDetails.next(value)
    }else this.isBannerDetails.next([])
  })
}

}
 
import { Component,Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { DashboardService } from 'src/app/modules/beckman/service/dashboard/dashboard.service';
import { DashboardFilterDialog } from 'src/app/modules/common/pages/dashboard/dashboard-dialog/filter.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-primary-secondary-trend-line',
  templateUrl: './primary-secondary-trend-line.html',
  styleUrls: ['./primary-secondary-trend-line.css']
})

export class PrimarySecondaryTrendLineComponent {

  public PrimaryTrendLine= [];
  public SecondaryTrendLine = [];
  public filterImagePath;
  @Input() permission:any;
  @Input() routeName:any;
  public years:number [] = [];
  public yearfilterform: FormGroup;
  public currentYear:any;
  constructor(private fb: FormBuilder,private _dashboardService: DashboardService, public filter_dialog: MatDialog,private router:Router   ) {

  }

  ngOnInit()
  {
   // this.loadPrimarySecondaryTrendLine();
    this.filterImagePath = '../../../../../assets/filter.png';
    this.yearList();
  }


  
  yearList()
{
  this.currentYear = new Date().getFullYear();
  for(let i = (this.currentYear - 3); i < this.currentYear + 1; i++) {
    this.years.push(i);
  }
  this.YearFilterFilter();
}


  yearFilterSearch()
  {
    let selectedyear = this.getPayload(this.yearfilterform);
    this._dashboardService.yearFilterPrimarySecondaryTrendLine(selectedyear, res => {

      if(res.length > 0 )
      {    

        this.PrimaryTrendLine = [];
        this.SecondaryTrendLine = [];
        this.lineChartData =[
          
          { data: this.PrimaryTrendLine, label: 'Primary' },
          { data: this.SecondaryTrendLine, label: 'Secondary' }
        
        ]
     
        let primarycharts = [];       
        let secondarycharts = []; 
        primarycharts =res[0];   
        secondarycharts = res[1]
        Object.keys(primarycharts).forEach(key => {
          this.PrimaryTrendLine.push(primarycharts[key]);
        });
        Object.keys(secondarycharts).forEach(key => {
          this.SecondaryTrendLine.push(secondarycharts[key]);
        });







       
      }
      else
      {
        this.PrimaryTrendLine =[];
        this.SecondaryTrendLine =[];
        this.lineChartData =[{ data: this.PrimaryTrendLine, label: 'Available' },
        { data: this.SecondaryTrendLine, label: 'Available' }] 
      
        console.log("No Value");
      }

    })
  }



  getPayload(filterValue){
    let data =  {};
    data['year'] = filterValue.value ? filterValue.value.type: '';
    return data;
  }

  YearFilterFilter() {

    this.yearfilterform = this.fb.group({
        type: [this.currentYear]
    });
  }




PrimarySecondaryTrendFilter(){
  let dialog = this.filterDialog();
  dialog.afterClosed().subscribe(result=>{
     if(result['need_filter']){
      result = result.append('year',  this.yearfilterform.get('type').value ? this.yearfilterform.get('type').value: this.currentYear);
      this._dashboardService.FilterPrimarySecondaryTrendLine(result, res =>{         
        this.PrimaryTrendLine = [];
        this.SecondaryTrendLine = [];
        this.lineChartData =[          
          { data: this.PrimaryTrendLine, label: 'Available' },
          { data: this.SecondaryTrendLine, label: 'Available' }
        ]
        if(res.length > 0){
          let primarycharts = [];       
          let secondarycharts = []; 
          primarycharts =res[0];   
          secondarycharts = res[1]
          Object.keys(primarycharts).forEach(key => {
            this.PrimaryTrendLine.push(primarycharts[key]);
          });
          Object.keys(secondarycharts).forEach(key => {
            this.SecondaryTrendLine.push(secondarycharts[key]);
          });                  
        }
        if((result["OTLNumber"] || result["cpnumber"]|| result["custNumber"]|| result["region"]|| result["salesperson_name"]|| result["state"])){          
          this.filterImagePath = '../../../../../assets/filter-active.png';
        }else{
          this.filterImagePath = '../../../../../assets/filter.png';
        }       

      });
     }
  })
}
filterDialog(){
    const dialog_ref = this.filter_dialog.open(DashboardFilterDialog, {
      autoFocus: false,
      width: "450px",
      data: {}
    })
    return dialog_ref;
  }


  loadPrimarySecondaryTrendLine(){
    this._dashboardService.getPrimarySecondaryTrendLine(res =>{
      let primarycharts = res[0];       
      let secondarycharts = res[1]; 

      if(this.PrimaryTrendLine.length === 0  && this.SecondaryTrendLine.length === 0 )
      {
        Object.keys(primarycharts).forEach(key => {
          this.PrimaryTrendLine.push(primarycharts[key]);
        });
   
       Object.keys(secondarycharts).forEach(key => {
        this.SecondaryTrendLine.push(secondarycharts[key]);
      });
      }
     


   })  

  }

  lineChartData: ChartDataSets[] = [
    { data: this.PrimaryTrendLine, label: 'Primary' },
    { data: this.SecondaryTrendLine, label: 'Secondary' }
  ];

  lineChartLabels: Label[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  lineChartOptions = {
    responsive: true,

    scales: {
      xAxes: [{
          gridLines: {
              display:false
          }
      }],
      yAxes: [{
          gridLines: {
              display:true
          }   
      }]
  },

  tooltips: {
    displayColors: false,
    backgroundColor: '#E6313A',
    padding: 20,
    boxShadow: 60,
    titleFontSize: 16,
    titleFontColor: '#0066ff',
    bodyFontColor: '#fff',
    bodyFontSize: 14,
    callbacks: {
      // use label callback to return the desired label
      label: function(tooltipItem, data) {
        return tooltipItem.xLabel + " ₹" + tooltipItem.yLabel;
      },
      // remove title
      title: function(tooltipItem, data) {
        
        return;

      }
    }
  }
  };

  lineChartColors: Color[] = [
    {
      borderColor: '#34B9E8',
      backgroundColor: 'rgba(255,255,255,0.1)',
      borderWidth: 1
    },
    {
          borderColor: '#DC3912',
          backgroundColor: 'rgba(255,255,255,0.1)',
     }
   
  ];

  lineChartLegend = true;
  lineChartPlugins = [];
  lineChartType = 'line';

  navigateTo(){
    window.open(this.routeName+'/reports/dashboard/primary-secondary', '_blank');
  }

}

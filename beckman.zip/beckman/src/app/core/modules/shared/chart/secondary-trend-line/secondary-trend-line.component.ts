import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { DashboardService } from 'src/app/modules/beckman/service/dashboard/dashboard.service';
import { DashboardFilterDialog } from 'src/app/modules/common/pages/dashboard/dashboard-dialog/filter.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-secondary-trend-line',
  templateUrl: './secondary-trend-line.html',
  styleUrls: ['./secondary-trend-line.css']
})

export class SecondaryTrendLineComponent {


  public PrimaryTrendLine= [];
  public filterImagePath;
  @Input() routeName:any;
  @Input() permission:any;
  public years:number [] = [];
  public yearfilterform: FormGroup;
  public currentYear:any =[];
  constructor(private fb: FormBuilder, public filter_dialog: MatDialog, private _dashboardService: DashboardService,private router:Router ) {

  }
  

  ngOnInit()
  {
    //this.loadSecondaryTrendLine();
    this.filterImagePath = '../../../../../assets/filter.png';
    this.yearList();
  }

  yearList()
{
  this.currentYear = new Date().getFullYear();
  for(let i = (this.currentYear - 3); i < this.currentYear + 1; i++) {
    this.years.push(i);
  }
  this.YearFilterFilter();
}


  yearFilterSearch()
  {
    let selectedyear = this.getPayload(this.yearfilterform);
    this._dashboardService.yearFilterSecondaryTrendLine(selectedyear, res => {
      if(res.length > 0 )
      {
        this.PrimaryTrendLine =[];
        this.lineChartData =[{ data: this.PrimaryTrendLine, label: 'Available' }]       
        let linecharts = [];
        linecharts = res[0];   
        Object.keys(linecharts).forEach(key => {
          this.PrimaryTrendLine.push(linecharts[key]);
        });
       
      }
      else
      {
        this.PrimaryTrendLine =[];
        this.lineChartData =[{ data: this.PrimaryTrendLine, label: 'Available' }]  
        console.log("No Value");
      }

    })
  }



  getPayload(filterValue){
    let data =  {};
    data['year'] = filterValue.value ? filterValue.value.type: '';
    return data;
  }

  YearFilterFilter() {

    this.yearfilterform = this.fb.group({
      type: [this.currentYear]
    });
  }







  secondaryTrendFilter(){
  let dialog = this.filterDialog();
  dialog.afterClosed().subscribe(result=>{
     if(result['need_filter']){          
       console.log(this.yearfilterform.get('type').value);
       
    result = result.append('year',  this.yearfilterform.get('type').value ? this.yearfilterform.get('type').value: this.currentYear);
      this._dashboardService.FilterSecondaryTrendLine(result, res =>{
        this.PrimaryTrendLine =[];
        this.lineChartData =[{ data: this.PrimaryTrendLine, label: 'Available' }]       
        if(res.length > 0){
          let linecharts =[];
          linecharts = res[0];   
          Object.keys(linecharts).forEach(key => {
            this.PrimaryTrendLine.push(linecharts[key]);
          });
        }        
        if((result["OTLNumber"] || result["cpnumber"]|| result["custNumber"]|| result["region"]|| result["salesperson_name"]|| result["state"])){          
          this.filterImagePath = '../../../../../assets/filter-active.png';
        }else{
          this.filterImagePath = '../../../../../assets/filter.png';
        }        

      });
     }
  })
}
filterDialog(){
    const dialog_ref = this.filter_dialog.open(DashboardFilterDialog, {
      autoFocus: false,
      width: "450px",
      data: {}
    })
    return dialog_ref;
  }



   loadSecondaryTrendLine()
  {
     this._dashboardService.getSecondaryTrendLine(res =>{
     let linecharts = res[0];  
      
     if(this.PrimaryTrendLine.length === 0 )
     {

      Object.keys(linecharts).forEach(key => {

      
       
        {
          this.PrimaryTrendLine.push(linecharts[key]);
      
        }
     

    });

     }
 
      
     })
  }

  lineChartData: ChartDataSets[] = [
    { data: this.PrimaryTrendLine, label: 'Available' }
  ];

  lineChartLabels: Label[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  lineChartOptions = {
    responsive: true,

    scales: {
      xAxes: [{
          gridLines: {
              display:false
          }
      }],
      yAxes: [{
          gridLines: {
              display:true
          }   
      }]
  },

  tooltips: {
    displayColors: false,
    backgroundColor: '#E6313A',
    padding: 20,
    boxShadow: 60,
    titleFontSize: 16,
    titleFontColor: '#0066ff',
    bodyFontColor: '#fff',
    bodyFontSize: 14,
    callbacks: {
      // use label callback to return the desired label
      label: function(tooltipItem, data) {
        return tooltipItem.xLabel + " ₹" + tooltipItem.yLabel;
      },
      // remove title
      title: function(tooltipItem, data) {
        
        return;

      }
    }
  }
  };

  lineChartColors: Color[] = [
    {
      borderColor: '#FF9900',
      backgroundColor: 'rgba(255,255,255,0.1)',
      borderWidth: 1
    }
   
  ];

  lineChartLegend = false;
  lineChartPlugins = [];
  lineChartType = 'line';
  

  navigateTo(){
    window.open(this.routeName+'/reports/dashboard/secondary-report', '_blank');
  }
}

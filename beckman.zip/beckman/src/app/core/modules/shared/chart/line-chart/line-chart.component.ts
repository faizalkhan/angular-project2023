import { Component, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';

@Component({
  selector: 'app-line-chart',
  templateUrl: './line-chart.component.html',
  styleUrls: ['./line-chart.component.css']
})
export class LineChartComponent  {

  lineChartData: ChartDataSets[] = [
    { data: [2, 10, 18, 44, 36, 28, 36, 44, 18, 10, 2, 10], label: 'Primary Sale' },
    { data: [4, 9, 15, 34, 22, 42, 22, 34, 15, 9, 4, 9], label: 'Secondary Sale' },
  ];

  lineChartLabels: Label[] = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  lineChartOptions = {
    responsive: true,
  };

  lineChartColors: Color[] = [
    {
      borderColor: '#E6313A',
      backgroundColor: 'rgba(255,255,255,0.1)',
    },
    {
      borderColor: '#1D10AC',
      backgroundColor: 'rgba(255,255,255,0.1)',
    },
  ];

  lineChartLegend = true;
  lineChartPlugins = [];
  lineChartType = 'line';

}

import { Component, OnInit } from '@angular/core';
import { ChartType } from 'chart.js';
import { MultiDataSet, Label, Color } from 'ng2-charts';

@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.css']
})
export class PieChartComponent {

  doughnutChartLabels: Label[] = ['SOUTH', 'APTE', 'WEST', 'NORTH'];
  doughnutChartData: MultiDataSet = [
    [55, 25, 20, 28]
  ];
  doughnutChartType: ChartType = 'doughnut';
  doughnutChartColors: Color[] = [ 
    {backgroundColor: ['#ff9900', '#F8327B', '#34B9E8', '#43D9BE']}
  ]
}

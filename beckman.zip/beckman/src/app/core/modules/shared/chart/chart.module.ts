import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChartsModule } from 'ng2-charts';
import { BarChartComponent } from './bar-chart/bar-chart.component';
import { PieChartComponent } from './pie-chart/pie-chart.component';
import { PrimarySecondaryTrendLineComponent } from './primary-secondary-trend-line/primary-secondary-trend-line.component';
import { PrimaryTrendLineComponent } from './primary-trend-line/primary-trend-line';
import { SecondaryTrendLineComponent } from './secondary-trend-line/secondary-trend-line.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LineChartComponent } from './line-chart/line-chart.component';

@NgModule({
  declarations: [BarChartComponent, PieChartComponent,  LineChartComponent, PrimarySecondaryTrendLineComponent,
     PrimaryTrendLineComponent, SecondaryTrendLineComponent,
    ],
  imports: [
    CommonModule,
    ChartsModule,
    FormsModule,
    ReactiveFormsModule    
  ],
  exports : [BarChartComponent, PieChartComponent, PrimaryTrendLineComponent, SecondaryTrendLineComponent,
     PrimarySecondaryTrendLineComponent]
})
export class ChartModule { }

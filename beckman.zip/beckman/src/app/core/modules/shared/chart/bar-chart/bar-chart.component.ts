import { Component, OnInit, Input } from '@angular/core';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label, Color } from 'ng2-charts';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.css']
})
export class BarChartComponent implements OnInit {

  @Input() chartInput;
  public barChartOptions: ChartOptions;
  public barChartLabels: Label[];
  public barChartType: ChartType = 'bar';
  public barChartLegend = true;
  public barChartPlugins = [];
  public barChartData: ChartDataSets[]
  public barChartColors: Color[]
  public chartReady:boolean = false;
  ngOnInit() {
    this.barChartOptions = {
      responsive: true,
      scales: { xAxes: [{}], yAxes: [{ticks: {beginAtZero:true}}] },
    };
    this.barChartColors = [ 
      {backgroundColor: '#1d10ac'},
      {backgroundColor: '#DC3912'},
      {backgroundColor: '#FF9900'}
    ];
    // this.barChartColors = [ 
    //   {backgroundColor: ['#1d10ac', '#DC3912', '#FF9900', '#000']},
    //   // {backgroundColor: '#DC3912'},
    //   // {backgroundColor: '#FF9900'}
    // ];

   }
  renderChart(chartData) {
    if(chartData) {
      this.chartReady = true;
      this.barChartLabels = chartData.label;
      this.barChartData = chartData.data;
    }
  }

  ngOnChanges(data) {
    this.renderChart(data.chartInput.currentValue);
  }
}

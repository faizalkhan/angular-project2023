export const getRegions = [
    {
        "field": "SOUTH", "name": "South"
    }, {
        "field": "APTE", "name": "APTE"
    }, {
        "field": "WEST", "name": "West"
    },
    {
        "field": "NORTH", "name": "North"
    }]
export const getState = [
    {
        "field": "SOUTH",
        "name": "Tamil Nadu"
    },
    {
        "field": "SOUTH",
        "name": "Kerala"
    },
    {
        "field": "SOUTH",
        "name": "Puducherry"
    },
    {
        "field": "SOUTH",
        "name": "Andhra Pradesh"
    },
    {
        "field": "SOUTH",
        "name": "Karnataka"
    },
    {
        "field": "SOUTH",
        "name": "Goa"
    },
    {
        "field": "APTE",
        "name": "Andhra Pradesh"
    },
    {
        "field": "APTE",
        "name": "West Bengal"
    },
    {
        "field": "APTE",
        "name": "Murshidabad"
    },
    {
        "field": "APTE",
        "name": "Telangana"
    },
    {
        "field": "APTE",
        "name": "Meghalaya"
    },
    
    {
        "field": "APTE",
        "name": "Odisha"
    },
   
    {
        "field": "APTE",
        "name": "Tripura"
    },
    {
        "field": "APTE",
        "name": "Bihar"
    },
    {
        "field": "WEST",
        "name": "Maharashtra"
    },
    {
        "field": "WEST",
        "name": "Madhya Pradesh"
    },
   
    {
        "field": "WEST",
        "name": "Chhattisgarh"
    },
    {
        "field": "NORTH",
        "name": "Jammu And Kashmir"
    },
    {
        "field": "NORTH",
        "name": "Uttar Pradesh"
    },
    {
        "field": "NORTH",
        "name": "Madhya Pradesh"
    },
    {
        "field": "NORTH",
        "name": "Rajasthan"
    },
    {
        "field": "NORTH",
        "name": "Uttarakhand"
    },
    {
        "field": "NORTH",
        "name": "Himachal Pradesh"
    },
    {
        "field": "NORTH",
        "name": "Jammu And Kashmir"
    },
    {
        "field": "NORTH",
        "name": "Punjab"
    },
    {
        "field": "NORTH",
        "name": "Haryana"
    },
    {
        "field": "NORTH",
        "name": "Delhi"
    },
    {
        "field": "APTE",
        "name": "Jharkhand"
    },
    {
        "field": "WEST",
        "name": "Gujarat "
    },
    {
        "field": "APTE",
        "name": "Orrisa"
    },
    {
        "field": "APTE",
        "name": "Purnia"
    },
    {
        "field": "APTE",
        "name": "Andaman"
    },
    {
        "field": "APTE",
        "name": "Assam"
    },
    {
        "field": "APTE",
        "name": "Guntur "
    },
    {
        "field": "APTE",
        "name": "Kolkata"
    }
]

export const getCities =  [
    {
        "name": "Trichy",
        "field": "Tamil Nadu"
    },
    {
        "name": "Chennai",
        "field": "Tamil Nadu"
    },
    {
        "name": "Coimbatore",
        "field": "Tamil Nadu"
    },
    {
        "name": "Madurai",
        "field": "Tamil Nadu"
    },
    {
        "name": "Tiruchirapalli",
        "field": "Tamil Nadu"
    },
    {
        "name": "Salem",
        "field": "Tamil Nadu"
    },
    {
        "name": "Nagercoil",
        "field": "Tamil Nadu"
    },
    {
        "name": "Ramanathapuram",
        "field": "Tamil Nadu"
    },
    {
        "name": "Erode",
        "field": "Tamil Nadu"
    },
    {
        "name": "Tiruchirappalli",
        "field": "Tamil Nadu"
    },
    {
        "name": " Thanjavur",
        "field": "Tamil Nadu"
    },
    {
        "name": "Tirunelveli",
        "field": "Tamil Nadu"
    },
    {
        "name": "Dindigul",
        "field": "Tamil Nadu"
    },
    {
        "name": "Tiruvarur",
        "field": "Tamil Nadu"
    },
    {
        "name": "Thiruvarur",
        "field": "Tamil Nadu"
    },
    {
        "name": "Cochin",
        "field": "Kerala"
    },
    {
        "name": "Vellore",
        "field": "Tamil Nadu"
    },
    {
        "name": "Krishnagiri",
        "field": "Tamil Nadu"
    },
  
    {
        "name": "Dharmapuri",
        "field": "Tamil Nadu"
    },
    {
        "name": "Cuddalore",
        "field": "Tamil Nadu"
    },
    {
        "name": "Chengalpattu",
        "field": "Tamil Nadu"
    },
    {
        "name": "Chittoor District",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Kanchipuram",
        "field": "Tamil Nadu"
    },
    {
        "name": "Nellore",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Hosur",
        "field": "Tamil Nadu"
    },
    {
        "name": "Calicut",
        "field": "Kerala"
    },
    {
        "name": "Kannur",
        "field": "Kerala"
    },
    {
        "name": "Payyanur",
        "field": "Kerala"
    },
    {
        "name": "Thiruvananthapuram",
        "field": "Kerala"
    },
    {
        "name": "Kottakkal",
        "field": "Kerala"
    },
    {
        "name": "Malappuram",
        "field": "Kerala"
    },
    {
        "name": "Kozhikode",
        "field": "Kerala"
    },
    {
        "name": "Manjeri",
        "field": "Kerala"
    },
    {
        "name": "Palakkad",
        "field": "Kerala"
    },
    {
        "name": "Kochi",
        "field": "Kerala"
    },
    {
        "name": "Ernakulam",
        "field": "Kerala"
    },
    {
        "name": "Thrissur",
        "field": "Kerala"
    },
    {
        "name": "Idukki",
        "field": "Kerala"
    },
    {
        "name": "Pathanamthitta",
        "field": "Kerala"
    },
    {
        "name": "Kodungallur",
        "field": "Kerala"
    },
    {
        "name": "Aluva",
        "field": "Kerala"
    },
    {
        "name": "Alappuzha",
        "field": "Kerala"
    },
    {
        "name": "Muvattupuzha",
        "field": "Kerala"
    },
    {
        "name": "Trivandrum",
        "field": "Kerala"
    },
    {
        "name": "Thodupuzha",
        "field": "Kerala"
    },
    {
        "name": "Kollam",
        "field": "Kerala"
    },
    {
        "name": "Trivandrum ",
        "field": "Kerala"
    },
    {
        "name": "Kasaragod",
        "field": "Kerala"
    },
    {
        "name": "Anjarakandi",
        "field": "Kerala"
    },
    {
        "name": "Nilambur",
        "field": "Kerala"
    },
    {
        "name": "Kottayam",
        "field": "Kerala"
    },
    {
        "name": "Kanyakumari",
        "field": "Tamil Nadu"
    },
    {
        "name": "Kozhencherry",
        "field": "Kerala"
    },
    {
        "name": "Mavelikara",
        "field": "Kerala"
    },
    {
        "name": "Karunagappally",
        "field": "Kerala"
    },
    {
        "name": "Bengaluru",
        "field": "Karnataka"
    },
    {
        "name": "Shimoga",
        "field": "Karnataka"
    },
    {
        "name": "Bangalore ",
        "field": "Karnataka"
    },
    {
        "name": "Kuppam",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Haripad",
        "field": "Kerala"
    },
    {
        "name": "Sivakasi",
        "field": "Tamil Nadu"
    },
    {
        "name": "Adoor",
        "field": "Kerala"
    },
    {
        "name": "Mandya",
        "field": "Karnataka"
    },
    {
        "name": "Mysore",
        "field": "Karnataka"
    },
    {
        "name": "Chikkamagaluru",
        "field": "Karnataka"
    },
    {
        "name": "Panji",
        "field": "Goa"
    },
    {
        "name": "Hubli",
        "field": "Karnataka"
    },
    {
        "name": "Davangere",
        "field": "Karnataka"
    },
    {
        "name": "Bangalore",
        "field": "Karnataka"
    },
    {
        "name": "Gulbarga",
        "field": "Karnataka"
    },
    {
        "name": "Raichur",
        "field": "Karnataka"
    },
    {
        "name": "Kalaburgi",
        "field": "Karnataka"
    },
    {
        "name": "Belgaum",
        "field": "Karnataka"
    },
    {
        "name": "Mangalore",
        "field": "Karnataka"
    },
    {
        "name": "Doddaballapur",
        "field": "Karnataka"
    },
    {
        "name": "Mysore ",
        "field": "Karnataka"
    },
    {
        "name": "Manipal",
        "field": "Karnataka"
    },
    {
        "name": "Karkala",
        "field": "Karnataka"
    },
    {
        "name": "Banglore",
        "field": "Karnataka"
    },
    {
        "name": "Lucknow",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Gudur",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Tirupati",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Murshidabad",
        "field": "West Bengal"
    },
    {
        "name": "Berhampore",
        "field": "West Bengal "
    },
    {
        "name": "Kandi",
        "field": "Murshidabad"
    },
    {
        "name": "Srikakulam",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Visakhapatnam",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Kakinada",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Rajahmundry",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Rajam",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Paravathipuram",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Marripalem",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Bhimavaram",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Guntur",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Eluru",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Vijayawada",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Narasaropet",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Palakol",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Hyderabad",
        "field": "Telangana"
    },
    {
        "name": "Secunderabad",
        "field": "Telangana"
    },
    {
        "name": "Karimnagar",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Hospet",
        "field": "Karnataka"
    },
    {
        "name": "Budhawarpet Kurnool",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Khammam",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Bowenpally",
        "field": "Telangana"
    },
    {
        "name": "Gachibowli",
        "field": "Telangana"
    },
    {
        "name": "Adoni",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Chevella",
        "field": "Telangana"
    },
    {
        "name": "Ongole",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Shillong",
        "field": "Meghalaya"
    },
    {
        "name": "Panchkula",
        "field": "Haryana"
    },
    {
        "name": "Bhubaneswar",
        "field": "Odisha"
    },
    {
        "name": "Berhambur",
        "field": "Odisha"
    },
    {
        "name": "Cuttack",
        "field": "Odisha"
    },
    {
        "name": "Bhubaneshwar",
        "field": "Odisha"
    },
    {
        "name": "Sambalpur",
        "field": "Odisha"
    },
    {
        "name": "Nuapada",
        "field": "Odisha"
    },
    {
        "name": "Jamshedpur",
        "field": "Jharkhand"
    },
    {
        "name": "Ranchi",
        "field": "Jharkhand"
    },
    {
        "name": ".",
        "field": "Jharkhand"
    },
    {
        "name": "Bokaro",
        "field": "Jharkhand"
    },
    {
        "name": "Ranchi ",
        "field": "Jharkhand"
    },
    {
        "name": "Kolkata",
        "field": "West Bengal"
    },
    {
        "name": "Siliguri",
        "field": "West Bengal"
    },
    {
        "name": "Mysuru",
        "field": "Karnataka"
    },
    {
        "name": "Khammam ",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Rourkela",
        "field": "Odisha"
    },
    {
        "name": "Silchar",
        "field": "Assam"
    },
    {
        "name": "Agartala",
        "field": "Tripura"
    },
    {
        "name": "Tinsukia",
        "field": "Assam"
    },
    {
        "name": "Guwahati",
        "field": "Assam"
    },
    {
        "name": "Nagao",
        "field": "Assam"
    },
    {
        "name": "Barpeta",
        "field": "Assam"
    },
    {
        "name": "Dispur",
        "field": "Assam"
    },
    {
        "name": "Nalbari",
        "field": "Assam"
    },
    {
        "name": "Malda",
        "field": "West Bengal"
    },
    {
        "name": "Hooghly Chinsura",
        "field": "West Bengal"
    },
    {
        "name": "Howrah",
        "field": "West Bengal"
    },
    {
        "name": "Patna",
        "field": "Bihar"
    },
    {
        "name": "Purnea",
        "field": "Bihar"
    },
    {
        "name": "Darbhanga",
        "field": "Jharkhand"
    },
    {
        "name": "Hajipur",
        "field": "Bihar"
    },
    {
        "name": "Begusarai",
        "field": "Bihar"
    },
    {
        "name": "Durgapur",
        "field": "West Bengal"
    },
    {
        "name": "Raiganj",
        "field": "West Bengal"
    },
    {
        "name": "Arambagh",
        "field": "West Bengal"
    },
    {
        "name": "Mogra",
        "field": "West Bengal"
    },
    {
        "name": "Dibrugarh",
        "field": "Assam"
    },
    {
        "name": "Jorhat",
        "field": "Assam"
    },
    {
        "name": "P.O. Jorhat",
        "field": "Assam"
    },
    {
        "name": "Mumbai",
        "field": "Maharashtra"
    },
    {
        "name": "Pune",
        "field": "Maharashtra"
    },
    {
        "name": "Aurangabad",
        "field": "Maharashtra"
    },
    {
        "name": "Thane",
        "field": "Maharashtra"
    },
    {
        "name": "Ratnagiri",
        "field": "Maharashtra"
    },
    {
        "name": "Indore",
        "field": "Madhya Pradesh"
    },
    {
        "name": "Navi Mumbai",
        "field": "Maharashtra"
    },
    {
        "name": "Vadodara",
        "field": "Gujarat"
    },
    {
        "name": "Ahmedabad",
        "field": "Gujarat"
    },
    {
        "name": "Surat",
        "field": "Gujarat"
    },
    {
        "name": "Bharuch",
        "field": "Gujarat"
    },
    {
        "name": "Anand",
        "field": "Gujarat"
    },
    {
        "name": "Navsari",
        "field": "Gujarat"
    },
    {
        "name": "Ujjain",
        "field": "Madhya Pradesh"
    },
    {
        "name": "Jabalpur",
        "field": "Madhya Pradesh"
    },
    {
        "name": "Jhalod",
        "field": "Gujarat"
    },
    {
        "name": "Pithampur",
        "field": "Madhya Pradesh"
    },
    {
        "name": "Nashik",
        "field": "Maharashtra"
    },
    {
        "name": "Pen",
        "field": "Maharashtra"
    },
    {
        "name": "Bhusaval",
        "field": "Maharashtra"
    },
    {
        "name": "Bilaspur",
        "field": "Chhattisgarh"
    },
    {
        "name": "Raigarh",
        "field": "Chhattisgarh"
    },
    {
        "name": "Bhilai",
        "field": "Chhattisgarh"
    },
    {
        "name": "Raipur",
        "field": "Chhattisgarh"
    },
    {
        "name": "Korba",
        "field": "Chhattisgarh"
    },
    {
        "name": "Nadiad",
        "field": "Gujarat"
    },
    {
        "name": "Bhavnagar",
        "field": "Gujarat"
    },
    {
        "name": "Rajkot",
        "field": "Gujarat"
    },
    {
        "name": "Paldi",
        "field": "Gujarat"
    },
    {
        "name": "Surendranagar",
        "field": "Gujarat"
    },
    {
        "name": "Ahemdabad",
        "field": "Gujarat"
    },
    {
        "name": "Kutch",
        "field": "Gujarat"
    },
    {
        "name": "Baroda",
        "field": "Gujarat"
    },
    {
        "name": "Dahod",
        "field": "Gujarat"
    },
    {
        "name": "Himmatnagar",
        "field": "Gujarat"
    },
    {
        "name": "Morbi",
        "field": "Gujarat"
    },
    {
        "name": "Gandhinagar",
        "field": "Gujarat"
    },
    {
        "name": "Valsad",
        "field": "Gujarat"
    },
    {
        "name": "Gandhidham",
        "field": "Gujarat"
    },
    {
        "name": "Patan",
        "field": "Gujarat"
    },
    {
        "name": "Vapi",
        "field": "Gujarat"
    },
    {
        "name": "Ahmednagar",
        "field": "Maharashtra"
    },
    {
        "name": "Nagpur",
        "field": "Maharashtra"
    },
    {
        "name": "Wardha",
        "field": "Maharashtra"
    },
    {
        "name": "Satara",
        "field": "Maharashtra"
    },
    {
        "name": "Thane West",
        "field": "Maharashtra"
    },
    {
        "name": "Akola",
        "field": "Maharashtra"
    },
    {
        "name": "Amravati",
        "field": "Maharashtra"
    },
    {
        "name": "Sangli",
        "field": "Maharashtra"
    },
    {
        "name": "Pandharpur",
        "field": "Maharashtra"
    },
    {
        "name": "Baramati",
        "field": "Maharashtra"
    },
    {
        "name": "Solapur",
        "field": "Maharashtra"
    },
    {
        "name": "Nalasopara",
        "field": "Maharashtra"
    },
    {
        "name": "Parbhani",
        "field": "Maharashtra"
    },
    {
        "name": "Jalgaon",
        "field": "Maharashtra"
    },
    {
        "name": "Latur",
        "field": "Maharashtra"
    },
    {
        "name": "Panvel",
        "field": "Maharashtra"
    },
    {
        "name": "Kolhapur",
        "field": "Maharashtra"
    },
    {
        "name": "Kalyan (East)",
        "field": "Maharashtra"
    },
    {
        "name": "Baramulla",
        "field": "Jammu And Kashmir"
    },
    {
        "name": "Srinagar",
        "field": "Jammu And Kashmir"
    },
    {
        "name": "Anantnag",
        "field": "Jammu And Kashmir"
    },
    {
        "name": "Jammu",
        "field": "Jammu And Kashmir"
    },
    {
        "name": "Kurnool",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Moradabad",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Kanpur",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Gorakhpur",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Deoria",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Azamgarh",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Varanasi",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Allahabad",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Gwalior",
        "field": "Madhya Pradesh"
    },
    {
        "name": "Aligarh",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Agra",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Firozabad",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Mathura",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Jhansi",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Jodhpur",
        "field": "Rajasthan"
    },
    {
        "name": "Jaipur",
        "field": "Rajasthan"
    },
    {
        "name": "Kota",
        "field": "Rajasthan"
    },
    {
        "name": "Udaipur",
        "field": "Rajasthan"
    },
    {
        "name": "Bhilwara",
        "field": "Rajasthan"
    },
    {
        "name": "Sikar",
        "field": "Rajasthan"
    },
    {
        "name": "Bikaner",
        "field": "Rajasthan"
    },
    {
        "name": "Bharatpur",
        "field": "Rajasthan"
    },
    {
        "name": "Jhalawar",
        "field": "Rajasthan"
    },
    {
        "name": "Rishikesh",
        "field": "Uttarakhand"
    },
    {
        "name": "Roorkee",
        "field": "Uttarakhand"
    },
    {
        "name": "Meerut",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Kashipur",
        "field": "Uttarakhand"
    },
    {
        "name": "Dehradun",
        "field": "Uttarakhand"
    },
    {
        "name": "Saharanpur",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Haridwar",
        "field": "Uttarakhand"
    },
    {
        "name": "Bijnor",
        "field": "Uttarakhand"
    },
    {
        "name": "Shimla",
        "field": "Himachal Pradesh"
    },
    {
        "name": "Mohali",
        "field": "Punjab"
    },
    {
        "name": "Chamba",
        "field": "Himachal Pradesh"
    },
    {
        "name": "Reasi",
        "field": "Jammu And Kashmir"
    },
    {
        "name": "Amritsar",
        "field": "Punjab"
    },
    {
        "name": "Chandigarh",
        "field": "Punjab"
    },
    {
        "name": "Hisar",
        "field": "Haryana"
    },
    {
        "name": "Pinjore",
        "field": "Haryana"
    },
    {
        "name": "Karnal",
        "field": "Haryana"
    },
    {
        "name": "Haryana",
        "field": "Punjab"
    },
    {
        "name": "Patiala",
        "field": "Punjab"
    },
    {
        "name": "Ludhiana",
        "field": "Punjab"
    },
    {
        "name": "Faridkot",
        "field": "Punjab"
    },
    {
        "name": "Jalandhar",
        "field": "Punjab"
    },
    {
        "name": "Bhatinda",
        "field": "Punjab"
    },
    {
        "name": "Malerkotla",
        "field": "Punjab"
    },
    {
        "name": "Dabwali",
        "field": "Haryana"
    },
    {
        "name": "Gurgaon",
        "field": "Haryana"
    },
    {
        "name": "New Delhi",
        "field": "Delhi"
    },
    {
        "name": "Panipat",
        "field": "Haryana"
    },
    {
        "name": "Basidarapur",
        "field": "Delhi"
    },
    {
        "name": "Ghaziabad",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Delhi",
        "field": "Delhi"
    },
    {
        "name": "Noida",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Bahadurgarh",
        "field": "Haryana"
    },
    {
        "name": "Faridabad",
        "field": "Haryana"
    },
    {
        "name": " Dehradun",
        "field": "Uttarakhand"
    },
    {
        "name": "Haldwani",
        "field": "Uttarakhand"
    },
    {
        "name": "Khanpur Kalan",
        "field": "Haryana"
    },
    {
        "name": "Greater Noida",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Rudarpur",
        "field": "Uttarakhand"
    },
    {
        "name": "Nalhar",
        "field": "Haryana"
    },
    {
        "name": " Dumka ",
        "field": "Jharkhand"
    },
    {
        "name": "Gurugram",
        "field": "Haryana"
    },
    {
        "name": "Handwara",
        "field": "Jammu And Kashmir"
    },
    {
        "name": "Alwar",
        "field": "Rajasthan"
    },
    {
        "name": "Manesar",
        "field": "Haryana"
    },
    {
        "name": "Bhiwadi",
        "field": "Rajasthan"
    },
    {
        "name": "Hamirpur",
        "field": "Himachal Pradesh"
    },
    {
        "name": "Mandi",
        "field": "Himachal Pradesh"
    },
    {
        "name": "Shimla ",
        "field": "Himachal Pradesh"
    },
    {
        "name": "Kangra",
        "field": "Himachal Pradesh"
    },
    {
        "name": "Damanjodi",
        "field": "Odisha"
    },
    {
        "name": "Bhopal",
        "field": "Madhya Pradeshï¿½"
    },
    {
        "name": "Tezpur",
        "field": "Assam"
    },
    {
        "name": "Una",
        "field": "Himachal Pradesh"
    },
    {
        "name": "Ferozpur",
        "field": "Punjab"
    },
    {
        "name": "Pathankot",
        "field": "Punjab"
    },
    {
        "name": "Vijaywada",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Navsari West ",
        "field": "Gujarat "
    },
    {
        "name": "Sri Ganganagar",
        "field": "Rajasthan"
    },
    {
        "name": "Bellary",
        "field": "Karnataka"
    },
    {
        "name": "Berhampur",
        "field": "Orrisa"
    },
    {
        "name": "Vishakapatnam",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Satna",
        "field": "Madhya Pradesh"
    },
    {
        "name": "Asansol",
        "field": "West Bengal"
    },
    {
        "name": "Udhampur ",
        "field": "Jammu And Kashmir"
    },
    {
        "name": "Chiittorgarh",
        "field": "Rajasthan"
    },
    {
        "name": "Deesa",
        "field": "Gujarat"
    },
    {
        "name": "Palanpur",
        "field": "Gujarat"
    },
    {
        "name": "Pulwama",
        "field": "Jammu And Kashmir"
    },
    {
        "name": "Patia Bhubhaneshwar",
        "field": "Odisha"
    },
    {
        "name": "Madhubani",
        "field": "Purnia"
    },
    {
        "name": "Piravom",
        "field": "Kerala"
    },
    {
        "name": "Port Blair",
        "field": "Andaman"
    },
    {
        "name": "Rohtak",
        "field": "Haryana"
    },
    {
        "name": "Hoshangabad",
        "field": "Madhya Pradesh"
    },
    {
        "name": "Timarpur",
        "field": "Delhi"
    },
    {
        "name": "Kalaburagi",
        "field": "Karnataka"
    },
    {
        "name": "Naroda",
        "field": "Gujarat"
    },
    {
        "name": "Makrana",
        "field": "Rajasthan"
    },
    {
        "name": "Alleppey",
        "field": "Kerala"
    },
    {
        "name": "Shivamogga",
        "field": "Karnataka"
    },
    {
        "name": "Nagaon",
        "field": "Assam"
    },
    {
        "name": "Kadapa",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Adilabad",
        "field": "Telangana"
    },
    {
        "name": "Ambala",
        "field": "Haryana"
    },
    {
        "name": "Bareilly",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Sumerpur",
        "field": "Rajasthan"
    },
    {
        "name": "Bhuj",
        "field": "Gujarat"
    },
    {
        "name": "Proddatur",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Jamnagar",
        "field": "Gujarat"
    },
    {
        "name": "Ambur",
        "field": "Tamil Nadu"
    },
    {
        "name": "Ramanagara",
        "field": "Karnataka"
    },
    {
        "name": "Sodepur",
        "field": "Kolkata"
    },
    {
        "name": "Kotputli",
        "field": "Rajasthan"
    },
    {
        "name": "Kalyani",
        "field": "West Bengal"
    },
    {
        "name": "Ajmer",
        "field": "Rajasthan"
    },
    {
        "name": "Sanpada",
        "field": "Maharashtra"
    },
    {
        "name": "Ghazipur",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Budgam",
        "field": "Jammu And Kashmir"
    },
    {
        "name": "Kushinagar",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Mehsana",
        "field": "Gujarat"
    },
    {
        "name": "Tanuku",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Hoskote",
        "field": "Karnataka"
    },
    {
        "name": "Kasargod",
        "field": "Kerala"
    },
    {
        "name": "Perambra",
        "field": "Kerala"
    },
    {
        "name": "Koraput",
        "field": "Odisha"
    },
    {
        "name": "Bargarh",
        "field": "Odisha "
    },
    {
        "name": "Bathinda ",
        "field": "Punjab "
    },
    {
        "name": "Uttam Nagar",
        "field": "Delhi"
    },
    {
        "name": "Bhandara",
        "field": "Maharashtra"
    },
    {
        "name": "Sikkim ",
        "field": "Sikkim"
    },
    {
        "name": "Daltonganj",
        "field": "Jharkhand"
    },
    {
        "name": "Patia",
        "field": "Gujarat"
    },
    {
        "name": "Mangalagiri",
        "field": "Guntur "
    },
    {
        "name": "Nandyal",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Thrisssur",
        "field": "Kerala"
    },
    {
        "name": "Nipani",
        "field": "Karnataka"
    },
    {
        "name": "Agra ",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Hapur",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Ratlam ",
        "field": "Madhya Pradeshï¿½"
    },
    {
        "name": "Kashmir",
        "field": "Jammu And Kashmir"
    },
    {
        "name": "Bulandshahr",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Neyveli",
        "field": "Tamil Nadu"
    },
    {
        "name": "Karad",
        "field": "Maharashtra"
    },
    {
        "name": "Durg",
        "field": "Maharashtra"
    },
    {
        "name": "Barmer",
        "field": "Rajasthan"
    },
    {
        "name": "Moga",
        "field": "Punjab"
    },
    {
        "name": "Jalna",
        "field": "Maharashtra"
    },
    {
        "name": "Panchkula ",
        "field": "Haryana "
    },
    {
        "name": "KANHANGAD",
        "field": "KERALA"
    },
    {
        "name": "Kodagu",
        "field": "Karnataka"
    },
    {
        "name": "KRISHNANAGAR",
        "field": "WEST BENGAL"
    },
    {
        "name": "Narasaraopet",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Muzaffarnagar",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Ladakh",
        "field": "Jammu And Kashmir"
    },
    {
        "name": "Siddipet Dist",
        "field": "Telangana"
    },
    {
        "name": "Chamarajanagar",
        "field": "Karnataka"
    },
    {
        "name": "Midnapore",
        "field": "West Bengal"
    },
    {
        "name": "NAMGALAGIRI",
        "field": "ANDHRA PRADESH"
    },
    {
        "name": "Neemuch",
        "field": "Madhya Pradesh"
    },
    {
        "name": "Chinnakkada",
        "field": "Kerala"
    },
    {
        "name": "Churu",
        "field": "Rajasthan"
    },
    {
        "name": "Muzaffarpur",
        "field": "Bihar"
    },
    {
        "name": "Lakhimpur Khe",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Zirakpur",
        "field": "Punjab"
    },
    {
        "name": "THANJAVUR",
        "field": "TAMIL NADU"
    },
    {
        "name": "Thamarassery",
        "field": "Kerala"
    },
    {
        "name": "PARIPALLI",
        "field": "KERALA"
    },
    {
        "name": "Suryapet",
        "field": "Telangana"
    },
    {
        "name": "Talegaon Dabhade",
        "field": "Maharashtra"
    },
    {
        "name": "Pitampura",
        "field": "Delhi"
    },
    {
        "name": "Mumbai West ",
        "field": "Maharashtra"
    },
    {
        "name": "Manimajra",
        "field": "Chandigarh"
    },
    {
        "name": "Bathinda",
        "field": "Punjab"
    },
    {
        "name": "Bhopal West ",
        "field": "Madhya Pradesh "
    },
    {
        "name": "Dist. Kamrup",
        "field": "Assam"
    },
    {
        "name": "Dungarpur",
        "field": "Rajasthan"
    },
    {
        "name": "Vizianagaram",
        "field": "Andhra Pradesh "
    },
    {
        "name": "Kalyan",
        "field": "Maharashtra"
    },
    {
        "name": "Chilakaluripet",
        "field": "Andhra Pradesh"
    },
    {
        "name": "GWALIOR WEST",
        "field": "MADHYA PRADESH"
    },
    {
        "name": "Himmatnagar West",
        "field": "Gujarat"
    },
    {
        "name": "Ankleshwar West",
        "field": "Gujarat"
    },
    {
        "name": "Madhapur",
        "field": "Telangana"
    },
    {
        "name": "Poolacode",
        "field": "Kerala"
    },
    {
        "name": "Ambala Cantt",
        "field": "Haryana"
    },
    {
        "name": "Kumbakonam",
        "field": "Tamil Nadu"
    },
    {
        "name": "Banswara",
        "field": "Rajasthan"
    },
    {
        "name": "Angul",
        "field": "Odisha"
    },
    {
        "name": "Dibrugrah",
        "field": "Assam"
    },
    {
        "name": "Ganganagar",
        "field": "Rajasthan"
    },
    {
        "name": "Barrackpore",
        "field": "West Bengal"
    },
    {
        "name": "Alipore ",
        "field": "Kolkata"
    },
    {
        "name": "Ambika Nagar",
        "field": "Gujarat"
    },
    {
        "name": "Kurukshetra",
        "field": "Haryana"
    },
    {
        "name": "Anantapuramu",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Katwa",
        "field": "West Bengal"
    },
    {
        "name": "Phagwara",
        "field": "Punjab"
    },
    {
        "name": "Rewa",
        "field": "Madhya Pradesh"
    },
    {
        "name": "Vishakhapatnam",
        "field": "Andhra Pradesh"
    },
    {
        "name": "Wayanad",
        "field": "Kerala"
    },
    {
        "name": "Kishanganj",
        "field": "Bihar"
    },
    {
        "name": "Nalgonda",
        "field": "Telangana"
    },
    {
        "name": "Charnok",
        "field": "Kolkata"
    },
    {
        "name": "Pondicherry",
        "field": "Puducherry"
    },
    {
        "name": "Sidharthnagar",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Basti",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Ranga Reddy",
        "field": "Telangana"
    },
    {
        "name": "Rajasthan",
        "field": "302012"
    },
    {
        "name": "Ludhiana ",
        "field": "Punjab"
    },
    {
        "name": "Bidar",
        "field": "Karnataka"
    },
    {
        "name": "Mangaluru",
        "field": "Karnataka"
    },
    {
        "name": "Udupi",
        "field": "Karnataka"
    },
    {
        "name": "Kheri",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Sonitpur",
        "field": "Assam"
    },
    {
        "name": "TUMAKURU",
        "field": "KARNATAKA"
    },
    {
        "name": "Palamu",
        "field": "Jharkhand"
    },
    {
        "name": "Harohalli",
        "field": "Karnataka"
    },
    {
        "name": "Kateelu",
        "field": "Karnataka"
    },
    {
        "name": "Hoshiarpur",
        "field": "Punjab"
    },
    {
        "name": "Faizabad",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Warangal",
        "field": "Telangana"
    },
    {
        "name": "NIZAMABAD",
        "field": "TELANGANA"
    },
    {
        "name": "Chopda",
        "field": "Maharashtra"
    },
    {
        "name": "Kolar",
        "field": "Karnataka"
    },
    {
        "name": "Paota",
        "field": "Rajasthan"
    },
    {
        "name": "Kancheepuram",
        "field": "Tamil Nadu"
    },
    {
        "name": "Koyilandy",
        "field": "Kerala"
    },
    {
        "name": "Laheriasarai",
        "field": "Bihar"
    },
    {
        "name": "Sambhal",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Sagwara",
        "field": "Rajasthan"
    },
    {
        "name": "Vatakara",
        "field": "Kerala"
    },
    {
        "name": "Amreli",
        "field": "Gujarat"
    },
    {
        "name": "Karaikudi",
        "field": "Tamil Nadu"
    },
    {
        "name": "Prayagraj",
        "field": "Uttar Pradesh"
    },
    {
        "name": "Kalwakurthy",
        "field": "Telangana"
    },
    {
        "name": "Chavakkad",
        "field": "Kerala"
    },
    {
        "name": "Godhra",
        "field": "Gujarat"
    },
    {
        "name": "Sriganganagar",
        "field": "Rajasthan"
    },
    {
        "name": "Tenkasi",
        "field": "Tamil Nadu"
    },
    {
        "name": "Ground Floor",
        "field": "Telangana"
    },
    {
        "name": "Kuttiyadi",
        "field": "Kerala"
    },
    {
        "name": "Newtown",
        "field": "Kolkata"
    }
]


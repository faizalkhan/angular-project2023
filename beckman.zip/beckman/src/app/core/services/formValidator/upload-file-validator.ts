import { FormControl } from '@angular/forms';

export function requiredFileType(type: string[]) {
    return function(control: FormControl) {
      const file = control.value;
      const valid = null;
      if (file) {
        var path = file.replace(/^.*[\\\/]/, "");
        const extensionarray = path.split(".");
        const lastIndex = extensionarray.length-1;
        const extension = extensionarray[lastIndex].toUpperCase();
        var existValue: boolean = false;
        for (var i = 0; i < type.length; i++) {
          let typeFile = type[i].toUpperCase();
          if (typeFile === extension.toUpperCase()) {
            existValue = true;
          }
        }
        if (existValue == true) {
          if (path.split(".")[0].length >200)  {
            return {
              fileTypeExceedMaxLength : true
            }
          }
          return null;
        } else {
          return {
            requiredFileType: true
          };
        }
        return null;
      }
      return null;
    };
  }
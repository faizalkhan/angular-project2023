import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NoticeService { 
  
  bannerDetails= new Subject<{siteId: String, dlExpiry: string}[]>();

  bannerShow(licenseDetails) {
      this.bannerDetails.next(licenseDetails);
  }




}

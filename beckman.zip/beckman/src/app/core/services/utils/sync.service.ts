import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

@Injectable({providedIn: 'root'})
export class syncService {

    private isSync = new BehaviorSubject<any>(false);
    private isSyncDC = new BehaviorSubject<any>(false);

    private isSyncError = new BehaviorSubject<any>(false);

    setSync(message) {
       this.isSync.next(message);
    }

    getSync(): Observable<any>  {
        return this.isSync.asObservable();
    }

    setDCSync(message) {
        this.isSyncDC.next(message);
     }
 
     getDCSync(): Observable<any>  {
         return this.isSyncDC.asObservable();
     }

    setErrorSync(message) {
        this.isSyncError.next(message);
     }
 
     getErrorSync(): Observable<any>  {
         return this.isSyncError.asObservable();
     }

     setErrorDCSync(message) {
        this.isSyncError.next(message);
     }
 
     getErrorDCSync(): Observable<any>  {
         return this.isSyncError.asObservable();
     }


}
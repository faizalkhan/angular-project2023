import { Injectable } from '@angular/core';
import { CanLoad, Route, UrlSegment } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from 'src/app/modules/auth/service/auth.service';
import { StorageService } from '../services/storage/storage.service';


@Injectable({
  providedIn: 'root'
})
export class ModulesGuard implements CanLoad {
  constructor(private _authService: AuthService, private _storage: StorageService,
  ) { }
  canLoad(
    route: Route, 
    segments: UrlSegment[]): Observable<boolean> | Promise<boolean> | boolean {
      if(this._authService.isLoggedIn() && this._storage.getMenuList() && this._storage.getMenuList()[route.data.menu]) {
        return true;
      }
      else {
        const currentUser = this._storage.getUserDetails();
        this._storage.redirectBasedonRoles(currentUser);
        return false;
      }
  }
}

import { Pipe, PipeTransform } from '@angular/core';
import { OPFControls, SecondaryControls, CreditDebitControls, OtlTransferControls } from '../services/constants';

@Pipe({
  name: 'cpAccessControl'
})
export class CpAccessControlPipe implements PipeTransform {

  transform(value: any, args : string): any {
      if (args == 'OPFControls') {
        return OPFControls[value]
      }
      else if  (args == 'SecondaryControls') {
        return SecondaryControls[value]
      }
      else if (args == 'CreditDebitControls'){
        return CreditDebitControls[value]
      }
      else if (args == 'OtlTransferControls'){
        return OtlTransferControls[value]
      }
    return null;
  }

}

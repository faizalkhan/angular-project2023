import { InvoiceTypePipe } from './invoice-type.pipe';

describe('InvoiceTypePipe', () => {
  it('create an instance', () => {
    const pipe = new InvoiceTypePipe();
    expect(pipe).toBeTruthy();
  });
});

import { Pipe, PipeTransform } from '@angular/core';
import { invoiceType } from '../services/constants';

@Pipe({
  name: 'invoiceType'
})
export class InvoiceTypePipe implements PipeTransform {

  transform(value: string): string {
    return invoiceType[value];
  }

}

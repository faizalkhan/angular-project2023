import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IndiancurrencyformatPipe } from './indiancurrencyformat.pipe';
import { splitUrlPipe } from './spliturl.pipe';
import { InvoiceTypePipe } from './invoice-type.pipe';
import { CpAccessControlPipe } from './cp-access-control.pipe';



@NgModule({
  declarations: [IndiancurrencyformatPipe, splitUrlPipe, InvoiceTypePipe, CpAccessControlPipe],
  imports: [
    CommonModule
  ],
  exports: [IndiancurrencyformatPipe, splitUrlPipe,InvoiceTypePipe,CpAccessControlPipe]
})
export class PipeModule { }

import { IndiancurrencyformatPipe } from './indiancurrencyformat.pipe';

describe('IndiancurrencyformatPipe', () => {
  it('create an instance', () => {
    const pipe = new IndiancurrencyformatPipe();
    expect(pipe).toBeTruthy();
  });
});

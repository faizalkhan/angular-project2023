import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ 
    name: 'splitUrl' 
})
export class splitUrlPipe implements PipeTransform {

  transform(input: string, separator: string,index:number): string {
    return input.split(separator)[index];
  }

}
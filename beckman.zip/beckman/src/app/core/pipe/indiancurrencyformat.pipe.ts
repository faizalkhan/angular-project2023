import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'indianCurrencyFormat'
})
export class IndiancurrencyformatPipe implements PipeTransform {

  transform(value: number): string {
    if(value || value == 0)
    {
      return value.toLocaleString('en-IN', {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
          // style: 'currency',
          // currency: 'INR'
        });
      }
  }
}

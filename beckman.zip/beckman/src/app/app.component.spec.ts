
import { TestBed, async, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { LoaderComponent } from './core/modules/shared/components/loader/loader.component';
import { AppMaterialModule } from './core/modules/material/material.module';
import { Router } from '@angular/router';
import { routes } from './app-routing.module';
import { SpyLocation } from '@angular/common/testing';


describe('AppComponent', () => {
  let location: SpyLocation;
  let router: Router;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes),
        AppMaterialModule
      ],
      providers: [
        Location
      ],
      declarations: [
        AppComponent,
        LoaderComponent
      ],
    }).compileComponents();
   
  }));

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'beckman-billing'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual('beckman-billing');
  });

//   it(`should redirect to login`, fakeAsync(() => {
//     //   const fixture = TestBed.createComponent(AppComponent);
//     //   location = TestBed.get(Location);
//     //   router = TestBed.get(Router);
//     // //   router.navigate(['']);
//     //   tick();
//     //   expect(location.path()).toBe('/login')
//   }));
});



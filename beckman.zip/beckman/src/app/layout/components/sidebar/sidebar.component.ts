import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { Roles } from 'src/app/modules/auth/model/user';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css'],
  encapsulation:ViewEncapsulation.None
})
export class SidebarComponent implements OnInit {

  sidebarStatus:boolean = false;
  admin: boolean = false; 
  channelPartner: boolean = false; 
  bookingAgent: boolean = false;
  otherUser:boolean = false;
  permissionMenu;
  routeName;
  constructor(private _utilsService: UtilsService, private _storage: StorageService, private _permissionMenuListService: PermissionMenuListService) { 
    
  }

  ngOnInit() {  
  this._utilsService.sidebarStatus.subscribe(sidebarStatus => this.sidebarStatus = sidebarStatus);
  this.getUserRole();
  this.getPermissionMenu(); 
  }

  getUserRole() {
    const currentUser = this._storage.getUserDetails();
    switch(currentUser.role) {
      case Roles.Admin:
        this.admin = true;
        this.routeName = 'beckman'
        break;
      case Roles.Channel_Partner:
        this.channelPartner = true;
        this.routeName = 'channel-partner'
        break;
      case Roles.Agent:
        this.bookingAgent = true;
        this.routeName = 'agent'
        break;
      
      default :
        this.otherUser = true;
        this.routeName = 'beckman-billing'
        break;
    }

  }
  getPermissionMenu(){
    this._permissionMenuListService.getPermissionMenu(response =>{
      this.permissionMenu = response;
    })
  }


}

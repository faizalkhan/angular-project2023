import { Component, OnInit, Input } from '@angular/core';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { AuthService } from 'src/app/modules/auth/service/auth.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { environment } from 'src/environments/environment';
import { Roles } from 'src/app/modules/auth/model/user';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  sidebarStatus:boolean = false; 
  userEmail:string;
  adminRole:boolean = false;
  baRole :boolean =false
  trainingvideourl : any;
  public serverUrl = environment.apiUrl;
  constructor(private _utilService: UtilsService, private _authService: AuthService, private _storage: StorageService,
    private _bookingService : CpbookingService) { }
  
  ngOnInit() {
    const currentUser = this._storage.getUserDetails();
    this.userEmail = currentUser.email;
    this.adminRole = currentUser.role.toLowerCase().replace(/\s/g, "") == Roles.Admin.toLowerCase().replace(/\s/g, "");
    this.baRole = currentUser.role.toLowerCase().replace(/\s/g, "") == Roles.Agent.toLowerCase().replace(/\s/g, "");
    this._utilService.sidebarStatus.subscribe(sidebarStatus => this.sidebarStatus = sidebarStatus);
    }
  toggleSiderbar() {
    this.sidebarStatus = !this.sidebarStatus;
    this._utilService.toggleSiderbar(this.sidebarStatus);
   }
  videoDocLink()
  { 
    this._bookingService.trainingVideos((res)=>{
    this.trainingvideourl = res['docx_url'][0].url;
    let link = document.createElement('a');
    link.setAttribute('type', 'hidden');
    link.href =  this.trainingvideourl;
    link.download = this.trainingvideourl;
    document.body.appendChild(link);
    link.click();
    link.remove();
    });  
  }
  logout() {
    this._authService.logout();
  }

}
 
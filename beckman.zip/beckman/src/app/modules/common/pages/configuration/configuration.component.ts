import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SecondarysalesService } from '../../../cpadmin/service/secondarysales.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { ActionItems } from 'src/app/core/services/constants';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';

@Component({
  selector: 'app-configuration',
  templateUrl: './configuration.component.html',
  styleUrls: ['./configuration.component.css'],
  encapsulation:ViewEncapsulation.None
})
export class ConfigurationComponent implements OnInit {

  public configForm: FormGroup;
  public configurationData;
  public isDisabled:boolean = true;
  public configPermission;
  constructor(private fb: FormBuilder, private _UtilsService : UtilsService, private _bookingService: CpbookingService, 
    private _secondarySalesService: SecondarysalesService, private _formValidator: FormValidatorService) { }

  ngOnInit() {
    this.loadConfigForm();
    this.loadStockLogPermission();
    // this.cessChange();
    this._secondarySalesService.getPrintConfiguration((response) => {
      this.configurationData = response;
      this.setConfigForm();
    });
  
  }
 
  loadStockLogPermission(){
    this._bookingService.getActionPermission({model : 'cpconfiguration'}, response =>{
      this.configPermission= response['cpconfiguration'];
      if (!response['cpconfiguration'][ActionItems['EDIT']])  this.configForm.disable();
    });
  }

  setActionsPermission(){
    return this.configPermission && typeof this.configPermission[ActionItems['EDIT']] != 'undefined'  ?  true : false;
  }

  loadConfigForm() {
    this.configForm = this.fb.group({
      accountName: ['', Validators.required],
      accountNumber: ['',[ Validators.required , this._formValidator.numberValidation, this._formValidator.negativeValidation,this._formValidator.noDecimalsValidation]],
      ifscCode: ['', Validators.required],
      micrCode: ['', Validators.required],
      // cess: ['', Validators.required],
      // cessName: [{value: '', disabled: this.isDisabled}],
      // cessPercentage: [{value: '', disabled: this.isDisabled}],
      cpLogoUrl: [''],
      originalPrintLabel: [''],
      duplicatePrintLabel: [''],
      triplicatePrintLabel: [''],
      footerText:[''],
      declaration: [''],
      fssaiNo: [''],
      msmeNo: [''],
      website: [''],
      email: ['', [this._formValidator.emailValidation,Validators.required]],
      secondaryInvoiceNamingConvention:[''],
      secondaryInvoiceRunningNumber:['', [this._formValidator.noDecimalsValidation,this._formValidator.negativeValidation]],
      secondaryDCNamingConvention:[''],
      secondaryDCRunningNumber:['', [this._formValidator.noDecimalsValidation,this._formValidator.negativeValidation]],
      secondaryCreditNamingConvention:[''],
      secondaryCreditRunningNumber:['', [this._formValidator.noDecimalsValidation,this._formValidator.negativeValidation]],
      secondaryDebitNamingConvention:[''],
      secondaryDebitRunningNumber:['', [this._formValidator.noDecimalsValidation,this._formValidator.negativeValidation]]

    },{validators :[this._formValidator.dependencyRequiredValidator('secondaryInvoiceNamingConvention','secondaryInvoiceRunningNumber'),
    this._formValidator.dependencyRequiredValidator('secondaryDCNamingConvention','secondaryDCRunningNumber'),
    this._formValidator.dependencyRequiredValidator('secondaryCreditNamingConvention','secondaryCreditRunningNumber'),
    this._formValidator.dependencyRequiredValidator('secondaryDebitNamingConvention','secondaryDebitRunningNumber')
  ]});
  }

  setConfigForm() {    
      this.configForm.setValue({
      accountName: this.configurationData.accountName,
      accountNumber: this.configurationData.accountNumber,
      ifscCode: this.configurationData.ifscCode,
      micrCode: this.configurationData.micrCode,
      // cess: this.configurationData.cess.toString(),
      // cessName: this.configurationData.cessName,
      // cessPercentage: this.configurationData.cessPercentage,
      cpLogoUrl: this.configurationData.cpLogoUrl,
      originalPrintLabel: this.configurationData.originalPrintLabel,
      duplicatePrintLabel: this.configurationData.duplicatePrintLabel,
      triplicatePrintLabel: this.configurationData.triplicatePrintLabel,
      footerText: this.configurationData.footerText,
      fssaiNo: this.configurationData.fssaiNo,
      msmeNo: this.configurationData.msmeNo,
      declaration: this.configurationData.declaration,
      email: this.configurationData.email,
      website: this.configurationData.website,
      secondaryInvoiceNamingConvention :this.configurationData.secondaryInvoiceNamingConvention,
      secondaryInvoiceRunningNumber :this.configurationData.secondaryInvoiceRunningNumber,
      secondaryDCNamingConvention :this.configurationData.secondaryDCNamingConvention,
      secondaryDCRunningNumber :this.configurationData.secondaryDCRunningNumber,
      secondaryCreditNamingConvention :this.configurationData.secondaryCreditNamingConvention,
      secondaryCreditRunningNumber : this.configurationData.secondaryCreditRunningNumber,
      secondaryDebitNamingConvention :this.configurationData.secondaryDebitNamingConvention,
      secondaryDebitRunningNumber : this.configurationData.secondaryDebitRunningNumber

    
    })
  }

  cessChange() {
    const cessName = this.configForm.get('cessName');
    const cessPercentage = this.configForm.get('cessPercentage');
    this.configForm.get('cess').valueChanges.subscribe(
      (status: any) => { 
        status = status.toString();
        if(status == "1") { 
          this.isDisabled = true;
          cessName.enable();
          cessPercentage.enable();
          cessName.setValidators([Validators.required]);
          cessPercentage.setValidators([Validators.required]);
        }
        else {
          this.isDisabled = false;
          this.configForm.controls['cessName'].setValue('');
          this.configForm.controls['cessPercentage'].setValue('');
          cessName.disable();
          cessPercentage.disable();
          cessName.clearValidators();
          cessPercentage.clearValidators();
        }
        cessName.updateValueAndValidity();
        cessPercentage.updateValueAndValidity();
      });
  }

  onChangeLogo(event) {
    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();
      reader.onload = () => {
        this.configForm.get('cpLogoUrl').setValue(event.target.files[0]);
      };
      reader.readAsDataURL(event.target.files[0]);
    }
  }

  updateConfiguration() {
    const updatedConfiguration = new FormData();
    updatedConfiguration.append('id', this.configurationData.id);
    updatedConfiguration.append('cpLogoUrl', this.configForm.get('cpLogoUrl').value);
    updatedConfiguration.append('accountName', this.configForm.get('accountName').value);
    updatedConfiguration.append('accountNumber',  this.configForm.get('accountNumber').value);
    updatedConfiguration.append('micrCode', this.configForm.get('micrCode').value);
    updatedConfiguration.append('ifscCode', this.configForm.get('ifscCode').value);
    // updatedConfiguration.append('cess', this.configForm.get('cess').value);
    // updatedConfiguration.append('cessName', this.configForm.get('cessName').value);
    // updatedConfiguration.append('cessPercentage', this.configForm.get('cessPercentage').value);
    updatedConfiguration.append('originalPrintLabel', this.configForm.get('originalPrintLabel').value);
    updatedConfiguration.append('duplicatePrintLabel', this.configForm.get('duplicatePrintLabel').value);
    updatedConfiguration.append('triplicatePrintLabel', this.configForm.get('triplicatePrintLabel').value);
    updatedConfiguration.append('footerText', this.configForm.get('footerText').value);
    updatedConfiguration.append('fssaiNo', this.configForm.get('fssaiNo').value);
    updatedConfiguration.append('msmeNo', this.configForm.get('msmeNo').value);
    updatedConfiguration.append('declaration', this.configForm.get('declaration').value);
    updatedConfiguration.append('website', this.configForm.get('website').value);
    updatedConfiguration.append('email', this.configForm.get('email').value);
    updatedConfiguration.append('secondaryInvoiceNamingConvention', this.configForm.get('secondaryInvoiceNamingConvention').value ?this.configForm.get('secondaryInvoiceNamingConvention').value : '');
    updatedConfiguration.append('secondaryInvoiceRunningNumber', this.configForm.get('secondaryInvoiceRunningNumber').value ? this.configForm.get('secondaryInvoiceRunningNumber').value : '');
    updatedConfiguration.append('secondaryDCNamingConvention', this.configForm.get('secondaryDCNamingConvention').value ? this.configForm.get('secondaryDCNamingConvention').value : '');
    updatedConfiguration.append('secondaryDCRunningNumber', this.configForm.get('secondaryDCRunningNumber').value ? this.configForm.get('secondaryDCRunningNumber').value : '');
    updatedConfiguration.append('secondaryCreditNamingConvention', this.configForm.get('secondaryCreditNamingConvention').value ? this.configForm.get('secondaryCreditNamingConvention').value : '');
    updatedConfiguration.append('secondaryCreditRunningNumber', this.configForm.get('secondaryCreditRunningNumber').value ? this.configForm.get('secondaryCreditRunningNumber').value : '');
    updatedConfiguration.append('secondaryDebitNamingConvention', this.configForm.get('secondaryDebitNamingConvention').value ? this.configForm.get('secondaryDebitNamingConvention').value : '');
    updatedConfiguration.append('secondaryDebitRunningNumber', this.configForm.get('secondaryDebitRunningNumber').value ? this.configForm.get('secondaryDebitRunningNumber').value : '');
    this._secondarySalesService.updatePrintConfiguration(updatedConfiguration, (response) => {
    });
  }

  resetConfiguration() {
    this.configForm .reset();

    this.setConfigForm()
  }

}

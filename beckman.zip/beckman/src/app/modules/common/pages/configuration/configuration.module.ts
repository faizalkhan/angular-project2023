import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfigurationComponent } from './configuration.component';
import { Routes, RouterModule } from '@angular/router';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';

const routes: Routes = [{
  path:'', 
  component:ConfigurationComponent,

}]
 
@NgModule({
  declarations: [ConfigurationComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    CustomFormsModule,
    AppMaterialModule
  ]
})
export class ConfigurationModule { }

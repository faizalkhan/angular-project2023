
import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { routes } from 'src/app/app-routing.module';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { OtlpartsDetailComponent } from './otlparts-detail.component';



describe('OtlpartsDetailComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes),
        AppMaterialModule,
        CustomFormsModule,
        HttpClientModule,
        BrowserAnimationsModule
      ],
     
      declarations: [
        OtlpartsDetailComponent
      ],
    }).compileComponents();
   
  }));

  it('should create the otl parts  detail', () => {
    const fixture = TestBed.createComponent(OtlpartsDetailComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

});



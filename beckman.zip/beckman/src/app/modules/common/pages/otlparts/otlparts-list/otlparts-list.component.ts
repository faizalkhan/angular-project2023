import { Component, OnInit, HostListener } from '@angular/core';
import { OtlpartsService } from '../../../../beckman/service/hospital/otlparts.service';
import { AgGridRouterComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-router.component';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { FormGroup, FormBuilder } from '@angular/forms';
import { PartsService } from '../../../../beckman/service/parts/parts.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { IGetRowsParams } from 'ag-grid-community';
import { ActionItems } from 'src/app/core/services/constants';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';

@Component({
  selector: 'app-otlparts-list',
  templateUrl: './otlparts-list.component.html',
  styleUrls: ['./otlparts-list.component.css']
})
export class OtlpartsListComponent implements OnInit {

  public columnDefs;
  public defaultColDef;
  public gridOptions;
  private gridApi; 
  public gridColumnApi;
  public searchValue;
  public otlPartsSearchForm: FormGroup;
  public productLineNames = [];
  public pageSize = 10;
  public moduleName;
  public editOtlParts =false;
  public deleteOtlPart =false;

  public otlPermission;
  constructor(private fb: FormBuilder,
    private _PromptService: PromptService, private _permissionMenuListService: PermissionMenuListService,
    private _utilsService : UtilsService , private _otlPartsService: OtlpartsService, private _partsService: PartsService) { }
    
   @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
  }
  ngOnInit() {
    this.moduleName = this._utilsService.moduleName()
    this.loadOtlPartsPermission()

    this._partsService.getProductLine((res)=>{
      this.productLineNames = res;
    })
    this.loadOtlPartsSearchForm();
    this.defaultColDef = {
      sortable: true,
      filter: false,
      resizable: true
    };
    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2
    };
    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.gridOptions.onFilterChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: "id",
        headerName: 'S No.',
        width: 75,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
      },
      {
        headerName: 'Part Number',
        field: "partNumber",
        width: 190,
        cellRendererFramework: AgGridRouterComponent,
        cellRendererParams: {
          inRouterLink: '/'+this.moduleName+'/otlparts/view/',
        },
        comparator:(param1,param2)=>{
          return this._utilsService.alphaNumbericSorting(param1,param2);
        }
      },
      {
        headerName: 'OTL Number',
        field: "OTLNumber",
        width: 150,
      },
      {
        headerName: 'Product Line',
        field: "productLine",
        width: 120,
        sortable: false,
      },
      {
        headerName: 'Description',
        field: "description",
        width: 250,
        sortable: false,
      },
      {
        headerName: 'Price',
        field: "price",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        cellRenderer :(params) =>{
          return typeof params.value !== 'undefined' ? "<div class = 'text-right'>" + this._utilsService.rupeeFormat(this.RoundOFTwoDigit(params.value)) + "</div>"  : ""
        }
      },
      {
        headerName: 'Discount',
        field: "discount",
        width: 100,
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        cellRenderer :(params) =>{
          return typeof params.value !== 'undefined' ? "<div class = 'text-right'>" + this._utilsService.rupeeFormat(this.RoundOFTwoDigit(params.value)) + "</div>"  : ""
        }
      },
      {
        field: "isActive",
        headerName: 'Status',
        width: 100,
        valueFormatter: (params) =>{
          return (params.value ||   params.value == 0) ?  this._utilsService.isActiveStatus(params.value) : ''
        }
      },
      {
        field: "",
        headerName: 'Action',
        sortable: false,
        filter: false,
        width: 100,
        cellRendererFramework: AgGridMenuComponent,
        cellRendererParams: (params) => {
          let menu = [{
            name: "View",
            link: "/"+this.moduleName +"/otlparts/view/",
            onMenuAction:''
          }]
          if (this.editOtlParts){
            menu.push({
              name: "Edit",
              link: "/"+this.moduleName + "/otlparts/edit/",
              onMenuAction:''
            })
          }
          if (this.deleteOtlPart){
            menu.push({
              name: "Delete",
              link: "",
              onMenuAction: this.deleteOtlParts.bind(this)
            })
          }
          return {menu}
        },
      }
    ];
  }

  loadOtlPartsPermission(){
    this._permissionMenuListService.getActionPermission({model : 'otlparts'}, response =>{
      this.otlPermission= response['otlparts'];
      this.editOtlParts = this.setActionsPermission('EDIT');
      this.deleteOtlPart = this.setActionsPermission('DELETE')
    });
  }
  setActionsPermission(name){
    return this.otlPermission && typeof this.otlPermission[ActionItems[name]] != 'undefined'  ?  true : false;
  }

  deleteOtlParts(id) {
    this._PromptService.openDialog({title : 'Delete OTL Parts',btnLabel : 'CONFIRM',content :'Are you sure you want to delete OTL parts?'}, response =>{
      if (response){
        this._otlPartsService.deleteOtlParts(id, () => this.getOtlPartsList())
      }
    })
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.getOtlPartsList();
  }


  getOtlPartsList(data?:any) {
    let payload = {};
    var datasource = {
      getRows: (params: IGetRowsParams) =>{
        if (data) {
          payload = data;
        }
        payload['page_size'] =this.pageSize
        payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
        payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
        payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
        this._otlPartsService.searchOtlParts(payload, (res)=>{
          let length = res['total'];
          params.successCallback(res['results'], length) 
          })
      }
    }
      this.gridApi.setDatasource(datasource);
  }

  

  importOtlParts($event) {
    const otlPartsData = new FormData();
    otlPartsData.append('file', $event.target.files[0]);
    this._otlPartsService.importOtlParts(otlPartsData, () => {
      this.getOtlPartsList();
    });
  }

  exportOTLParts() {
    this._otlPartsService.exportOtlParts();
  }
  loadOtlPartsSearchForm() {
    this.otlPartsSearchForm = this.fb.group({
      partNumber: [''],
      OTLNumber: [''],
    });
  }


  searchOtlPartsFilter() {
    this.getOtlPartsList(this.otlPartsSearchForm.value);
  }
  
  getFilterProductName(value) {
    let options = {};
      options = this.productLineNames.filter((val) => {
        return val.name=== value
      });
    return options[0] ? options[0] : '';
  }
  
  

  cancelOtlPartsFilter() {
    this.getOtlPartsList();
    this.otlPartsSearchForm.reset();
  }
  RoundOFTwoDigit(num: any){
    var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
    return number;
  }
}

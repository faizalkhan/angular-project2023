import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otlparts',
  templateUrl: './otlparts.component.html',
  styleUrls: ['./otlparts.component.css']
})
export class OtlpartsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

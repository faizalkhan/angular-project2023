import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { OtlpartsListComponent } from './otlparts-list/otlparts-list.component';
import { OtlpartsComponent } from './otlparts.component';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { AgGridModule } from 'ag-grid-angular';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { OtlpartsDetailComponent } from './otlparts-detail/otlparts-detail.component';
import { PipeModule } from 'src/app/core/pipe/pipe.module';
import { OtlpartsAddComponent } from './otlparts-add/otlparts-add.component';

const routes:Routes = [{
  path: '',
  component: OtlpartsComponent,
  children: [
    {
      path:'',
      component:OtlpartsListComponent
    },
    {
      path:'add',
      component:OtlpartsAddComponent
    },
    {
      path:'view/:id',
      component:OtlpartsDetailComponent
    },
    {
      path:'edit/:editId',
      component:OtlpartsDetailComponent
    }
  ]
}];

@NgModule({
  declarations: [OtlpartsListComponent, OtlpartsComponent, OtlpartsDetailComponent,  OtlpartsAddComponent],
  imports: [
    CommonModule,
    AppMaterialModule,
    CustomFormsModule,
    AgGridModule.withComponents([]),
    RouterModule.forChild(routes),
    PipeModule
  ]
})
export class OtlpartsModule { }

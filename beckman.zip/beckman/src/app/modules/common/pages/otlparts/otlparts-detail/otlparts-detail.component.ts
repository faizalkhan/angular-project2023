import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { OtlpartsService } from '../../../../beckman/service/hospital/otlparts.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { ActionItems } from 'src/app/core/services/constants';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';

@Component({
  selector: 'app-otlparts-detail',
  templateUrl: './otlparts-detail.component.html',
  styleUrls: ['./otlparts-detail.component.css'],
  encapsulation: ViewEncapsulation.None

})
export class OtlpartsDetailComponent implements OnInit {

  public otlPartId;
  public otlData;
  public editOtlParts =  false;
  public otlPartsForms : FormGroup;
  public moduleName ;
  public editOtlPartsPermission = false;
  public deleteOtlPartsPermission= false;
  constructor( private router: Router,public route: ActivatedRoute, private _utilsService : UtilsService , private _permissionMenuListService: PermissionMenuListService,    private _PromptService: PromptService,
    private _formValidator: FormValidatorService,private _otlPartsService: OtlpartsService,private fb: FormBuilder) { }

  ngOnInit() {
    this.moduleName = this._utilsService.moduleName();
    this.loadOtlPartsForm();
    this.route.paramMap.subscribe((params: ParamMap) => {
      if(parseInt(params.get('id'))){
        this.otlPartId = parseInt(params.get('id'));
        this.editOtlParts = false;
      }else{
        this.otlPartId = parseInt(params.get('editId'));
        this.editOtlParts = true;
      }
      this.loadOtlPartsPermission()
    });
    
    this._otlPartsService.viewOtlParts(this.otlPartId,
      (response) => {
        this.otlData = response;
        this.setOtlParts();
      },
      (error) => console.log(error));

      this.otlPartsForms.get('price').valueChanges.subscribe(value =>{
        this.otlPartsForms.get('discount').clearValidators();
        
        if(value == 0 ) {
         this.otlPartsForms.get('discount').setValidators([Validators.required, this._formValidator.noDecimalsValidation, this._formValidator.maxLength(100,'0'), this._formValidator.dependencyNumberValidator(0)]);
         if (this.otlPartsForms.get('discount').value !=100)  this.otlPartsForms.get('discount').reset();
          
        }else{
         if (this.otlPartsForms.get('discount').value ==100 || this.otlPartsForms.get('discount').value  < 0)  this.otlPartsForms.get('discount').reset();
         this.otlPartsForms.get('discount').setValidators([Validators.required, this._formValidator.noDecimalsValidation, this._formValidator.maxLength(99,'0')]);
         this.otlPartsForms.get('discount').updateValueAndValidity()
        }
       
      })
   
      this.otlPartsForms.get('discount').valueChanges.subscribe(value =>{
         if (value == 100) {
           this.otlPartsForms.get('price').setValue(0);
         }
      }) 
      
  }

  loadOtlPartsPermission(){
    this._permissionMenuListService.getActionPermission({model : 'otlparts'},response =>{
        this.editOtlPartsPermission = response['otlparts'] && typeof response['otlparts'][ActionItems['EDIT']] == 'undefined' ? false : true
        this.deleteOtlPartsPermission = response['otlparts'] && typeof response['otlparts'][ActionItems['DELETE']] == 'undefined' ? false : true
      if( this.editOtlParts && ! this.editOtlPartsPermission ) this._otlPartsService.navigateOtlParts();
    });
}

  setOtlParts(){
    if (this.editOtlParts){
      this.otlPartsForms.setValue({
        price : this.otlData.price,
        discount: this.otlData.discount,
        isActive : this.otlData.isActive.toString()
      });
    }

  }
  loadOtlPartsForm(){
    this.otlPartsForms = this.fb.group({
      price: ['',[Validators.required,this._formValidator.withZeroAndNegativeValidation]],
      discount: ['', [Validators.required, this._formValidator.noDecimalsValidation, this._formValidator.maxLength(100)]],
      isActive : ['']
    });
  }

  redirectTo(){
  this._otlPartsService.navigateOtlParts();
  }

  navigate(){
    // this.router.navigate(['/beckman//otlparts/edit', this.otlPartId]);
    this._otlPartsService.navigateEditOtlParts(this.otlPartId)
  }

  resetOtlParts(){
    this.setOtlParts();
  }

  submitOtlParts(){
    let data  = this.otlPartsForms.value;
    data.partNumber = this.otlData.partNumber;
    data.cpnumber = this.otlData.cpnumber;
    data.OTLNumber = this.otlData.OTLNumber;
    data.productLine =this.otlData.productLine;
    data.site_id = this.otlData.site_id;
    data.custNumber = this.otlData.custNumber;
    this._otlPartsService.editOtlParts(this.otlPartId, data);
  }

  deleteOtlParts() {
    this._PromptService.openDialog({title : 'Delete OTL Parts',btnLabel : 'CONFIRM',content :'Are you sure you want to delete OTL parts?'}, response =>{
      if (response){
        this._otlPartsService.deleteOtlParts(this.otlPartId, () => this._otlPartsService.navigateOtlParts())
      }
    })
  }
    

}

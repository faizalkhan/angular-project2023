import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { OtlpartsService } from '../../../../beckman/service/hospital/otlparts.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { ActionItems } from 'src/app/core/services/constants';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';

@Component({
  selector: 'app-otlparts-add',
  templateUrl: './otlparts-add.component.html',
  styleUrls: ['./otlparts-add.component.css'],
  encapsulation: ViewEncapsulation.None

})
export class OtlpartsAddComponent implements OnInit {

  constructor(private fb: FormBuilder, private _formValidator: FormValidatorService, private _UtilsService:UtilsService,private _permissionMenuListService: PermissionMenuListService,
 private _OtlpartsService: OtlpartsService,
    ) { }
  public otlPartsForm: FormGroup;
  public partsList = [];
  public otlList = [];
  public moduleName;  


  ngOnInit() {
    this.moduleName = this._UtilsService.moduleName();
    this._permissionMenuListService.getActionPermission({model : 'otlparts'},response =>{
      if (response['otlparts'] == 'undefined' || typeof response['otlparts'][ActionItems['ADD']] == 'undefined') this._OtlpartsService.navigateOtlParts();
    });
    this.loadOTLPartForm();
    this._OtlpartsService.getPartsAndOtlParts((response) =>{
     this.partsList = response[1];
     this.otlList = response[0];
   } );


   this.otlPartsForm.get('price').valueChanges.subscribe(value =>{
    this.otlPartsForm.get('discount').clearValidators();
    if(value == 0 ) {
      this.otlPartsForm.get('discount').setValidators([Validators.required, this._formValidator.noDecimalsValidation, this._formValidator.maxLength(100,'0'), this._formValidator.dependencyNumberValidator(0)]);
      if (this.otlPartsForm.get('discount').value !=100)  this.otlPartsForm.get('discount').reset();
       
     }else{
      if (this.otlPartsForm.get('discount').value ==100 || this.otlPartsForm.get('discount').value  < 0)  this.otlPartsForm.get('discount').reset();
      this.otlPartsForm.get('discount').setValidators([Validators.required, this._formValidator.noDecimalsValidation, this._formValidator.maxLength(99,'0')]);
      this.otlPartsForm.get('discount').updateValueAndValidity()
     }
   })

   this.otlPartsForm.get('discount').valueChanges.subscribe(value =>{
      if (value == 100) {
        this.otlPartsForm.get('price').setValue(0);
      }
   }) 
  }
  loadOTLPartForm(){
    this.otlPartsForm = this.fb.group({
      partNumber : ['', [Validators.required, this._formValidator.requireMatch]],
      OTLNumber:  ['', [Validators.required, this._formValidator.requireMatch]],
      price: ['', [Validators.required,this._formValidator.withZeroAndNegativeValidation]],
      discount: ['', [Validators.required, this._formValidator.noDecimalsValidation, this._formValidator.maxLength(100)]],
      isActive:['1'],
      productLine:['']
    });
  }
  onPartsChange(value){
    this.otlPartsForm.get('productLine').setValue('')
    if(value) this.otlPartsForm.get('productLine').setValue(value.productLine)
  }


  cancelParts() {
    this._OtlpartsService.navigateOtlParts();
  }

  resetParts() {
      this.otlPartsForm.reset();
    this.otlPartsForm.get('isActive').setValue('1')

  }
  submit(){
    let data = this.otlPartsForm.value;
    data['OTLNumber'] = this.otlPartsForm.get('OTLNumber').value['OTLnumber']
    data['partNumber'] = this.otlPartsForm.get('partNumber').value['partNumber']
    this._OtlpartsService.addOtlParts(data);
  }

}

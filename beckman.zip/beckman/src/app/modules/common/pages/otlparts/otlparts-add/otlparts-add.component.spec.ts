import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtlpartsAddComponent } from './otlparts-add.component';

describe('OtlpartsAddComponent', () => {
  let component: OtlpartsAddComponent;
  let fixture: ComponentFixture<OtlpartsAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtlpartsAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtlpartsAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

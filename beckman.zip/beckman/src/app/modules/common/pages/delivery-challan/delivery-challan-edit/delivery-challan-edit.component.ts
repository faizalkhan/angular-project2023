import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { MatDialog } from '@angular/material';
import { LocationService } from 'src/app/core/services/utils/location.service';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { Roles } from 'src/app/modules/auth/model/user';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { BILLING, SHIPPING, colorCodes, ErrorMessage, SHIP_TO, BILL_TO, dcType, ActionItems } from 'src/app/core/services/constants';
import { AddShippingDialog, ListShippingAddress, AddPartsDialog, AddStockSwapTransfer, BackTopartsDialog } from '../../../dialogs/secondary-dialog/dialog.component';
import { UtilsService } from 'src/app/core/services/utils/utils.service';

@Component({
  selector: 'app-delivery-challan-edit',
  templateUrl: './delivery-challan-edit.component.html',
  styleUrls: ['./delivery-challan-edit.component.css']
})
export class DeliveryChallanEditComponent implements OnInit {
  public currentDate = new Date();
  public displayClientKeys = ['name','address','city','pincode']
  public setCurrentDate = new Date();
  public dcForm: FormGroup;
  public dcId;
  public clientNames = [];
  public otlList = [];
  public clientNumber;
  public otlPartsList = []; 
  public partsData = [];
  public shipDetails; // current shipping address
  public billingDetails;
  public netAmount = 0;
  public iGst:boolean;
  public  dcData;
  public partsCurrentOptions = [];
  public viewDC  =false;
  public cpAccountDetails ;
  public  regionFromService=[];
  public cpSiteIdList = [];
  public cpAddress ;
  public dcStatus; 
  public role;
  public accessControls =[];
  // for edit Purpose;
  public bill_to_id ;
  public ship_to_id;
  public dc_address_id;// map invoice address,  in shipping and billing thru cp_invoice
  public isAdmin = false;
  public TransferValue: any;
  public login_cpNumber: any;
  public is_for_cprt: boolean=false;
  constructor(private fb: FormBuilder, public _dialog: MatDialog, public _swapdialog: MatDialog,
     public _backTopartsDialog: MatDialog, private _locationService: LocationService,
     private _momentService: MomentService,private _storageService: StorageService,
    public route: ActivatedRoute, private _bookingService: CpbookingService,private _snackBar :SnackbarService, 
    private _secondarySalesService: SecondarysalesService, private _formValidator: FormValidatorService) { }


  ngOnInit() {
    this._bookingService.getActionPermission({model : 'deliverychallan'}, response =>{
      if (!response['deliverychallan'] || !response['deliverychallan'][ActionItems['EDIT']])this.cancel();
    })
    this.loadDcForm();
    this.getDCPermissionAccessControl();
     // get roles 
     this.role = this._storageService.getUserDetails()['role'];
     this.isAdmin = this.role ==Roles.Admin;
     this.route.paramMap.subscribe((params: ParamMap) => {
       this.dcId = parseInt(params.get('id'));
     });
     this._secondarySalesService.cpModuleAccess(res => {
      this.login_cpNumber = res['cpnumber'];
    });
     this._secondarySalesService.viewDeliveryChallan(this.dcId,
      (response) => {
        console.log(response);
        this.dcData = response;
      
        this.is_for_cprt = response['is_for_cprt'];
        this.dcStatus = dcType[response.status]
        if (!response['isEditable'] && this.role != Roles.Admin)this.cancel();
        this.getHospitals();
        if (this.dcData.status!= 0) this.dcForm.get('custName').disable()
      },
      (error) => console.log(error))

      // getting region ,state and city 
      this._locationService.getLocationData((locationData) => {
        this.regionFromService = locationData
      });
  }


  loadDcForm() {
    this.dcForm = this.fb.group({
      custName: ['', [Validators.required, this._formValidator.requireMatch]],
      custNumber: [{value : '' , disabled : true }, Validators.required],
      orderNumber: [''],
      orderDate: [''],
      site_id: [{value : '' , disabled : true }, Validators.required],
      dispatchThrough: [''],
      dispatchDocNo: [''],
      dispatchDocDate: [''],
      referenceNumber: [''],
      destination: [''],
      bankDetails: [''],
      waybillNumber: [''],
      waybillDate: [''],
      dcDate : ['', Validators.required],
      supplierRef :[''],
      supplierRefDate:['', Validators.required],
      remarks:[''],
      otherRef:[''],
      accountName :[''],
      accountNumber:[''],
      website:[''],
      ifscCode:[''],
      email:[''],
      gst:[''],
      pan:['']
     
    });
  }
  getHospitals(){
    this._bookingService.getDistinctHospitals({order_by:"name", cpnumber : this.dcData.cpNumber, model:"secondary"},(response => {
      this.clientNames = response;
      this.setDCForm(this.dcData);
     }));
  }
  getDCPermissionAccessControl(){
    this._bookingService.getPermissionAccessControls({module : "DC_Edit"}, response =>{      
        this.accessControls = response.field_permission;
        if (!response.parent_permission[0].is_allowed && this.role != Roles.Admin)this.cancel();
        if (this.role == Roles.Channel_Partner &&  response.field_permission.length){
          this.getEditDCAccessControl();
        }
        
    })
  }
  getEditDCAccessControl(){
    this.accessControls.map((editControl) => {
      if (typeof this.dcForm.controls[editControl.name] !== 'undefined'){
       if (editControl['is_allowed']) {
          this.dcForm.controls[editControl.name].enable();
         }
         else this.dcForm.controls[editControl.name].disable();
       }
     });
  }
  checkEditAccess(fieldName){
    if (this.role == Roles.Channel_Partner){
      let control  = this.accessControls.find(response => response['name'] == fieldName);
      if (control ){
       return  control['is_allowed'] ;
      }
    }else
    return true;
  }
  setDCForm(response){
    this.getCustName(response.custNumber, response.siteId ,response.OTLNumber, response.parts);
    this.partsData = response.parts;
    this.bill_to_id = this.dcData.address.find(address => address['type'] ==BILLING)['id']
    this.ship_to_id = this.dcData.address.find(address => address['type'] ==SHIPPING)['id'];
    this.dc_address_id = this.dcData.address.find(address => address['type'] ==SHIPPING)['dcId'];
    this.setDCFormControls(response)
  }

  setDCFormControls(response){
    this.billingDetails = this.dcData.address.find(address => address.type == BILLING );
    this.shipDetails = this.dcData.address.find(address => address.type == SHIPPING );
    this.dcForm.patchValue({
      orderNumber: response.orderNumber,
      orderDate: response.orderDate,
      deliveryNote:response.deliveryNote,
      dispatchThrough: response.dispatchThrough,
      dispatchDocNo: response.dispatchDocNo,
      dispatchDocDate: response.dispatchDocDate,
      referenceNumber: response.referenceNumber,
      destination: response.destination,
      bankDetails: response.bankDetails ,
      waybillDate: response.waybillDate,
      waybillNumber: response.waybillNumber,
      deliveryNoteDate: response.deliveryNoteDate,
      dcDate: response.dcDate,
      supplierRef: response.supplierRef,
      supplierRefDate: response.supplierRefDate,
      termsOfPayment: response.termsOfPayment,
      remarks: response.remarks,
      otherRef:response.otherRef,
      accountName :response.accountName,
      accountNumber:response.accountNumber,
      website:response.website,
      ifscCode:response.ifscCode,
      email:response.email,
      gst:response.gstNumber,
      pan:response.panNumber
  })
  }
  getCustName(custNumber,siteId ,otlno, parts) {
    let details;
    details = this.clientNames.find((res) =>res.custNumber == custNumber && res.site_id == siteId)
    this.dcForm.get('custName').setValue(details);
    this.onClientChange(details ? details : '', otlno, parts);
  }
   // autocomplte fields 
   onClientChange(value, otlNo?: any, partsData?: any) {
    this.clearDataOnClientChange();
    if (value) { 
     
      this.getChannelPartnerSiteAddress(value);
      this.dcForm.get('custNumber').setValue(value.custNumber);
      this.dcForm.get('site_id').setValue(value.site_id);
      this._bookingService.getOtlBySiteId({'cpnumber' : this.dcData.cpNumber, "custNumber":value.custNumber, "order_by":"otl_number" }, (response) => {
        this.otlList = response;
        if (!response.length)  this._snackBar.loadSnackBar(ErrorMessage.NO_OTLNUMBER_STOCK, colorCodes.ERROR);
        if (!this.dcForm.get('custName').touched || (value.custNumber == this.dcData.custNumber && value.site_id == this.dcData.siteId)) {
          this.partsData =  JSON.parse(JSON.stringify(this.dcData.parts))
            if (value.custNumber == this.dcData.custNumber && value.site_id == this.dcData.siteId){
              this.setDCFormControls(this.dcData);
              this.loadPartsTable(this.dcData.parts);
            }else this.loadPartsTable(partsData);
            
        }else{
          this.billingDetails = value['edit_bill_to'];
          this.shipDetails = value['edit_ship_to'];
        }
      });
    }
  }
  clearDataOnClientChange(){
    this.otlList = [];
    this.partsData =  [];
    this.netAmount =0;
    this.dcForm.patchValue({
      site_id: '',
      custNumber: ' '
    })
  }

   // ---------------------------Address section ------------------------------------
  
       // To ser Channel partner address and store the address list 
       getChannelPartnerSiteAddress(value){
        this._secondarySalesService.getCpSiteAddress({'cust_number' :value.custNumber, cpnumber : this.dcData.cpNumber },response => {
          if (!this.dcForm.get('custName').touched || (value.custNumber == this.dcData.custNumber && value.site_id == this.dcData.siteId)) { 
            this.cpAddress = response.find(address => address['cpSiteId'] ==this.dcData['cpSiteId'] );
          }else {
          this.cpAddress = response[0];
          }
          this.cpSiteIdList = response;
        })
      }
      // on changing the CP address
      lisChannelPartnertAddress(){
        const dialogRef = this._dialog.open(ListShippingAddress, {
          width: '500px',
          data: {details: this.cpSiteIdList, currentAddressDetails:  this.cpAddress , type : 'Channel_Partner'}
        });
        dialogRef.afterClosed().subscribe(result => {
          result['id'] = this.dcData.cpSiteAddress['id']
          if (result ) this.cpAddress = result
        });
      }
  
      //  hospital bill to and ship to address 
      listClientAddress(addressType) {
        let addressList = [];
        this._secondarySalesService.getAddressList({custNumber : this.dcForm.get('custNumber').value ,cpnumber : this.dcData.cpNumber} , response =>{
          if (response.length) {
          response.map(data => {
              if (data.type == addressType || data.type == "both"){
                // adding hospital address id to each address obj 
                data['address']['addressId']  = data.id;
                addressList.push( data['address']);
              }
            });
          }
          this.openClientAddressListDialog(addressType,addressList.length ? addressList : (addressType == BILL_TO ? [this.billingDetails] : [this.shipDetails]))
        })
      }
  
      openClientAddressListDialog(type,addressList){
        const dialogRef = this._dialog.open(ListShippingAddress, {
          width: '500px',
          data: {details: addressList, currentAddressDetails:  (type == BILL_TO ? this.billingDetails : this.shipDetails) }
        });
        dialogRef.afterClosed().subscribe(result => {
          if (result && !result['edited']) {
            result['address'] = result['addressLine']
            this.billingDetails = (type == BILL_TO) ? result : this.billingDetails;
            this.shipDetails = (type == SHIP_TO) ? result : this.shipDetails;
  
          }else{
            if (result) this.editClientAddress(result ,type);
          }
       
        });
      }
      editClientAddress(data, type){
        let addressDetails ;
        if (data['addressId']){
          this._secondarySalesService.getAddressDetails(data['addressId'], response =>{
            addressDetails = response['address'];
            addressDetails['addressId'] = response['id'];
            addressDetails['type'] =type;
            this.addClientAddress(addressDetails)
          })
        }else{
          addressDetails =  type == BILL_TO ? this.billingDetails : this.shipDetails
          addressDetails['type'] =type;
          this.addClientAddress(addressDetails)
        }
        
      }
      addClientAddress(addressDetails ? :any) {
        const dialogRef = this._dialog.open(AddShippingDialog, {
          width: '500px',
          data: {custNumber: this.dcForm.get('custNumber').value, cpnumber : this.dcData.cpNumber, regionFromService : this.regionFromService , address : addressDetails}
    
        }); 
        dialogRef.afterClosed().subscribe(result => {
          if (result) {
  
             this.shipDetails = (result.type == 'both' || result.type == SHIP_TO) ? result['address'] : this.shipDetails;
              this.billingDetails = (result.type == 'both' || result.type == BILL_TO) ? result['address'] : this.billingDetails;   
          }
        });
      }
    // --------------------------OTl Parts and DC  section  ---------------------------
    AddParts() {
      let dialogRef = this.openPartsDialog(this.partsData);
      dialogRef.afterClosed().subscribe(result => {
        if(result && result['isswap']){
          this.TransferValue ={
            clientName: this.dcForm.get('custName').value,
            clientNumber: this.dcForm.get('custNumber').value,
            siteId: this.dcForm.get('site_id').value,
            otlNumber: result.data['OTLNumber'],
            partNumber: result.data['partsList']
          }
          this.loadSwapTransfer(this.TransferValue);
      }
      else{
        if (result && Object.keys(result).length > 0) { 
          if (result['groupByParts']){
            result['groupByParts'].forEach((part)=>{
              part['newParts'] = true;
              this.addPartsData(part);
            })
          }
        }
      }
      });
    }
    addPartsData(result){
      if(result.quantity) this.partsData.push(result);
      this.loadPartsTable(result);
    }
    editParts(index) {
      let value = this.partsData[index]; 
      let availableQuantity = 0;
      let availableQtyParts = [];
      this._secondarySalesService.getStock({ "OTLNumber": value.OTLNumber, cpnumber : this.dcData.cpNumber, "siteId":  this.dcForm.get('site_id').value ,'custNumber' : this.dcForm.get('custNumber').value,'partNumber': value.partNumber}, (response) => {
       //get stock avaaible qty for existed parts 
       if (!value.newParts) {
         if (this.partsData[index]['type'] == 'OTL'){
          availableQtyParts =  response.filter((part) =>( part['lotNumber'] == this.partsData[index]['lotNumber'] &&part['lotExpiryDate'] == this.partsData[index]['lotExpiryDate'] && part['unitPurchasePrice'] > 0 ))
          availableQuantity =availableQtyParts.reduce((currentAmount, partData) => currentAmount + partData['availableQuantity'],0) ;
         }else {
          availableQtyParts =  response.filter((part) =>( part['lotNumber'] == this.partsData[index]['lotNumber'] &&part['lotExpiryDate'] == this.partsData[index]['lotExpiryDate'] && part['unitPurchasePrice'] == 0 ))
          availableQuantity = availableQtyParts.reduce((currentAmount, partData) => currentAmount + partData['availableQuantity'],0) ;
         } 
          this.partsData[index]['availableQuantity'] = availableQuantity;
          this.partsData[index]['edited_quantity'] = value.edited_quantity ? value.edited_quantity : value.quantity;
          
       }
      
        let dialogRef = this.openPartsDialog(this.partsData, this.partsData[index]);
        dialogRef.afterClosed().subscribe(result => {
          if (result ) {
            result['groupByParts'][0]['dcNumber'] = this.dcData.dcNumber;
            result['groupByParts'][0]['groupedData'] = availableQtyParts
            this.updatePartsData(result, index); 
          }
        
        }); 

     });
     
    }

    updatePartsData(result, partIndex) {
     this.partsData[partIndex] = result['groupByParts'][0];
      this.loadPartsTable(result)
    }

    
    openPartsDialog(data, parts?: any) {
      const dialogRef = this._dialog.open(AddPartsDialog, {
        autoFocus: false,
        width: '750px',
        data: { "dcEdit" : true, "partsOutput": {},'cpnumber' : this.dcData.cpNumber,'otlList' : this.otlList,
         "currentPartsData": data, "editParts": parts ? parts : '', "iGst" : this.iGst,  "editForm" : this.dcId, 
         "site_id":this.dcForm.get('site_id').value, "isEdit":true, "LogincpNumber":this.login_cpNumber }
      });
      return dialogRef;
    }
    openSwapParts(transferData: any){
      const swap_dialogRef = this._swapdialog.open(AddStockSwapTransfer,{
        autoFocus: false,
        width: '80%',
        disableClose: true,
        data: {"partsOutput":{}, "swapData": transferData, "isDcScreen": true}
      });
      return swap_dialogRef;
     }
     backToOpenParts(partsdetail: any, data:any, parts?:any){
      const parts_dialog = this._backTopartsDialog.open(BackTopartsDialog, {
        autoFocus: false,
        width: "750px",
        disableClose: true,
        data: { "partsOutput": {},"partsData": partsdetail, "currentPartsData": data,
         "editParts": parts ? parts : '', "iGst" : this.iGst, 'cpnumber' : this.dcData.cpNumber,"site_id":this.dcForm.get('site_id').value,
         "editForm" : this.dcId, "isEdit":true, "LogincpNumber":this.login_cpNumber}
      });
    return parts_dialog;
   }
    loadSwapTransfer(transferValue: any){
      let swap_dialogRefe = this.openSwapParts(transferValue);
      swap_dialogRefe.afterClosed().subscribe(result =>{
     
        if(result['iscancel'] =='cancel'){
          this.loadBackToParts(result['datavalue']['swapData']);
        }else{
          if(result['isSwap'] == 'swap'){
          this.loadBackToParts(result['datavalue']['swapData']);
          }
        }
  
      })
    }
    loadBackToParts(data?: any){
      let back_to_Dialog = this.backToOpenParts(data, this.partsData);
      back_to_Dialog.afterClosed().subscribe(result =>{
        if(result && result['isswap']){
          this.TransferValue ={
            clientName: this.dcForm.get('custName').value,
            clientNumber: this.dcForm.get('custNumber').value,
            siteId: this.dcForm.get('site_id').value,
            otlNumber: result.data['OTLNumber'],
            partNumber: result.data['partsList']
          }
          this.loadSwapTransfer(this.TransferValue);
      }
        else{
          if (result && Object.keys(result).length > 0) {
            if (result['groupByParts']){
              result['groupByParts'].forEach((part)=>{
                part['newParts'] = true;
                this.addPartsData(part);
              })
            }
          }
      }
      })
   }

  
  
    deleteParts(index) {
        this.partsData.splice(index, 1);
        this.checkPartsDataCount();
    }
    checkPartsDataCount() {
      if (this.partsData.length > 0) this.loadPartsTable(this.partsData);
      else {
        this.netAmount = 0;
        this.dcForm.get('discount_value').setValue('')
        this.dcForm.get('discount_type').setValue('2')
      }
    }
 //-------------Price and tax calculation ------------
loadPartsTable(result) {
  if (result && this.partsData) {
    this.netAmount= this.partsData.reduce((currentAmount, part)=>{
      return this.RoundOFTwoDigit(Number((currentAmount+ part['total_amount'])))
    },0)

  }
}
RoundOFTwoDigit(num: any){
  var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
  return number;
}
  //// ---reset ,cancel, view and update page ----------
  viewDCDetails(status){
    this.viewDC= status 
  }


  reset(){
    this.partsData = [];
    this.setDCForm(this.dcData);
  }
  retriggerParts(fieldName, index?:any){
      let payload = {
        field : fieldName
      }
      if (typeof index == 'undefined'){
        payload['dc_id']  = this.dcData.id
      }
      else {
      payload['dc_part_id']  = this.partsData[index]['part'][0].id
      }
   
      this._secondarySalesService.retriggerDC(payload, response=>{
          if (fieldName == 'price' && typeof index != 'undefined'){
              let part = this.partsData[index];
              if (typeof this.partsData[index]['edited_quantity'] == 'undefined')  this.addRetriggerFlag(index);
              this.partsData[index]['price']  = response.price; 
              let quantity = typeof this.partsData[index]['edited_quantity'] != 'undefined' ?  part['edited_quantity'] :  part['quantity']
              part['total_amount'] =  this.RoundOFTwoDigit(Number((part['price'] * quantity )));
               this.loadPartsTable(this.partsData);
          }
          else{
            if (fieldName != 'price')this.dcForm.get(fieldName).setValue(response[fieldName])
          }
    })
  }

  addRetriggerFlag(index){
    let value =  this.partsData[index];
    this._secondarySalesService.getStock({ "OTLNumber": value.OTLNumber, cpnumber : this.dcData.cpNumber, "siteId":  this.dcForm.get('site_id').value ,'custNumber' : this.dcForm.get('custNumber').value,'partNumber': value.partNumber}, (response) => { 
      if (this.partsData[index]['type'] == 'OTL'){
        this.partsData[index]['groupedData']=  response.filter((part) =>( part['lotNumber'] == this.partsData[index]['lotNumber'] &&part['lotExpiryDate'] == this.partsData[index]['lotExpiryDate']&& part['unitPurchasePrice'] > 0 ))
      }else {
        this.partsData[index]['groupedData']=  response.filter((part) =>( part['lotNumber'] == this.partsData[index]['lotNumber']  &&part['lotExpiryDate'] == this.partsData[index]['lotExpiryDate']&&part['unitPurchasePrice'] == 0 ))
      } 
    })
    this.partsData[index]['reTrigger'] = true;
  }

   cancel(){
   this._secondarySalesService.navigateDCList();
    
   }
 
   updateDC(){ 
    let data = this.dcForm.getRawValue();
    data.custName = this.dcForm.get('custName').value.name;
   
    data.dispatchDocDate = data.dispatchDocDate ? this._momentService.getIsoFormat(data.dispatchDocDate): null;
    data.orderDate = data.orderDate ? this._momentService.getIsoFormat(data.orderDate): null;
    data.deliveryNoteDate = data.deliveryNoteDate ? this._momentService.getIsoFormat(data.deliveryNoteDate): null;
    data.dcDate = data.dcDate ? this._momentService.getIsoFormat(data.dcDate): null;
    data.dcIdentifier = this.dcData ? this.dcData['dcIdentifier'] : null;
    data.waybillDate = data.waybillDate ? this._momentService.getIsoFormat(data.waybillDate): null;
    data.supplierRefDate = data.supplierRefDate ? this._momentService.getIsoFormat(data.supplierRefDate) : null;
    this.shipDetails['contactPerson']=this.shipDetails['contactperson'] ? this.shipDetails['contactperson'] :this.shipDetails['contactPerson']
    this.billingDetails['contactPerson'] =this.billingDetails['contactperson'] ?this.billingDetails['contactperson'] :this.billingDetails['contactPerson'];
    delete this.shipDetails['contactperson'];
    delete this.billingDetails['contactperson'];
     // to append the id and invoice id in each ship ,bill and channel partner address
     this.shipDetails['id'] = this.ship_to_id;
     this.billingDetails['id'] = this.bill_to_id;
     this.shipDetails['dcId'] = this.dc_address_id;
     this.billingDetails['dcId'] = this.dc_address_id
     this.cpAddress['cpSiteAddress']['id'] = this.dcData['cpSiteAddress']['id'];
     
    data['shipping_address'] =Object.assign({}, this.shipDetails) ;
    data['shipping_address']['type'] = 'shipping'
    data['billing_address'] = Object.assign({}, this.billingDetails)  ;
    data['billing_address']['type'] = 'billing'
    data['net_amount'] = this.RoundOFTwoDigit(Number(this.netAmount));
    data['total_amount'] = this.RoundOFTwoDigit(Number(((data['net_amount'] ))));
    data['gstNumber'] =this.dcForm.get('gst').value;
    data['panNumber'] =this.dcForm.get('pan').value;
    data['cpSiteAddress'] = this.cpAddress['cpSiteAddress']
    data['cpSiteId']= this.cpAddress['cpSiteId']
    data['cpNumber'] = this.dcData.cpNumber,
    data['dcNumber'] = this.dcData.dcNumber;
    data['siteId'] = data.site_id
    data['id'] = this.dcData.id
    data['is_for_cprt'] = this.is_for_cprt;
    data['dcstatus'] = this.dcData.status;
    data.parts = this.partsData.filter(part => 
       part['reTrigger'] || typeof part['edited_quantity'] == 'undefined' && !part['part'] && part['quantity'] > 0 ? part['quantity'] > 0 : (part['edited_quantity']>=0 && part['groupedData']) 
       )
     // for retrigger options
     if (data.parts.length){
      let retriggerParts = data.parts.map(part =>{
        part.dcIdentifier = this.dcData['dcIdentifier']
         if (part['reTrigger'] && typeof part['edited_quantity'] == 'undefined') part['edited_quantity'] = part['quantity']
         return part;
      });
      data.parts = retriggerParts;
      } 
    this._secondarySalesService.editDeliveryChallan(this.dcId, data);

   }
   onChange(event:any){
     this.is_for_cprt = event.checked;
   }

}

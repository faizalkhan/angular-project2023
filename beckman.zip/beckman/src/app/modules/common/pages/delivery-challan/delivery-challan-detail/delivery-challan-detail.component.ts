import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import {  SHIPPING, dcType, ActionItems } from 'src/app/core/services/constants';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { environment } from 'src/environments/environment';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { Roles } from 'src/app/modules/auth/model/user';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { MatDialog } from '@angular/material';
import { EditStatus } from '../../../dialogs/secondary-dialog/dialog.component';

@Component({
  selector: 'app-delivery-challan-detail',
  templateUrl: './delivery-challan-detail.component.html',
  styleUrls: ['./delivery-challan-detail.component.css']
})
export class DeliveryChallanDetailComponent implements OnInit {
  
  public dcId; 
  public dcData;
  public billingAddress;
  public shippingAddress;
  public role;
  public serverUrl = environment.apiUrl;
  public dcStatus;
  public isAdmin =false;
  public moduleName;
  public editDcPermission = false;
  public editDc = false;
  public isupdateStatus: boolean= false;
  public dc_update_status : any;
  public dc_update_status_id:any;
  constructor(private route: ActivatedRoute,private _UtilsService : UtilsService, 
     private _secondarySalesService: SecondarysalesService,public _CpbookingService: CpbookingService, public status_dialog: MatDialog,
     private _storageService: StorageService) { }

  ngOnInit() {
    this.moduleName = this._UtilsService.moduleName();
    this.isAdmin = this._storageService.getUserDetails().role == Roles.Admin;

    this.route.paramMap.subscribe((params: ParamMap) => {
      this.dcId = parseInt(params.get('id'));
    });
       // get roles 
       this.role = this._storageService.getUserDetails()['role'];
    this._secondarySalesService.viewDeliveryChallan(this.dcId,
      (response) => {
        this.dcData = response;
        this.dcStatus = dcType[response.status]
        this.billingAddress = response.address.find(address => address.type !== SHIPPING );
        this.shippingAddress = response.address.find(address => address.type === SHIPPING );
        if (this._storageService.getUserDetails().role !=Roles.Channel_Partner){
          this.editDc  = true;
        }else{
          this.checkSecondaryLockAccess()
        }
      },
      (error) => console.log(error))
      this._CpbookingService.getActionPermission({model : 'deliverychallan'},response =>{ 
        this.editDcPermission = response['deliverychallan'] && typeof response['deliverychallan'][ActionItems['EDIT']] != 'undefined' ? true : false;
     })   
  }
  checkSecondaryLockAccess(){
    this._secondarySalesService.cpModuleAccess(res => {
      if (res['secondaryLock'] == 0 ) {
        this.editDc = true;
        this.checkAccessControl();
      }else{
        this.editDc= false
      }
    });
  }
  checkAccessControl(){
    this._CpbookingService.getPermissionAccessControls({module : 'DC_Edit'},response =>{
      this.editDc = response.parent_permission[0]['is_allowed'];
    })
  }
  moveDctoInvoice() {
    this._secondarySalesService.moveDctoInvoice({"dcNumber": this.dcData.dcNumber});
  }

  navigateEditDc(){
    this._secondarySalesService.navigateToEditDc(this.dcId);
   }
 navigate(){
   this._secondarySalesService.navigateDCList()
 }
  printInvoice() {
    window.print();
  }
  editStatus(index: any){
    let ids = [];
    let dialog = this.openStatus();
    dialog.afterClosed().subscribe(result=>{
      if(result){
        let data = this.dcData['parts'][index]['part'];
        data.forEach(item=>{
          ids.push(item.id);
        })
        let payload ={
          'ids':ids,
          'status_id':result['id']
        }
        this._secondarySalesService.getUpdateStatus(payload,response=>{
          this.isupdateStatus = true;
          this.dc_update_status_id = response['dc_status'];
          this.dc_update_status = dcType[response.dc_status];
        })
        this.dcData['parts'][index]['invoicedStatus'] = result['id'];
      }
    })
  }
openStatus(){
  const dialog_ref = this.status_dialog.open(EditStatus, {
    autoFocus: false,
    width: "400px",
    data: {'data':''}
  })
  return dialog_ref;
}

}


import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { routes } from 'src/app/app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { DeliveryChallanComponent } from './delivery-challan.component';



describe('DeliveryChallanComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes),
        AppMaterialModule,
        HttpClientModule,
      ],
     
      declarations: [
        DeliveryChallanComponent
      ],
    }).compileComponents();
   
  }));

  it('should create DC ', () => {
    const fixture = TestBed.createComponent(DeliveryChallanComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

});



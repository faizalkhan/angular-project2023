import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivery-challan',
  templateUrl: './delivery-challan.component.html',
  styleUrls: ['./delivery-challan.component.css']
})
export class DeliveryChallanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

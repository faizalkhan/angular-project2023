import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DeliveryChallanNewComponent } from './delivery-challan-new/delivery-challan-new.component';
import { Routes, RouterModule } from '@angular/router';
import { DeliveryChallanComponent } from './delivery-challan.component';
import { DeliveryChallanListComponent } from './delivery-challan-list/delivery-challan-list.component';
import { DeliveryChallanDetailComponent } from './delivery-challan-detail/delivery-challan-detail.component';
import { CommonDialogModule } from '../../dialogs/common-dialog.module';
import { AgGridModule } from 'ag-grid-angular';
import { DeliveryChallanEditComponent } from './delivery-challan-edit/delivery-challan-edit.component';
import { AddShippingDialog, ListShippingAddress, AddPartsDialog, AddStockSwapTransfer, BackTopartsDialog, EditStatus } from '../../dialogs/secondary-dialog/dialog.component';


const routes: Routes = [{ 
  path:'', 
  component:DeliveryChallanComponent,
  children:[{
    path: '', 
    component:DeliveryChallanListComponent
  },{
    path: 'add',
    component:DeliveryChallanNewComponent
  },{
    path: 'view/:id',
    component:DeliveryChallanDetailComponent
  },
  {
    path: 'edit/:id',
    component:DeliveryChallanEditComponent
  }
]
}]

@NgModule({
  declarations: [DeliveryChallanComponent,DeliveryChallanListComponent,DeliveryChallanNewComponent,DeliveryChallanDetailComponent, DeliveryChallanEditComponent
  ],
  entryComponents:[AddShippingDialog, ListShippingAddress, AddPartsDialog, AddStockSwapTransfer, BackTopartsDialog, EditStatus ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    AgGridModule.withComponents([]),
    CommonDialogModule,
  ],
  exports :[  AgGridModule,DeliveryChallanComponent,DeliveryChallanListComponent,DeliveryChallanNewComponent,DeliveryChallanDetailComponent,DeliveryChallanEditComponent],

})
export class DeliveryChallanModule { }

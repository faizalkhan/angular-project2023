import { Component, OnInit, HostListener } from '@angular/core';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { AgGridRouterComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-router.component';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { Roles } from 'src/app/modules/auth/model/user';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { dcType, ActionItems } from 'src/app/core/services/constants';
import { StockReportService } from '../../../service/stock-reports/stock-report.service';
import { IGetRowsParams } from 'ag-grid-community';

@Component({
  selector: 'app-delivery-challan-list',
  templateUrl: './delivery-challan-list.component.html',
  styleUrls: ['./delivery-challan-list.component.css']
})
export class DeliveryChallanListComponent implements OnInit {

  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public searchValue; 
  public custNameList = [];
  public dcSearchForm: FormGroup;
  public isSecondaryLock;
  public gridData = [];
  public editDC = false;
  public role ;
  //role matrix
  public editDCPermission = false;
  public moduleName;
  public dcPermission ;
  public partList=[];
  public otlList =[];
  public pageSize = 10;
  public isAdmin:boolean = false;
  public cpList = [];
  public isChannelPartner;
  public displayChannelPartnerKeys = ['name', 'cpnumber']
 public displayChannelPartnerKeys1 = ['name', 'custNumber'];
 public is_cprt_list = [];
  constructor(private _secondarySalesService: SecondarysalesService, private _StockReportService:StockReportService,
    private _UtilsService : UtilsService, private _StorageService: StorageService, 
    private _momentService: MomentService,private _bookingService: CpbookingService,
    private fb: FormBuilder, private _formValidator: FormValidatorService) { }
  @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
  }
  ngOnInit() {
    this.checkEditAccessControl();
    this.moduleName = this._UtilsService.moduleName();
    this.role = this._StorageService.getUserDetails().role;
    this.isAdmin = this.role == Roles.Admin ;
    this.isChannelPartner = this._UtilsService.isCpRole(this.role);
    this.loadDcPermission()

    if (this.role == Roles.Channel_Partner) {
      this._secondarySalesService.cpModuleAccess(res => {
        this.isSecondaryLock = res['secondaryLock'] == 1 ? true : false 
        });
    }

    this.loadDcFilterForm();
    this.setClientList ();
    this.setOtlList();
    this.setPartsList(); 
    this.setCPList();
    this.setCPRT();
    this.defaultColDef = {
      sortable: true,
      filter: true,
      resizable: true
    };

    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2
    };

    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.gridOptions.onFilterChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: 'id',
        headerName: 'S No.',
        width: 100,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
      },
      {
        headerName: 'DC No.',
        field: 'dcNumber',
        width: 190,
        cellRendererFramework: AgGridRouterComponent,
        cellRendererParams: {
          inRouterLink:  '/'+this.moduleName+'/secondary-sales/delivery-challan/view' ,
          navigateId: ''
        },
      },
      {
        headerName: 'DC Date',
        field: 'created_on',
        valueFormatter : this.formatDate.bind(this),
        width: 150,
      },
      {
        headerName: 'Client Name',
        field: 'custName',
        width: 200,
      },
      {
        headerName: 'Order No.',
        field: 'orderNumber',
        width: 200,
      },
      {
        headerName: 'Reference No.',
        field: 'referenceNumber',
        width: 200,
      },
      {
        headerName:'Type',
        field:'is_for_cprt',
        valueFormatter:this.formatCPRT.bind(this),
        width:150
      },
      {
        headerName: 'Status',
        field: 'status',
        width: 200,
        cellRenderer :(params) =>{
          let color = params.value == 0 ? 'text-danger' : (params.value == 2 ? 'text-success' : (params.value == 3 ? 'text-info' : 'text-warning') )
          return "<div class = "+color+">" +params.value ?  dcType[params.value] : ''+ "</div>" 
        }
      },

      {
        headerName: 'Net Amount',
        field: 'net_amount',
        width: 200,
      comparator: (param1, param2) => {
          return this._UtilsService.numberSorting(param1,param2);
        },
        cellRenderer :(params) =>{
          return  typeof params.value!=='undefined'?"<div class = 'text-right'>" + this._UtilsService.rupeeFormat(this.RoundOFTwoDigit(params.value)) + "</div>" :'';
        }
      },
      {
        field: 'isEditable',
        headerName: 'Action',
        sortable: false,
        filter: false,
        width: 100,
        cellRendererFramework: AgGridMenuComponent,
        cellRendererParams:   (params) => {
          let menu=[
            {
              name: 'View',
              link: '/'+this.moduleName+'/secondary-sales/delivery-challan/view',
            }]
            if ((this.editDCPermission && this.role != Roles.Channel_Partner)||(this.role == Roles.Channel_Partner && this.editDCPermission  && ! this.isSecondaryLock && params.value  && this.editDC)) {
              menu.push ({
                    name: 'Edit',
                    link: '/'+this.moduleName+'/secondary-sales/delivery-challan/edit',
                  }
              )
             }
          return {  
            menu
          }
      }
      }
    ];
  }
  setActionsPermission(name){
    return this.dcPermission && typeof this.dcPermission[ActionItems[name]] != 'undefined'  ?  true : false;
  }
  setOtlList(){
    this._bookingService.getListofOTLParts(res =>{
      this.otlList =  this._UtilsService.groupByMultipleKeys(res,['name','OTLnumber'])
    })
  }
  setPartsList(){
    // need to change api  
    this._StockReportService.getListParts(this.role,(res) => {
      this.partList = res  
    });
  }
  setCPList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpList = this._UtilsService.groupByMultipleKeys(res,['name','cpnumber'])   
    })
  }
  loadDcPermission(){
      this._bookingService.getActionPermission({model : 'deliverychallan'}, response =>{        
        this.dcPermission= response['deliverychallan'];
        this.editDCPermission = this.setActionsPermission('EDIT')
      });
  }

 
  checkEditAccessControl(){
    this._bookingService.getPermissionAccessControls({module : 'DC_Edit' },response =>{      
    this.editDC = response.parent_permission[0].is_allowed;
    })
  }
  formatDate(params){
    return params.data?this._momentService.getDateTimeFormat(params.data.created_on):'';
  }
  formatCPRT(params){
    return params.data ? (params.data['is_for_cprt'] == true ? 'CPRT DC' :'DC'):'';
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.getDeliveryChallans();
  }
  getDCList(data?: any){
    let payload = {};
    var datasource = {
      getRows: (params: IGetRowsParams) =>{
        if (data) {
          payload = data;
        }
        payload['page_size'] =this.pageSize
        payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
        payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
        payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
          this._secondarySalesService.DClist(data,(res)=>{
            let length = res['total'];
            this.gridData = res['results'];
            params.successCallback(res['results'], length)
          })
      }
    }
      this.gridApi.setDatasource(datasource);
  }

  getDeliveryChallans() {
    let data = {
      from_date : this._momentService.getFilterFormat(this.dcSearchForm.get('from_date').value),
      to_date : this._momentService.getFilterFormat(this.dcSearchForm.get('to_date').value, "toDate"),
    }
    return this.getDCList(data);

    // this._secondarySalesService.listDeliveryChallan(data, (res) => {
    //   this.gridApi.setRowData(res);
    //   this.gridData = res;
    //   this.gridApi.paginationGoToFirstPage();
    // },
    //   (error) => {
    //     this.gridApi.setRowData([])
    //   }
    // ); 

  }
  

  quickSearch() {
    this.gridApi.setQuickFilter(this.searchValue);
  }
  setClientList(){
    this._bookingService.listHospital( res =>{
      this.custNameList =this._UtilsService.groupByMultipleKeys(res,['name','custNumber'])
    })
  }

  loadDcFilterForm() {
    this.dcSearchForm = this.fb.group({
      from_date:[this._momentService.deceedDate(new Date(),31)],
      to_date:[new Date()],
      dcNumber: [''],
      custNumber: ['',this._formValidator.requireMatch],
      orderNumber: [''],
      status:[null],
      OTLNumber:  ['',this._formValidator.requireMatch],
      partNumber :  ['',this._formValidator.requireMatch],
      cpNumber : ['', this._formValidator.requireMatch],
      is_cprt:['', this._formValidator.requireMatch]
    },{ validator: this._formValidator.dateValidation('from_date', 'to_date') });
  }

  searchDcFilter() {
  if (this.dcSearchForm.valid){
    let dcFilterValues = this.getDcPayload(this.dcSearchForm.value);
    return this.getDCList(dcFilterValues);
    // this._secondarySalesService.listDeliveryChallan(dcFilterValues, (res) => {
    //   this.gridApi.setRowData(res);
    //   this.gridData = res;
    //   this.gridApi.paginationGoToFirstPage();
    // },
    //   (error) => {
    //     this.gridApi.setRowData([])
    //   }
    // ); 
  }
  }

  getDcPayload(dcFilterValues) {
    let data = {};
    data['from_date'] = dcFilterValues.from_date ? this._momentService.getFilterFormat(dcFilterValues.from_date) : '';
    data['to_date'] = dcFilterValues.to_date ? this._momentService.getFilterFormat(dcFilterValues.to_date, "toDate") : '';
    data['dcNumber'] = dcFilterValues.dcNumber ? dcFilterValues.dcNumber : '';
    data['custNumber'] = dcFilterValues.custNumber ? dcFilterValues.custNumber.custNumber : '';
    data['orderNumber'] = dcFilterValues.orderNumber ? dcFilterValues.orderNumber : '';
    data['status'] = dcFilterValues.status ? dcFilterValues.status : '';
    data['partNumber'] =dcFilterValues.partNumber ? dcFilterValues.partNumber.partNumber : '';
    data['OTLNumber'] = dcFilterValues.OTLNumber ? dcFilterValues.OTLNumber.OTLnumber : '';
    data['cpNumber'] = dcFilterValues.cpNumber ? dcFilterValues.cpNumber.cpnumber : '';
    data['is_for_cprt'] =dcFilterValues.is_cprt ? dcFilterValues.is_cprt.value:'';

    return data;
  }

  exportDC() {
    let dcFilterValues = this.getDcPayload(this.dcSearchForm.value);
    // dcFilterValues['from_date'] = dcFilterValues['from_date'] ?  dcFilterValues['from_date'] : this._momentService.getFilterFormat(this._momentService.deceedDate(new Date(),90));
    // dcFilterValues['to_date'] =  dcFilterValues['to_date'] ?  dcFilterValues['to_date'] : this._momentService.getFilterFormat(new Date(),"toDate");
    this._secondarySalesService.exportDCFilter(dcFilterValues);
  }

  cancelFilter(){
 
    this.dcSearchForm.reset();
    this.dcSearchForm.get('from_date').setValue(this._momentService.deceedDate(new Date(),31));
    this.dcSearchForm.get('to_date').setValue(new Date())
    this.dcSearchForm.get('status').setValue(null)

    this.getDeliveryChallans();
  }
  RoundOFTwoDigit(num: any){
    var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
    return number;
  }
  setCPRT(){
    this._secondarySalesService.getIsCPRT(response=>{
      this.is_cprt_list = response;
    })
  }
}

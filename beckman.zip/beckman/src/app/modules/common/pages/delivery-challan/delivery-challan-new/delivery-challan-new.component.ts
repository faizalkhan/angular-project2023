import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog'

import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { BECKMAN_GODOWN, SHIPPING, BILL_TO, SHIP_TO, ErrorMessage, colorCodes, ActionItems } from 'src/app/core/services/constants';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { ParamMap, ActivatedRoute } from '@angular/router';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { LocationService } from 'src/app/core/services/utils/location.service';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import {AddShippingDialog, ListShippingAddress, AddPartsDialog, AddStockSwapTransfer, BackTopartsDialog  } from 'src/app/modules/common/dialogs/secondary-dialog/dialog.component';

import { Roles } from 'src/app/modules/auth/model/user';

@Component({
  selector: 'app-delivery-challan-new',
  templateUrl: './delivery-challan-new.component.html',
  styleUrls: ['./delivery-challan-new.component.css']
})
export class DeliveryChallanNewComponent implements OnInit {
  public currentDate = new Date();
  public displayClientKeys = ['name','address','city','pincode']
  public setCurrentDate = new Date();
  public dcForm: FormGroup;
  public dcId;
  public clientNames = [];
  public otlList = [];
  public clientNumber;
  public otlPartsList = []; 
  public partsData = [];
  public shipDetails; // current shipping address
  public billingDetails;
  public netAmount = 0;
  public iGst:boolean;
  public  dcData;
  public partsCurrentOptions = [];
  public viewDC  =false;
  public cpAccountDetails ;
  public  regionFromService=[];
  public cpSiteIdList = [];
  public cpAddress ;
  public TransferValue: any;
  public login_cpNumber: any;
  public isChecked : boolean = false;
  public is_for_cprt: boolean = false;
  constructor(private fb: FormBuilder,private _PromptService: PromptService, public _dialog: MatDialog, public _swapdialog: MatDialog, 
    public _backTopartsDialog: MatDialog, private _locationService: LocationService,private _momentService: MomentService,private _storageService: StorageService,
    public route: ActivatedRoute, private _StorageService: StorageService,private _bookingService: CpbookingService,private _snackBar :SnackbarService, private _secondarySalesService: SecondarysalesService, private _formValidator: FormValidatorService) { }

  ngOnInit() {
    this.loadDcForm();
    this._bookingService.getActionPermission({model : 'deliverychallan'}, response =>{
      if (!response['deliverychallan'] || !response['deliverychallan'][ActionItems['ADD']])this.cancel();
    })
    if (this._StorageService.getUserDetails().role == Roles.Channel_Partner) {
      this._secondarySalesService.cpModuleAccess(res => {
        this.login_cpNumber = res['cpnumber'];
          if (res['secondaryLock'] == 1 ) this._secondarySalesService.navigateDCList();
      });
     }
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.dcId = parseInt(params.get('id'));
      if (this.dcId){
        this.setDcForm();
      }
    });


    this._bookingService.getDistinctHospitals({order_by:"name", model : "secondary"},(response => {
      this.clientNames = response
    }));
    this._secondarySalesService.getPrintDCConfiguration(res=>{
      this.cpAccountDetails = res;
      this.cpAccountDetails['gst'] = this._storageService.getUserDetails().license_details[0]['gst']
      this.cpAccountDetails['pan'] = this._storageService.getUserDetails().license_details[0]['pan']
      this.cpAccountDetails['state'] = this._storageService.getUserDetails().license_details[0]['state']
    }, 'isChallan');
    this._locationService.getLocationData((locationData) => {
      this.regionFromService = locationData
    });

   
  
  }

  loadDcForm() {
    this.dcForm = this.fb.group({
      custName: ['', [Validators.required, this._formValidator.requireMatch]],
      custNumber: ['', Validators.required],
      orderNumber: [''],
      orderDate: [''],
      site_id: ['', Validators.required],
      dispatchThrough: [''],
      dispatchDocNo: [''],
      dispatchDocDate: [''],
      referenceNumber: [''],
      destination: [''],
      bankDetails: [''],
      packageAmount: ['0'],
      discount_type: ['2'],
      discount_value: [''],
      waybillNumber: [''],
      waybillDate: [''],
      dcDate : [new Date(), Validators.required],
      supplierRef :[''],
      supplierRefDate:['', Validators.required],
      remarks:[''],
      otherRef:[''],
    });
  }

    
  getChannelPartnerSiteAddress(value){
    this._secondarySalesService.getCpSiteAddress({'cust_number' :value.custNumber },response => {
      this.cpAddress = response[0];
      this.cpSiteIdList = response;
    })
  }

  
  onClientChange(value, otlNo?: any, partsData?: any) {
    this.otlList = [];
    this.partsData = this.dcId ? this.partsData : [];
    this.dcForm.patchValue({
      
      site_id: '',
      custNumber: ' '
    })
    if (value) { 
      // if (!value.type && this.dcId){
      //   value.dcId =  this.billingDetails.dcId
      // }
      

      this._bookingService.getShippingAddress({ "custNumber":value.custNumber, "site_id":value.site_id, "model" :"secondary" }, (res) => {
        this.billingDetails = res[0]['edit_bill_to'];
        this.shipDetails = res[0]['edit_ship_to'];
        this.dcForm.get('custNumber').setValue(value.custNumber);
        this.dcForm.get('site_id').setValue(value.site_id);
        this.getChannelPartnerSiteAddress(value);
   
    
      });






      this._bookingService.getOtlBySiteId({ "custNumber":value.custNumber,"order_by":"otl_number" }, (response) => {
        this.otlList = response;
        if (!response.length)  this._snackBar.loadSnackBar(ErrorMessage.NO_OTLNUMBER_STOCK, colorCodes.ERROR);
        if (this.dcId) {
          this.otlList.filter((res) => {
            if (res.OTLnumber === otlNo) {
              this.partsData = partsData;
              this.loadPartsTable(partsData);
            }
          })
        }
      });
    }
  }
// list  channel partner address

lisChannelPartnertAddress(){
  const dialogRef = this._dialog.open(ListShippingAddress, {
    width: '500px',
    data: {details: this.cpSiteIdList, currentAddressDetails:  this.cpAddress , type : 'Channel_Partner'}
  });
  dialogRef.afterClosed().subscribe(result => {
    if (result ) this.cpAddress = result
  });
}
// start-  addresss methods 


  listAddress(addressType) {
    let addressList = [];
    this._secondarySalesService.getAddressList({custNumber : this.dcForm.get('custNumber').value} , response =>{
      if (response.length) {
      response.map(data => {
          if (data.type == addressType || data.type == "both"){
            // adding hospital address id to each address obj 
            data['address']['addressId']  = data.id;
            addressList.push( data['address']);
          }
        });
      }
      this.openAddressListDialog(addressType,addressList.length ? addressList : (addressType == BILL_TO ? [this.billingDetails] : [this.shipDetails]))
    })
  }
openAddressListDialog(type,addressList){ 
  const dialogRef = this._dialog.open(ListShippingAddress, {
    width: '500px',
    data: {details: addressList, currentAddressDetails:  (type == BILL_TO ? this.billingDetails : this.shipDetails) }
  });
  dialogRef.afterClosed().subscribe(result => {
    if (result && !result['edited']) {
        result['address'] = result['addressLine']
        this.billingDetails = (type == BILL_TO) ? result : this.billingDetails;
        this.shipDetails = (type == SHIP_TO) ? result : this.shipDetails;
    }else{
      if (result) this.editAddress(result ,type);
    }
  });
}



editAddress(data, type){
  let addressDetails ;
  if (data['addressId']){
    this._secondarySalesService.getAddressDetails(data['addressId'], response =>{
      addressDetails = response['address'];
      addressDetails['addressId'] = response['id'];
      addressDetails['type'] =type;
      this.addAddress(addressDetails)
    })
  }else{
    addressDetails =  type == BILL_TO ? this.billingDetails : this.shipDetails
    addressDetails['type'] =type;
    this.addAddress(addressDetails)
  }
}
addAddress(addressDetails ? :any) {
  const dialogRef = this._dialog.open(AddShippingDialog, {
    width: '500px',
    data: {custNumber: this.dcForm.get('custNumber').value, regionFromService : this.regionFromService , address : addressDetails}

  });
  dialogRef.afterClosed().subscribe(result => {
    if (result) {
       this.shipDetails = (result.type == 'both' || result.type == SHIP_TO) ? result['address'] : this.shipDetails;
        this.billingDetails = (result.type == 'both' || result.type == BILL_TO) ? result['address'] : this.billingDetails;      
    }
  });
}

// end -  addresss methods 
 
  loadParts() {
    let dialogRef = this.openParts(this.partsData);
    dialogRef.afterClosed().subscribe(result => {
      if(result && result['isswap']){
        this.TransferValue ={
          clientName: this.dcForm.get('custName').value,
          clientNumber: this.dcForm.get('custNumber').value,
          siteId: this.dcForm.get('site_id').value,
          otlNumber: result.data['OTLNumber'],
          partNumber: result.data['partsList']
        }
        this.loadSwapTransfer(this.TransferValue);
    }
      else{
      if (result && Object.keys(result).length > 0) {
        if (result['groupByParts']){
          result['groupByParts'].forEach((part)=>{
            this.getPartsData(part);
          })
        }
      }
    }
    });
  }
  getPartsData(result){
    if(result.quantity) {
      let index = this.partsData.findIndex(part => part['OTLNumber'] === result['OTLNumber'] && part['partNumber'] === result['partNumber']&& part['lotNumber']=== result['lotNumber'] );
      if(index >= 0 &&  this.partsData.length) this.partsData[index] = result;
      else this.partsData.push(result);
    }
    this.loadPartsTable(result);
  }

  loadPartsTable(result) {
    if (result && this.partsData) {
      this.netAmount= this.partsData.reduce((currentAmount, part)=>{
        return this.RoundOFTwoDigit(Number((currentAmount+ part['total_amount'])))
      },0)
    }
  }

  openParts(data, parts?: any) {
    const dialogRef = this._dialog.open(AddPartsDialog, {
      autoFocus: false,
      width: '750px',
      data: { "partsOutput": {},'otlList' : this.otlList, "currentPartsData": data, "editParts": parts ? parts : '',
       "iGst" : this.iGst,  "editForm" : this.dcId, "site_id":this.dcForm.get('site_id').value,"isADD":true, "LogincpNumber":this.login_cpNumber  }
    });
    return dialogRef;
  }
  openSwapParts(transferData: any){
    const swap_dialogRef = this._swapdialog.open(AddStockSwapTransfer,{
      autoFocus: false,
      width: '80%',
      disableClose: true,
      data: {"partsOutput":{}, "swapData": transferData, "isDcScreen": true}
    });
    return swap_dialogRef;
   }
   backToOpenParts(partsdetail: any, data:any, parts?: any){
    const parts_dialog = this._backTopartsDialog.open(BackTopartsDialog, {
      autoFocus: false,
      width: "750px",
      disableClose: true,
      data: { "partsOutput": {},"partsData": partsdetail, "currentPartsData": data, "editParts": parts ? parts : '',"iGst" : this.iGst,  "editForm" : this.dcId, 
      "isADD":true, "LogincpNumber":this.login_cpNumber }
    });
  return parts_dialog;
 }
  loadSwapTransfer(transferValue: any){
    let swap_dialogRefe = this.openSwapParts(transferValue);
    swap_dialogRefe.afterClosed().subscribe(result =>{
   
      if(result['iscancel'] =='cancel'){
        this.loadBackToParts(result['datavalue']['swapData']);
      }else{
        if(result['isSwap'] == 'swap'){
        this.loadBackToParts(result['datavalue']['swapData']);
        }
      }

    })
  }
  loadBackToParts(data?: any){
    let back_to_Dialog = this.backToOpenParts(data, this.partsData);
    back_to_Dialog.afterClosed().subscribe(result =>{
      if(result && result['isswap']){
        this.TransferValue ={
          clientName: this.dcForm.get('custName').value,
          clientNumber: this.dcForm.get('custNumber').value,
          siteId: this.dcForm.get('site_id').value,
          otlNumber: result.data['OTLNumber'],
          partNumber: result.data['partsList']
        }
        this.loadSwapTransfer(this.TransferValue);
    }
      else{
        if (result && Object.keys(result).length > 0) {
          if (result['groupByParts']){
            result['groupByParts'].forEach((part)=>{
              this.getPartsData(part);
            })
          }
        }
    }
    })
 }


  deleteParts(index) {
    if (this.dcId) {
      this._PromptService.openDialog({title : 'Delete Part',btnLabel : 'CONFIRM'}, response =>{
        if (response){
          this.deletePartService(index)
        }
      })
    } else {
      this.partsData.splice(index, 1);
    }
    this.checkPartsDataCount();
  }
  deletePartService(index){
    this._secondarySalesService.deleteDcParts(this.partsData[index]['id'], (res) => {
      this.partsData.splice(index, 1);
      this.checkPartsDataCount();
    })
  }
  checkPartsDataCount() {
    if (this.partsData.length > 0) this.loadPartsTable(this.partsData);
    else {
      this.netAmount = 0;
    }
  }
 

  loadPartsTableForm(result, index) {
    for (let part = 0; part < this.partsData.length; part++) {
      if (part == index) {
        this.partsData[part] = result;
      }
    }
    this.loadPartsTable(result)
  }

  createDc() {
    let data = this.dcForm.value;
    data.custName = this.dcForm.get('custName').value.name;
    data.OTLNumber = ''
    data.siteId = data.site_id;
    delete data['site_id'];
    data.dispatchDocDate = data.dispatchDocDate ? this._momentService.getIsoFormat(data.dispatchDocDate): null;
    data.waybillDate = data.waybillDate ? this._momentService.getIsoFormat(data.waybillDate): null;
    data.orderDate = data.orderDate ? this._momentService.getIsoFormat(data.orderDate): null;
    data.deliveryNoteDate = data.deliveryNoteDate ? this._momentService.getIsoFormat(data.deliveryNoteDate): null;
    data.dcDate = data.dcDate ? this._momentService.getIsoFormat(data.dcDate): null;
    data.supplierRefDate = data.supplierRefDate ? this._momentService.getIsoFormat(data.supplierRefDate) : null;
     this.shipDetails['contactPerson']=this.shipDetails['contactperson'] ? this.shipDetails['contactperson'] :this.shipDetails['contactPerson']
    this.billingDetails['contactPerson'] =this.billingDetails['contactperson'] ?this.billingDetails['contactperson'] :this.billingDetails['contactPerson'];
    delete this.shipDetails['contactperson'];
    delete this.billingDetails['contactperson'];
    data['shipping_address'] =Object.assign({}, this.shipDetails) ;
    data['shipping_address']['type'] = 'shipping'
    data['billing_address'] = Object.assign({}, this.billingDetails)  ;
    data['billing_address']['type'] = 'billing'

   data['net_amount'] = this.RoundOFTwoDigit(Number(this.netAmount));
    data['total_amount'] = this.RoundOFTwoDigit(Number((data['net_amount'])));
    data['gstNumber'] = this.cpAccountDetails.gst;
    data['panNumber'] = this.cpAccountDetails.pan;
    data['billing_address']['type'] = data['billing_address']['type'] ? data['billing_address']['type'] :  'billing'
    data['shipping_address']['type']  = 'shipping';
    data['packageAmount'] = data['packageAmount'] ? data['packageAmount'] : '0';
    data['discount_value'] = data['discount_value'] ? data['discount_value'] : '0';
    data['termsOfPayment'] = data['termsOfPayment'] ? data['termsOfPayment'] : '0';
    data['cpSiteAddress'] = this.cpAddress['cpSiteAddress']
    data['cpSiteId']= this.cpAddress['cpSiteId']
    data['is_for_cprt'] = this.is_for_cprt;
  
      data.parts = this.partsData;
      this._secondarySalesService.addDeliveryChallan(data, (response) => {
        this._secondarySalesService.navigateDCList();
      });  

  }
  setDcForm(){
    this._secondarySalesService.viewDeliveryChallan(this.dcId,response=>{
      if (response) { 
        this.billingDetails = response.address.find(address => address.type !== SHIPPING);
        this.shipDetails = response.address.find(address => address.type === SHIPPING );
        
       let name =  this.getCustName(response.custName, response.OTLNumber , response.parts);
       this.partsData = response.parts;
       this.dcData = response;
        this.dcForm.patchValue({
            custName:name,
            custNumber:response.cpNumber ,
            orderNumber: response.orderNumber,
            orderDate: response.orderDate,
            deliveryNote:response.deliveryNote,
            despatchThrough: response.despatchThrough,
            despatchDocNo: response.despatchDocNo,
            despatchDate: response.despatchDate,
            referenceNumber: response.referenceNumber,
            destination: response.destination,
            paymentMode: response.paymentMode,
        });
      }
    },error=> console.log(error))
  }

  getCustName(custName, otlno, partsData) {
    let customerDetails;
    customerDetails = this.clientNames.filter((res) => {
      return res.name.toLowerCase() === custName.toLowerCase();
    });
    if (customerDetails.length> 0){
      customerDetails[0]['type'] = 'billing'
    }
    this.onClientChange(customerDetails ? customerDetails[0] : '', otlno, partsData);
    return customerDetails ? customerDetails[0] : '';
  }

  cancel(){
    this._secondarySalesService.navigateDCList();
  }
  
  reset(){
    if (this.dcId) this.setDcForm();
    else{
      this.partsData = [];
      this.dcForm.reset()
      this.shipDetails = ''; 
      this.billingDetails='';
      this.netAmount = 0;
      this.dcForm.get('dcDate').setValue(new Date())
    }
  }
  viewDCDetails(status){
    this.viewDC =  status
  }
  RoundOFTwoDigit(num: any){
    var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
    return number;
  }
  onChange(event: any){
    this.is_for_cprt = event.checked;
  }
}

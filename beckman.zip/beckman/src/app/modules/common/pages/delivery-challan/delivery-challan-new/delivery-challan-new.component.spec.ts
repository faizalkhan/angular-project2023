
import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { routes } from 'src/app/app-routing.module';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { HttpClientModule } from '@angular/common/http';
import { DeliveryChallanNewComponent } from './delivery-challan-new.component';



describe('DeliveryChallanNewComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes),
        AppMaterialModule,
        CustomFormsModule,
        HttpClientModule,
      ],
     
      declarations: [
        DeliveryChallanNewComponent
      ],
    }).compileComponents();
   
  }));

  it('should create DC new ', () => {
    const fixture = TestBed.createComponent(DeliveryChallanNewComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

});



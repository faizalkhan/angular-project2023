
import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { routes } from 'src/app/app-routing.module';

import { InvoiceComponent } from 'src/app/modules/common/pages/secondary-sales/invoice/invoice.component';



describe('InvoiceComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes)
      ],
     
      declarations: [
        InvoiceComponent
      ],
    }).compileComponents();
   
  }));

  it('should create the invoice in admin', () => {
    const fixture = TestBed.createComponent(InvoiceComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

});



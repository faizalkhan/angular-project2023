import { Component, OnInit, ViewEncapsulation, Inject } from '@angular/core';
import { ParamMap, ActivatedRoute } from '@angular/router';

import { FormGroup, FormBuilder } from '@angular/forms';
import { InvoiceService } from 'src/app/modules/beckman/service/invoice/invoice.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { BILLING, SHIPPING, invoiceStatus, BECKMAN_GODOWN, ErrorMessage, colorCodes, SuccessMessage, ActionItems } from 'src/app/core/services/constants';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import {AddBeckManInvoicePartsDialog } from '../../../dialogs/secondary-dialog/dialog.component';
import { IGetRowsParams } from 'ag-grid-community';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { InvoicesImportDialog } from '../returns/returns.component';


@Component({
  selector: 'app-invoice-integration.detail',
  templateUrl: './invoice-integration-detail.component.html',
  styleUrls: ['./invoice-integration-detail.component.css']
})
export class InvoiceIntegrationDetailComponent implements OnInit {
 


  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;


  public isResponseHitting = false;

  public invoicePermission;
  public gridData = [];
  public invoiceId;
  public data:any;
  public shippingAddress;
  public billingAddress;
  public totalTax = 0; 
  public invoiceStatus = ''; 
  public iGst:boolean;
  public isAcknowledged = true;
  public moduleName;
  public isChannelPartner = false;
  public isAdmin = false;
  public isUpdate:Boolean= false;
  public isEditShow: boolean = true;
  public filter_array:any;
  public isAdminEdit: boolean = false;
  public pageSize = 10;
  public deleteInvoices = false;
  constructor(public route: ActivatedRoute,private _invoiceService: InvoiceService, private _permissionMenuListService: PermissionMenuListService,
    public _dialog: MatDialog, private _UtilsService : UtilsService,private _StorageService : StorageService,private _snackBar: SnackbarService,
    public status_dialog: MatDialog) { }

  ngOnInit() {
    this.moduleName = this._UtilsService.moduleName();
    this.isChannelPartner = this._UtilsService.isCpRole(this._StorageService.getUserDetails().role);
    this.isAdmin = this._UtilsService.isAdminRole(this._StorageService.getUserDetails().role);
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.invoiceId = parseInt(params.get('id'));
    });

 




//Grid view


this.defaultColDef = {
  sortable: true,
  resizable: true
};    
this.gridOptions = {
  rowHeight: 45,
  paginationPageSize: 10,
  cacheBlockSize : 10,
  rowModelType :'infinite',
  cacheOverflowSize:100,
  maxConcurrentDatasourceRequests: 2,
  onPaginationChanged: (params) => {
    if (params.newPage) {
      let currentPage = params.api.paginationGetCurrentPage();    
      localStorage.setItem('currentPage', JSON.stringify(currentPage));
    }
  }
}; 
this.gridOptions.onSortChanged = event => {
  this.gridApi.redrawRows(); 
}
this.gridOptions.onFilterChanged = event => {
  this.gridApi.redrawRows(); 
}
this.columnDefs = [
  {
    field: 'id',
    headerName: 'S No.',
    width: 100,
    sortable: false,
    filter: false,
    valueGetter: "node.rowIndex + 1",
    suppressSizeToFit: true
  },     
  {
    headerName: 'FileName',
    field: 'file_name',
    width: 200

  },  
  {
    headerName: 'Integrated Date',
    field: 'processed_on_date',   
    width: 200,
    suppressSizeToFit: true
  },


    
  {
    headerName: 'Integrated Time',
    field: 'processed_on_time',
    width: 150,
    suppressSizeToFit: true
  
  },

  {
    headerName: 'Status',
    field: 'status',
    width: 200,
    valueFormatter: (params) =>{
      return this._UtilsService.invoiceStatus(params.value)
    },
    suppressSizeToFit: true

  },
  {
    field: 'status',
    headerName: 'Action',
    sortable: false, 
    filter: false,
    width: 100, 
    suppressSizeToFit: true,
    cellRendererFramework: AgGridMenuComponent,
    cellRendererParams:  (params) => {

      console.log("params", params);

      let menu = [];
    
   
      if (params.value == "Failed") {
        menu.push(
          {
            name: 'Download Uploaded File',
           
          },
          {
            name : 'Download Error Log File'
          },
          {
            name : 'Upload File',
            link : '',
            onMenuAction: this.uploadProgress.bind(this)
          }  
    
        
        )
      }
      if (params.value =="Success") {
        menu.push(
          {
            name: 'Download Uploaded File',
           
          } 
        
        )
      }
   
      return { 
        menu,
        navigateId: 'id'
      }
    }
    }
];


 }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.getInvoicesList();
  }


  getInvoicesList() { 
    let payload = {};    
    var datasource = {      
      getRows: (params: IGetRowsParams) =>{        
     
     
        payload['page_size'] =this.pageSize;
        payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
        payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
        payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
        this._invoiceService.detailInvoiceIntegration(this.invoiceId,payload, (res)=>{
          let length = res['total'];
           this.gridData  = res['results'];
           this.isResponseHitting = true;
          params.successCallback(res['results'], length)
          const pageToNavigate = JSON.parse(localStorage.getItem('currentPage'));
          this.gridApi.paginationGoToPage(pageToNavigate);
          })
      }
      
    }
     this.gridApi.setDatasource(datasource); 
      
  }

  importStock($event) {
    const formData = new FormData();
    formData.append('file', $event.target.files[0]);
    this._invoiceService.importStockCsv(formData);
  }

 
  exportInvoiceFilter(){
  
    // payload['from_date'] = payload['from_date'] ?  payload['from_date'] : this._momentService.getFilterFormat(this._momentService.deceedDate(new Date(),90))
    // payload['to_date'] =  payload['to_date'] ?  payload['to_date'] : this._momentService.getFilterFormat(new Date(),"toDate")

  }

  loadInvoicePermission(){
    this._permissionMenuListService.getActionPermission({model : 'revenue'}, response =>{
      this.invoicePermission= response['revenue'];
      this.deleteInvoices = this.setActionsPermission('DELETE')
      });
}

  setActionsPermission(name){
    return this.invoicePermission && typeof this.invoicePermission[ActionItems[name]] != 'undefined'  ?  true : false;
  }

  
  uploadProgress(){
    let ids = [];
    let dialog = this.uploadStatus();
    dialog.afterClosed().subscribe(result=>{
      if(result){
        // let data = this.dcData['parts'][index]['part'];
        // data.forEach(item=>{
        //   ids.push(item.id);
        // })
        // let payload ={
        //   'ids':ids,
        //   'status_id':result['id']
        // }
        // this._secondarySalesService.getUpdateStatus(payload,response=>{
        //   this.isupdateStatus = true;
        //   this.dc_update_status_id = response['dc_status'];
        //   this.dc_update_status = dcType[response.dc_status];
        // })
        // this.dcData['parts'][index]['invoicedStatus'] = result['id'];
      }
    })


    
  }


  uploadStatus(){
    const dialog_ref = this.status_dialog.open(InvoicesImportDialog, {
      autoFocus: false,
      width: "400px",
      data: {'data':''}
    })
    return dialog_ref;
  }



}





import { Component, OnInit, ViewEncapsulation, Inject, ViewChild } from '@angular/core';
import { InvoiceService } from '../../../../beckman/service/invoice/invoice.service';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { ActionItems, Endpoints } from 'src/app/core/services/constants';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { MatStepper } from '@angular/material/stepper';

@Component({
  selector: 'app-returns',
  templateUrl: './returns.component.html',
  styleUrls: ['./returns.component.css'],
  encapsulation:ViewEncapsulation.None
})
export class ReturnsComponent implements OnInit {

  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public searchValue;
  
  constructor(private _invoiceService: InvoiceService, public _dialog: MatDialog,private _momentService: MomentService) { }

  ngOnInit() {

    this.defaultColDef = {
      sortable: true,
      filter: true,
      resizable: true
    };

    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
    };

    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.gridOptions.onFilterChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: 'id',
        headerName: 'S No.',
        width:100,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
      },
      {
        headerName: 'Channel Partner Name',
        field: 'cpNumber'
      },
      {
        headerName: 'OPF Type',
        field: 'opfType'
      },
      {
        headerName: 'OPF Number',
        field: 'OPFNumber'
      },
      {
        headerName: 'OPF Date',
        field: 'opfDate',
        valueFormatter :  (params) => {
          return this._momentService.getDateTimeFormat(params.value)
        }
      },
      {
        headerName: 'Invoice number',
        field: 'invoiceNumber'
      },
      {
        headerName: 'Order Number',
        field: 'orderNumber'
      },
      {
        headerName: 'View Returns',
        sortable: false,
        filter: false,
        field: '',
        cellRendererFramework: AgGridMenuComponent,
        cellRendererParams: {
          menu: [ {
            name: "View",
            link: "",
            onMenuAction: this.viewReturnDetail.bind(this)
          }],
          
        },
      }
    ];

  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.getReturnsList();
  }
  
  getReturnsList() {

    this._invoiceService.listReturns((res) => {
      this.gridApi.setRowData(res);
    },
      (error) => {
        this.gridApi.setRowData([])
      }
    );
    
  }

  quickSearch() {
    this.gridApi.setQuickFilter(this.searchValue);
  }

  viewReturnDetail(id) {
   
    this._invoiceService.viewReturns(id, (res) => { 
      this._dialog.open(ViewReturnDialog, {
        width: '900px',
        data: res
      });

    });
  }
}

@Component({
  selector: 'view-return',
  templateUrl: 'viewreturn-dialog.html',
  styles: [`.mat-dialog-container{
    padding : 0 !important;
    overflow: hidden;
}
.mat-dialog-content{
  padding: 0px;
  margin:0px;
}
`],
  encapsulation: ViewEncapsulation.None
})

export class ViewReturnDialog implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<ViewReturnDialog>,
    @Inject(MAT_DIALOG_DATA) public data) { }

  ngOnInit() {
  }

  dialogClose(): void {
    this.dialogRef.close();
  }

}



@Component({
  selector: 'app-invoices-import',
  templateUrl: 'invoicesintegration-dialog.html',
  styles: [`.mat-dialog-container { padding:0px 0px; } .close-icon { color: #fff !important;  padding-top: 2px;   padding-right: 6px;} .dragDrop { border: 1px dashed #000000;   padding: 0;
    background: #e8e8e8;    margin-bottom: 50px;    border-radius: 5px;    position: relative;
  }.mat-step-header {    pointer-events: none !important;}.font-light{  font-weight: 100;  color: #929292;}
#fileDropRef {  position: absolute;  opacity: 0;  z-index: 5;  width: 100%;  height: 100%; }
.excelUploadBody {  text-align: center;  margin: 50px 0;  padding: 40px 10px 20px 10px; }
.progressContainer{  text-align: center;  padding: 40px 10px 20px 10px; }
.mat-step-header .mat-step-icon-selected {  background-color:  #E6313A;}
.mat-step-header .mat-step-icon-state-edit{  background-color:  #E6313A; }
.mat-progress-bar-fill::after {  background-color: #E6313A;}
.bg-light-grey{  color: #e8e8e8;  background-color:  #929292;  border-color:  #e8e8e8;}
  ` 
  ],
  encapsulation: ViewEncapsulation.None
})
export class InvoicesImportDialog implements OnInit { 
 
  constructor(public dialogRef: MatDialogRef<InvoicesImportDialog>,private _invoiceService: InvoiceService,private _UtilsService : UtilsService,private _permissionMenuListService: PermissionMenuListService, 
    @Inject(MAT_DIALOG_DATA) public data
    ) { }
  @ViewChild('stepper', { static: false })  private myStepper: MatStepper;
  public zeroIndex = 0;
  public progressCount = 100;
  public csvData;
  public selectedValue = ''; 
  public permission = false;
  public invoicePermission;
  ngOnInit() {
      this._permissionMenuListService.getActionPermission({model : 'revenue'},response =>{
      this.permission = response['revenue'] && typeof response['revenue'][ActionItems['IMPORT_BECKMAN_INVOICE']] != 'undefined'  ?  true : false; 
    });
  }

  onChange(){
    this.csvData = '';
  }

  importCSV(event) {
    this.csvData = event[this.zeroIndex];
    this.csvData['progress'] = this.zeroIndex;
    this.uploadProgressBar(this.zeroIndex, this.csvData);
  }

  uploadProgressBar(index, fileData) {
    setTimeout(() => {
      if (index == 1 &&  Object.keys(fileData).length > 0 ) {
        return;
      } else {
        const progressInterval = setInterval(() => {
          if (fileData.progress === this.progressCount) {
            clearInterval(progressInterval);
            this.uploadProgressBar(index + 1, fileData);
          } else {
            fileData.progress += 5;
          }
        }, 200);
      }
    }, 1000);
  }

 
 
  submit() {
      let endPoint = Endpoints.IMPORT_TAXILA_FILE;
      this._invoiceService.importCSV(endPoint,this.selectedValue, this.getFormData(this.csvData));
      this.getFormData(this.csvData).delete('file');
      this.csvData = '';
      this.selectedValue = '';
      this.dialogRef.close();
  }

  getFormData(fileData){
    const files = new FormData();
    files.append('file', fileData);
    files.append('taxilla_invoice_file_id', this.data.fileId);
    return files;
  }

  cancelInvoice() {
    this.csvData = '';
    this.selectedValue =''
    this.dialogRef.close();
  }

  exportFreezeTemplate(){
    this._invoiceService.exportFreezeDownloadTemplate();
  }
  exportFreezeInstructions(){
    this._invoiceService.exportFreezeTemplateInstructions();
  }

}

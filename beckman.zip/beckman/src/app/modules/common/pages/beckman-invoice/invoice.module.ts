import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InvoiceComponent } from './invoice.component';
import { InvoicesImportComponent } from './invoices-import/invoices-import.component';
import { InvoicesListComponent } from './invoices-list/invoices-list.component';
import { InvoicesDetailComponent } from './invoices-detail/invoices-detail.component';
import { Routes, RouterModule } from '@angular/router';
import { AgGridModule } from 'ag-grid-angular';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { DragAndDropDirective } from '../../../beckman/directive/dragAndDropDirective';
import { ReturnsComponent, ViewReturnDialog, InvoicesImportDialog} from './returns/returns.component';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { PipeModule } from 'src/app/core/pipe/pipe.module';
import { AddBeckManInvoicePartsDialog } from '../../dialogs/secondary-dialog/dialog.component';
import { InvoiceIntegrationComponent } from './invoice-Integration/invoice-integration.component';
import { InvoiceIntegrationDetailComponent } from './invoice-Integration-detail/invoice-integration-detail.component';


const routes: Routes = [{
  path:'', 
  component:InvoiceComponent,
  children:[{
    path: '',
    component:InvoicesListComponent
  },
  {
    path: 'invoiceIntegration',
    component:InvoiceIntegrationComponent
  },
  {
    path: 'detailview/:id',
    component:InvoiceIntegrationDetailComponent
  },
  {
    path: 'import',
    component:InvoicesImportComponent
  },
  {
    path:'view/:id',
    component:InvoicesDetailComponent
  },
  {
    path: 'returns',
    component: ReturnsComponent
  }
]
}]

@NgModule({
  declarations: [InvoiceComponent, InvoicesImportComponent, InvoiceIntegrationComponent, InvoiceIntegrationDetailComponent, InvoicesListComponent,AddBeckManInvoicePartsDialog, InvoicesDetailComponent,DragAndDropDirective,
     ReturnsComponent, ViewReturnDialog, InvoicesImportDialog ],
  entryComponents:[ViewReturnDialog,AddBeckManInvoicePartsDialog, InvoicesImportDialog ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    AgGridModule.withComponents([]),
    CustomFormsModule,
    AppMaterialModule,
    PipeModule
  ]
})
export class InvoiceModule { }

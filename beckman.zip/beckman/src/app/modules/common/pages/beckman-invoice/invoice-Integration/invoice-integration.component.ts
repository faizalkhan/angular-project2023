import { Component, OnInit, HostListener } from '@angular/core';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { AgGridRouterComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-router.component';
import { InvoiceService } from '../../../../beckman/service/invoice/invoice.service';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { invoiceType, ActionItems } from 'src/app/core/services/constants';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { Roles } from 'src/app/modules/auth/model/user';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { IGetRowsParams } from 'ag-grid-community';
import { StockReportService } from '../../../service/stock-reports/stock-report.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { InvoicesImportDialog } from '../returns/returns.component';
@Component({
  selector: 'app-invoice-integration',
  templateUrl: './invoice-integration.component.html',
  styleUrls: ['./invoice-integration.component.css']
})
export class InvoiceIntegrationComponent implements OnInit {
  
  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public searchValue; 
  public cpNameList = [];
  public invoiceSearchForm: FormGroup;
  public otlList =[];
  public gridData = [];
  clientNames=[];
  public moduleName;
  public isChannelPartner = false;
  public deleteInvoices = false;
  public invoicePermission;
  public pageSize = 10;
  public isResponseHitting = false;
  public partList=[];
  public role;
  public currentpage;
  public displayChannelPartnerKeys = ['name', 'cpnumber'];
  public displayChannelPartnerKeys1 = ['name', 'custNumber']
  constructor(private _bookingService: CpbookingService,private _promptService: PromptService,private _StorageService : StorageService,private _permissionMenuListService: PermissionMenuListService,private _StockReportService:StockReportService,
    private _invoiceService: InvoiceService, private _UtilsService : UtilsService, private _momentService: MomentService,private fb: FormBuilder,private _formValidator: FormValidatorService, public status_dialog: MatDialog) {}
  
  @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
  }
  ngOnInit() {

    this.role = this._StorageService.getUserDetails().role;
    this.loadInvoiceSearchForm();
    this.loadInvoicePermission();
    this.isChannelPartner = this._UtilsService.isCpRole(this._StorageService.getUserDetails().role);
    console.log(this.isChannelPartner);
    this.moduleName = this._UtilsService.moduleName();   
    this.setOtlList();
    this.setPartsList();  
    this.defaultColDef = {
      sortable: true,
      resizable: true
    };    
    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2,
      onPaginationChanged: (params) => {
        if (params.newPage) {
          let currentPage = params.api.paginationGetCurrentPage();    
          localStorage.setItem('currentPage', JSON.stringify(currentPage));
        }
      }
    }; 
    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.gridOptions.onFilterChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: 'id',
        headerName: 'S No.',
        width: 100,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
        suppressSizeToFit: true
      },     
      {
        headerName: 'FileName',
        field: 'file_name',
        width: 200
   
      },  
      {
        headerName: 'Integrated Date',
        field: 'processed_on_date',   
        width: 200,
        suppressSizeToFit: true
      },

    
        
      {
        headerName: 'Integrated Time',
        field: 'processed_on_time',
        width: 150,
        suppressSizeToFit: true
      
      },
   
      {
        headerName: 'Status',
        field: 'status',
        width: 200,
        valueFormatter: (params) =>{
          return this._UtilsService.invoiceStatus(params.value)
        },
        suppressSizeToFit: true
  
      },
      {
        field: 'status',
        headerName: 'Action',
        sortable: false, 
        filter: false,
        width: 100, 
        suppressSizeToFit: true,
        cellRendererFramework: AgGridMenuComponent,
        cellRendererParams:  (params) => {
          let menu = [];
          menu.push();
       

          if (params.value == "Failed") {
            menu.push(
              {
                name: 'View', 
               link: '/'+this.moduleName+'/invoices/detailview/',
              },
              {
                name: 'Download Oracle File',
                onMenuAction: this.downloadOriginalError.bind(this, params.data.id,params.data.file_name ,'download-original-file')//params.data.file_path
               
              },
              {
                name: 'Download Original Error Log File',
                link : '',
                onMenuAction: this.downloadOriginalError.bind(this,params.data.id,params.data.file_name+"_Error" ,'download-error-log')//params.data.error_log_path
              },
              {
                name : 'Upload File',
                link : '',
                onMenuAction: this.uploadProgress.bind(this, params.data.id)
              },
              {
                name : 'Update Status Manually',
                link : '',
                onMenuAction: this.updateStatusManually.bind(this, params.data.id)
              },
            
            )
          }


          
          if (params.value == "Success") {
            menu.push(
              {
                name: 'View', 
               link: '/'+this.moduleName+'/invoices/detailview/',
              },
              {
                name: 'Download Uploaded File',
                onMenuAction: this.downloadOriginalError.bind(this, params.data.id,params.data.file_name , 'download-original-file')//params.data.file_path
              }          
            )
          }

             return { 
            menu,
            navigateId: 'id'
          }
        }
        }

    ];
  
  }

loadInvoicePermission(){
    this._permissionMenuListService.getActionPermission({model : 'revenue'}, response =>{
      this.invoicePermission= response['revenue'];
      this.deleteInvoices = this.setActionsPermission('DELETE')
      });
}
RoundOFTwoDigit(num: any){
  var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
  return number;
}
setActionsPermission(name){
  return this.invoicePermission && typeof this.invoicePermission[ActionItems[name]] != 'undefined'  ?  true : false;
}

setPartsList(){
  // need to change api  
  this._StockReportService.getListParts(this.role,(res) => {
    this.partList = res  
  });
}

  setOtlList(){
    this._bookingService.getListofOTLParts(res =>{
      this.otlList =  this._UtilsService.groupByMultipleKeys(res,['name','OTLnumber'])
    })
  }
  setClientList(){
    this._bookingService.listHospital( res =>{
      this.clientNames =  this._UtilsService.groupByMultipleKeys(res,['name','custNumber'])
    })
  }

  deleteInvoice(id){
    this._promptService.openDialog({title : 'Delete Invoice: '+ id, btnLabel : 'CONFIRM', content: 'Are you sure you want to delete Invoice?'}, response =>{
      if (response){
        this._invoiceService.deleteInvoice(id,(res) =>{
          this.getInvoicesList(this.getPayload(this.invoiceSearchForm.value));
        });
      }
    })
  }

  frozenInvoice(id){
    this._promptService.openDialog({title : 'Freeze Invoice',btnLabel : 'CONFIRM',content :'Are you sure you want to freeze?'}, response =>{
      if (response){
       this._invoiceService.frozenInvoice(id, (res) =>  {
        this.getInvoicesList(this.getPayload(this.invoiceSearchForm.value));
       });
      }
    })
  }
  setCpList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpNameList = this._UtilsService.groupByMultipleKeys(res,['name','cpnumber'])
    })
  }
  formatDate(params){
    return params.data ? this._momentService.getDate(params.data.invoiceDate) : ''
  }
  formatTime(params)
  {
    return params.data ? this._momentService.convertHours(params.data.invoiceDate) : ''
  }

  formatDispatchDate(params){
    return params.data && params.data.despatchDate ? this._momentService.getDate(params.data.despatchDate) : ''
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.setInvoiceParams();
  }

  setInvoiceParams(){
    let data = {
      from_date : this._momentService.getFilterFormat(this.invoiceSearchForm.get('from_date').value),
      to_date : this._momentService.getFilterFormat(this.invoiceSearchForm.get('to_date').value, "toDate"),
      status : 'Failed'
    }
   return  this.getInvoicesList(data);
  }

   getInvoicesList(data?:any) { 
    let payload = {};    
    var datasource = {      
      getRows: (params: IGetRowsParams) =>{        
        if (data) {
          payload = data; 
        }
        payload['page_size'] =this.pageSize;
        payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
        payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
        payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
        this._invoiceService.searchInvoiceIntegration(payload, (res)=>{
          let length = res['total'];
           this.gridData  = res['results'];
           this.isResponseHitting = true;
          params.successCallback(res['results'], length)
          const pageToNavigate = JSON.parse(localStorage.getItem('currentPage'));
          this.gridApi.paginationGoToPage(pageToNavigate);
          })
      }
      
    }
     this.gridApi.setDatasource(datasource); 
      
  }
  loadInvoiceSearchForm(){
    this.invoiceSearchForm = this.fb.group({
      file_name :[''],
      from_date:[this._momentService.deceedDate(new Date(),31)],
      to_date:[new Date()],
      status:['Failed'],      
    },{ validator: this._formValidator.dateValidation('from_date', 'to_date') });
  }

  searchInvoiceFilter(){
   
  if (this.invoiceSearchForm.valid){
    let invoicePayload = this.getPayload(this.invoiceSearchForm.value)
    localStorage.setItem('currentPage', JSON.stringify(0));
    this.isResponseHitting = false;
    this.getInvoicesList(invoicePayload);
   }
  }
 
  getPayload(invoiceValue){
    let data =  {};

    data['from_date'] = invoiceValue.from_date ?  this._momentService.getFilterFormat(invoiceValue.from_date) : '';
    data['to_date'] = invoiceValue.to_date ? this._momentService.getFilterFormat(invoiceValue.to_date , "toDate" ) : '';
   
    data['file_name'] =invoiceValue.file_name ? invoiceValue.file_name : '';

    data['status'] =invoiceValue.status? invoiceValue.status : '';
    return data;
  }

  importStock($event) {
    const formData = new FormData();
    formData.append('file', $event.target.files[0]);
    this._invoiceService.importStockCsv(formData);
  }

  cancelFilter(){
    //this.setInvoiceParams();
    this.invoiceSearchForm.reset();
    //this.invoiceSearchForm.get('from_date').setValue(this._momentService.deceedDate(new Date(),31));
    //this.invoiceSearchForm.get('to_date').setValue(new Date())
    this.invoiceSearchForm.get('from_date').setValue('')
    this.invoiceSearchForm.get('to_date').setValue('')
    this.invoiceSearchForm.get('status').setValue('')
    this.invoiceSearchForm.get('file_name').setValue('')
    this.getInvoicesList(this.invoiceSearchForm.value);
      
  }
  exportInvoiceFilter(){
    let payload =  this.getPayload(this.invoiceSearchForm.value);
    // payload['from_date'] = payload['from_date'] ?  payload['from_date'] : this._momentService.getFilterFormat(this._momentService.deceedDate(new Date(),90))
    // payload['to_date'] =  payload['to_date'] ?  payload['to_date'] : this._momentService.getFilterFormat(new Date(),"toDate")
   this._invoiceService.exportInvoiceFilter(payload);
  }
  downloadOriginalError(path,filename,endpt)
  {
    this._invoiceService.downloadOriginalLogFiles('/taxilla-invoice-files/'+ path+'/'+endpt,filename);
  }


  uploadProgress(fileId:any){
    let dialog = this.uploadStatus(fileId);
    dialog.afterClosed().subscribe();

   }


  uploadStatus(fileId){
    const dialog_ref = this.status_dialog.open(InvoicesImportDialog, {
      autoFocus: false,
      width: "450px",
      data: {'fileId': fileId }
    })
    return dialog_ref;
  }


  updateStatusManually(fileId:any){
    
      let data = {};
      data['status'] = "Success";
    this._invoiceService.updateManuallyStatus(fileId, data, res=>{
      if(res)
      {
        this.setInvoiceParams();
      }
        
    })

   }


}

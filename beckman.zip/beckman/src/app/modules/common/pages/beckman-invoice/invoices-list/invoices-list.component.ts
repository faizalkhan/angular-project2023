import { Component, OnInit, HostListener } from '@angular/core';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { AgGridRouterComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-router.component';
import { InvoiceService } from '../../../../beckman/service/invoice/invoice.service';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { invoiceType, ActionItems } from 'src/app/core/services/constants';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { Roles } from 'src/app/modules/auth/model/user';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { IGetRowsParams } from 'ag-grid-community';
import { StockReportService } from '../../../service/stock-reports/stock-report.service';

@Component({
  selector: 'app-invoices-list',
  templateUrl: './invoices-list.component.html',
  styleUrls: ['./invoices-list.component.css']
})
export class InvoicesListComponent implements OnInit {
  
  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public searchValue; 
  public cpNameList = [];
  public invoiceSearchForm: FormGroup;
  public otlList =[];
  public gridData = [];
  clientNames=[];
  public moduleName;
  public isChannelPartner = false;
  public deleteInvoices = false;
  public invoicePermission;
  public pageSize = 10;
  public isResponseHitting = false;
  public partList=[];
  public role;
  public currentpage;
  public displayChannelPartnerKeys = ['name', 'cpnumber'];
  public displayChannelPartnerKeys1 = ['name', 'custNumber']
  constructor(private _bookingService: CpbookingService,private _promptService: PromptService,private _StorageService : StorageService,private _permissionMenuListService: PermissionMenuListService,private _StockReportService:StockReportService,
    private _invoiceService: InvoiceService, private _UtilsService : UtilsService, private _momentService: MomentService,private fb: FormBuilder,private _formValidator: FormValidatorService) {}
  
  @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
  }
  ngOnInit() {
    this.role = this._StorageService.getUserDetails().role;
    this.loadInvoiceSearchForm();
    this.loadInvoicePermission();
    this.isChannelPartner = this._UtilsService.isCpRole(this._StorageService.getUserDetails().role);
    console.log(this.isChannelPartner);
    this.moduleName = this._UtilsService.moduleName();   
    this.setOtlList();
    this.setPartsList();  
    this.setClientList();
    this.defaultColDef = {
      sortable: true,
      resizable: true
    };    
    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2,
      onPaginationChanged: (params) => {
        if (params.newPage) {
          let currentPage = params.api.paginationGetCurrentPage();    
          localStorage.setItem('currentPage', JSON.stringify(currentPage));
        }
      }
    }; 
    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.gridOptions.onFilterChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: 'id',
        headerName: 'S No.',
        width: 100,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
      },
      {
        headerName: 'Invoice Date',
        field: 'invoiceDate',
        valueFormatter : this.formatDate.bind(this),
        width: 250,
      },
      {
        headerName: 'Invoice Number',
        field: 'invoiceNumber',
        width: 250,
        cellRendererFramework: AgGridRouterComponent,
        cellRendererParams: {
          inRouterLink: '/'+this.moduleName+'/invoices/view/',
          navigateId: 'invoiceNumber'
        },
        
      },
     
      {
        headerName: 'OPF Number',
        field: 'OPFNumber',
        width: 250,
      }, 
      {
        headerName: 'Order Number',
        field: 'orderNumber',
        width: 200,
      },
         {
        headerName: 'OTL Number',
        field: 'OTLNumber',
        width: 200,
      }, 
      {
        headerName: 'Carrier',
        field: 'courierName',
        width: 200,
      }, 
      {
        headerName: 'AWB No#',
        field: 'waybillNumber',
        width: 200,
      }, 
      {
        headerName: 'Mode',
        field: 'mode',
        width: 250,
      },
      {
        headerName: 'Despatch Date',
        field: 'despatchDate',
        width: 200,
        valueFormatter : this.formatDispatchDate.bind(this),

      }, 
      {
        headerName: 'Type',
        field: 'orderTypeCode',
        width:200,
        valueFormatter: (params) => {
          return invoiceType[params.value]
        }
      },
      {
        headerName: 'Net Amount',
        field: 'sumNetAmount',
        width: 200,
       
        cellRenderer :(params) =>{
          return typeof params.value !== 'undefined' ? "<div class = 'text-right'>" + this._UtilsService.rupeeFormat(this.RoundOFTwoDigit(params.value)) + "</div>" : ''
        }
      },
      {
        headerName: 'Status',
        field: 'status',
        width: 200,
        valueFormatter: (params) =>{
          return this._UtilsService.invoiceStatus(params.value)
        }
      },
      {
        field: 'status',
        headerName: 'Action',
        sortable: false, 
        filter: false,
        width: 100, 
        cellRendererFramework: AgGridMenuComponent,
        cellRendererParams:  (params) => {
          let menu = [];
          menu.push({
            name: 'View', 
            link: '/'+this.moduleName+'/invoices/view/',
          });
        

         
          if (params.value == 0 ) {
          
          }


          // can't show delete options for cp 
          if (params.value == 0 && this.deleteInvoices) {
            menu.push({
              name : 'Delete',
            link: "",
            onMenuAction: this.deleteInvoice.bind(this)
            },
            {
              name : 'Freeze',
              onMenuAction: this.frozenInvoice.bind(this)
            }
            
            
            );
          }

          return { 
            menu,
            navigateId: 'invoiceNumber'
          }
        }
        }
    ];
    if(!this.isChannelPartner){
      this.columnDefs.splice(4,0, {
        headerName: 'Channel Partner',
        field: 'clientName',
        width: 400,
      });
      this.setCpList();
    }else{
      this.columnDefs.splice(4,0 ,{
        headerName: 'Client Name',
        field: 'custName',
        width: 490,
      });
      this.setClientList()

    } 
  }

loadInvoicePermission(){
    this._permissionMenuListService.getActionPermission({model : 'revenue'}, response =>{
      this.invoicePermission= response['revenue'];
      this.deleteInvoices = this.setActionsPermission('DELETE')
      });
}
RoundOFTwoDigit(num: any){
  var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
  return number;
}
setActionsPermission(name){
  return this.invoicePermission && typeof this.invoicePermission[ActionItems[name]] != 'undefined'  ?  true : false;
}

setPartsList(){
  // need to change api  
  this._StockReportService.getListParts(this.role,(res) => {
    this.partList = res  
  });
}

  setOtlList(){
    this._bookingService.getListofOTLParts(res =>{
      this.otlList =  this._UtilsService.groupByMultipleKeys(res,['name','OTLnumber'])
    })
  }
  setClientList(){
    this._bookingService.listHospital( res =>{
      this.clientNames =  this._UtilsService.groupByMultipleKeys(res,['name','custNumber'])
    })
  }
  deleteInvoice(id){
    this._promptService.openDialog({title : 'Delete Invoice: '+ id, btnLabel : 'CONFIRM', content: 'Are you sure you want to delete Invoice?'}, response =>{
      if (response){
        this._invoiceService.deleteInvoice(id,(res) =>{
          this.getInvoicesList(this.getPayload(this.invoiceSearchForm.value));
        });
      }
    })
  }

  frozenInvoice(id){
    this._promptService.openDialog({title : 'Freeze Invoice',btnLabel : 'CONFIRM',content :'Are you sure you want to freeze?'}, response =>{
      if (response){
       this._invoiceService.frozenInvoice(id, (res) =>  {
        this.getInvoicesList(this.getPayload(this.invoiceSearchForm.value));
       });
      }
    })
  }
  setCpList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpNameList = this._UtilsService.groupByMultipleKeys(res,['name','cpnumber'])
    })
  }
  formatDate(params){
    return params.data ? this._momentService.getDate(params.data.invoiceDate) : ''
  }

  formatDispatchDate(params){
    return params.data && params.data.despatchDate ? this._momentService.getDate(params.data.despatchDate) : ''
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.setInvoiceParams();
  }

  setInvoiceParams(){
    let data = {
      from_date : this._momentService.getFilterFormat(this.invoiceSearchForm.get('from_date').value),
      to_date : this._momentService.getFilterFormat(this.invoiceSearchForm.get('to_date').value, "toDate"),
    }
   return  this.getInvoicesList(data);
  }

   getInvoicesList(data?:any) { 
    let payload = {};    
    var datasource = {      
      getRows: (params: IGetRowsParams) =>{        
        if (data) {
          payload = data; 
        }
        payload['page_size'] =this.pageSize;
        payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
        payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
        payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
        this._invoiceService.searchInvoice(payload, (res)=>{
          let length = res['total'];
           this.gridData  = res['results'];
           this.isResponseHitting = true;
          params.successCallback(res['results'], length)
          const pageToNavigate = JSON.parse(localStorage.getItem('currentPage'));
          this.gridApi.paginationGoToPage(pageToNavigate);
          })
      }
      
    }
     this.gridApi.setDatasource(datasource); 
      
  }
  loadInvoiceSearchForm(){
    this.invoiceSearchForm = this.fb.group({
      OPFNumber: [''],
      invoiceNumber: [''],
      from_date:[this._momentService.deceedDate(new Date(),31)],
      to_date:[new Date()],
      cpnumber : ['', this._formValidator.requireMatch],
      OTLNumber: [''],
      custNumber: [''],
      status:[null],
      partNumber :  ['',this._formValidator.requireMatch],
    },{ validator: this._formValidator.dateValidation('from_date', 'to_date') });
  }

  searchInvoiceFilter(){
   
  if (this.invoiceSearchForm.valid){
    let invoicePayload = this.getPayload(this.invoiceSearchForm.value)
    localStorage.setItem('currentPage', JSON.stringify(0));
    this.isResponseHitting = false;
    this.getInvoicesList(invoicePayload);
   }
  }
 
  getPayload(invoiceValue){
    let data =  {};
    data['custNumber'] =  invoiceValue.custNumber ? invoiceValue.custNumber.custNumber : '';
    data['cpnumber'] =  invoiceValue.cpnumber ? invoiceValue.cpnumber.cpnumber : '';
    data['OTLNumber'] = invoiceValue.OTLNumber ? invoiceValue.OTLNumber.OTLnumber : '';
    data['from_date'] = invoiceValue.from_date ?  this._momentService.getFilterFormat(invoiceValue.from_date) : '';
    data['to_date'] = invoiceValue.to_date ? this._momentService.getFilterFormat(invoiceValue.to_date , "toDate" ) : '';
    data['OPFNumber'] =invoiceValue.OPFNumber ? invoiceValue.OPFNumber : '';
    data['invoiceNumber'] =invoiceValue.invoiceNumber ? invoiceValue.invoiceNumber : '';
    data['status']= invoiceValue.status ? invoiceValue.status : '';
    data['partNumber'] =invoiceValue.partNumber ? invoiceValue.partNumber.partNumber : '';
    return data;
  }

  importStock($event) {
    const formData = new FormData();
    formData.append('file', $event.target.files[0]);
    this._invoiceService.importStockCsv(formData);
  }

  cancelFilter(){
    this.setInvoiceParams();
    this.invoiceSearchForm.reset();
    this.invoiceSearchForm.get('from_date').setValue(this._momentService.deceedDate(new Date(),31));
    this.invoiceSearchForm.get('to_date').setValue(new Date())
      
  }
  exportInvoiceFilter(){
    let payload =  this.getPayload(this.invoiceSearchForm.value);
    // payload['from_date'] = payload['from_date'] ?  payload['from_date'] : this._momentService.getFilterFormat(this._momentService.deceedDate(new Date(),90))
    // payload['to_date'] =  payload['to_date'] ?  payload['to_date'] : this._momentService.getFilterFormat(new Date(),"toDate")
   this._invoiceService.exportInvoiceFilter(payload);
  }
}

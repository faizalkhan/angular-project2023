import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MatStepper } from '@angular/material/stepper';
import { InvoiceService } from '../../../../beckman/service/invoice/invoice.service';
import { Endpoints, ActionItems } from 'src/app/core/services/constants';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';

@Component({
  selector: 'app-invoices-import',
  templateUrl: './invoices-import.component.html',
  styleUrls: ['./invoices-import.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class InvoicesImportComponent implements OnInit { 
 
  constructor(private _invoiceService: InvoiceService,private _UtilsService : UtilsService,private _permissionMenuListService: PermissionMenuListService, ) { }
  @ViewChild('stepper', { static: false }) private myStepper: MatStepper;
  public zeroIndex = 0;
  public progressCount = 100;
  public csvData;
  public selectedValue = ''; 
  public permission = false;
  public invoicePermission;
  ngOnInit() {
    this._permissionMenuListService.getActionPermission({model : 'revenue'},response =>{
      this.permission = response['revenue'] && typeof response['revenue'][ActionItems['IMPORT_BECKMAN_INVOICE']] != 'undefined'  ?  true : false; 
    });
  }

  onChange(){
    this.csvData = '';
  }




  importCSV(event) {
    this.csvData = event[this.zeroIndex];
    this.csvData['progress'] = this.zeroIndex;
    this.uploadProgressBar(this.zeroIndex, this.csvData);
  }

  uploadProgressBar(index, fileData) {
    setTimeout(() => {
      if (index == 1 &&  Object.keys(fileData).length > 0 ) {
        return;
      } else {
        const progressInterval = setInterval(() => {
          if (fileData.progress === this.progressCount) {
            clearInterval(progressInterval);
            this.uploadProgressBar(index + 1, fileData);
          } else {
            fileData.progress += 5;
          }
        }, 200);
      }
    }, 1000);
  }

 
 
  submit() {
   let endPoint = this.selectedValue == 'revenue'  ? Endpoints.IMPORT_REVENUE : 
   (this.selectedValue == 'shipping' ? Endpoints.IMPORT_SHIPPING : this.selectedValue == 'freeze' ? Endpoints.IMPORT_FREEZE : this.selectedValue == 'taxilafile' ?  Endpoints.IMPORT_TAXILA_FILE : Endpoints.IMPORT_CP_OUTBOUND)
      this._invoiceService.importCSV(endPoint,this.selectedValue.toUpperCase(), this.getFormData(this.csvData));
      this.getFormData(this.csvData).delete('file');
      this.csvData = '';
      this.selectedValue = '';
  }

  getFormData(fileData){
    const files = new FormData();
    files.append('file', fileData);
    return files;
  }

  cancelInvoice() {
    this.csvData = '';
    this.selectedValue =''
  
  }

  exportFreezeTemplate(){
    this._invoiceService.exportFreezeDownloadTemplate();
  }
  exportFreezeInstructions(){
    this._invoiceService.exportFreezeTemplateInstructions();
  }

}

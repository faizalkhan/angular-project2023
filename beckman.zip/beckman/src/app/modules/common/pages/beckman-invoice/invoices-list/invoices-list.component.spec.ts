
import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { routes } from 'src/app/app-routing.module';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { AgGridModule } from 'ag-grid-angular';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { InvoicesListComponent } from './invoices-list.component';



describe('InvoicesListComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes),
        AppMaterialModule,
        CustomFormsModule,
        AgGridModule.withComponents([]),
        HttpClientModule,
        BrowserAnimationsModule
      ],
     
      declarations: [
        InvoicesListComponent
      ],
    }).compileComponents();
   
  }));

  it('should create the admin invoice list', () => {
    const fixture = TestBed.createComponent(InvoicesListComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

});



import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PermissionsComponent } from './permissions.component';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { RouterModule, Routes } from '@angular/router';
import { PipeModule } from 'src/app/core/pipe/pipe.module';


const routes: Routes = [{
  path:'', 
  component:PermissionsComponent,
}
]



@NgModule({
  declarations: [PermissionsComponent],
  imports: [
    CommonModule,
    AppMaterialModule,
    RouterModule.forChild(routes),
    PipeModule
  ]
})
export class PermissionsModule { }

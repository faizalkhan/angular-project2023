import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { Roles } from 'src/app/modules/auth/model/user';

@Component({
  selector: 'app-permissions',
  templateUrl: './permissions.component.html',
  styleUrls: ['./permissions.component.css'] ,
  encapsulation: ViewEncapsulation.None

})
export class PermissionsComponent implements OnInit {
  public permission =[]
  public BA = Roles.Agent;
  public  submitted = true; 
  constructor(private _permissionMenuListService :PermissionMenuListService) { }

  ngOnInit() {
    this._permissionMenuListService.getAllPermission(response =>{
      this.permission  = response;
      response.map(res=>{
        let name = res['role']
        //console.log(res[res['role']]['add_otlparts-otl-otlparts']) 
      })
    })
 
  }

  submit(){
    this.submitted = false;
    this._permissionMenuListService.uploadPermission(this.permission, response =>{
      this.submitted = true
    });
  }

}

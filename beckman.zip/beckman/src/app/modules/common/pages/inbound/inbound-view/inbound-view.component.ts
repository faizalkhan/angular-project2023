 import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { OutboundService } from '../../../service/outbound/outbound.service';
import { ActionItems } from 'src/app/core/services/constants';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';

@Component({
  selector: 'app-inbound-view',
  templateUrl: './inbound-view.component.html',
  styleUrls: ['./inbound-view.component.css']
})
export class InboundViewComponent implements OnInit {
  public opfNumber;
  public data;
  public serverUrl = environment.apiUrl;
  public inboundPermission;

  constructor(public route: ActivatedRoute, private _bookingService: CpbookingService,  private _OutboundService: OutboundService) { }


  ngOnInit() {
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.opfNumber = params.get('id');
      this.getInboundDetails();
      this.loadInboundPermission();
    });
  }

  getInboundDetails(){
    this._OutboundService.viewInbound(this.opfNumber , response=>{
      this.data = response;
    })
  }
  loadInboundPermission(){
    this._bookingService.getActionPermission({model : 'inbound'}, response =>{
      this.inboundPermission= response['inbound'];
    });
  }
  setActionsPermission(name){
    return this.inboundPermission && typeof this.inboundPermission[ActionItems[name]] != 'undefined'  ?  true : false;
   }
}

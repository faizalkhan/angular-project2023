import { Component, OnInit, HostListener } from '@angular/core';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { AgGridRouterComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-router.component';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { OutboundService } from '../../../service/outbound/outbound.service';
import { ORACLE, ActionItems } from 'src/app/core/services/constants';
import { IGetRowsParams } from 'ag-grid-community';
import { Roles } from 'src/app/modules/auth/model/user';

@Component({
  selector: 'app-inbound-list',
  templateUrl: './inbound-list.component.html',
  styleUrls: ['./inbound-list.component.css']
})
export class InboundListComponent implements OnInit {
  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public inboundSearchForm:FormGroup;
  public gridData = [];
  public pageSize = 10;
  otlList = [];
  clientNames=[];
  cpNames=[];
 
  // permission 
  public isAdmin:boolean = false;
  public isBookingAgent =false;
  public role;
  public moduleName;
  public inboundPermission;
  public displayChannelPartnerKeys = ['name', 'cpnumber']
  public displayChannelPartnerKeys1 = ['name', 'custNumber']
  constructor(private _StorageService: StorageService, private _bookingService: CpbookingService,private _PromptService: PromptService, private _UtilsService: UtilsService, private _outboundService: OutboundService, private _momentService: MomentService, private fb: FormBuilder, private _formValidator: FormValidatorService) { }
  @HostListener('window:resize', ['$event'])onResize(event) {
    this.gridApi.sizeColumnsToFit();
}

  ngOnInit() { 
    this.moduleName = this._UtilsService.moduleName()
    this.loadinboundSearchForm();
    this.loadInboundPermission();

    this.role = this._StorageService.getUserDetails().role;
    this.isAdmin = this._UtilsService.isAdminRole(this.role);
    this.isBookingAgent  =  this._UtilsService.isBaRole(this.role);

    this.setClientList();
    this.setCpList();
    this.setOtlList();

    this.inboundSearchForm.get('isMatched').valueChanges.subscribe(value =>{
      if (value) {
        this.inboundSearchForm.get('isMatchedColumn').enable()
        this.inboundSearchForm.get('isMatchedColumn').updateValueAndValidity();
      }
    })
    
    this.defaultColDef = {
      sortable: true,
      filter: false,
      resizable: true
    };

    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2
    };

    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.gridOptions.onFilterChanged = event => {
      this.gridApi.redrawRows(); 
    }

    this.columnDefs = [
      {
        field: 'id',
        headerName: 'S No.',
        width: 100,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
      },
      {
        headerName: 'OPF Number',
        field: 'OPFNumber',
        cellRendererFramework: AgGridRouterComponent,
        cellRendererParams: {
          inRouterLink: this.isBookingAgent ?   '/agent/inbound/ba/view/' : '/'+this.moduleName+'/bookings/inbound/view/',
        },
      },
      {
        headerName: 'Ordered Date and Time',
        field: 'OPFDate',
        valueFormatter: (params) => {
          return params.value ? this._momentService.getDateTimeFormat(params.value) : ''
        },

      },
      {
        headerName: 'Order Status',
        field: 'status',
      },
      {
        headerName: 'Oracle Order No',
        field: 'oracleOrderNumber',
      },
      {
        headerName: 'Match Status',
        field: 'isMatched',
        valueFormatter: (params) =>{
          if (params.value != null ) return  params.value  ? 'Matched' : 'Not Matched'
          
        }
      },
      {
        headerName: 'Client Name',
        field: 'custName',
      },
      {
        headerName: 'Channel Partner',
        field: 'cpName',
      },
      {
        headerName: 'OTL No.',
        field: 'OTLNumber',
      },

      {
        headerName: 'Net Amount (Rs.)',
        field: 'net_amount',
        comparator: (param1, param2) => {
          return this._UtilsService.numberSorting(param1, param2);
        },
        cellRenderer: (params) => {
          return typeof params.value !== 'undefined' ? "<div class = 'text-right'>" + this._UtilsService.rupeeFormat(this.RoundOFTwoDigit(params.value)) + "</div>" : ''
        }
      },
      {
        headerName: 'Total Amount (Rs.)',
        field: 'total_amount',
        comparator: (param1, param2) => {
          return this._UtilsService.numberSorting(param1, param2);
        },
        cellRenderer: (params) => {
          return typeof params.value !== 'undefined' ? "<div class = 'text-right'>" + this._UtilsService.rupeeFormat(this.RoundOFTwoDigit(params.value)) + "</div>" : ''
        }
      },
      
      { //oracleStatus -manual , not sent, disabled the VIEW JSON button 
        field: 'oracleStatus',
        headerName: 'Action',
        sortable: false,
        filter: false,
        cellRendererFramework: AgGridMenuComponent,
        cellRendererParams: (params) =>{
          let menu = [];
          menu.push({
            name: 'View',
            link: this.isBookingAgent ?   '/agent/inbound/ba/view/' : '/'+this.moduleName+'/bookings/inbound/view/', 
            id : 'id'
          });
          if (params.value  && params.value != ORACLE.Manual && params.value != ORACLE.Not_Sent && params.data['isMatched'] !== null) {
            menu.push({
              name: 'View JSON',
              link: this.isBookingAgent  ?  '/agent/inbound/JSON/' :'/'+this.moduleName+'/inbound/JSON/',
            });
          }
         return  {
          menu, 
         navigateId: 'OPFNumber'
        }
         },
      }
    ];

  }
  loadInboundPermission(){
    this._bookingService.getActionPermission({model : 'inbound'}, response =>{
      this.inboundPermission= response['inbound'];
    });
  }
  setActionsPermission(name){
    return this.inboundPermission && typeof this.inboundPermission[ActionItems[name]] != 'undefined'  ?  true : false;
   }
  setClientList(){
    this._bookingService.listHospital( res =>{
      this.clientNames = this._UtilsService.groupByMultipleKeys(res,['name','custNumber'])
    })
  }

  setCpList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpNames =  this._UtilsService.groupByMultipleKeys(res,['name','cpnumber'])   
    })
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.setInboundForm();
  }
  setInboundForm(){
    let payload = {
      from_date : this._momentService.getFilterFormat(this.inboundSearchForm.get('from_date').value),
      to_date : this._momentService.getFilterFormat(this.inboundSearchForm.get('to_date').value, "toDate"),
      status : 'Open'
    }
    this.getInBoundList(payload);
  }
  getInBoundList(data?:any){
    let payload = {}; 
    var datasource = {
      getRows: (params: IGetRowsParams) =>{
        if (data) {
          payload = data;
        }
        payload['page_size'] =this.pageSize
        payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
        payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
        payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
        this._outboundService.searchInBoundFilter(data, (res) => {
          let length = res['total'];
          this.gridData =res['results']
          params.successCallback(res['results'], length) // data and totalcount of records 
          })
      }
    }
      this.gridApi.setDatasource(datasource);
  }

  setOtlList(){
    this._bookingService.getListofOTLParts(res =>{
      this.otlList =  this._UtilsService.groupByMultipleKeys(res,['name','OTLnumber'])
    })
  }

  loadinboundSearchForm(){
    this.inboundSearchForm = this.fb.group({
      custNumber: ['',this._formValidator.requireMatch],
      OTLNumber: ['',this._formValidator.requireMatch],
      isMatched: [null],
      OPFNumber: [''],
      from_date:[this._momentService.deceedDate(new Date(),31)],
      to_date:[new Date()],
      oracleOrderNumber :[null],
      cpNumber:['', this._formValidator.requireMatch],
      isMatchedColumn:[{value: null, disabled: true}],
      status:['Open']
    },{ validator: this._formValidator.dateValidation('from_date', 'to_date') })
  }

  getpayload(data) {
    let payload = {};
    payload['custNumber'] = data.custNumber ? data.custNumber.custNumber : '';
    payload['OTLNumber'] = data.OTLNumber ? data.OTLNumber.OTLnumber : '';
    payload['isMatched'] = data.isMatched ? data.isMatched : '';
    payload['from_date'] = data.from_date ?  this._momentService.getFilterFormat(data.from_date) : '';
    payload['to_date'] = data.to_date ? this._momentService.getFilterFormat(data.to_date, "toDate") : '';
    payload['oracleOrderNumber'] = data.oracleOrderNumber ? data.oracleOrderNumber : '';
    payload['cpNumber'] = data.cpNumber ? data.cpNumber.cpnumber : '';
    payload['OPFNumber'] = data.OPFNumber ? data.OPFNumber : '';
    payload['isMatchedColumn'] = data.isMatchedColumn ? data.isMatchedColumn : '';
    payload['status'] = data.status ? data.status : ''
    return payload;
  }

  searchFilter(){
       this.getInBoundList(this.getpayload( this.inboundSearchForm.value));
  }
  cancelFilter(){
    this.inboundSearchForm.reset();
    this.inboundSearchForm.get('isMatchedColumn').disable()
    this.inboundSearchForm.get('isMatchedColumn').updateValueAndValidity();
    this.inboundSearchForm.get('from_date').setValue(this._momentService.deceedDate(new Date(),31));
    this.inboundSearchForm.get('to_date').setValue(new Date())
    this.inboundSearchForm.get('status').setValue('Open');
    this.setInboundForm();
  }
  exportInBoundFilter(){
    let inBoundPayload =  this.getpayload(this.inboundSearchForm.value);
    // inBoundPayload['from_date'] = inBoundPayload['from_date'] ?  inBoundPayload['from_date'] : this._momentService.getFilterFormat(this._momentService.deceedDate(new Date(),90))
    // inBoundPayload['to_date'] =  inBoundPayload['to_date'] ?  inBoundPayload['to_date'] : this._momentService.getFilterFormat(new Date(),"toDate")
    this._outboundService.exportInboundFilter(inBoundPayload);
  }
  
  exportDifferenceReport(){
    let inBoundPayload =  this.getpayload(this.inboundSearchForm.value);
    // inBoundPayload['from_date'] = inBoundPayload['from_date'] ?  inBoundPayload['from_date'] : this._momentService.getFilterFormat(this._momentService.deceedDate(new Date(),90))
    // inBoundPayload['to_date'] =  inBoundPayload['to_date'] ?  inBoundPayload['to_date'] : this._momentService.getFilterFormat(new Date(),"toDate")
    this._outboundService.exportDifferenceReportFilter(inBoundPayload);
  }
  RoundOFTwoDigit(num: any){
    var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
    return number;
  }

}

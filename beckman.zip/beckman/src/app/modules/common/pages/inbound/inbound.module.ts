import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InboundComponent } from './inbound.component';
import { InboundListComponent } from './inbound-list/inbound-list.component';
import { AppMaterialModule } from '../../../../core/modules/material/material.module';
import { RouterModule, Routes } from '@angular/router';
import { InboundViewComponent } from './inbound-view/inbound-view.component';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { AgGridModule } from 'ag-grid-angular';
import { PipeModule } from 'src/app/core/pipe/pipe.module';



const routes: Routes = [{ 
  path:'', 
  component:InboundComponent,
  children:[{
    path: '',
    component:InboundListComponent
  },
  {
    path: 'JSON/:id',
    component:InboundViewComponent
  }
]
}]


@NgModule({
  declarations: [InboundComponent,InboundListComponent, InboundViewComponent],
  imports: [
    CommonModule,
    AppMaterialModule,
    RouterModule.forChild(routes),
    AgGridModule.withComponents([]),
    CustomFormsModule,
    PipeModule
  ],
  exports :[CustomFormsModule, AgGridModule, InboundComponent,InboundListComponent,InboundViewComponent]
})
export class InboundModule { }

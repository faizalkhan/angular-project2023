import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { OutboundListComponent } from './outbound-list/outbound-list.component';
import { AppMaterialModule } from '../../../../core/modules/material/material.module';
import { OutboundComponent } from './outbound.component';
import { AgGridModule } from 'ag-grid-angular';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { OutboundViewComponent } from './outbound-view/outbound-view.component';
import { PipeModule } from 'src/app/core/pipe/pipe.module';

const routes: Routes = [{
  path:'', 
  component:OutboundComponent,
  children:[{
    path: '',
    component:OutboundListComponent
  },{
    path: 'JSON/:id',
    component:OutboundViewComponent
  }
]
}]


@NgModule({
  declarations: [OutboundComponent,OutboundListComponent, OutboundViewComponent],
  imports: [
    CommonModule,
    AppMaterialModule,
    RouterModule.forChild(routes),
    AgGridModule.withComponents([]),
    CustomFormsModule,
    PipeModule
  ],
  // exports :[  CustomFormsModule, AgGridModule, OutboundComponent,OutboundListComponent,OutboundViewComponent]
})
export class  OutboundModule { }

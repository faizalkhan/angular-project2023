import { Component, OnInit } from '@angular/core';
import { OutboundService } from '../../../service/outbound/outbound.service';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ActionItems } from 'src/app/core/services/constants';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';

@Component({
  selector: 'app-outbound-view',
  templateUrl: './outbound-view.component.html',
  styleUrls: ['./outbound-view.component.css']
}) 
export class OutboundViewComponent implements OnInit {   
  public opfNumber;
  public data;
  public serverUrl = environment.apiUrl;
  public outboundPermission;

  constructor(public route: ActivatedRoute, private _bookingService: CpbookingService,  private _OutboundService: OutboundService) { }

  ngOnInit() {
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.opfNumber = params.get('id');
      this.getOutboundDetails();
      this.loadOutboundPermission()
    });
    
  }

  getOutboundDetails(){
    this._OutboundService.viewOutbound(this.opfNumber , response=>{
      this.data = response;
    })
  }

   loadOutboundPermission(){
    this._bookingService.getActionPermission({model : 'outbound'}, response =>{
      this.outboundPermission= response['outbound'];
    });
  }
  setActionsPermission(name){
    return this.outboundPermission && typeof this.outboundPermission[ActionItems[name]] != 'undefined'  ?  true : false;
   }

}
 
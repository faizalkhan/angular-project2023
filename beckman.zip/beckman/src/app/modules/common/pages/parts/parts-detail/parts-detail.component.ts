import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { PartsService } from 'src/app/modules/beckman/service/parts/parts.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { ActionItems } from 'src/app/core/services/constants';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';


@Component({
  selector: 'app-parts-detail',
  templateUrl: './parts-detail.component.html',
  styleUrls: ['./parts-detail.component.css']
})
export class PartsDetailComponent implements OnInit {

  public partId;
  public data: any;
  public moduleName;
  public editParts= false;
  public deletePart = false
  constructor( public route: ActivatedRoute,private _PromptService: PromptService,private _permissionMenuListService: PermissionMenuListService, private _UtilsService:UtilsService, private _partsService: PartsService) { }

  ngOnInit() {
    this.moduleName = this._UtilsService.moduleName()
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.partId = parseInt(params.get('id'));
    });
  
    this._partsService.viewPart(this.partId,
      (response) => {
        this.data = response;
      },
      (error) => console.log(error))
      
      this._permissionMenuListService.getActionPermission({model : 'parts'},response =>{
        this.editParts = response['parts'] && typeof response['parts'][ActionItems['EDIT']] != 'undefined' ? true : false
        this.deletePart = response['parts'] && typeof response['parts'][ActionItems['DELETE']] != 'undefined' ? true : false
       });
  }

  redirect(){
    this._partsService.navigateEditParts(this.data.id)
  }
  deleteParts(){
    this._PromptService.openDialog({title : 'Delete Parts',btnLabel : 'CONFIRM',content :'Are you sure you want to delete parts?'}, response =>{
      if (response){
        this._partsService.deleteParts(this.partId, () => this._partsService.navigateParts())
      }
    })
  }

}

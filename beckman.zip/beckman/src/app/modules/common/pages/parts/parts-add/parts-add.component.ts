import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import {  ActivatedRoute, ParamMap } from '@angular/router';
import { PartsService } from 'src/app/modules/beckman/service/parts/parts.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { ActionItems } from 'src/app/core/services/constants';


@Component({
  selector: 'app-parts-add',
  templateUrl: './parts-add.component.html',
  styleUrls: ['./parts-add.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class PartsAddComponent implements OnInit {
  public productName = []; 
  public data:any;
  public partsId;
  public isDisabled:boolean = true;
  public moduleName;
  constructor(private fb: FormBuilder, private _UtilsService:UtilsService,private _partsService:PartsService,public route: ActivatedRoute,private _permissionMenuListService: PermissionMenuListService,private _formValidator: FormValidatorService) { }
  public partsForm: FormGroup;
  
  ngOnInit() {
    this.moduleName = this._UtilsService.moduleName()
    this.loadCPPermission();
    this.loadPartForm();
    this.statusValueChanged();
    this._partsService.getProductLine((res)=>{
      this.productName = res;
    });
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.partsId = parseInt(params.get('id'));
      if (params.get('id')) {
        this.getPartsData();
      }
    });
    
  }
  loadCPPermission(){
    this._permissionMenuListService.getActionPermission({model : 'parts'},response =>{
      if((! this.partsId && typeof response['parts'][ActionItems['ADD']] == 'undefined')|| ( this.partsId && typeof response['parts'][ActionItems['EDIT']] == 'undefined') )  this._partsService.navigateParts()
    });
}
  getPartsData(){
    this._partsService.viewPart(this.partsId,
      (response) => {
        this.data = response;
        this.setPartsData();
      },
      (error) => console.log(error))
  }
  setPartsData(){
    this.partsForm.setValue({
      partNumber:this.data.partNumber,
      description:this.data.description,
      productLine : this.getFilterProductName(this.data.productLine),
      HSSNcode: this.data.HSSNcode,
      HSSNtax: this.data.HSSNtax,
      isActive: this.data.isActive.toString(),
      inActiveReason: this.data.inActiveReason
    });
  }

  getFilterProductName(value) {
    let options = {};
      options = this.productName.filter((val) => {
        return val.name=== value
      });
    return options[0] ? options[0] : '';
  }

  loadPartForm() {
    this.partsForm = this.fb.group({
      partNumber: ['', Validators.required],
      description: ['', Validators.required],
      productLine : ['', [Validators.required, this._formValidator.requireMatch]],
      HSSNcode: ['', Validators.required],
      HSSNtax: ['', [Validators.required, this._formValidator.maxLength(100)]],
      isActive: ['1', Validators.required],
      inActiveReason: [{value: null, disabled: this.isDisabled}]
    });
  }

  cancelParts() {
    this._partsService.navigateParts()
  }

  resetParts() {
    if (!this.partsId) {
      this.partsForm.reset();
      this.partsForm.get('isActive').setValue('1');
    }
    else this.setPartsData();
      
  }
  statusValueChanged() {
    const inActiveReason = this.partsForm.get('inActiveReason');
    this.partsForm.get('isActive').valueChanges.subscribe(
      (status: any) => {
        if(status == 0) {
          this.isDisabled = false;
          inActiveReason.enable();
          inActiveReason.setValidators([Validators.required, this._formValidator.noWhitespaceValidation]);
        }
        else {
          this.isDisabled = true;
          this.partsForm.controls['inActiveReason'].setValue(null);
          inActiveReason.disable();
          inActiveReason.clearValidators();
        }
        inActiveReason.updateValueAndValidity();
        // status == 0 ? this.isDisabled = false : this.isDisabled = true;
        // status == 0 ?  this.partsForm.get('inActiveReason').enable() :  this.partsForm.get('inActiveReason').disable();
        });
  }

  submit(){
    let partsData = this.partsForm.value;
    partsData['productLine']  = this.partsForm.get('productLine').value.name;
    partsData['inActiveReason']  = this.partsForm.get('inActiveReason').value;
    if (this.partsId) {
      this._partsService.editParts(this.partsId,partsData, () => {
        this.partsId = '';
        this.partsForm.reset();
      });
    } else {
      this._partsService.addParts(partsData);
    }
  }
}

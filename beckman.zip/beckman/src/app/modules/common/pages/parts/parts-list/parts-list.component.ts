import { Component, OnInit, HostListener } from '@angular/core';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { AgGridRouterComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-router.component';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Roles } from 'src/app/modules/auth/model/user';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { IGetRowsParams } from 'ag-grid-community';
import { PartsService } from 'src/app/modules/beckman/service/parts/parts.service';
import { ActionItems } from 'src/app/core/services/constants';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';


@Component({
  selector: 'app-parts-list',
  templateUrl: './parts-list.component.html',
  styleUrls: ['./parts-list.component.css']
}) 
export class PartsListComponent implements OnInit {

  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public partsSearchForm: FormGroup;
  public productName = [];
  public searchValue;
  public pageSize = 10;
  public moduleName;
  public editPart = false;
  public deletePart = false;
  public partPermission;
  constructor(private _partsService:PartsService,private _permissionMenuListService: PermissionMenuListService,
    private _formValidator: FormValidatorService, private _UtilsService:UtilsService,
    private _PromptService: PromptService,private fb: FormBuilder) { }
  @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
  }
  ngOnInit() {
    this.moduleName = this._UtilsService.moduleName()
    this.loadPartsPermission()
    this._partsService.getProductLine((res)=>{
      this.productName = res;
    })
    this.loadPartsSearchForm();
    this.defaultColDef = {
      sortable: true,
      filter: false,
      resizable: true
    };
    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2
    };
    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.gridOptions.onFilterChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: "id",
        headerName: 'S No.',
        width: 100,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
      },
      {
        headerName: 'Part Number',
        field: "partNumber",
        width: 190,
        cellRendererFramework: AgGridRouterComponent,
        cellRendererParams: {
          inRouterLink: '/'+this.moduleName+ '/parts/view/',
        },
        comparator:(param1,param2)=>{
          return this._UtilsService.alphaNumbericSorting(param1,param2);
        }
      },
      {
        headerName: 'Description',
        field: "description",
        width: 200,
      },
      {
        headerName: 'Product Line',
        field: "productLine",
        width: 200,
      }, 
      {
        headerName: 'HSSN Code',
        field: "HSSNcode",
        width: 200,
      },
      {
        headerName: 'HSSN Tax',
        field: "HSSNtax",
        width: 100,
        comparator: (param1, param2) => {
          return this._UtilsService.numberSorting(param1,param2);
        }
      },
      {
        field: "isActive",
        headerName: 'Status',
        width: 100,
        valueFormatter: (params) =>{
          
          return (params.value || params.value == 0) ?  this._UtilsService.isActiveStatus(params.value) : ''
        }
      },
      {
        field: "",
        headerName: 'Action',
        sortable: false,
        filter: false,
        width: 100,
        cellRendererFramework: AgGridMenuComponent,
        cellRendererParams: (params) => {
          let menu = [{
            name: "View",
            link: "/"+this.moduleName +"/parts/view/",
            onMenuAction:""
          }]
          if (this.editPart){
            menu.push({
              name: "Edit",
              link: "/"+this.moduleName + "/parts/edit/",
              onMenuAction:""
            })
          }
          if(this.deletePart){
            menu.push({
              name: "Delete",
              link: "",
              onMenuAction: this.deleteParts.bind(this)
            })
          }
          return {menu}
        },
      }
    ];

  }
  setActionsPermission(name){
    return this.partPermission && typeof this.partPermission[ActionItems[name]] != 'undefined'  ?  true : false;
  }

  loadPartsPermission(){
      this._permissionMenuListService.getActionPermission({model : 'parts'}, response =>{
        this.partPermission= response['parts'];
        this.editPart = this.setActionsPermission('EDIT');
        this.deletePart = this.setActionsPermission('DELETE');
      });
  }
  
  deleteParts(id){
    this._PromptService.openDialog({title : 'Delete Parts',btnLabel : 'CONFIRM',content :'Are you sure you want to delete parts?'}, response =>{
      if (response){
        this._partsService.deleteParts(id, () => this.getPartsList())
      }
    })
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.getPartsList();
  }
 

  getPartsList(data ?:any) {
    let payload = {}; 
    var datasource = {
      getRows: (params: IGetRowsParams) =>{
        if (data) {
          payload = data;
        }
        payload['page_size'] =this.pageSize
        payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
        payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
        payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
        this._partsService.searchParts(Roles.Admin, payload, (res)=>{
          let length = res['total'];
          params.successCallback(res['results'], length) 
          })
      }
    }
      this.gridApi.setDatasource(datasource);
  }

  importParts($event) {
    const formData = new FormData();
    formData.append('file', $event.target.files[0]);
    this._partsService.importParts(formData, () => {
      this.getPartsList();
    });
  }

  exportParts() {
    this._partsService.exportParts();
  }

  
  
  loadPartsSearchForm() {
    this.partsSearchForm = this.fb.group({
      partNumber:  [''],
      productLine:  ['',this._formValidator.requireMatch],
      description:  [''],
    });
  }

  getPartPayload(data){
    let partPayload = {};
    partPayload['partNumber'] = data.partNumber ? data.partNumber : '';
    partPayload['productLine'] =  data.productLine  ? data.productLine.name : ''
    partPayload['description'] = data.description ? data.description : ''
    return partPayload;
  }

  searchParts() {
    let data = this.getPartPayload(this.partsSearchForm.value);
    this.getPartsList(data);
  }

  

  clearFilter() {
    this.getPartsList();
    this.partsSearchForm.reset();
  }
 
}

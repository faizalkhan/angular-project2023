import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { PartsComponent } from './parts.component';
import { PartsListComponent } from './parts-list/parts-list.component';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { AgGridModule } from 'ag-grid-angular';
import { PartsAddComponent } from './parts-add/parts-add.component';
import { PartsDetailComponent } from './parts-detail/parts-detail.component';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';

const routes: Routes = [{
  path:'',
  component: PartsComponent,
  children:[
    {
      path: '',
      component:PartsListComponent
    },
    {
      path: 'view/:id',
      component:PartsDetailComponent
    },
    {
      path:'add',
      component:PartsAddComponent
    },
    {
      path:'edit/:id',
      component:PartsAddComponent
    }
]
}]

@NgModule({
  declarations: [
    PartsComponent,
    PartsListComponent,
    PartsAddComponent,
    PartsDetailComponent
  ],
  imports: [
    CommonModule,
    AppMaterialModule,
    CustomFormsModule,
    RouterModule.forChild(routes),
    AgGridModule.withComponents([])
  ]
})
export class PartsModule { }

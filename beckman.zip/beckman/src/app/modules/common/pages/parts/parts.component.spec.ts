
import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { PartsComponent } from './parts.component';
import { routes } from 'src/app/app-routing.module';




describe('PartsComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes),
        AppMaterialModule
      ],
     
      declarations: [
        PartsComponent
      ],
    }).compileComponents();
   
  }));

  it('should create the parts', () => {
    const fixture = TestBed.createComponent(PartsComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

});



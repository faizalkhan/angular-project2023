
import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { routes } from 'src/app/app-routing.module';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { PartsDetailComponent } from './parts-detail.component';



describe('PartsDetailComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes),
        AppMaterialModule,
        CustomFormsModule,
        HttpClientModule,
        BrowserAnimationsModule
      ],
     
      declarations: [
        PartsDetailComponent
      ],
    }).compileComponents();
   
  }));

  it('should create the parts  detail', () => {
    const fixture = TestBed.createComponent(PartsDetailComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

});



import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { DashboardService } from '../../../beckman/service/dashboard/dashboard.service';
import { Component, ElementRef, OnInit, ViewChild,ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { StockReportService } from '../../service/stock-reports/stock-report.service';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DashboardFilterDialog } from './dashboard-dialog/filter.component';
import { Router } from '@angular/router';
import { Roles } from 'src/app/modules/auth/model/user';
import { DashboardReportService } from 'src/app/modules/common/pages/dashboard-reports/service/dashboard-report.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { SecondaryTrendLineComponent } from 'src/app/core/modules/shared/chart/secondary-trend-line/secondary-trend-line.component';
import { PrimarySecondaryTrendLineComponent } from 'src/app/core/modules/shared/chart/primary-secondary-trend-line/primary-secondary-trend-line.component';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  encapsulation : ViewEncapsulation.Emulated
})
export class DashboardComponent implements OnInit {

  @ViewChild(SecondaryTrendLineComponent, {static : true}) SecondaryTrendLineComponents : SecondaryTrendLineComponent ;
  @ViewChild(PrimarySecondaryTrendLineComponent, {static : true}) PrimarySecondaryTrendLineComponents :PrimarySecondaryTrendLineComponent ;
  title: string = "Dashboard";
  public inventory;
  public inventoryDio;
  public daysinventoryForm: FormGroup;
  public displayChannelPartnerKeys = ['name', 'cpnumber']
  public displayChannelPartnerKeys1 = ['name', 'custNumber'];
  routeName='';
  permissionMenu;
  public role;
  public clientNames =[];
  public otlList =[];
  public partList=[];
  public cityList=[];
  public siteIdList=[];
  public stockReportPermission;
  public cpNames =[];
  public isAdmin:boolean = false;
  public isChannelPartner;
  public filterImagePath;
  public primaryTotalMonthValue;
  public primaryTotalCurrentDayValue;
  public secondaryTotalMonthValue;
  public secondaryTotalCurrentDayValue;
  public inventoryOutStandingDate;
  public flipFrontShow = true;
  public flipFrontBack =false;
  ExportInventoryPermission: any;
  public tabflag1 = false;
  public tabflag2 = false;
  loadsecondarytrendline;
  tabIndex;
  constructor(private _StorageService: StorageService, private _dashboardService: DashboardService, private fb: FormBuilder, private _utilService: UtilsService,
    private _formValidator: FormValidatorService, private _StockReportService:StockReportService,private router:Router, private _DashboardReportService:DashboardReportService,
    private _bookingService :CpbookingService, private _utilsService : UtilsService, private _momentService: MomentService, private _permissionMenuListService: PermissionMenuListService,
     public filter_dialog: MatDialog ) {}

     @ViewChild('myTestDiv', { static :true}) myTestDiv: ElementRef;
  ngOnInit() {
    this.isChannelPartner = this._utilsService.isCpRole(this._StorageService.getUserDetails().role);
    this.role = this._StorageService.getUserDetails().role;
    this.loadDaysInventoryOutstandingForm();
    this.filterImagePath = '../../../../../assets/filter.png';
    this.loadPrimaryandSecondarySales();
    this.getUserRole();
    this.setCpList();
    this.setOtlList();
    this.setPartsList();
	this.getPermissionMenu(); 
  this.loadReportsPermission();
  }
  
salesFilter(){
  let dialog = this.filterDialog();
  dialog.afterClosed().subscribe(result=>{
     if(result['need_filter']){
    
      this._dashboardService.FilterPrimarySecondarySales(result, res =>{

        if(res.length > 0 ){
          this.filterImagePath = '../../../../../assets/filter-active.png';
          this.primaryTotalMonthValue = res[0].primary_total_month_value
          this.primaryTotalCurrentDayValue = res[0].primary_total_current_day_value;
          this.secondaryTotalMonthValue = res[0].secondary_total_month_value;
          this.secondaryTotalCurrentDayValue = res[0].secondary_total_current_day_value;
        }else{
          this.primaryTotalMonthValue = 0
          this.primaryTotalCurrentDayValue = 0;
          this.secondaryTotalMonthValue = 0;
          this.secondaryTotalCurrentDayValue = 0;
        }
        if((result["OTLNumber"] || result["cpnumber"]|| result["custNumber"]|| result["region"]|| result["salesperson_name"]|| result["state"])){
          this.filterImagePath = '../../../../../assets/filter-active.png';
        }else{
          this.filterImagePath = '../../../../../assets/filter.png';
        }
      });
     }
  })
}
filterDialog(){
    const dialog_ref = this.filter_dialog.open(DashboardFilterDialog, {
      autoFocus: false,
      width: "450px",
      data: {}
    })
    return dialog_ref;
  }

  loadPrimaryandSecondarySales()
  {
    this._dashboardService.getPrimarySecondarySales(res =>{
      if(res.length>0){
        this.primaryTotalMonthValue = res[0].primary_total_month_value
        this.primaryTotalCurrentDayValue = res[0].primary_total_current_day_value;
        this.secondaryTotalMonthValue = res[0].secondary_total_month_value;
        this.secondaryTotalCurrentDayValue = res[0].secondary_total_current_day_value;
      }else{
        this.primaryTotalMonthValue = 0
        this.primaryTotalCurrentDayValue = 0;
        this.secondaryTotalMonthValue = 0;
        this.secondaryTotalCurrentDayValue = 0;
      }
    })
  }
 
  multipleBarChartFormat(chartData) {
    let chartLabel;
    let reducedChartData = [];
      Object.keys(chartData).forEach((aggregatedData) => {      
      chartLabel = Object.keys(chartData[aggregatedData]);
      reducedChartData.push({ label:aggregatedData, data: Object.values(chartData[aggregatedData]) });
    });
    chartLabel = chartLabel.map((d) => { return this._utilService.toUpper(d); });
    return {label: chartLabel, data: reducedChartData};
  }

  barChartFormat(chartData) {
    let chartLabel = Object.keys(chartData).map((d) => { return this._utilService.toUpper(d); });
    return { label: chartLabel, data: [{ 'data': Object.values(chartData), 'label': 'Inventory DIO' }] }
  }
 
  loadDaysInventoryOutstandingForm(){

    
    this.daysinventoryForm = this.fb.group({
       OTLNumber: ['',this._formValidator.requireMatch], 
      partNumber: ['',this._formValidator.requireMatch],
      cpNumber: ['', this._formValidator.requireMatch]
    });
  }

  onChange(event)
  {
    if(event.index == '1' && this.tabflag1  == false)
    {
      this.SecondaryTrendLineComponents.loadSecondaryTrendLine();
      this.tabflag1  = true;
    }
    else if(event.index == '2' && this.tabflag2  == false)
    {
      this.PrimarySecondaryTrendLineComponents.loadPrimarySecondaryTrendLine()
      this.tabflag2  = true;
    }

  }

  findDaysInverstoryOutstanding(event)
  {
 
    this.flipFrontShow = false;
    this.flipFrontBack = true;
    let DaysInverstoryOutstanding = this.getPayload(this.daysinventoryForm.value);
    console.log(DaysInverstoryOutstanding);
    event.srcElement.firstChild.childNodes[0].classList.add("flip-card-rotate");
    this._dashboardService.filterInventoryDaysOutstanding(DaysInverstoryOutstanding, res =>{
      //res = [{days:123.4, total_value : 140008999}];
      this.inventoryOutStandingDate = res[0];
      });
  }

  getPayload(filterValue){    
    let params = new HttpParams();    
    let selectedOTLs =  this.daysinventoryForm.get('OTLNumber').value ? this.daysinventoryForm.get('OTLNumber').value : [];
    let selectedCPs =  this.daysinventoryForm.get('cpNumber').value ?  this.daysinventoryForm.get('cpNumber').value :[];
    let selectedParts =  this.daysinventoryForm.get('partNumber').value ? this.daysinventoryForm.get('partNumber').value :[];
    for(let i=0;i<selectedOTLs.length;i++){
      params = params.append('OTLNumber',  selectedOTLs[i].OTLnumber);
    } 
    for(let i=0;i<selectedCPs.length;i++){
      params = params.append('cpnumber',  selectedCPs[i].cpnumber);
    }  
    for(let i=0;i<selectedParts.length;i++){
      params = params.append('partNumber',  selectedParts[i].partNumber);
    } 
   // data['cpnumber'] = filterValue.cpNumber ? filterValue.cpNumber.cpnumber : '';
    //data['OTLNumber'] = filterValue.OTLNumber ?  filterValue.OTLNumber.OTLnumber : '';
    //data['partNumber'] = filterValue.partNumber ? filterValue.partNumber.partNumber : '';
    return params;
  }
  closeFilter()
  {
    this.flipFrontShow = true;
    this.myTestDiv.nativeElement.classList.remove("flip-card-rotate");
  }

  // start - set values for  filter fields
  setPartsList(){
    // need to change api  
    this._DashboardReportService.getListParts(this.role,(res) => {
      this.partList =res;
    });
  }

 
  setClientList(){
    this._bookingService.listHospital(res =>{
      this.clientNames =  this._utilsService.groupByMultipleKeys(res,['name','custNumber'])
    })
  }
  setOtlList(){
    this._bookingService.getListofOTLParts(res =>{
      this.otlList =  this._utilsService.groupByMultipleKeys(res,['name','OTLnumber'])
    })
  }
  setCities(){
    this._StockReportService.getCities(res=>{
      this.cityList = this._utilsService.getDistinctRecords(res,'name');
    })
  } 
  setSites(){
    this._StockReportService.getSiteId(res=>{
      this.siteIdList = res;
    })
  }
  setCpList(){
    this._bookingService.listChannelPartner(res=>{
      
      this.cpNames = this._utilsService.groupByMultipleKeys(res,['name','cpnumber'])   
     
    })
  }
// end - set values for  filter fields



navigateTo(report){
  if(report == "sales" ){
    window.open(this.routeName+'/reports/dashboard/sales-report', '_blank');
  }else if(report == "inventory" ){
    window.open(this.routeName+'/reports/dashboard/inventory-report', '_blank');
  }
}
getUserRole() {
  const currentUser = this._StorageService.getUserDetails();
  switch(currentUser.role) {
    case Roles.Admin:
      this.routeName = 'beckman'
      break;
    case Roles.Channel_Partner:
      this.routeName = 'channel-partner'
      break;
    case Roles.Agent:
      this.routeName = 'agent'
      break;
    
    default :
      this.routeName = 'beckman-billing'
      break;
  }
}
downloadReport(){
  let payload:any = this.getPayload(this.daysinventoryForm.value);
  payload = payload.append('is_export',  'true');
  payload = payload.append('is_table_view',  'true');
  this._DashboardReportService.exportInventoryReportFilter(payload);
}
 getPermissionMenu(){
    this._permissionMenuListService.getPermissionMenu(response =>{
      this.permissionMenu = response;
    })
  }

  loadReportsPermission(){
    this._permissionMenuListService.getActionPermission({model : 'reports'}, response =>{
      this.ExportInventoryPermission= response['reports'];    
    });
  }
  
  onOTLChange(value){
    this.daysinventoryForm.get('OTLNumber').setValue(value)
  }
  onCPChange(value){
    this.daysinventoryForm.get('cpNumber').setValue(value)
  }
  onPartChange(value){
    this.daysinventoryForm.get('partNumber').setValue(value)
  }
  formReset(){
    this.daysinventoryForm.reset();
  }
}

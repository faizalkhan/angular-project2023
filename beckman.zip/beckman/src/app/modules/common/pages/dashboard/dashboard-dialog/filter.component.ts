import { Component, OnInit, ViewEncapsulation, Inject,ChangeDetectorRef } from '@angular/core';
import { InvoiceService } from '../../../../beckman/service/invoice/invoice.service';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { LocationService } from 'src/app/core/services/utils/location.service';
import { OtlmasterService } from 'src/app/modules/beckman/service/hospital/otlmaster.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'view-dashboardfilter',
  templateUrl: 'filterdashboard-dialog.html',
  styles: [`.mat-dialog-container{
    padding : 0 !important;
    overflow: hidden;
}
.mat-dialog-content{
  padding: 0px;
  margin:0px;
}
.sidenav-bar {
  display: flex;
  justify-content: end;
  width: 305px;
  height:100%;
  
}
.sidenav-container {
  position: absolute;
  top: 0px;
  bottom: 0px;
 
  right: 0;
}
.close-icon
{
  color:#fff;
}
h6
{
  font-size: 1.1rem !important;
}
.cursor-pointer
{
  cursor:pointer
}
`],
  encapsulation: ViewEncapsulation.None
})

export class DashboardFilterDialog implements OnInit {

  public filterSearchForm : FormGroup;
  selectedRegions=[];
  selectedStates = [];
  selectedOTLs = [];
  selectedCPs = [];
  selectedCustomers =[] 
  selectedSalesPerson = [];
  public currentState =[];
  public currentCities = [];
  public otlList =[];
  public clientNames=[];
  public regionFromService= [];
  public groupedUserEmail;
  public salesPerson =[];
  cpNames = [];
  public isChannelPartner = false;
  public isAdmin = false;
  public displayChannelPartnerKeys = ['name', 'cpnumber']
  public displayChannelPartnerKeys1 = ['name', 'custNumber'];
  public displaychannelPartnerKeys2 = ['Name', 'issuanceBased']
  displaySalesPersonKeys = ['name', 'email']
  constructor( private _UtilsService : UtilsService, private _StorageService : StorageService,  private _otlMasterService: OtlmasterService, private _locationService: LocationService, private _bookingService: CpbookingService, private _formValidator: FormValidatorService, private fb: FormBuilder, private _utilsService : UtilsService, 
    public dialogRef: MatDialogRef<DashboardFilterDialog>, private cdRef : ChangeDetectorRef,
    @Inject(MAT_DIALOG_DATA) public data) { 
      this.loadSalesSearchForm();
      }

  ngOnInit() {

    this.isChannelPartner = this._UtilsService.isCpRole(this._StorageService.getUserDetails().role);
    console.log(this.isChannelPartner);
    this.isAdmin = this._UtilsService.isAdminRole(this._StorageService.getUserDetails().role);
    console.log(this.isAdmin);
    this.loadLocationData();
    this.setOtlList();
    this.setClientList();
    this.setCpList();
    this.groupedUserList();
  }

  dialogClose(): void {
    let SearchFilterPayload = this.getPayload(this.filterSearchForm.value);
    SearchFilterPayload['need_filter']=false;
    this.dialogRef.close(SearchFilterPayload);
  }

  filterClose(): void {    
    let SearchFilterPayload = this.getPayload(this.filterSearchForm.value);
    SearchFilterPayload['need_filter']=true;
    this.dialogRef.close(SearchFilterPayload);
  }

  getPayload(filterValue){
    let params = new HttpParams();
    for(let i=0;i<this.selectedRegions.length;i++){
      params = params.append('region',  this.selectedRegions[i]);
    }
    for(let i=0;i<this.selectedStates.length;i++){
      params = params.append('state',  this.selectedStates[i]);
    }
    for(let i=0;i<this.selectedOTLs.length;i++){
      params = params.append('OTLNumber',  this.selectedOTLs[i]);
    }    
    for(let i=0;i<this.selectedCPs.length;i++){
      params = params.append('cpnumber',  this.selectedCPs[i]);
    }    
    for(let i=0;i<this.selectedCustomers.length;i++){
      params = params.append('custNumber',  this.selectedCustomers[i]);
    }    
    for(let i=0;i<this.selectedSalesPerson.length;i++){
      params = params.append('salesman_email',  this.selectedSalesPerson[i]);
    }
    // let data =  {};
    // data['region'] = this.selectedRegions? JSON.stringify(this.selectedRegions) : [];
    // data['state'] =  filterValue.state ? filterValue.state.name : '';
    // data['cpnumber'] = filterValue.cpNumber ? filterValue.cpNumber.cpnumber : '';
    // data['OTLNumber'] = filterValue.OTLNumber ?  filterValue.OTLNumber.OTLnumber : '';
    // data['custNumber'] = filterValue.custNumber ? filterValue.custNumber.custNumber : '';
    // data['salesman_email'] = filterValue.salesperson_name ? filterValue.salesperson_name.email : '';
 
    return params;
  }

  SalesFilter()
  {
      
  }
  loadSalesSearchForm() {
    this.filterSearchForm = this.fb.group({
      region: ['',this._formValidator.requireMatch],
      state: ['',this._formValidator.requireMatch],
      cpNumber : [],
      salesperson_name: [''],
      OTLNumber : [''],
      custNumber: ['']

    });
  }

  groupedUserList(){
    this._otlMasterService.groupUserEmail(response =>{
      this.groupedUserEmail = response;
      this.salesPerson = [...response['Salesperson'], ...response['RegionalBusinessManager'], ...response['StateManager']];
     
    })
  }

  setOtlList(){
    this._bookingService.getListofOTLParts(res =>{
    this.otlList =  this._utilsService.groupByMultipleKeys(res,['name','OTLnumber'])
  })
}

loadLocationData() {
  //Location from Service call implementation
  this._locationService.getLocationData((locationData) => {
    this.regionFromService = locationData;
  });
}

  onRegionChange(value) {
    this.currentCities =[];
    this.currentState =[];
    this.selectedRegions =[]
    if (value) {
      for(let i=0;i<value.length;i++){
        this.selectedRegions.push(value[i].name)
        this.currentState = [ ...this.currentState,...value[i].states];
      }
    }
    this.filterSearchForm.patchValue({
      //region:selectedRegion,
      state : '',
      city : ''
    });
    
  }

  onStateChange(value) {
    this.currentCities =[];
    this.selectedStates = []
    this.filterSearchForm.patchValue({
      city : ''
    });
    if (value) {
      for(let i=0;i<value.length;i++){
        this.selectedStates.push(value[i].name)
        this.currentCities = [ ...this.currentCities,...value[i].cities];
      }
    }
  }
  onOTLChange(value){
    this.selectedOTLs =[];
    if (value) {
      for(let i=0;i<value.length;i++){
        this.selectedOTLs.push(value[i].OTLnumber)
      }
    }
  }
  onCPChange(value){
    this.selectedCPs =[];
    if (value) {
      for(let i=0;i<value.length;i++){
        this.selectedCPs.push(value[i].cpnumber)
      }
    }
  }
  onCustomerChange(value){
    this.selectedCustomers =[];
    if (value) {
      for(let i=0;i<value.length;i++){
        this.selectedCustomers.push(value[i].custNumber)
      }
    }
  }
  onSPChange(value){
    this.selectedSalesPerson =[];
    if (value) {
      for(let i=0;i<value.length;i++){
        this.selectedSalesPerson.push(value[i].email)
      }
    }
  }
  ngAfterViewInit(){
    this.cdRef.detectChanges()
  }

  setClientList(){
    this._bookingService.listHospital( res =>{
      this.clientNames =  this._utilsService.groupByMultipleKeys(res,['name','custNumber'])
    })
  }

  setCpList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpNames = this._utilsService.groupByMultipleKeys(res,['name','cpnumber'])   
    })
  }

  cancelFilter() {
 
    this.filterSearchForm.reset();
  }


}



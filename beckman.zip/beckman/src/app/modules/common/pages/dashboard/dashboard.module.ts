import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DashboardComponent } from './dashboard.component';
import { ChartModule } from 'src/app/core/modules/shared/chart/chart.module';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { DashboardFilterDialog } from './dashboard-dialog/filter.component';
const routes: Routes = [{ path: '', component: DashboardComponent}]

@NgModule({
  declarations: [
    DashboardComponent,
    DashboardFilterDialog
  ],
  
  entryComponents:[DashboardFilterDialog],

  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ChartModule,
    AppMaterialModule,
    FormsModule,
    ReactiveFormsModule,
    CustomFormsModule 
  ],
  providers:[]
})
export class DashboardModule { }

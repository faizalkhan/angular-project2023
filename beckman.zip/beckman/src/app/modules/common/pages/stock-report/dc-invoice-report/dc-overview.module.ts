import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { PipeModule } from 'src/app/core/pipe/pipe.module';
import { DcInvoiceReportComponent } from './dc-invoice-report.component';
import { Routes, RouterModule } from '@angular/router';
import { AgGridModule } from 'ag-grid-angular';

const routes: Routes = [{
  path:'', 
  component:DcInvoiceReportComponent ,
}]


@NgModule({
  declarations: [DcInvoiceReportComponent],
  imports: [
    CommonModule,
    AppMaterialModule,
    RouterModule.forChild(routes),
    AgGridModule.withComponents([]),
    CustomFormsModule,
    PipeModule
  ],
  exports :[CustomFormsModule, AgGridModule, DcInvoiceReportComponent]
})
export class DcOverviewModule { }

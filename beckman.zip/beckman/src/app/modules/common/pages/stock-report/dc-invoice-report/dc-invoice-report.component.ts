import { Component, OnInit, ViewEncapsulation, HostListener } from '@angular/core';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Roles } from 'src/app/modules/auth/model/user';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { StockReportService } from 'src/app/modules/common/service/stock-reports/stock-report.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { ActionItems } from 'src/app/core/services/constants';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { IGetRowsParams } from 'ag-grid-community';
import { OutboundService } from '../../../service/outbound/outbound.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { OtlmasterService } from 'src/app/modules/beckman/service/hospital/otlmaster.service';
import { syncService } from 'src/app/core/services/utils/sync.service';

@Component({
  selector: 'app-dc-invoice-report',
  templateUrl: './dc-invoice-report.component.html',
  styleUrls: ['./dc-invoice-report.component.css'],
  encapsulation:ViewEncapsulation.None

})
export class DcInvoiceReportComponent implements OnInit {
  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public gridData = [];
  public stockReportForm: FormGroup;
  public role;
  public isAdmin:boolean = false;
  public clientNames =[];
  public otlList =[];
  public opfList =[];
  public partList=[];
  public cpList=[];
  public pageSize = 10;
  public isChannelPartner;
  public stockReportPermission;
  public displayChannelPartnerKeys = ['name', 'cpnumber']
  public displayChannelPartnerKeys1 = ['name', 'custNumber']
  displaySalesPersonKeys = ['name', 'email']
  public isLoading:boolean = false;
  public isError:any = false;
  public groupedUserEmail;
  public salesPerson = [];
  constructor(private _StorageService: StorageService,private _permissionMenuListService: PermissionMenuListService, private _bookingService :CpbookingService, private _utilsService : UtilsService,
    private _formValidator: FormValidatorService, private fb: FormBuilder,private _StockReportService:StockReportService,private _momentService: MomentService, private _outboundService: OutboundService, private _PromptService: PromptService,
     private _otlMasterService: OtlmasterService, private _syncService : syncService) { }
    @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
    }

  ngOnInit() {
    this.loadStockReportForm();

  

    this.role = this._StorageService.getUserDetails().role;

    this.isAdmin =this._utilsService.isAdminRole(this.role);

    this.isChannelPartner = this._utilsService.isCpRole(this.role);
    this.groupedUserList();
    // calling filters api 
    this.setClientList();
    this.setPartsList();
    this.setOtlList();
    this.setCPList();
    this._syncService.getDCSync().subscribe(res =>  this.isLoading = res)
    this._syncService.getErrorDCSync().subscribe(res =>  this.isError = res )

    
    this.defaultColDef = {
      sortable: true,
      filter: true,
      resizable: true,
 
    };
    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2
    };

    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: "",
        headerName: 'S No.',
        width: 100,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
        suppressSizeToFit: true
      },
      {
        headerName: 'OTL No.',
        field: "OTLNumber",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true
      },
      {
        headerName: 'End Customer Number',
        field: "custNumber",
        width: 200, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true
      },
      {
        headerName: 'End Customer Name',
        field: "custName",
        width: 300, 
        suppressSizeToFit: true
      },
      {
        headerName: 'CP Number',
        field: "cpNumber",
        width: 200, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true
      },  
      {
        headerName: 'CP Name',
        field: "cp_name",
        width: 350, 
        suppressSizeToFit: true
      },

      {
        headerName: 'DC Created Date',
        field: 'created_on',
        valueFormatter : this.formatDate.bind(this),
        width: 250,
        suppressSizeToFit: true,
      },

      {
        headerName: 'DC No.',
        field: "dcNumber",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true
      },
        
      {
        headerName: 'Type',
        field: "dc_type",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true
      },
      {
        headerName: 'Item No',
        field: "partNumber",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true
      },
        
     
    
      {
        headerName: 'Lot No.',
        field: "lotNumber",
        width: 150, 
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },

      {
        headerName: 'Lol Exp Date',
        field: 'lotExpiryDate',
        valueFormatter : this.formatDate.bind(this),
        width: 250,
        suppressSizeToFit: true,
      },

      {
        headerName: 'Dc Qty',
        field: "total_dc_quantity",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'Invoice status',
        field: "invoice_status",
        width: 200, 
        suppressSizeToFit: true
      },

  

      {
        headerName: 'Invoice Number',
        field: "invoiceNumber",
        width: 200, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true
      },

      {
        headerName: 'Invoice Created Date',
        field: 'invoice_created_on',
        valueFormatter : this.formatDate.bind(this),
        width: 250,
        suppressSizeToFit: true,
      },
      {
        headerName: 'Invoice Qty',
        field: "total_invoiced_quantity",
        width: 200, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true
      },
      {
        headerName: 'Invoice Line Value',
        field: "invoice_total_amount_with_out_tax",
        width: 200, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true
      },

      {
        headerName: 'DC Pending Qty to be invoiced',
        field: "dc_pending_qty",
        width: 200, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true
      },
  
      {
        headerName: 'Salesperson Name',
        field: "salesperson_name",
        width: 350, 
        suppressSizeToFit: true
      }   
     
    ];
    this.loadReportsPermission()
  }
  setActionsPermission(name){
        return this.stockReportPermission && typeof this.stockReportPermission[ActionItems[name]] != 'undefined'  ?  true : false;

 }

 loadReportsPermission(){
  this._permissionMenuListService.getActionPermission({model : 'appreport'}, response =>{
    this.stockReportPermission= response['appreport'];    
  });
}
generateListNow() {

  this._syncService.setDCSync(true);
 
  this._outboundService.generateNowDC(res => {  
 
       if(res.success === true)
       {
         this._syncService.setDCSync(false);
         this.getStockOverviewReportList(); 
       }
      else
      {     
       this._syncService.setDCSync(false);
       this._syncService.setErrorDCSync(true);    
      }
   
   });    
    
 }

formatDate(params){
  return  params.data? this._momentService.getDate(params.data.created_on):'';
}

  // start - set values for  filter fields
  setPartsList(){
    this._StockReportService.getListParts(this.role,(res) => {
      this.partList =res;
    });
  }

  setClientList(){
    this._bookingService.listHospital( res =>{
      this.clientNames =  this._utilsService.groupByMultipleKeys(res,['name','custNumber'])
    })
  }
  setOtlList(){
    this._bookingService.getListofOTLParts(res =>{
      this.otlList =  this._utilsService.groupByMultipleKeys(res,['name','OTLnumber'])
    })
  }

  setCPList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpList = this._utilsService.groupByMultipleKeys(res,['name','cpnumber'])   
    })
  }
// end - set values for  filter fields

groupedUserList(){
  this._otlMasterService.groupUserEmail(response =>{
    this.groupedUserEmail = response;
    this.salesPerson = [...response['Salesperson'], ...response['RegionalBusinessManager'], ...response['StateManager']];
  
  })
}
onGridReady(params) {
  this.gridApi = params.api;
  this.gridColumnApi = params.columnApi;
  this.gridApi.sizeColumnsToFit();
  this.getStockOverviewReportList()
}

getStockOverviewReportList(){

  let data = {
    created_on_start_date : this._momentService.getFilterFormat(this.stockReportForm.get('from_date').value),
    created_on_end_date : this._momentService.getFilterFormat(this.stockReportForm.get('to_date').value, "toDate"),
  }
return this.getCPList(data);
}
getCPList(data?: any){
  
  let payload = {};
  var datasource = {
    getRows: (params: IGetRowsParams) =>{
      if (data) {
        payload = data;
      }
      this.onBtShowLoading();
      payload['page_size'] =this.pageSize
      payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
      payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
      payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
      this._StockReportService.searchGetDCInvoiceReport(data,(res)=>{
         if((res.results).length > 0){
          let length = res['total'];
          this.gridData = res['results'];
          console.log(this.gridData,'-203-');
          this.onBtHide();
          console.log(res['results']);
          params.successCallback(res['results'], length)
         }
         else
         {
          this.onBtShowNoRows(); 
         }
        })
    }
  }
    this.gridApi.setDatasource(datasource);
}

  loadStockReportForm(){
    this.stockReportForm = this.fb.group({
      from_date:[this._momentService.deceedDate(new Date(),31)],
      to_date:[new Date()],
      status:[null],
      custNumber: ['', this._formValidator.requireMatch],
      cpNumber: ['', this._formValidator.requireMatch], 
      OPFNumber: [''],
      OTLNumber: ['', this._formValidator.requireMatch],
      partNumber: ['', this._formValidator.requireMatch],
      invoiceNumber : [''],
      dcNumber : [],
      salesman_email :  [''],
    },{ validator: this._formValidator.dateValidation('from_date', 'to_date') });
  }


  exportStockReport(){
    let paylaod =  this.getPayload(this.stockReportForm.value);
    paylaod['is_export'] = true;
    this._StockReportService.exportDCReportFilter(paylaod);
  }
  getPayload(formValue){ 
    let data =  {};
    //Success Scenario

     data['created_on_start_date'] = formValue.from_date ? this._momentService.getFilterFormat(formValue.from_date) : '';
     data['created_on_end_date'] = formValue.to_date ? this._momentService.getFilterFormat(formValue.to_date, "toDate") : '';   
     data['custNumber'] =  formValue.custNumber ? formValue.custNumber.custNumber : '';
     data['invoiceNumber']  =  formValue.invoiceNumber ? formValue.invoiceNumber : '';
     data['OTLNumber'] = formValue.OTLNumber ? formValue.OTLNumber.OTLnumber : '';
     data['partNumber'] =formValue.partNumber ? formValue.partNumber.partNumber : '';
     data['cpNumber'] = formValue.cpNumber ? formValue.cpNumber.cpnumber : ''; 
     data['invoicedStatus'] = formValue.status ? formValue.status : ''; 
     data['dcNumber'] = formValue.dcNumber ? formValue.dcNumber : '';
     data['salesperson_email'] = formValue.salesman_email ? formValue.salesman_email.email: ''
    return data;
    }
  

  searchStockReport(){

    if (this.stockReportForm.valid){
      let invoiceFilterValues = this.getPayload(this.stockReportForm.value);
      return this.getCPList(invoiceFilterValues);
      }
    }
  cancelStockReport(){ 
    this.stockReportForm.reset();
    this.stockReportForm.get('from_date').setValue(this._momentService.deceedDate(new Date(),31));
    this.stockReportForm.get('to_date').setValue(new Date())
    this.getStockOverviewReportList();
  }
  RoundOFTwoDigit(num: any){
    var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
    return number;
  }
  onBtShowLoading() {
    this.gridApi.showLoadingOverlay();
  }
  
  onBtShowNoRows() {
    this.gridApi.showNoRowsOverlay();
  }
  
  onBtHide() {
    this.gridApi.hideOverlay();
  }

}


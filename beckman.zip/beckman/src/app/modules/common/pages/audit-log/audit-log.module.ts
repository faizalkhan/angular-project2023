import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { RouterModule, Routes } from '@angular/router';
import { AgGridModule } from 'ag-grid-angular';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { PipeModule } from 'src/app/core/pipe/pipe.module';
import {OtlsAuditComponent} from './otls-audit/otls-audit.component';
import {OpfAuditComponent} from './opf-audit/opf-audit.component';
import {OtlPartsAuditComponent} from './otl-parts-audit/otl-parts-audit.component';
import {SecondaryInvoiceAuditComponent} from './secondary-invoice-audit/secondary-invoice-audit.component';
import {PartsAuditComponent} from './parts-audit/parts-audit.component';
import { HospitalComponent } from './hospital/hospital.component';
import { SecondaryDcComponent } from './secondary-dc/secondary-dc.component';
import { SecondaryCreditDebitComponent } from './secondary-credit-debit/secondary-credit-debit.component';
import { StockTransferComponent } from './stock-transfer/stock-transfer.component';

const routes: Routes = [{
  path:'', 
  component:OtlsAuditComponent
},{
  path:'otls', 
  component:OtlsAuditComponent
},{
  path:'parts', 
  component:PartsAuditComponent
},{
  path:'opf', 
  component:OpfAuditComponent
},{
  path:'otl-parts', 
  component:OtlPartsAuditComponent
},{
  path:'secondary-invoice', 
  component:SecondaryInvoiceAuditComponent
},{
  path:'secondary-dc', 
  component:SecondaryDcComponent
},{
  path:'secondary-credit-debit', 
  component:SecondaryCreditDebitComponent
},{
  path:'stock-transfer', 
  component:StockTransferComponent
},{
  path:'hospitals', 
  component:HospitalComponent
}]

@NgModule({
  declarations: [OtlsAuditComponent,PartsAuditComponent,OpfAuditComponent,OtlPartsAuditComponent,HospitalComponent,SecondaryInvoiceAuditComponent, HospitalComponent, SecondaryDcComponent, SecondaryCreditDebitComponent, StockTransferComponent],
  imports: [
    CommonModule,
    AppMaterialModule,
    RouterModule.forChild(routes),
    AgGridModule.withComponents([]),
    CustomFormsModule,
    PipeModule
  ],
  exports :[OtlsAuditComponent,PartsAuditComponent,OpfAuditComponent,OtlPartsAuditComponent,HospitalComponent,SecondaryInvoiceAuditComponent]
})
export class AuditLogModule { }

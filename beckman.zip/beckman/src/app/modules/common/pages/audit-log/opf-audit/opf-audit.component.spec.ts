import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpfAuditComponent } from './opf-audit.component';

describe('OpfAuditComponent', () => {
  let component: OpfAuditComponent;
  let fixture: ComponentFixture<OpfAuditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OpfAuditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpfAuditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

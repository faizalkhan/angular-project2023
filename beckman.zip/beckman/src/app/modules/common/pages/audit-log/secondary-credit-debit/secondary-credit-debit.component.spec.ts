import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecondaryCreditDebitComponent } from './secondary-credit-debit.component';

describe('SecondaryCreditDebitComponent', () => {
  let component: SecondaryCreditDebitComponent;
  let fixture: ComponentFixture<SecondaryCreditDebitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecondaryCreditDebitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecondaryCreditDebitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

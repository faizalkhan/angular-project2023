import { Component, OnInit, HostListener  } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { AuditService } from '../service/audit.service';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { IGetRowsParams } from 'ag-grid-community';

@Component({
  selector: 'app-secondary-invoice-audit',
  templateUrl: './secondary-invoice-audit.component.html',
  styleUrls: ['./secondary-invoice-audit.component.css']
})
export class SecondaryInvoiceAuditComponent implements OnInit {
  public pageSize = 10;
  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public gridData = [];
  public auditForm: FormGroup;
  public role;
  public cpList = [];
  public otlReportPermission;
  public isChannelPartner;
 public allColumnIds =[];
 public custNameList = [];
 public displayChannelPartnerKeys = ['name', 'cpnumber']
 public displayChannelPartnerKeys1 = ['name', 'custNumber'];
  constructor(private _StorageService: StorageService,private _bookingService: CpbookingService, private _formValidator: FormValidatorService, private _permissionMenuListService: PermissionMenuListService,
    private fb: FormBuilder, private _AuditService:AuditService,private _utilsService : UtilsService, private _momentService: MomentService
    ) { }
  @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
    }
  ngOnInit() {
    this.role = this._StorageService.getUserDetails().role;
    this.isChannelPartner = this._utilsService.isCpRole(this.role);
    this.loadauditForm();
    this.setClientList();
    this.setCPList();
    // calling filters api 
    this.defaultColDef = {
      sortable: true,
      filter: true,
      resizable: true,
    };
    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2
    };

    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: "",
        headerName: 'S No.',
        width: 60,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
        suppressSizeToFit: true,
      },
      {
        headerName: 'Invoice Number',
        field: "ref_no",
        width: 250,
        suppressSizeToFit: true,       
      },
      {
        headerName: 'Client Name',
        field: "cust_name",
        width: 250,
        suppressSizeToFit: true,       
      },
      {
        headerName: 'CP Number',
        field: "cpnumber",
        width: 250,
        suppressSizeToFit: true,       
      },
      {
        headerName: 'Action By',
        field: "updated_user_email",
        width: 300,
        suppressSizeToFit: true,       
      },
      {
        headerName: 'Role',
        field: "role",
        width: 170,
        suppressSizeToFit: true,
        },
        {
          headerName: 'Date and Time',
          field: "updated_on",
          width: 250, 
          suppressSizeToFit: true,
        },
        {
          headerName: 'Status',
          field: "action",
          width: 250,
          suppressSizeToFit: true,
        }, {
          headerName: 'Field Name',
          field: "key",
          width: 170,
          suppressSizeToFit: true,
        },
        {
          headerName: 'Actual Value',
          field: "existing_value",
          width: 110,
          suppressSizeToFit: true,
        }, 
        {
          headerName: 'Edited Value',
          field: "updated_value",
          width: 120,
          suppressSizeToFit: true,
        }
    ];
    this.loadReportsPermission()
  }

  formatDate(params){
    return params.data ? this._momentService.getDate(params.data.swapTransferDateAndTime) : ''
  }
 loadReportsPermission(){
  this._permissionMenuListService.getActionPermission({model : 'reports'}, response =>{
    this.otlReportPermission= response['reports'];    
  });
}

  onGridReady(params) {
   var allColumnIds =[];
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit()
    this.searchAuditList();
  }
// end - set values for  filter fields
  loadauditForm(){
    this.auditForm = this.fb.group({
      from_date:[this._momentService.deceedDate(new Date(),31)],
      to_date:[new Date()],
      partNumber: ['',this._formValidator.requireMatch],
      OTLNumber: ['',this._formValidator.requireMatch],
      invoiceNumber:[''],
      custNumber:[''],
      cpNumber : ['', this._formValidator.requireMatch],
      site_id:[''],
      search_key: [''],
    },{ validator: this._formValidator.dateValidation('from_date', 'to_date') });
  }
  setCPList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpList = this._utilsService.groupByMultipleKeys(res,['name','cpnumber'])   
    })
  }
  exportStockReport(){
    let paylaod =  this.getOTLPayload(this.auditForm.value);
    paylaod['is_export'] = true;
    this._AuditService.exportAuditData(paylaod,"Secondary Invoice-Audit-Log.csv");
  }
  setClientList(){
    this._bookingService.listHospital( res =>{
      this.custNameList = this._utilsService.groupByMultipleKeys(res,['name','custNumber'])
    })
  }

  getOTLPayload(data){
    let otlPayload ={
      from_date :  this.auditForm.value.from_date ?  this._momentService.getFilterFormat(this.auditForm.value.from_date) : '',
      to_date :  this.auditForm.value.to_date ?  this._momentService.getFilterFormat(this.auditForm.value.to_date, "toDate") : ''
    };
    //otlPayload['part_number'] = data.partNumber ? data.partNumber : '';
    //otlPayload['otl_number'] = data.OTLNumber ?  data.OTLNumber : '';
    otlPayload['invoiceNumber'] = data.invoiceNumber ?  data.invoiceNumber : '';
    otlPayload['custNumber'] = data.custNumber ?  data.custNumber.custNumber : '';
    otlPayload['cpnumber'] = data.cpNumber ?  data.cpNumber.cpnumber : '';
    //otlPayload['custName'] = data.custNumber ?  data.custNumber.name : '';
    otlPayload['site_id'] = data.site_id ? data.site_id : '';    
    otlPayload['search_key'] = data.search_key ? data.search_key : '';   
    otlPayload['log_type'] = "client_invoice";
    return otlPayload;
  }
  searchAuditList(){
    let data =  this.getOTLPayload(this.auditForm.value);  
     let payload = {};
    var datasource = {
      getRows: (params: IGetRowsParams) =>{
        if (data) {
          payload = data;
        }
          this.onBtShowLoading();
        payload['page_size'] =this.pageSize
        payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
        payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
        payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
        
        this._AuditService.searchAuditData(payload,(res)=>{
          if((res.results).length > 0){
            let length = res['total'];
            this.gridData = res['results'];
            console.log(this.gridData,'-203-');
            this.onBtHide();
            console.log(res['results']);
            params.successCallback(res['results'], length)
           }
           else
           {
            this.gridData = res['results'];
            console.log("no data found");
            this.onBtShowNoRows(); 
           }
          })
      }
    }
      this.gridApi.setDatasource(datasource);
  }
  cancelStockReport(){
    this.auditForm.reset();
    this.auditForm.get('from_date').setValue(this._momentService.deceedDate(new Date(),31));
    this.auditForm.get('to_date').setValue(new Date());   
    this.searchAuditList();
  }

  onBtShowLoading() {
    this.gridApi.showLoadingOverlay();
  }
  
  onBtShowNoRows() {
    this.gridApi.showNoRowsOverlay();
  }
  
  onBtHide() {
    this.gridApi.hideOverlay();
  }





}

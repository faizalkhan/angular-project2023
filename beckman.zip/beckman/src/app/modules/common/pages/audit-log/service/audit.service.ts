import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { HttpService } from 'src/app/core/services/http/http.service';
import { Endpoints, ApiMethod, SuccessMessage, colorCodes } from 'src/app/core/services/constants';
import { Roles } from 'src/app/modules/auth/model/user';
@Injectable({
  providedIn: 'root'
})
export class AuditService {
  constructor(private _http: HttpService, private _snackBar: SnackbarService,private _router: Router) { }


  searchAuditData(payload,successResponseCallback){
    this._http.requestCall(Endpoints.GET_AUDIT_LIST,ApiMethod.GETPARAMS,payload).subscribe(
      (res) => {
        successResponseCallback(res);
      });
  }
  
exportAuditData(payload, reportName){
  this._http.requestCall(Endpoints.GET_AUDIT_LIST,ApiMethod.DOWNLOAD_PARAMS,payload).subscribe(
    (res) => {
      var downloadLink = document.createElement("a");
      const blob = new Blob([res], { type: 'text/csv' });
      const url= window.URL.createObjectURL(blob);
      downloadLink.href = url;
      downloadLink.download = reportName;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      this._snackBar.loadSnackBar(SuccessMessage.EXPORT_AUDIT_LIST, colorCodes.SUCCESS);
      return false;
    },
    (error) => {
      console.log(error);
    }
  );
}

}
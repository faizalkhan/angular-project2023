import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtlPartsAuditComponent } from './otl-parts-audit.component';

describe('OtlPartsAuditComponent', () => {
  let component: OtlPartsAuditComponent;
  let fixture: ComponentFixture<OtlPartsAuditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtlPartsAuditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtlPartsAuditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecondaryInvoiceAuditComponent } from './secondary-invoice-audit.component';

describe('SecondaryInvoiceAuditComponent', () => {
  let component: SecondaryInvoiceAuditComponent;
  let fixture: ComponentFixture<SecondaryInvoiceAuditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecondaryInvoiceAuditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecondaryInvoiceAuditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

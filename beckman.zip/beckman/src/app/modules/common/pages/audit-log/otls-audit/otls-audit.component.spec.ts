import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtlsAuditComponent } from './otls-audit.component';

describe('OtlsAuditComponent', () => {
  let component: OtlsAuditComponent;
  let fixture: ComponentFixture<OtlsAuditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtlsAuditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtlsAuditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

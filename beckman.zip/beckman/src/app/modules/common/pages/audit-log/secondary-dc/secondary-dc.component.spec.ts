import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecondaryDcComponent } from './secondary-dc.component';

describe('SecondaryDcComponent', () => {
  let component: SecondaryDcComponent;
  let fixture: ComponentFixture<SecondaryDcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecondaryDcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecondaryDcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

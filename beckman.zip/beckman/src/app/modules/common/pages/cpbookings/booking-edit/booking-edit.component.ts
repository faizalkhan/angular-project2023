import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { MatDialog } from '@angular/material';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { StockService } from 'src/app/modules/cpadmin/service/stock.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';

import { ListShippingAddressDialog, PartsDialog } from 'src/app/modules/common/dialogs/booking-dialog';
import { requiredFileType } from 'src/app/core/services/formValidator/upload-file-validator';
import { colorCodes, OPF_Type_Value, BILLING, SHIPPING, ErrorMessage, BECKMAN_GODOWN, OTL_params, OPF_type, BookingStatus, SuccessMessage, ActionItems } from 'src/app/core/services/constants';
import { Roles } from 'src/app/modules/auth/model/user';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { HospitalService } from '../../../../beckman/service/hospital/hospital.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';

@Component({
  selector: 'app-booking-edit',
  templateUrl: './booking-edit.component.html',
  styleUrls: ['./booking-edit.component.css']
})
export class BookingEditComponent implements OnInit {
  public bookingId ;
  public bookingData; 
  public date =new Date ();
  public displayClientKeys = ['name','address','city','pincode']
  public opfForm: FormGroup;
  public clientNames = [];
  public cpDetails;
  public clientNumber;
  public otlList = [];
  public otlPartsList = [];
  public partsData = [];
  public subTotal = 0;
  public netAmount = 0;
  public totalTax = 0;
  public regionalId = '';
  public salesId = '';
  public shipDetails ; // current shipping address
  public billingDetails ;
  public attachmentData = new FormData();
  public iGst:boolean;
  public partsCurrentOptions = [];
  public viewOPF = false;
  public attachmentArray =[];
  public othersFoc:boolean = false;
  public billingList = [];
  public shippingList = [];
  public onSubmit = false  //   used to avoid multiple times of OPF creation 
  public isOltNoActive = false;
  public reset = false;
  public invalidParts = '';
  public opfStatus;
  public clickingGetDetails =false;
  public isAdmin = false;

  constructor(private fb: FormBuilder,public _dialog: MatDialog, private _bookingService: CpbookingService, private _formValidator: FormValidatorService, public _utilsService : UtilsService
   ,private _snackBar :SnackbarService, private _stockService:StockService,public _hospitalService:HospitalService,private _StorageService: StorageService, 
    public route: ActivatedRoute) { }

  ngOnInit() {
    this.loadBookingForm();
    this.isAdmin = this._utilsService.isAdminRole(this._StorageService.getUserDetails().role);

    this._bookingService.getActionPermission({model : 'opf'},response =>{ 
      if (typeof response['opf'][ActionItems['EDIT']] == 'undefined') this.cancelOpf();
    })
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.bookingId = parseInt(params.get('id'));
      this.getOPFdetails();
    });

    // attachments
    this.opfForm.get('attachment').valueChanges.subscribe(res => {
      if (this.opfForm.get('attachment').errors && this.opfForm.get('attachment').errors.requiredFileType){
        this._snackBar.loadSnackBar('Please attach (pdf ,png ,jpg) file', colorCodes.ERROR);
      }
    })
  }
 
  getOPFdetails(){
    this._bookingService.viewBooking(this.bookingId,
      (response) => {
        this.bookingData = response; 
        if (response.status == "Cancelled" || response.status == "Rejected" || (!this.isAdmin && response.isInvoiced)) this.cancelOpf();
        else{
          this.setBookingForm(response);
          this.opfForm.get('type').setValue(OPF_Type_Value[response.type]) 
          this.getDistinctHospitals();
          this.getCpDetail();
        } 
      },
      (error) => console.log(error))
  }

  loadBookingForm() { 
    this.opfForm = this.fb.group({
      OPFNumber: [{value : '' , disabled : true }],
      clientPOnumber: [''],
      custName: ['', [Validators.required, this._formValidator.requireMatch]],
      custNumber: ['', Validators.required],
      OTLNumber: ['', [Validators.required, this._formValidator.requireMatch]],
      site_id: ['', Validators.required],
      type: ['', Validators.required],
      transcationType: ['', Validators.required],
      priority: ['', Validators.required],
      comment: [''],
      attachment:['',  [requiredFileType(["jpg", "png", "pdf"])] ],
      regionalBranchName:[''],
      salesManagerName:[''],
      invoiceNumber:[{value : '' , disabled : true }],
      cpnumber:[''],
      cfNumber:[{value : '' , disabled : true }],
      oracleOrderNumber:[''],
      oracleStatus:[''],
      orderAgainRef:[''],
      rejectReason:['']
    })
  }
  // -------------------setBooking and autocomplete section -----------------------
  setBookingForm(response){
    this.billingDetails = response.address.find(address => address.type === BILLING );
    this.shipDetails = response.address.find(address => address.type === SHIPPING );
    this.opfForm.patchValue({
      clientPOnumber: response.clientPOnumber,
      transcationType:response.transcationType.toLowerCase(), 
      priority:response.priority ? 'standard' : '',
      comment: response.comment,
      regionalBranchName :response.regionalBranchName,
      salesManagerName :   response.salesManagerName,
      OPFNumber : response.OPFNumber,
      invoiceNumber : response.invoiceNumber ,
      cpnumber:response.cpnumber,
      cfNumber:response.cfNumber,
      oracleOrderNumber:response.oracleOrderNumber ? response.oracleOrderNumber  : '',
      oracleStatus:response.oracleStatus ?response.oracleStatus:'',
      orderAgainRef:response.orderAgainRef ?response.orderAgainRef:'',
      rejectReason:response.rejectReason ?response.rejectReason:'',
    });
    
    
    //disbaling all the fields for FOC -other
      this.disableFields()
    this.checkTax();
  }

  disableFields(){
    if ((OPF_Type_Value[this.bookingData.type] != 'OTL' && OPF_Type_Value[this.bookingData.type] != 'FOC') || this.bookingData.isInvoiced){
      this.opfForm.get('custName').disable();
      this.opfForm.get('OTLNumber').disable();
      if (this.bookingData.isInvoiced) this.opfForm.get('type').disable();
    }
  }
  getDistinctHospitals(){
    // this._hospitalService.searchHospital({cpnumber : this.bookingData.cpnumber} ,Roles.Channel_Partner, response =>{

    this._hospitalService.searchHospital({cpnumber : this.bookingData.cpnumber,"opf_type":this.opfForm.get('type').value == 'FOC'? OTL_params.FOC : this.opfForm.get('type').value } , response =>{
      this.clientNames = response
      let cilentName =   this.clientNames.find((res) => {
        return res.custNumber == this.bookingData.custNumber && res.site_id == this.bookingData.site_id  ;
      });
      this.opfForm.get('custName').setValue(cilentName);
      this.onClientChange(cilentName);
    },Roles.Channel_Partner)
  }


 

 
  onClientChange(value, otlNo?:any) {
    this.opfForm.patchValue({
      OTLNumber: '',
      site_id: '',
      custNumber: ' '
    })
    this.partsData = [];
    this.otlList = [];
    this.netAmount = 0;
    this.totalTax = 0;
    this.subTotal = 0;
    this.opfForm.get('regionalBranchName').setValue('')
    this.opfForm.get('salesManagerName').setValue('')
    if (value) {
      this._bookingService.validateHospital({"site_id": value.site_id,"custNumber" :value.custNumber }, (response)=>{
        this.opfForm.get('custNumber').setValue(value.custNumber);
        this.opfForm.get('site_id').setValue(value.site_id);
        //set OTL
        this._stockService.getOtl({ "site_id": value.site_id, "order_by":"otl_number", "opf_type":this.opfForm.get('type').value == 'FOC'? OTL_params.FOC : this.opfForm.get('type').value }, (response) => {
          this.otlList = response;
          if (!this.opfForm.get('custName').touched || this.reset) {
            let currentOTL = response.find(res => res.OTLnumber === this.bookingData['OTLNumber']);
            this.opfForm.get('OTLNumber').setValue(currentOTL);
            this.onOtlChange(currentOTL);
          }
          // setting OTL  for NCMS order after touched 
          if(this.opfForm.get('invoiceNumber').value && this.opfForm.get('invoiceNumber').touched) {
            this.otlList.filter((res) => {
              if (res.OTLnumber === otlNo) {
               this.onOtlChange(res)
              }
            })
          }
        });
    });
    }else{
      this._snackBar.loadSnackBar(" You don't have a permission to raise OPF,Since  hospital is Inactive", colorCodes.ERROR);
      this.cancelOpf();
    }
  }
  onOtlChange(value) {
    this.partsData = [];
    this.isOltNoActive = false;
    this.netAmount = 0; 
    this.totalTax = 0;
    this.subTotal = 0;
    
    
    if (value) {
      this._bookingService.validateOtl({"site_id": value.site_id,"OTLNumber" :value.OTLnumber }, (response)=>{ 
        this.isOltNoActive = true;
       
        
      this._bookingService.getOtlPartsOpf({ "OTLNumber": value.OTLnumber,"opf_type":this.opfForm.get('type').value == 'FOC'? OTL_params.FOC : this.opfForm.get('type').value, "order_by": "name"}, (response) => {
        
         if(!this.opfForm.get('OTLNumber').touched  || this.reset) {
            //updating regional ID 
          this.upDateRegionalSalesId('');
           // add parts dialog list
          if (!this.opfForm.get('invoiceNumber').value) this.otlPartsList = response;
          else  this.getNcmsPartsList(value);
           
           //update original OTL parts price to each parts based on admin OTL parts price 
           this.updateOTLPartsPrice(this.bookingData['parts']);
        }else if(this.opfForm.get('invoiceNumber').value) {
          this.upDateRegionalSalesId(value);
           // add parts dialog partlist 
           this.getNcmsPartsList(value);
        }
        else{
          this.upDateRegionalSalesId(value);
          this.otlPartsList = response;
        }
      });
    }); 
    }
  }

  getNcmsPartsList(value){
    this.othersFoc = true;
    this.opfForm.get('OTLNumber').setValue(value);
    this._bookingService.getInvoiceDetails(this.opfForm.get('invoiceNumber').value, (invoiceDetails) => { 
      this.otlPartsList =  invoiceDetails['parts']
     });

  }
  upDateRegionalSalesId(value){
    this.regionalId =value ?value['regionalBranchEmailid'] : this.bookingData['regionalBranchEmailid'];
    this.opfForm.get('regionalBranchName').setValue(value ?value['regional_name'] :this.bookingData['regionalBranchName'] ) ;
    this.opfForm.get('salesManagerName').setValue(value ? value['sales_name'] :this.bookingData['salesManagerName'] ) ;
    this.salesId =value ? value['salesEmail'] :  this.bookingData['salesManagerEmailid'];
  
}

updateOTLPartsPrice(partsData){ 
//   let bookingParts = this.bookingData['parts'].filter(part => {
//     return response.find(res =>{
//       if (res['partNumber'] == part['partNumber'] && res['OTLNumber'] == otlField.OTLnumber ) {
//         if (res['isActive'] == 1) {
//          part['HSSNtax'] = res['HSSNtax']
//          part['HSSNcode'] =  res['HSSNcode']
//          part['price'] =  res['price']
//          part['discount'] = res['discount']
//          part['total_amount'] = Number((res['price'] * part['quantity'] - ((res['price'] * part['quantity']) * res['discount'])/100).toFixed(2)) ;
//          part['cgst'] = Number(((part['total_amount']*(res['HSSNtax']/2))/100).toFixed(2)); 
//          part['sgst'] = Number(((part['total_amount']*(res['HSSNtax']/2))/100).toFixed(2)); 
//          part['igst'] = Number(((part['total_amount']*res['HSSNtax'])/100).toFixed(2)); 
//           return part;
//         }else{
//           this.invalidParts += res['partNumber'] + '-'
       
//         }
        
//       }

//     })
//  })
             
//  if (this.invalidParts)  this._snackBar.loadSnackBar( this.invalidParts +  ErrorMessage.IN_ACTIVE_PARTS, colorCodes.ERROR);
if (!this.clickingGetDetails) {
  this.partsData = JSON.parse(JSON.stringify(partsData));
 this.loadPartsTable(this.partsData);
 this.reset = false;
}
 
}

//--------------Dialog section---------------
 //add parts
 loadPartsDialog() {
  this.partsCurrentOptions= !this.partsData.length ? this.otlPartsList : this.otlPartsList.filter(otlPart => !this.partsData.find(part =>otlPart['partNumber'] === part['partNumber'] ));
  let dialogRef = this.openPartsDialog(this.partsCurrentOptions);
  dialogRef.afterClosed().subscribe(result => {
    if (result && Object.keys(result).length > 0) {
        result['newPart'] = true;
      this.partsData.push(result);
    }
    this.loadPartsTable(result)
  });
}

editParts(index) {
  // to get avaiable qty of the part 
  if (this.bookingData.type == 'OTL' || this.bookingData.type == OPF_type['FOC']) {
    this._bookingService.getOpfPartsQty({'cpnumber' : this.opfForm.get('cpnumber').value, 'partNumber' : this.partsData[index].partNumber, 'OTLNumber': this.opfForm.get('OTLNumber').value.OTLnumber,'opf_type' : this.opfForm.get('type').value == 'FOC' ? OTL_params[this.opfForm.get('type').value ]  :this.opfForm.get('type').value }, response => {
      this.partsData[index]['ncmsAvailableQty'] = response['available_quantity'];
      this.loadEditPartsDialog(index);
    })
  }else{
    this.partsData[index]['ncmsAvailableQty'] = this.otlPartsList.find(res => res['partNumber'] ==this.partsData[index]['partNumber'] )['netInvoicedQty']
    this.loadEditPartsDialog(index);
  }
 
  }

  loadEditPartsDialog(index){
    let dialogRef = this.openPartsDialog(this.otlPartsList, this.partsData[index]);
    dialogRef.afterClosed().subscribe(result => {
      if (result && typeof result.quantity != 'undefined' ) {
            let part =  this.partsData[index];
            part['quantity'] = result['quantity']
            part['total_amount'] = this.RoundOFTwoDigit(Number((part['price'] * part['quantity'] - ((part['price'] * part['quantity']) * part['discount'])/100)));

            if(part['igst'] !==0)
            {
                  
              part['cgst'] = parseFloat('0').toFixed(2);                      
              part['sgst'] =parseFloat('0').toFixed(2);     
              part['igst'] = this.RoundOFTwoDigit(Number((( part['total_amount']*part.HSSNtax)/100)));
              
            }
            else
            {
              part['cgst'] =this.RoundOFTwoDigit(Number((( part['total_amount']*(part.HSSNtax/2))/100)));
              part['sgst'] =this.RoundOFTwoDigit(Number((( part['total_amount']*(part.HSSNtax/2))/100)));
            }
           
           
            this.loadPartsTable(result)
      }
    });
  }
deleteParts(index) {
 
    this.partsData.splice(index, 1);
  
  this.checkPartsDataCount();
}
checkPartsDataCount() {
  if (this.partsData.length > 0) this.loadPartsTable(this.partsData);
  else {
    this.netAmount = 0;
    this.totalTax = 0;
    this.subTotal = 0;
  }
}
// open parts-dialog.html
openPartsDialog(data, parts?: any) {
  const dialogRef = this._dialog.open(PartsDialog, {
    autoFocus: false,
    width: '500px',
    data: { "partsOutput": {}, "partsOptions": data, "editParts": parts ? parts : '', "iGst" : this.iGst, "editBooking" : this.bookingId , "OpfType" : this.opfForm.get('type').value,"OTLNumber": this.opfForm.get('OTLNumber').value}
  });
  return dialogRef;
}

//-------------------Price and Tax section --------------------

percentage(num, per) {
  return ((num / 100) * per);
}

reCalculateTax(){
  this.partsData =  this.partsData.map(part =>{
      part['cgst'] =this.RoundOFTwoDigit(Number((( part['total_amount']*(part.HSSNtax/2))/100)))  
      part['sgst'] =this.RoundOFTwoDigit(Number((( part['total_amount']*(part.HSSNtax/2))/100)));
      part['igst'] =  this.RoundOFTwoDigit(Number((( part['total_amount']*part.HSSNtax)/100)));
      return part;
    })
}

//calculate net, tax,total amount 
loadPartsTable(result) {
  if (result && this.partsData) {
    this.netAmount= this.partsData.reduce((currentAmount, part)=>{
      return currentAmount+ part['total_amount']
    },0)
    this.totalTax = this.partsData.reduce((currentAmount, part)=>{
      return currentAmount+ (this.iGst ? part['igst'] : (part['sgst'] + part['cgst']))
    },0)
    this.subTotal =  this.partsData.reduce((currentAmount, part)=>{
      return currentAmount+ (part['price'] * part['quantity'])
    },0)
  }
}

checkTax() {
  if(this.billingDetails['state'].toLowerCase().replace(/\s/g,'') == BECKMAN_GODOWN.toLowerCase().replace(/\s/g,'')) {
    this.iGst = false;
  }
  else {
    this.iGst = true;
  }
}
// to hide and show the save page and update page 
viewOpfDetails(status){
  this.viewOPF= status 
  this.onSubmit = false;
}

cancelOpf(){
  this._bookingService.navigateToOPFList()
}



  // --------------Address section ---------------
  listBillingAddress(){
    this.openshipAddressDialog(this.billingList, this.billingDetails,'BILL_TO');
  }

  listShippingAddress() {
      this.openshipAddressDialog(this.shippingList,this.shipDetails,'SHIP_TO');
  }
  openshipAddressDialog(addressList,currentAddress,name) {
    const dialogRef = this._dialog.open(ListShippingAddressDialog, {
      width: '500px',
      data: { details: addressList, currentAddressDetails: currentAddress}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (name == 'BILL_TO') {
          this.billingDetails = result;
        }else{
          this.shipDetails = result;
        }
        this.checkTax()
        this.reCalculateTax();
      }
    });
  }
  // to get bill to and ship to address list
  getCpDetail() {
    this._bookingService.getCpDetails((response) => {
      this.cpDetails = response;  
      this.billingList = response.bill_to;
      this.shippingList = response.ship_to;
     },{cpnumber : this.bookingData.cpnumber});
  }

  getBillingAddress() {
    let data = {
      cpName: this.cpDetails.name,
      contactperson : this.cpDetails.contactPerson

    }

    return data;
  }
  //------------------attachments ------------------
  setAttachment($event) {
    if(!this.opfForm.get('attachment').errors && $event.target.files[0] && !this.attachmentArray.find(file => file.name ==$event.target.files[0]['name'] ) && !this.bookingData.attachment.find(file => file.fileName.split('/')[file.fileName.split('/').length-1] == $event.target.files[0]['name'] )) {
      this.attachmentArray.push($event.target.files[0])
    }
  }
  addAttachment(opfId) {
    this.attachmentData.append('opf_id', opfId);
    this.attachmentArray.map((file, index) =>{
      this.attachmentData.append(index == 0  ? 'attachment' : 'attachment'+ index, file);
    })
    this._bookingService.addAttachment(this.attachmentData , (response) => {
      this._bookingService.navigateToOPFList()
      this._snackBar.loadSnackBar(SuccessMessage.OPF_UPDATE, colorCodes.SUCCESS);
    });
  }
  
  clearAttachment(index){
    this.attachmentArray.splice(index,1)
  }
  //--------------OPF Type  change ----------------
   //type change 
   OnTypeChange(event){
    const isOTLnumberActive = this.opfForm.get('OTLNumber');
    if(this.opfForm.get('type').value || (this.opfForm.value.OTLNumber || this.partsData.length)) {
      // to restore the value after resetting form 
      let opfType = this.opfForm.get('type').value;
      if(this.opfForm.get('type').value === 'FOC-D' || this.opfForm.get('type').value === 'FOC-S' || this.opfForm.get('type').value === 'FOC-A')
      {
        this.othersFoc = true;
        this.cpDetails = {};
        // this.opfForm.get('invoiceNumber').setValidators([Validators.required, this._formValidator.negativeValidation]);
        // this.opfForm.get('cfNumber').setValidators([Validators.required, this._formValidator.negativeValidation]);
      }
      else
      {
        this.othersFoc = false;
        //getting FOC or OTL parts 
        isOTLnumberActive.setValue('');
        this.opfForm.get('custName').reset();
        this.opfForm.get('custNumber').reset();
        this.opfForm.get('site_id').reset();
          this.getHospital()
        // this.getCpDetail();
        // this.opfForm.get('invoiceNumber').clearValidators();
        this.clearOPF();
        // this.opfForm.get('cfNumber').clearValidators();
      }
     
    }
    // this.opfForm.get('invoiceNumber').updateValueAndValidity();
    // this.opfForm.get('cfNumber').updateValueAndValidity();
  }

  getHospital(){
    this._bookingService.getDistinctHospitals({cpnumber : this.bookingData.cpnumber,order_by:"name", model : "primary","opf_type":this.opfForm.get('type').value == 'FOC'? OTL_params.FOC : this.opfForm.get('type').value },(response => {
      this.clientNames = response
    }));
  }

  clearOPF(){
    this.partsData =[];
    this.netAmount = 0;
    this.totalTax = 0;
    this.subTotal = 0;
  
  }
  getInvoiceDetails() {
    this.clickingGetDetails = true;
    let invoiceNumber = this.opfForm.get('invoiceNumber').value;
    this._bookingService.getInvoiceDetails(invoiceNumber, (invoiceDetails) => {
      //Process Invoice details and populated OPF - NCMS
      this.cpDetails = invoiceDetails.OPF;
      this.setNcmsBookingForm();
      // this.regionalId = this.cpDetails.regionalBranchEmailid;
      // this.salesId = this.cpDetails.salesManagerEmailid;
      this.getCustName(this.cpDetails.custNumber, this.cpDetails.site_id,this.cpDetails.OTLNumber);
    // empty the parts table 
      this.partsData = [];
      this.loadPartsTable(this.partsData);
      this.reset = false;
      this.otlPartsList = invoiceDetails.parts;
      
    });
  }

  setNcmsBookingForm(){
     this.billingDetails = this.cpDetails.address.find(address => address.type === BILLING );
     this.shipDetails = this.cpDetails.address.find(address => address.type === SHIPPING );
     this.regionalId = this.cpDetails.regionalBranchEmailid;
     this.salesId = this.cpDetails.salesManagerEmailid;
     this.opfForm.patchValue({
       clientPOnumber: this.cpDetails.clientPOnumber,
       transcationType:this.cpDetails.transcationType ,
       priority:'standard',
       custNumber: this.cpDetails.custNumber,
     })
    
     this.checkTax();
     this.disableFields()
 }

  getCustName(custNumber,siteId ,otlno) {
    let details;
    details = this.clientNames.find((res) => {
      return res.custNumber == custNumber && res.site_id == siteId ;
    });
    this.opfForm.get('custName').setValue(details);
    this.onClientChange(details ? details : '', otlno);
    
  }

  retriggerParts( field, index?:any){
    let payload = {};
    payload['field'] = field;
    if (typeof index === 'undefined'){
      payload['opf_id'] = this.bookingData['id'];
    }else 
    payload['opf_part_id'] = this.partsData[index]['id'] ;

    this._bookingService.refreshParts(payload, response =>{
      if (typeof index !== 'undefined'){
        this.partsData[index]['price']  = typeof response.price !== 'undefined' ? response.price :this.partsData[index]['price']
        this.partsData[index]['discount']  =  typeof response.discount !== 'undefined' ? response.discount :this.partsData[index]['discount']
        this.partsData[index]['HSSNtax']  = typeof response.HSSNtax !== 'undefined' ? response.HSSNtax :this.partsData[index]['HSSNtax']
        let part = this.partsData[index];
        part['total_amount'] =this.RoundOFTwoDigit(Number((part['price'] * part['quantity'] - ((part['price'] * part['quantity']) * part['discount'])/100))); 
        part['cgst'] =this.RoundOFTwoDigit(Number((( part['total_amount']*(part.HSSNtax/2))/100)));  
        part['sgst'] =this.RoundOFTwoDigit(Number((( part['total_amount']*(part.HSSNtax/2))/100)));
        part['igst'] = this.RoundOFTwoDigit(Number((( part['total_amount']*part.HSSNtax)/100)));
        this.loadPartsTable(this.partsData);
      }else {
        this.opfForm.get(field).setValue(response[field]);
        this.regionalId =  response['regionalBranchEmailid'] ?response['regionalBranchEmailid'] : this.regionalId;
        this.salesId = response['salesManagerEmailid'] ?response['salesManagerEmailid'] : this.salesId;
      }
    })
  }
 
  updateOpf(){
    let data = this.opfForm.getRawValue();
    data.attachment = [];
    this.attachmentArray.forEach(function(index, item) {
          data.attachment.push("C:\\fakepath\\" + index.name);
    });   
    this.onSubmit = true
    if (this.opfForm.valid){
    data.OTLNumber = this.opfForm.get('OTLNumber').value.OTLnumber;
    data.custName = this.opfForm.get('custName').value.name;
    data.type = OPF_type[this.opfForm.get('type').value];
    data.regionalBranchEmailid = this.regionalId
    data.salesManagerEmailid = this.salesId;
    data['bill_to'] = this.billingDetails['id'];
    data['ship_to'] = this.shipDetails['id'];
    data['net_amount'] = this.RoundOFTwoDigit(Number(this.netAmount));
    data['total_amount'] = this.RoundOFTwoDigit(Number((data['net_amount'] + this.totalTax)));
    data['total_tax'] = this.RoundOFTwoDigit(Number(this.totalTax));
    data['status'] = this.partsData.find(res => res.quantity  > 0 ) ? this.bookingData.status : 'Cancelled';
    data['hasAttachments'] = this.opfForm.get('attachment').value ? true : false
    data['id'] = this.bookingData.id
    if (this.othersFoc) {
      // data.OPFNumber = this.cpDetails.OPFNumber ? this.cpDetails.OPFNumber : this.bookingData.OPFNumber;
      data.invoiceNumber =  this.opfForm.get('invoiceNumber').value;
      // data.cfNumber =  this.opfForm.get('cfNumber').value;
    }
    let updateData = Object.assign(this.getBillingAddress(), data);
    updateData.parts = this.partsData;
    this._bookingService.updateBooking(this.bookingId,updateData,response=>{
      if (this.opfForm.get('attachment').value){
            this.addAttachment(response.id);
          }else{
            this._bookingService.navigateTo(Roles.Admin,'Edit');
          }
    });
     
  }
  }

  resetOpf(value?:any) {
    this.reset = value ? true : false;
      this.setBookingForm(this.bookingData);
      this.opfForm.get('type').setValue(OPF_Type_Value[this.bookingData.type])
      this.getDistinctHospitals();
      this.partsData = this.bookingData['parts'];
      this.loadPartsTable(this.partsData);
      this.attachmentArray = [];
    this.clickingGetDetails = false;

 
  }
  RoundOFTwoDigit(num: any){
    var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
    return number;
  }

}


import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { routes } from 'src/app/app-routing.module';
import { LoaderComponent } from 'src/app/core/modules/shared/components/loader/loader.component';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { AgGridModule } from 'ag-grid-angular';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CpbookingsListComponent } from './cpbookings-list.component';




describe('CpbookingsListComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes),
        AppMaterialModule,
        CustomFormsModule,
        AgGridModule.withComponents([]),
        HttpClientModule,
        BrowserAnimationsModule
      ],
      declarations: [
        CpbookingsListComponent,
        LoaderComponent
      ],
    }).compileComponents();
   
  }));

  it('should create the CP booking  list', () => {
    const fixture = TestBed.createComponent(CpbookingsListComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

});



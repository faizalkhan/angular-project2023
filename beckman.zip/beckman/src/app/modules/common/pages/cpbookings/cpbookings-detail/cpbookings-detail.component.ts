import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { CpbookingService } from '../../../../cpadmin/service/cpbooking.service';
import { environment } from '../../../../../../environments/environment';
import { BECKMAN_GODOWN, BILLING, SHIPPING, BookingStatus, ActionItems } from 'src/app/core/services/constants';
import { Validators } from '@angular/forms';
import { InputDialogService } from 'src/app/core/modules/shared/components/input-dialog/input-dialog.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { Roles } from 'src/app/modules/auth/model/user';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';

@Component({
  selector: 'app-cpbookings-detail',
  templateUrl: './cpbookings-detail.component.html',
  styleUrls: ['./cpbookings-detail.component.css']
})
export class CpbookingsDetailComponent implements OnInit {
public bookingId;
public data; 
public subTotal = 0;
public billingAddress;
public shippingAddress;
public serverUrl = environment.apiUrl;
public iGst:boolean=false;
public isAdmin = false;
public isChannelPartner = false;
public paramName; 
public moduleName;
public addOpf = false;
public editBookingPermission = false;
public editOpf = false;
public editOpfAdmin = false;
public status: any;
public statusDate: any;
public otlnumber: any;
public ishide: boolean = false;
  constructor(public route: ActivatedRoute, private _UtilsService : UtilsService , private _StorageService: StorageService, private _secondarysalesService : SecondarysalesService,
     public _inputDialogService : InputDialogService,  private _formValidator: FormValidatorService,public _CpbookingService: CpbookingService,private _router: Router ) { }

  ngOnInit() {
    // const value = JSON.parse(localStorage.getItem('opfFilter'));
    // if(value){
    //   localStorage.setItem('opfView', 'true');
    // }
    http://localhost:8000/check_cp_has_otl/?OTLNumber=6538IN
   
    this.moduleName = this._UtilsService.moduleName();
    this.isAdmin = this._UtilsService.isAdminRole(this._StorageService.getUserDetails().role);
    this.isChannelPartner = this._UtilsService.isCpRole(this._StorageService.getUserDetails().role);
    this._CpbookingService.getActionPermission({model : 'opf'},response =>{ 
       this.addOpf = response['opf'] && typeof response['opf'][ActionItems['ADD']] != 'undefined' ? true : false;
       this.editBookingPermission = response['opf'] && typeof response['opf'][ActionItems['EDIT']] != 'undefined' ? true : false;

    })    
    this.route.paramMap.subscribe((params: ParamMap) => {
        this.paramName = params.get('name');
        if (parseInt(params.get('id'))) {
          this.bookingId = parseInt(params.get('id'));
        } 
      });
    this._CpbookingService.viewBooking(this.bookingId,
      (response) => {
        this.data = response; 
        this.status = this.data['status'];
        this.statusDate = this.data ['status_updated_on'];
        this.otlnumber = this.data['OTLNumber'];
        if(this.otlnumber){
          this._CpbookingService.getCheck_cp({OTLNumber:this.otlnumber}, response =>{
         
             if(response['success']){
            
               this.ishide= false;
             }
             else{
               this.ishide= true;
              }
           })
          
        }
        this.billingAddress = response.address.find(address => address.type === BILLING );
        this.shippingAddress = response.address.find(address => address.type === SHIPPING );
        if (this._StorageService.getUserDetails().role !=Roles.Channel_Partner){
          this.editOpf = this.data.status != "Cancelled" &&  this.data.status != "Rejected" &&  !this.data['isInvoiced'];
          this.editOpfAdmin = this.isAdmin && this.data.status != "Cancelled" &&  this.data.status != "Rejected" 

        }else{
          this.checkPrimaryLockAccess()
        }

        // need to remove in future
        this.subTotal =  response['parts'].reduce((currentAmount, part)=>{
          return currentAmount+ (part['price'] * part['quantity'])
        },0)
        this.checkTax();
      },
      (error) => console.log(error))

     
  } 

  checkPrimaryLockAccess(){
    this._secondarysalesService.cpModuleAccess(res => {
      if (res['primaryLock'] == 0 ) {
        this.editOpf =true ;
        this.checkEditAccessControl()
      }
      else this.editOpf = false ;
    }); 
  }
  checkEditAccessControl(){
    this._CpbookingService.getPermissionAccessControls({module : 'OPF_Edit'},response =>{
    this.editOpf = this.data.status == 'Open' && response.parent_permission[0]['is_allowed'];
    })
  } 
percentage(num, per) {
  return ((num / 100) * per);
}

checkTax() {
  if(this.billingAddress['state'].toLowerCase().replace(/\s/g,'') == BECKMAN_GODOWN.toLowerCase().replace(/\s/g,'')) {
    this.iGst = false;
  }
  else {
    this.iGst = true;
  }
  
}

download(id){
  this._CpbookingService.exportAttachment(id);
}

print() {
  window.print();
}
copyOPF(){
  this._router.navigate(['/channel-partner/bookings/repeat', this.data.id]); 
}


setBookingStatus(status) {
  let fields =  [
{
 "type":"textarea",
 "label":"Reason for Rejection",
 "fieldName" :'rejectReason',
 'validator' : [Validators.required,this._formValidator.noWhitespaceValidation]
}
]
this._inputDialogService.openDialog({btnLabel: 'REJECTED',title : 'REJECTED OPF',fields:fields },result =>{
if (result){
 this.data['rejectReason'] = result['rejectReason'];
 this.data['status'] = status;
 this._CpbookingService.editBooking(this.bookingId, this.data, status);
}
}); 
}


navigate(){
  if (this.paramName == 'outbound') this._router.navigate([this.moduleName+'/outbound']);
  else if (this.paramName== 'inbound') this._router.navigate([this.moduleName+'/inbound']);
  else this._CpbookingService.navigateToOPFList()
}
navigateEditBooking(){
 this._CpbookingService.navigateToEditOPF(this.bookingId);
}
}
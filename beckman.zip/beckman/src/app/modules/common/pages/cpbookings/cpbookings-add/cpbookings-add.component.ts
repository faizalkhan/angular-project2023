import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog'
import { CpbookingService } from '../../../../cpadmin/service/cpbooking.service';
import { getState, getCities, getRegions } from 'src/app/core/services/location';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { BookingStatus, BECKMAN_GODOWN, BILLING, SHIPPING, colorCodes, OPF_type,OTL_params, ErrorMessage, ActionItems } from 'src/app/core/services/constants';
import { requiredFileType } from 'src/app/core/services/formValidator/upload-file-validator';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { PartsDialog, ListShippingAddressDialog } from '../../../dialogs/booking-dialog';
import { StockService } from '../../../../cpadmin/service/stock.service';
import { SecondarysalesService } from '../../../../cpadmin/service/secondarysales.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';


@Component({
  selector: 'app-cpbookings-add',
  templateUrl: './cpbookings-add.component.html',
  styleUrls: ['./cpbookings-add.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CpbookingsAddComponent implements OnInit {
  public date =new Date ();
  public displayClientKeys = ['name','address','city','pincode']
  public bookingId;
  public opfForm: FormGroup;
  public clientNames = [];
  public cpDetails;
  public clientNumber;
  public otlList = [];
  public otlPartsList = [];
  public partsData = [];
  public subTotal = 0; 
  public netAmount = 0;
  public totalTax = 0;
  public regionalId = '';
  public salesId = '';
  public shipDetails; // current shipping address
  public billingDetails;
  public attachmentData = new FormData();
  public iGst:boolean = false;
  public partsCurrentOptions = [];
  public viewOPF = false;
  public attachmentArray =[];
  public regionalName = '';
  public saleslName = '';
  public othersFoc:boolean = false;
  public billingList = [];
  public shippingList = [];
  public onSubmit = false; //  used to avoid multiple times of OPF creation 
  public isOltNoActive = false;
  public OPFNumberLength: any;
  constructor(private fb: FormBuilder, private _PromptService: PromptService, private _StorageService: StorageService,private _stockService:StockService,private _secondarysalesService :SecondarysalesService, private _UtilsService : UtilsService,
    public _dialog: MatDialog, public route: ActivatedRoute, private _bookingService: CpbookingService, private _snackBar :SnackbarService, private _formValidator: FormValidatorService) { }

  ngOnInit() {
    this.loadBookingForm();
    this._bookingService.getActionPermission({model : 'opf'},response =>{ 
      if (  typeof response['opf'][ActionItems['ADD']] == 'undefined') this.cancelOpf();
    })
    if (this._UtilsService.isCpRole(this._StorageService.getUserDetails().role)){
      this._secondarysalesService.cpModuleAccess(res => {
        if (res['primaryLock'] == 1 )   this.cancelOpf();
      }); 
    } 
    this.getHospital();

    this.opfForm.get('type').valueChanges.subscribe(response=>{
      this.getHospital()
     })
   
 
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.bookingId = parseInt(params.get('id'));
          //add 
        this.getCpDetail();
    });
    this.opfForm.get('attachment').valueChanges.subscribe(res => {
      if (this.opfForm.get('attachment').errors && ( this.opfForm.get('attachment').errors.requiredFileType ||   this.opfForm.get('attachment').errors.fileTypeExceedMaxLength )){
        this.opfForm.get('attachment').errors.fileTypeExceedMaxLength ? this._snackBar.loadSnackBar(ErrorMessage.ATTACHMENT_FILE_NAME_LENGTH, colorCodes.ERROR) :  this._snackBar.loadSnackBar(ErrorMessage.ATTACHMENT_FILE, colorCodes.ERROR);
      }

    }
  )}

  getHospital(){
    this._bookingService.getDistinctHospitals({order_by:"name", model : "primary","opf_type":this.opfForm.get('type').value == 'FOC'? OTL_params.FOC : this.opfForm.get('type').value },(response => {
      this.clientNames = response
    }));
  }

  //  Getting channel partner details 
  getCpDetail() {
    this._bookingService.getCpDetails((response) => {
      this.cpDetails = response;  
      this.billingList = response.bill_to;
      this.shippingList = response.ship_to;
    });
  }

  loadBookingForm() { 
    this.opfForm = this.fb.group({
      OPFNumber: [''],
      clientPOnumber: [''],
      custName: ['', [Validators.required, this._formValidator.requireMatch]],
      custNumber: ['', Validators.required],
      OTLNumber: ['', [Validators.required, this._formValidator.requireMatch]],
      site_id: ['', Validators.required],
      type: ['OTL', Validators.required],
      transcationType: ['stock', Validators.required],
      priority: ['standard', Validators.required],
      comment: [''],
      attachment:['',  [requiredFileType(["jpg", "png", "pdf"])] ],
      invoiceNumber: [''],
      cfNumber: ['']
    })
  }

  onClientChange(value, otlNo?: any, partsData?: any) {
    this.otlList = [];
    this.partsData = this.bookingId ? this.partsData : [];
    this.opfForm.patchValue({
      OTLNumber: '',
      site_id: '',
      custNumber: ' '
    })
    this.netAmount = 0;
    this.totalTax = 0;
    this.subTotal = 0;

    if (value) {

      this._bookingService.getShippingAddress({ "custNumber":value.custNumber, "site_id":value.site_id, "model" :"primary" }, (res) => {
        this.opfForm.get('custNumber').setValue(value.custNumber);
        this.opfForm.get('site_id').setValue(value.site_id);
        this.billingDetails = this.billingList.find(address => address['id'] == res[0]['opf_bill_to'])
        this.shipDetails = this.shippingList.find(address => address['id'] == res[0]['opf_ship_to'])    
      });
      this._bookingService.validateHospital({"site_id": value.site_id,"custNumber" :value.custNumber }, (response)=>{  
        //set OTL
        this._stockService.getOtl({ "site_id": value.site_id, "order_by":"otl_number",
        "opf_type":this.opfForm.get('type').value == 'FOC'? OTL_params.FOC : this.opfForm.get('type').value, "is_primary":true }, (response) => {
          this.otlList = response;
          if(this.opfForm.get('invoiceNumber').value) {
            this.otlList.filter((res) => {
              if (res.OTLnumber === otlNo) {
               this.onOtlChange(res)
              }
            })
          }
        });
        this.checkTax();
      })
    }
  }
  onOtlChange(value) {
    this.partsData = [];
    this.isOltNoActive = false;
    if (value) {
      // Need to show active OTL number 
      this._bookingService.validateOtl({"site_id": value.site_id,"OTLNumber" :value.OTLnumber }, (response)=>{ 
        this.isOltNoActive = true;
        this.updateRegionalSalesName(value);
        this._bookingService.getOtlPartsOpf({ "OTLNumber": value.OTLnumber,"opf_type":this.opfForm.get('type').value == 'FOC'? OTL_params.FOC : this.opfForm.get('type').value, "order_by": "name"}, (response) => {
          // for OPF NCMS - should show only active parts 
          if (this.opfForm.get('invoiceNumber').value)  {
            let filteredParts = [];
             this.opfForm.get('OTLNumber').setValue(value);
             this.otlPartsList.forEach(part => {
               let details =  response.find(res =>res['partNumber'] == part['partNumber'])
               if (details){
                filteredParts.push(part)
               }
             });
             this.otlPartsList = filteredParts;
          } else
          this.otlPartsList = response;
        });
      });
    }
  }

  updateRegionalSalesName(value){
    this.regionalName =value['regional_name'] ;
    this.saleslName = value['sales_name']; 
    this.regionalId =value['regionalBranchEmailid'] ? value['regionalBranchEmailid'] : '';
    this.salesId = value['salesEmail'];
  }

  loadPartsDialog() {
    // this.partsCurrentOptions= !this.partsData.length ? this.otlPartsList : this.otlPartsList.filter(otlPart => !this.partsData.find(part =>otlPart['partNumber'] === part['partNumber'] ));
    if (this.partsData.length){
      this.otlPartsList =  this.otlPartsList.map(part => {
        let newPart = this.partsData.find(newPart => part['partNumber'] == newPart['partNumber']);
        if (newPart) part['quantity'] = newPart['quantity'];
        return part
      });
    }
    let dialogRef = this.openPartsDialog(this.otlPartsList);
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        let index = this.partsData.findIndex(part => part['OTLNumber'] === result['OTLNumber'] && part['partNumber'] === result['partNumber']&& part['lotNumber']=== result['lotNumber'] );
          if(index >= 0 &&  this.partsData.length) this.partsData[index] = result;
          else this.partsData.push(result);
      }
      this.loadPartsTable(result)
    });
  }

  loadPartsTable(result) {
    if (result && this.partsData) {
      this.netAmount= this.partsData.reduce((currentAmount, part)=>{
        return currentAmount+ part['total_amount']
      },0)
      this.totalTax = this.partsData.reduce((currentAmount, part)=>{
        return currentAmount+ (this.iGst ? part['igst'] : (part['sgst'] + part['cgst']))
      },0)
      this.subTotal =  this.partsData.reduce((currentAmount, part)=>{
        return currentAmount+ (part['price'] * part['quantity'])
      },0)
      this.checkTax();
    }
  }
  
  openPartsDialog(data, parts?: any) {
    const dialogRef = this._dialog.open(PartsDialog, {
      autoFocus: false,
      width: '500px',
      data: { "partsOutput": {}, "partsOptions": data, "editParts": parts ? parts : '', "iGst" : this.iGst, "editBooking" : this.bookingId , "OpfType" : this.opfForm.get('type').value, "OTLNumber": this.opfForm.get('OTLNumber').value}
    });
    return dialogRef;
  }

  percentage(num, per) {
    return ((num / 100) * per);
  }

  deleteParts(index) {
    if (this.bookingId) {
      this._PromptService.openDialog({title : 'Delete Part',btnLabel : 'CONFIRM'}, response =>{
        if (response){
          this.deletePartService(index)
        }
      })
    } else {
      this.partsData.splice(index, 1);
    }
    this.checkPartsDataCount();
  }
  
  deletePartService(index){
    this._bookingService.deleteParts(this.partsData[index]['id'], (res) => {
      this.partsData.splice(index, 1);
      this.checkPartsDataCount();
    })
  }
  checkPartsDataCount() {
    if (this.partsData.length > 0) this.loadPartsTable(this.partsData);
    else {
      this.netAmount = 0;
      this.totalTax = 0;
      this.subTotal = 0;
    }
  }
  editParts(index) {
    let dialogRef = this.openPartsDialog(this.otlPartsList, this.partsData[index]);
    dialogRef.afterClosed().subscribe(result => {
      if (result && result.partNumber) {
        if (this.bookingId) {
          let data = result;
          data['opf_id'] = this.partsData[index]['opf_id']
          data['OPFNumber'] = this.partsData[index]['OPFNumber'];
          data['id'] = this.partsData[index]['id'];
          this._bookingService.editParts(data['id'] , data, (res) => {
            this.loadPartsTableForm(result, index)
          })
        } else { this.loadPartsTableForm(result, index); }
      }
    });
  }
  loadPartsTableForm(result, index) {
    for (let part = 0; part < this.partsData.length; part++) {
      if (part == index) {
        this.partsData[part] = result;     
      }
    }
    this.loadPartsTable(result)
  }

  getBillingAddress() {
    let data = {
      name: this.cpDetails.name,
      address: this.cpDetails.address,
      city: this.cpDetails.city,
      state: this.cpDetails.state,
      region: this.cpDetails.region,
      pincode: this.cpDetails.pincode,
      telephone: this.cpDetails.telephone,
      mobile: this.cpDetails.mobile,
      fax: this.cpDetails.fax,
      contactPerson : this.cpDetails.contactPerson

    }

    return data;
  }

  createOpf() {
    let data = this.opfForm.value;
    this.onSubmit = true
    if (this.opfForm.valid){
     
    data.OTLNumber = this.opfForm.get('OTLNumber').value.OTLnumber;
    data.custName = this.opfForm.get('custName').value.name;
    data.type = OPF_type[this.opfForm.get('type').value];
    data.regionalBranchEmailid = this.regionalId
    data.salesManagerEmailid = this.salesId;
    data['bill_to'] = this.billingDetails['id'];
    data['ship_to'] = this.shipDetails['id'];

    data['net_amount'] = this.RoundOFTwoDigit(Number(this.netAmount));
    data['total_amount'] = this.RoundOFTwoDigit(Number((data['net_amount'] + this.totalTax)));
    data['total_tax'] = this.RoundOFTwoDigit(Number(this.totalTax));
    data['shipping_address'] = this.shipDetails;
    data['status'] = BookingStatus.OPEN;
    data['hasAttachments'] = this.opfForm.get('attachment').value ? true : false


    if (this.othersFoc) {
      data.OPFNumber = this.cpDetails.OPFNumber;
      data.invoiceNumber =  this.opfForm.get('invoiceNumber').value;
      data.cfNumber =  this.opfForm.get('cfNumber').value;
    }
    
      // adding cp  address for OTL, FOC-contract
      let addData = Object.assign(this.getBillingAddress(), data);
      // adding CP details to billing address for OTL, FOC-contract , FOC-others
      addData['billing_address'] =  this.billingDetails ;

      addData.parts = this.partsData;
      addData['contactperson'] = this.cpDetails.contactPerson;
      addData['shipping_address']['type'] = 'shipping';
      addData['billing_address']['type'] = 'billing';
      addData['billing_address']['contactPerson'] =this.billingDetails['contactPerson'];
      this._bookingService.addBooking(addData, (response) => {
        if (this.opfForm.get('attachment').value){
          this.addAttachment(response.id);
        }else{
          this._bookingService.navigateToOPFList()
        }
      });
    
  }
  }
  viewOpfDetails(status){
    this.viewOPF= status 
    this.onSubmit = false;
  }

  cancelOpf(){
    this._bookingService.navigateToOPFList();
  }

  RoundOFTwoDigit(num: any){
    var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
    return number;
  }

  resetOpf() {
    if (!this.bookingId){
      this.partsData = [];
      this.opfForm.reset();
      this.billingDetails ={};
      this.shipDetails = {};
      this.regionalName= ''
      this.saleslName= ''
      this.netAmount = 0;
      this.totalTax = 0;
      this.subTotal = 0;
      this.regionalId = '';
      this.salesId = '';
      this.attachmentArray = [];
      this.othersFoc = false;
      this.isOltNoActive = false;
      this.opfForm.get('type').setValue('OTL');
      this.opfForm.get('transcationType').setValue('stock');
      this.opfForm.get('priority').setValue('standard');


    }else{
      this.setBookingForm();
      
    }
    
  }

  setAttachment($event) {
    if(!this.opfForm.get('attachment').errors && $event.target.files[0] && !this.attachmentArray.find(file => file.name ==$event.target.files[0]['name'] ) && $event.target.files[0]['name'].length <= 200) {
      this.attachmentArray.push($event.target.files[0])
    }
  }
  addAttachment(opfId) {
    this.attachmentData.append('opf_id', opfId);
    this.attachmentArray.map((file, index) =>{
      this.attachmentData.append(index == 0  ? 'attachment' : 'attachment'+ index, file);
    })
    this._bookingService.addAttachment(this.attachmentData,res => {
        this._bookingService.navigateToOPFList()
    });
  }

  clearAttachment(index){
    this.attachmentArray.splice(index,1)
  }
// Edit opf start
setBookingForm(){
   let name =  this.getCustName(this.cpDetails.custNumber, this.cpDetails.site_id,this.cpDetails.OTLNumber , this.cpDetails.parts);
    this.billingDetails = this.cpDetails.address.find(address => address.type === BILLING );
    this.shipDetails = this.cpDetails.address.find(address => address.type === SHIPPING );
    this.regionalId = this.cpDetails.regionalBranchEmailid;
    this.salesId = this.cpDetails.salesManagerEmailid;
    this.opfForm.patchValue({
      custName:name,
      clientPOnumber: this.cpDetails.clientPOnumber,
      OPFNumber: this.cpDetails.OPFNumber,
      transcationType:this.cpDetails.transcationType ,
      priority:'standard',
      custNumber: this.cpDetails.custNumber,
      cfNumber:this.cpDetails.cfNumber
    })
    this.checkTax();
}

  getCustName(custNumber,siteId ,otlno, partsData) {
    let details;
    details = this.clientNames.find((res) => {
      return res.custNumber == custNumber && res.site_id == siteId ;
    });
    
    this.onClientChange(details ? details : '', otlno, partsData);
    return details ? details : '';
  }

  //End edit opf 

  // add and edit shipping address  start
  addShippingAddress() {
    const dialogRef = this._dialog.open(ShippingAddressDialog, {
      width: '500px',
      data: {}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.getCpDetail();
        this.shipDetails = result;
        this.checkTax();
      }
    });
  }

  listBillingAddress(){
    this.openshipAddressDialog(this.billingList, this.billingDetails,'BILL_TO');
  }

  listShippingAddress() {
    
      this.openshipAddressDialog(this.shippingList,this.shipDetails,'SHIP_TO');
  }
  openshipAddressDialog(addressList,currentAddress,name) {
    const dialogRef = this._dialog.open(ListShippingAddressDialog, {
      width: '500px',
      data: { details: addressList, currentAddressDetails: currentAddress}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (name == 'BILL_TO') {
          this.billingDetails = result;
        }else{
          this.shipDetails = result;
        }
        this.checkTax();
        this.loadPartsTable(this.partsData)
      }
    });
  }

  setPartsTax(){
    this.partsData.forEach(part =>{
      if (!this.iGst) {
        part['cgst'] = part.igst /2;
        part['sgst'] = part.igst /2;
        part['igst'] = 0;
      }else{
        part['igst'] =part['cgst'] + part['sgst'];
        part['cgst'] = 0;
        part['sgst'] = 0;
      }
    })
  }
  // add and edit shipping address end

  checkTax() {
  
    if(this.billingDetails['state'].toLowerCase().replace(/\s/g,'') == BECKMAN_GODOWN.toLowerCase().replace(/\s/g,'')) {
      this.iGst = false;
    }
    else {
      this.iGst = true;
    }
  }


  //type change 
  OnTypeChange(event){
    const isOTLnumberActive = this.opfForm.get('OTLNumber');
    if(this.opfForm.get('type').value || (this.opfForm.value.OTLNumber || this.partsData.length)) {
      let opfType = this.opfForm.get('type').value;
      this.resetOpf();
       this.shipDetails = {};
      this.billingDetails = {};
      this.opfForm.get('type').setValue(opfType);
      this.otlList = [];
      // for FOC-others 
      if(this.opfForm.get('type').value === 'FOC-D' || this.opfForm.get('type').value === 'FOC-S' || this.opfForm.get('type').value === 'FOC-A')
      {
        this.othersFoc = true;
        this.billingDetails = {};
        this.shipDetails = {};
        this.cpDetails = {};
        this.opfForm.get('invoiceNumber').setValidators([Validators.required, this._formValidator.negativeValidation]);
        this.opfForm.get('cfNumber').setValidators([Validators.required, this._formValidator.negativeValidation]);
      }
      else
      {
        this.othersFoc = false;
        isOTLnumberActive.setValue('');
        this.getCpDetail();
        this.opfForm.get('invoiceNumber').clearValidators();
        this.opfForm.get('cfNumber').clearValidators();
      }
    }
    
    this.opfForm.get('invoiceNumber').updateValueAndValidity();
    this.opfForm.get('cfNumber').updateValueAndValidity();
  }

  getInvoiceDetails() {
    let invoiceNumber = this.opfForm.get('invoiceNumber').value;
    this._bookingService.getInvoiceDetails(invoiceNumber, (invoiceDetails) => {
      //Process Invoice details and populated OPF - NCMS
      this.cpDetails = invoiceDetails.OPF;
      this.OPFNumberLength = this.cpDetails['OPFNumber'].length;
      this.setBookingForm();
      this.otlPartsList = invoiceDetails.parts;
    });
  }

}


@Component({
  selector: 'ship-dialog',
  templateUrl: 'ship-dialog.html',
  styles: [`.mat-dialog-container{
    padding : 0 !important;
    margin-top: 20px;
    margin-bottom: 20px;
    overflow-x : hidden;
    overflow-y : auto;
}
.pointer:hover {cursor: pointer} 
`],
  encapsulation: ViewEncapsulation.None
})
export class ShippingAddressDialog implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<ShippingAddressDialog>, private fb: FormBuilder, private _bookingService: CpbookingService, private _formValidator: FormValidatorService,
    @Inject(MAT_DIALOG_DATA) public data) { }
  public states = getState;
  public cities = getCities;
  public region = getRegions;
  public currentCities = [];
  public currentState = [];
  public shippingForm: FormGroup
  ngOnInit() {
    this.loadShippingAddressForm();
    if (Object.keys(this.data).length > 0) this.setShippingAddressForm()
  }
  setShippingAddressForm() {
    this.shippingForm.setValue({
      name: this.data.name,
      address: this.data.address,
      region: this.getFilterValue('region', this.data.region),
      state: this.getFilterValue('state', this.data.state),
      city: this.getFilterValue('city', this.data.city),
      telephone: this.data.telephone,
      pincode: this.data.pincode,
      mobile: this.data.mobile,
      fax: this.data.fax,
      contactPerson: this.data.contactPerson,
      type: this.data.type,

    })


  }
  loadShippingAddressForm() {
    this.shippingForm = this.fb.group({
      name: ['', Validators.required],
      address: ['', Validators.required],
      region: ['', [Validators.required, this._formValidator.requireMatch]],
      state: ['', [Validators.required, this._formValidator.requireMatch]],
      city: ['', [Validators.required, this._formValidator.requireMatch]],
      telephone: ['', this._formValidator.numberValidation],
      pincode: ['', [Validators.required,this._formValidator.pincodePatternValidation]],
      mobile: ['',this._formValidator.mobilePatternValidation],
      fax: ['', this._formValidator.numberValidation],
      contactPerson: ['', Validators.required],
      type: ['']
    });
  }
  getFilterValue(fieldName, value) {
    let options = {};
    if (fieldName === 'region') {
      this.onRegionChange(value);
      options = this.region.filter((val) => {
        return val.field.toLowerCase() === value.toLowerCase()
      });
    } else if (fieldName === 'state') {
      this.onStateChange(value);
      options = this.states.filter((val) => {
        return val.name.toLowerCase() === value.toLowerCase()
      });
    } else {
      options = this.cities.filter((val) => {
        return val.name.toLowerCase() === value.toLowerCase()
      });
    }
    return options[0] ? options[0] : '';
  }
  onRegionChange(value) {
    this.currentCities = [];
    this.currentState = [];
    this.shippingForm.patchValue({
      state: '',
      city: ''
    });
    if (value) {
      let id = (value.field) ? value.field : value;
      this.currentState = this.states.filter((val) => {
        return val.field.toLowerCase() === id.toLowerCase()
      });
    }
  }
  onStateChange(value) {
    this.currentCities = [];
    this.shippingForm.patchValue({
      city: ''
    });
    if (value) {
      let field = (value.name) ? value.name : value;
      this.currentCities = this.cities.filter((val) => {
        return val.field.toLowerCase() === field.toLowerCase();
      });
    }
  }
  dialogClose(): void {
    this.dialogRef.close();
  }
  submit() {
    let shipAddress = this.shippingForm.value;
    shipAddress.state = this.shippingForm.value.state.name;
    shipAddress.city = this.shippingForm.value.city.name;
    shipAddress.region = this.shippingForm.value.region.field;
    if (Object.keys(this.data).length > 0) {
      this.dialogRef.close(Object.assign(this.data, shipAddress))
    } else {
      this._bookingService.addShippingAddress(shipAddress, (res) => {
        this.dialogRef.close(res);
      })
    }
  }

}

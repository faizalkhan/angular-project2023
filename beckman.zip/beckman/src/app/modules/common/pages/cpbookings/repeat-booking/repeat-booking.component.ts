import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { CpbookingService } from '../../../../cpadmin/service/cpbooking.service';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { requiredFileType } from 'src/app/core/services/formValidator/upload-file-validator';
import { BILLING, SHIPPING, BECKMAN_GODOWN, OTL_params, BookingStatus, OPF_type, colorCodes, ErrorMessage, SuccessMessage, ActionItems } from 'src/app/core/services/constants';
import { PartsDialog, ListShippingAddressDialog } from '../../../dialogs/booking-dialog';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { StockService } from '../../../../cpadmin/service/stock.service';
import { SecondarysalesService } from '../../../../cpadmin/service/secondarysales.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';

@Component({
  selector: 'app-repeat-booking',
  templateUrl: './repeat-booking.component.html',
  styleUrls: ['./repeat-booking.component.css']
})
export class RepeatBookingComponent implements OnInit {
public bookingId ;
public bookingData; 
public date =new Date ();
public displayClientKeys = ['name','address','city','pincode']
public opfForm: FormGroup;
public clientNames = [];
public cpDetails;
public clientNumber;
public otlList = [];
public otlPartsList = [];
public partsData = [];
public subTotal = 0;
public netAmount = 0;
public totalTax = 0;
public regionalId = '';
public salesId = '';
public shipDetails ; // current shipping address
public billingDetails ;
public attachmentData = new FormData();
public iGst:boolean;
public partsCurrentOptions = [];
public viewOPF = true;
public attachmentArray =[];
public othersFoc:boolean = false;
public billingList = [];
public shippingList = [];
public onSubmit = false  //   used to avoid multiple times of OPF creation 
public isOltNoActive = false;
public reset = false;
public invalidParts = '';
public isChannelPartner= false;
public moduleName ;




constructor(private fb: FormBuilder,public _dialog: MatDialog, private _bookingService: CpbookingService, private _formValidator: FormValidatorService,private _StorageService: StorageService,
    private _router: Router,private _snackBar :SnackbarService, private _stockService:StockService,private _secondarysalesService :SecondarysalesService,private _UtilsService : UtilsService,
    public route: ActivatedRoute) { 
      
    }

  ngOnInit() {
    this.loadBookingForm();
    this.moduleName = this._UtilsService.moduleName();
    this._bookingService.getActionPermission({model : 'opf'},response =>{ 
      if (typeof response['opf'][ActionItems['ADD']] == 'undefined') this.cancelOpf();
    })
    this.isChannelPartner = this._UtilsService.isCpRole(this._StorageService.getUserDetails().role);
    if (this.isChannelPartner){
        this._secondarysalesService.cpModuleAccess(res => {
          if (res['primaryLock'] == 1)  this.cancelOpf();
      }); 
    }

   this.getCpDetail();
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.bookingId = parseInt(params.get('id'));
      this._bookingService.viewBooking(this.bookingId,
        (response) => {
          this.bookingData = response; 
          this.setBookingForm(response);
          this.getDistinctHospitals();
        },
        (error) => console.log(error))
    });
    this.opfForm.get('attachment').valueChanges.subscribe(res => {
      if (this.opfForm.get('attachment').errors && this.opfForm.get('attachment').errors.requiredFileType){
        this._snackBar.loadSnackBar('Please attach (pdf ,png ,jpg) file', colorCodes.ERROR);
      }
    }
  )
  
  }
  listBillingAddress(){
    this.openshipAddressDialog(this.billingList, this.billingDetails,'BILL_TO');
  }

  listShippingAddress() {
      this.openshipAddressDialog(this.shippingList,this.shipDetails,'SHIP_TO');
  }
  openshipAddressDialog(addressList,currentAddress,name) {
    const dialogRef = this._dialog.open(ListShippingAddressDialog, {
      width: '500px',
      data: { details: addressList, currentAddressDetails: currentAddress}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (name == 'BILL_TO') {
          this.billingDetails = result;
        }else{
          this.shipDetails = result;
        }
        this.checkTax()

      }
    });
  }
  getDistinctHospitals(){
    this._bookingService.getDistinctHospitals({order_by:"name",model : "primary","opf_type":this.opfForm.get('type').value == 'FOC'? OTL_params.FOC : this.opfForm.get('type').value},(response => {
      this.clientNames = response
       this.setClientName() 
    }));
  }
  loadBookingForm() { 
    this.opfForm = this.fb.group({
      OPFNumber: [''],
      clientPOnumber: [''],
      custName: ['', [Validators.required, this._formValidator.requireMatch]],
      custNumber: ['', Validators.required],
      OTLNumber: ['', [Validators.required, this._formValidator.requireMatch]],
      site_id: ['', Validators.required],
      type: ['OTL', Validators.required],
      transcationType: ['', Validators.required],
      priority: ['', Validators.required],
      comment: [{value : '' , disabled : false }],
      attachment:['',  [requiredFileType(["jpg", "png", "pdf"])] ],
      regionalName:[''],
      salesName:[''],
    })
  }

  setBookingForm(response){
    this.billingDetails = response.address.find(address => address.type === BILLING );
    this.shipDetails = response.address.find(address => address.type === SHIPPING );
    this.opfForm.patchValue({
      clientPOnumber: response.clientPOnumber,
      type: response.type == 'OTL' ? response.type : 'FOC',
      transcationType:response.transcationType ,
      priority:'standard',
      comment: response.comment,
      regionalName :response.regionalBranchName,
      salesName :   response.salesManagerName,
    });
    this.checkTax();
  }

  setClientName(){
    let cilentName =   this.clientNames.find((res) => {
      return res.custNumber == this.bookingData.custNumber && res.site_id == this.bookingData.site_id  ;
    });
    this.opfForm.get('custName').setValue(cilentName);
    this.onClientChange(cilentName);
  }


  onClientChange(value) {
    this.opfForm.patchValue({
      OTLNumber: '',
      site_id: '',
      custNumber: ' '
    })
    this.partsData = [];
    this.otlList = [];
    this.netAmount = 0;
    this.totalTax = 0;
    this.subTotal = 0;
    
    if (value) {
      this._bookingService.validateHospital({"site_id": value.site_id,"custNumber" :value.custNumber }, (response)=>{
        this.opfForm.get('custNumber').setValue(value.custNumber);
        this.opfForm.get('site_id').setValue(value.site_id);
        //set OTL
        this._stockService.getOtl({ "site_id": value.site_id, "order_by":"otl_number", "opf_type":this.opfForm.get('type').value == 'FOC'? OTL_params.FOC : this.opfForm.get('type').value }, (response) => {
          this.otlList = response;
          if (!this.opfForm.get('custName').touched || this.reset) {
            let currentOTL = response.find(res => res.OTLnumber === this.bookingData['OTLNumber']);
            this.opfForm.get('OTLNumber').setValue(currentOTL);
            this.onOtlChange(currentOTL);
          }
        });
    });
    }else{
      this._snackBar.loadSnackBar(" You don't have a permission to raise OPF,Since  hospital is Inactive", colorCodes.ERROR);
      this.cancelOpf();
    }
  }

  onOtlChange(value) {
    this.partsData = [];
    this.isOltNoActive = false;
    this.netAmount = 0; 
    this.totalTax = 0;
    this.subTotal = 0;
    
    
    if (value) {
      this._bookingService.validateOtl({"site_id": value.site_id,"OTLNumber" :value.OTLnumber }, (response)=>{ 
        this.isOltNoActive = true;
      this.regionalId =value['regionalBranchEmailid'] ?value['regionalBranchEmailid'] : '';
      this.opfForm.get('regionalName').setValue(value['regional_name'] ) ;
      this.opfForm.get('salesName').setValue(value['sales_name']) ;
      this.salesId =value['salesEmail'];
      this._bookingService.getOtlPartsOpf({ "OTLNumber": value.OTLnumber,"opf_type":this.opfForm.get('type').value == 'FOC'? OTL_params.FOC : this.opfForm.get('type').value, "order_by": "name"}, (response) => {
        this.otlPartsList = response;
        if ( !this.opfForm.get('OTLNumber').touched || this.reset ) {
          let bookingParts = this.bookingData['parts'].filter(part => {
             return response.find(res =>{
               if (res['partNumber'] == part['partNumber'] && res['OTLNumber'] == value.OTLnumber ) {
                 if (res['isActive'] == 1) {
                  part['HSSNtax'] = res['HSSNtax']
                  part['HSSNcode'] =  res['HSSNcode']
                  part['price'] =  res['price']
                  part['discount'] = res['discount']
                  //part['total_amount'] = this.RoundOFTwoDigit(Number((res['price'] * part['quantity'] - ((res['price'] * part['quantity']) * res['discount'])/100))) ;

                 part['discount_amount']  = this.RoundOFTwoDigit(res['price'] * res['discount'] / 100);
                 part['total_diff']    = res['price'] - part['discount_amount'];
                 part['total_amount']   =  part['total_diff'] * part['quantity'];

                  part['cgst'] = this.RoundOFTwoDigit(Number(((part['total_amount']*(res['HSSNtax']/2))/100))); 
                  part['sgst'] = this.RoundOFTwoDigit(Number(((part['total_amount']*(res['HSSNtax']/2))/100))); 
                  part['igst'] = this.RoundOFTwoDigit(Number(((part['total_amount']*res['HSSNtax'])/100))); 
                   return part;
                 }else{
                   this.invalidParts += res['partNumber'] + '-'
                
                 }
                 
               }

             })
          })
                      
          if (this.invalidParts)  this._snackBar.loadSnackBar( this.invalidParts +  ErrorMessage.IN_ACTIVE_PARTS, colorCodes.ERROR);
          this.partsData = bookingParts;
          this.loadPartsTable(this.partsData);
          this.reset = false;
        }
      });
    });
    }
  }
  loadPartsDialog() {
        // this.partsCurrentOptions= !this.partsData.length ? this.otlPartsList : this.otlPartsList.filter(otlPart => !this.partsData.find(part =>otlPart['partNumber'] === part['partNumber'] ));
        if (this.partsData.length){
          this.otlPartsList =  this.otlPartsList.map(part => {
            let newPart = this.partsData.find(newPart => part['partNumber'] == newPart['partNumber']);
            if (newPart) part['quantity'] = newPart['quantity'];
            return part
          });
        }
    let dialogRef = this.openPartsDialog(this.otlPartsList);
    dialogRef.afterClosed().subscribe(result => {
      if (result ) {
        let index = this.partsData.findIndex(part => part['OTLNumber'] === result['OTLNumber'] && part['partNumber'] === result['partNumber']&& part['lotNumber']=== result['lotNumber'] );
        if(index >= 0 &&  this.partsData.length) this.partsData[index] = result;
        else this.partsData.push(result);
      }
      this.loadPartsTable(result)
    });
  }

  openPartsDialog(data, parts?: any) {
    const dialogRef = this._dialog.open(PartsDialog, {
      autoFocus: false,
      width: '500px',
      data: { "partsOutput": {}, "partsOptions": data, "editParts": parts ? parts : '', "iGst" : this.iGst, "editBooking" : this.bookingId , "OpfType" : this.opfForm.get('type').value,"OTLNumber": this.opfForm.get('OTLNumber').value}
    });
    return dialogRef;
  }

  percentage(num, per) {
    return ((num / 100) * per);
  }

  deleteParts(index) {
      this.partsData.splice(index, 1);
    this.checkPartsDataCount();
  }
  RoundOFTwoDigit(num: any){
    var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
    return number;
  }
  checkPartsDataCount() {
    if (this.partsData.length > 0) this.loadPartsTable(this.partsData);
    else {
      this.netAmount = 0;
      this.totalTax = 0;
      this.subTotal = 0;
    }
  }

  loadPartsTable(result) {
    if (result && this.partsData) {
      this.netAmount= this.partsData.reduce((currentAmount, part)=>{
        return currentAmount+ part['total_amount']
      },0)
      this.totalTax = this.partsData.reduce((currentAmount, part)=>{
        return currentAmount+ (this.iGst ? part['igst'] : (part['sgst'] + part['cgst']))
      },0)
      this.subTotal =  this.partsData.reduce((currentAmount, part)=>{
        return currentAmount+ (part['price'] * part['quantity'])
      },0)
    }
  }

  checkTax() {
    if(this.billingDetails['state'].toLowerCase().replace(/\s/g,'') == BECKMAN_GODOWN.toLowerCase().replace(/\s/g,'')) {
      this.iGst = false;
    }
    else {
      this.iGst = true;
    }
  }

  viewOpfDetails(status){
    this.viewOPF= status 
    this.onSubmit = false;

  }

  cancelOpf(){
    this._router.navigate(['/'+this.moduleName+'/bookings/view' , this.bookingId]);
  }
  createOpf(){
    this.onSubmit = true;
    let data = this.opfForm.value;

    if (this.opfForm.valid){
    data.OTLNumber = this.opfForm.get('OTLNumber').value.OTLnumber;
    data.custName = this.opfForm.get('custName').value.name;
    data.type = OPF_type[this.opfForm.get('type').value];
    data.regionalBranchEmailid = this.regionalId
    data.salesManagerEmailid = this.salesId;
    data['bill_to'] = this.billingDetails['id'];
    data['ship_to'] = this.shipDetails['id'];

    data['net_amount'] = this.RoundOFTwoDigit(Number(this.netAmount));
    data['total_amount'] = this.RoundOFTwoDigit(Number((data['net_amount'] + this.totalTax)));
    data['total_tax'] = this.RoundOFTwoDigit(Number(this.totalTax));
    data['shipping_address'] = this.shipDetails;
    data['status'] = BookingStatus.OPEN;
    let addData = Object.assign(this.getBillingAddress(), data);
    // adding CP details to billing address for OTL, FOC-contract , FOC-others
    addData['billing_address'] =  this.billingDetails ;

    addData.parts = this.partsData;
    addData['contactperson'] = this.cpDetails.contactPerson;
    addData['shipping_address']['type'] = 'shipping';
    addData['billing_address']['type'] = 'billing';
    addData['billing_address']['contactPerson'] =this.billingDetails['contactPerson'];
    addData['orderAgainRef'] = this.bookingData.OPFNumber;
    this._bookingService.addBooking(addData, (response) => {
      if (this.opfForm.get('attachment').value){
        this.addAttachment(response.id);
      }else{
        this._bookingService.navigateToOPFList()
      }
    });
  }
}

setAttachment($event) {
  if(!this.opfForm.get('attachment').errors && $event.target.files[0] && !this.attachmentArray.find(file => file.name ==$event.target.files[0]['name'] )) {
    this.attachmentArray.push($event.target.files[0])
  }
}
addAttachment(opfId) {
  this.attachmentData.append('opf_id', opfId);
  this.attachmentArray.map((file, index) =>{
    this.attachmentData.append(index == 0  ? 'attachment' : 'attachment'+ index, file);
  })
  this._bookingService.addAttachment(this.attachmentData,(response) => {
    this._router.navigate(['/'+this.moduleName+'/bookings'])
    this._snackBar.loadSnackBar(SuccessMessage.OPF_ADD, colorCodes.SUCCESS);
  })
}

clearAttachment(index){
  this.attachmentArray.splice(index,1)
}


  getCpDetail() {
    this._bookingService.getCpDetails((response) => {
      this.cpDetails = response;  
      this.billingList = response.bill_to;
      this.shippingList = response.ship_to;
     });
  }

  getBillingAddress() {
    let data = {
      name: this.cpDetails.name,
      address: this.cpDetails.address,
      city: this.cpDetails.city,
      state: this.cpDetails.state,
      region: this.cpDetails.region,
      pincode: this.cpDetails.pincode,
      telephone: this.cpDetails.telephone,
      mobile: this.cpDetails.mobile,
      fax: this.cpDetails.fax,
      contactPerson : this.cpDetails.contactPerson

    }

    return data;
  }

  //type change 
  OnTypeChange(event){
    if (this.bookingId) {
      this.opfForm.get('OTLNumber').markAsTouched();
      this.partsData = [];
    }
    const isOTLnumberActive = this.opfForm.get('OTLNumber');
    if(this.opfForm.get('type').value || (this.opfForm.value.OTLNumber || this.partsData.length)) {
      let opfType = this.opfForm.get('type').value;
      this.resetOpf();
      this.opfForm.get('type').setValue(opfType);
      this.otlList = [];

        this.othersFoc = false;
        isOTLnumberActive.setValue('');
        this.getCpDetail();
        isOTLnumberActive.enable();
        this.opfForm.get('comment').enable();
    }
    else 
    {
      isOTLnumberActive.disable();
      isOTLnumberActive.updateValueAndValidity();
    }
    this.opfForm.get('comment').updateValueAndValidity();
  }

  resetOpf(value?:any) {
    this.reset = value ? true : false;
      this.setBookingForm(this.bookingData);
      this.getDistinctHospitals();
      this.partsData = this.bookingData['parts'];
      this.loadPartsTable(this.partsData);
 
  }


}



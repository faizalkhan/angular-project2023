import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cpbookings',
  templateUrl: './cpbookings.component.html',
  styleUrls: ['./cpbookings.component.css']
})
export class CpbookingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

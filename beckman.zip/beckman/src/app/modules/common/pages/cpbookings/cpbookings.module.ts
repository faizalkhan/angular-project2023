import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CpbookingsComponent } from './cpbookings.component';
import { RouterModule, Routes } from '@angular/router';
import { CpbookingsListComponent } from './cpbookings-list/cpbookings-list.component';
import { CpbookingsAddComponent, ShippingAddressDialog
 } from './cpbookings-add/cpbookings-add.component';
import { CpbookingsDetailComponent } from './cpbookings-detail/cpbookings-detail.component';
import { AgGridModule } from 'ag-grid-angular';
import { PartsDialog, ListShippingAddressDialog } from '../../dialogs/booking-dialog';
import { RepeatBookingComponent } from './repeat-booking/repeat-booking.component';
import { CpbookingsEditComponent } from './cpbookings-edit/cpbookings-edit.component';
import { CommonDialogModule } from 'src/app/modules/common/dialogs/common-dialog.module';
import { BookingEditComponent } from './booking-edit/booking-edit.component';

const routes: Routes = [{ 
      path: '', 
      component: CpbookingsComponent,
      children:[
        {
          path:'',
          component:CpbookingsListComponent
        },
        {
          path:'add',
          component:CpbookingsAddComponent
        },
        {
          path:'editCP/:id',
          component:CpbookingsEditComponent
        },
        {
          path:'view/:id',
          component:CpbookingsDetailComponent
        },
        {
          path:'repeat/:id',
          component:RepeatBookingComponent
        },
        {
          path:'edit/:id',
          component:BookingEditComponent
        },
        {
          path:':name/view/:id',
          component:CpbookingsDetailComponent
        },
      ]}]

@NgModule({
  declarations: [CpbookingsComponent,BookingEditComponent, CpbookingsListComponent, CpbookingsAddComponent, CpbookingsDetailComponent, ShippingAddressDialog,  RepeatBookingComponent, CpbookingsEditComponent],
  entryComponents: [PartsDialog,ListShippingAddressDialog,ShippingAddressDialog
],
  imports: [
    CommonModule,
    AgGridModule.withComponents([]),
    RouterModule.forChild(routes),
    CommonDialogModule

  ]
})
export class CpbookingsModule { }

import { Component, OnInit, HostListener } from '@angular/core';


import { IGetRowsParams } from 'ag-grid-community';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { AgGridRouterComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-router.component';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { ActionItems } from 'src/app/core/services/constants';
import { StockReportService } from '../../../service/stock-reports/stock-report.service';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-cpbookings-list',
  templateUrl: './cpbookings-list.component.html',
  styleUrls: ['./cpbookings-list.component.css']
})
export class CpbookingsListComponent implements OnInit {

  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public searchValue;
  public gridData = [];
  public bookingSearchForm: FormGroup;
  otlList =[];
  clientNames=[];
  cpNames=[];
  public pageSize = 10;
  public editOpf = false;
  public role;
  public moduleName;  
  public isChannelPartner;
  public isPrimaryLock;
  public editBookings= false;
  public opfPermission;
  public partList=[];
  public isAdmin = false;

  public displayChannelPartnerKeys = ['name', 'cpnumber']
  public displayChannelPartnerKeys1 = ['name', 'custNumber']

  public isOPFFilter: boolean =false;
  public isBacktrigger : boolean = false;
  public iscurrentPath: boolean = false;
  public previousUrl: any;
  public currentUrl : any;
  public routeString: string;
  public stringSplit: any[];
  public isPageRetain: any;
  public pageToNavigate: any;
  public isview: boolean;

  constructor(private _bookingService: CpbookingService,private _StockReportService:StockReportService,
    private _utilsService : UtilsService , private _momentService: MomentService, private fb: FormBuilder,private _StorageService : StorageService, private _secondarysalesService :SecondarysalesService,
    private _formValidator: FormValidatorService, public route: ActivatedRoute, public router: Router) { }
   @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
  }
  ngOnInit() {
    // this.router.events.subscribe(event => {
    //   if (event instanceof NavigationEnd) {        
    //     this.previousUrl = this.currentUrl;
    //     this.currentUrl = event.url;
    //   this.routeString = this.currentUrl;
    //   this.stringSplit = this.routeString.split('/')
    //   if(localStorage.getItem('opffilterpayload') && localStorage.getItem('opfView'))   {
    //       if(this.stringSplit[2] != 'bookings'){
    //         localStorage.removeItem('opffilterpayload')
    //         localStorage.removeItem('opfView');
    //         localStorage.removeItem('opfFilter')
    //       }
    //   }
    //   };
    // });

    this.role = this._StorageService.getUserDetails().role
    this.loadOPFPermission();
    this.moduleName = this._utilsService.moduleName();
    this.isChannelPartner = this._utilsService.isCpRole(this.role);
    this.isAdmin = this._utilsService.isAdminRole(this.role);
    if (this.isChannelPartner){
      this._secondarysalesService.cpModuleAccess(res => {
        this.isPrimaryLock =  res['primaryLock'] == 1  ? true : false
      });
      this.checkEditAccessControl();
    }
  
    this. loadBookingSearchForm();
    this.setClientList ();
    this.setCpList(); 
    this.setOtlList();
    this.setPartsList()
    // this.editOpf = this.setActionsPermission('EDIT')


    this.defaultColDef = {
      sortable: true,
      filter: false,
      resizable: true
    };

    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2
    };

    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.gridOptions.onFilterChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: 'id',
        headerName: 'S No.',
        width: 100,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
      },
      {
        headerName: 'OPF Number',
        field: 'OPFNumber',
        width: 190,
        cellRendererFramework: AgGridRouterComponent,
        cellRendererParams: {
          inRouterLink: '/'+this.moduleName+'/bookings/view/',
        },
      },
      {
        headerName: 'Ordered Date and Time',
        field: 'created_on',
        valueFormatter : this.formatDate.bind(this),
        width: 250,
      },
     
      { 
        headerName: 'Client Name',
        field: 'custName',
        width: 420,
      },
     {
        headerName: 'OTL No.',
        field: 'OTLNumber',
        width: 150,
      },

      {
        headerName: 'Net Amount (Rs.)',
        field: 'net_amount', 
        width: 200,
   
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        cellRenderer :(params) =>{
          return typeof params.value !== 'undefined'?  "<div class = 'text-right'>" + this._utilsService.rupeeFormat(this.RoundOFTwoDigit(params.value)) + "</div>" : ''
        }
      },
      { 
        headerName: 'Total Amount (Rs.)',
        field: 'total_amount',
        width: 200,
   
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        cellRenderer :(params) =>{
          return typeof params.value !== 'undefined' ?  "<div class = 'text-right'>" +this._utilsService.rupeeFormat(this.RoundOFTwoDigit(params.value))  + "</div>" : ''
        }
      },
      {
        headerName: 'Order Status',
        field: 'status',
        width: 190,
      },
      {
        field: 'status',
        headerName: 'Action',
        sortable: false,
        filter: false,
        width: 100,
        cellRendererFramework: AgGridMenuComponent,
        cellRendererParams:  (params) => {
          let menu = [];
          menu.push({
            name: 'View', 
            link: '/'+this.moduleName+'/bookings/view/',
          });
          if (!this.isChannelPartner && this.editBookings && params.value != "Cancelled" &&  params.value != "Rejected" && (this.isAdmin || (!this.isAdmin && params.data && !params.data['isInvoiced']))) {
            menu.push({
                name: 'Edit',
                link: '/'+this.moduleName+'/bookings/edit/',
             })
          }else if (this.isChannelPartner &&this.editBookings && !this.isPrimaryLock&& params.value == 'Open' && this.editOpf ) { 
            menu.push({
              name: 'Edit',
              link: '/'+this.moduleName+'/bookings/editCP/',
            })
          }
          return { 
            menu
          }
        }
      }
    ];

    if (!this.isChannelPartner){
      this.columnDefs.splice(4,0, {
        headerName: 'Channel Partner',
        field: 'cpName',
        width: 250
      } )
    }
  }
  loadOPFPermission(){
    this._bookingService.getActionPermission({model : 'opf'}, response =>{
      this.opfPermission= response['opf'];
      this.editBookings = this.setActionsPermission('EDIT')
    });
  }
  
  setActionsPermission(name){
    return this.opfPermission && typeof this.opfPermission[ActionItems[name]] != 'undefined'  ?  true : false;

 }
  checkEditAccessControl(){
    this._bookingService.getPermissionAccessControls({module : "OPF_Edit"},response =>{
      this.editOpf = response.parent_permission[0].is_allowed;
    })
  }  

  RoundOFTwoDigit(num: any){
    var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
    return number;
  }
  setOtlList(){
    this._bookingService.getListofOTLParts(res =>{
      this.otlList =  this._utilsService.groupByMultipleKeys(res,['name','OTLnumber'])
    })
  }
  setClientList(){
    this._bookingService.listHospital( res =>{
      this.clientNames =  this._utilsService.groupByMultipleKeys(res,['name','custNumber'])
    })
  }
  setPartsList(){
    // need to change api  
    this._StockReportService.getListParts(this.role,(res) => {
      this.partList = res  
    });
  }

  setCpList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpNames = this._utilsService.groupByMultipleKeys(res,['name','cpnumber'])   
    })
  }

  formatDate(params){
    return params.data ? this._momentService.getDateTimeFormat(params.data.created_on) : ''
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi; 
    this.gridApi.sizeColumnsToFit();
    this.setOpfParams();
  }
 
 
  getOPFList(data ?:any) {
    let payload = {};
    var datasource = {
      getRows: (params: IGetRowsParams) =>{
        if (data) {
          payload = data;
        }
        payload['page_size'] =this.pageSize
        payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
        payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
        payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
        // if(this.isOPFFilter){
        //   localStorage.setItem('opffilterpayload', JSON.stringify(payload));
        //   localStorage.setItem('opfFilter', JSON.stringify(this.isOPFFilter));
        // }
        // const c = JSON.parse(localStorage.getItem('opfView'));
        // if(c){
        //   let backup_payload = JSON.parse(localStorage.getItem('opffilterpayload'));
        //   let filter_value = JSON.parse(localStorage.getItem('opfSetvalue'));
        //   if(backup_payload['OPFNumber']){
        //   this.bookingSearchForm.get('OPFNumber').setValue(backup_payload['OPFNumber']);
        //   }
        //   this.bookingSearchForm.patchValue({
        //     cpnumber : this.getCpName(filter_value['cpnumber'])
        //   })
        //   this._bookingService.searchBooking(backup_payload,(res)=>{
        //     let length = res['total'];
        //     this.gridData = res['results'];
        //     params.successCallback(res['results'], length)
        //   })
        // }
         // else{
          this._bookingService.searchBooking(payload,(res)=>{
            let length = res['total'];
            this.gridData = res['results'];
            params.successCallback(res['results'], length)
          })
     //   }

      }
    }
      this.gridApi.setDatasource(datasource);
  }
  setOpfParams(){
    let data = {
      from_date : this._momentService.getFilterFormat(this.bookingSearchForm.get('from_date').value),
      to_date : this._momentService.getFilterFormat(this.bookingSearchForm.get('to_date').value, "toDate"),
    }
   return  this.getOPFList(data);
  }

//  search filter 
 loadBookingSearchForm(){
  this.bookingSearchForm = this.fb.group({
    custNumber: ['',this._formValidator.requireMatch],
    OPFNumber: [''],
    OTLNumber: [''],
    status: [null],
    from_date:[this._momentService.deceedDate(new Date(),31)],
    to_date:[new Date()],
    cpnumber:['', this._formValidator.requireMatch],
    partNumber :  ['',this._formValidator.requireMatch],
  },{ validator: this._formValidator.dateValidation('from_date', 'to_date') });
}

 

searchBookingFilter(){
 if (this.bookingSearchForm.valid){
 let bookingPayload =  this.getBookingPayload(this.bookingSearchForm.value);
 this.isOPFFilter = true;
 this.getOPFList(bookingPayload);
}
} 

getBookingPayload(bookingValue){
  let data =  {};
  data['custNumber'] =  bookingValue.custNumber ? bookingValue.custNumber.custNumber : '';
  data['OTLNumber'] = bookingValue.OTLNumber ? bookingValue.OTLNumber.OTLnumber : '';
  data['from_date'] = bookingValue.from_date ?  this._momentService.getFilterFormat(bookingValue.from_date) : '';
  data['to_date'] = bookingValue.to_date ? this._momentService.getFilterFormat(bookingValue.to_date, "toDate") : '';
  data['OPFNumber'] =bookingValue.OPFNumber ? bookingValue.OPFNumber : '';
  data['status']= bookingValue.status ? bookingValue.status : '';
  data['cpnumber'] = bookingValue.cpnumber ? bookingValue.cpnumber.cpnumber : '';
  data['partNumber'] =bookingValue.partNumber ? bookingValue.partNumber.partNumber : '';
  return data;
}

cancelFilter(){
  // localStorage.removeItem('opfSetvalue');
  // localStorage.removeItem('opffilterpayload');
  // localStorage.removeItem('opfFilter');
  // localStorage.removeItem('opfView');
  this.bookingSearchForm.reset();
  this.bookingSearchForm.get('from_date').setValue(this._momentService.deceedDate(new Date(),31));
  this.bookingSearchForm.get('to_date').setValue(new Date())
  this.setOpfParams();
}

exportBookingFilter(){
  let bookingPayload =  this.getBookingPayload(this.bookingSearchForm.value);
  // bookingPayload['from_date'] = bookingPayload['from_date'] ?  bookingPayload['from_date'] : this._momentService.getFilterFormat(this._momentService.deceedDate(new Date(),90))
  // bookingPayload['to_date'] =  bookingPayload['to_date'] ?  bookingPayload['to_date'] : this._momentService.getFilterFormat(new Date(),"toDate")
  this._bookingService.exportBookingFilter(bookingPayload);
}

importOpf($event) {
  const formData = new FormData();
  formData.append('file', $event.target.files[0]);
  this._bookingService.importOpfCsv(formData, () => {
    this.setOpfParams();
  });
}

importOpfParts($event) {
  const formData = new FormData();
  formData.append('file', $event.target.files[0]);
  this._bookingService.importOpfPartsCsv(formData, () => {
    this.getOPFList();
  });
}

exportOPFTemplate(){
  this._bookingService.exportOpfUploadTemplate();
}
exportOPFInstructions(){
  this._bookingService.exportOpfTemplateInstructions();
}
getCpName(cpNumber?:any){
  let cpDetails = {};
  cpDetails = this.cpNames.find((val) => val.cpnumber === cpNumber);
  return cpDetails ? cpDetails : '';
}
}

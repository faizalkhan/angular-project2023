
import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { routes } from 'src/app/app-routing.module';
import { LoaderComponent } from 'src/app/core/modules/shared/components/loader/loader.component';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { HttpClientModule } from '@angular/common/http';
import { CpbookingsAddComponent } from './cpbookings-add.component';




describe('CpbookingsAddComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes),
        AppMaterialModule,
        CustomFormsModule,
        HttpClientModule
      ],
      providers: [
        Location
      ],
      declarations: [
        CpbookingsAddComponent,
        LoaderComponent
      ],
    }).compileComponents();
   
  }));

  it('should create CP booking add ', () => {
    const fixture = TestBed.createComponent(CpbookingsAddComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

});



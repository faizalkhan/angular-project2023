
import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { routes } from 'src/app/app-routing.module';
import { ChannelpartnersListComponent } from './channelpartners-list.component';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { AgGridModule } from 'ag-grid-angular';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';



describe('ChannelpartnersListComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes),
        AppMaterialModule,
        CustomFormsModule,
        AgGridModule.withComponents([]),
        HttpClientModule,
        BrowserAnimationsModule
      ],
     
      declarations: [
        ChannelpartnersListComponent
      ],
    }).compileComponents();
   
  }));

  it('should create the Channel partner list', () => {
    const fixture = TestBed.createComponent(ChannelpartnersListComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

});



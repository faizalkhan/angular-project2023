import { Component, OnInit, ViewEncapsulation, HostListener } from '@angular/core';
import { ChannelpartnerService } from '../../../../beckman/service/channelpartner/channelpartner.service';
import { AgGridRouterComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-router.component';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Roles } from 'src/app/modules/auth/model/user';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { LocationService } from 'src/app/core/services/utils/location.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { ActionItems } from 'src/app/core/services/constants';

@Component({
  selector: 'app-channelpartners-list',
  templateUrl: './channelpartners-list.component.html',
  styleUrls: ['./channelpartners-list.component.css'],
  encapsulation:ViewEncapsulation.None
})
export class ChannelpartnersListComponent implements OnInit {

  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi; 
  public gridData = [];
  public cpSearchForm: FormGroup;
  public currentState =[];
  public currentCities = [];
  public searchValue;
  public regionFromService= [];
  public moduleName;
  public editCP = false;
  public deleteCp = false;
  public cpPermission;


  constructor(private _channelpartnerService: ChannelpartnerService, private _permissionMenuListService: PermissionMenuListService,
    private _PromptService: PromptService,private _formValidator: FormValidatorService,
    private _utilsService : UtilsService , private fb: FormBuilder, private _locationService: LocationService) { }
  @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
  }

  ngOnInit() {
    this.moduleName = this._utilsService.moduleName()
    this.loadCpPermission();

 
    this.loadLocationData();
    this.loadCpSearchForm();
    this.defaultColDef = {
      sortable: true,
      filter: true,
      resizable: true
    };
    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
    };

    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.gridOptions.onFilterChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: "",
        headerName: 'S No.',
        width: 100,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
      },
      {
        headerName: 'Name',
        field: "name",
        width: 250,
        cellRendererFramework: AgGridRouterComponent,
        cellRendererParams: {
          inRouterLink: '/'+this.moduleName+'/channel-partners/view/',
        },
      },
      {
        headerName: 'CP Number',
        field: "cpnumber",
        width: 150, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        }
      },
      {
        headerName: 'Site ID',
        field: "siteId",
        width: 120,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        }
      },
      
      {
        headerName: 'Region',
        field: "region",
        width: 140,
        valueFormatter: (params) => {
          return this._utilsService.camelCase(params.value)
        }
      },
      {
        headerName: 'City',
        field: "city",
        width: 180,
      },
      {
        headerName: 'State',
        field: "state",
        width: 180,
      }, 
      {
        field: "isActive",
        headerName: 'Status',
        width: 130,
        valueFormatter: (params) =>{
          return this._utilsService.isActiveStatus(params.value)
        }
      },
      {
        field: "",
        headerName: 'Action',
        sortable: false,
        filter: false,
        width: 100,
        cellRendererFramework: AgGridMenuComponent,
        cellRendererParams: (params) =>  {
          let menu =[{
                name: "View",
                link: "/"+this.moduleName+"/channel-partners/view/",
                onMenuAction: ""
              }];
            
          if (this.editCP){
            menu.push({
              name: "Edit",
              link: "/"+this.moduleName+ "/channel-partners/edit/",
              onMenuAction: ""
            })
          } 
          if(this.deleteCp){
            menu.push({
              name: "Delete",
              link: "",
              onMenuAction: this.deleteCpList.bind(this)
            })
          }
          return {menu}        
        },
      }
    ];
  };
  loadCpPermission(){
    this._permissionMenuListService.getActionPermission({model : 'channelpartner'}, response =>{
      this.cpPermission= response['channelpartner'];
      this.editCP = this.setActionsPermission('EDIT');
      this.deleteCp = this.setActionsPermission('DELETE')
    });
  }
  setActionsPermission(name){
    return this.cpPermission && typeof this.cpPermission[ActionItems[name]] != 'undefined'  ?  true : false;
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.getCpList();
  }



  getCpList() {
    this._channelpartnerService.listChannelPartner((res) => {
      this.gridApi.setRowData(res);
      this.gridData = res;
      this.gridApi.paginationGoToFirstPage();
    },
      (error) => {
        this.gridApi.setRowData([]);
        this.gridData = [];
      });
  };

  importChannelPartner($event) {
    const formData = new FormData();
    formData.append('file', $event.target.files[0]);
    this._channelpartnerService.importChannelpartner(formData, () => {
      this.getCpList();
    });
  }
  exportChannelPartner() {
    this._channelpartnerService.exportChannelPartner();
  }

  loadCpSearchForm() {
    this.cpSearchForm = this.fb.group({
      name: [''],
      city: ['',this._formValidator.requireMatch], 
      state: ['',this._formValidator.requireMatch],
      region: ['',this._formValidator.requireMatch],
      contactPerson: [''],
      isActive: ['']

    });
  }
  searchCpFilter() {
    this._channelpartnerService.searchChannelPartner(this.getCpPayload(this.cpSearchForm.value), (res) => {
      this.gridApi.setRowData(res);
      this.gridData = res;
      this.gridApi.paginationGoToFirstPage();
    });
  }

  
  cancelCpFilter() {
    this.getCpList();
    this.cpSearchForm.reset();
  }

  deleteCpList(id) {
    this._PromptService.openDialog({title : 'Delete Channel Partner',btnLabel : 'CONFIRM',content :''}, response =>{
      if (response){
        this._channelpartnerService.deleteChannelPartner(id, () =>  this.getCpList())
      }
    })
    
  }

  loadLocationData() {
    //Location from Service call implementation
    this._locationService.getLocationData((locationData) => {
      this.regionFromService = locationData;
    });
  }

  onRegionChange(value) {
    this.currentCities =[];
    this.currentState =[];
    this.cpSearchForm.patchValue({
      state : '',
      city : ''
    });
    if (value) {
      this.currentState = value.states;
    }
  }

  onStateChange(value) {
    this.currentCities =[];
    this.cpSearchForm.patchValue({
      city : ''
    });
    if (value) {
      this.currentCities = value.cities;
    }
  }
  quickSearch() {
    this.gridApi.setQuickFilter(this.searchValue);
  }

  getCpPayload(data) {
    let cpPayload = {};
    cpPayload['name'] = data.name? data.name : '';
    cpPayload['region'] = data.region ? data.region.name : '';
    cpPayload['city'] = data.city ? data.city.name : '';
    cpPayload['state'] = data.state ?  data.state.name : '';
    cpPayload['contactPerson'] = data.contactPerson ?  data.contactPerson  : '';
    cpPayload['isActive'] = data.isActive ?  data.isActive  : '';
    return cpPayload;
  }

  exportCPFilter() {
    let cpPayload = this.getCpPayload(this.cpSearchForm.value);
    this._channelpartnerService.exportCpFilter(cpPayload);
  }
}

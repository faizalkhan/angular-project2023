import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ParamMap, ActivatedRoute, Router } from '@angular/router';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { ChannelpartnerService } from 'src/app/modules/beckman/service/channelpartner/channelpartner.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { ActionItems } from 'src/app/core/services/constants';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';


@Component({
  selector: 'app-channelpartners-detail',
  templateUrl: './channelpartners-detail.component.html',
  styleUrls: ['./channelpartners-detail.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ChannelpartnersDetailComponent implements OnInit {
  public channelId;
  public data: any;
  public moduleName;
  public editCp = false;
  public deleteCp = false;
  //access control
  public OPFEditControlID=1;
  public InvoiceEditControlID = 2;
  public DCEditControlID = 3;
  public CreditDebitControlID = 64;

  public modifiedAccessControl = [];
  public parentPermission =[];
  
  public OPFEditControlName ="OPF_Edit";
  public InvoiceEditControlName = "Invoice_Edit";
  public DCEditControlName = "DC_Edit";
  public CreditDebitControlName = "Credit_Debit_Edit"; 
  public OtlTransferControlName = "OTL_TRANSFER";


  constructor( private router: Router,private _PromptService: PromptService,  
    public route: ActivatedRoute,private _utilsService : UtilsService , 
    private _channelpartnerService: ChannelpartnerService ,
     private _permissionMenuListService: PermissionMenuListService,) { }

  ngOnInit() {
    this.moduleName = this._utilsService.moduleName()
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.channelId = parseInt(params.get('id'));
    });
    this._channelpartnerService.viewChannelPartner(this.channelId,
      (response) => {
        this.data = response;
        this.modifiedAccessControl = JSON.parse(JSON.stringify(this.data.access_data))    
        this.parentPermission = JSON.parse(JSON.stringify(this.data.parent_permissions))  
        this.data['region'] =  this._utilsService.camelCase(this.data.region)
      },
      (error) => console.log(error))

      this._permissionMenuListService.getActionPermission({model : 'channelpartner'},response =>{
          this.editCp =  response['channelpartner'] && typeof response['channelpartner'][ActionItems['EDIT']] != 'undefined'  ?  true : false; 
          this.deleteCp =response['channelpartner'] && typeof response['channelpartner'][ActionItems['DELETE']] != 'undefined'  ?  true : false; 
        });
  }
  

  
  selectAllControl(checked,params ){    
    //let controlId = params == 'OPF' ? this.OPFEditControlName : (params == 'DC' ? this.DCEditControlName: (params == 'CREDITDEBIT' ? this.CreditDebitControlName: this.InvoiceEditControlName))
    
    let controlId = params == 'OPF' ? this.OPFEditControlName : (params == 'DC' ? this.DCEditControlName: (params == 'CREDITDEBIT' ? this.CreditDebitControlName:
    (params =='OTLTRANSFER' ?  this.OtlTransferControlName : this.InvoiceEditControlName)))
    this.modifiedAccessControl.map(control => {
      if (control.parent_name == controlId) {
        control['is_allowed'] = checked;
      }
     
      return control;
    });
  }


  redirect(){
    this._channelpartnerService.navigateEditCp(this.channelId)
   }

   deleteChannelPartner(){
    this._PromptService.openDialog({title : 'Delete Channel Partner',btnLabel : 'CONFIRM',content :''}, response =>{
      if (response){
        this._channelpartnerService.deleteChannelPartner(this.channelId, (response) =>  this._channelpartnerService.navigateCP())
      }
    })   
  }
}

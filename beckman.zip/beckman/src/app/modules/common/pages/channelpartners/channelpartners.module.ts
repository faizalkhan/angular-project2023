import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ChannelpartnersComponent } from './channelpartners.component';
import { ChannelpartnersAddComponent } from './channelpartners-add/channelpartners-add.component';
import { ChannelpartnersListComponent } from './channelpartners-list/channelpartners-list.component';
import { ChannelpartnersDetailComponent } from './channelpartners-detail/channelpartners-detail.component';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { AgGridModule } from 'ag-grid-angular';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { PipeModule } from 'src/app/core/pipe/pipe.module';

const routes: Routes = [{
  path:'',
  component:ChannelpartnersComponent,
  children:[
    {
      path:'',
      component:ChannelpartnersListComponent
    },
    {
      path:'add',
      component:ChannelpartnersAddComponent
    },
    {
      path: 'view/:id',
      component:ChannelpartnersDetailComponent
    },
    {
      path:'edit/:id',
      component:ChannelpartnersAddComponent
    },

  ]
}]

@NgModule({
  declarations: [
    ChannelpartnersComponent,
    ChannelpartnersAddComponent,
    ChannelpartnersListComponent,
    ChannelpartnersDetailComponent,
    
  ],
  imports: [
    CommonModule,
    AppMaterialModule,
    CustomFormsModule,
    RouterModule.forChild(routes),
    AgGridModule.withComponents([]),
    PipeModule
  ]
})
export class ChannelpartnersModule { }

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-channelpartners',
  templateUrl: './channelpartners.component.html',
  styleUrls: ['./channelpartners.component.css']
})
export class ChannelpartnersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

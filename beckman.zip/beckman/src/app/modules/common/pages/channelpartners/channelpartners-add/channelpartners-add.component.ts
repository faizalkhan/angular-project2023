import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ChannelpartnerService } from '../../../../beckman/service/channelpartner/channelpartner.service';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { LocationService } from 'src/app/core/services/utils/location.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { ActionItems } from 'src/app/core/services/constants';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';



@Component({
  selector: 'app-channelpartners-add',
  templateUrl: './channelpartners-add.component.html',
  styleUrls: ['./channelpartners-add.component.css'],
  encapsulation: ViewEncapsulation.None
})

export class ChannelpartnersAddComponent implements OnInit {



  constructor(private fb: FormBuilder, public route: ActivatedRoute, private _channelPartnerService: ChannelpartnerService,private _utilsService : UtilsService ,private _PromptService: PromptService,private _permissionMenuListService: PermissionMenuListService,
  private _router: Router,  private _momentService : MomentService,  private _formValidator: FormValidatorService,  
  private _locationService: LocationService) { }
  public cpId;
  public data: any;
  public cpForm: FormGroup;
  public currentState = [];
  public currentCities = [];
  public minDate = new Date();
  //Location from Service call implementation
  public regionFromService = [];
    public moduleName;
  //access control
  public OPFEditControlID=1;
  public InvoiceEditControlID = 2;
  public DCEditControlID = 3;
  public CreditDebitControlID = 64;
  public modifiedAccessControl = [];
  public parentPermission =[];
  public isActiveValue: any;

  public OPFEditControlName ="OPF_Edit";
  public InvoiceEditControlName = "Invoice_Edit";
  public DCEditControlName = "DC_Edit";
  public CreditDebitControlName = "Credit_Debit_Edit"; 
  public OtlTransferControlName = "OTL_TRANSFER"; 

  ngOnInit() {
    this.moduleName = this._utilsService.moduleName();
    this.loadCPPermission();
    //Location from Service call implementation
    this.loadLocationData(); 
    this.loadChannelPartnerForms();
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.cpId = parseInt(params.get('id'));
    });
  }
  loadCPPermission(){
    this._permissionMenuListService.getActionPermission({model : 'channelpartner'},response =>{
      console.log(response);
      if((! this.cpId &&  typeof response['channelpartner'][ActionItems['ADD']] == 'undefined')||
       ( this.cpId &&  typeof response['channelpartner'][ActionItems['EDIT']] == 'undefined') ) 
       this._channelPartnerService.navigateCP()
    });
}
  loadChannelPartnerForms() {
    this.cpForm = this.fb.group({
      name: ['', Validators.required],
      isActive: ['1', Validators.required],
      address: ['', Validators.required],
      telephone: ['',this._formValidator.numberValidation],
      region: ['', [Validators.required, this._formValidator.requireMatch]],
      email: ['', [Validators.required, this._formValidator.emailValidation]],
      city: [' ', [Validators.required, this._formValidator.requireMatch]],
      state: [' ', [Validators.required, this._formValidator.requireMatch]],
      pincode: ['', [Validators.required, this._formValidator.pincodePatternValidation]],
      mobile: ['', this._formValidator.mobilePatternValidation],
      gst: ['', [Validators.required,this._formValidator.gstValidation]],
      dl21b: ['', Validators.required],
      dl20b: ['', Validators.required],
      dlExpiry: ['', Validators.required],
      bankName: [''],
      accountName: [''],
      accountNumber: [''],
      pan: ['', [Validators.required,this._formValidator.pancardValidation]],
      cpnumber: ['', Validators.required],
      siteId: ['', Validators.required],
      contactPerson: [''],
      primaryLock: ['0', Validators.required],  
      secondaryLock: ['0', Validators.required],
      businessPurpose : ['', Validators.required],
      stockTransferLock: ['0'],
      opfNamingConvention: ['', Validators.required],
      opfEdit:['0'],
      dcEdit: ['0'],
      invoiceEdit : ['0'],
      creditdebitEdit: ['0'],
      otltransferEdit : ['0'],
      invoiceEditTerms:['15', [Validators.required,this._formValidator.noDecimalsValidation , this._formValidator.negativeValidation, this._formValidator.maxEqualLength(28)]],
      dcEditTerms :['2', [Validators.required,this._formValidator.noDecimalsValidation , this._formValidator.negativeValidation]],
      opfSelectAllControl : [false],
      dcSelectAllControl :[false],
      invoiceSelectAllControl :[false],
      creditdebitSelectAllcontrol: [false],
      otltransferSelectAllcontrol: [false]
    })
  }

 

  loadLocationData() {
    //Location from Service call implementation
    this._locationService.getLocationData((locationData) => {
      this.regionFromService = locationData;
      if(this.cpId) {
        this.getChannelPartnerData();
      }
    });
  }

  getChannelPartnerData() {
    this._channelPartnerService.viewChannelPartner(this.cpId,
      (response) => {
        this.data = response;
        console.log(this.data)
        this.isActiveValue = this.data.isActive

        this.setChannelPartnerData();
      },
      (error) => console.log(error))
  }
 
  accessEventControls(checked, params){
   let control=  this.modifiedAccessControl.find(field => field['id'] == params['id']);
   control['is_allowed'] = checked;
   if (params.parent_name == "OPF_Edit") {
     let opfSelectAllControl = this.modifiedAccessControl.filter(field => field.name!='type' && field.name!='custName'&& field.name!='OTLNumber' && field.parent_name == "OPF_Edit") .every(control=>  control['is_allowed'])
    this.cpForm.get('opfSelectAllControl').setValue(opfSelectAllControl)

   }else if (params.parent_name == "DC_Edit") {
     
    let dcSelectAllControl =this.modifiedAccessControl.filter(field => field.name!='custName' && field.parent_name == this.DCEditControlName) .every(control=>  control['is_allowed'])
    this.cpForm.get('dcSelectAllControl').setValue(dcSelectAllControl)
   } else if (params.parent_name == "Credit_Debit_Edit") {
    let creditdebitSelectAllcontrol =this.modifiedAccessControl.filter(field => field.name!='custName' && field.parent_name == this.CreditDebitControlName) .every(control=>  control['is_allowed'])
    this.cpForm.get('creditdebitSelectAllcontrol').setValue(creditdebitSelectAllcontrol)
   }
   else if (params.parent_name == "OTL_TRANSFER") {
    let otltransferSelectAllcontrol =this.modifiedAccessControl.filter(field => field.name!='custName' && field.parent_name == this.OtlTransferControlName ) .every(control=>  control['is_allowed'])
    this.cpForm.get('otltransferSelectAllcontrol').setValue(otltransferSelectAllcontrol)
   }
   else {
    let invoiceSelectAllControl =this.modifiedAccessControl.filter(field =>  field.name!='custName' && field.parent_name == this.InvoiceEditControlName) .every(control=>  control['is_allowed'])
    this.cpForm.get('invoiceSelectAllControl').setValue(invoiceSelectAllControl)
   }
  }

  // end - access control
  setChannelPartnerData() { 

    this.cpForm.patchValue({
      name: this.data.name,
      isActive: this.data.isActive.toString(),
      address: this.data.address,
      telephone: this.data.telephone,
      region: this.getFilterValue('region', this.data.region),
      email: this.data.email,
      state: this.getFilterValue('state', this.data.state),
      city: this.getFilterValue('city', this.data.city),
      pincode: this.data.pincode,
      mobile: this.data.mobile,
      gst: this.data.gst,
      dl21b: this.data.dl21b,
      dl20b: this.data.dl20b,
      dlExpiry: this.data.dlExpiry,
      pan: this.data.pan,
      accountNumber: this.data.accountNumber,
      accountName: this.data.accountName,
      bankName: this.data.bankName,
      cpnumber: this.data.cpnumber,
      siteId: this.data.siteId,
      contactPerson: this.data.contactPerson,
      primaryLock: this.data.primaryLock.toString(),
      secondaryLock: this.data.secondaryLock.toString(),
      businessPurpose : Array.isArray(this.data.businessPurpose) ? (this.data.businessPurpose.length == 1 ? this.data.businessPurpose[0] : 'BOTH') : this.data.businessPurpose,
      stockTransferLock: this.data.stockTransferLock.toString(),
      opfNamingConvention: this.data.opfNamingConvention,
      opfEdit:this.data.parent_permissions[0]['is_allowed'] ? '1' : '0',
      invoiceEdit : this.data.parent_permissions[1]['is_allowed'] ? '1' : '0',
      dcEdit: this.data.parent_permissions[2]['is_allowed'] ? '1' : '0',
      creditdebitEdit :  this.data.parent_permissions[3]['is_allowed'] ? '1' : '0',
      otltransferEdit :  this.data.parent_permissions[4]['is_allowed'] ? '1' : '0',
      invoiceEditTerms: this.data.invoiceEditTerms,
      dcEditTerms : this.data.dcEditTerms

    });
    //deep copy of array
    this.modifiedAccessControl = JSON.parse(JSON.stringify(this.data.access_data))    
    this.parentPermission = JSON.parse(JSON.stringify(this.data.parent_permissions))       
    this.checkAllControlsSelected()
  }

  selectAllControl(checked,params ){    
   // let controlId = params == 'OPF' ? this.OPFEditControlName : (params == 'DC' ? this.DCEditControlName: (params == 'CREDITDEBIT' ? this.CreditDebitControlName: this.InvoiceEditControlName))
   
   let controlId = params == 'OPF' ? this.OPFEditControlName : (params == 'DC' ? this.DCEditControlName: (params == 'CREDITDEBIT' ? this.CreditDebitControlName:

   (params =='OTLTRANSFER' ?  this.OtlTransferControlName : this.InvoiceEditControlName)))
   this.modifiedAccessControl.map(control => {
      if (control.parent_name == controlId) {
        control['is_allowed'] = checked;
      }
     
      return control;
    });
  }

  checkAllControlsSelected(){
      let opfControls = this.modifiedAccessControl.filter(field => field.name!='type' && field.name!='custName'&& field.name!='OTLNumber' && field.parent_name == "OPF_Edit") .every(control=>  control['is_allowed'])
      this.cpForm.get('opfSelectAllControl').setValue(opfControls)    
      let dcSelectAllControl =this.modifiedAccessControl.filter(field => field.name!='custName' && field.parent_name == this.DCEditControlName) .every(control=>control['is_allowed'])
      this.cpForm.get('dcSelectAllControl').setValue(dcSelectAllControl)      
      let invoiceSelectAllControl =this.modifiedAccessControl.filter(field =>  field.name!='custName' && field.parent_name == this.InvoiceEditControlName).every(control=>  control['is_allowed'])
      this.cpForm.get('invoiceSelectAllControl').setValue(invoiceSelectAllControl)
      let creditdebitSelectAllControl = this.modifiedAccessControl.filter(field =>  field.name!='custName' && field.parent_name == this.CreditDebitControlName ) .every(control=>  control['is_allowed'])
      this.cpForm.get('creditdebitSelectAllcontrol').setValue(creditdebitSelectAllControl);
  }

  getFilterValue(fieldName, value) {
    let options = {};
    if (fieldName === 'region') {
      options = this.regionFromService.filter((val) => {
        return val.name.toLowerCase() === value.toLowerCase()
      });
      this.onRegionChange(options[0]);
    } else if (fieldName === 'state') {
      options = this.currentState.filter((val) => {
        return val.name.toLowerCase().replace(/\s/g,'') === value.toLowerCase().replace(/\s/g,'')
      });
      this.onStateChange(options[0]);
    } else {
      options = this.currentCities.filter((val) => {
        return val.name.toLowerCase() === value.toLowerCase()
      });
    }
    return options[0] ? options[0] : '';
  }

  onRegionChange(value) {
    this.currentCities =[];
    this.currentState =[];
    this.cpForm.patchValue({
      state : '',
      city : ''
    });
    if (value) {
      //Location from Service call implementation
      this.currentState = value.states;
    }
  }

  onStateChange(value) {
    this.currentCities =[];
    this.cpForm.patchValue({
      city : ''
    });
    
    if (value) {
      //Location from Service call implementation
      this.currentCities = value.cities;
    }
  }
 

  submit() {
    if(this.cpForm.get('isActive').value == 0){
      this.cpForm.get('isActive').setValidators(null)
    }
    let cpData = this.cpForm.value;
    cpData.region = this.cpForm.get('region').value.name;
    cpData.state = this.cpForm.get('state').value.name;
    cpData.city = this.cpForm.get('city').value.name;
    cpData.dlExpiry = cpData.dlExpiry ?  this._momentService.getIsoFormat(cpData.dlExpiry) : '';
    if (this.cpId) {
      this.openEditConfirmAccessDialog(cpData);
     
    } else {
      this._channelPartnerService.addChannelPartner(cpData);
    }

  }  
  openEditConfirmAccessDialog(cpData){ 
    this._PromptService.openDialog({title : 'Edit Access Controls',btnLabel : 'CONFIRM',content :'Should you want to apply it for this user?'}, response =>{
      if (response){
        this.parentPermission[0]['is_allowed'] = this.cpForm.get('opfEdit').value == '1' ? true : false;
        this.parentPermission[1]['is_allowed'] = this.cpForm.get('invoiceEdit').value == '1' ? true : false;
        this.parentPermission[2]['is_allowed']  = this.cpForm.get('dcEdit').value == '1' ? true : false;
        this.parentPermission[3]['is_allowed']  = this.cpForm.get('creditdebitEdit').value == '1' ? true : false;
        this.parentPermission[4]['is_allowed']  = this.cpForm.get('otltransferEdit').value == '1' ? true : false;
          // cpData = this.parentPermission;
          cpData['parent_permissions'] = this.parentPermission;
          cpData['access_data'] = this.modifiedAccessControl;
        this._channelPartnerService.editChannelPartner(this.cpId, cpData, () => {
          this.cpId = '';
          this.cpForm.reset();
        });
      }
    })
  }
  resetChannelPartner() {
    if(this.cpId){
      this.modifiedAccessControl= [];
      this.setChannelPartnerData();
    }else{
      this.cpForm.reset();
      this.cpForm.get('isActive').setValue('1');
      this.cpForm.get('primaryLock').setValue('0');
      this.cpForm.get('secondaryLock').setValue('0');
      this.cpForm.get('stockTransferLock').setValue('0');
      this.cpForm.get('businessPurpose').setValue('');
      this.cpForm.get('invoiceEditTerms').setValue('15');
      this.cpForm.get('dcEditTerms').setValue('2');
    }
  }

  cancelChannelPartner() {
    this._channelPartnerService.navigateCP();
  }
 
}

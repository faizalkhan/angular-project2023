import { AgGridRouterComponent } from '../../../../../core/modules/shared/components/ag-grid-router/ag-grid-router.component';
import { Component, OnInit, ViewEncapsulation, HostListener } from '@angular/core';
import { HospitalService } from '../../../../beckman/service/hospital/hospital.service';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Roles } from 'src/app/modules/auth/model/user';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { LocationService } from 'src/app/core/services/utils/location.service';
import { IGetRowsParams } from 'ag-grid-community';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { ActionItems } from 'src/app/core/services/constants';



@Component({
  selector: 'app-hospital-list',
  templateUrl: './hospital-list.component.html',
  styleUrls: ['./hospital-list.component.css'],
  encapsulation:ViewEncapsulation.None
})
export class HospitalListComponent implements OnInit {
  constructor(private _hospitalService: HospitalService,
    private _PromptService: PromptService,
    private _formValidator: FormValidatorService,private _permissionMenuListService: PermissionMenuListService,
    private fb: FormBuilder, private _UtilsService : UtilsService , private _locationService: LocationService) { }


  public columnDefs;
  public defaultColDef;
  public gridOptions; 
  public gridApi;
  public gridColumnApi;
  public hospitalSearchForm: FormGroup;
  public searchValue;
  public currentState = [];
  public currentCities = [];
  public gridData =[];
  public pageSize = 10;
  public regionFromService= [];
  public moduleName;  
  public editHospital =false;
  public deleteHospitalPermission =false;
  public hospitalPermission;
  
  @HostListener('window:resize', ['$event'])onResize(event) {
    this.gridApi.sizeColumnsToFit();
  }

  ngOnInit() { 
    this.loadLocationData();
    this.loadhospitalSearchForm();
    this.moduleName = this._UtilsService.moduleName();
    this.loadHospitalPermission();
    this.defaultColDef = {
      sortable: true,
      filter: false,
      resizable: true
    };
    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2
    };
    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.gridOptions.onFilterChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: "",
        headerName: 'S No.',
        width: 100,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
      },
      {
        headerName: 'Hospital Name',
        field: "name",
        width: 190,
        cellRendererFramework: AgGridRouterComponent,
        cellRendererParams: {
          inRouterLink: '/'+this.moduleName + '/hospitals/view/',
        },
      },
      {
        headerName: 'Customer ID',
        field: "custNumber",
        width: 200,
        comparator: (param1, param2) => {
          return this._UtilsService.alphaNumbericSorting(param1,param2);
        }
      },
      {
        headerName: 'Site ID',
        field: "site_id",
        width: 150,
        comparator: (param1, param2) => {
          return this._UtilsService.alphaNumbericSorting(param1,param2);
        }
      },
      {
        headerName: 'Region',
        field: "region",
        width: 150,
        valueFormatter: (params) => {
          return params.value ? this._UtilsService.camelCase(params.value) : ''
        }
      },
      {
        headerName: 'City',
        field: "city",
        width: 120,
      },
      {
        headerName: 'State',
        field: "state",
        width: 120,
      },
      {
        field: "isActive",
        headerName: 'Status',
        width: 100,
        valueFormatter: (params) =>{
          return (params.value || params.value == 0) ?  this._UtilsService.isActiveStatus(params.value) : ''
        }
      },
      {
        field: "",
        headerName: 'Action',
        sortable: false,
        filter: false,
        width: 100,
        cellRendererFramework: AgGridMenuComponent,
        cellRendererParams: (params) => {
          let menu = [{
            name: "View",
            link: "/"+this.moduleName + "/hospitals/view/",
            onMenuAction:''
          }]
          if (this.editHospital){
            menu.push({
              name: "Edit",
              link: "/"+this.moduleName + "/hospitals/edit/",
              onMenuAction:''
            })
          }
          if (this.deleteHospitalPermission){
            menu.push(
              {
                name: "Delete",
                link: "",
                onMenuAction: this.deleteHospital.bind(this)
              })
          }
          return {menu} 
        },
      }
    ];
  }

  setActionsPermission(name){
    return this.hospitalPermission && typeof this.hospitalPermission[ActionItems[name]] != 'undefined'  ?  true : false;
  }

  loadHospitalPermission(){
      this._permissionMenuListService.getActionPermission({model : 'hospitals'}, response =>{
        this.hospitalPermission= response['hospitals'];
        this.editHospital = this.setActionsPermission('EDIT');
        this.deleteHospitalPermission = this.setActionsPermission('DELETE');
      });
  }

deleteHospital(id){
  this._PromptService.openDialog({title : 'Delete Hospital',btnLabel : 'CONFIRM', content: 'Are you sure you want to delete hospital?'}, response =>{
    if (response){
      this._hospitalService.deleteHospital(id,()=>this.getHospitalList())
    }
  })
}
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.getHospitalList();
  }

  getHospitalList(data ?:any) {
    let payload = {};
    var datasource = {
      getRows: (params: IGetRowsParams) =>{
        if (data) {
          payload = data;
        }
        payload['page_size'] =this.pageSize
        payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
        payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
        payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
        this._hospitalService.searchHospital(payload, (res)=>{
          let length = res['total'];
          this.gridData = res['results'];
          params.successCallback(res['results'], length) 
          })
      }
    }
      this.gridApi.setDatasource(datasource);
  }

  importHospital($event) {
    const formData = new FormData();
    formData.append('file', $event.target.files[0]);
    this._hospitalService.importHospital(formData, () => {
      this.getHospitalList();
    });
  }

  exportHospital() {
    this._hospitalService.exportHospital();
  }

  loadhospitalSearchForm() {
    this.hospitalSearchForm = this.fb.group({
      name: [''],
      site_id: [''],
      cust_number: [''],
      isActive : [''],
      region: ['',this._formValidator.requireMatch],
      state: ['',this._formValidator.requireMatch],
      city: ['',this._formValidator.requireMatch],
    });
  }

  searchHospitalFilter() {
    let payload = this.getHospitalPayload(this.hospitalSearchForm.value) ;
    this.getHospitalList(payload)
  }

  getHospitalPayload(data){
    let hospitalPayload ={};
    hospitalPayload['region'] = data.region ? data.region.name : '';
    hospitalPayload['city'] = data.city ? data.city.name : '';
    hospitalPayload['state'] = data.state ?  data.state.name : '';
    hospitalPayload['site_id'] = data.site_id ?  data.site_id  : '';
    hospitalPayload['cust_number'] = data.cust_number ?  data.cust_number  : '';
    hospitalPayload['name'] = data.name? data.name : '';
    hospitalPayload['isActive'] = data.isActive? data.isActive : '';
    return hospitalPayload;
  }

  loadLocationData() {
    //Location from Service call implementation
    this._locationService.getLocationData((locationData) => {
      this.regionFromService = locationData;
    });
  }
   
  onRegionChange(value) {
    this.currentCities =[];
    this.currentState =[];
    this.hospitalSearchForm.patchValue({
      state : '',
      city : ''
    });
    if (value) {
      this.currentState = value.states;
    }
  }

  onStateChange(value) {
    this.currentCities =[];
    this.hospitalSearchForm.patchValue({
      city : ''
    });
    if (value) {
      this.currentCities = value.cities;
      
    }
  }
  cancelHospitalFilter() {
    this.getHospitalList();
    this.hospitalSearchForm.reset();
  }

  exportHospitalFilter(){
    let hospitalPayload = this.getHospitalPayload( this.hospitalSearchForm.value);
    this._hospitalService.exportHospitalFilter(hospitalPayload);
  }

}

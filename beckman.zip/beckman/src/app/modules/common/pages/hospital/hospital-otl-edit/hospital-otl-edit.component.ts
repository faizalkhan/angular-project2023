import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { sectors } from 'src/app/core/services/constants';

@Component({
  selector: 'app-hospital-otl-edit',
  templateUrl: './hospital-otl-edit.component.html',
  styleUrls: ['./hospital-otl-edit.component.css'],
  encapsulation : ViewEncapsulation.None
})
export class HospitalOtlEditComponent implements OnInit {

  constructor(
    public _dialogRef: MatDialogRef<HospitalOtlEditComponent>,
    @Inject(MAT_DIALOG_DATA) public editOtlData: any,
    private fb: FormBuilder, private _formValidator: FormValidatorService
  ) { }
  otlForm: FormGroup;
  public options = [];
  public data = {};
  displaySalesPersonKeys = ['name', 'email']
  public displayChannelPartnerKeys = ['name', 'cpnumber']
  public groupedUserEmail;
  public salesPerson =[];
  isEdit: boolean=true;

  ngOnInit() {
    this.options = this.editOtlData.options;
    this.salesPerson = this.editOtlData.salesPerson
    this.groupedUserEmail = this.editOtlData.groupedUserEmail

    this.loadOtlForm();
    this.statusValueChanged();
  }
  loadOtlForm() {
      let data = this.editOtlData.otlData;
      this.otlForm = this.fb.group({
      OTLnumber: [{value: data.OTLnumber,  disabled: true}, [Validators.required,this._formValidator.alphaNumericValidation]],
      start_date: [data.start_date , Validators.required],
      end_date: [ data.end_date, Validators.required],
      isActive: [data.isActive.toString()],
      inActiveReason: [data.inActiveReason],
      salesEmail: [this.salesPerson.some(res => res['email'].toLowerCase() == data.salesEmail.toLowerCase() ) ? this.salesPerson.find(res => res['email'].toLowerCase() == data.salesEmail.toLowerCase() ) : '', [Validators.required,this._formValidator.requireMatch]],
      businessUnitEmailid: [this.groupedUserEmail['NationalSalesManager'].some(res => res['email'] == data.businessUnitEmailid ) ? this.groupedUserEmail['NationalSalesManager'].find(res => res['email'] == data.businessUnitEmailid ) : '',this._formValidator.requireMatch],
      regionalBranchEmailid: [ this.groupedUserEmail['RegionalBusinessManager'].some(res => res['email'] == data.regionalBranchEmailid ) ? this.groupedUserEmail['RegionalBusinessManager'].find(res => res['email'] == data.regionalBranchEmailid ) : '', this._formValidator.requireMatch],
      corporateMgrEmailid: [this.groupedUserEmail['CorporateManager'].some(res => res['email'] == data.corporateMgrEmailid ) ? this.groupedUserEmail['CorporateManager'].find(res => res['email'] == data.corporateMgrEmailid ) : '', this._formValidator.requireMatch],
      govtMgrEmailid: [ this.groupedUserEmail['GovtManager'].some(res => res['email'] == data.govtMgrEmailid ) ?  this.groupedUserEmail['GovtManager'].find(res => res['email'] == data.govtMgrEmailid ) : '', this._formValidator.requireMatch],
      productLineMgrEmailid: [this.groupedUserEmail['ProductlineManager'].some(res => res['email'] == data.productLineMgrEmailid ) ? this.groupedUserEmail['ProductlineManager'].find(res => res['email'] == data.productLineMgrEmailid ) : '', this._formValidator.requireMatch],
      teamLeadEmailid: [this.groupedUserEmail['StateManager'].some(res => res['email'] == data.teamLeadEmailid ) ? this.groupedUserEmail['StateManager'].find(res => res['email'] == data.teamLeadEmailid ) : '', this._formValidator.requireMatch],
      commitment: [data.commitment, this._formValidator.withZeroAndNegativeValidation],
      corporatePersonEmailid: [this.groupedUserEmail['CorporatePerson'].some(res => res['email'] == data.corporatepersonEmailid ) ? this.groupedUserEmail['CorporatePerson'].find(res => res['email'] == data.corporatepersonEmailid) : '', this._formValidator.requireMatch],
      govtPersonEmailid:  [this.groupedUserEmail['GovtPerson'].some(res => res['email'] == data.govtpersonEmailid ) ? this.groupedUserEmail['GovtPerson'].find(res => res['email'] == data.govtpersonEmailid) : '', this._formValidator.requireMatch],
      distEmail: [data.distEmail],
      type: [data.type, Validators.required],
      site_id: [data.site_id],
      custNumber : [data.custNumber],
      cpnumber: [this.getCpName(data.cpnumber), [Validators.required,this._formValidator.requireMatch]]
    }, { validator: this._formValidator.dateValidation('start_date', 'end_date') });
    
  }

  getCpName(custNumber){
    let cpDetails = {};
    cpDetails = this.options.filter((val) => {
        return val.cpnumber=== custNumber
      });
    return cpDetails[0] ? cpDetails[0] : '';
  }
  statusValueChanged(){
    const inActiveReason = this.otlForm.get('inActiveReason');
    this.otlForm.get('isActive').valueChanges.subscribe(
      (status: any) => {
        if(status == 0) {
          inActiveReason.enable();
          inActiveReason.setValidators([Validators.required, this._formValidator.noWhitespaceValidation]);
        }
        else {
          this.otlForm.controls['inActiveReason'].setValue(null);
          inActiveReason.disable();
          inActiveReason.clearValidators();
        }
        inActiveReason.updateValueAndValidity();
      })
   }
  onSubmit() {
    this.otlForm.value['OTLnumber'] = this.otlForm.get('OTLnumber').value;
    this._dialogRef.close(this.otlForm.value);
  }
  cancelOtlForm() {
    this.otlForm.reset();
    this._dialogRef.close();
  }
  resetOtlForm(){
    let data = this.editOtlData.otlData;
    this.otlForm.patchValue({
      OTLnumber: data.OTLnumber,
      type: data.type,
      start_date:data.start_date,
      end_date: data.end_date,
      isActive: data.isActive.toString(),
      commitment: data.commitment,
      distEmail: data.distEmail,
      cpnumber: this.getCpName(data.cpnumber),
      inActiveReason: data.inActiveReason,
      salesEmail: this.salesPerson.find(res => res['email'] == data.salesEmail ) ? this.salesPerson.find(res => res['email'] == data.salesEmail ) : '',
      businessUnitEmailid:this.groupedUserEmail['NationalSalesManager'].find(res => res['email'] == data.businessUnitEmailid ) ? this.groupedUserEmail['NationalSalesManager'].find(res => res['email'] == data.businessUnitEmailid ) : '',
      regionalBranchEmailid:  this.groupedUserEmail['RegionalBusinessManager'].find(res => res['email'] == data.regionalBranchEmailid ) ? this.groupedUserEmail['RegionalBusinessManager'].find(res => res['email'] == data.regionalBranchEmailid ) : '',
      corporateMgrEmailid: this.groupedUserEmail['CorporateManager'].find(res => res['email'] == data.corporateMgrEmailid ) ? this.groupedUserEmail['CorporateManager'].find(res => res['email'] == data.corporateMgrEmailid ) : '', 
      govtMgrEmailid: this.groupedUserEmail['GovtManager'].find(res => res['email'] == data.govtMgrEmailid ) ?  this.groupedUserEmail['GovtManager'].find(res => res['email'] == data.govtMgrEmailid ) : '',
      productLineMgrEmailid: this.groupedUserEmail['ProductlineManager'].find(res => res['email'] == data.productLineMgrEmailid ) ? this.groupedUserEmail['ProductlineManager'].find(res => res['email'] == data.productLineMgrEmailid ) : '',
      teamLeadEmailid:this.groupedUserEmail['StateManager'].find(res => res['email'] == data.teamLeadEmailid ) ? this.groupedUserEmail['StateManager'].find(res => res['email'] == data.teamLeadEmailid ) : '', 
      corporatePersonEmailid :  this.groupedUserEmail['CorporatePerson'].find(res => res['email'].data.corporatepersonEmailid) ? this.groupedUserEmail['CorporatePerson'].find(res => res['email'] == data.corporatepersonEmailid ) : '',
      govtpersonEmailid  : this.groupedUserEmail['GovtPerson'].find(res => res['email'].data.govtpersonEmailid) ?  this.groupedUserEmail['GovtPerson'].find(res => res['email'] == data.govtpersonEmailid ) : '',



    

    })
  }

}

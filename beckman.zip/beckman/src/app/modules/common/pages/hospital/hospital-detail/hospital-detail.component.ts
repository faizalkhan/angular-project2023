import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { HospitalService } from '../../../../beckman/service/hospital/hospital.service';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Tab } from '../../../model/dynamic-tab.model';
import { ChannelpartnerService } from '../../../../beckman/service/channelpartner/channelpartner.service';
import { DynamicTabComponent } from '../dynamic-tab/dynamic-tab.component';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { Roles } from 'src/app/modules/auth/model/user';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { ActionItems } from 'src/app/core/services/constants';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';


@Component({
  selector: 'app-hospital-detail',
  templateUrl: './hospital-detail.component.html',
  styleUrls: ['./hospital-detail.component.css'],
  encapsulation:ViewEncapsulation.None
})
export class HospitalDetailComponent implements OnInit {
  hospitalId;
  tabs = new Array<Tab>();  // whole tab details [{component, custid, componentdata}]
  selectedTab: number;
  public currentIndex;
  public viewData:any;
  public otlData = [];
  public index = 0; // initally setting the first tab as  active 
  public cpName =[];
  public editHospital =false;
  public addOTL = false;
  public deleteHospitalPermission = false;
  public moduleName;  
  
  constructor(public route: ActivatedRoute, private _PromptService: PromptService,private _permissionMenuListService: PermissionMenuListService,private router: Router,private _bookingService:CpbookingService ,private _StorageService: StorageService, private _ChannelpartnerService: ChannelpartnerService,
    private _hospitalService: HospitalService,private _UtilsService: UtilsService) { }

  ngOnInit() {
    this.loadHospitalPermission()
    this.moduleName = this._UtilsService.moduleName()
    // Moved this based on region based filter in CP
    this._bookingService.listChannelPartner((res)=>{
      this.cpName = res;
    })

    this.route.paramMap.subscribe((params: ParamMap) => {
      this._hospitalService.resetTab();
      this.hospitalId = parseInt(params.get('id'));
    });
    
   
    // view hospital data
   this.getHospitalData();
    // update the tabs and getting array of tab from subject
    this._hospitalService.tabSub.subscribe(tabs => {
      this.tabs = tabs;
      this.selectedTab = this.index === 0 ? 0 : tabs.findIndex(tab => tab.active); 
    });
  }
  loadHospitalPermission(){
    this._permissionMenuListService.getActionPermission({model : ['hospitals', 'otl']},response =>{
      this.editHospital =response['hospitals'] && typeof response['hospitals'][ActionItems['EDIT']] != 'undefined'  ?  true : false; 
      this.deleteHospitalPermission =response['hospitals'] && typeof response['hospitals'][ActionItems['DELETE']] != 'undefined'  ?  true : false; 
      this.addOTL =response['otl']  && typeof response['otl'][ActionItems['ADD']] != 'undefined'  ?  true : false; 
    });
}
  getHospitalData(){
    this._hospitalService.viewHospital(this.hospitalId.toString(),
    (res)=>{
      this.viewData = res;
      this.viewData['region'] = this._UtilsService.camelCase(this.viewData.region)
      this.getCpListByRegion(res);
      
    });
  }

  getCpListByRegion(hospitalData) {
    // this._ChannelpartnerService.searchChannelPartner({'region': hospitalData.region}, (res) => {
    this._bookingService.listChannelPartner( (res) => {
      this.cpName = res;
      if (hospitalData.otl_list.length > 0){
        this.loadDynamicViewTab();
      }else{
        this.addNewTab();
      }
    });
    
  }

  loadDynamicViewTab(){
   this.otlData =  this.viewData.otl_list;
    for (let i=0; i<this.otlData.length;i++){
      this.otlData[i]['sector'] = this.viewData.sector;
      this._hospitalService.addTab(new Tab(DynamicTabComponent, this.otlData[i].OTLnumber, this.otlData[i]));
    }
  }


  addNewTab() {
    this._hospitalService.addTab(
      new Tab(DynamicTabComponent, 'Add OTL', this.viewData)
    );
    
  }

  addOtlSubmit(otlData){
    otlData.custNumber =  this.viewData.custNumber;
    otlData.site_id = this.viewData.site_id;
    // otlData.type = this.viewData.sector;
    this._hospitalService.addOtl(otlData,(res)=>{
      this._hospitalService.addTab(new Tab(DynamicTabComponent,res.OTLnumber, res));
      this.removeTab();
    });
  }

  deleteOtl(res){
    this._hospitalService.removeTab(this.currentIndex);
    let length = this._hospitalService.tabSub.getValue().length;
    
    if (length == 0){
      this.addNewTab();
    }
  }
  deleteHospital(){
    this._PromptService.openDialog({title : 'Delete Hospital',btnLabel : 'CONFIRM', content: 'Are you sure you want to delete hospital?'}, response =>{
      if (response){
        this._hospitalService.deleteHospital(this.hospitalId,(response)=>console.log(response))
      }
    })
   
  }
 
  selectedIndexChange(event){
    this.index = this.index+1;
    this.currentIndex = event;
  }


  removeTab(tabIndex?:number): void {
    this._hospitalService.removeTab(tabIndex ? tabIndex : this.currentIndex);
  }

  redirect(){
    this._hospitalService.navigateToEditHospital(this.hospitalId)
  }
}
 
import { Component, OnInit, ViewChild, Input, ComponentFactoryResolver, EventEmitter, Output, OnChanges } from '@angular/core';
import { Tab } from 'src/app/modules/common/model/dynamic-tab.model';
import { TabContentDirective } from '../tab-content.directive';


@Component({
  selector: 'app-tab-view',
  template: `<ng-template appTabContent></ng-template>`
})
export class TabViewComponent implements OnInit {
  @Output() otlFormSubmit : EventEmitter<any> = new EventEmitter<any>(); 
  @Output() deleteOtlData : EventEmitter<any> = new EventEmitter<any>(); 
  @Output() cancelOTL: EventEmitter<any> = new EventEmitter<any>(); 

  @Input() tabInput;
  @Input() clientName;
 
  @ViewChild(TabContentDirective, { static: true })
  contentContainer: TabContentDirective;

  constructor(private componentFactoryResolver: ComponentFactoryResolver) {}

  ngOnInit() {
    const tab: Tab = this.tabInput;
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(
      tab.component
    );
     
    const viewContainerRef = this.contentContainer.viewContainerRef;
    // getting the appTabContent directive instance and  creating component dynamically , setting a input to dynamic component
    const componentRef = viewContainerRef.createComponent(componentFactory);
    componentRef.instance.data = this.tabInput.tabData;
    componentRef.instance.title = this.tabInput.title;
    componentRef.instance.cpName = this.clientName;
 

    // subscribe for outPut event 
    componentRef.instance.submitOtl.subscribe(val => {
      this.otlFormSubmit.emit(val);
    });

    componentRef.instance.deleteOtl.subscribe(val => {
      this.deleteOtlData.emit(val);
    });
    componentRef.instance.cancelOtl.subscribe(val => {
      this.cancelOTL.emit(val);
    });
  }

}

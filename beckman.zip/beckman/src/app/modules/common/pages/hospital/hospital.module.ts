import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HospitalComponent } from './hospital.component';
import { RouterModule, Routes } from '@angular/router';
import { AgGridModule } from 'ag-grid-angular';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { HospitalListComponent } from './hospital-list/hospital-list.component';
import { HospitalDetailComponent } from './hospital-detail/hospital-detail.component';
import { HospitalAddComponent } from './hospital-add/hospital-add.component';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { HospitalOtlEditComponent } from './hospital-otl-edit/hospital-otl-edit.component';
import { DynamicTabComponent } from './dynamic-tab/dynamic-tab.component';
import { TabContentDirective } from './tab-content.directive';
import { TabViewComponent } from './tab-view/tab-view.component';
import { PipeModule } from 'src/app/core/pipe/pipe.module';

const routes: Routes = [{
  path:'', 
  component:HospitalComponent,
  children:[{
    path: '',
    component:HospitalListComponent
  },
  {
    path: 'view/:id',
    component:HospitalDetailComponent
  },
  {
    path:'add',
    component:HospitalAddComponent
  },
  {
    path:'edit/:id',
    component:HospitalAddComponent
  }
]
}]

@NgModule({
  declarations: [
    HospitalComponent,
    HospitalListComponent,
    HospitalDetailComponent,
    HospitalAddComponent,
    DynamicTabComponent,
    HospitalOtlEditComponent,
    TabViewComponent,
    TabContentDirective
  ],
  entryComponents:[DynamicTabComponent,HospitalOtlEditComponent],
  imports: [
    CommonModule,
    AppMaterialModule,
    CustomFormsModule,
    RouterModule.forChild(routes),
    AgGridModule.withComponents([]),
    PipeModule
  ]
})
export class HospitalModule { }

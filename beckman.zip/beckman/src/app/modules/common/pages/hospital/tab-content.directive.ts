import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[appTabContent]'
})
export class TabContentDirective {
  // refrence to create component 
  constructor(public viewContainerRef: ViewContainerRef) {
   }

}

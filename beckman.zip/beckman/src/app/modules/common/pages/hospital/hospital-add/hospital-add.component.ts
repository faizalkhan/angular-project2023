import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { HospitalService } from '../../../../beckman/service/hospital/hospital.service';
import { ParamMap, ActivatedRoute } from '@angular/router';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { LocationService } from 'src/app/core/services/utils/location.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { ActionItems } from 'src/app/core/services/constants';

@Component({
  selector: 'app-hospital-add',
  templateUrl: './hospital-add.component.html',
  styleUrls: ['./hospital-add.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class HospitalAddComponent implements OnInit {
  
  public minDate = new Date();

  constructor(private fb: FormBuilder, private _formValidator: FormValidatorService, public route: ActivatedRoute,  private _UtilsService : UtilsService,private _permissionMenuListService: PermissionMenuListService,
    private _momentService: MomentService, private _hospitalService: HospitalService, private _locationService: LocationService) { }
  public forms: FormGroup;
  public formError = {};
  public State = [];
  public currentCities = [];
  // as of now   
  
  public productNames = []
  public hospitalId;
  public hospitalData;
  //Location from Service call implementation
  public regionFromService = [];
  public  moduleName;
  public isSubmit = false;

  ngOnInit() {
    this.loadHospitalPermission();
    this.moduleName = this._UtilsService.moduleName();
    this.loadLocationData();
    this.loadForms();

    this.route.paramMap.subscribe((params: ParamMap) => {
      this.hospitalId = parseInt(params.get('id'));
    });
    
  }

  loadHospitalPermission(){
    this._permissionMenuListService.getActionPermission({model : 'hospitals'},response =>{
      if((! this.hospitalId && typeof response['hospitals'][ActionItems['ADD']] == 'undefined')|| ( this.hospitalId && typeof response['hospitals'][ActionItems['EDIT']] == 'undefined') ) this.redirectTo();
    });
}


  loadForms() {
    this.forms = this.fb.group({
      name: ['', Validators.required],
      custNumber: ['', Validators.required],
      site_id: ['', Validators.required],
      telephone: ['',this._formValidator.numberValidation],
      region: ['', [Validators.required, this._formValidator.requireMatch]],
      email: ['', this._formValidator.emailValidation],
      address: ['', Validators.required],
      city: ['', [Validators.required, this._formValidator.requireMatch]],
      state: ['', [Validators.required, this._formValidator.requireMatch]],
      pincode: ['', [Validators.required, this._formValidator.pincodePatternValidation]],
      contactperson: [''],
      isActive: ['1', Validators.required],
      mobile:['', this._formValidator.mobilePatternValidation],
      sector:['', Validators.required],
      segmentation:['', Validators.required],
      dl20b:[''],
      dl21b:[''],
      dlExpiry:[''],
      pan:['', this._formValidator.pancardValidation],
      gst:['', this._formValidator.gstValidation],
      bankName:[''],
      accountName:[''],
      accountNumber:[''],
      businessPurpose : ['', Validators.required]
    });
  }
  
  loadLocationData() {
    //Location from Service call implementation
    this._locationService.getLocationData((locationData) => {
      this.regionFromService = locationData;
      if(this.hospitalId) {
        this.getHospitalData();
      }
    });
  }

  onRegionChange(value) {
    this.currentCities =[];
    this.State =[];
    this.forms.patchValue({
      state : '',
      city : ''
    });
    if (value) {
      //Location from Service call implementation
      this.State = value.states;
    }
  }

  onStateChange(value) {
    this.currentCities =[];
    this.forms.patchValue({
      city : ''
    });
    if (value) {
       //Location from Service call implementation
      this.currentCities = value.cities;
    }
  }


  
  resetForm() {
    if (this.hospitalId){
      this.setHospitalData();
    } else{
      this.forms.reset();
      this.forms.get('isActive').setValue('1');
      this.forms.get('businessPurpose').setValue('');
      this.forms.get('segmentation').setValue('');
      this.forms.get('sector').setValue('');

    }
   
  }

  submit() {
    let hospitalData = this.forms.value;
    hospitalData.region = this.forms.get('region').value.name;
    hospitalData.state = this.forms.get('state').value.name;
    hospitalData.city = this.forms.get('city').value.name;
    hospitalData.dlExpiry = hospitalData.dlExpiry ? this._momentService.getIsoFormat(hospitalData.dlExpiry) : null;
      
    if(this.hospitalId) {
      this._hospitalService.editHospital(this.hospitalId, hospitalData, () => {
        this.hospitalId = '';
        this.forms.reset();
      });
    }
    else {
      this._hospitalService.addHospital(hospitalData);
    }
    
  }

  getHospitalData() {
    this._hospitalService.viewHospital(this.hospitalId,
      (response) => {
        this.hospitalData = response;
        this.setHospitalData();
      })
  }

  setHospitalData() {

    this.forms.setValue({
      name: this.hospitalData.name,
      custNumber: this.hospitalData.custNumber,
      site_id: this.hospitalData.site_id,
      telephone: this.hospitalData.telephone,
      region: this.getFilterValue('region', this.hospitalData.region),
      email: this.hospitalData.email,
      address: this.hospitalData.address,
      state: this.getFilterValue('state', this.hospitalData.state),
      city: this.getFilterValue('city', this.hospitalData.city),
      pincode:this.hospitalData.pincode,
      contactperson: this.hospitalData.contactperson,
      isActive: this.hospitalData.isActive.toString(),
      mobile : this.hospitalData.mobile,
      sector: this.hospitalData.sector.toLowerCase(),
      segmentation:this.hospitalData.segmentation.toUpperCase(),
      dl20b:this.hospitalData.dl20b,
      dl21b:this.hospitalData.dl21b,
      dlExpiry:this.hospitalData.dlExpiry,
      pan:this.hospitalData.pan,
      gst:this.hospitalData.gst,
      bankName:this.hospitalData.bankName,
      accountName:this.hospitalData.accountName,
      accountNumber:this.hospitalData.accountNumber,
      businessPurpose : Array.isArray(this.hospitalData.businessPurpose) ? (this.hospitalData.businessPurpose.length == 1 ? this.hospitalData.businessPurpose[0] : 'BOTH') : this.hospitalData.businessPurpose,
      
    })
  }
  getFilterValue(fieldName, value) {
    let options = {};
    if (fieldName === 'region') {
      // this.onRegionChange(value);
      options = this.regionFromService.filter((val) => {
        return val.name.toLowerCase() === value.toLowerCase()
      });
      this.onRegionChange(options[0]);
    } else if (fieldName === 'state') {
      // this.onStateChange(value);
      options = this.State.filter((val) => {
        return val.name.toLowerCase().replace(/\s/g,'') === value.toLowerCase().replace(/\s/g,'')
      });
      this.onStateChange(options[0]);
    } else {
      options = this.currentCities.filter((val) => {
        return  val.name.toLowerCase() === value.toLowerCase()
      });
    }
    
    return options[0] ? options[0] : '';
  }

  redirectTo(){
    this._hospitalService.navigate();
  }

}

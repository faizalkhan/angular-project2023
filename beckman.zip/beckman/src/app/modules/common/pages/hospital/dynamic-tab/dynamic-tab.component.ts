import { Component, Input, OnInit, Output, EventEmitter, ViewEncapsulation, OnChanges } from '@angular/core';
import {  FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import {MatDialog} from '@angular/material/dialog'
import { HospitalOtlEditComponent } from 'src/app/modules/common/pages/hospital/hospital-otl-edit/hospital-otl-edit.component';
import { HospitalService } from 'src/app/modules/beckman/service/hospital/hospital.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { ActionItems } from 'src/app/core/services/constants';
import { OtlmasterService } from 'src/app/modules/beckman/service/hospital/otlmaster.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';

@Component({
  selector: 'app-dynamic-tab',
  templateUrl: './dynamic-tab.component.html',
  styleUrls: ['./dynamic-tab.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class DynamicTabComponent implements OnInit {
  @Output() submitOtl: EventEmitter<any> = new EventEmitter<any>();
  @Output() deleteOtl: EventEmitter<any> = new EventEmitter<any>();
  @Output() cancelOtl: EventEmitter<any> = new EventEmitter<any>();
  @Input() data;
  @Input() title;
  @Input()cpName;

  otlForm: FormGroup;

  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public channelPartnerName='';
  public displayChannelPartnerKeys = ['name', 'cpnumber']
  displaySalesPersonKeys = ['name', 'email']
  public editOtl =false;
  public groupedUserEmail ;
  public salesPerson = [];

  constructor(private fb: FormBuilder, 
    public _dialog: MatDialog,
    private _formValidator: FormValidatorService, private _otlMasterService: OtlmasterService,private _permissionMenuListService: PermissionMenuListService,
    private _PromptService: PromptService,
    public _hospitalService :HospitalService, private _momentService: MomentService, private _utilService:UtilsService) { }
  
  ngOnInit() {
    this.cpName = this.getUniqueValue(this.cpName);

    this._permissionMenuListService.getActionPermission({model :  'otl'}, response =>{
      this.editOtl = typeof response['otl'][ActionItems['EDIT']] == 'undefined' ?  false : true
    });
    this.loadOtlForm();
    // if (this.title == 'Add OTL'){
      this.groupedUserList();
    // }
    this.statusValueChanged();
    this.channelPartnerName  = this.getCpName(this.data.cpnumber);
    this.loadGrid();

  }
  loadGrid() {
    this.defaultColDef = {
      sortable: true,
      filter: true,
      resizable: true
    };
    this.gridOptions = {
      rowHeight: 45
    }
    this.columnDefs = [
      {
        field: "OTLNumber",
        headerName: 'OTL No',
      },
      {
        headerName: 'Part Number',
        field: "partNumber",
        comparator:(param1,param2)=>{
          return this._utilService.alphaNumbericSorting(param1,param2);
        }
      },
      {
        field: "description",
        headerName: 'Description',
        width : 300
      },
      {
        headerName: 'Product Line',
        field: "part.productLine",
      }, 
      {
        headerName: 'Price',
        field: "price",
        valueFormatter: (params) => {
          return this._utilService.rupeeFormat(this.RoundOFTwoDigit(params.value))
        }
      },
      {
        headerName: 'Discount',
        field: "discount",
      }
    ];
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    params.api.setRowData(this.data.otl_parts);
  }

  groupedUserList(){
    this._otlMasterService.groupUserEmail(response =>{
      this.groupedUserEmail = response;
      this.salesPerson = [...response['Salesperson'], ...response['RegionalBusinessManager'], ...response['StateManager']];
    })
  }


  loadOtlForm() {
    this.otlForm = this.fb.group({
      OTLnumber: ['', [Validators.required,this._formValidator.alphaNumericValidation]],
      type: [null, Validators.required],
      start_date: ['', Validators.required],
      end_date: ['', Validators.required],
      isActive: ['1'],
      inActiveReason: [{value: null, disabled: true}],
      salesEmail: ['', [Validators.required,this._formValidator.requireMatch]],
      businessUnitEmailid: ['', this._formValidator.requireMatch],
      regionalBranchEmailid: ['', this._formValidator.requireMatch],
      corporateMgrEmailid: ['', this._formValidator.requireMatch],
      govtMgrEmailid: ['', this._formValidator.requireMatch],
      productLineMgrEmailid: ['', this._formValidator.requireMatch],
      corporatePersonEmailid: ['', this._formValidator.requireMatch],
      govtPersonEmailid: ['', this._formValidator.requireMatch],
      teamLeadEmailid: ['', this._formValidator.requireMatch],
      commitment: ['', this._formValidator.withZeroAndNegativeValidation],
      distEmail: ['', this._formValidator.emailValidation],
      cpnumber : ['', [Validators.required, this._formValidator.requireMatch]]
    }, { validator: this._formValidator.dateValidation('start_date', 'end_date')});
  }
  
  statusValueChanged(){
    const inActiveReason = this.otlForm.get('inActiveReason');
    this.otlForm.get('isActive').valueChanges.subscribe(
      (status: any) => {
        if(status == 0) {
          inActiveReason.enable();
          inActiveReason.setValidators([Validators.required, this._formValidator.noWhitespaceValidation]);
        }
        else {
          this.otlForm.controls['inActiveReason'].setValue(null);
          inActiveReason.disable();
          inActiveReason.clearValidators();
        }
        inActiveReason.updateValueAndValidity();
      })
   }
  onSubmit() {
    let data =  this.otlForm.value;
    data['cpnumber'] =this.otlForm.get('cpnumber').value.cpnumber;
    data.start_date = this._momentService.getIsoFormat(this.otlForm.get('start_date').value);
    data.end_date = this._momentService.getIsoFormat(this.otlForm.get('end_date').value);
    data['inActiveReason']  = this.otlForm.get('inActiveReason').value;
    data['salesEmail'] =  this.otlForm.get('salesEmail').value ? this.otlForm.get('salesEmail').value.email : '';
    data['businessUnitEmailid']=this.otlForm.get('businessUnitEmailid').value ? this.otlForm.get('businessUnitEmailid').value.email : '';
    data['regionalBranchEmailid']  = this.otlForm.get('regionalBranchEmailid').value ? this.otlForm.get('regionalBranchEmailid').value.email : '';
    data['corporateMgrEmailid']   = this.otlForm.get('corporateMgrEmailid').value ? this.otlForm.get('corporateMgrEmailid').value.email : '';
    data['govtMgrEmailid']  = this.otlForm.get('govtMgrEmailid').value ? this.otlForm.get('govtMgrEmailid').value.email : '';
    data['productLineMgrEmailid'] =this.otlForm.get('productLineMgrEmailid').value ? this.otlForm.get('productLineMgrEmailid').value.email : '';
    data['teamLeadEmailid']  = this.otlForm.get('teamLeadEmailid').value ? this.otlForm.get('teamLeadEmailid').value.email : '';
    data['corporatepersonEmailid']  = this.otlForm.get('corporatePersonEmailid').value ? this.otlForm.get('corporatePersonEmailid').value.email : '';
    data['govtpersonEmailid']  = this.otlForm.get('govtPersonEmailid').value ? this.otlForm.get('govtPersonEmailid').value.email : '';
    // data.start_date =this.otlForm.get('start_date').value  ? this.otlForm.get('start_date').value.toISOString() : '';
    // data.end_date =this.otlForm.get('end_date').value  ? this.otlForm.get('end_date').value.toISOString() : ''; 
    this.submitOtl.emit(data)
  }

  resetOtlForm() {
    this.otlForm.reset();
    this.otlForm.get('isActive').setValue('1');
  }

  getCpName(custNumber){
    let cpDetails = {};
    cpDetails = this.cpName.filter((val) => {
        return val.cpnumber=== custNumber
      });
    return cpDetails[0] ? cpDetails[0].name : '';
  }

  editOtlForm(){
    this._hospitalService.viewOtl(this.data.id,(res)=>{
      res['sector'] = this.data['sector'];
      this.loadEditView(res);
    },()=>console.log('error'));
   
  }

  loadEditView(res){
    const dialogRef = this._dialog.open(HospitalOtlEditComponent, {
      width: '900px',
      data: {otlData :res, options: this.cpName ,salesPerson : this.salesPerson , groupedUserEmail : this.groupedUserEmail}
    });

    dialogRef.afterClosed().subscribe(otlData => {
      if (otlData){
      // otlData.start_date = otlData.start_date && typeof(otlData.start_date) === 'string' ? otlData.start_date : otlData.start_date.toISOString();
      // otlData.end_date = otlData.end_date &&  typeof(otlData.end_date) === 'string' ? otlData.end_date : otlData.end_date.toISOString();
      otlData.start_date = this._momentService.getIsoFormat(otlData.start_date);
      otlData.end_date = this._momentService.getIsoFormat(otlData.end_date);
      otlData.cpnumber = otlData.cpnumber.cpnumber;
      console.log(otlData)
      otlData['salesEmail'] =  otlData['salesEmail'] ? otlData['salesEmail'].email : '';
      otlData['businessUnitEmailid']= otlData['businessUnitEmailid']?  otlData['businessUnitEmailid'].email : '';
      otlData['regionalBranchEmailid']  = otlData['regionalBranchEmailid'] ? otlData['regionalBranchEmailid'].email : '';
      otlData['corporateMgrEmailid']   =  otlData['corporateMgrEmailid']  ?  otlData['corporateMgrEmailid'] .email : '';
      otlData['govtMgrEmailid']  =  otlData['govtMgrEmailid']?  otlData['govtMgrEmailid'].email : '';
      otlData['productLineMgrEmailid'] = otlData['productLineMgrEmailid'] ? otlData['productLineMgrEmailid'].email : '';
      otlData['teamLeadEmailid']  = otlData['teamLeadEmailid'] ? otlData['teamLeadEmailid'].email : '';
      otlData['corporatepersonEmailid']  = otlData['corporatePersonEmailid'] ?  otlData['corporatePersonEmailid'].email : '';
      otlData['govtpersonEmailid']  =  otlData['govtPersonEmailid'] ?  otlData['govtPersonEmailid'].email : '';
        this._hospitalService.editOtl(this.data.id,otlData,(res)=>{
        this.data.isActive = res.isActive;
        this.data.inActiveReason = res.inActiveReason;
        this.data.salesEmail = res.salesEmail;
        this.data.corporatepersonEmailid = res.corporatepersonEmailid;
        this.data.govtpersonEmailid = res.govtpersonEmailid;  
        this.data.businessUnitEmailid = res.businessUnitEmailid;
        this.data.OTLnumber = res.OTLnumber;
        this.data.type= res.type;
        this.data.distEmail= res.distEmail;
        this.data.regionalBranchEmailid=res.regionalBranchEmailid;
        this.data.govtMgrEmailid=res.govtMgrEmailid;
        this.data.corporateMgrEmailid=res.corporateMgrEmailid;
        this.data.productLineMgrEmailid=res.productLineMgrEmailid;
        this.data.teamLeadEmailid = res.teamLeadEmailid;
        this.data.commitment =res.commitment;
        this.data.start_date= res.start_date;
        this.data.end_date=res.end_date;
        this.channelPartnerName  = this.getCpName(res.cpnumber)
        })
      }
    })
  }
  deleteOtlForm(){
    this._PromptService.openDialog({title : 'Delete OTL',btnLabel : 'CONFIRM',content :'Are you sure you want to delete OTL'}, response =>{
      if (response){
        this._hospitalService.deleteOtl(this.data.id,(res)=>{
          this.deleteOtl.emit(res)
        })
      }
    })
   
  }

  cancelOTLForm(){
    this.cancelOtl.emit();
  }

RoundOFTwoDigit(num: any){
      var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
      return number;
    }
  getUniqueValue(res){
    var uniqueArr =[];
    res.forEach((item)=>{
      var i= uniqueArr.findIndex(x=>x.cpnumber == item.cpnumber);
      if(i<=-1){
        uniqueArr.push(item);
      }
      return null;
    });
    return uniqueArr;
  }
  
}

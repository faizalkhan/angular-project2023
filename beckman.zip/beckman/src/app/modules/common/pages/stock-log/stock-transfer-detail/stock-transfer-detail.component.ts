import { Component, OnInit } from '@angular/core';
import { StockService } from 'src/app/modules/cpadmin/service/stock.service';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { MatDialog } from '@angular/material';
import { ReduceReverseDialog } from 'src/app/modules/common/dialogs/secondary-dialog/dialog.component';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { ActionItems } from 'src/app/core/services/constants';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';


@Component({
  selector: 'app-stock-transfer-detail',
  templateUrl: './stock-transfer-detail.component.html',
  styleUrls: ['./stock-transfer-detail.component.css']
})
export class StockTransferDetailComponent implements OnInit {


  public logId;
  public stockLogData;
  public stockLogPermission;
  constructor(public route: ActivatedRoute, private _bookingService: CpbookingService, private _StockService: StockService, public _dialog: MatDialog) { }

  ngOnInit() {
    this.loadStockLogPermission();
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.logId = parseInt(params.get('id'));
    });
    this.getStock();
  }
  getStock(){
    this._StockService.searchStock({'id':this.logId}, (response) => {
      this.stockLogData = response['results'][0];
    });
  }

  reduceStock() {
    const dialogRef = this._dialog.open(ReduceReverseDialog, {
      width: '600px',
      data:  this.stockLogData
    });

    dialogRef.afterClosed().subscribe(result => { 
      if(result) {
        if (result) {
          this.getStock();
        }
      }
    });
  }
  cancel(){
    this._StockService.navigateTo();
  }
  reversalStock(){
    this._StockService.navigateToReversal(this.logId)
  }


 
 loadStockLogPermission(){
  this._bookingService.getActionPermission({model : 'stocklog'}, response =>{
    this.stockLogPermission= response['stocklog'];
  });
}

setActionsPermission(name){
  return this.stockLogPermission && typeof this.stockLogPermission[ActionItems[name]] != 'undefined'  ?  true : false;
}

}
 
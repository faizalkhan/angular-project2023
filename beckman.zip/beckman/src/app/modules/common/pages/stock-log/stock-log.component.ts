import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-log',
  templateUrl: './stock-log.component.html',
  styleUrls: ['./stock-log.component.css']
})
export class StockLogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

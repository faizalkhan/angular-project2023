import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, ValidationErrors } from '@angular/forms';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { StockService } from 'src/app/modules/cpadmin/service/stock.service';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { Router } from '@angular/router';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { Roles } from 'src/app/modules/auth/model/user';
import { ActionItems } from 'src/app/core/services/constants';

@Component({
  selector: 'app-stock-swap-new',
  templateUrl: './stock-swap-new.component.html',
  styleUrls: ['./stock-swap-new.component.css']
})
export class StockSwapNewComponent implements OnInit {

  public displayClientKeys = ['name', 'address']
  public stockId;
  public stockSwapForm: FormGroup;
  public clientNames = [];
  public otlList = [];
  public clientNumber;
  public otlPartsList = [];
  public partsData = [];
  public partsList = [];
  public stockDetails = [];
  public displayLotKeys = ['lotNumber', 'lotExpiryDate']
  public lotList = [];
  public viewStock = false;
  public currentRelatedPartswithQty = [];
  public stockLotList = [];
  public relatedParts = [];
  public helper = {}
  public displayPartsKeys = ['partNumber','description'];
  public selectedOtl_number: any;

  constructor(private fb: FormBuilder, private _stockService: StockService,private _StorageService: StorageService,
    private _MomentService: MomentService, private _utilsService: UtilsService,private _secondarysalesService :SecondarysalesService,  private _router: Router,
    private _bookingService: CpbookingService, private _formValidator: FormValidatorService) { }

  ngOnInit() {
    this._bookingService.getActionPermission({model : 'stocklog'}, response =>{
      if (!response['stocklog'] || !response['stocklog'][ActionItems['ADD_STOCK_SWAP']])this.cancel();
    })
    this.loadStockSwapForm();
    if (this._StorageService.getUserDetails().role == Roles.Channel_Partner) {
      this._secondarysalesService.cpModuleAccess(res => {
        if (res['stockTransferLock'] == 1)   this._router.navigate(['/channel-partner/secondary-sales/stock-transfer']);
         });
    }
  
  this._bookingService.getDistinctHospitals({ isActive: 1 }, (response => {
    this.clientNames = response
  }));
   

    this.stockSwapForm.get('desiredQty').valueChanges.subscribe(value => {
      if (this.stockSwapForm.get('relatedParts') && value) {
        let arrayControl = this.stockSwapForm.get('relatedParts') as FormArray;
        arrayControl.controls.map((control) => {
          control.get('desiredQuantityForSwapTransfer').enable();
          control.updateValueAndValidity();
        });
      }
    })
  }

  loadStockSwapForm() {
    this.stockSwapForm = this.fb.group({
      fromHospital: ['', [Validators.required, this._formValidator.requireMatch]],
      OTLNumber: ['', [Validators.required, this._formValidator.requireMatch]],
      custNumber: ['', Validators.required],
      siteId: ['', Validators.required],
      desiredQty: ['', Validators.required],
      partNumber: ['', Validators.required],
      lotNumber: ['', Validators.required],
    }, { validator: this.swapPartsValidation });
  }


  resetParts() {
    this.currentRelatedPartswithQty = []
    this.partsData = [];
    this.stockSwapForm.get('desiredQty').setValue('');
    if (this.stockSwapForm.get('relatedParts')) this.stockSwapForm.removeControl('relatedParts');
  }

  onClientChange(value) {
    this.resetParts();
    this.stockSwapForm.get('partNumber').setValue('');
    this.stockSwapForm.get('lotNumber').setValue('');
    this.stockSwapForm.get('OTLNumber').setValue('');
    this.otlList = [];
    this.lotList = [];
    this.partsList = [];


    // filter parts 

    this.stockSwapForm.get('siteId').setValue(value.site_id);
    this.stockSwapForm.get('custNumber').setValue(value.custNumber);
    
    this._stockService.getOTLParts({ "custNumber": value.custNumber }, (response) => {
     // this.otlList = this._utilsService.groupByProperty(response, 'OTLNumber');
     if(response){
      this._stockService.getOtl({ "custNumber": value.custNumber}, (response1) => {
      this.otlList = response1;
    })
  }
      this.stockDetails = response;
    })
  }



  onOtlChange(value) {
    this.selectedOtl_number = value['OTLnumber'];
    this.stockSwapForm.get('siteId').setValue(value.site_id);
    this.resetParts();
    this.partsList = [];
    this.lotList = [];
    this.stockSwapForm.get('partNumber').setValue('');
    this.stockSwapForm.get('lotNumber').setValue('');
    if (this.stockSwapForm.get('relatedParts')) this.stockSwapForm.removeControl('relatedParts');
    // filter parts 

    let filteredParts = this.stockDetails.filter(res => res['OTLNumber'] == value['OTLnumber']);
    this.partsList = this._utilsService.groupByProperty(filteredParts, 'partNumber')    //this.getUnqiueData(filteredParts, 'partNumber')
  }
  onPartsChange(value) {
    this.resetParts();
    this.lotList = [];
    this.stockSwapForm.get('lotNumber').setValue('');
    if (this.stockSwapForm.get('relatedParts')) this.stockSwapForm.removeControl('relatedParts');

    // filter lots  stockLotList- contains all lotnumber with different lot expiry dates respective to selected partNumber
    
    this.stockLotList = this.stockDetails.filter(res => res['partNumber'] == value['partNumber'] && res['OTLNumber'] == this.selectedOtl_number);
    //&& res['OTLNumber'] == this.selectedOtl_number
   
    // get unqiue lot number with lot expiry date
    this.lotList = this._utilsService.groupByProperty(this.stockLotList, 'lotNumber','lotExpiryDate');
  }


groupBySumOfProperty(array, key1, key2 , key3){
  let obj= {};
  return array.reduce(function(currentArray, data) {
    var key = data[key1] + '-' + data[key2] + '-' + data[key3];
    if(!obj[key]) {
      obj[key] = Object.assign({}, data);
      currentArray.push(obj[key]);
    }else{
      obj[key]['availableQuantity'] =obj[key]['availableQuantity']+ data['availableQuantity']
    }   
    return currentArray;
  }, [])
}


  onLotChange(value) {
    this.resetParts();

    // sum of total  availableQuantity in each parts 
    value['availableQuantity'] = this.stockLotList.reduce((currentQty, data )=>{
        if (value['lotNumber'] == data['lotNumber'] && value['lotExpiryDate']== data['lotExpiryDate']) {
           currentQty += data['availableQuantity'];
        }
        return currentQty;
    },0)

    if ( value['availableQuantity'] ) {
      this.partsData = [value];

     
    this.stockSwapForm.get('desiredQty').setValidators([Validators.required, this._formValidator.noDecimalsValidation, this._formValidator.maxEqualLength(value.availableQuantity)]);

    this._stockService.getRelatedHospitalParts({ "custNumber": value.custNumber, "partNumber": value.partNumber, 
    "lotExpiryDate": this._MomentService.getIsoFormat(value.lotExpiryDate), "siteId": this.stockSwapForm.get('siteId').value, "otlNumber": this.stockSwapForm.get('OTLNumber').value.OTLnumber}, (response) => {
      if (response.length) {
        this.relatedParts = response;
        // groupby response 
       let filteredResponse =  this.groupBySumOfProperty(response, 'OTLNumber', 'lotNumber','lotExpiryDate');
        this.stockSwapForm.addControl('relatedParts', this.fb.array(this.getRelatedParts(filteredResponse)))
      }
    })
    }
    
  }

  getRelatedParts(relatedParts) {
    return relatedParts.map((data) => {
      return this.fb.group({
        custNumber: [data.custNumber],
        name: [data.name],
        address: [data.address],
        state: [data.state],
        city: [data.city],
        pincode: [data.pincode],
        OTLNumber: [data.OTLNumber],
        partNumber: [data.partNumber],
        lotNumber: [data.lotNumber],
        lotExpiryDate: [data.lotExpiryDate],
        originalQuantity: [data.originalQuantity],
        secondarySalesQuantity: [data.secondarySalesQuantity],
        availableQuantity: [data.availableQuantity],
        siteId: [data.siteId],
        unitPurchasePrice: [data.unitPurchasePrice],
        cpNumber: [data.cpNumber],
        origin: [data.origin],
        purchaseRowIdentifier: [data.purchaseRowIdentifier],
        region: [data.region],
        id: [data.id],
        description: [data.description],
        desiredQuantityForSwapTransfer: [{ value: '', disabled: true }, [this._formValidator.maxEqualLength(data.availableQuantity), this._formValidator.noDecimalsValidation]]
      });
    });
  }

  swapPartsValidation(group: FormGroup): ValidationErrors | null {
    if (group.controls['desiredQty'].value && group.controls.relatedParts) {
      let arrayControls = group.controls.relatedParts as FormArray;
      let totaldesiredQtySwapTransfer = arrayControls.controls.reduce((currentAmount, control) => {
        return currentAmount + Number(control.value.desiredQuantityForSwapTransfer)
      }, 0);

      if (totaldesiredQtySwapTransfer && group.controls['desiredQty'].value < totaldesiredQtySwapTransfer) return { 'swapDesiredQuantity': true }
    }
    return null;
  }
  
  gettotaldesiredQtySwapTransfer() {
    let data = this.stockSwapForm.value.relatedParts && this.stockSwapForm.value.relatedParts.reduce((currentAmount, control) => {
      return currentAmount + Number(control.desiredQuantityForSwapTransfer)
    }, 0);
    return data
  }




  createStockTransfer() {
    let data ={};
    data['from_customer'] = {};
    data['from_customer']['totalAvailableQuantity']  = this.partsData[0]['availableQuantity'];
    data['from_customer']['desiredQuantityForSwapTransfer'] = Number(this.stockSwapForm.get('desiredQty').value);
    data['from_customer']['data'] = this.stockDetails.filter(res => {
      if (this.partsData[0]['lotNumber'] == res['lotNumber'] && this.partsData[0]['lotExpiryDate'] ==  res['lotExpiryDate']){
        res['desiredQuantityForSwapTransfer'] = 0;
        return res;
      }
    });
    let array =[];
    this.stockSwapForm.value.relatedParts.map((data) => {
      let  obj = {};
      if (data['desiredQuantityForSwapTransfer'] > 0){
         obj['desiredQuantityForSwapTransfer'] = data['desiredQuantityForSwapTransfer'];
         obj['data'] =  this.relatedParts.filter(response => {
           if(response['OTLNumber'] == data['OTLNumber'] && response['lotNumber'] == data['lotNumber'] && response['lotExpiryDate'] == data['lotExpiryDate']){
           response['desiredQuantityForSwapTransfer'] = 0;
            return response;
           }
          });
         array.push(obj);
      }
    });
    data['with_customers']  =array;

    this._stockService.createStockSwap(data)

  }

  cancel() {
    this._stockService.navigateTo();
  }

  resetStock() {
    this.resetParts();
    this.stockSwapForm.reset();
  }

  viewStockSwapDetails(value) {
      this.viewStock = value;
      this.currentRelatedPartswithQty = this.stockSwapForm.value.relatedParts.filter(response => response['desiredQuantityForSwapTransfer'] > 0);
  

  }

}

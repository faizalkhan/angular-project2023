import { Component, OnInit, HostListener } from '@angular/core';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { StockService } from 'src/app/modules/cpadmin/service/stock.service';
import { AgGridStockComponent } from 'src/app/core/modules/shared/components/ag-grid-stock/ag-grid-stock.component';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { IGetRowsParams } from 'ag-grid-community';
import { Roles } from 'src/app/modules/auth/model/user';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { ActionItems } from 'src/app/core/services/constants';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';

@Component({
  selector: 'app-stock-transfer-list',
  templateUrl: './stock-transfer-list.component.html',
  styleUrls: ['./stock-transfer-list.component.css']
})
export class StockTransferListComponent implements OnInit {

  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi; 
  public gridColumnApi;
  public searchValue;
  public stockTransSwapSearchForm: FormGroup;
  public fromOtlList =[];
  public toOtlList =[];
  public isStockTransferLock; 
  public pageSize = 10;
  public moduleName;
  public viewStockLog = false;
  public stockLogPermission;
  public isAdmin:boolean = false;
  public cpList = [];
  public gridData = []
  public role ;
  public isChannelPartner;
  public displayChannelPartnerKeys = ['name', 'cpnumber']
  public displayChannelPartnerKeys1 = ['name', 'custNumber']
  constructor(private _StockService: StockService,private _StorageService: StorageService,private _bookingService: CpbookingService,private _formValidator: FormValidatorService,
     private _secondarysalesService :SecondarysalesService, private _UtilsService : UtilsService,private _momentService: MomentService, private fb: FormBuilder) { }
     @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
  }
  ngOnInit() {
    this. loadStockTransSwapFilterForm();
    this.moduleName = this._UtilsService.moduleName()
    this.role = this._StorageService.getUserDetails().role;
    this.isAdmin = this.role == Roles.Admin ;
    this.isChannelPartner = this._UtilsService.isCpRole(this.role);
    this.loadStockLogPermission();
    this.setCPList();
    
    if (this._StorageService.getUserDetails().role == Roles.Channel_Partner) {
      this._secondarysalesService.cpModuleAccess(res => {
        this.isStockTransferLock = res['stockTransferLock'] == 1  ? true : false
      });
    }
    this.defaultColDef = {
      sortable: true,
      filter: false,
      resizable: true
    };

    this.gridOptions = {
      rowHeight: 75,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2
    };

    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.gridOptions.onFilterChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      { 
        field: 'id',
        headerName: 'S No.',
        width: 40,
        sortable: false,
        filter: false,  
        valueGetter: "node.rowIndex + 1",
      },
      {
        headerName: 'Date',
        width: 90,
        field: 'swapTransferDateAndTime',
        valueFormatter : this.formatDate.bind(this)
      },
      {
        headerName: 'Type',
        field: 'indicator',
        width:60,
        valueFormatter: (params) =>{
          if (params.value) {
            return params.value == 'S' ? 'Swap' : 'Transfer'
          }
         
        }
      },
      {
        headerName: 'From End Customer',
        field: '',
        width: 160,
        sortable: false,
        filter: false,
        cellRendererFramework: AgGridStockComponent,
        cellRendererParams: {
          headerName : 'name',
          menu: [
          {
            title: "Lot No",
            name: "lotNumber",
          },
          {
            title : "Item No",
            name: "itemNumber",
          }
          ]
        }
      },
      {
        headerName: 'From Customer No.',
        field: 'fromEndCustomerNumber',
        width:100,
      },
      {
        headerName: 'From OTL',
        field: 'fromOTL',
        width:80,
      },
      {
        headerName: 'To End Customer',
        field: '',
        width: 160,
        sortable: false,
        filter: false,
        cellRendererFramework: AgGridStockComponent,
        cellRendererParams: {
          headerName : 'end_customer_name',
          menu: [
          {
            title: "Lot No",
            name: "toEndCustomerLotNumber",
          },
          {
            title : "Item No",
            name: "itemNumber",
          }
          ]
        }
      },
      {
        headerName: 'To Customer No.',
        field: 'toEndCustomerNumber',
        width:100,
      },
      {
        headerName: 'To OTL',
        field: 'toOTL',
        width:80,
      },
      {
        headerName: 'Original Transfer Swap Qty',
        field: 'swapTransferQuantity',
        width: 90,
      },
      {
        headerName: 'Available Qty',
        field: 'availableQuantity',
        width: 90,
      },
      {
        field: '',
        headerName: 'Action',
        sortable: false,
        filter: false,
        width: 100,
        cellRendererFramework: AgGridMenuComponent,
        cellRendererParams: (params) => {
          let menu = []
            menu.push({
              name: 'View',
              link: '/'+this.moduleName+'/secondary-sales/stock-transfer/view',
              newTab : true
            })
          return {menu}
        },
      }
    ];


  }
  setCPList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpList = this._UtilsService.groupByMultipleKeys(res,['name','cpnumber'])   
    })
  }
  loadStockLogPermission(){
    this._bookingService.getActionPermission({model : 'stocklog'}, response =>{
      this.stockLogPermission= response['stocklog'];
    });
  }

  setActionsPermission(name){
    return this.stockLogPermission && typeof this.stockLogPermission[ActionItems[name]] != 'undefined'  ?  true : false;
  }

 
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.setStockTransferParams();
  }
  setStockTransferParams(){
    let data = {
      from_date : this._momentService.getFilterFormat(this.stockTransSwapSearchForm.get('from_date').value),
      to_date : this._momentService.getFilterFormat(this.stockTransSwapSearchForm.get('to_date').value, "toDate"),
    }
   this.getStockTransferList(data);
  }
  getStockTransferList(data?:any) {
    let payload = {};
    var datasource = {
      getRows: (params: IGetRowsParams) =>{
        if (data) {
          payload = data;
        }
        payload['page_size'] =this.pageSize
        payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
        payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
        payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
        this._StockService.searchStock(payload, (res)=>{
           let length = res['total'];
           res['results'].forEach((element: any, index) => {
           let hospitaldetails = element.hospital_details;
           let customerdetails =   element.end_customer_details;
           let grid =  Object.assign(element, hospitaldetails, customerdetails);       
           this.gridData.push(grid);
        });           
          params.successCallback(res['results'], length) // data and totalcount of records 
          })
      }
    }
      this.gridApi.setDatasource(datasource);
  }

  formatDate(params){
    return params.data ? this._momentService.getDateTimeFormat(params.data.swapTransferDateAndTime) : ''
  }


  loadStockTransSwapFilterForm() {
    this.stockTransSwapSearchForm = this.fb.group({ 
      fromEndCustomerNumber: [''],
      fromOTL: [''],
      toEndCustomerNumber: [''],
      toOTL: [''],
      itemNumber: [''],
      lotNumber: [''],
      lotExpiry: [''],
      indicator: [''],
      // swapTransferDateAndTime:[''],
      readableTransferId: [''],
      from_date:[this._momentService.deceedDate(new Date(),31)],
      to_date:[new Date()],
      cpNumber: ['', this._formValidator.requireMatch]
    },{ validator: this._formValidator.dateValidation('from_date', 'to_date') });
  }
  getStockPayload(data){
    let stockPayload ={};
    stockPayload['fromEndCustomerNumber'] = data.fromEndCustomerNumber ? data.fromEndCustomerNumber : '';
    stockPayload['fromOTL'] = data.fromOTL ? data.fromOTL : '';
    stockPayload['toOTL'] = data.toOTL ?  data.toOTL : '';
    stockPayload['itemNumber'] = data.itemNumber ?  data.itemNumber  : '';
    stockPayload['lotNumber'] = data.lotNumber? data.lotNumber : '';
    stockPayload['lotExpiry'] = data.lotExpiry? this._momentService.getIsoFormat(data.lotExpiry) : '';
    // stockPayload['swapTransferDateAndTime'] = data.swapTransferDateAndTime? this._momentService.getIsoFormat(data.swapTransferDateAndTime) : '';
    stockPayload['indicator'] = data.indicator? data.indicator : '';
    stockPayload['toEndCustomerNumber'] = data.toEndCustomerNumber ? data.toEndCustomerNumber : '';
    stockPayload['readableTransferId'] = data.readableTransferId ? data.readableTransferId : '';
    stockPayload['from_date'] = data.from_date ?  this._momentService.getFilterFormat(data.from_date) : '';
    stockPayload['to_date'] = data.to_date ? this._momentService.getFilterFormat(data.to_date, "toDate") : '';
    stockPayload['cpNumber'] = data.cpNumber ? data.cpNumber.cpnumber : '';
    return stockPayload;
  }
  searchStockTransSwap() {
    let payload = this.getStockPayload(this.stockTransSwapSearchForm.value) ;
     this.getStockTransferList(payload)
  }

  cancelFilter() {
    this.stockTransSwapSearchForm.reset();
    this.stockTransSwapSearchForm.get('from_date').setValue(this._momentService.deceedDate(new Date(),31));
    this.stockTransSwapSearchForm.get('to_date').setValue(new Date())
    this.setStockTransferParams();
  }

  exportStockTransfer(){
    let stockFilterValues = this.getStockPayload(this.stockTransSwapSearchForm.value);
    this._StockService.exportStockInvoiceFilter(stockFilterValues);

  }

}


import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { routes } from 'src/app/app-routing.module';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { HttpClientModule } from '@angular/common/http';
import { StockTransferNewComponent } from './stock-transfer-new.component';



describe('StockTransferNewComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes),
        AppMaterialModule,
        CustomFormsModule,
        HttpClientModule,
      ],
     
      declarations: [
        StockTransferNewComponent
      ],
    }).compileComponents();
   
  }));

  it('should create new stock transfer  ', () => {
    const fixture = TestBed.createComponent(StockTransferNewComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

});



import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, ValidationErrors } from '@angular/forms';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { StockService } from 'src/app/modules/cpadmin/service/stock.service';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { Router } from '@angular/router';
import { colorCodes, ErrorMessage, ActionItems } from 'src/app/core/services/constants';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { Roles } from 'src/app/modules/auth/model/user';

@Component({
  selector: 'app-stock-transfer-new',
  templateUrl: './stock-transfer-new.component.html',
  styleUrls: ['./stock-transfer-new.component.css']
})
export class StockTransferNewComponent implements OnInit {

  public displayClientKeys = ['name','address']
  public displayPartsType = ['partNumber','description','type']
  public stockId;
  public stockTransferForm: FormGroup;
  public clientNames = [];
  public otlList = [];
  public partsList =[];
  public clientNumber;
  public otlPartsList = [];
  public partsData = [];
  public transferDetails = [];
  public viewStock = false;
  public relatedParts =[];
  public transferPartsToDetails= [];
  public isOtlChange: boolean = false;

  constructor(private fb: FormBuilder, private _bookingService: CpbookingService, private _formValidator: FormValidatorService ,private _secondarysalesService :SecondarysalesService, 
     private _router: Router,private _snackBar :SnackbarService,private _StorageService: StorageService,
    private _stockService:StockService
    ) { }

  ngOnInit() {
    this._bookingService.getActionPermission({model : 'stocklog'}, response =>{
      if (!response['stocklog'] || !response['stocklog'][ActionItems['ADD_STOCK_TRANSFER']])this.cancel();
    })
    this.loadStockTransferForm();
    if (this._StorageService.getUserDetails().role == Roles.Channel_Partner){
      this._secondarysalesService.cpModuleAccess(res => {
        if (res['stockTransferLock'] == 1 )   this._router.navigate(['/channel-partner/secondary-sales/stock-transfer']);
       });
    } 

  this._bookingService.getDistinctHospitals({order_by:"name"},(response => {
    this.clientNames = response
  }));
 

    this.stockTransferForm.get('desiredQty').valueChanges.subscribe(value => {
      if (this.stockTransferForm.get('relatedParts')  ) {
        let arrayControl = this.stockTransferForm.get('relatedParts') as FormArray;
        arrayControl.controls.map((control) => {
          value ? control.get('desiredQuantityForSwapTransfer').enable() :control.get('desiredQuantityForSwapTransfer').disable() ;
          control.updateValueAndValidity();
        });
      }
      
    })
  }

  loadStockTransferForm() {
    this.stockTransferForm = this.fb.group({ 
      fromHospital: ['', [Validators.required, this._formValidator.requireMatch]],
      fromOtl: ['', [Validators.required, this._formValidator.requireMatch]],
      fromCustNumber: ['', Validators.required],
      fromSiteId: ['', Validators.required],
      desiredQty: ['', Validators.required],
      partNumber: ['',[Validators.required, this._formValidator.requireMatch]],
      type:['Temporary']
    }, { validator: this.transferPartsValidation });
  }

  onClientChange(value) {
    this.resetParts();
    this.stockTransferForm.get('partNumber').setValue('');
    this.stockTransferForm.get('fromOtl').setValue('');
    this.otlList = [];
    this.partsList = [];


    // filter parts 
    this._bookingService.validateHospital({"site_id": value.site_id,"custNumber" :value.custNumber }, (response)=>{ 
      this.stockTransferForm.get('fromSiteId').setValue(value.site_id);
      this.stockTransferForm.get('fromCustNumber').setValue(value.custNumber);
     // this._stockService.getOtl({ "custNumber": value.custNumber, "site_id": value.site_id}, (response) => {
      this._stockService.getOtl({ "custNumber": value.custNumber,'is_primary':true}, (response) => {
        this.otlList = response;
      })
    });
  }

  onOtlChange(value) {
    this.isOtlChange = true;
    this.stockTransferForm.get('')
  
    this.stockTransferForm.get('partNumber').setValue('');
    this.resetParts();
    this.stockTransferForm.get('fromSiteId').setValue(value.site_id);
    this.partsList = [];

    this._bookingService.validateOtl({"site_id": value.site_id,"OTLNumber" :value.OTLnumber ,"screen" : "stock_transfer"}, (response)=>{ 
      this._bookingService.getOtlPartsOpf({OTLNumber: value.OTLnumber,  "order_by": "name"},(response) =>{
        //adding type 
        response = response.map(res =>{
          if (res.discount == 100){
            res['type'] = 'FoC'
          }else{
            res['type'] = "Value"
          }
          return res;
        })
        this.partsList = response;
      })
    });
  
  }
  onpartsChange(value){
    this.resetParts();
    
    if (value.isActive == 0){
      this._snackBar.loadSnackBar( value.partNumber + "-"  +ErrorMessage.IN_ACTIVE_PARTS , colorCodes.ERROR);
    }else{
      this._stockService.getAvailableQty({"custNumber": this.stockTransferForm.get('fromCustNumber').value, "OTLNumber":value.OTLNumber,"partNumber":value.partNumber,"discount" : value.discount}, (response) => {
        this.partsData = this.groupBySumOfProperty(response.filter(res => res['availableQuantity'] > 0), 'partNumber', 'lotNumber','lotExpiryDate');
        // used to send a details to server request 
        if (response.length ) {
          response[0]['unitPurchasePrice'] =   response.find(part => part['unitPurchasePrice'] > 0 ) ?response.find(part => part['unitPurchasePrice'] > 0 )['unitPurchasePrice'] : 0
          this.transferPartsToDetails = response[0];
        }else {
          this.transferPartsToDetails = value;
          this.transferPartsToDetails ['unitPurchasePrice'] = value.price;
        }
        this.callingRelatedParts(value);
      })
    }
   
  }

  callingRelatedParts(value){
    this._stockService.getRelatedHospitalParts({custNumber : this.stockTransferForm.get('fromCustNumber').value, partNumber :value.partNumber, siteId : this.stockTransferForm.get('fromSiteId').value }, response=> {
      this.relatedParts = response;
        let totalTransferPartsQty = response.reduce((currentAmount, control) => {
          return currentAmount + Number(control.availableQuantity)
        }, 0);
        this.stockTransferForm.get('desiredQty').setValidators([Validators.required, this._formValidator.noDecimalsValidation, this._formValidator.negativeValidation, this._formValidator.maxEqualLength(totalTransferPartsQty)]);
      // groupby response 
     let filteredResponse =  this.groupBySumOfProperty(response, 'OTLNumber', 'lotNumber','lotExpiryDate');
      this.stockTransferForm.addControl('relatedParts', this.fb.array(this.getRelatedParts(filteredResponse)));
    })
  }


groupBySumOfProperty(array, key1, key2 , key3){
  let obj= {};
  return array.reduce(function(currentArray, data) {
    var key = data[key1] + '-' + data[key2] + '-' + data[key3];
    if(!obj[key]) {
      obj[key] = Object.assign({}, data);
      currentArray.push(obj[key]);
    }else{
      obj[key]['availableQuantity'] =obj[key]['availableQuantity']+ data['availableQuantity']
    }   
    return currentArray;
  }, [])
}

  getRelatedParts(relatedParts) {
    const data= relatedParts.map((data) => {
      return this.fb.group({
        custNumber: [data.custNumber],
        name: [data.name],
        address: [data.address],
        state: [data.state],
        city: [data.city],
        pincode: [data.pincode],
        OTLNumber: [data.OTLNumber],
        partNumber: [data.partNumber],
        lotNumber: [data.lotNumber],
        lotExpiryDate: [data.lotExpiryDate],
        originalQuantity: [data.originalQuantity],
        secondarySalesQuantity: [data.secondarySalesQuantity],
        availableQuantity: [data.availableQuantity],
        siteId: [data.siteId],
        unitPurchasePrice: [data.unitPurchasePrice],
        cpNumber: [data.cpNumber],
        origin: [data.origin],
        purchaseRowIdentifier: [data.purchaseRowIdentifier],
        region: [data.region],
        id: [data.id],
        description: [data.description],
        price : [data.unitPurchasePrice],
        desiredQuantityForSwapTransfer: [{ value: '', disabled: true }, [this._formValidator.maxEqualLength(data.availableQuantity), this._formValidator.noDecimalsValidation]]
      });
    });
    return data;
  }

  transferPartsValidation(group: FormGroup): ValidationErrors | null {
    if (group.controls['desiredQty'].value && group.controls.relatedParts) {
      let arrayControls = group.controls.relatedParts as FormArray;
      let totaldesiredQtySwapTransfer = arrayControls.controls.reduce((currentAmount, control) => {
        return currentAmount + Number(control.value.desiredQuantityForSwapTransfer)
      }, 0);

      if (totaldesiredQtySwapTransfer && group.controls['desiredQty'].value < totaldesiredQtySwapTransfer) return { 'swapDesiredQuantity': true }
    }
    return null;
  }


  cancel() {
    this._stockService.navigateTo();
  }

  getTotalDesiredQtyTransfer() {
    let data = this.stockTransferForm.value.relatedParts && this.stockTransferForm.value.relatedParts.reduce((currentAmount, control) => {
      return currentAmount + Number(control.desiredQuantityForSwapTransfer)
    }, 0);
    return data
  }

  resetParts(){
    this.partsData = [];
    this.stockTransferForm.get('desiredQty').setValue('');
    if (this.stockTransferForm.get('relatedParts')) this.stockTransferForm.removeControl('relatedParts');
  }

  resetStock() {
    this.resetParts();
    this.stockTransferForm.reset();
    this.stockTransferForm.get('type').setValue('Temporary')
  }

  viewStockTransferDetails(value) {
      this.viewStock = value;
  }

  createStockTransfer() {
      let data ={};
      data['from_customer'] = {};
      data['from_customer']['totalAvailableQuantity']  = this.partsData.reduce((currentQty, qty) => { 
        return currentQty + Number(qty.availableQuantity)
      },0);
      let fromData = Object.assign({}, this.transferPartsToDetails);
      data['from_customer']['type'] =  this.stockTransferForm.get('type').value
      data['from_customer']['partType'] =  this.stockTransferForm.get('partNumber').value.type ?  this.stockTransferForm.get('partNumber').value.type : 'OTL'
      data['from_customer']['desiredQuantityForSwapTransfer'] = Number(this.stockTransferForm.get('desiredQty').value);
      fromData['id'] =0
      fromData['custNumber'] = this.stockTransferForm.get('fromCustNumber').value
      fromData['siteId'] = this.stockTransferForm.get('fromSiteId').value
      fromData['lotExpiryDate'] = ''
      fromData['lotNumber'] =''
      fromData['originalQuantity'] = 0
      fromData['secondarySalesQuantity'] = 0
      fromData['availableQuantity'] =0
      fromData['cpNumber'] = this.stockTransferForm.get('fromOtl').value.cpnumber 
      fromData['origin']  = 'OPF'
      fromData['desiredQuantityForSwapTransfer']  = 0
      fromData['purchaseRowIdentifier']  = ''
      data['from_customer']['data'] =  [fromData];
      let array =[];
      this.stockTransferForm.value.relatedParts.map((data) => {
        let  obj = {};
        if (data['desiredQuantityForSwapTransfer'] > 0){
           obj['desiredQuantityForSwapTransfer'] = data['desiredQuantityForSwapTransfer'];
           obj['data'] =  this.relatedParts.filter(response => {
             if(response['OTLNumber'] == data['OTLNumber'] && response['lotNumber'] == data['lotNumber'] && response['lotExpiryDate'] == data['lotExpiryDate']){
               delete response['unitPurchasePrice'];
             response['desiredQuantityForSwapTransfer'] = 0;
              return response;
             }
            });
           array.push(obj);
        }
      });
      data['with_customers']  =array;
   this._stockService.createStockTransfer(data);
  }


}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReduceReverseDialog } from '../../dialogs/secondary-dialog/dialog.component';
import { StockReversalComponent } from './stock-reversal/stock-reversal.component';
import { StockTransferNewComponent } from './stock-transfer-new/stock-transfer-new.component';
import { StockTransferListComponent } from './stock-transfer-list/stock-transfer-list.component';
import { StockTransferDetailComponent } from './stock-transfer-detail/stock-transfer-detail.component';
import { StockSwapNewComponent } from './stock-swap-new/stock-swap-new.component';
import { StockLogComponent } from './stock-log.component';
import { Routes, RouterModule } from '@angular/router';
import { CommonDialogModule } from '../../dialogs/common-dialog.module';
import { AgGridModule } from 'ag-grid-angular';

const routes: Routes = [{
  path:'', 
  component:StockLogComponent,
  children:[
  {
    path:'stock-transfer',
    component:StockTransferListComponent
  },
  {
    path:'stock-transfer/add',
    component:StockTransferNewComponent
  },
  {
    path: 'stock-swap/add',
    component:StockSwapNewComponent
  },
  {
    path:'stock-transfer/view/:id',
    component:StockTransferDetailComponent
  }, {
    path:'stock-transfer/reversal/view/:id',
    component:StockReversalComponent
  }
]
}]

@NgModule({
  declarations: [ StockLogComponent, StockReversalComponent,StockTransferNewComponent, StockTransferListComponent, StockTransferDetailComponent, StockSwapNewComponent],
  entryComponents:[ReduceReverseDialog ],

  imports: [
    CommonModule, 
    RouterModule.forChild(routes),
    AgGridModule.withComponents([]),
    CommonDialogModule
  ],
})
export class StockLogModule { }

import { Component, OnInit } from '@angular/core';
import { StockService } from 'src/app/modules/cpadmin/service/stock.service';
import { FormBuilder, FormGroup, ValidationErrors, FormArray } from '@angular/forms';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { colorCodes, ErrorMessage, ActionItems } from 'src/app/core/services/constants';

@Component({
  selector: 'app-stock-reversal',
  templateUrl: './stock-reversal.component.html',
  styleUrls: ['./stock-reversal.component.css']
})
export class StockReversalComponent implements OnInit {
  public viewStock = false;
  public stockReversalForm :FormGroup;
  public formCustomer=[];
  public toCustomer=[];
  public stockLogId ;
  public stockLogData ;
  constructor(private fb: FormBuilder, public route: ActivatedRoute  , private _formValidator: FormValidatorService , private _bookingService: CpbookingService,
    private _stockService:StockService,private _snackBar: SnackbarService ,private _router: Router,
    ) { }

  ngOnInit() {
    this._bookingService.getActionPermission({model : 'stocklog'}, response =>{
      if (!response['stocklog'] || !response['stocklog'][ActionItems['REVERSE']])this.cancel();
    })  
    this.loadStockReversalForm();
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.stockLogId = parseInt(params.get('id'));
    });
    this.getStockLog();
    
  }
  getStockLog(){
    this._stockService.searchStock({'id':this.stockLogId}, (response) => {
      this.stockLogData =  response['results'][0]
      this.getFormCustomer();
    });
  }

  getFormCustomer(){
    this._stockService.getFromCustomerStockdetails(
      {
        'purchaseRowIdentifier' : this.stockLogData['purchaseRowIdentifier'],
        'transferId' : this.stockLogData['transferId']
      },(response)=>{
        this.formCustomer = response;
        this.setDataToForm();
        this.getToEndCustomerDetails();
      });
  }

  setDataToForm(){
    this.stockReversalForm.patchValue({
      fromHospital :this.formCustomer[0].name,
      fromOtl:this.formCustomer[0].OTLNumber,
      fromCustNumber:this.formCustomer[0].custNumber,
      fromSiteId:this.formCustomer[0].siteId,
      partNumber:this.formCustomer[0].partNumber,
      transferQty : this.stockLogData.swapTransferQuantity,
      reversalQty: this.stockLogData.reversalTransferQuantity,
      availableQty :  this.stockLogData.availableQuantity
    })
  }

  getToEndCustomerDetails(){
    this._stockService.getToCustomerStockdetails(
      {
        'purchaseRowIdentifier' : this.stockLogData['toEndCustomerPurchaseRowIdentifier'],
        'transferId' : this.stockLogData['transferId'],
        'custNumber' : this.stockLogData['toEndCustomerNumber'],
        'OTLNumber' : this.stockLogData['toOTL'],
        'partNumber' : this.stockLogData['itemNumber'],
        // 'siteId' : this.stockLogData['end_customer_site_id']
      },(response)=>{
        this.toCustomer = response;
        if (response.length){
            let filteredResponse =  this.groupBySumOfProperty(response, 'OTLNumber', 'lotNumber','lotExpiryDate');
            this.stockReversalForm.addControl('relatedParts', this.fb.array(this.getRelatedParts(filteredResponse)));
        }else{
          this._snackBar.loadSnackBar("Customer doesn't have sufficient parts to reverse", colorCodes.ERROR); 
        }
      });
  }


  loadStockReversalForm(){
    this.stockReversalForm = this.fb.group({ 
      fromHospital: [''],
      fromOtl: [''],
      fromCustNumber:[''],
      fromSiteId:[''],
      reversalQty:[''],
      transferQty:[''],
      availableQty:[''],
      partNumber:[''],
    },{ validator: this.transferPartsValidation })
  }

  groupBySumOfProperty(array, key1, key2 , key3){
    let obj= {};
    return array.reduce(function(currentArray, data) {
      var key = data[key1] + '-' + data[key2] + '-' + data[key3];
      if(!obj[key]) {
        obj[key] = Object.assign({}, data);
        currentArray.push(obj[key]);
      }else{
        obj[key]['availableQuantity'] =obj[key]['availableQuantity']+ data['availableQuantity']
      }   
      return currentArray;
    }, [])
  }
  

  getRelatedParts(relatedParts){
    return relatedParts.map((data) => {
      return this.fb.group({
        custNumber: [data.custNumber],
        name: [data.name],
        address: [data.address],
        state: [data.state],
        city: [data.city],
        pincode: [data.pincode],
        OTLNumber: [data.OTLNumber],
        partNumber: [data.partNumber],
        lotNumber: [data.lotNumber],
        lotExpiryDate: [data.lotExpiryDate],
        originalQuantity: [data.originalQuantity],
        secondarySalesQuantity: [data.secondarySalesQuantity],
        availableQuantity: [data.availableQuantity],
        siteId: [data.siteId],
        unitPurchasePrice: [data.unitPurchasePrice],
        cpNumber: [data.cpNumber],
        origin: [data.origin],
        purchaseRowIdentifier: [data.purchaseRowIdentifier],
        region: [data.region],
        id: [data.id],
        description: [data.description],
        price : [data.unitPurchasePrice],
        desiredQuantityForSwapTransfer: ['', [this._formValidator.maxEqualLength(data.availableQuantity), this._formValidator.noDecimalsValidation]]
      });
    });
  }

  transferPartsValidation(group: FormGroup): ValidationErrors | null {
    if (group.controls.relatedParts) {
      let arrayControls = group.controls.relatedParts as FormArray;
      let totaldesiredQtySwapTransfer = arrayControls.controls.reduce((currentAmount, control) => {
        return currentAmount + Number(control.value.desiredQuantityForSwapTransfer)
      }, 0);

      if (totaldesiredQtySwapTransfer && (group.controls['transferQty'].value - group.controls['reversalQty'].value) < totaldesiredQtySwapTransfer) return { 'swapDesiredQuantity': true }
    }
    return null;
  }

  getTotalDesiredQtyTransfer() {
    let data = this.stockReversalForm.value.relatedParts && this.stockReversalForm.value.relatedParts.reduce((currentAmount, control) => {
      return currentAmount + Number(control.desiredQuantityForSwapTransfer)
    }, 0);
    return data
  }

  viewStockSwapDetails(value) {
    this.viewStock = value;
}

createStockReverse(){
  let data ={};
  delete this.formCustomer[0]['address'];
  delete this.formCustomer[0]['city'];
  delete this.formCustomer[0]['state'];
  delete this.formCustomer[0]['region'];
  delete this.formCustomer[0]['name'];
  delete this.formCustomer[0]['pincode'];

  data['stock_log_id'] = this.stockLogData.id;
  data['from_customer'] = {};
  data['from_customer']['desiredQuantityForSwapTransfer'] = this.getTotalDesiredQtyTransfer();
  this.formCustomer[0]['desiredQuantityForSwapTransfer'] =0;
  data['from_customer']['data'] =  this.formCustomer;
  let array =[];
  this.stockReversalForm.value.relatedParts.map((data) => {
    let  obj = {};
    if (data['desiredQuantityForSwapTransfer'] > 0){
       obj['desiredQuantityForSwapTransfer'] = data['desiredQuantityForSwapTransfer'];
       obj['data'] =  this.toCustomer.filter(response => {
         if(response['OTLNumber'] == data['OTLNumber'] && response['lotNumber'] == data['lotNumber'] && response['lotExpiryDate'] == data['lotExpiryDate']){
           delete response['address'];
           delete response['city'];
           delete response['state'];
           delete response['region'];
           delete response['name'];
           delete response['pincode'];
         response['desiredQuantityForSwapTransfer'] = 0;
          return response;
         }
        });
       array.push(obj);
    }
  });
  data['with_customers']  =array;
  this._stockService.reverseStock(data);

}

cancel(){
  this._stockService.navigateToStock( this.stockLogId)
}


redirect(){
  this._stockService.navigateTo()
}

}

import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { HttpService } from 'src/app/core/services/http/http.service';
import { Endpoints, ApiMethod, SuccessMessage, colorCodes } from 'src/app/core/services/constants';
import { Roles } from 'src/app/modules/auth/model/user';
@Injectable({
  providedIn: 'root'
})
export class DashboardReportService {
  constructor(private _http: HttpService, private _snackBar: SnackbarService,private _router: Router) { }
   getListParts(role,successResponseCallback) {
    let endpoint = (role == Roles.Channel_Partner) ?  Endpoints.GET_REPORTS_CP_PARTS : Endpoints.LIST_PARTS ;
    this._http.requestCall(endpoint, ApiMethod.GET).subscribe(
      (res) => {
        successResponseCallback(res);
      });
  }
  getOTLCP(successResponseCallback,payload) {
    let endpoint = Endpoints.GET_OTL_LIST_FOR_CP//(role == Roles.Channel_Partner) ?  Endpoints.GET_OTL_PARTS : Endpoints.LIST_PARTS ;
    this._http.requestCall(endpoint, ApiMethod.GETPARAMS,payload).subscribe(
      (res) => {
        successResponseCallback(res);
      });
  }

  searchGetPrimarySecondaryInvoiceReport(payload,successResponseCallback){
    this._http.requestCall(Endpoints.GET_PRIMARY_SECONDARY_DASHBOARD_LIST,ApiMethod.GETPARAMS,payload).subscribe(
      (res) => {
        successResponseCallback(res);
      });
  }
  
createOTLTransferonSameScreen(payload, successCallback){
  this._http.requestCall(Endpoints.CREATE_OTL_TRANSFER_, ApiMethod.POST, payload).subscribe(
    (res) => { 
      if(res){

        this._snackBar.loadSnackBar(SuccessMessage.CREATE_OTL_TRANSFER, colorCodes.SUCCESS); 
     // this.navigateTo()
   //  return res;
   successCallback(res);
      }
     },
    (error) => { console.log(error); }
  )
}
searchOTL(payload, successResponseCallback) {
  let endpt:any = Endpoints.GET_OTL_TRANSFER_LIST+payload
  this._http.requestCall(endpt, ApiMethod.GET).subscribe(
    (res) => {
      successResponseCallback(res);
    },
    (error) => {
      console.log(error)
    });
}

exportPrimarySecondaryReportFilter(payload){
  this._http.requestCall(Endpoints.GET_PRIMARY_SECONDARY_DASHBOARD_LIST,ApiMethod.DOWNLOAD_PARAMS,payload).subscribe(
    (res) => {
      var downloadLink = document.createElement("a");
      const blob = new Blob([res], { type: 'text/csv' });
      const url= window.URL.createObjectURL(blob);
      downloadLink.href = url;
      downloadLink.download = "Dashboard-PrimarySecondary-Report.csv";
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      this._snackBar.loadSnackBar(SuccessMessage.EXPORT_PRIMARY_SECONDARY_LIST, colorCodes.SUCCESS);
      return false;
    },
    (error) => {
      console.log(error);
    }
  );
}
//Primary Report
searchPrimaryReportList(payload,successResponseCallback){
  this._http.requestCall(Endpoints.DASHBOARD_PRIMARY_TREND_REPORT,ApiMethod.GETPARAMS,payload).subscribe(
    (res) => {
      successResponseCallback(res);
    });
}

getPrimaryReportList(successResponseCallback){
  this._http.requestCall(Endpoints.DASHBOARD_PRIMARY_TREND_REPORT, ApiMethod.GET).subscribe(
    (res) => {
      successResponseCallback(res);
    });
}
exportPrimaryReportFilter(payload){
  this._http.requestCall(Endpoints.DASHBOARD_PRIMARY_TREND_REPORT,ApiMethod.DOWNLOAD_PARAMS,payload).subscribe(
    (res) => {
      var downloadLink = document.createElement("a");
      const blob = new Blob([res], { type: 'text/csv' });
      const url= window.URL.createObjectURL(blob);
      downloadLink.href = url;
      downloadLink.download = "Dashboard-Primary-Report.csv";
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      this._snackBar.loadSnackBar(SuccessMessage.EXPORT_PRIMARY_LIST, colorCodes.SUCCESS);
      return false;
    },
    (error) => {
      console.log(error);
    }
  );
}
//Secondary Report
searchSecondaryReportList(payload,successResponseCallback){
  this._http.requestCall(Endpoints.DASHBOARD_SECONDARY_TREND_REPORT , ApiMethod.GETPARAMS,payload).subscribe(
    (res) => {
      successResponseCallback(res);
    });
}

getSecondaryReportList(successResponseCallback){
  this._http.requestCall(Endpoints.DASHBOARD_SECONDARY_TREND_REPORT ,ApiMethod.GET).subscribe(
    (res) => {
      successResponseCallback(res);
    });
}



exportSecondaryReportFilter(payload){
  this._http.requestCall(Endpoints. DASHBOARD_SECONDARY_TREND_REPORT,ApiMethod.DOWNLOAD_PARAMS,payload).subscribe(
    (res) => {
      var downloadLink = document.createElement("a");
      const blob = new Blob([res], { type: 'text/csv' });
      const url= window.URL.createObjectURL(blob);
      downloadLink.href = url;
      downloadLink.download = "Dashboard-Secondary-Report.csv";
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      this._snackBar.loadSnackBar(SuccessMessage.EXPORT_SECONDARY_LIST, colorCodes.SUCCESS);
      return false;
    },
    (error) => {
      console.log(error);
    }
  );
}

//SALES Report
searchSalesReportList(payload,successResponseCallback){
  this._http.requestCall(Endpoints.DASHBOARD_PRIMARY_SECONDARY_SALES_ORDER,ApiMethod.GETPARAMS,payload).subscribe(
    (res) => {
      successResponseCallback(res);
    });
}


getSalesReportList(payload,successResponseCallback){
  this._http.requestCall(Endpoints.DASHBOARD_PRIMARY_SECONDARY_SALES_ORDER,ApiMethod.GETPARAMS,payload).subscribe(
    (res) => {
      successResponseCallback(res);
    });
}
exportSalesReportFilter(payload){
  this._http.requestCall(Endpoints.DASHBOARD_PRIMARY_SECONDARY_SALES_ORDER,ApiMethod.DOWNLOAD_PARAMS,payload).subscribe(
    (res) => {
      var downloadLink = document.createElement("a");
      const blob = new Blob([res], { type: 'text/csv' });
      const url= window.URL.createObjectURL(blob);
      downloadLink.href = url;
      downloadLink.download = "Dashboard-Sales-Report.csv";
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      this._snackBar.loadSnackBar(SuccessMessage.EXPORT_SALES_LIST, colorCodes.SUCCESS);
      return false;
    },
    (error) => {
      console.log(error);
    }
  );
}

//Inventory Report
searchInventoryReportList(payload,successResponseCallback){
  this._http.requestCall(Endpoints.DASHBOARD_INVENTORY_DAYS_OUTSTANDING,ApiMethod.GETPARAMS,payload).subscribe(
    (res) => {
      successResponseCallback(res);
    });
}
exportInventoryReportFilter(payload){
  this._http.requestCall(Endpoints.DASHBOARD_INVENTORY_DAYS_OUTSTANDING,ApiMethod.SEARCHDOWNLOADPARAMS,payload).subscribe(
    (res) => {
      var downloadLink = document.createElement("a");
      const blob = new Blob([res], { type: 'text/csv' });
      const url= window.URL.createObjectURL(blob);
      downloadLink.href = url;
      downloadLink.download = "Dashboard-Inventory-Report.csv";
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      this._snackBar.loadSnackBar(SuccessMessage.EXPORT_INVENTORY_LIST, colorCodes.SUCCESS);
      return false;
    },
    (error) => {
      console.log(error);
    }
  );
}
}
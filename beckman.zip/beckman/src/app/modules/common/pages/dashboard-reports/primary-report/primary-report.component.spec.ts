import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrimaryReportComponent } from './primary-report.component';

describe('PrimaryReportComponent', () => {
  let component: PrimaryReportComponent;
  let fixture: ComponentFixture<PrimaryReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrimaryReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrimaryReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

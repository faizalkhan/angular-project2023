import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AgGridModule } from 'ag-grid-angular';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';

import { SalesReportComponent } from './sales-report/sales-report.component';
import { PrimaryReportComponent } from './primary-report/primary-report.component';
import { PrimarySecondaryReportComponent } from './primary-secondary-report/primary-secondary-report.component';
import { SecondaryReportComponent } from './secondary-report/secondary-report.component';
import { InventoryReportComponent } from './inventory-report/inventory-report.component';

const routes: Routes = [
  {
    path: '',
    component:SalesReportComponent,
  },
  {
    path:'sales-report',
    component:SalesReportComponent
  },
  {
    path:'primary-report',
    component:PrimaryReportComponent
  },
  {
    path:'secondary-report',
    component:SecondaryReportComponent
  },
  {
    path:'primary-secondary',
    component:PrimarySecondaryReportComponent
  },
  {
    path:'inventory-report',
    component:InventoryReportComponent
  }
]
 // }]

@NgModule({
  declarations: [PrimarySecondaryReportComponent, SalesReportComponent, PrimaryReportComponent, SecondaryReportComponent, InventoryReportComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    AgGridModule.withComponents([]),
    CustomFormsModule,AppMaterialModule
  ],
  exports:[PrimarySecondaryReportComponent]
})
export class DashboardReportsModule { }

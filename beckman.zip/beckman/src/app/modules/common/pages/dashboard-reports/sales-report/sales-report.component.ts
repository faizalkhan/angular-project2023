import { Component, OnInit, ViewEncapsulation, HostListener } from '@angular/core';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Roles } from 'src/app/modules/auth/model/user';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { DashboardReportService } from 'src/app/modules/common/pages/dashboard-reports/service/dashboard-report.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { ActionItems } from 'src/app/core/services/constants';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { IGetRowsParams } from 'ag-grid-community';
import { OutboundService } from '../../../service/outbound/outbound.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { PartsService } from 'src/app/modules/beckman/service/parts/parts.service';
import { LocationService } from 'src/app/core/services/utils/location.service';
import { OtlmasterService } from 'src/app/modules/beckman/service/hospital/otlmaster.service';

@Component({
  selector: 'app-sales-report',
  templateUrl: './sales-report.component.html',
  styleUrls: ['./sales-report.component.css']
})
export class SalesReportComponent implements OnInit {
  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public gridData = [];
  public salesReportForm: FormGroup;
  public role;
  public isAdmin:boolean = false;
  public clientNames =[];
  public currentState =[];
  public otlList =[];
  public opfList =[];
  public partList=[];
  public cpList=[];
  public regionFromService= [];
  public productName = [];
  public pageSize = 10;
  public isChannelPartner = false;
  public psReportPermission;
  public displayChannelPartnerKeys = ['name', 'cpnumber']
  public displayChannelPartnerKeys1 = ['name', 'custNumber']
  displaySalesPersonKeys = ['name', 'email']
  public isLoading:boolean = false;
  public groupedUserEmail;
  public salesPerson = [];
  permissionMenu: any;
  constructor(private _partsService:PartsService, private _StorageService: StorageService,private _permissionMenuListService: PermissionMenuListService, private _bookingService :CpbookingService, private _utilsService : UtilsService,
    private _formValidator: FormValidatorService, private fb: FormBuilder,private _DashboardReportService:DashboardReportService,private _momentService: MomentService,    
    private _outboundService: OutboundService, private _PromptService: PromptService,  private _locationService: LocationService, private _otlMasterService: OtlmasterService
    ) { }
    @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
    }

  ngOnInit() {

    this.loadsalesReportForm();
     this.loadLocationData();
     this.groupedUserList();
    this.role = this._StorageService.getUserDetails().role;

    this.isAdmin =this._utilsService.isAdminRole(this.role);

    this.isChannelPartner = this._utilsService.isCpRole(this.role);

    this._partsService.getProductLine((res)=>{
      this.productName = res;
    })
    // calling filters api 
	this.setClientList();
    this.setPartsList();
    this.setOtlList();
    this.setCPList();
    // this.defaultColDef = {
    //   sortable: true,
    //   filter: true,
    //   resizable: true
 
    // };
    // this.gridOptions = {
    //   rowHeight: 45,
    //   paginationPageSize: 10,
    //   cacheBlockSize : 10,
    //   rowModelType :'infinite',
    //   cacheOverflowSize:100,
    //   maxConcurrentDatasourceRequests: 2
    
    // };

    this.defaultColDef = {
      sortable: true,
      filter: false,
      resizable: true
    };
    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
    };

    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: "",
        headerName: 'S No.',
        width: 100,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
        suppressSizeToFit: true
      },
      {
        headerName: 'Type',
        field: "type",
        width: 100,
        suppressSizeToFit: true
      },
      {
        headerName: 'OTL No.',
        field: "OTLNumber",
        width: 100,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true
      },

      {
        headerName: 'Part Number',
        field: "partNumber",
        width: 100,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true
      },

      {
        headerName: 'Product Line',
        field: "productLine",
        width: 200,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true
      },
      {
        headerName: 'Region',
        field: "region",
        width: 100,
        suppressSizeToFit: true
      },
      {
        headerName: 'CP Name',
        field: "cpName",
        width: 350, 
        suppressSizeToFit: true
      },

      {
        headerName: 'End Customer Name',
        field: "name",
        width: 350, 
        suppressSizeToFit: true
      },
      {
        headerName: 'Salesperson Name',
        field: "salesman_name",
        width: 300,
        suppressSizeToFit: true
      },

      {
        headerName: 'Current Day Primary Value ',
        field: "primary_total_current_day_value",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'Current Primary Value (MTD)',
        field: "primary_total_month_value",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'Current Secondary Value',
        field: "secondary_total_current_day_value",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
    
      {
        headerName: 'Current Secondary Value (MTD)',
        field: "secondary_total_month_value",
        width: 150, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'End Customer Site ID',
        field: "site_id",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'CP Number',
        field: "cpnumber",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'CP Site City',
        field: "cp_site_city",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'CP Site ID',
        field: "cp_site_id",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'CP Region',
        field: "cp_region",
        width: 150,
        suppressSizeToFit: true
      },
    ];
    this.loadReportsPermission()
  }

 groupedUserList(){
  this._otlMasterService.groupUserEmail(response =>{
    this.groupedUserEmail = response;
    this.salesPerson = [...response['Salesperson'], ...response['RegionalBusinessManager'], ...response['StateManager']];
  
  })
}
 loadLocationData() {
  //Location from Service call implementation
  this._locationService.getLocationData((locationData) => {
    this.regionFromService = locationData;
  });
}

 loadReportsPermission(){
  this._permissionMenuListService.getActionPermission({model : 'reports'}, response =>{
    this.psReportPermission= response['reports'];
  });
}

formatDate(params){
  return  params.data? this._momentService.getDateTimeFormat(params.data.created_on):'';
}

  // start - set values for  filter fields
  setPartsList(){
    this._DashboardReportService.getListParts(this.role,(res) => {
      this.partList =res;
    });
  }
  setOtlList(){
    this._bookingService.getListofOTLParts(res =>{
      this.otlList =  this._utilsService.groupByMultipleKeys(res,['name','OTLnumber'])
    })
  }
  setClientList(){
    this._bookingService.listHospital(res =>{
      this.clientNames =  this._utilsService.groupByMultipleKeys(res,['name','custNumber'])
    })
  }

  setCPList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpList = this._utilsService.groupByMultipleKeys(res,['name','cpnumber'])   
    })
  }
  onRegionChange(value) {
    this.currentState =[];
    this.salesReportForm.patchValue({
      state : '',
    });
    if (value) {
      this.currentState = value.states;
    }
  }

onGridReady(params) {
  this.gridApi = params.api;
  this.gridColumnApi = params.columnApi;
  this.gridApi.sizeColumnsToFit();
  this.getSalesReportList({});
}
getSalesReportList(data?: any){
  let payload = {};
  payload['is_table_view']=true;
  this._DashboardReportService.getSalesReportList(payload,(res)=>{
  this.gridData = res['results']?res['results'] : res;
  this.gridApi.setRowData( this.gridData);
  console.log(this.gridData);
  
  this.gridApi.paginationGoToFirstPage();
  })
  // let payload = {};
  // var datasource = {
  //   getRows: (params: IGetRowsParams) =>{
  //     if (data) {
  //       payload = data;
  //     }
  //     this.onBtShowLoading();
  //     payload['page_size'] =this.pageSize
  //     payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
  //     payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
  //     payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
  //     payload['is_table_view']=true
  //     this._DashboardReportService.searchSalesReportList(payload,(res)=>{
  //       if(res.length > 0){
  //         let length = res.length;
  //         this.gridData = res;
  //         console.log(this.gridData,'-203-');
  //         params.successCallback(res, length)
  //         this.onBtHide();
  //       }
  //       else
  //       {
  //         this.onBtShowNoRows(); 
  //       }
  //    })

  //  }

 //}
    //this.gridApi.setDatasource(datasource);
}
  loadsalesReportForm(){
    this.salesReportForm = this.fb.group({
	  custNumber:  ['', this._formValidator.requireMatch],
      OTLNumber: ['', this._formValidator.requireMatch],
      cpNumber: ['', this._formValidator.requireMatch],
      region:  ['', this._formValidator.requireMatch],
      state: ['', this._formValidator.requireMatch],
      salesman_email :  [''],

    });
  }
  exportStockReport(){
    let payload =  this.getPayload(this.salesReportForm.value);
    payload['is_export'] = true;
    //payload['is_table_view']=true
    this._DashboardReportService.exportSalesReportFilter(payload);
  }
  getPayload(formValue){ 
    let data =  {}; 
    console.log(formValue);

	data['custNumber'] =  formValue.custNumber ? formValue.custNumber.custNumber : '';
     data['OTLNumber'] = formValue.OTLNumber ? formValue.OTLNumber.OTLnumber : '';
     data['cpnumber'] = formValue.cpNumber ? formValue.cpNumber.cpnumber : '';
     data['region'] = formValue.region ? formValue.region.name : '';
     data['state'] = formValue.state ? formValue.state.name : '';
     data['salesman_email'] = formValue.salesman_email ? formValue.salesman_email.email: ''
    return data;
    }
    searchStockReport(){   
    if (this.salesReportForm.valid){
      let invoiceFilterValues = this.getPayload(this.salesReportForm.value);
      return this.getSalesReportList(invoiceFilterValues);
      }
    }
  cancelPSReport(){
    this.salesReportForm.reset();
    this.getSalesReportList();
  }
  RoundOFTwoDigit(num: any){
    var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
    return number;
  } 


  onBtShowLoading() {
    this.gridApi.showLoadingOverlay();
  }

  onBtShowNoRows() {
    this.gridApi.showNoRowsOverlay();
 }

  onBtHide() {
    this.gridApi.hideOverlay();
  }

}


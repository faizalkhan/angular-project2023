import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrimarySecondaryReportComponent } from './primary-secondary-report.component';

describe('PrimarySecondaryReportComponent', () => {
  let component: PrimarySecondaryReportComponent;
  let fixture: ComponentFixture<PrimarySecondaryReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrimarySecondaryReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrimarySecondaryReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

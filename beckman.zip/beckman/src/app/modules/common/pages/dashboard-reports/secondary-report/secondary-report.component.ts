import { Component, OnInit, ViewEncapsulation, HostListener } from '@angular/core';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Roles } from 'src/app/modules/auth/model/user';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { DashboardReportService } from 'src/app/modules/common/pages/dashboard-reports/service/dashboard-report.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { ActionItems } from 'src/app/core/services/constants';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { IGetRowsParams } from 'ag-grid-community';
import { OutboundService } from '../../../service/outbound/outbound.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { PartsService } from 'src/app/modules/beckman/service/parts/parts.service';
import { LocationService } from 'src/app/core/services/utils/location.service';
import { OtlmasterService } from 'src/app/modules/beckman/service/hospital/otlmaster.service';

@Component({
  selector: 'app-secondary-report',
  templateUrl: './secondary-report.component.html',
  styleUrls: ['./secondary-report.component.css']
})
export class SecondaryReportComponent implements OnInit {
  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public gridData = [];
  public primarySecReportForm: FormGroup;
  public role;
  public isAdmin:boolean = false;
  public clientNames =[];
  public otlList =[];
  public opfList =[];
  public partList=[];
  public cpList=[];
  public regionFromService= [];
  public productName = [];
  public pageSize = 10;
  public isChannelPartner;
  public psReportPermission;
  public displayChannelPartnerKeys = ['name', 'cpnumber']
  public displayChannelPartnerKeys1 = ['name', 'custNumber']
  displaySalesPersonKeys = ['name', 'email']
  public isLoading:boolean = false;
  public groupedUserEmail;
  public salesPerson = [];
  public currentState =[];
  permissionMenu: any;
  constructor(private _partsService:PartsService, private _StorageService: StorageService,private _permissionMenuListService: PermissionMenuListService, private _bookingService :CpbookingService, private _utilsService : UtilsService,
    private _formValidator: FormValidatorService, private fb: FormBuilder,private _DashboardReportService:DashboardReportService,private _momentService: MomentService,    
    private _outboundService: OutboundService, private _PromptService: PromptService,  private _locationService: LocationService, private _otlMasterService: OtlmasterService
    ) { }
    @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
    }

  ngOnInit() {
    console.log("dsf");
    
    this.loadprimarySecReportForm();
     this.loadLocationData();
     this.groupedUserList();
    this.role = this._StorageService.getUserDetails().role;

    this.isAdmin =this._utilsService.isAdminRole(this.role);

    this.isChannelPartner = this._utilsService.isCpRole(this.role);

    this._partsService.getProductLine((res)=>{
      this.productName = res;
    })
    // calling filters api
    this.setClientList()
    this.setPartsList();
    this.setOtlList();
    this.setCPList();
    this.defaultColDef = {
      sortable: true,
      filter: true,
      resizable: true
 
    };
    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2
    
    };

    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }

    this.columnDefs = [
      {
        field: "",
        headerName: 'S No.',
        width: 100,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
        suppressSizeToFit: true
      },
      {
        headerName: 'OTL No.',
        field: "OTLNumber",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true
      },

      {
        headerName: 'Part Number',
        field: "partNumber",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true
      },

      {
        headerName: 'Product Line',
        field: "productLine",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true
      },
      {
        headerName: 'Region',
        field: "region",
        width: 300, 
        suppressSizeToFit: true
      },
      {
        headerName: 'CP Name',
        field: "cpName",
        width: 350, 
        suppressSizeToFit: true
      },
      {
        headerName: 'End Customer Name',
        field: "name",
        width: 300, 
        suppressSizeToFit: true
      },
      {
        headerName: 'Salesperson Name',
        field: "salesman_name",
        width: 300, 
        suppressSizeToFit: true
      },  
      {
        headerName: 'Current Secondary Value (MTD)',
        field: "secondary_current_value",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
     
   
      {
        headerName: 'Current Month-1 Secondary Value',
        field: "previous_month_1_secondary_value",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },



      {
        headerName: 'Current Month-2 Secondary Value',
        field: "previous_month_2_secondary_value",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },




   
      
      {
        headerName: 'Current Month-3 Secondary Value',
        field: "previous_month_3_secondary_value",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },


    
      {
        headerName: 'Current Month-4 Secondary Value',
        field: "previous_month_4_secondary_value",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },


    
    
      {
        headerName: 'Current Month-5 Secondary Value',
        field: "previous_month_5_secondary_value",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },

    
    
      {
        headerName: 'Current Month-6 Secondary Value',
        field: "previous_month_6_secondary_value",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },


      {
        headerName: 'Current Month-7 Secondary Value',
        field: "previous_month_7_secondary_value",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },



      
      {
        headerName: 'Current Month-8 Secondary Value',
        field: "previous_month_8_secondary_value",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },


      
     
      {
        headerName: 'Current Month-9 Secondary Value',
        field: "previous_month_9_secondary_value",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },



      
      {
        headerName: 'Current Month-10 Secondary Value',
        field: "previous_month_10_secondary_value",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },


      
      {
        headerName: 'Current Month-11 Secondary Value',
        field: "previous_month_11_secondary_value",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },

    
      {
        headerName: 'Current Month-12 Secondary Value',
        field: "previous_month_12_secondary_value",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
  
      {
        headerName: 'End Customer Site ID',
        field: "site_id",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'CP Number',
        field: "cpnumber",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'CP Site City',
        field: "cp_site_city",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'CP Site ID',
        field: "cp_site_id",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'CP Region',
        field: "cp_region",
        width: 100, 
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      }
    
    
     
    ];
    this.loadReportsPermission()
  }
 groupedUserList(){
  this._otlMasterService.groupUserEmail(response =>{
    this.groupedUserEmail = response;
    this.salesPerson = [...response['Salesperson'], ...response['RegionalBusinessManager'], ...response['StateManager']];
  
  })
}
 loadLocationData() {
  //Location from Service call implementation
  this._locationService.getLocationData((locationData) => {
    this.regionFromService = locationData;
  });
}

 loadReportsPermission(){
  this._permissionMenuListService.getActionPermission({model : 'reports'}, response =>{
    this.psReportPermission= response['reports'];
  });
}

formatDate(params){
  return  params.data? this._momentService.getDateTimeFormat(params.data.created_on):'';
}

  // start - set values for  filter fields
  setPartsList(){
    this._DashboardReportService.getListParts(this.role,(res) => {
      this.partList =res;
    });
  }
  setOtlList(){
    this._bookingService.getListofOTLParts(res =>{
      this.otlList =  this._utilsService.groupByMultipleKeys(res,['name','OTLnumber'])
    })
  }

  setCPList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpList = this._utilsService.groupByMultipleKeys(res,['name','cpnumber'])   
    })
  }
onGridReady(params) {
  this.gridApi = params.api;
  this.gridColumnApi = params.columnApi;
  this.gridApi.sizeColumnsToFit();
  this.getSecondaryReportList({});
}
getSecondaryReportList(data?: any){
  let payload = {};
  var datasource = {
    getRows: (params: IGetRowsParams) =>{
      if (data) {
        payload = data;
      }
      payload['page_size'] =this.pageSize
      payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
      payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
      payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
      payload['is_table_view']=true;
      this.onBtShowLoading();
      this._DashboardReportService.getSecondaryReportList((res)=>{
        console.log(res);
        if((res.results).length > 0){

          let length = res['total'];
          this.gridData =  res['results']; 
          this.onBtHide();
          params.successCallback(res['results'], length)
        }

        else
        {
          this.onBtShowNoRows();
        }
       
        })
    }
  }
    this.gridApi.setDatasource(datasource);
}


searchSecondaryReportList(data?: any){
  let payload = {};
  var datasource = {
    getRows: (params: IGetRowsParams) =>{
      if (data) {
        payload = data;
      }
      payload['page_size'] =this.pageSize
      payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
      payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
      payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
      this.onBtShowLoading();
      this._DashboardReportService.searchSecondaryReportList(data,(res)=>{

        if((res.results).length > 0){
          let length = res['total'];
          this.gridData = res['results'];
          this.onBtHide();
          params.successCallback(res['results'], length)
         }
         else
         {
            this.onBtShowNoRows(); 
         }
    
        })
    }
  }
    this.gridApi.setDatasource(datasource);
}


onRegionChange(value) {
  this.currentState =[];
  this.primarySecReportForm.patchValue({
    state : '',
  });
  if (value) {
    this.currentState = value.states;
  }
}
  loadprimarySecReportForm(){
    this.primarySecReportForm = this.fb.group({
      custNumber: ['', this._formValidator.requireMatch],
      OTLNumber: ['', this._formValidator.requireMatch],
      cpNumber: ['', this._formValidator.requireMatch],
      region:  [''],
      state:  [''],
      salesman_email :  ['']
    });
  }
  exportStockReport(){
    let payload =  this.getPayload(this.primarySecReportForm.value);
    payload['is_export'] = true;
    payload['is_table_view']=true
    this._DashboardReportService.exportSecondaryReportFilter(payload);
  }
  getPayload(formValue){
    let data =  {}; 
    console.log(formValue);
    data['custNumber'] =  formValue.custNumber ? formValue.custNumber.custNumber : '';
     data['OTLNumber'] = formValue.OTLNumber ? formValue.OTLNumber.OTLnumber : '';
     data['cpnumber'] = formValue.cpNumber ? formValue.cpNumber.cpnumber : '';
     data['region'] = formValue.region ? formValue.region.name : '';
     data['state'] = formValue.state ? formValue.state.name : '';
     data['salesman_email'] = formValue.salesman_email ? formValue.salesman_email.email: ''
    return data;
    }
    searchStockReport(){   
    if (this.primarySecReportForm.valid){
      let invoiceFilterValues = this.getPayload(this.primarySecReportForm.value);
      return this.searchSecondaryReportList(invoiceFilterValues);
      }
    }
    setClientList(){
      this._bookingService.listHospital(res =>{
        this.clientNames =  this._utilsService.groupByMultipleKeys(res,['name','custNumber'])
      })
    }

  cancelPSReport(){
    this.primarySecReportForm.reset();
    this.getSecondaryReportList();
  }
  RoundOFTwoDigit(num: any){
    var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
    return number;
  } 
  getPermissionMenu(){
    this._permissionMenuListService.getPermissionMenu(response =>{
      this.permissionMenu = response;
    })
  }

  onBtShowLoading() {
    this.gridApi.showLoadingOverlay();
  }
  
  onBtShowNoRows() {
    this.gridApi.showNoRowsOverlay();
  }
  
  onBtHide() {
    this.gridApi.hideOverlay();
  }

}


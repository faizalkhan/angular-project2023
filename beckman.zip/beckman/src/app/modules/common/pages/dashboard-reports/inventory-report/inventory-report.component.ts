import { Component, OnInit, ViewEncapsulation, HostListener } from '@angular/core';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Roles } from 'src/app/modules/auth/model/user';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { DashboardReportService } from 'src/app/modules/common/pages/dashboard-reports/service/dashboard-report.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { ActionItems } from 'src/app/core/services/constants';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { IGetRowsParams } from 'ag-grid-community';
import { OutboundService } from '../../../service/outbound/outbound.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { PartsService } from 'src/app/modules/beckman/service/parts/parts.service';
import { LocationService } from 'src/app/core/services/utils/location.service';
import { OtlmasterService } from 'src/app/modules/beckman/service/hospital/otlmaster.service';

@Component({
  selector: 'app-inventory-report',
  templateUrl: './inventory-report.component.html',
  styleUrls: ['./inventory-report.component.css']
})
export class InventoryReportComponent implements OnInit {

  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public gridData = [];
  public primarySecReportForm: FormGroup;
  public role;
  public isAdmin:boolean = false;
  public clientNames =[];
  public otlList =[];
  public opfList =[];
  public partList=[];
  public cpList=[];
  public regionFromService= [];
  public productName = [];
  public pageSize = 10;
  public isChannelPartner;
  public psReportPermission;
  public displayChannelPartnerKeys = ['name', 'cpnumber']
  public displayChannelPartnerKeys1 = ['name', 'custNumber']
  public isLoading:boolean = false;
  public groupedUserEmail;
  public salesPerson = [];
  permissionMenu: any;
  constructor(private _partsService:PartsService, private _StorageService: StorageService,private _permissionMenuListService: PermissionMenuListService, private _bookingService :CpbookingService, private _utilsService : UtilsService,
    private _formValidator: FormValidatorService, private fb: FormBuilder,private _DashboardReportService:DashboardReportService,private _momentService: MomentService,    
    private _outboundService: OutboundService, private _PromptService: PromptService,  private _locationService: LocationService, private _otlMasterService: OtlmasterService
    ) { }
    @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
    }

  ngOnInit() {
    console.log("dsf");
    
    this.loadprimarySecReportForm();
     this.loadLocationData();
     this.groupedUserList();
    this.role = this._StorageService.getUserDetails().role;

    this.isAdmin =this._utilsService.isAdminRole(this.role);

    this.isChannelPartner = this._utilsService.isCpRole(this.role);

    this._partsService.getProductLine((res)=>{
      this.productName = res;
    })
    // calling filters api 
    this.setPartsList();
    this.setOtlList();
    this.setCPList();
    this.defaultColDef = {
      sortable: true,
      filter: true,
      resizable: true
 
    };
    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2
    
    };

    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: "",
        headerName: 'S No.',
        width: 100,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
        suppressSizeToFit: true
      },
      {
        headerName: 'Channel Partner Name',
        field: "cp_name",
        width: 150,
        suppressSizeToFit: true
      },
      {
        headerName: 'Region',
        field: "region",
        width: 100,
        suppressSizeToFit: true
      },      
      {
        headerName: 'State',
        field: "state",
        width: 100,
        suppressSizeToFit: true
      },
      {
        headerName: 'OTL Number',
        field: "OTLNumber",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true
      },

      {
        headerName: 'Part Number',
        field: "partNumber",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true
      },
      {
        headerName: 'Quantity',
        field: "available_quantity",
        width: 100,
        suppressSizeToFit: true
      },
      {
        headerName: 'Unit Price	',
        field: "unit_price",
        width: 150,
        suppressSizeToFit: true
      },
      {
        headerName: 'Value',
        field: "total_value_with_lot_expiry",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'DIO based on CP Inventory',
        field: "dio_cp",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'DIO based on Part Number',
        field: "dio_cp_part",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'DIO based on OTL + Part Number',
        field: "dio_cp_otl_part",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        suppressSizeToFit: true,
      }
    ];
    this.loadReportsPermission()
  }

 groupedUserList(){
  this._otlMasterService.groupUserEmail(response =>{
    this.groupedUserEmail = response;
    this.salesPerson = [...response['Salesperson']];
  
  })
}
 loadLocationData() {
  //Location from Service call implementation
  this._locationService.getLocationData((locationData) => {
    this.regionFromService = locationData;
  });
}

 loadReportsPermission(){
  this._permissionMenuListService.getActionPermission({model : 'reports'}, response =>{
    this.psReportPermission= response['reports'];    
  });
}

formatDate(params){
  return  params.data? this._momentService.getDateTimeFormat(params.data.created_on):'';
}

  // start - set values for  filter fields
  setPartsList(){
    this._DashboardReportService.getListParts(this.role,(res) => {
      this.partList =res;
    });
  }
  setOtlList(){
    this._bookingService.getListofOTLParts(res =>{
      this.otlList =  this._utilsService.groupByMultipleKeys(res,['name','OTLnumber'])
    })
  }

  setCPList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpList = this._utilsService.groupByMultipleKeys(res,['name','cpnumber'])   
    })
  }
onGridReady(params) {
  this.gridApi = params.api;
  this.gridColumnApi = params.columnApi;
  this.gridApi.sizeColumnsToFit();
  this.getInventoryReportList({});
}
getInventoryReportList(data?: any){
  let payload = {};
  var datasource = {
    getRows: (params: IGetRowsParams) =>{
      if (data) {
        payload = data;
      }
      payload['page_size'] =this.pageSize
      payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
      payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
      payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
      
      payload['is_table_view']=true
      this._DashboardReportService.searchInventoryReportList(payload,(res)=>{
          let length = res.length;
          this.gridData = res;
          params.successCallback(res, length)
        })
    }
  }
    this.gridApi.setDatasource(datasource);
}

searchCPList(data?: any){
  let payload = {};
  var datasource = {
    getRows: (params: IGetRowsParams) =>{
      if (data) {
        payload = data;
      }
      this.onBtShowLoading();
      payload['page_size'] =this.pageSize
      payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
      payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
      payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
      payload['is_table_view']=true
      this._DashboardReportService.searchInventoryReportList(data,(res)=>{
          let length = res.length;
          this.gridData = res;
          params.successCallback(res, length);
          this.onBtHide();
        })
    }
  }
    this.gridApi.setDatasource(datasource);
}

  loadprimarySecReportForm(){
    this.primarySecReportForm = this.fb.group({
      CustNumber: ['', this._formValidator.requireMatch],
      OTLNumber: ['', this._formValidator.requireMatch],
      partNumber: [''],
      cpNumber: ['', this._formValidator.requireMatch],
      // productLine:  ['',this._formValidator.requireMatch],
      // region:  ['',this._formValidator.requireMatch],
      // salesman_email :  [''],

    });
  }
  exportStockReport(){
    let paylaod =  this.getPayload(this.primarySecReportForm.value);
    paylaod['is_export'] = true;
    paylaod['is_table_view'] = true;
    this._DashboardReportService.exportInventoryReportFilter(paylaod);
  }
  getPayload(formValue){
    let data =  {};
    //data['CustNumber'] = formValue.CustNumber ? formValue.CustNumber : '';
     data['OTLNumber'] = formValue.OTLNumber ? formValue.OTLNumber.OTLnumber : '';
     data['partNumber'] =formValue.partNumber ? formValue.partNumber.partNumber : '';
     data['cpnumber'] = formValue.cpNumber ? formValue.cpNumber.cpnumber : '';
    return data;
    }
    searchStockReport(){
      let invoiceFilterValues = this.getPayload(this.primarySecReportForm.value);
      return this.searchCPList(invoiceFilterValues);
    }
  cancelPSReport(){
    this.primarySecReportForm.reset();
    this.getInventoryReportList();
  }
  RoundOFTwoDigit(num: any){
    var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
    return number;
  } 
  getPermissionMenu(){
    this._permissionMenuListService.getPermissionMenu(response =>{
      this.permissionMenu = response;
    })
  }


  onBtShowLoading() {
       this.gridApi.showLoadingOverlay();
     }

     onBtShowNoRows() {
       this.gridApi.showNoRowsOverlay();
    }

     onBtHide() {
       this.gridApi.hideOverlay();
     }

}


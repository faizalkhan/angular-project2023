import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecondaryReportComponent } from './secondary-report.component';

describe('SecondaryReportComponent', () => {
  let component: SecondaryReportComponent;
  let fixture: ComponentFixture<SecondaryReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecondaryReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecondaryReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

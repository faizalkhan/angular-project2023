import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { ActivatedRoute, ParamMap } from '@angular/router';

import { StorageService } from 'src/app/core/services/storage/storage.service';
import { SHIPPING, ActionItems } from 'src/app/core/services/constants';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { Roles } from 'src/app/modules/auth/model/user';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';

@Component({
  selector: 'app-secondary-invoice-details',
  templateUrl: './secondary-invoice-details.component.html',
  styleUrls: ['./secondary-invoice-details.component.css']
})
export class SecondaryInvoiceDetailsComponent implements OnInit {

  public invoiceId;
  public invoiceData;
  public billingAddress;
  public shippingAddress;
  public iGst:boolean;
  public serverUrl = environment.apiUrl;
  public isAdmin =false;
  public moduleName;
  public editInvoicePermission =false;
  public editInvoice = false 
  public isCPRT = 1;
  constructor(private route: ActivatedRoute,private _UtilsService : UtilsService, public _CpbookingService: CpbookingService,
     private _secondarySalesService: SecondarysalesService ,private _storageService: StorageService) { }

  ngOnInit() {
  
    this.moduleName = this._UtilsService.moduleName();
    this.isAdmin = this._storageService.getUserDetails().role == Roles.Admin;

    this.route.paramMap.subscribe((params: ParamMap) => {
      this.invoiceId = parseInt(params.get('id'));
    });
  
    this._secondarySalesService.viewInvoice(this.invoiceId,
      (response) => {
        if(response['invoice_type'] == 'cprt'){
          this.isCPRT = 1
        }else{
          this.isCPRT = 2;
        }
        this.invoiceData = response;
        this.billingAddress = response.address.find(address => address.type !== SHIPPING );
        this.shippingAddress = response.address.find(address => address.type === SHIPPING );
        this.checkTax();
      
        if (this._storageService.getUserDetails().role !=Roles.Channel_Partner){
          this.editInvoice  = true;
        }else{
          this.checkSecondaryLockAccess()
        }

      },
      (error) => console.log(error))

      this._CpbookingService.getActionPermission({model : 'cpinvoice'},response =>{ 
        this.editInvoicePermission = response['cpinvoice'] && typeof response['cpinvoice'][ActionItems['EDIT']] != 'undefined' ? true : false;
 
     })  
     
     
  }

  checkSecondaryLockAccess(){
    this._secondarySalesService.cpModuleAccess(res => {
      if (res['secondaryLock'] == 0 ) {
        this.editInvoice = true;
        this.checkAccessControl();
      }else{
        this.editInvoice= false
      }
    });
  }
  checkAccessControl(){
    this._CpbookingService.getPermissionAccessControls({module : 'Invoice_Edit'},response =>{
      this.editInvoice = response.parent_permission[0]['is_allowed'];
    })
  }
  checkTax() { 
    if(this.billingAddress['state'].toLowerCase().replace(/\s/g,'') == this.invoiceData.cpSiteAddress['state'].toLowerCase().replace(/\s/g,'')) {
      this.iGst = false;
    }
    else {
      this.iGst = true;
    }
   
    
  }
  printInvoice() {
    window.print();
  }

  navigateEditInvoice(){
    this._secondarySalesService.navigateToEditInvoice(this.invoiceId);
   }
 

}
 
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';

import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { MatDialog } from '@angular/material';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { LocationService } from 'src/app/core/services/utils/location.service';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { InputDialogService } from 'src/app/core/modules/shared/components/input-dialog/input-dialog.service';
import { ErrorMessage, colorCodes, BILL_TO, SHIP_TO, SHIPPING, ActionItems } from 'src/app/core/services/constants';
import { AddShippingDialog, ListShippingAddress, AddPartsDialog, DcToInvoicePartsDialog,
   AddStockSwapTransfer, BackTopartsDialog, CPRTBILLING, TaxValueFreeDialog, EditCPRT } from '../../../dialogs/secondary-dialog/dialog.component';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { Roles } from 'src/app/modules/auth/model/user';

@Component({
  selector: 'app-secondary-invoice-add',
  templateUrl: './secondary-invoice-add.component.html',
  styleUrls: ['./secondary-invoice-add.component.css']
})
export class SecondaryInvoiceAddComponent implements OnInit {
  public displayClientKeys = ['name','address','city','pincode']
  public currentDate = new Date();
  public invoiceId;
  public clientInvoiceForm: FormGroup;
  public clientNames = [];
  public otlList = [];
  public clientNumber;
  public otlPartsList = [];
  public partsData = [];
  public shipDetails; // current shipping address
  public billingDetails;
  public netAmount = 0;
  public totalTax = 0;
  public iGst:boolean;
  public invoiceData;
  public packageAmount = 0;
  public calculatedDiscount = 0;
  public partsCurrentOptions = [];
  public viewInvoice = false;

  public  regionFromService=[];
  public cpAddress ;
  public cpSiteIdList = [];
  public cpAccountDetails ;
  public cessAmount=0;
  public tcsAmount =0;

  public dcList=[];
  public TransferValue: any;
  public login_cpNumber: any;
  public isCPRT: boolean = false;
  public isADDorDC: boolean = false;
  public CPRTList =[];
  constructor(private fb: FormBuilder, private _PromptService: PromptService,public _dialog: MatDialog, public _swapdialog: MatDialog, 
    public _backTopartsDialog: MatDialog, public cprt_dialog: MatDialog, public cprt_tax_dialog: MatDialog, public invoice_tax_dialog: MatDialog, public cprt_edit_dialog: MatDialog, private _bookingService: CpbookingService, private _locationService: LocationService, 
    public route: ActivatedRoute, private _secondarySalesService: SecondarysalesService,private _storageService: StorageService,private _snackBar :SnackbarService,public _inputDialogService : InputDialogService ,
    private _momentService: MomentService, private _formValidator: FormValidatorService) { }

  ngOnInit() {
     this._bookingService.getActionPermission({model : 'cpinvoice'}, response =>{
      if (!response['cpinvoice'] || !response['cpinvoice'][ActionItems['ADD']])this.cancel();
    })
    this.loadInvoiceForm();
    if (this._storageService.getUserDetails().role == Roles.Channel_Partner) {
      this._secondarySalesService.cpModuleAccess(res => {
            this.login_cpNumber = res['cpnumber'];
        if (res['secondaryLock'] == 1 ) this._secondarySalesService.navigateInvoiceList();
      });
    }
    this._bookingService.getDistinctHospitals({order_by:"name", model:"secondary"},(response => {
      this.clientNames = response;
     }));

      this._secondarySalesService.getPrintConfiguration(res=>{
        this.cpAccountDetails = res;
        this.cpAccountDetails['gst'] = this._storageService.getUserDetails().license_details[0]['gst']
        this.cpAccountDetails['pan'] = this._storageService.getUserDetails().license_details[0]['pan']
        this.cpAccountDetails['state'] = this._storageService.getUserDetails().license_details[0]['state'];
      },'isInvoice')

      this._locationService.getLocationData((locationData) => {
        this.regionFromService = locationData
      });

    this.route.paramMap.subscribe((params: ParamMap) => {
      this.invoiceId = parseInt(params.get('id'));
      if (this.invoiceId){
        this.setInvoiceForm();
      }
    });
    
    //Calculate package Amount
    this.clientInvoiceForm.get('packageAmount').valueChanges.subscribe((response) => { 
      this.packageAmount = Number(response);
    });
    //Calculate cess Amount
    this.clientInvoiceForm.get('cess_amount').valueChanges.subscribe((response) => { 
      this.cessAmount = Number(response);
      this.calculateDiscount();
    });
    //Calculate tcs Amount
    this.clientInvoiceForm.get('tcs').valueChanges.subscribe((response) => { 
      this.tcsAmount = Number(response);
      this.calculateDiscount();
    });
    //Calculate Discount value when discount value changes
    this.clientInvoiceForm.get('discount_value').valueChanges.subscribe((response) => { 
      // if (this.netAmount && this.netAmount< response) this.clientInvoiceForm.get('discount_value').reset();
      this.calculateDiscount();
    });

    //Calculate discount when discount type changes
    this.clientInvoiceForm.get('discount_type').valueChanges.subscribe((response) => { 
      this.clientInvoiceForm.get('discount_value').reset();
      if (response == 0) {
        this.clientInvoiceForm.get('discount_value').setValidators([this._formValidator.noDecimalsValidation,this._formValidator.maxEqualLength(99)])
        this.clientInvoiceForm.get('discount_value').enable()
      }
      else if (response == 1) {
        this.clientInvoiceForm.get('discount_value').setValidators([this._formValidator.noDecimalsValidation, this._formValidator.maxLength(this.netAmount - 1)])
        this.clientInvoiceForm.get('discount_value').enable()
      }
      else this.clientInvoiceForm.get('discount_value').disable();
    });
  }


  loadInvoiceForm() { 
  
    this.clientInvoiceForm = this.fb.group({
      custName: ['', [Validators.required, this._formValidator.requireMatch]],
      custNumber: ['', Validators.required],
      orderNumber: [''],
      orderDate: [''],
      site_id: ['', Validators.required],
      deliveryNote: [''],
      dispatchThrough: [''],
      dispatchDocNo: [''],
      dispatchDocDate: [''],
      referenceNumber: [''], 
      destination: [''],
      bankDetails: [''],
      packageAmount: ['0'],
      discount_type: ['2'],
      discount_value: [{value : '0' , disabled : true}],
      waybillDate: [''],
      waybillNumber: [''],
      deliveryNoteDate :[''],
      invoiceDate : [new Date(), Validators.required],
      supplierRef :[''], 
      supplierRefDate:['', Validators.required],
      termsOfPayment:[''],
      remarks:[''],
      otherRef:[''],
      tcs:['0',this._formValidator.withZeroAndNegativeValidation],
      cess_amount :['0', this._formValidator.withZeroAndNegativeValidation]

    });
  }

  onClientChange(value, otlNo?: any, partsData?: any) {
    this.otlList = [];
    this.isADDorDC = false;
    this.isCPRT = false
    this.partsData = this.invoiceId ? this.partsData : [];
    this.netAmount = 0;
    this.totalTax = 0;
    this.clientInvoiceForm.patchValue({
      site_id: '',
      custNumber: ' ',
      packageAmount : '',
      discount_type : '2',
      discount_value : '',
      tcs : '',
      cess_amount : ''
    })
    if (value) { 

      this._bookingService.getShippingAddress({ "custNumber":value.custNumber, "site_id":value.site_id, "model" :"secondary" }, (res) => {
        this.billingDetails = res[0]['edit_bill_to'];
        this.shipDetails = res[0]['edit_bill_to'];

        this.getChannelPartnerSiteAddress(value);
        this.clientInvoiceForm.get('custNumber').setValue(value.custNumber);
        this.clientInvoiceForm.get('site_id').setValue(value.site_id);
      });

      // this.checkTax();
      
     // this.billingDetails = value['edit_bill_to'];
     
    
     // this.shipDetails = value['edit_ship_to'];
 
      this._bookingService.getOtlBySiteId({ "custNumber":value.custNumber, "order_by":"otl_number" }, (response) => {
        this.otlList = response;
         if (!response.length) {
           this.loadDC();
         }
        if (this.invoiceId) {
          this.otlList.filter((res) => {
            if (res.OTLnumber === otlNo) {
              this.partsData = partsData;
              this.loadPartsTable(partsData);
            }
          })
        }
      });
    }
  }









  loadDC(){
    this._secondarySalesService.getDcList({siteId : this.clientInvoiceForm.get('site_id').value,custNumber :  this.clientInvoiceForm.get('custNumber').value}, (response) => {
      // to check if the dcnumber is already exist 
     
      this.dcList = response;
      if (!this.dcList.length)
     this._snackBar.loadSnackBar(ErrorMessage.NO_OTLNUMBER_STOCK, colorCodes.ERROR);
    })
  }
  
  getChannelPartnerSiteAddress(value){
    this._secondarySalesService.getCpSiteAddress({'cust_number' :value.custNumber },response => {
      this.cpAddress = response[0];
      this.cpSiteIdList = response;
      this.checkTax();
    })
  }


  editAddress(data, type){
    let addressDetails ;
    if (data['addressId']){
      this._secondarySalesService.getAddressDetails(data['addressId'], response =>{
        addressDetails = response['address'];
        addressDetails['addressId'] = response['id'];
        addressDetails['type'] =type;
        this.addAddress(addressDetails)
      })
    }else{
      addressDetails =  type == BILL_TO ? this.billingDetails : this.shipDetails
      addressDetails['type'] =type;
      this.addAddress(addressDetails)
    }
  }


  addAddress(addressDetails ? :any) {
    const dialogRef = this._dialog.open(AddShippingDialog, {
      width: '500px',
      data: {custNumber: this.clientInvoiceForm.get('custNumber').value, regionFromService : this.regionFromService , address : addressDetails}

    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
         this.shipDetails = (result.type == 'both' || result.type == SHIP_TO) ? result['address'] : this.shipDetails;
          this.billingDetails = (result.type == 'both' || result.type == BILL_TO) ? result['address'] : this.billingDetails;      
        this.checkTax();
      }
    });
  }
// list  channel partner address

lisChannelPartnertAddress(){
  const dialogRef = this._dialog.open(ListShippingAddress, {
    width: '500px',
    data: {details: this.cpSiteIdList, currentAddressDetails:  this.cpAddress , type : 'Channel_Partner'}
  });
  dialogRef.afterClosed().subscribe(result => {
    if (result ) this.cpAddress = result
    this.checkTax()
  });

}
// list hospital address bill-to and ship-to
  listAddress(addressType) {
    let addressList = [];
    this._secondarySalesService.getAddressList({custNumber : this.clientInvoiceForm.get('custNumber').value} , response =>{
      if (response.length) {
      response.map(data => {
          if (data.type == addressType || data.type == "both"){
            // adding hospital address id to each address obj 
            data['address']['addressId']  = data.id;
            addressList.push( data['address']);
          }
        });
      }
      this.openAddressListDialog(addressType,addressList.length ? addressList : (addressType == BILL_TO ? [this.billingDetails] : [this.shipDetails]))
    })
  }
openAddressListDialog(type,addressList){
  const dialogRef = this._dialog.open(ListShippingAddress, {
    width: '500px',
    data: {details: addressList, currentAddressDetails:  (type == BILL_TO ? this.billingDetails : this.shipDetails) }
  });
  dialogRef.afterClosed().subscribe(result => {
    if (result && !result['edited']) {
        result['address'] = result['addressLine']
        this.billingDetails = (type == BILL_TO) ? result : this.billingDetails;
        this.shipDetails = (type == SHIP_TO) ? result : this.shipDetails;
        this.checkTax();

    }else{
      if (result) this.editAddress(result ,type);
    }

  
  });
}

  loadParts() {
    let dialogRef = this.openParts(this.partsData);

    dialogRef.afterClosed().subscribe(result => {
      if(result && result['isswap']){
          this.TransferValue ={
            clientName: this.clientInvoiceForm.get('custName').value,
            clientNumber: this.clientInvoiceForm.get('custNumber').value,
            siteId: this.clientInvoiceForm.get('site_id').value,
            otlNumber: result.data['OTLNumber'],
            partNumber: result.data['partsList']
          }
          this.loadSwapTransfer(this.TransferValue);
      }
      else{
      if (result && Object.keys(result).length > 0) {
        if (result['groupByParts']){
          this.isADDorDC = true;
          result['groupByParts'].forEach((part,index)=>{
            let discountAmount =0;
            let discountType = this.clientInvoiceForm.get('discount_type').value 
            if (discountType == 0 || discountType == 2){
            discountAmount = part['total_amount'] - (( discountType ==0 ? ( part['total_amount'] * (this.clientInvoiceForm.get('discount_value').value/100)): 0 ))
            part['cgst'] = this.RoundOFTwoDigit(Number((( discountAmount*(part.HSSNtax/2))/100))) 
            part['sgst'] = this.RoundOFTwoDigit(Number((( discountAmount*(part.HSSNtax/2))/100))); 
            part['igst'] =  this.RoundOFTwoDigit(Number((( discountAmount*part.HSSNtax)/100)));
          }
            this.getPartsData(part);
          })
        }
      }
    }
    });

  }
 
  getPartsData(result){
    if(result.quantity){
      let index = this.partsData.findIndex(part => part['OTLNumber'] === result['OTLNumber'] && part['partNumber'] === result['partNumber']&& part['lotNumber']=== result['lotNumber'] );
      if(index >= 0 &&  this.partsData.length) this.partsData[index] = result;
      else this.partsData.push(result);
      }
    if ( this.clientInvoiceForm.get('discount_type').value == 1 ) this.calculatePartsTaxWithDiscountPrice();
    this.loadPartsTable(result);
    this.calculateDiscount();
  }

  loadPartsTable(result) {
    if (result && this.partsData) {
      this.netAmount= this.partsData.reduce((currentAmount, part)=>{
        return this.RoundOFTwoDigit(Number((currentAmount+ part['total_amount'])))
      },0)
      this.getTotalTax();
      if (!this.netAmount|| !this.enableDiscountField() || (this.clientInvoiceForm.get('discount_type').value == 1 && this.netAmount < this.clientInvoiceForm.get('discount_value').value)){
        this.clientInvoiceForm.get('discount_value').setValue('')
        this.clientInvoiceForm.get('discount_type').setValue('2');
        this.discountFocusOut(2);
      }
      if (this.clientInvoiceForm.get('discount_type').value == 1)  this.clientInvoiceForm.get('discount_value').setValidators([this._formValidator.noDecimalsValidation, this._formValidator.maxEqualLength(this.netAmount - 1) ])
    }
  }
  getTotalTax(){
    this.totalTax = this.partsData.reduce((currentAmount, part)=>{
      return this.RoundOFTwoDigit(Number((currentAmount+ (this.iGst ? part['igst'] : (part['sgst'] + part['cgst'])))))
    },0);
  }
  
  calculateSinglePart(index, discountAmount){
       this.partsData[index]['cgst'] = this.RoundOFTwoDigit(Number((( discountAmount*(this.partsData[index].HSSNtax/2))/100)))  
        this.partsData[index]['sgst'] =  this.RoundOFTwoDigit(Number((( discountAmount*(this.partsData[index].HSSNtax/2))/100)));
        this.partsData[index]['igst'] =  this.RoundOFTwoDigit(Number((( discountAmount*this.partsData[index].HSSNtax)/100)));
  }

  
  openParts(data, parts?: any) {
    const dialogRef = this._dialog.open(AddPartsDialog, {
      autoFocus: false,
      width: '750px',
      disableClose: true,
      data: { "partsOutput": {},'otlList' : this.otlList, "currentPartsData": data, "editParts": parts ? parts : '', 
      "iGst" : this.iGst,  "editForm" : this.invoiceId, 
      "site_id":this.clientInvoiceForm.get('site_id').value, "isADD":true, "LogincpNumber":this.login_cpNumber }
    });
    return dialogRef;
  }

  openSwapParts(transferData: any){
    const swap_dialogRef = this._swapdialog.open(AddStockSwapTransfer,{
      autoFocus: false,
      width: '80%',
      disableClose: true,
      data: {"partsOutput":{}, "swapData": transferData, "isSecondaryScreen": true}
    });
    return swap_dialogRef;
   }
   backToOpenParts(partsdetail: any, data:any, parts?:any){
    const parts_dialog = this._backTopartsDialog.open(BackTopartsDialog, {
      autoFocus: false,
      width: "750px",
      disableClose: true,
      data: { "partsOutput": {},"partsData": partsdetail, "currentPartsData": data, "editParts": parts ? parts : '', "iGst" : this.iGst,  "editForm" : this.invoiceId,
       "isADD":true,"site_id":this.clientInvoiceForm.get('site_id').value, "LogincpNumber":this.login_cpNumber}
    });
  return parts_dialog;
 }
  loadSwapTransfer(transferValue: any){
    let swap_dialogRefe = this.openSwapParts(transferValue);
    swap_dialogRefe.afterClosed().subscribe(result =>{
   
      if(result['iscancel'] =='cancel'){
        this.loadBackToParts(result['datavalue']['swapData']);
      }else{
        if(result['isSwap'] == 'swap'){
        this.loadBackToParts(result['datavalue']['swapData']);
        }
      }

    })
  }
  loadBackToParts(data?: any){
    let back_to_Dialog = this.backToOpenParts(data, this.partsData);
    back_to_Dialog.afterClosed().subscribe(result =>{
      if(result && result['isswap']){
        this.TransferValue ={
          clientName: this.clientInvoiceForm.get('custName').value,
          clientNumber: this.clientInvoiceForm.get('custNumber').value,
          siteId: this.clientInvoiceForm.get('site_id').value,
          otlNumber: result.data['OTLNumber'],
          partNumber: result.data['partsList']
        }
        this.loadSwapTransfer(this.TransferValue);
    }
      else{
      if (result && Object.keys(result).length > 0) {
        if (result['groupByParts']){
          this.isADDorDC = true;
          // let partsQty = this.partsData.reduce((currentAmount, partData) => currentAmount + partData['quantity'],0) ; 
          result['groupByParts'].forEach((part,index)=>{
            let discountAmount =0;
            let discountType = this.clientInvoiceForm.get('discount_type').value 
            if (discountType == 0 || discountType == 2){
            discountAmount = part['total_amount'] - (( discountType ==0 ? ( part['total_amount'] * (this.clientInvoiceForm.get('discount_value').value/100)): 0 ))
            part['cgst'] = Number((( discountAmount*(part.HSSNtax/2))/100).toFixed(2))  
            part['sgst'] = Number((( discountAmount*(part.HSSNtax/2))/100).toFixed(2)) 
            part['igst'] =  Number((( discountAmount*part.HSSNtax)/100).toFixed(2)) 
          }
            this.getPartsData(part);
          })
        }
      }
    }
    })
 }

  deleteParts(index) {
      this.partsData.splice(index, 1);
      if(this.partsData.length == 0){
        this.isADDorDC = false;
      }
      if (this.clientInvoiceForm.get('discount_type').value == 1) this.calculatePartsTaxWithDiscountPrice();
      this.checkPartsDataCount();
  }


  checkPartsDataCount() {
    if (this.partsData.length > 0) this.loadPartsTable(this.partsData);
    else {
      this.netAmount = 0;
      this.totalTax = 0;
      this.clientInvoiceForm.get('discount_value').setValue('')
      this.clientInvoiceForm.get('discount_type').setValue('2')
    }
    this.calculateDiscount();
  }

  loadPartsTableForm(result, index) {
    for (let part = 0; part < this.partsData.length; part++) {
      if (part == index) {
        this.partsData[part] = result;
      }
    }
    this.loadPartsTable(result)
  }

// Start - converting DC to Invoice 
loadDcToInvoice(){
  this._secondarySalesService.getDcList({custNumber :  this.clientInvoiceForm.get('custNumber').value}, (response) => {
    // to check if the dcnumber is already exist 
   
    this.dcList = response;
    if (!this.dcList.length  && !this.otlList.length){}
    else this.openDcListDialog(response)
  }); 
}
loadCPRT(){
  let dialogref = this.openCPRT();
  dialogref.afterClosed().subscribe(result =>{
   if(result['CPRT']){
     this.isCPRT = result['CPRT']
    result['value'].forEach(item=>{

      let object={
        'test_name':item['test_name'],
        'HSSNcode':item['hsn'],
        'quantity':item['no_of_tests'],
        'price':item['cost_per_test'],
        'total_amount':item['cost_per_test'] * item['no_of_tests'],
        'total_amount_with_tax':item['cost_per_test'] * item['no_of_tests'],
        'HSSNtax':0,
        'cgst':0,
        'igst':0,
        'sgst':0

      }
        
      this.CPRTList.push(object);
      this.loadCPRT_list(this.CPRTList);
    })
   }
  })

}
editCPRT(index: any){
  let dialogref = this.openEditCPRT(this.CPRTList[index], index);
  dialogref.afterClosed().subscribe(result=>{
    if(result){
      this.CPRTList[index]['test_name'] = result['desc'];
      this.CPRTList[index]['quantity'] = result['no_of_tests'];
      this.CPRTList[index]['HSSNcode'] = result['hsn'];
      this.CPRTList[index]['price'] = result['cost_per_tests'];
      this.CPRTList[index]['total_amount'] =this.RoundOFTwoDigit(this.CPRTList[index]['quantity']*this.CPRTList[index]['price']);
      this.CPRTList[index]['igst']= this.RoundOFTwoDigit((this.CPRTList[index]['total_amount'] *this.CPRTList[index]['HSSNtax'])/100);
      this.CPRTList[index]['cgst']=this.RoundOFTwoDigit((this.CPRTList[index]['total_amount'] *this.CPRTList[index]['HSSNtax'])/200);
      this.CPRTList[index]['sgst']=this.RoundOFTwoDigit((this.CPRTList[index]['total_amount'] *this.CPRTList[index]['HSSNtax'])/200);
      this.CPRTList[index]['total_amount_with_tax']= this.iGst ? (this.CPRTList[index]['total_amount'] + this.CPRTList[index]['igst']) : (this.CPRTList[index]['total_amount'] + (this.CPRTList[index]['cgst'] + this.CPRTList[index]['sgst'] ) )
      this.loadCPRT_list(this.CPRTList);
    }


  })

}

editCPRTTax(index:any){
  let dialogRef = this.openTaxCPRT(this.CPRTList[index], index);
  dialogRef.afterClosed().subscribe(result=>{
    if(result>=0){
      this.CPRTList[index]['HSSNtax'] = result;
      this.CPRTList[index]['igst']= this.RoundOFTwoDigit((this.CPRTList[index]['total_amount'] *this.CPRTList[index]['HSSNtax'])/100);
      this.CPRTList[index]['cgst']=this.RoundOFTwoDigit((this.CPRTList[index]['total_amount'] *this.CPRTList[index]['HSSNtax'])/200);
      this.CPRTList[index]['sgst']=this.RoundOFTwoDigit((this.CPRTList[index]['total_amount'] *this.CPRTList[index]['HSSNtax'])/200);
      this.CPRTList[index]['total_amount_with_tax']= this.RoundOFTwoDigit(this.iGst ? (this.CPRTList[index]['total_amount'] + this.CPRTList[index]['igst']) :
       (this.CPRTList[index]['total_amount'] + (this.CPRTList[index]['cgst'] + this.CPRTList[index]['sgst'] ) ))
      this.loadCPRT_list(this.CPRTList);
    }
  })

}
deleteCPRT(index){
  this.CPRTList.splice(index,1);
  if(this.CPRTList.length == 0){
    this.isCPRT = false;
  }
  this.loadCPRT_list(this.CPRTList);
}

openCPRT(){
 const dialogRef =  this.cprt_dialog.open(CPRTBILLING, {
    autoFocus: false,
    width: '950px',
    });
  return dialogRef;

}
openTaxCPRT(value, indexid){
  const dialogRef = this.cprt_tax_dialog.open(TaxValueFreeDialog,{
    autoFocus: false,
    width: '500px',
    data:{ "parts": value, "index":indexid}
  });
  return dialogRef;
}
openEditCPRT(value: any, index_id:any){
  const dialogRef = this.cprt_dialog.open(EditCPRT, {
    autoFocus:false,
    width:'750px',
    data:{'parts': value, 'index':index_id}
  });
  return dialogRef;
}

loadCPRT_list(result:any){
  if(result && this.CPRTList){
    this.netAmount= this.CPRTList.reduce((currentAmount, cprt)=>{
      return this.RoundOFTwoDigit(Number(currentAmount+ (cprt['total_amount'])))
    
    },0)


  this.totalTax = this.CPRTList.reduce((currentAmount, cprt)=>{
    return this.RoundOFTwoDigit(Number(currentAmount+ ( this.iGst ? cprt['igst'] : (cprt['sgst'] + cprt['cgst']))))
  },0);
     
  }
}
openDcListDialog(response){
  let dialogRef = this.openDcDialog(response,'DC_LIST');
    dialogRef.afterClosed().subscribe(result => { 
      if (result){
                this.isADDorDC = true;
                this._secondarySalesService.getDcParts({'dcId' : result},
                  (response) => {
                    response =   response.filter(res=> !this.partsData.some(part => (part['dcNumber'] == res['dcNumber'] && part['partNumber'] == res['partNumber'])));
                    if (response.length) {
                    let dcParts = response.map((part,index) =>{
                      part['groupedData'] = part['part'];
                      part['quantity'] = part['quantity'] > part['invoicedQuantity']  ? part['quantity'] - part['invoicedQuantity'] :  part['invoicedQuantity'] - part['quantity']
                      part['total_amount'] = this.RoundOFTwoDigit(Number((part.price *  part['quantity'])));    
                      // calculate discount field 
                      let discountType = this.clientInvoiceForm.get('discount_type').value 
                      
                      if (discountType == 0 || discountType ==2){
                        let discountAmount = 0
                         // calculating only for discount type = 0 or discount type = 1
                         discountAmount = part['total_amount'] - ( discountType == 0 ? ( part['total_amount'] * (this.clientInvoiceForm.get('discount_value').value/100)): 0 )
                         part['cgst'] = this.RoundOFTwoDigit(Number((( discountAmount*(part.HSSNtax/2))/100))) 
                         part['sgst'] = this.RoundOFTwoDigit(Number((( discountAmount*(part.HSSNtax/2))/100))) 
                         part['igst'] =  this.RoundOFTwoDigit(Number((( discountAmount*part.HSSNtax)/100))) 
                      }
                     
                      delete part['part'];
                      return part;
                    })
                      this.partsData = this.partsData.concat(dcParts);
                      if (this.clientInvoiceForm.get('discount_type').value  == 1) this.calculatePartsTaxWithDiscountPrice();
                      this.loadPartsTable(result);
                      this.calculateDiscount()
                    }
                  })
      }
    })
}


openDcDialog(response,type){
  const dialogRef =  this._dialog.open(DcToInvoicePartsDialog, {
    autoFocus: false,
    width: '950px',
    data: { "parts": response, 'type' : type,'siteId' : this.clientInvoiceForm.get('site_id').value,'custNumber' :  this.clientInvoiceForm.get('custNumber').value , 'Create_Invoice' :  true}
    });
  return dialogRef;
}

editDCParts(index){
  // to maintain dcparts orginal quantity, when the quantity is editing 
  this.partsData[index]['originalQty'] = this.partsData[index]['originalQty']  ? this.partsData[index]['originalQty'] : this.partsData[index]['quantity'];
  let dialogRef = this.openDcDialog(this.partsData[index],'EDIT_DC_LIST');
  dialogRef.afterClosed().subscribe(result => { 
    if (result){
      this.partsData[index]['quantity'] = result['quantity'];
      this.partsData[index]['total_amount'] = this.RoundOFTwoDigit(Number((this.partsData[index].price *  this.partsData[index]['quantity']))); 
      // calculate discount with tax parts
      this.checkNetAmountLessThanDiscountValue(index);
     
      this.loadPartsTable(result)
      this.calculateDiscount();
    }
  })
}


// End- converting DC to Invoice 
  createClientInvoice() {
    let data = this.clientInvoiceForm.value;
    data.custName = this.clientInvoiceForm.get('custName').value.name;
    data.siteId = data.site_id;
    data.OTLNumber = '';
    data.dispatchDocDate = data.dispatchDocDate ? this._momentService.getIsoFormat(data.dispatchDocDate): null;
    data.orderDate = data.orderDate ? this._momentService.getIsoFormat(data.orderDate): null;
    data.deliveryNoteDate = data.deliveryNoteDate ? this._momentService.getIsoFormat(data.deliveryNoteDate): null;
    data.invoiceDate = data.invoiceDate ? this._momentService.getIsoFormat(data.invoiceDate): null;
    data.waybillDate = data.waybillDate ? this._momentService.getIsoFormat(data.waybillDate): null;
    data.supplierRefDate = data.supplierRefDate ? this._momentService.getIsoFormat(data.supplierRefDate) : null;
    this.shipDetails['contactPerson']=this.shipDetails['contactperson'] ? this.shipDetails['contactperson'] :this.shipDetails['contactPerson']
    this.billingDetails['contactPerson'] =this.billingDetails['contactperson'] ?this.billingDetails['contactperson'] :this.billingDetails['contactPerson'];
    delete this.shipDetails['contactperson'];
    delete this.billingDetails['contactperson'];
    data['shipping_address'] =Object.assign({}, this.shipDetails) ;
    data['shipping_address']['type'] = 'shipping'
    data['billing_address'] = Object.assign({}, this.billingDetails)  ;
    data['billing_address']['type'] = 'billing'
    data['net_amount'] = this.RoundOFTwoDigit(Number(this.netAmount));
    data['total_amount'] = this.RoundOFTwoDigit(Number(((data['net_amount'] - this.calculatedDiscount)+ + this.totalTax + this.cessAmount +this.tcsAmount + this.packageAmount)));
    data['total_tax'] = this.RoundOFTwoDigit(Number(this.totalTax));
    data['gstNumber'] = this.cpAccountDetails.gst;
    data['panNumber'] = this.cpAccountDetails.pan;
    data['packageAmount'] = data['packageAmount'] ? data['packageAmount'] : '0';
    data['tcs'] = data['tcs'] ? data['tcs'] : '0';
    data['cess_amount'] = data['cess_amount'] ? data['cess_amount'] : '0';
    data['discount_value'] =this.enableDiscountField() && data['discount_value'] ? data['discount_value'] : '0';
    data['discount_type'] = this.enableDiscountField() &&data['discount_type'] ? data['discount_type'] : '2';
    data['termsOfPayment'] = data['termsOfPayment'] ? data['termsOfPayment'] : '0';
    data['cpSiteAddress'] = this.cpAddress['cpSiteAddress']
     data['cpSiteId']= this.cpAddress['cpSiteId']
     data['hasDCParts']= this.partsData.find(part => part['dcNumber']) ? 1 : 0
      if(this.isCPRT){
        data['invoice_type'] ='cprt'
        data.parts = this.CPRTList;
      }else{
        data['invoice_type'] ='invoice'
      data.parts = this.partsData;
      }
      this._secondarySalesService.addInvoice(data, (response) => {
        this._secondarySalesService.navigateInvoiceList();
      });  

  
  }

  checkTax() {
    // Based on hospital state and ship to state , IGST is calculated 
    if(this.billingDetails['state'].toLowerCase().replace(/\s/g,'')  ==   this.cpAddress['cpSiteAddress']['state'].toLowerCase().replace(/\s/g,'')) {
      this.iGst = false;
    }
    else {
      this.iGst = true;
    }
  }

  setInvoiceForm() {
    this._secondarySalesService.viewInvoice(this.invoiceId,response=>{
      if (response) { 
        this.billingDetails = response.address.find(address => address.type !== SHIPPING );
        this.shipDetails = response.address.find(address => address.type === SHIPPING );
        
       let name =  this.getCustName(response.custName, response.OTLNumber , response.parts);
       this.partsData = response.parts;
       this.CPRTList = response.parts;
       this.invoiceData = response;
        this.clientInvoiceForm.patchValue({
            custName:name,
            custNumber:response.cpNumber ,
            orderNumber: response.orderNumber,
            orderDate: response.orderDate,
            deliveryNote:response.deliveryNote,
            dispatchThrough: response.dispatchThrough,
            dispatchDocNo: response.dispatchDocNo,
            dispatchDocDate: response.dispatchDocDate,
            referenceNumber: response.referenceNumber,
            destination: response.destination,
            bankDetails: response.bankDetails ,
            packageAmount: response.packageAmount,
            discount_value: response.discount_value,
            discount_type: response.discount_type.toString(),
        })
        this.checkTax();
        // this.calculatedDiscount = Number(((response.net_amount + response.total_tax) * (response.discount_value/100)).toFixed(2));
      }
    },error=> console.log(error))
  }

  getCustName(custName, otlno, partsData) {
    let customerDetails;
    customerDetails = this.clientNames.filter((res) => {
      return res.name.toLowerCase() === custName.toLowerCase();
    });
    if (customerDetails.length > 0){
      customerDetails[0]['type'] = 'billing'
    }
    this.onClientChange(customerDetails ? customerDetails[0] : '', otlno, partsData);
    return customerDetails ? customerDetails[0] : '';
  }
  
  checkNetAmountLessThanDiscountValue(index){
     // calculate discount with tax parts
     let discountValue = this.clientInvoiceForm.get('discount_type').value;
    if (discountValue == 1){
      this.calculatePartsTaxWithDiscountPrice();
    }else if (discountValue ==0) {
     this.calculateSinglePart(index, (this.partsData[index]['total_amount']  -( this.partsData[index]['total_amount'] * (this.clientInvoiceForm.get('discount_value').value/100)) ))
    }else{
      this.calculateSinglePart(index ,  this.partsData[index]['total_amount'])
    }

  }

  calculateDiscount() {
   if(this.clientInvoiceForm.get('discount_type').value && this.clientInvoiceForm.get('discount_value').value)
   {
      if(this.clientInvoiceForm.get('discount_type').value === '0') this.calculatedDiscount = this.RoundOFTwoDigit(Number(((this.netAmount) * (this.clientInvoiceForm.get('discount_value').value/100)))); 
      if(this.clientInvoiceForm.get('discount_type').value === '1') this.calculatedDiscount = this.clientInvoiceForm.get('discount_value').value; 
  }
  else {
      this.calculatedDiscount = 0;
  }
  
  }
  // to disable the save button when discount type is selected and discount value is empty 
  checkDiscountAmount(){
       return  (this.clientInvoiceForm.get('discount_type').value != 2 &&  !this.clientInvoiceForm.get('discount_value').value) ? false : true
  }

  discountFocusOut(value){
        if (this.clientInvoiceForm.get('discount_type').value == 0) this.calculatePartsTaxWithDiscountPercentage();
        else if (this.clientInvoiceForm.get('discount_type').value == 1) this.calculatePartsTaxWithDiscountPrice();
        else this.calculatedPartsTaxWithoutDiscount();
  }
    // tax should be caluclate after netamount is minus by discount amount  price

    calculatePartsTaxWithDiscountPrice(){
      let partsQty = this.partsData.reduce((currentAmount, partData) => currentAmount + (partData['price'] ? partData['quantity'] : 0),0) ;
      let singlePartDiscountAmt = this.clientInvoiceForm.get('discount_value').value / partsQty;

      this.partsData.map((part,index) => {
            let discountAmount = part['total_amount']  ? part['total_amount']  - (singlePartDiscountAmt * part['quantity'] ) : 0; 
            if (discountAmount < 0) {
              this.clientInvoiceForm.get('discount_type').setValue('2');
              this.clientInvoiceForm.get('discount_value').reset();
              this.calculatePartsTaxWithDiscountPrice();
            }else {
            this.calculateSinglePart(index , discountAmount);
            }
            return part;
      })
      this.getTotalTax();
    }
  
    // tax should be caluclate after netamount is minus by discount amount  percentage
    calculatePartsTaxWithDiscountPercentage(){
            this.partsData.map((part,index) => {
                let netAmount = part['price'] *  part['quantity']
                 this.calculateSinglePart(index , (netAmount - (netAmount * (this.clientInvoiceForm.get('discount_value').value/100))));
                return part;
          })
      this.getTotalTax();
    }
    calculatedPartsTaxWithoutDiscount(){
      this.partsData.map((part,index) => {
        let netAmount = part['price'] *  part['quantity']
         this.calculateSinglePart(index ,netAmount);
        return part;
  })
      // this.loadPartsTable(this.partsData, 'noDiscount')
      this.getTotalTax();
    }

  enableDiscountField(){
    if(!this.partsData.every(res => res['partNumber'] == this.partsData[0]['partNumber'] && res['OTLNumber'] == this.partsData[0]['OTLNumber']) ){
      this.clientInvoiceForm.get('discount_value').setValue('')
      this.clientInvoiceForm.get('discount_type').setValue('2')
    }
    
    return  this.partsData.every(res => res['partNumber'] == this.partsData[0]['partNumber'] && res['OTLNumber'] == this.partsData[0]['OTLNumber'] );
  }

  cancel(){
     this._secondarySalesService.navigateInvoiceList();
  }

  reset(){
    if (this.invoiceId) this.setInvoiceForm();
    else{
      this.partsData = [];
      this.clientInvoiceForm.reset();
      this.shipDetails = ''; 
      this.otlList =[];
      this.billingDetails='';
      this.netAmount = 0;
      this.totalTax = 0;
      this.cessAmount = 0;
      this.tcsAmount = 0;
      this.clientInvoiceForm.get('invoiceDate').setValue(new Date())
      this.clientInvoiceForm.get('discount_type').setValue('2')
      this.clientInvoiceForm.get('discount_value').setValue('0') 
    }
    this.isADDorDC = false;
  
  }
  resetCPRT(){
    if(this.invoiceId){
      this.setInvoiceForm();

    }else{
      this.CPRTList = [];
      this.clientInvoiceForm.reset();
      this.shipDetails = ''; 
      this.otlList =[];
      this.billingDetails='';
      this.netAmount = 0;
      this.totalTax = 0;
      this.cessAmount = 0;
      this.tcsAmount = 0;
      this.clientInvoiceForm.get('invoiceDate').setValue(new Date())
      this.clientInvoiceForm.get('discount_type').setValue('2')
      this.clientInvoiceForm.get('discount_value').setValue('0')

    }
    this.isCPRT = false
  }
  viewInvoiceDetails(status){
    this.viewInvoice= status 
 }
 RoundOFTwoDigit(num: any){
  var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
  return number;
}
editinvoiceTax(index: any){
  let dialogRef = this.openinvoiceTax(this.partsData[index], index);
  dialogRef.afterClosed().subscribe(result=>{
    if(result>=0){
      this.partsData[index]['HSSNtax'] = result;
      this.partsData[index]['igst']= this.RoundOFTwoDigit((this.partsData[index]['total_amount'] *this.partsData[index]['HSSNtax'])/100);
      this.partsData[index]['cgst']=this.RoundOFTwoDigit((this.partsData[index]['total_amount'] *this.partsData[index]['HSSNtax'])/200);
      this.partsData[index]['sgst']=this.RoundOFTwoDigit((this.partsData[index]['total_amount'] *this.partsData[index]['HSSNtax'])/200);
      this.loadPartsTable(this.partsData);
    }
  })
}
openinvoiceTax(value, indexid){
  const dialogRef = this.invoice_tax_dialog.open(TaxValueFreeDialog,{
    autoFocus: false,
    width: '500px',
    data:{ "parts": value, "index":indexid}
  });
  return dialogRef;
}
}

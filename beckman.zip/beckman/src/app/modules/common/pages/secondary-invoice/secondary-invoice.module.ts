import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SecondaryInvoiceComponent } from './secondary-invoice.component';
import { SecondaryInvoiceAddComponent } from './secondary-invoice-add/secondary-invoice-add.component';
import { SecondaryInvoiceListComponent } from './secondary-invoice-list/secondary-invoice-list.component';
import { SecondaryInvoiceDetailsComponent } from './secondary-invoice-details/secondary-invoice-details.component';
import { SecondaryInvoiceEditComponent } from './secondary-invoice-edit/secondary-invoice-edit.component';
import { RouterModule, Routes } from '@angular/router';
import { AgGridModule } from 'ag-grid-angular';
import { CommonDialogModule } from '../../dialogs/common-dialog.module';
import { AddShippingDialog, ListShippingAddress, AddPartsDialog, DcToInvoicePartsDialog, AddStockSwapTransfer,
   BackTopartsDialog, CPRTBILLING, TaxValueFreeDialog, TaxValueInvoiceDialog, EditCPRT } from '../../dialogs/secondary-dialog/dialog.component';


const routes: Routes = [{ 
  path:'', 
  component:SecondaryInvoiceComponent,
  children:[{
    path: '', 
    component:SecondaryInvoiceListComponent
  },{
    path: 'add',
    component:SecondaryInvoiceAddComponent
  },{
    path: 'view/:id',
    component:SecondaryInvoiceDetailsComponent
  },{
    path: 'edit/:id',
    component:SecondaryInvoiceEditComponent
  }
]
}]


@NgModule({
  declarations: [SecondaryInvoiceComponent, SecondaryInvoiceAddComponent, SecondaryInvoiceListComponent, SecondaryInvoiceDetailsComponent, SecondaryInvoiceEditComponent
   
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    AgGridModule.withComponents([]),
    CommonDialogModule,
  ],
  entryComponents:[AddShippingDialog, ListShippingAddress, AddPartsDialog, DcToInvoicePartsDialog, AddStockSwapTransfer, BackTopartsDialog, CPRTBILLING, TaxValueInvoiceDialog, 
    TaxValueFreeDialog, EditCPRT ],
  exports :[  SecondaryInvoiceComponent,AgGridModule, SecondaryInvoiceAddComponent, SecondaryInvoiceListComponent, SecondaryInvoiceDetailsComponent, SecondaryInvoiceEditComponent],
})
export class SecondaryInvoiceModule { }

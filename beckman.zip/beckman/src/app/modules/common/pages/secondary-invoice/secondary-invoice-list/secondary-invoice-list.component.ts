import { Component, OnInit, HostListener } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { IGetRowsParams } from 'ag-grid-community';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { AgGridRouterComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-router.component';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { Roles } from 'src/app/modules/auth/model/user';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { ActionItems } from 'src/app/core/services/constants';
import { StockReportService } from '../../../service/stock-reports/stock-report.service';

@Component({ 
  selector: 'app-secondary-invoice-list',
  templateUrl: './secondary-invoice-list.component.html',
  styleUrls: ['./secondary-invoice-list.component.css']
})
export class SecondaryInvoiceListComponent implements OnInit {

  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public searchValue;
  public custNameList = [];
  public gridData = [];
  public invoiceSearchForm: FormGroup;
  public isSecondaryLock;
  public role ;
  public editInvoice = false;
  public moduleName ;
  public editCpInvoice= false;
  public secondaryInvoicePermission ;
  public partList=[];
  public otlList =[];
  public pageSize = 10;
  public isAdmin:boolean = false;
  public cpList = [];
  public isChannelPartner;
  public displayChannelPartnerKeys = ['name', 'cpnumber']
  public displayChannelPartnerKeys1 = ['name', 'custNumber'];
  public invoice_typeList = [];
  constructor(private _secondarySalesService: SecondarysalesService,private _UtilsService : UtilsService, private _StorageService: StorageService, private _StockReportService:StockReportService,
    private _momentService: MomentService, private fb: FormBuilder, private _bookingService: CpbookingService,
 private _formValidator: FormValidatorService, private _utilsService : UtilsService) { }
 @HostListener('window:resize', ['$event'])onResize(event) {
  this.gridApi.sizeColumnsToFit();
}
  ngOnInit() {
    this.checkEditAccessControl();
    this.loadSecondaryPermission();
    this.moduleName = this._UtilsService.moduleName();
    this.role = this._StorageService.getUserDetails().role;
   // this.isAdmin = this.role == Roles.Admin ;
    this.isChannelPartner = this._utilsService.isCpRole(this.role);
    if (this.role == Roles.Channel_Partner) {
      this._secondarySalesService.cpModuleAccess(res => {
        this.isSecondaryLock = res['secondaryLock'] == 1 ? true : false 
        });
    }

    this. loadInvoiceFilterForm();
    this.setClientList ();
    this.setOtlList();
    this.setPartsList(); 
    this.setCPList();
    this.setInvoiceList();
    this.defaultColDef = {
      sortable: true,
      filter: true,
      resizable: true
    };

    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2
    };

    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.gridOptions.onFilterChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: 'id',
        headerName: 'S No.',
        width: 100,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
      },
      {
        headerName: 'Invoice Number',
        field: 'invoiceNumber',
        width: 190,
        cellRendererFramework: AgGridRouterComponent,
        cellRendererParams: {
          inRouterLink:'/'+this.moduleName+'/secondary-sales/invoice/view',
          navigateId: 'id'
        },
        comparator: (param1, param2) => {
          return this._UtilsService.numberSorting(param1,param2);
        },
      },
      {
        headerName: 'Invoice Date',
        field: 'created_on',
        valueFormatter : this.formatDate.bind(this),
        width: 250,
      },
      {
        headerName: 'Client Name',
        field: 'custName',
        width: 200,
      },
      {
        headerName: 'Order No.',
        field: 'orderNumber',
        width: 200,
      },
      {
        headerName: 'Reference No.',
        field: 'referenceNumber',
        width: 200,
      },
      {
        headerName:'Invoice Type',
        field:'invoice_type',
        valueFormatter: this.formatType.bind(this),
        width:200
      },
      {
        headerName: 'Net Amount', 
        field: 'net_amount',
        width: 200,
        comparator: (param1, param2) => {
          return this._UtilsService.numberSorting(param1,param2);
        },
        cellRenderer :(params) =>{
          return  typeof params.value !== 'undefined'? "<div class = 'text-right'>" + this._UtilsService.rupeeFormat(this.RoundOFTwoDigit(params.value)) + "</div>":'';
        }
      },
      {
        field: 'isEditable',
        headerName: 'Action',
        sortable: false,
        filter: false, 
        width: 100,
        cellRendererFramework: AgGridMenuComponent,
        cellRendererParams:   (params) => {
          console.log(params.value)
         let menu=[{
            name: 'View',
            link: '/'+this.moduleName+'/secondary-sales/invoice/view',
          }]
          if ((this.editCpInvoice && this.role != Roles.Channel_Partner)||(this.role == Roles.Channel_Partner && this.editCpInvoice && !this.isSecondaryLock &&params.value  && this.editInvoice)) {
           menu.push({
              name: 'Edit',
              link: '/'+this.moduleName+'/secondary-sales/invoice/edit',
            })
          }
          return { 
            menu
          }

      }
    }]; 
   }


   setActionsPermission(name){
     
    return this.secondaryInvoicePermission && typeof this.secondaryInvoicePermission[ActionItems[name]] != 'undefined'  ?  true : false;
  }

  loadSecondaryPermission(){
      this._bookingService.getActionPermission({model : 'cpinvoice'}, response =>{
        this.secondaryInvoicePermission= response['cpinvoice'];
        this.editCpInvoice = this.setActionsPermission('EDIT')
      });
  }

  checkEditAccessControl(){
    this._bookingService.getPermissionAccessControls({module : 'Invoice_Edit'},response =>{
      this.editInvoice = response.parent_permission[0].is_allowed;
    })
  }
  setClientList(){
    this._bookingService.listHospital( res =>{
      this.custNameList = this._UtilsService.groupByMultipleKeys(res,['name','custNumber'])
    })
  }
  setOtlList(){
    this._bookingService.getListofOTLParts(res =>{
      this.otlList =  this._UtilsService.groupByMultipleKeys(res,['name','OTLnumber'])
    })
  }
  setPartsList(){
    // need to change api  
    this._StockReportService.getListParts(this.role,(res) => {
      this.partList = res  
    });
  }
  setCPList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpList = this._utilsService.groupByMultipleKeys(res,['name','cpnumber'])   
    })
  }
  formatDate(params){
    return  params.data? this._momentService.getDateTimeFormat(params.data.created_on):'';
  }
  formatType(params){            
    return params.data ? (params.data['invoice_type'] == 'cprt' ? 'CPRT' : 'Invoice'):'';
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
   
        this.getSecondaryInvoices();
  }
  getCPList(data?: any){
    let payload = {};
    var datasource = {
      getRows: (params: IGetRowsParams) =>{
        if (data) {
          payload = data;
        }
        payload['page_size'] =this.pageSize
        payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
        payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
        payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
          this._secondarySalesService.searchClientInvoice(data,(res)=>{
            let length = res['total'];
            this.gridData = res['results'];
            console.log(this.gridData,'-203-');
            params.successCallback(res['results'], length)
          })
      }
    }
      this.gridApi.setDatasource(datasource);
  }

  getSecondaryInvoices() {
    let data = {
      from_date : this._momentService.getFilterFormat(this.invoiceSearchForm.get('from_date').value),
      to_date : this._momentService.getFilterFormat(this.invoiceSearchForm.get('to_date').value, "toDate"),
    }
return this.getCPList(data);
    // this._secondarySalesService.listInvoices(data, (res) => {
    //   this.gridApi.setRowData(res);
    //   this.gridData = res;
    //   console.log(this.gridData,'-197')
    //   this.gridApi.paginationGoToFirstPage(); 
    // },
    //   (error) => {
    //     this.gridApi.setRowData([])
    //   }
    // ); 
  }
  

  quickSearch() {
    this.gridApi.setQuickFilter(this.searchValue);
  }



  loadInvoiceFilterForm() {
    this.invoiceSearchForm = this.fb.group({
      from_date:[this._momentService.deceedDate(new Date(),31)],
      to_date:[new Date()],
      invoiceNumber: [''],
      custNumber: ['',this._formValidator.requireMatch],
      orderNumber: [''] ,
      OTLNumber:  ['',this._formValidator.requireMatch],
      partNumber :  ['',this._formValidator.requireMatch],
      cpNumber : ['', this._formValidator.requireMatch],
      invoice_type:['', this._formValidator.requireMatch]
    },{ validator: this._formValidator.dateValidation('from_date', 'to_date') });
  }

  searchInvoiceFilter() {
    if (this.invoiceSearchForm.valid){
    let invoiceFilterValues = this.getInvoiceSearchPayload(this.invoiceSearchForm.value);
    return this.getCPList(invoiceFilterValues);
    // this._secondarySalesService.listInvoices(invoiceFilterValues, (res) => {
    //   this.gridApi.setRowData(res);
    //   this.gridData = res;
    //   this.gridApi.paginationGoToFirstPage();
    // },
    //   (error) => {
    //     this.gridApi.setRowData([])
    //   }
    // ); 
    }
  }

  cancelFilter(){
    this.invoiceSearchForm.reset();
    this.invoiceSearchForm.get('from_date').setValue(this._momentService.deceedDate(new Date(),31));
    this.invoiceSearchForm.get('to_date').setValue(new Date())
    this.getSecondaryInvoices();

  }

  getInvoiceSearchPayload(invoiceFilterValues) {
    let data = {};
    data['from_date'] = invoiceFilterValues.from_date ? this._momentService.getFilterFormat(invoiceFilterValues.from_date) : '';
    data['to_date'] = invoiceFilterValues.to_date ? this._momentService.getFilterFormat(invoiceFilterValues.to_date, "toDate") : '';
    data['invoiceNumber'] = invoiceFilterValues.invoiceNumber ? invoiceFilterValues.invoiceNumber : '';
    data['custNumber'] = invoiceFilterValues.custNumber ? invoiceFilterValues.custNumber.custNumber : '';
    data['orderNumber'] = invoiceFilterValues.orderNumber ? invoiceFilterValues.orderNumber : '';
    data['partNumber'] =invoiceFilterValues.partNumber ? invoiceFilterValues.partNumber.partNumber : '';
    data['OTLNumber'] = invoiceFilterValues.OTLNumber ? invoiceFilterValues.OTLNumber.OTLnumber : '';
    data['cpNumber'] = invoiceFilterValues.cpNumber ? invoiceFilterValues.cpNumber.cpnumber : '';
    data['invoice_type']= invoiceFilterValues.invoice_type ? invoiceFilterValues.invoice_type.value : '';


    return data;
  }

  exportSecondaryInvoice() {
    let invoiceFilterValues = this.getInvoiceSearchPayload(this.invoiceSearchForm.value);
    // invoiceFilterValues['from_date'] = invoiceFilterValues['from_date'] ?  invoiceFilterValues['from_date'] : this._momentService.getFilterFormat(this._momentService.deceedDate(new Date(),90));
    // invoiceFilterValues['to_date'] =  invoiceFilterValues['to_date'] ?  invoiceFilterValues['to_date'] : this._momentService.getFilterFormat(new Date(),"toDate");
    this._secondarySalesService.exportSecondaryInvoiceFilter(invoiceFilterValues);
  }
  RoundOFTwoDigit(num: any){
    var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
    return number;
  }

  setInvoiceList(){
    this._secondarySalesService.getInvoiceType(response=>{
      this.invoice_typeList = response;
    })
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecondaryInvoiceDetailsComponent } from './secondary-invoice-details.component';

describe('SecondaryInvoiceDetailsComponent', () => {
  let component: SecondaryInvoiceDetailsComponent;
  let fixture: ComponentFixture<SecondaryInvoiceDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecondaryInvoiceDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecondaryInvoiceDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-secondary-invoice',
  templateUrl: './secondary-invoice.component.html',
  styleUrls: ['./secondary-invoice.component.css']
})
export class SecondaryInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecondaryInvoiceAddComponent } from './secondary-invoice-add.component';

describe('SecondaryInvoiceAddComponent', () => {
  let component: SecondaryInvoiceAddComponent;
  let fixture: ComponentFixture<SecondaryInvoiceAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecondaryInvoiceAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecondaryInvoiceAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

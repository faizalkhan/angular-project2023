import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { MomentService } from 'src/app/core/services/utils/moment.service';

import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { MatDialog } from '@angular/material';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { LocationService } from 'src/app/core/services/utils/location.service';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { InputDialogService } from 'src/app/core/modules/shared/components/input-dialog/input-dialog.service';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { Roles } from 'src/app/modules/auth/model/user';
import { SHIPPING, ErrorMessage, colorCodes, BILL_TO, SHIP_TO, BILLING, ActionItems, SuccessMessage } from 'src/app/core/services/constants';
import { ListShippingAddress, AddShippingDialog, AddPartsDialog, DcToInvoicePartsDialog,  AddStockSwapTransfer, BackTopartsDialog, TaxValueFreeDialog, EditCPRT, CPRTBILLING } from '../../../dialogs/secondary-dialog/dialog.component';

@Component({
  selector: 'app-secondary-invoice-edit',
  templateUrl: './secondary-invoice-edit.component.html',
  styleUrls: ['./secondary-invoice-edit.component.css']
})
export class SecondaryInvoiceEditComponent implements OnInit {
  public displayClientKeys = ['name','address','city','pincode']
  public currentDate = new Date();
  public invoiceId;
  public clientInvoiceForm: FormGroup;
  public clientNames = []; 
  public otlList = [];
  public clientNumber;
  public otlPartsList = []; // for OTL parts list 
  public partsData = [];
  public shipDetails; // current shipping address
  public billingDetails;//current billing address
  public netAmount = 0;
  public totalTax = 0;
  public iGst:boolean;
  public invoiceData; // to store the initial invoice records 
  public packageAmount = 0;
  public calculatedDiscount = 0;
  public partsCurrentOptions = [];
  public viewInvoice = false;

  public  regionFromService=[];
  public cpAddress ; // set cp address details 
  public cpSiteIdList = []; //store  cp address list 
  public cpAccountDetails ;
  public cessAmount=0;
  public tcsAmount =0;


  public role;
  public accessControls = [];
  // for edit Purpose;
  public bill_to_id ; 
  public ship_to_id;
  public cp_invoice_id;// to map invoice address,  in shipping and billing thru cp_invoice
  public isAdmin = false;
  public TransferValue: any;
  public login_cpNumber: any;
  public invoice_type: boolean = false;
  public CPRTList = [];
  public new_CPRT: boolean= false;
  constructor(private fb: FormBuilder,public _dialog: MatDialog, private _bookingService: CpbookingService, 
    private _locationService: LocationService, public _swapdialog: MatDialog, public _backTopartsDialog: MatDialog,
    public cprt_dialog: MatDialog, public cprt_tax_dialog: MatDialog, public cprt_edit_dialog: MatDialog,
    public route: ActivatedRoute, private _secondarySalesService: SecondarysalesService,private _storageService: StorageService,private _snackBar :SnackbarService,public _inputDialogService : InputDialogService ,
    private _momentService: MomentService, private _formValidator: FormValidatorService,public invoice_tax_dialog: MatDialog) { }
    ngOnInit() {
      
      this._bookingService.getActionPermission({model : 'cpinvoice'}, response =>{
        if (!response['cpinvoice'] || !response['cpinvoice'][ActionItems['EDIT']])this.cancel();
      })
      this.loadInvoiceForm();
      // PERMISSION access control for edit invoice 
      this.getInvoicePermissionAccessControl()
    
      // get roles 
      this.role = this._storageService.getUserDetails()['role'];
      this.isAdmin = this.role ==Roles.Admin;
      this.route.paramMap.subscribe((params: ParamMap) => {
        this.invoiceId = parseInt(params.get('id'));
      });
      this._secondarySalesService.cpModuleAccess(res => {
        this.login_cpNumber = res['cpnumber'];
  });
      // get invoice data 
      this._secondarySalesService.viewInvoice(this.invoiceId,
        (response) => {
          this.invoiceData = response;
          if(this.invoiceData['invoice_type'] == 'cprt'){
            this.invoice_type = true;
          }else{
            this.invoice_type = false;
          }
         // this.invoice_type = this.invoiceData['invoice_type'];

          // invoice can't editable for channel partner
          if (!response['isEditable'] && this.role != Roles.Admin)this.cancel();
           // get hospital list 
           this.getHospitals();
        },
        (error) => console.log(error))

        
        // getting region ,state and city 
        this._locationService.getLocationData((locationData) => {
          this.regionFromService = locationData
        });
          // Calculate package Amount
        this.clientInvoiceForm.get('packageAmount').valueChanges.subscribe((response) => { 
          this.packageAmount = Number(response);
        });
        //Calculate cess Amount
        this.clientInvoiceForm.get('cess_amount').valueChanges.subscribe((response) => { 
          this.cessAmount = Number(response);
          this.calculateDiscount();
        });
        //Calculate tcs Amount
        this.clientInvoiceForm.get('tcs').valueChanges.subscribe((response) => { 
          this.tcsAmount = Number(response);
          this.calculateDiscount();
        });
        //Calculate Discount value when discount value changes
        this.clientInvoiceForm.get('discount_value').valueChanges.subscribe((response) => { 
          this.calculateDiscount();
        });

        //Calculate discount when discount type changes
        this.clientInvoiceForm.get('discount_type').valueChanges.subscribe((response) => { 
          
          this.clientInvoiceForm.get('discount_value').reset();
          if (response == 0) {
            this.clientInvoiceForm.get('discount_value').setValidators([this._formValidator.noDecimalsValidation,this._formValidator.maxEqualLength(99)])
            this.clientInvoiceForm.get('discount_value').enable()
          }
          else if (response == 1) {
            this.clientInvoiceForm.get('discount_value').setValidators([this._formValidator.noDecimalsValidation, this._formValidator.maxLength(this.netAmount -1)])
            this.clientInvoiceForm.get('discount_value').enable()
          }
          else this.clientInvoiceForm.get('discount_value').disable();
        });

    }
  
    getHospitals(){
      this._bookingService.getDistinctHospitals({order_by:"name", model:"secondary",cpnumber : this.invoiceData.cpNumber},(response => {
        this.clientNames = response;
        this.setInvoice(this.invoiceData);
       }));
    }
    
    getInvoicePermissionAccessControl(){
        this._bookingService.getPermissionAccessControls({module : 'Invoice_Edit'}, response =>{
            this.accessControls = response.field_permission;
            if (!response.parent_permission[0].is_allowed &&  this.role != Roles.Admin)this.cancel();
            if (this.role == Roles.Channel_Partner &&  response.field_permission.length){
              this.getEditInvoiceAccessControl();
            }
           
        })
    }
    
    getEditInvoiceAccessControl(){
      this.accessControls.map((editControl) => {
        if (typeof this.clientInvoiceForm.controls[editControl.name] !== 'undefined'){
           if ( editControl['is_allowed'] ) {
            this.clientInvoiceForm.controls[editControl.name].enable();
           }
           else this.clientInvoiceForm.controls[editControl.name].disable();
         }else if (editControl.name == 'discount'){
            if (editControl['is_allowed']) {
              this.clientInvoiceForm.get('discount_type').enable();
              this.clientInvoiceForm.get('discount_value').enable();
            }else{
              this.clientInvoiceForm.get('discount_type').disable();
              this.clientInvoiceForm.get('discount_value').disable();
            }
         }  else if (editControl.name == 'cess'){ 
              if (editControl['is_allowed'])  this.clientInvoiceForm.get('cess_amount').enable();
              else this.clientInvoiceForm.get('cess_amount').disable();
         }
       });
    }

    checkEditAccess(fieldName){
      if (this.role == Roles.Channel_Partner){
        let control  = this.accessControls.find(response => response['name'] == fieldName);
        if (control ){
         return  control['is_allowed'] ;
        }
      }else 
      return true;
    }

    loadInvoiceForm() { 
      this.clientInvoiceForm = this.fb.group({
        custName: [ '', [Validators.required, this._formValidator.requireMatch]],
        custNumber: [{value : '' , disabled : true }, Validators.required],
        orderNumber: [''],
        orderDate: [''],
        site_id: [{value : '' , disabled : true }, Validators.required],
        deliveryNote: [''],
        dispatchThrough: [''],
        dispatchDocNo: [''],
        dispatchDocDate: [''],
        referenceNumber: [''],
        destination: [''],
        bankDetails:  [''],
        packageAmount: ['0'],
        discount_type: ['2'  ],
        discount_value: ['0'],
        waybillDate: ['' ],
        waybillNumber: [''],
        deliveryNoteDate : [''],
        invoiceDate : [ new Date(), Validators.required],
        supplierRef : [''], 
        supplierRefDate: ['', Validators.required],
        termsOfPayment: [''],
        remarks:[''],
        otherRef: [''],
        tcs:['0',this._formValidator.withZeroAndNegativeValidation],
        cess_amount :['0', this._formValidator.withZeroAndNegativeValidation],
        accountName :[''],
        accountNumber:[''],
        website:[''],
        ifscCode:[''],
        email:[''],
        gst:[''],
        pan:['']
      });
    }
    setInvoice(response){
      this.getCustName(response.custNumber, response.siteId ,response.OTLNumber, response.parts);
      this.bill_to_id = this.invoiceData.address.find(address => address['type'] ==BILLING)['id']
      this.ship_to_id = this.invoiceData.address.find(address => address['type'] ==SHIPPING)['id'];
      this.cp_invoice_id = this.invoiceData.address.find(address => address['type'] ==SHIPPING)['cp_invoice'];
      if(this.invoice_type){
        this.CPRTList = response.parts;
      }else{
      this.partsData = response.parts;
      }
      this.setInvoiceForm(response);
      
    }

    setInvoiceForm(response){
      this.billingDetails = this.invoiceData.address.find(address => address.type == BILLING );
      this.shipDetails = this.invoiceData.address.find(address => address.type == SHIPPING );
      this.clientInvoiceForm.patchValue({
          orderNumber: response.orderNumber,
          orderDate: response.orderDate,
          deliveryNote:response.deliveryNote,
          dispatchThrough: response.dispatchThrough,
          dispatchDocNo: response.dispatchDocNo,
          dispatchDocDate: response.dispatchDocDate,
          referenceNumber: response.referenceNumber,
          destination: response.destination,
          bankDetails: response.bankDetails ,
          packageAmount: response.packageAmount,
          discount_type: response.discount_type.toString(),
          discount_value: response.discount_value,
          waybillDate: response.waybillDate,
          waybillNumber: response.waybillNumber,
          deliveryNoteDate: response.deliveryNoteDate,
          invoiceDate: response.invoiceDate,
          supplierRef: response.supplierRef,
          supplierRefDate: response.supplierRefDate,
          termsOfPayment: response.termsOfPayment,
          remarks: response.remarks,
          otherRef:response.otherRef,
          tcs: response.tcs,
          cess_amount:response.cess_amount,
          accountName :response.accountName,
          accountNumber:response.accountNumber,
          website:response.website,
          ifscCode:response.ifscCode,
          email:response.email,
          gst:response.gstNumber,
          pan:response.panNumber,
      })
      if(this.invoiceData['invoice_type'] == 'cprt'){
        this.CPRTList = this.invoiceData['parts'].map(part=>{
          let total_amount = this.RoundOFTwoDigit(part['total_amount']);
          let hsntax = part['HSSNtax'];
          part['igst']= this.RoundOFTwoDigit((total_amount * hsntax)/100);
          part['cgst']=this.RoundOFTwoDigit((total_amount * hsntax)/200);
          part['sgst']=this.RoundOFTwoDigit((total_amount *hsntax)/200);
          part['total_amount_with_tax']= this.iGst ? (total_amount + part['igst']) : (total_amount + (part['cgst'] + part['sgst'] ) )
          return part;
        })

      }
    }
    getCustName(custNumber,siteId ,otlno, parts) {
      let details;
      details = this.clientNames.find((res) =>res.custNumber == custNumber && res.site_id == siteId)
      this.clientInvoiceForm.get('custName').setValue(details);
      this.onClientChange(details ? details : '', otlno, parts);
    }
    // autocomplte fields 
    onClientChange(value, otlNo?: any, partsData?: any) {
      this.clearDataOnClientChange();
      if (value) { 
        // to set bill to and ship to address 
       
        this.getChannelPartnerSiteAddress(value);
        this.clientInvoiceForm.get('custNumber').setValue(value.custNumber);
        this.clientInvoiceForm.get('site_id').setValue(value.site_id);
        this._bookingService.getOtlBySiteId({'cpnumber' : this.invoiceData.cpNumber, "custNumber":value.custNumber, "order_by":"otl_number" }, (response) => {
          this.otlList = response;
          if (!response.length)  this._snackBar.loadSnackBar(ErrorMessage.NO_OTLNUMBER_STOCK, colorCodes.ERROR);

          if (!this.clientInvoiceForm.get('custName').touched || (value.custNumber == this.invoiceData.custNumber && value.site_id == this.invoiceData.siteId)) {
                this.partsData =  JSON.parse(JSON.stringify(this.invoiceData.parts))
                if (value.custNumber == this.invoiceData.custNumber && value.site_id == this.invoiceData.siteId) {
                  this.setInvoiceForm(this.invoiceData);
                }
                this.reCalculateTax();
                this.loadPartsTable(this.partsData);
                this.calculateDiscount();
          }else{
            this.billingDetails = value['edit_bill_to'];
            this.shipDetails = value['edit_ship_to'];
            this.clientInvoiceForm.get('discount_value').setValue('')
            this.clientInvoiceForm.get('discount_type').setValue('2')
          }
          this.checkTax();
        });
        
      }
    }
    clearDataOnClientChange(){
      this.otlList = [];
      this.partsData =  [];
      this.CPRTList = [];
      this.netAmount =0;
      this.totalTax =0;
      this.clientInvoiceForm.patchValue({
        site_id: '',
        custNumber: '',
        tcs: '',
        packageAmount: '',
        cess_amount : '',
        discount_type : '',
        discount_value : ''
      })
    }

    // ---------------------------Address section ------------------------------------
  
       // To ser Channel partner address and store the address list 
    getChannelPartnerSiteAddress(value){
      this._secondarySalesService.getCpSiteAddress({'cust_number' :value.custNumber, cpnumber : this.invoiceData.cpNumber },response => {
        if (!this.clientInvoiceForm.get('custName').touched || (value.custNumber == this.invoiceData.custNumber && value.site_id == this.invoiceData.siteId)) { 
          this.cpAddress = response.find(address => address['cpSiteId'] ==this.invoiceData['cpSiteId'] );
        }else {
        this.cpAddress = response[0];
        }
        this.cpSiteIdList = response;
        this.checkTax();
      })
    }
    // on changing the CP address
    lisChannelPartnertAddress(){
      const dialogRef = this._dialog.open(ListShippingAddress, {
        width: '500px',
        data: {details: this.cpSiteIdList, currentAddressDetails:  this.cpAddress , type : 'Channel_Partner'}
      });
      dialogRef.afterClosed().subscribe(result => {
        // result['id'] = this.invoiceData.cpSiteAddress['id']
        if (result ) this.cpAddress = result
        this.checkTax()
        this.reCalculateTax();
      });
    }

    //  hospital bill to and ship to address 
    listClientAddress(addressType) {
      let addressList = [];
      this._secondarySalesService.getAddressList({custNumber : this.clientInvoiceForm.get('custNumber').value ,cpnumber : this.invoiceData.cpNumber} , response =>{
        if (response.length) {
        response.map(data => {
            if (data.type == addressType || data.type == "both"){
              // adding hospital address id to each address obj 
              data['address']['addressId']  = data.id;
              addressList.push( data['address']);
            }
          });
        }
        this.openClientAddressListDialog(addressType,addressList.length ? addressList : (addressType == BILL_TO ? [this.billingDetails] : [this.shipDetails]))
      })
    }

    openClientAddressListDialog(type,addressList){
      const dialogRef = this._dialog.open(ListShippingAddress, {
        width: '500px',
        data: {details: addressList, currentAddressDetails:  (type == BILL_TO ? this.billingDetails : this.shipDetails) }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result && !result['edited']) {
          result['address'] = result['addressLine']
          this.billingDetails = (type == BILL_TO) ? result : this.billingDetails;
          this.shipDetails = (type == SHIP_TO) ? result : this.shipDetails;

        }else{
          if (result) this.editClientAddress(result ,type);
        }
        this.checkTax();
        this.reCalculateTax();
        
      });
    }
    editClientAddress(data, type){
      let addressDetails ;
      if (data['addressId']){
        this._secondarySalesService.getAddressDetails(data['addressId'], response =>{
          addressDetails = response['address'];
          addressDetails['addressId'] = response['id'];
          addressDetails['type'] =type;
          this.addClientAddress(addressDetails)
        })
      }else{
        addressDetails =  type == BILL_TO ? this.billingDetails : this.shipDetails
        addressDetails['type'] =type;
        this.addClientAddress(addressDetails)
      }
      
    }
    addClientAddress(addressDetails ? :any) {
      const dialogRef = this._dialog.open(AddShippingDialog, {
        width: '500px',
        data: {custNumber: this.clientInvoiceForm.get('custNumber').value, cpnumber : this.invoiceData.cpNumber, regionFromService : this.regionFromService , address : addressDetails}
  
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) {

           this.shipDetails = (result.type == 'both' || result.type == SHIP_TO) ? result['address'] : this.shipDetails;
            this.billingDetails = (result.type == 'both' || result.type == BILL_TO) ? result['address'] : this.billingDetails;   
          this.checkTax();
          this.reCalculateTax();
        }
      });
    }

//----------------CPRT BILLING --------------

loadCPRT(){
  let dialogref = this.openCPRT();
  dialogref.afterClosed().subscribe(result =>{
   if(result['CPRT']){
     this.new_CPRT = true;
    // this.isCPRT = result['CPRT']
    result['value'].forEach(item=>{

      let object={
        'test_name':item['test_name'],
        'HSSNcode':item['hsn'],
        'quantity':item['no_of_tests'],
        'price':item['cost_per_test'],
        'total_amount':item['cost_per_test'] * item['no_of_tests'],
        'total_amount_with_tax':item['cost_per_test'] * item['no_of_tests'],
        'HSSNtax':0,
        'cgst':0,
        'igst':0,
        'sgst':0

      }
      object['newparts'] = true;
        
      this.CPRTList.push(object);
      this.loadCPRT_list(this.CPRTList);
    })
   }
  })

}

editCPRTTax(index:any){
  let dialogRef = this.openTaxCPRT(this.CPRTList[index], index);
  dialogRef.afterClosed().subscribe(result=>{
    if(result>=0){
      this.CPRTList[index]['HSSNtax'] = result;
      this.CPRTList[index]['igst']= this.RoundOFTwoDigit((this.CPRTList[index]['total_amount'] *this.CPRTList[index]['HSSNtax'])/100);
      this.CPRTList[index]['cgst']=this.RoundOFTwoDigit((this.CPRTList[index]['total_amount'] *this.CPRTList[index]['HSSNtax'])/200);
      this.CPRTList[index]['sgst']=this.RoundOFTwoDigit((this.CPRTList[index]['total_amount'] *this.CPRTList[index]['HSSNtax'])/200);
      this.CPRTList[index]['total_amount_with_tax']= this.RoundOFTwoDigit(this.iGst ? (this.CPRTList[index]['total_amount'] + this.CPRTList[index]['igst']) : (this.CPRTList[index]['total_amount'] + (this.CPRTList[index]['cgst'] + this.CPRTList[index]['sgst'] ) ))
      this.loadCPRT_list(this.CPRTList);
    }
  })

}
editCPRT(index:any){
  let dialogref = this.openEditCPRT(this.CPRTList[index], index);
  dialogref.afterClosed().subscribe(result=>{
    if(result){
      this.CPRTList[index]['HSSNcode'] = result['hsn'];
      this.CPRTList[index]['test_name'] = result['desc'];
      this.CPRTList[index]['quantity'] = result['no_of_tests'];
      this.CPRTList[index]['price'] = result['cost_per_tests'];
      this.CPRTList[index]['total_amount'] =this.RoundOFTwoDigit(this.CPRTList[index]['quantity']*this.CPRTList[index]['price']);
      this.CPRTList[index]['igst']= this.RoundOFTwoDigit((this.CPRTList[index]['total_amount'] *this.CPRTList[index]['HSSNtax'])/100);
      this.CPRTList[index]['cgst']=this.RoundOFTwoDigit((this.CPRTList[index]['total_amount'] *this.CPRTList[index]['HSSNtax'])/200);
      this.CPRTList[index]['sgst']=this.RoundOFTwoDigit((this.CPRTList[index]['total_amount'] *this.CPRTList[index]['HSSNtax'])/200);
      this.CPRTList[index]['total_amount_with_tax']= this.iGst ? (this.CPRTList[index]['total_amount'] + this.CPRTList[index]['igst']) : (this.CPRTList[index]['total_amount'] + (this.CPRTList[index]['cgst'] + this.CPRTList[index]['sgst'] ) )
      this.loadCPRT_list(this.CPRTList);
    }
   })
}
deleteCPRT(index:any){
  this.CPRTList.splice(index,1);
  this.loadCPRT_list(this.CPRTList);
}
openCPRT(){
  const dialogRef =  this.cprt_dialog.open(CPRTBILLING, {
     autoFocus: false,
     width: '950px',
     });
   return dialogRef;
 
 }
openTaxCPRT(value, indexid){
  const dialogRef = this.cprt_tax_dialog.open(TaxValueFreeDialog,{
    autoFocus: false,
    width: '500px',
    data:{ "parts": value, "index":indexid}
  });
  return dialogRef;
}
openEditCPRT(value: any, index_id:any){
  const dialogRef = this.cprt_dialog.open(EditCPRT, {
    autoFocus:false,
    width:'750px',
    data:{'parts': value, 'index':index_id}
  });
  return dialogRef;
}

loadCPRT_list(result:any){
  if(result && this.CPRTList){
    this.netAmount= this.CPRTList.reduce((currentAmount, cprt)=>{
      return this.RoundOFTwoDigit(Number(currentAmount+ (cprt['total_amount'])))
   },0)
this.totalTax = this.CPRTList.reduce((currentAmount, cprt)=>{
    return this.RoundOFTwoDigit(Number(currentAmount+ ( this.iGst ? cprt['igst'] : (cprt['sgst'] + cprt['cgst']))))
  },0);
 }
}
  

    // --------------------------OTl Parts and DC  section  ---------------------------
    AddParts() {
      let dialogRef = this.openPartsDialog(this.partsData);
      dialogRef.afterClosed().subscribe(result => {
        if(result && result['isswap']){
          this.TransferValue ={
            clientName: this.clientInvoiceForm.get('custName').value,
            clientNumber: this.clientInvoiceForm.get('custNumber').value,
            siteId: this.clientInvoiceForm.get('site_id').value,
            otlNumber: result.data['OTLNumber'],
            partNumber: result.data['partsList']
          }
          this.loadSwapTransfer(this.TransferValue);
      }

      else{
        if (result && Object.keys(result).length > 0) { 
          if (result['groupByParts']){
            result['groupByParts'].forEach((part,index)=>{
              part['newParts'] = true;
              let discountType = this.clientInvoiceForm.get('discount_type').value 
                let discountAmount = 0;
                if (discountType == 0 || discountType == 2){
                  discountAmount = part['total_amount'] - (( discountType ==0 ? ( part['total_amount'] * (this.clientInvoiceForm.get('discount_value').value/100)): 0 ))
                  part['cgst'] = this.RoundOFTwoDigit(Number((( discountAmount*(part.HSSNtax/2))/100)));  
                  part['sgst'] = this.RoundOFTwoDigit(Number((( discountAmount*(part.HSSNtax/2))/100))) 
                  part['igst'] =  this.RoundOFTwoDigit(Number((( discountAmount*part.HSSNtax)/100))) 
                }
              this.addPartsData(part);
            })
          }
        }
      }
      });
    }
    addPartsData(result){
      if(result.quantity) this.partsData.push(result);
      if ( this.clientInvoiceForm.get('discount_type').value == 1 ) this.calculatePartsTaxWithDiscountPrice();
      this.loadPartsTable(result);
      this.calculateDiscount();
    }
    editParts(index) {
      let value = this.partsData[index]; 
      let availableQuantity = 0;
      let availableQtyParts = [];
      this._secondarySalesService.getStock({ "OTLNumber": value.OTLNumber, cpnumber : this.invoiceData.cpNumber, "siteId":  this.clientInvoiceForm.get('site_id').value ,'custNumber' : this.clientInvoiceForm.get('custNumber').value,'partNumber': value.partNumber}, (response) => {
       //get stock avaaible qty for existed parts 
       if (!value.newParts) {
        if (this.partsData[index]['type'] == 'OTL'){
          availableQtyParts =  response.filter((part) =>( part['lotNumber'] == this.partsData[index]['lotNumber'] &&part['lotExpiryDate'] == this.partsData[index]['lotExpiryDate'] && part['unitPurchasePrice'] > 0 ))
          availableQuantity =  availableQtyParts.reduce((currentAmount, partData) => currentAmount + partData['availableQuantity'],0) ;

        }else {
          availableQtyParts =  response.filter((part) =>( part['lotNumber'] == this.partsData[index]['lotNumber']  &&part['lotExpiryDate'] == this.partsData[index]['lotExpiryDate'] && part['unitPurchasePrice'] == 0 ))
         availableQuantity = availableQtyParts.reduce((currentAmount, partData) => currentAmount + partData['availableQuantity'],0) ;
        } 
      
          this.partsData[index]['availableQuantity'] = availableQuantity 
          this.partsData[index]['edited_quantity'] = value.edited_quantity ? value.edited_quantity : value.quantity;
       }
      
        let dialogRef = this.openPartsDialog(this.partsData, this.partsData[index]);
        dialogRef.afterClosed().subscribe(result => {
          if (result ) {
   
            result['groupByParts'][0]['groupedData'] = availableQtyParts
            this.updatePartsData(result, index); 
            this.calculateDiscount()
          }
        }); 

     });
     
    }

    updatePartsData(result, partIndex) {
      let discountType = this.clientInvoiceForm.get('discount_type').value 
      let discountAmount = 0;
      // to check netamount is less than discount value  
      // if (discountValue == 1 && result['groupByParts'][0]['total_amount'] && result['groupByParts'][0]['total_amount'] < this.clientInvoiceForm.get('discount_value').value){
      //   discountAmount = result['groupByParts'][0]['total_amount']; 
      //       result['groupByParts'][0]['cgst'] = Number((( discountAmount*(result['groupByParts'][0].HSSNtax/2))/100).toFixed(2))  
      //       result['groupByParts'][0]['sgst'] = Number((( discountAmount*(result['groupByParts'][0].HSSNtax/2))/100).toFixed(2)) 
      //       result['groupByParts'][0]['igst'] =  Number((( discountAmount*result['groupByParts'][0].HSSNtax)/100).toFixed(2)) 
      //     // to update reamining parts value in parts table
      //       this.clientInvoiceForm.get('discount_type').setValue('2');
      //       this.clientInvoiceForm.get('discount_value').reset();
      //       this.calculatePartsTaxWithDiscountPrice();
      // }

        if (result['groupByParts'][0]['total_amount'])discountAmount = result['groupByParts'][0]['total_amount'] - (  ( discountType == 0? ( result['groupByParts'][0]['total_amount'] * (this.clientInvoiceForm.get('discount_value').value/100)): 0 ))
        result['groupByParts'][0]['cgst'] = this.RoundOFTwoDigit(Number((( discountAmount*(result['groupByParts'][0].HSSNtax/2))/100)))  
        result['groupByParts'][0]['sgst'] = this.RoundOFTwoDigit(Number((( discountAmount*(result['groupByParts'][0].HSSNtax/2))/100))) 
        result['groupByParts'][0]['igst'] =  this.RoundOFTwoDigit(Number((( discountAmount*result['groupByParts'][0].HSSNtax)/100))) 
      
     this.partsData[partIndex] = result['groupByParts'][0];
     if (discountType == 1) this.calculatePartsTaxWithDiscountPrice();
      this.loadPartsTable(result)
    }

    
    openPartsDialog(data, parts?: any) {
      const dialogRef = this._dialog.open(AddPartsDialog, {
        autoFocus: false,
        width: '750px',
        data: { "partsOutput": {},'cpnumber' : this.invoiceData.cpNumber,'otlList' : this.otlList, "currentPartsData": data, 
        "editParts": parts ? parts : '', "iGst" : this.iGst,  "editForm" : this.invoiceId, 
        "site_id":this.clientInvoiceForm.get('site_id').value, "isEdit":true, "LogincpNumber":this.login_cpNumber }
      });
      return dialogRef;
    }
    openSwapParts(transferData: any){
      const swap_dialogRef = this._swapdialog.open(AddStockSwapTransfer,{
        autoFocus: false,
        width: '80%',
        disableClose: true,
        data: {"partsOutput":{}, "swapData": transferData, "isSecondaryScreen": true}
      });
      return swap_dialogRef;
     }
     backToOpenParts(partsdetail: any, data:any, parts?: any){
      const parts_dialog = this._backTopartsDialog.open(BackTopartsDialog, {
        autoFocus: false,
        width: "750px",
        disableClose: true,
        data: { "partsOutput": {},"partsData": partsdetail,'cpnumber' : this.invoiceData.cpNumber,"site_id":this.clientInvoiceForm.get('site_id').value,
         "currentPartsData": data,  "editParts": parts ? parts : '', 
        "iGst" : this.iGst,  "editForm" : this.invoiceId, "isEdit":true, "LogincpNumber":this.login_cpNumber}
      });
    return parts_dialog;
   }
    loadSwapTransfer(transferValue: any){
      let swap_dialogRefe = this.openSwapParts(transferValue);
      swap_dialogRefe.afterClosed().subscribe(result =>{
     
        if(result['iscancel'] =='cancel'){
          this.loadBackToParts(result['datavalue']['swapData']);
        }else{
          if(result['isSwap'] == 'swap'){
          this.loadBackToParts(result['datavalue']['swapData']);
          }
        }
  
      })
    }
    loadBackToParts(data?: any){
      let back_to_Dialog = this.backToOpenParts(data, this.partsData);
      back_to_Dialog.afterClosed().subscribe(result =>{
        if(result && result['isswap']){
          this.TransferValue ={
            clientName: this.clientInvoiceForm.get('custName').value,
            clientNumber: this.clientInvoiceForm.get('custNumber').value,
            siteId: this.clientInvoiceForm.get('site_id').value,
            otlNumber: result.data['OTLNumber'],
            partNumber: result.data['partsList']
          }
          this.loadSwapTransfer(this.TransferValue);
      }
        else{
        if (result && Object.keys(result).length > 0) {
          // if (result['groupByParts']){
          //   // let partsQty = this.partsData.reduce((currentAmount, partData) => currentAmount + partData['quantity'],0) ; 
          //   result['groupByParts'].forEach((part,index)=>{
          //     let discountAmount =0;
          //     let discountType = this.clientInvoiceForm.get('discount_type').value 
          //     if (discountType == 0 || discountType == 2){
          //     discountAmount = part['total_amount'] - (( discountType ==0 ? ( part['total_amount'] * (this.clientInvoiceForm.get('discount_value').value/100)): 0 ))
          //     part['cgst'] = Number((( discountAmount*(part.HSSNtax/2))/100).toFixed(2))  
          //     part['sgst'] = Number((( discountAmount*(part.HSSNtax/2))/100).toFixed(2)) 
          //     part['igst'] =  Number((( discountAmount*part.HSSNtax)/100).toFixed(2)) 
          //   }
          //     this.addPartsData(part);
          //   })
          // }
          
            if (result['groupByParts']){
    result['groupByParts'].forEach((part,index)=>{
      part['newParts'] = true;
      let discountType = this.clientInvoiceForm.get('discount_type').value 
        let discountAmount = 0;
        if (discountType == 0 || discountType == 2){
          discountAmount = part['total_amount'] - (( discountType ==0 ? ( part['total_amount'] * (this.clientInvoiceForm.get('discount_value').value/100)): 0 ))
          part['cgst'] = Number((( discountAmount*(part.HSSNtax/2))/100).toFixed(2))  
          part['sgst'] = Number((( discountAmount*(part.HSSNtax/2))/100).toFixed(2)) 
          part['igst'] =  Number((( discountAmount*part.HSSNtax)/100).toFixed(2)) 
        }
      this.addPartsData(part);
    })
  }
        }
      }
      })
   }

  
    deleteParts(index) {
        this.partsData.splice(index, 1);
        if (this.clientInvoiceForm.get('discount_type').value == 1) this.calculatePartsTaxWithDiscountPrice();
        this.checkPartsDataCount();

    }
    checkPartsDataCount() {
      if (this.partsData.length > 0) this.loadPartsTable(this.partsData);
      else {
        this.netAmount = 0;
        this.totalTax = 0;
        this.clientInvoiceForm.get('discount_value').setValue('')
        this.clientInvoiceForm.get('discount_type').setValue('2')
      }
      this.calculateDiscount();

    }
 
    //------------------------------- Start - converting DC to Invoice --------------------------------
loadDcToInvoice(){
  this._secondarySalesService.getDcList({custNumber :  this.clientInvoiceForm.get('custNumber').value}, (response) => {
    // to check if the dcnumber is already exist 
    if (!response.length)this._snackBar.loadSnackBar('There is no DC raised for  selected client', colorCodes.ERROR );
    else this.openDcListDialog(response)
  }); 
}
openDcListDialog(response){
  let dialogRef = this.openDcDialog(response,'DC_LIST');
    dialogRef.afterClosed().subscribe(result => { 
      if (result){
                this._secondarySalesService.getDcParts({'dcId' : result},
                  (response) => {
                    response =   response.filter(res=> !this.partsData.some(part => (part['dcNumber'] == res['dcNumber'] && part['type'] == res['type'] &&  part['partNumber'] == res['partNumber'])));
                    if (response.length) {
                    let dcParts = response.map((part, index) =>{
                      part['groupedData'] = part['part'];
                      part['quantity'] = part['quantity'] > part['invoicedQuantity']  ? part['quantity'] - part['invoicedQuantity'] :  part['invoicedQuantity'] - part['quantity']
                      part['total_amount'] = this.RoundOFTwoDigit(Number((part.price *  part['quantity'])));    
                    // calculate discount field 
                      let discountType = this.clientInvoiceForm.get('discount_type').value 
                      let discountAmount = 0
                      if (discountType == 0 || discountType == 2){
                        if (part['total_amount'])discountAmount= (  ( discountType ==0 ? part['total_amount'] - ( part['total_amount'] * (this.clientInvoiceForm.get('discount_value').value/100)): part['total_amount'] ))
                        part['cgst'] = this.RoundOFTwoDigit(Number((( discountAmount*(part.HSSNtax/2))/100)))  
                        part['sgst'] = this.RoundOFTwoDigit(Number((( discountAmount*(part.HSSNtax/2))/100))) 
                        part['igst'] =  this.RoundOFTwoDigit(Number((( discountAmount*part.HSSNtax)/100))) 
                      }
                        part['newParts'] = true;
                        delete part['part'];
                        return part;
                      })
                      this.partsData = this.partsData.concat(dcParts);
                      if (this.clientInvoiceForm.get('discount_type').value  == 1) this.calculatePartsTaxWithDiscountPrice();
                      this.loadPartsTable(result);
                      this.calculateDiscount();
                    }
                  })
      }
    })

}
openDcDialog(response,type){
  const dialogRef =  this._dialog.open(DcToInvoicePartsDialog, {
    autoFocus: false,
    width: '950px',
    data: { "parts": response, 'type' : type,'siteId' : this.clientInvoiceForm.get('site_id').value,'custNumber' :  this.clientInvoiceForm.get('custNumber').value}
    });
  return dialogRef;
}

editDCParts(index){
  if (this.partsData[index]['newParts'] == true){
     // to maintain dcparts orginal quantity, when the quantity is editing
  this.partsData[index]['originalQty'] = this.partsData[index]['originalQty']  ? this.partsData[index]['originalQty'] : this.partsData[index]['quantity'];
  this.getDcGroupedParts(index,'editDC');
  }else{
    this.partsData[index]['originalQty'] = this.partsData[index]['dcQuantity'];
    this.partsData[index]['invoicedQuantity'] = this.partsData[index]['quantity'];
    this.partsData[index]['edited_quantity'] =this.partsData[index]['edited_quantity'] ? this.partsData[index]['edited_quantity']  :this.partsData[index]['quantity'];
    this.partsData[index]['newParts'] = false;
    this.getDcGroupedParts(index,'editDC');
  }
 
  
 
}
getDcGroupedParts (index,params?:any){
  let payload = {
    'OTLNumber' : this.partsData[index]['OTLNumber'],
    'partNumber' : this.partsData[index]['partNumber'],
    'lotNumber' : this.partsData[index]['lotNumber'],'lotExpiryDate' : this.partsData[index]['lotExpiryDate'],
    'dcNumber' : this.partsData[index]['dcNumber'],'type' : this.partsData[index]['type'],
    'ungroup_parts':true
  }
  this._secondarySalesService.getDcParts(payload, response =>{
    // when parts ordered qty is zero and response is empty 
    if (params && this.partsData[index]['quantity'] == 0 && !response.length ){
      this._snackBar.loadSnackBar( "Part - " +this.partsData[index]['partNumber'] + " " +ErrorMessage.ALREADY_INVOICED_UNABLE_TO_EDIT_DC, colorCodes.ERROR)
    }else if (!params) {
      // for retrigger
      this.partsData[index]['groupedData'] =  response;
    }else{
      this.openEditDcDialog(index);
      this.partsData[index]['groupedData'] =  response;
    }
    
  })
}
openEditDcDialog(index){
  let dialogRef = this.openDcDialog(this.partsData[index],'EDIT_DC_LIST');
  dialogRef.afterClosed().subscribe(result => { 
    if (result){
      if (this.partsData[index]['newParts']) {
        this.partsData[index]['quantity'] = result['quantity']
        this.partsData[index]['total_amount'] = this.RoundOFTwoDigit(Number((this.partsData[index].price *  this.partsData[index]['quantity'])));    
      }else{
        this.partsData[index]['edited_quantity'] = result['quantity']
        this.partsData[index]['total_amount'] = this.RoundOFTwoDigit(Number((this.partsData[index].price *  this.partsData[index]['edited_quantity'])));    
        this._snackBar.loadSnackBar(SuccessMessage.STOCKS_REVERTED_TO_DC_AGAIN,colorCodes.SUCCESS)
      }
      
      let discountValue = this.clientInvoiceForm.get('discount_type').value 
      let discountAmount =0;
      
      if (discountValue == 0 && discountValue == 2){ 
        if(this.partsData[index]['total_amount'] ) discountAmount =( ( discountValue ==0? this.partsData[index]['total_amount'] - ( this.partsData[index]['total_amount'] * (this.clientInvoiceForm.get('discount_value').value/100)):  this.partsData[index]['total_amount']))
        this.calculateSinglePart(index ,  discountAmount)
      }else{
        this.calculatePartsTaxWithDiscountPrice();
      }

      this.loadPartsTable(result);
      this.calculateDiscount();
      
    }
  })
}
//-------------------------------------- End- converting DC to Invoice ------------------
//-------------Price and tax calculation ------------
loadPartsTable(result, onInitalLoad?:any) {
  if (result && this.partsData) {
    this.netAmount= this.partsData.reduce((currentAmount, part)=>{
      return this.RoundOFTwoDigit(Number((currentAmount+ part['total_amount'])))
    },0)
    this.getTotalTax();

    // couldn't earse the discount value on inital laod 
    // if ((!onInitalLoad && this.clientInvoiceForm.get('site_id').value  !=  this.invoiceData.siteId && this.clientInvoiceForm.get('custNumber').value !=this.invoiceData.custNumber) ||!this.enableDiscountField() ){
     if (!this.enableDiscountField() || this.netAmount == 0){
        this.clientInvoiceForm.get('discount_value').setValue('')
        this.clientInvoiceForm.get('discount_type').setValue('2')
        if (!this.enableDiscountField()) this.discountFocusOut(2);
    }
    if (this.clientInvoiceForm.get('discount_type').value == 1)  this.clientInvoiceForm.get('discount_value').setValidators([this._formValidator.noDecimalsValidation, this._formValidator.maxEqualLength(this.netAmount - 1) ])
  }
}
getTotalTax(){
  this.totalTax = this.partsData.reduce((currentAmount, part)=>{
    var x = this.RoundOFTwoDigit(Number((currentAmount+ (this.iGst ? part['igst'] : (part['sgst'] + part['cgst'])))))
    return x;
  },0);
}
discountFocusOut(value){
  if (this.clientInvoiceForm.get('discount_type').value == 0) this.calculatePartsTaxWithDiscountPercentage();
  else if (this.clientInvoiceForm.get('discount_type').value == 1) this.calculatePartsTaxWithDiscountPrice();
  else this.calculatedPartsTaxWithoutDiscount();
}
// tax should be caluclate after netamount is minus by discount amount  price

calculatePartsTaxWithDiscountPrice(){
let partsQty = this.partsData.reduce((currentAmount, partData) => currentAmount + (partData.newParts&&partData.price ? partData.quantity : (partData.edited_quantity >=0&&partData.price  ? partData.edited_quantity :(partData.price ?  partData['quantity'] : 0) ))  ,0) ;
let singlePartDiscountAmt = this.clientInvoiceForm.get('discount_value').value / partsQty;

this.partsData.map((part,index) => {
      let discountAmount = part['total_amount']  ? part['total_amount']  - (singlePartDiscountAmt * (part.newParts ? part.quantity : (part.edited_quantity >=0  ? part.edited_quantity : part['quantity'])) ) : 0; 
      if (discountAmount < 0) {
        this.clientInvoiceForm.get('discount_type').setValue('2');
        this.clientInvoiceForm.get('discount_value').reset();
        this.calculatePartsTaxWithDiscountPrice();
      }else {
      this.calculateSinglePart(index , discountAmount);
      }
      return part;
})
this.getTotalTax();

}

// tax should be caluclate after netamount is minus by discount amount  percentage
calculatePartsTaxWithDiscountPercentage(){
      this.partsData.map((part,index) => {
          let netAmount = part['total_amount']
           this.calculateSinglePart(index , (netAmount - (netAmount * (this.clientInvoiceForm.get('discount_value').value/100))));
          return part;
    })
    this.getTotalTax();

}
calculatedPartsTaxWithoutDiscount(){
this.partsData.map((part,index) => {
   this.calculateSinglePart(index ,part['total_amount']);
  return part;
})
this.getTotalTax();
}
calculateSinglePart(index, discountAmount){
  this.partsData[index]['cgst'] = discountAmount ?  this.RoundOFTwoDigit(Number((( discountAmount*(this.partsData[index].HSSNtax/2))/100)))   : 0
   this.partsData[index]['sgst'] = discountAmount ?  this.RoundOFTwoDigit(Number((( discountAmount*(this.partsData[index].HSSNtax/2))/100))) : 0
   this.partsData[index]['igst'] =  discountAmount ?  this.RoundOFTwoDigit(Number((( discountAmount*this.partsData[index].HSSNtax)/100))) : 0
}
// when changing address;
reCalculateTax(){
  let discountType = this.clientInvoiceForm.get('discount_type').value;
  if (discountType == 0 || discountType == 2){
    this.partsData =  this.partsData.map(part =>{
      let discountAmount = 0;
      if (part['total_amount'])  discountAmount = part['total_amount'] - ( discountType == 0? ( part['total_amount'] * (this.clientInvoiceForm.get('discount_value').value/100)): 0 )
      part['cgst'] = this.RoundOFTwoDigit(Number((( discountAmount*(part.HSSNtax/2))/100)))  
      part['sgst'] = this.RoundOFTwoDigit(Number((( discountAmount*(part.HSSNtax/2))/100))) 
      part['igst'] =  this.RoundOFTwoDigit(Number((( discountAmount*part.HSSNtax)/100))) 
        return part;
      })
  }else{
    this.calculatePartsTaxWithDiscountPrice()
  }
  
}
    checkTax() {
      if(this.cpAddress && (this.billingDetails['state'].toLowerCase().replace(/\s/g,'') == this.cpAddress.cpSiteAddress['state'].toLowerCase().replace(/\s/g,''))) {
        this.iGst = false;
      }
      else {
        this.iGst = true;
      }
      
    }
    // ---------------discount calculation -------------
    calculateDiscount() {
      if(this.clientInvoiceForm.get('discount_type').value && this.clientInvoiceForm.get('discount_value').value)
      {
         if(this.clientInvoiceForm.get('discount_type').value === '0') this.calculatedDiscount = this.RoundOFTwoDigit(Number(((this.netAmount) * (this.clientInvoiceForm.get('discount_value').value/100)))); 
         if(this.clientInvoiceForm.get('discount_type').value === '1') this.calculatedDiscount = this.clientInvoiceForm.get('discount_value').value; 
     }
     else {
         this.calculatedDiscount = 0;
     }
     }
   
     enableDiscountField(){
       
       return this.partsData.every(res => res['partNumber'] == this.partsData[0]['partNumber'] && res['OTLNumber'] == this.partsData[0]['OTLNumber'] );
     }
    //// ---reset ,cancel, view and update page ----------
    viewInvoiceDetails(status){
      this.viewInvoice= status 
  
    }

 
    reset(){
      this.partsData = [];
      this.setInvoice(this.invoiceData);
    }
    resetCPRT(){
      this.CPRTList = [];
      this._secondarySalesService.viewInvoice(this.invoiceId,
        (response) => {
          this.invoiceData = response;
          this.setInvoice(this.invoiceData);
        },
        (error) => console.log(error))

    
     
    }
    retriggerParts(fieldName, index?:any){
        let payload = {
          field : fieldName 
        }
        if (typeof index == 'undefined')
          payload['invoice_id']  = this.invoiceData.id
        else 
        payload['invoice_part_id']  = this.partsData[index]['part'][0].id
 
        this._secondarySalesService.retriggerInvoice(payload, response=>{
            // if (typeof index != 'undefined' &&this.partsData[index]['type'] == 'OTL'){
            if (typeof index != 'undefined'){
              let part = this.partsData[index];
              if (typeof this.partsData[index]['edited_quantity'] == 'undefined')  this.addRetriggerFlag(index);
              this.partsData[index]['price']  = typeof response.price !== 'undefined' ? response.price :this.partsData[index]['price']
              this.partsData[index]['HSSNtax']  = typeof response.tax !== 'undefined'? response.tax :this.partsData[index]['HSSNtax']
                let quantity = typeof this.partsData[index]['edited_quantity'] != 'undefined' ?  part['edited_quantity'] :  part['quantity']
                  part['total_amount'] =this.RoundOFTwoDigit(Number((part['price'] * quantity ))) ; 
                  let discountValue = this.clientInvoiceForm.get('discount_type').value;
                  let discountAmount = 0;
                  if (discountValue == 1 ){ 
                    // to update reamining parts value in parts table
                    // discountAmount = this.partsData[index]['total_amount'] ;
                    // this.calculateSinglePart(index ,  discountAmount)
                    // this.clientInvoiceForm.get('discount_type').setValue('2');
                    // this.clientInvoiceForm.get('discount_value').reset();
                    this.calculatePartsTaxWithDiscountPrice();
                  }else{
                    if (this.partsData[index]['total_amount'] ) discountAmount =(discountValue == 1 ? (this.partsData[index]['total_amount'] - this.clientInvoiceForm.get('discount_value').value) : ( discountValue ==0? this.partsData[index]['total_amount'] - ( this.partsData[index]['total_amount'] * (this.clientInvoiceForm.get('discount_value').value/100)):  this.partsData[index]['total_amount'])) 
                   this.calculateSinglePart(index , discountAmount)
                  }
                  this.loadPartsTable(this.partsData);
                  this.calculateDiscount();
               
              
            }

            else{
              this.clientInvoiceForm.get(fieldName).setValue(response[fieldName])
            }
        })
    } 

    addRetriggerFlag(index){
        if (this.partsData[index]['dcNumber'] ==  "" ) {
          let value =  this.partsData[index];
          this._secondarySalesService.getStock({ "OTLNumber": value.OTLNumber, cpnumber : this.invoiceData.cpNumber, "siteId":  this.clientInvoiceForm.get('site_id').value ,'custNumber' : this.clientInvoiceForm.get('custNumber').value,'partNumber': value.partNumber}, (response) => { 
            if (this.partsData[index]['type'] == 'OTL'){
              this.partsData[index]['groupedData']=  response.filter((part) =>( part['lotNumber'] == this.partsData[index]['lotNumber'] &&part['lotExpiryDate'] == this.partsData[index]['lotExpiryDate']&& part['unitPurchasePrice'] > 0 ))
    
            }else {
              this.partsData[index]['groupedData']=  response.filter((part) =>( part['lotNumber'] == this.partsData[index]['lotNumber'] &&part['lotExpiryDate'] == this.partsData[index]['lotExpiryDate'] && part['unitPurchasePrice'] == 0 ))
            } 
          })
         
         }else {
           this.getDcGroupedParts(index);
         }
         this.partsData[index]['reTrigger'] = true;
    }
     cancel(){
      this._secondarySalesService.navigateInvoiceList()
     }

     RoundOFTwoDigit(num: any){
      var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
      return number;
    }

     updateClientInvoice(){ 
      let data = this.clientInvoiceForm.getRawValue();
      data.custName = this.clientInvoiceForm.get('custName').value.name;
      data.dispatchDocDate = data.dispatchDocDate ? this._momentService.getIsoFormat(data.dispatchDocDate): null;
      data.orderDate = data.orderDate ? this._momentService.getIsoFormat(data.orderDate): null;
      data.deliveryNoteDate = data.deliveryNoteDate ? this._momentService.getIsoFormat(data.deliveryNoteDate): null;
      data.invoiceDate = data.invoiceDate ? this._momentService.getIsoFormat(data.invoiceDate): null;
      data.invoiceIdentifier = this.invoiceData ? this.invoiceData['invoiceIdentifier'] : null;
      data.waybillDate = data.waybillDate ? this._momentService.getIsoFormat(data.waybillDate): null;
      data.supplierRefDate = data.supplierRefDate ? this._momentService.getIsoFormat(data.supplierRefDate) : null;
      this.shipDetails['contactPerson']=this.shipDetails['contactperson'] ? this.shipDetails['contactperson'] :this.shipDetails['contactPerson']
      this.billingDetails['contactPerson'] =this.billingDetails['contactperson'] ?this.billingDetails['contactperson'] :this.billingDetails['contactPerson'];
     
      // to append the id and invoice id in each ship ,bill and channel partner address
       this.shipDetails['id'] = this.ship_to_id;
      this.billingDetails['id'] = this.bill_to_id;
      this.shipDetails['cp_invoice'] = this.cp_invoice_id;
      this.billingDetails['cp_invoice'] = this.cp_invoice_id
      this.cpAddress['cpSiteAddress']['id'] = this.invoiceData['cpSiteAddress']['id'];
      delete this.shipDetails['contactperson'];
      delete this.billingDetails['contactperson'];  
      data['shipping_address'] =Object.assign({}, this.shipDetails) ;
      data['shipping_address']['type'] = 'shipping'
      data['billing_address'] = Object.assign({}, this.billingDetails)  ;
      data['billing_address']['type'] = 'billing'
      data['net_amount'] = this.RoundOFTwoDigit(Number(this.netAmount));
      data['total_amount'] = this.RoundOFTwoDigit(Number(((data['net_amount'] - (this.enableDiscountField()  ? this.calculatedDiscount : 0 ))+ + this.totalTax + this.cessAmount +this.tcsAmount + this.packageAmount)));
      data['total_tax'] = this.RoundOFTwoDigit(Number(this.totalTax));
      data['gstNumber'] =this.clientInvoiceForm.get('gst').value;
      data['panNumber'] =this.clientInvoiceForm.get('pan').value;
      data['packageAmount'] = data['packageAmount'] ? data['packageAmount'] : '0';
      data['tcs'] = data['tcs'] ? data['tcs'] : '0';
      data['cess_amount'] = data['cess_amount'] ? data['cess_amount'] : '0';
      data['discount_value'] =this.netAmount &&  data['discount_value'] ? data['discount_value'] : '0';
      data['discount_type'] = this.netAmount && data['discount_type'] ? data['discount_type'] : '2';
      data['discount_amount'] = this.calculatedDiscount ? this.calculatedDiscount : '0';
      data['cpSiteAddress'] = this.cpAddress['cpSiteAddress']
      data['cpSiteId']= this.cpAddress['cpSiteId']
      data['hasDCParts']= this.partsData.find(part => part['dcNumber']) ? 1 : 0
      data['cpNumber'] = this.invoiceData.cpNumber,
      data['invoiceNumber'] = this.invoiceData.invoiceNumber;
      data['siteId'] = data.site_id
      data['id'] = this.invoiceData.id

      if(this.invoice_type){
        data.parts = this.CPRTList;
      }
      else{
      data.parts = this.partsData.filter(part =>  part['reTrigger'] || (typeof part['edited_quantity'] == 'undefined' && !part['part'] && part['quantity'] > 0 ? part['quantity'] > 0 : (part['edited_quantity']>=0 && part['groupedData'])) )
      // for retrigger options
      if (data.parts.length){
      let retriggerParts = data.parts.map(part =>{
         if (part['reTrigger'] && typeof part['edited_quantity'] == 'undefined') part['edited_quantity'] = part['quantity']
         return part;
      });
      data.parts = retriggerParts
      } 
    }
     this._secondarySalesService.editInvoice(this.invoiceId, data);

     }

     editinvoiceTax(index: any){
      let dialogRef = this.openinvoiceTax(this.partsData[index], index);
      dialogRef.afterClosed().subscribe(result=>{
        if(result>=0){
          this.partsData[index]['HSSNtax'] = result;
          this.partsData[index]['igst']= this.RoundOFTwoDigit((this.partsData[index]['total_amount'] *this.partsData[index]['HSSNtax'])/100);
          this.partsData[index]['cgst']=this.RoundOFTwoDigit((this.partsData[index]['total_amount'] *this.partsData[index]['HSSNtax'])/200);
          this.partsData[index]['sgst']=this.RoundOFTwoDigit((this.partsData[index]['total_amount'] *this.partsData[index]['HSSNtax'])/200);
          this.partsData[index]['reTrigger'] = true;
          this.loadPartsTable(this.partsData);
        }
      })
    }
    openinvoiceTax(value, indexid){
      const dialogRef = this.invoice_tax_dialog.open(TaxValueFreeDialog,{
        autoFocus: false,
        width: '500px',
        data:{ "parts": value, "index":indexid}
      });
      return dialogRef;
    }
}

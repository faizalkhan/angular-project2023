import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecondaryInvoiceEditComponent } from './secondary-invoice-edit.component';

describe('SecondaryInvoiceEditComponent', () => {
  let component: SecondaryInvoiceEditComponent;
  let fixture: ComponentFixture<SecondaryInvoiceEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecondaryInvoiceEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecondaryInvoiceEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

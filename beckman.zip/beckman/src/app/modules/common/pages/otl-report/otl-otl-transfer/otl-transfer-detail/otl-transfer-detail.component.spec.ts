import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtlTransferDetailComponent } from './otl-transfer-detail.component';

describe('OtlTransferDetailComponent', () => {
  let component: OtlTransferDetailComponent;
  let fixture: ComponentFixture<OtlTransferDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtlTransferDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtlTransferDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

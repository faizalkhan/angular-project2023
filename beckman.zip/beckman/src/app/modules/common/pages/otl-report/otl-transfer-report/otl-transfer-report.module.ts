import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { RouterModule, Routes } from '@angular/router';
import { AgGridModule } from 'ag-grid-angular';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { PipeModule } from 'src/app/core/pipe/pipe.module';
import {OtlTransferReportComponent} from './otl-transfer-report.component';

const routes: Routes = [{
  path:'', 
  component:OtlTransferReportComponent
}]

@NgModule({
  declarations: [OtlTransferReportComponent],
  imports: [
    CommonModule,
    AppMaterialModule,
    RouterModule.forChild(routes),
    AgGridModule.withComponents([]),
    CustomFormsModule,
    PipeModule
  ],
  exports :[OtlTransferReportComponent]
})
export class OtlTransferReportModule { }

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { MatDialog } from '@angular/material';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { OtlTransferService} from '../../../../service/otl-transfer/otl-transfer.service';
import { Roles } from 'src/app/modules/auth/model/user';
import { Router } from '@angular/router';
@Component({
  selector: 'app-otl-transfer-detail',
  templateUrl: './otl-transfer-detail.component.html',
  styleUrls: ['./otl-transfer-detail.component.css']
})
export class OtlTransferDetailComponent implements OnInit {


  public logId;
  public OTLData;
  public stockLogPermission;
  constructor(public route: ActivatedRoute,private _router:Router, private _bookingService: CpbookingService, private _OtlTransferService: OtlTransferService, public _StorageService: StorageService) { }

  ngOnInit() {
    this.loadStockLogPermission();
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.logId = parseInt(params.get('id'));
    });
    this.getStock();
  }
  getStock(){
    this._OtlTransferService.searchOTL("/"+this.logId, (response) => {
      this.OTLData = response;
    });
  }

  cancel(){
    let roles = this._StorageService.getUserDetails().role;
    if (roles == Roles.Admin)   this._router.navigate(['beckman/secondary-sales/otl-otl-transfer']);
    else if (roles == Roles.Channel_Partner) this._router.navigate(['/channel-partner/secondary-sales/otl-otl-transfer'])
    else this._router.navigate(['beckman-billing/secondary-sales/otl-otl-transfer']);
  }

 
 loadStockLogPermission(){
  this._bookingService.getActionPermission({model : 'otllog'}, response =>{
    this.stockLogPermission= response['otllog'];
  });
}

}
 
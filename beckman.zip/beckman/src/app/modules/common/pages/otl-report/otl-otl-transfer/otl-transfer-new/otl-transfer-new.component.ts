import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, ValidationErrors } from '@angular/forms';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { OtlTransferService } from '../../../../service/otl-transfer/otl-transfer.service';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { ActivatedRoute, Router } from '@angular/router';
import { colorCodes, ErrorMessage, ActionItems } from 'src/app/core/services/constants';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { Roles } from 'src/app/modules/auth/model/user';
@Component({
  selector: 'app-otl-transfer-new',
  templateUrl: './otl-transfer-new.component.html',
  styleUrls: ['./otl-transfer-new.component.css']
})
export class OtlTransferNewComponent implements OnInit {

  public displayClientKeys = ['name', 'address']
  public stockId;
  public otlTransferForm: FormGroup;
  public clientNames = [];
  public fromotlList = [];
  public tootlList = [];
  selectAllCheckbox = true;
  isChecked = false;
  routeName;
  urlName;
  constructor(private fb: FormBuilder, private route: ActivatedRoute, private _bookingService: CpbookingService, private _formValidator: FormValidatorService, private _secondarysalesService: SecondarysalesService,
    private _router: Router, private _snackBar: SnackbarService, private _StorageService: StorageService,
    private _OTLService: OtlTransferService
  ) { }

  ngOnInit() {

    this.checkAccessControl();
    // this.urlName = this._router.url;
    // console.log(this.route.snapshot.params);
    // this.urlName = this.urlName.split("/");
    //   this.urlName[4];
    //  console.log(this.urlName[4]);

    // this._bookingService.getActionPermission({ model: 'OTLlog' }, response => {
    //   if (!response['stocklog'] || !response['stocklog'][ActionItems['ADD_STOCK_TRANSFER']]) this.cancel();
    // })
    this.loadotlTransferForm();
    if (this._StorageService.getUserDetails().role == Roles.Channel_Partner) {
      this._secondarysalesService.cpModuleAccess(res => {
        if (res['stockTransferLock'] == 1) this._router.navigate(['/secondary-sales/otl-otl-transfer']);
      });
    }

    this._bookingService.getDistinctHospitals({ order_by: "name",otl_transfer:true }, (response => {
      this.clientNames = response
    }));
    this.getUserRole()

  }

  checkAccessControl(){
    this._bookingService.getPermissionAccessControls({module : 'OTL_TRANSFER'},response =>{
      this.urlName = response.parent_permission[0]['is_allowed'];
      this.urlName = this.urlName  ?  '' : this._router.navigate([this.routeName + '/secondary-sales/otl-otl-transfer'])

    })
  }
  getUserRole() {
    const currentUser = this._StorageService.getUserDetails();
    switch(currentUser.role) {
      case Roles.Admin:
        this.routeName = 'beckman'
        break;
      case Roles.Channel_Partner:
        this.routeName = 'channel-partner'
        break;
      case Roles.Agent:
        this.routeName = 'agent'
        break;
      
      default :
        this.routeName = 'beckman-billing'
        break;
    }

  }

  loadotlTransferForm() {
    this.otlTransferForm = this.fb.group({
      fromHospital: ['', [Validators.required, this._formValidator.requireMatch]],
      fromOtl: ['', [Validators.required, this._formValidator.requireMatch]],
      fromCustNumber: ['', Validators.required],
      fromSiteId: ['', Validators.required],
      toHospital: ['', [Validators.required, this._formValidator.requireMatch]],
      toOtl: ['', [Validators.required, this._formValidator.requireMatch]],
      toCustNumber: ['', Validators.required],
      toSiteId: ['', Validators.required],
    });
  }

  onClientChangeFrom(value) {
    this.resetParts();
    this.otlTransferForm.get('fromOtl').setValue('');
    this.fromotlList = [];
    
      this.otlTransferForm.get('fromSiteId').setValue(value.site_id);
      this.otlTransferForm.get('fromCustNumber').setValue(value.custNumber);
      this._OTLService.getOTLCP( (response) => {
        this.fromotlList = response;
      },{ "custNumber": value.custNumber, 'is_primary': true })
  }
  onClientChangeTo(value) {
    this.otlTransferForm.get('toOtl').setValue('');
    this.tootlList = [];
    
      this.otlTransferForm.get('toSiteId').setValue(value.site_id);
      this.otlTransferForm.get('toCustNumber').setValue(value.custNumber);
      this._OTLService.getOTLCP( (response) => {
        this.tootlList = response;
      },{ "custNumber": value.custNumber, 'is_primary': true })
  }
  onOtlChangeFrom(value) {
    this.otlTransferForm.get('')
    this.resetParts();
    this.otlTransferForm.get('fromSiteId').setValue(value.site_id);
    this.callingRelatedParts(value);
  }
  onOtlChangeTo(value) {
    this.otlTransferForm.get('toSiteId').setValue(value.site_id);
  }

  callingRelatedParts(value) {
    this._OTLService.getOTLParts({ custNumber: this.otlTransferForm.get('fromCustNumber').value, OTLNumber: value.OTLnumber, siteId:value.site_id }, response => {
      let filteredResponse = this.groupBySumOfProperty(response, 'OTLNumber', 'lotNumber', 'lotExpiryDate');
      this.selectAllCheckbox=true;
      this.otlTransferForm.addControl('relatedParts', this.fb.array(this.getRelatedParts(filteredResponse)));
      this.isChecked = true;
    })
  }

  setCheckBox(value){
    this.selectAllCheckbox =value;
    let parts = this.otlTransferForm.get("relatedParts") as FormArray 
    parts.controls.map(data =>{
      data.patchValue({
        checked : value,
      })
    })
    this.isChecked = value;
  }
  groupBySumOfProperty(array, key1, key2, key3) {
    let obj = {};
    return array.reduce(function (currentArray, data) {
      var key = data[key1] + '-' + data[key2] + '-' + data[key3];
      if (!obj[key]) {
        obj[key] = Object.assign({}, data);
        currentArray.push(obj[key]);
      } else {
        obj[key]['availableQuantity'] = obj[key]['availableQuantity'] + data['availableQuantity']
      }
      return currentArray;
    }, [])
  }
  onSelectCheckBox(value,index){
    if(!value)
      this.selectAllCheckbox=false      
    let arr=this.otlTransferForm.value.relatedParts;
    arr[index]['checked']=value
    let ischecked = arr.some(data =>data.checked==true)
    this.isChecked = ischecked ? true : false;  
  }
  getRelatedParts(relatedParts) {
    const data = relatedParts.map((data) => {
      return this.fb.group({
        custNumber: [data.custNumber],
        partNumber: [data.partNumber],
        OTLNumber: [data.OTLNumber],
        lotNumber: [data.lotNumber],
        lotExpiryDate: [data.lotExpiryDate],
        availableQuantity: [data.availableQuantity],
        siteId: [data.siteId],
        id: [data.id],
        description: [data.description],
        checked:[true]
      });
    });
    return data;
  }

  resetParts() {
    if (this.otlTransferForm.get('relatedParts')) this.otlTransferForm.removeControl('relatedParts');
  }

  resetStock() {
    this.resetParts();
    this.otlTransferForm.reset();
  }

  createOTLTransfer(Otl?:any) {
    let data = {};
    data['fromCustomerNumber'] = this.otlTransferForm.get('fromCustNumber').value
    data['toCustomerNumber'] = this.otlTransferForm.get('toCustNumber').value
    data['fromOTL'] = this.otlTransferForm.value.fromOtl.OTLnumber
    data['toOTL'] = this.otlTransferForm.value.toOtl.OTLnumber 
    data['fromCustomerSiteId'] = this.otlTransferForm.get('fromSiteId').value
    data['toCustomerSiteId'] = this.otlTransferForm.get('toSiteId').value
    data['type'] = "transfer"
    let array = this.otlTransferForm.value.relatedParts;
    array = array.filter(o=>o.checked)
    array = array.filter(o=>{
      if(o.checked){
        delete o.checked;
        return o;
      } })
    data['parts'] = array
    this._OTLService.createOTLTransferonSameScreen(data, () => { this._router.navigate([this.routeName+'/secondary-sales/otl-otl-transfer']); });
  }
  cancel() {this._router.navigate([this.routeName+'/secondary-sales/otl-otl-transfer']) }

}

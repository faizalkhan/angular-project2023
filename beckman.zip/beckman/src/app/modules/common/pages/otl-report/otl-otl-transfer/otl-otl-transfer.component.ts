import { Component, OnInit, ViewEncapsulation, HostListener } from '@angular/core';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { OtlTransferService} from '../../../service/otl-transfer/otl-transfer.service';
import { Roles } from 'src/app/modules/auth/model/user';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { IGetRowsParams } from 'ag-grid-community';
import { ActivatedRoute, Params, Router } from '@angular/router';
@Component({
  selector: 'app-otl-otl-transfer',
  templateUrl: './otl-otl-transfer.component.html',
  styleUrls: ['./otl-otl-transfer.component.css'],
  encapsulation:ViewEncapsulation.None
})
export class OtlOtlTransferComponent implements OnInit {
  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public gridData = [];
  public OTLTransferFilterForm: FormGroup;
  public role;
  public isStockTransferLock;
  public moduleName;
  public clientNames =[];
  public pageSize = 10;
  public otlList =[];
  public partList=[];
  public stockReportPermission;
  public cpList = [];
  public isAdmin:boolean = false;
  public isChannelPartner;
  otlTransferPermission;
  isOTLTransferLock;
  public displayChannelPartnerKeys = ['name', 'cpnumber']
 public displayChannelPartnerKeys1 = ['name', 'custNumber']
 public displayChannelPartnerKeys2 = ['name', 'custNumber']
 public editOtlTransfer = false;
 public urlName;
  constructor(private _router: Router,private route: ActivatedRoute, private _StorageService: StorageService, private _momentService: MomentService, private _permissionMenuListService: PermissionMenuListService,
    private _formValidator: FormValidatorService, private fb: FormBuilder, private _otlTransferService:OtlTransferService,
    private _bookingService :CpbookingService, private _utilsService : UtilsService, private _secondarysalesService:SecondarysalesService) { }
    @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
    }
  ngOnInit() {


    

    console.log(this.urlName);
    this.checkAccessControl();
    this.loadOTLTransferFilterForm();
    this.moduleName = this._utilsService.moduleName()
    this.role = this._StorageService.getUserDetails().role;
    this.isChannelPartner = this._utilsService.isCpRole(this.role);
    this.displayChannelPartnerKeys1 = this.isChannelPartner ? this.displayChannelPartnerKeys:this.displayChannelPartnerKeys2;
     this.setOtlList();
     this.loadStockLogPermission();
    this.setCPList();
        
    if (this._StorageService.getUserDetails().role == Roles.Channel_Partner) {
      this._secondarysalesService.cpModuleAccess(res => {
        this.isOTLTransferLock = res['stockTransferLock'] == 1  ? true : false
      });
    }
    this.defaultColDef = {
      sortable: true,
      filter: false,
      resizable: true
    };

    this.gridOptions = {
      rowHeight: 75,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2
    };

    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.gridOptions.onFilterChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: "id",
        headerName: 'S No.',
        width: 60,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
        suppressSizeToFit: true,
      },
      {
        headerName: 'Date',
        field: "updated_on",
        width: 150, 
        valueFormatter : this.formatDate.bind(this),
        suppressSizeToFit: true,
      },
      {
        headerName: 'Type',
        field: "type",
        width: 150, 
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'From CP',
        field: "fromCpName",
        width: 250,
        suppressSizeToFit: true,
      },
      {
        headerName: 'From End Customer',
        field: "fromEndCustomerName",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'From Customer Number',
        field: "fromCustomerNumber",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'From OTL',
        field: "fromOTL",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'To CP',
        field: "toCpName",
        width: 250,
        suppressSizeToFit: true,
      },
      {
        headerName: 'To End Customer',
        field: "toEndCustomerName",
        width: 150, 
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'To Customer Number',
        field: "toCustomerNumber",
        width: 150, 
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'To OTL',
        field: "toOTL",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        field: '',
        headerName: 'Action',
        width: 100,
        cellRendererFramework: AgGridMenuComponent,
        cellRendererParams: (params) => {
          let menu = []
            menu.push({
              name: 'View',
              link: '/'+this.moduleName+'/secondary-sales/otl-otl-transfer/view',
              newTab : true
            })
          return {menu}
        },
        suppressSizeToFit: true,
      }
    ];
  }

  checkAccessControl(){
    this._bookingService.getPermissionAccessControls({module : 'OTL_TRANSFER'},response =>{
      this.editOtlTransfer = response.parent_permission[0]['is_allowed'];
    })
  }
 loadStockLogPermission(){
   this._bookingService.getActionPermission({model : 'otltransfer'}, response =>{
     this.otlTransferPermission= response['otltransfer'];
     if(!this.otlTransferPermission || !this.otlTransferPermission['Can view otl transfer']){
       
    this.columnDefs = [
      {
        field: "id",
        headerName: 'S No.',
        width: 60,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
        suppressSizeToFit: true,
      },
      {
        headerName: 'Date',
        field: "updated_on",
        width: 150, 
        valueFormatter : this.formatDate.bind(this),
        suppressSizeToFit: true,
      },
      {
        headerName: 'Type',
        field: "type",
        width: 150, 
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'From CP',
        field: "fromCpName",
        width: 250,
        suppressSizeToFit: true,
      },
      {
        headerName: 'From End Customer',
        field: "fromEndCustomerName",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'From Customer Number',
        field: "fromCustomerNumber",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'From OTL',
        field: "fromOTL",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'To CP',
        field: "toCpName",
        width: 250,
        suppressSizeToFit: true,
      },
      {
        headerName: 'To End Customer',
        field: "toEndCustomerName",
        width: 150, 
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'To Customer Number',
        field: "toCustomerNumber",
        width: 150, 
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true,
      },
      {
        headerName: 'To OTL',
        field: "toOTL",
        width: 150,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true,
      }
    ];
     }
   });
 }


  setPartsList(){
    let payload = {
      "OTLNumber":"MYOTL001",
      "custNumber":"10282892",
      "siteId":"61072369"
    }
    this._otlTransferService.getOTLParts((res) => {
      this.partList =res;
    },payload);
  }

  setOtlList(){
    this._otlTransferService.getOTLTransferList(res =>{
      this.otlList =  this._utilsService.groupByMultipleKeys(res.results,['name','OTLnumber'])
    })
  }
  setCPList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpList = this._utilsService.groupByMultipleKeys(res,['name','cpnumber'])   
    })
  }
   
// end - set values for  filter fields

  loadOTLTransferFilterForm(){
    this.OTLTransferFilterForm = this.fb.group({
      partNumber: ['',this._formValidator.requireMatch],
      fromCP: ['',this._formValidator.requireMatch],
      toCP: ['',this._formValidator.requireMatch],
      fromCustomerNumber: ['',this._formValidator.requireMatch],
      fromOTLNumber: ['',this._formValidator.requireMatch], 
      type: [''],
      toCustomerNumber: ['',this._formValidator.requireMatch],
      toOTLNumber: ['',this._formValidator.requireMatch],
      lotNumber: ['',this._formValidator.requireMatch],
      lotExpiry: ['',this._formValidator.requireMatch],
      transferID:[''],
      from_date:[this._momentService.deceedDate(new Date(),31)],
      to_date:[new Date()]
    },{ validator: this._formValidator.dateValidation('from_date', 'to_date') });
  }  

  cancelOTLTransferReport(){
    this.OTLTransferFilterForm.reset();
    this.OTLTransferFilterForm.get('type').setValue("");
    this.getOTLTransferList();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.setOTLTransferParams();
  }
  setOTLTransferParams(){
    let data = {
      from_date : this._momentService.getFilterFormat(this.OTLTransferFilterForm.get('from_date').value),
      to_date : this._momentService.getFilterFormat(this.OTLTransferFilterForm.get('to_date').value, "toDate"),
    }
   this.getOTLTransferList(data);
  }
  getOTLTransferList(data?:any) {
    let payload = {};
    var datasource = {
      getRows: (params: IGetRowsParams) =>{
        if (data) {
          payload = data;
        }
        // payload['page_size'] =this.pageSize
        // payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
        // payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
        // payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
        this._otlTransferService.searchOTLTransferList(payload,(res)=>{
          this.gridData = res['results']?res['results'] : res;
           let length = res['total'];
          params.successCallback(res['results'], length) // data and totalcount of records 
          })
      }
    }
      this.gridApi.setDatasource(datasource);
      this.gridApi.setRowData( this.gridData);
  }

  formatDate(params){
    return params.data ? this._momentService.getDate(params.data.updated_on) : ''
  }
  getOTLPayload(data){
    let otlPayload ={};
    otlPayload['partNumber'] = data.partNumber ? data.partNumber : '';
    otlPayload['fromCpNumber'] = data.fromCP ? data.fromCP.cpnumber : '';
    otlPayload['toCpNumber'] = data.toCP ? data.toCP.cpnumber : '';
    otlPayload['fromCustomerNumber'] = data.fromCustomerNumber ? data.fromCustomerNumber : '';
    otlPayload['toCustomerNumber'] = data.toCustomerNumber ? data.toCustomerNumber : '';
    otlPayload['fromOTL'] = data.fromOTLNumber ? data.fromOTLNumber : '';
    otlPayload['toOTL'] = data.toOTLNumber ?  data.toOTLNumber : '';
    otlPayload['itemNumber'] = data.itemNumber ?  data.itemNumber  : '';
    otlPayload['lotNumber'] = data.lotNumber? data.lotNumber : '';
    otlPayload['lotExpiryDate'] = data.lotExpiry? this._momentService.getIsoFormat(data.lotExpiry) : '';
    otlPayload['type'] = data.type? data.type : '';    
    otlPayload['transferId'] = data.transferID ? data.transferID : '';
    otlPayload['from_date'] = data.from_date ?  this._momentService.getFilterFormat(data.from_date) : '';
    otlPayload['to_date'] = data.to_date ? this._momentService.getFilterFormat(data.to_date, "toDate") : '';
    return otlPayload;
  }
  searchOTLTrans() {
    let payload = this.getOTLPayload(this.OTLTransferFilterForm.value) ;
     this.getOTLTransferList(payload)
  }

  cancelFilter() {
    this.OTLTransferFilterForm.reset();
    this.OTLTransferFilterForm.get('from_date').setValue(this._momentService.deceedDate(new Date(),31));
    this.OTLTransferFilterForm.get('to_date').setValue(new Date())
    this.setOTLTransferParams();
  }

  exportOTLTransfer(){
    let stockFilterValues = this.getOTLPayload(this.OTLTransferFilterForm.value);
    stockFilterValues['is_export'] = true;
    this._otlTransferService.exportOTLFilter(stockFilterValues);

  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtlTransferNewComponent } from './otl-transfer-new.component';

describe('OtlTransferNewComponent', () => {
  let component: OtlTransferNewComponent;
  let fixture: ComponentFixture<OtlTransferNewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtlTransferNewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtlTransferNewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

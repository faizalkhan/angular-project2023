import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { RouterModule, Routes } from '@angular/router';
import { AgGridModule } from 'ag-grid-angular';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { PipeModule } from 'src/app/core/pipe/pipe.module';
import { OtlOtlTransferComponent } from './otl-otl-transfer.component';
import { OtlTransferNewComponent } from './otl-transfer-new/otl-transfer-new.component';
import { OtlTransferDetailComponent } from './otl-transfer-detail/otl-transfer-detail.component';

const routes: Routes = [{
  path:'', 
  component:OtlOtlTransferComponent
},{
  path:'add',
  component:OtlTransferNewComponent
},
{
  path:'view/:id',
  component:OtlTransferDetailComponent
}]


@NgModule({
  declarations: [ OtlOtlTransferComponent,OtlTransferNewComponent,OtlTransferDetailComponent],
  
  imports: [
    CommonModule,
    AppMaterialModule,
    RouterModule.forChild(routes),
    AgGridModule.withComponents([]),
    CustomFormsModule,
    PipeModule
  ],
  exports :[CustomFormsModule, AgGridModule, OtlOtlTransferComponent,OtlTransferNewComponent,OtlTransferDetailComponent]

})
export class OtlOtlTransferModule { }


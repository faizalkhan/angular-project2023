import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtlOtlTransferComponent } from './otl-otl-transfer.component';

describe('OtlOtlTransferComponent', () => {
  let component: OtlOtlTransferComponent;
  let fixture: ComponentFixture<OtlOtlTransferComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtlOtlTransferComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtlOtlTransferComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

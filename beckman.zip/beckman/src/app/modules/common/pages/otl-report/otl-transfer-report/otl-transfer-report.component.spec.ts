import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtlTransferReportComponent } from './otl-transfer-report.component';

describe('OtlTransferReportComponent', () => {
  let component: OtlTransferReportComponent;
  let fixture: ComponentFixture<OtlTransferReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtlTransferReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtlTransferReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit, HostListener  } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { Roles } from 'src/app/modules/auth/model/user';
import { OtlTransferService } from '../../../service/otl-transfer/otl-transfer.service';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { ActionItems } from 'src/app/core/services/constants';
@Component({
  selector: 'app-otl-transfer-report',
  templateUrl: './otl-transfer-report.component.html',
  styleUrls: ['./otl-transfer-report.component.css']
})
export class OtlTransferReportComponent implements OnInit {

  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public gridData = [];
  public otlReportForm: FormGroup;
  public role;
  public clientNames =[];
  public otlList =[];
  public partList=[];
  public cityList=[];
  public siteIdList=[];
  public otlReportPermission;
  public cpNames =[];
  public isAdmin:boolean = false;
  public isChannelPartner;
  public displayChannelPartnerKeys = ['name', 'cpnumber']
 public displayChannelPartnerKeys1 = ['name', 'custNumber'];
 public displayChannelPartnerKeys2 = ['name', 'custNumber']
 public allColumnIds =[];
 public cpList = [];
  constructor(private _StorageService: StorageService, private _formValidator: FormValidatorService, private _permissionMenuListService: PermissionMenuListService,
    private fb: FormBuilder, private _OtlTransferService:OtlTransferService,
    private _bookingService :CpbookingService, private _utilsService : UtilsService, private _momentService: MomentService
    ) { }
  @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
    }
  ngOnInit() {
    this.role = this._StorageService.getUserDetails().role;
    this.isChannelPartner = this._utilsService.isCpRole(this.role);
    this.displayChannelPartnerKeys1 = this.isChannelPartner ? this.displayChannelPartnerKeys:this.displayChannelPartnerKeys2;
    this.loadotlReportForm();
    this.setClientList();
    this.setCPList();
    // calling filters api 
    this.defaultColDef = {
      sortable: true,
      filter: false,
      resizable: true
    };
    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
    };

    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: "",
        headerName: 'S No.',
        width: 60,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
        suppressSizeToFit: true,
      },
      {
        headerName: 'From CP',
        field: "fromCpName",
        width: 250,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true,
       
      },
      {
        headerName: 'From Customer Name',
        field: "fromEndCustomerName",
        width: 300,
        comparator: (param1, param2) => {
          return this._utilsService.alphaNumbericSorting(param1,param2);
        },
        suppressSizeToFit: true,
       
      },
      {
        headerName: 'From Site ID',
        field: "fromCustomerSiteId",
        width: 170,
        suppressSizeToFit: true,
        },
        {
          headerName: 'From OTL',
          field: "fromOTL",
          width: 110, 
          comparator: (param1, param2) => {
            return this._utilsService.alphaNumbericSorting(param1,param2);
          },
          suppressSizeToFit: true,
        },
        {
          headerName: 'Part Number(Item)',
          field: "partNumber",
          width: 100,
          comparator: (param1, param2) => {
            return this._utilsService.alphaNumbericSorting(param1,param2);
          },
          suppressSizeToFit: true,
        },
        {
          headerName: 'Description',
          field: "description",
          width: 250,
          suppressSizeToFit: true,
        }, {
          headerName: 'Available Quantity',
          field: "availableQuantity",
          width: 170,
          comparator: (param1, param2) => {
            return this._utilsService.numberSorting(param1,param2);
          },
          suppressSizeToFit: true,
        },
        {
          headerName: 'Lot No',
          field: "lotNumber",
          width: 110,
          comparator: (param1, param2) => {
            return this._utilsService.alphaNumbericSorting(param1,param2);
          },
          suppressSizeToFit: true,
        }, 
        {
          headerName: 'Expiry Date',
          field: "lotExpiryDate",
          width: 120,
          valueFormatter : (params) =>{
            return params.data.lotExpiryDate && params.data.lotExpiryDate!="None" ? this._momentService.getDate(new Date(params.data.lotExpiryDate)) : ''
          },
          suppressSizeToFit: true,
        },
      {
        headerName: 'To CP',
        field: "toCpName",
        width: 300,
        suppressSizeToFit: true,
      },
      {
        headerName: 'To Customer Name',
        field: "toEndCustomerName",
        width: 300,
        suppressSizeToFit: true,
      },
      {
        headerName: 'To Site Id',
        field: "toCustomerSiteId",
        width: 100,
        suppressSizeToFit: true,
        }, 
        {
          headerName: 'To OTL',
          field: "toOTL",
          width: 100, 
          comparator: (param1, param2) => {
            return this._utilsService.alphaNumbericSorting(param1,param2);
          },
          suppressSizeToFit: true,
        },
        {
          headerName: 'Transfer ID',
          field: "transferId",
          width: 300, 
          comparator: (param1, param2) => {
            return this._utilsService.alphaNumbericSorting(param1,param2);
          },
          suppressSizeToFit: true,
        },
        {
          headerName: 'Type',
          field: "type",
          width: 100, 
          comparator: (param1, param2) => {
            return this._utilsService.alphaNumbericSorting(param1,param2);
          },
          suppressSizeToFit: true,
        },        
      {
        headerName: 'Date of Transfer',
        field: "dateOfTransfer",
        width: 150, 
        valueFormatter : this.formatDate.bind(this),
        suppressSizeToFit: true,
      },
        {
          headerName: 'Time of Transfer',
          field: "timeOfTransfer",
          width: 200, 
          comparator: (param1, param2) => {
            return this._utilsService.alphaNumbericSorting(param1,param2);
          },
          suppressSizeToFit: true,
        }
    ];
    this.loadReportsPermission()
  }

  formatDate(params){
    return params.data ? this._momentService.getDate(params.data.dateOfTransfer) : ''
  }
 loadReportsPermission(){
  this._permissionMenuListService.getActionPermission({model : 'reports'}, response =>{
    this.otlReportPermission= response['reports'];    
  });
}
setCPList(){
  this._bookingService.listChannelPartner(res=>{
    this.cpList = this._utilsService.groupByMultipleKeys(res,['name','cpnumber'])   
  })
}

setClientList(){
  this._bookingService.listHospital(res =>{
    this.clientNames =  this._utilsService.groupByMultipleKeys(res,['name','custNumber'])
  })
}
  onGridReady(params) {
   var allColumnIds =[];
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit()
    this.getOTLReportList();
  }
  getOTLReportList(){
    this._OtlTransferService.getOTLTransferReportList((res) => {
      this.gridData = res['results']?res['results'] : res;
      this.gridApi.setRowData( this.gridData);
      console.log(this.gridData);
      
      this.gridApi.paginationGoToFirstPage();
    }
    );
  }
// end - set values for  filter fields
  loadotlReportForm(){
    this.otlReportForm = this.fb.group({
      partNumber: ['',this._formValidator.requireMatch],
      fromCpName: ['',this._formValidator.requireMatch], 
      toCpName: ['',this._formValidator.requireMatch],
      transferID: ['',this._formValidator.requireMatch],
      fromCustomerNumber: ['',this._formValidator.requireMatch],
      fromOTLNumber: ['',this._formValidator.requireMatch],
      CustomerNumber: ['', this._formValidator.requireMatch],
      toOTLNumber: ['', this._formValidator.requireMatch],
      type: ['', this._formValidator.requireMatch]
    });
  }

  exportStockReport(){
    let paylaod =  this.getOTLPayload(this.otlReportForm.value);
    paylaod['is_export'] = true;
    this._OtlTransferService.exportOTLReportFilter(paylaod);
  }

  getOTLPayload(data){
    let otlPayload ={};
    otlPayload['partNumber'] = data.partNumber ? data.partNumber : '';
    otlPayload['fromCpNumber'] = data.fromCpName ?  data.fromCpName.cpnumber : '';
    otlPayload['toCpNumber'] = data.toCpName  ?  data.toCpName.cpnumber :'';
    otlPayload['fromCustomerNumber'] = data.fromCustomerNumber ? data.fromCustomerNumber : '';
    otlPayload['toCustomerNumber'] = data.toCustomerNumber ? data.toCustomerNumber : '';
    otlPayload['fromOTL'] = data.fromOTLNumber ? data.fromOTLNumber : '';
    otlPayload['toOTL'] = data.toOTLNumber ?  data.toOTLNumber : '';
    otlPayload['type'] = data.type? data.type : '';    
    otlPayload['transferId'] = data.transferID ? data.transferID : '';
    return otlPayload;
  }

  searchOTLReport(){
    this._OtlTransferService.searchOTLReport(this.getOTLPayload(this.otlReportForm.value), (res) => {
      this.gridData = res['results']?res['results'] : res;
      this.gridApi.setRowData( this.gridData);
      console.log(this.gridData);
      this.gridApi.paginationGoToFirstPage();
    });
  }
  cancelStockReport(){
    this.otlReportForm.reset();
    this.getOTLReportList();
  }
  RoundOFTwoDigit(num: any){
    var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
    return number;
  }

}

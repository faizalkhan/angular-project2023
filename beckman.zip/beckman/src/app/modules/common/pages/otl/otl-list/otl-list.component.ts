import { Component, OnInit, ViewEncapsulation, HostListener } from '@angular/core';
import { IGetRowsParams } from 'ag-grid-community';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { FormGroup, FormBuilder } from '@angular/forms';
import { HospitalService } from 'src/app/modules/beckman/service/hospital/hospital.service';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { OtlmasterService } from 'src/app/modules/beckman/service/hospital/otlmaster.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { AgGridRouterComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-router.component';
import { Roles } from 'src/app/modules/auth/model/user';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { ActionItems } from 'src/app/core/services/constants';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
//import { OtlService } from '../otl.service';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-otl-list',
  templateUrl: './otl-list.component.html',
  styleUrls: ['./otl-list.component.css'],
  encapsulation:ViewEncapsulation.None
})
export class OtlListComponent implements OnInit {

   
  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public searchValue;
  public pageSize = 10;
  public otlSearchForm: FormGroup;
  otlList =[];
  clientNames=[];
  cpNames=[];
  public moduleName;
  public editOtl = false;
  public deleteOtlPermission = false;
  public otlPermission;
  public displayChannelPartnerKeys = ['name', 'cpnumber']
  public displayChannelPartnerKeys1 = ['name', 'custNumber']
  public isFilter: boolean =false;
  public isBacktrigger : boolean = false;
  public iscurrentPath: boolean = false;
  public previousUrl: any;
  public currentUrl : any;
  public routeString: string;
  public stringSplit: any[];
  public isPageRetain: any;
  public pageToNavigate: any;
  public isview: boolean;
  public exportPermission = false;
  gridData:any =[]
  constructor(private _hospitalService: HospitalService,private fb: FormBuilder,private _bookingService: CpbookingService,private _permissionMenuListService: PermissionMenuListService,
    private _formValidator: FormValidatorService,  private _otlMasterService: OtlmasterService, private _PromptService: PromptService, private _UtilsService:UtilsService,
   // public _otlservice: OtlService, 
    public route: ActivatedRoute, public router: Router) { }
    @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
      this.currentUrl = this.router.url;
    
  }
  
  ngOnInit() {
  //  this.router.events.subscribe(event => {
  //   if (event instanceof NavigationEnd) {        
  //     this.previousUrl = this.currentUrl;
  //     this.currentUrl = event.url;
  //   this.routeString = this.currentUrl;
  //   this.stringSplit = this.routeString.split('/')
  //   if(localStorage.getItem('filtervalue') && localStorage.getItem('isviewFilter'))   {
  //       if(this.stringSplit[2] != 'otl'){
  //         localStorage.removeItem('filtervalue')
  //         localStorage.removeItem('isviewFilter');
  //         localStorage.removeItem('isfilter')
  //       }
  //   }
  //   };
  // });

    this. loadOTLSearchForm();
    this.setClientList ();
    this.setCpList();
    this.setOtlList();
    this.moduleName = this._UtilsService.moduleName()
    this.loadOtlPermission()
    this.defaultColDef = {
      filter: false,
      sortable: true,
      resizable: true
    };
    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
     cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2,
      onFirstDataRendered: (params) => {
       
        this.pageToNavigate = JSON.parse(localStorage.getItem('currentPage'));
        params.api.paginationGoToPage(this.pageToNavigate);
      },
      onPaginationChanged: (params) => {
       
        if (params.newPage) {
          let currentPage = params.api.paginationGetCurrentPage();
    if(currentPage>1){
          localStorage.setItem('currentPage', JSON.stringify(currentPage));
    }
        }
      },
    };
    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.gridOptions.onFilterChanged = event => {
      this.gridApi.redrawRows(); 
    }
    // this.gridOptions.onFirstDataRendered = event =>{
    //   this.gridApi.onFirstDataRendered();
    // }
    this.columnDefs = [
      {
        field: "id",
        headerName: 'S No.',
        width: 50,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
      },
      {
        headerName: 'OTL Number',
        field: "OTLnumber",
        width: 80,
        cellRendererFramework: AgGridRouterComponent,
        cellRendererParams: {
          inRouterLink: '/'+this.moduleName + '/otl/view/',
        },
      },
      {
        headerName: 'Type',
        field: "type",
        width: 70,
      },
      {
        headerName: 'Hospital',
        field: "hospital_name",
        width: 300,
        sortable: false,
      },
      {
        headerName: 'Customer no',
        field: "custNumber",
        width: 120,
        comparator: (param1, param2) => {
          return this._UtilsService.alphaNumbericSorting(param1,param2);
        }
      },
      {
        headerName: 'Site Id',
        field: "site_id",
        width: 120,
        comparator: (param1, param2) => {
          return this._UtilsService.alphaNumbericSorting(param1,param2);
        }
      },
      {
        headerName: 'Channel partner',
        field: "channel_partner_name",
        width: 300,
        sortable: false,
      },
      {
        field: "isActive",
        headerName: 'Status',
        width: 90,
        valueFormatter: (params) =>{
          return (params.value || params.value == 0) ?  this._UtilsService.isActiveStatus(params.value) : ''
        }
      },
      {
        field: "",
        headerName: 'Action',
        sortable: false, 
        filter: false,
        width: 80,
        cellRendererFramework: AgGridMenuComponent,
        cellRendererParams: (params) => {
         
          let menu = [{
            name: "View",
            link: "/"+this.moduleName +"/otl/view/",
            onMenuAction: "",
           // filter:'value'
          }]
          if (this.editOtl){
            menu.push({
              name: "Edit",
              link: "/"+this.moduleName + "/otl/edit/",
              onMenuAction: ""
            })
          }
          if(this.deleteOtlPermission){
            menu.push({
              name: "Delete",
              link: "",
              onMenuAction:this.deleteOtl.bind(this)
            })
          }
          
          return {menu}
        },
      }
    ]; 

  }
  loadOtlPermission(){
    this._permissionMenuListService.getActionPermission({model : 'otl'}, response =>{
      this.otlPermission= response['otl'];
      this.editOtl = this.setActionsPermission('EDIT');
      this.deleteOtlPermission = this.setActionsPermission('DELETE');
      this.exportPermission =  this.setActionsPermission('EXPORT');
      
    });
  }

  setActionsPermission(name){
    return this.otlPermission && typeof this.otlPermission[ActionItems[name]] != 'undefined'  ?  true : false;
  }

  loadOTLSearchForm(){
    this.otlSearchForm = this.fb.group({
      custNumber: ['',this._formValidator.requireMatch],
      site_id: [''],
      OTLnumber: ['', this._formValidator.requireMatch],
      isActive: [''],
      cpnumber:['', this._formValidator.requireMatch]
    });
  }


  setOtlList(){
    this._bookingService.getListofOTLParts(res =>{
      this.otlList =  this._UtilsService.groupByMultipleKeys(res,['name','OTLnumber'])
    })
  }
  setClientList(){
    this._bookingService.listHospital( res =>{
      this.clientNames =  this._UtilsService.groupByMultipleKeys(res,['name','custNumber'])
    })
  }

  setCpList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpNames = this._UtilsService.groupByMultipleKeys(res,['name','cpnumber'])   
    })
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();  
    this.getOtlList();
  } 

  deleteOtl(id){
    this._PromptService.openDialog({title : 'Delete OTL',btnLabel : 'CONFIRM',content :'Are you sure you want to delete this OTL?'}, response =>{
      if (response){
        this._hospitalService.deleteOtl(id,(res)=>{
          this.getOtlList();
        })
      }
    })
  }
 
  getOtlList(data?:any) { 
    let payload = {};
    var datasource = {
      getRows: (params: IGetRowsParams) =>{
        if (data) {
          payload = data;
        }
        payload['page_size'] =this.pageSize
        payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
        payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
        payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : '';
        payload['is_primary'] = true;
      // this._otlservice.sendfilter(payload);
      
    //     if(this.isFilter){
    //       localStorage.setItem('filter',JSON.stringify(payload));
    //       localStorage.setItem('isfilter',JSON.stringify(this.isFilter));
    //        }
    //  const c = localStorage.getItem('isviewFilter');
    //  if(c){
    //     let filter_value = JSON.parse(localStorage.getItem('filtervalue'));
      
    //     this.otlSearchForm.patchValue({
    //       custNumber : this.getCustName(filter_value.custNumber, filter_value.site_id)
    //   })
    //    let payloadv = JSON.parse(localStorage.getItem('filter'));
    //   this._otlMasterService.getOtlList(payloadv, (res)=>{
    //   let length = res['total'];
    //     params.successCallback(res['results'], length) 
    //     })
    //  }
     
      
            this._otlMasterService.getOtlList(payload, (res)=>{
         
              let length = res['total'];
              this.gridData = res['results'];
              params.successCallback(res['results'], length) 
              })
         }
    }
 
      this.gridApi.setDatasource(datasource);
  }
  getPayload(bookingValue){
    let data =  {};
    data['custNumber'] =  bookingValue.custNumber ? bookingValue.custNumber.custNumber : '';
    data['OTLnumber'] = bookingValue.OTLnumber ? bookingValue.OTLnumber.OTLnumber : '';
    data['site_id'] =bookingValue.site_id ? bookingValue.site_id : '';
    data['isActive']= bookingValue.isActive ? bookingValue.isActive : '';
    data['cpnumber'] = bookingValue.cpnumber ? bookingValue.cpnumber.cpnumber : '';
    return data;
  }

  searchFilter(){
    if (this.otlSearchForm.valid){
      this.isFilter = true;
    let payload =  this.getPayload(this.otlSearchForm.value);
    this.isFilter = true;
    this.getOtlList(payload);
   }
   }

  cancelFilter(){
    localStorage.removeItem('filtervalue');
    localStorage.removeItem('filter');
    localStorage.removeItem('isfilter');
    localStorage.removeItem('isviewFilter');
    this.otlSearchForm.reset();
    this.getOtlList();
  }
  

importOtlMaster($event) {
    const otlMasterData = new FormData();
    otlMasterData.append('file', $event.target.files[0]);
    this._otlMasterService.importOtlMaster(otlMasterData, () => {
       //Callback
       this.getOtlList();
    });
  }
  exportOTLMaster() {
    this._otlMasterService.exportOtlMaster();
  }

  navigate(){
    this._otlMasterService.navigate()
  }
  // getCustName(custNumber, siteId) {
  //   let custDetails = {};
  //   custDetails = this.clientNames.find((val) => val.custNumber === custNumber && val.site_id === siteId);
  //   return custDetails ? custDetails : '';
  // }

  exportOTLData(){
    let paylaod =  this.getPayload(this.otlSearchForm.value);
    paylaod['is_export'] = true;
    this._otlMasterService.exportOTLData(paylaod);
  }
}

import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { HospitalService } from 'src/app/modules/beckman/service/hospital/hospital.service';
import { OtlmasterService } from 'src/app/modules/beckman/service/hospital/otlmaster.service';
import { ChannelpartnerService } from 'src/app/modules/beckman/service/channelpartner/channelpartner.service';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { ActionItems } from 'src/app/core/services/constants';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';



@Component({
  selector: 'app-otl-add',
  templateUrl: './otl-add.component.html',
  styleUrls: ['./otl-add.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class OtlAddComponent implements OnInit {
  

  otlForm: FormGroup;
  public cpName =[];
  public displayClientKeys = ['name','address']
  public displayChannelPartnerKeys = ['name', 'cpnumber']
  displaySalesPersonKeys = ['name', 'email']
  public clientNames = [];
  public otlId;
  public data:any;
  public sector;
  public moduleName;
  public groupedUserEmail ;
  public salesPerson = [];
  constructor(private fb: FormBuilder, private _momentService: MomentService, 
    private _hospitalService: HospitalService, private _bookingService:CpbookingService,
    private _otlMasterService: OtlmasterService, private _UtilsService:UtilsService,private _permissionMenuListService: PermissionMenuListService,
    public route: ActivatedRoute,
    private _formValidator: FormValidatorService) { 
    }
isEdit: boolean = false;
  ngOnInit() {
    this.loadOtlPermission();
    this.loadOtlForm();
    this.groupedUserList();
    this.statusValueChanged();
    this.moduleName = this._UtilsService.moduleName()
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.otlId = parseInt(params.get('id'));
      if (this.otlId){
        this.isEdit = true;
         this.getOtlData();
        }
    else{
       this.loadHospitals();
      }
    });
  }
  
  loadOtlPermission(){
    this._permissionMenuListService.getActionPermission({model : 'otl'},response =>{
      if((! this.otlId && response['otl']&&  typeof response['otl'][ActionItems['ADD']] == 'undefined')|| ( this.otlId &&response['otl'] && typeof response['otl'][ActionItems['EDIT']] == 'undefined') )this._otlMasterService.navigate();
    });
} 
  groupedUserList(){
    this._otlMasterService.groupUserEmail(response =>{
      this.groupedUserEmail = response;
      this.salesPerson = [...response['Salesperson'], ...response['RegionalBusinessManager'], ...response['StateManager']];
      if (this.otlId){
        this.setManagerEmailId()
      }
    })
  }
  setManagerEmailId(){
    if (this.data){
      let salesEmail = this.salesPerson.find(res => res['email'].toLowerCase() == this.data.salesEmail.toLowerCase());
      let businessUnitEmailid=  this.groupedUserEmail['NationalSalesManager'].find(res => res['email'].toLowerCase() == this.data.businessUnitEmailid.toLowerCase() )
      let regionalBranchEmailid =  this.groupedUserEmail['RegionalBusinessManager'].find(res => res['email'].toLowerCase() == this.data.regionalBranchEmailid.toLowerCase() )
      let corporateMgrEmailid = this.groupedUserEmail['CorporateManager'].find(res => res['email'].toLowerCase() == this.data.corporateMgrEmailid.toLowerCase() )
      let govtMgrEmailid=  this.groupedUserEmail['GovtManager'].find(res => res['email'].toLowerCase() == this.data.govtMgrEmailid.toLowerCase() )
      let  productLineMgrEmailid = this.groupedUserEmail['ProductlineManager'].find(res => res['email'].toLowerCase() == this.data.productLineMgrEmailid.toLowerCase() )
      let  teamLeadEmailid =this.groupedUserEmail['StateManager'].find(res => res['email'].toLowerCase() == this.data.teamLeadEmailid.toLowerCase() )
      let corporateEmailid  =  this.groupedUserEmail['CorporatePerson'].find(res => res['email'].toLowerCase() == this.data.corporatepersonEmailid.toLowerCase())
      let govtPersonEmailid =  this.groupedUserEmail['GovtPerson'].find(res => res['email'].toLowerCase() == this.data.govtpersonEmailid.toLowerCase())
      this.otlForm.patchValue({ 
        salesEmail: salesEmail != 'undefined' ? salesEmail : '',
        businessUnitEmailid: businessUnitEmailid != 'undefined' ? businessUnitEmailid : '', 
        regionalBranchEmailid:  regionalBranchEmailid != 'undefined' ? regionalBranchEmailid : '', 
       
        corporateMgrEmailid:  corporateMgrEmailid != 'undefined' ? corporateMgrEmailid : '', 
        govtMgrEmailid: govtMgrEmailid != 'undefined' ? govtMgrEmailid : '', 
        productLineMgrEmailid: productLineMgrEmailid != 'undefined' ? productLineMgrEmailid : '', 
        teamLeadEmailid: teamLeadEmailid != 'undefined' ? teamLeadEmailid : '', 
        corporatePersonEmailid : corporateEmailid != 'undefined' ? corporateEmailid: '',
        govtPersonEmailid : govtPersonEmailid != 'undefined' ? govtPersonEmailid: '',
      });
    }
  }
  loadCP(data) {
  
    this._bookingService.listChannelPartner((res)=>{
      const uniquevalue = this.getUniqueValue(res);
      this.cpName = uniquevalue;
      if(this.otlId) {
      this.otlForm.patchValue({
        cpnumber : this.getCpName(data ? data.cpnumber : '')
      })
    }
    });
  }

  loadHospitals(data?:any) {
    this._otlMasterService.getDistinctHospitals({isActive : 1},(response) => {
      this.clientNames = response
      if(this.otlId && data) {
        this.otlForm.patchValue({
          custName : this.getCustName(data.custNumber, data.site_id)
        })
        this.loadCP(data);
      }
    });
  }

  loadOtlForm() {
    this.otlForm = this.fb.group({
      custName: ['', [Validators.required, this._formValidator.requireMatch]],
      OTLnumber: ['', [Validators.required,this._formValidator.alphaNumericValidation]],
      type: [null, Validators.required],
      custNumber: [''],
      site_id : [''],
      start_date: ['', Validators.required],
      end_date: ['', Validators.required],
      isActive: ['1'],
      inActiveReason: [{value: null, disabled: true}],
      salesEmail: ['', [Validators.required,this._formValidator.requireMatch]],
      businessUnitEmailid: ['', this._formValidator.requireMatch],
      regionalBranchEmailid: ['', this._formValidator.requireMatch],
      corporatePersonEmailid: ['', this._formValidator.requireMatch],
      govtPersonEmailid: ['', this._formValidator.requireMatch],
      corporateMgrEmailid: ['', this._formValidator.requireMatch],
      govtMgrEmailid: ['', this._formValidator.requireMatch],
      productLineMgrEmailid: ['', this._formValidator.requireMatch],
      teamLeadEmailid: ['', this._formValidator.requireMatch],
      commitment: ['', this._formValidator.withZeroAndNegativeValidation],
      
      cpnumber : ['', [Validators.required, this._formValidator.requireMatch]]
    }, { validator: this._formValidator.dateValidation('start_date', 'end_date')});
    
  }
  statusValueChanged(){
    const inActiveReason = this.otlForm.get('inActiveReason');
    this.otlForm.get('isActive').valueChanges.subscribe(
      (status: any) => {
        if(status == 0) {
          inActiveReason.enable();
          inActiveReason.setValidators([Validators.required, this._formValidator.noWhitespaceValidation]);
        }
        else {
          this.otlForm.controls['inActiveReason'].setValue(null);
          inActiveReason.disable();
          inActiveReason.clearValidators();
        }
        inActiveReason.updateValueAndValidity();
      })
   }

 
  
  onSubmit() {
    let otlData =  this.otlForm.value;
    otlData['cpnumber'] =this.otlForm.get('cpnumber').value.cpnumber;
    otlData.start_date = this._momentService.getIsoFormat(this.otlForm.get('start_date').value);
    otlData.end_date = this._momentService.getIsoFormat(this.otlForm.get('end_date').value);
    otlData.custNumber =  this.otlForm.get('custName').value.custNumber; 
    otlData.site_id = this.otlForm.get('custName').value.site_id;
    otlData['inActiveReason']  = this.otlForm.get('inActiveReason').value;
    otlData['salesEmail'] =  this.otlForm.get('salesEmail').value ? this.otlForm.get('salesEmail').value.email : '';
    otlData['businessUnitEmailid']=this.otlForm.get('businessUnitEmailid').value ? this.otlForm.get('businessUnitEmailid').value.email : '';
    otlData['regionalBranchEmailid']  = this.otlForm.get('regionalBranchEmailid').value ? this.otlForm.get('regionalBranchEmailid').value.email : '';
    otlData['corporatepersonEmailid']  = this.otlForm.get('corporatePersonEmailid').value ? this.otlForm.get('corporatePersonEmailid').value.email : '';
    otlData['govtpersonEmailid']  = this.otlForm.get('govtPersonEmailid').value ? this.otlForm.get('govtPersonEmailid').value.email : '';
    otlData['corporateMgrEmailid']   = this.otlForm.get('corporateMgrEmailid').value ? this.otlForm.get('corporateMgrEmailid').value.email : '';
    otlData['govtMgrEmailid']  = this.otlForm.get('govtMgrEmailid').value ? this.otlForm.get('govtMgrEmailid').value.email : '';
    otlData['productLineMgrEmailid'] =this.otlForm.get('productLineMgrEmailid').value ? this.otlForm.get('productLineMgrEmailid').value.email : '';
    otlData['teamLeadEmailid']  = this.otlForm.get('teamLeadEmailid').value ? this.otlForm.get('teamLeadEmailid').value.email : '';
    if (this.otlId) {
      this._hospitalService.editOtl(this.otlId, otlData, (res) => { 
        this._otlMasterService.navigate();
      }); 
    } else {
      this._hospitalService.addOtl(otlData,(res)=>{
        this._otlMasterService.navigate();
      });
    }
    
  }

  resetOtlForm() {
    if (!this.otlId) {
      this.otlForm.reset();
      this.otlForm.get('isActive').setValue('1');
    }
    else { this.setOtlData(); }
    
  }

  onClientChange(value) {
    this.otlForm.patchValue({ 
      cpnumber : ''
     });
     this.otlForm.get('custNumber').setValue(value.custNumber);
     this.otlForm.get('site_id').setValue(value.site_id)

    this.loadClientsBasedCp();
  }
  loadClientsBasedCp(){
  this._bookingService.listChannelPartner( (res) => {
   const uniquedata= this.getUniqueValue(res);
    this.cpName = uniquedata;

  });
}
  getOtlData() {
    this._hospitalService.viewOtl(this.otlId,(res)=> {
      this.data = res;
      this.loadHospitals(this.data);
      this.setOtlData();
    },()=>console.log('error'));
  }

  setOtlData() {
      this.otlForm.patchValue({ 
      OTLnumber: this.data.OTLnumber,
      type: this.data.type,
      start_date: this.data.start_date,
      end_date: this.data.end_date,
      isActive: this.data.isActive.toString(),
      commitment: this.data.commitment,
        custNumber: this.data.custNumber,
      site_id: this.data.site_id,
      inActiveReason: this.data.inActiveReason

    });
    this.loadClientsBasedCp();
    this.setManagerEmailId()

  }
  getCustName(custNumber, siteId) {
    let custDetails = {};
    custDetails = this.clientNames.find((val) => val.custNumber === custNumber && val.site_id === siteId);
    return custDetails ? custDetails : '';
  }

  getCpName(cpNumber?:any){
    let cpDetails = {};
    if (!cpNumber && this.data) cpNumber = this.data.cpNumber
    cpDetails = this.cpName.find((val) => val.cpnumber === cpNumber);
    return cpDetails ? cpDetails : '';
  }

  getUniqueValue(res){
    var uniqueArr =[];
    res.forEach((item)=>{
      var i= uniqueArr.findIndex(x=>x.cpnumber == item.cpnumber);
      if(i<=-1){
        uniqueArr.push(item);
      }
      return null;
    });
    return uniqueArr;
  }

}

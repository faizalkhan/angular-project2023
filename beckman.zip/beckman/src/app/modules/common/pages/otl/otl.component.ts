import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otl',
  // templateUrl: './otl.component.html',
  // styleUrls: ['./otl.component.css']
  template : `<router-outlet></router-outlet>`,
  styles : []
})
export class OtlComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

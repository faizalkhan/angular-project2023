import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { HospitalService } from 'src/app/modules/beckman/service/hospital/hospital.service';
import { OtlmasterService } from 'src/app/modules/beckman/service/hospital/otlmaster.service';
import { ActionItems } from 'src/app/core/services/constants';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
//import { OtlService } from '../otl.service';

@Component({
  selector: 'app-otl-view',
  templateUrl: './otl-view.component.html',
  styleUrls: ['./otl-view.component.css']
})
export class OtlViewComponent implements OnInit {

  
  public otlId;
  public otlData: any;
  public editOtl = false
  public deleteOtlPermission = false
  public isback : boolean;
  constructor(public route: ActivatedRoute, private _hospitalService: HospitalService,  private _PromptService: PromptService, private _permissionMenuListService: PermissionMenuListService, private _otlMasterService: OtlmasterService) 
  {
    window.onpopstate = function(event) {
  
    }
   }

  ngOnInit() {
    // const value = JSON.parse(localStorage.getItem('isfilter'));
    // if(value){
    //   localStorage.setItem('isviewFilter', 'true');
    // }
//  const getcurvalue = this._otlservice.getFilter();
//   if(getcurvalue){
//     localStorage.setItem('returnvalue',JSON.stringify(getcurvalue) );
//   }
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.otlId = parseInt(params.get('id'));
    });

    this._hospitalService.viewOtl(this.otlId,(res)=>{
      this.otlData = res;
    },()=>console.log('error'));

    this._permissionMenuListService.getActionPermission({model :  'otl'},response =>{
      this.editOtl =response['otl'] && typeof response['otl'][ActionItems['EDIT']] != 'undefined'  ?  true : false; 
      this.deleteOtlPermission =response['otl'] && typeof response['otl'][ActionItems['DELETE']] != 'undefined'  ?  true : false; 
    });
  }

 
  navigate(){
    this._otlMasterService.navigate()
  }
  navigateToEditOtl(){
    this._otlMasterService.navigateEditOtl(this.otlId)
  }
  deleteOtl(){
    this._PromptService.openDialog({title : 'Delete OTL',btnLabel : 'CONFIRM',content :'Are you sure you want to delete this OTL?'}, response =>{
      if (response){
        this._hospitalService.deleteOtl(this.otlId,(res)=>{
          this._otlMasterService.navigate();
        })
      }
    })
  }
}

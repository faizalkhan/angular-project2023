import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OtlComponent } from './otl.component';
import { OtlListComponent } from './otl-list/otl-list.component';
import { OtlViewComponent } from './otl-view/otl-view.component';
import { Routes, RouterModule } from '@angular/router';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { PipeModule } from 'src/app/core/pipe/pipe.module';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { AgGridModule } from 'ag-grid-angular';
import { OtlAddComponent } from './otl-add/otl-add.component';


const routes: Routes = [{ 
  path:'', 
  component:OtlComponent,
  children:[{
    path: '',
    component:OtlListComponent
  },
  {
    path: 'view/:id',
    component:OtlViewComponent
  },
  {
    path: 'add',
    component:OtlAddComponent
  },
  {
    path:'edit/:id',
    component:OtlAddComponent
  }

]
}]


@NgModule({
  declarations: [OtlComponent, OtlListComponent, OtlViewComponent,OtlAddComponent],
  imports: [
    CommonModule,
    AppMaterialModule,
    RouterModule.forChild(routes),
    AgGridModule.withComponents([]),
    CustomFormsModule,
    PipeModule
  ],
  exports :[CustomFormsModule, AgGridModule, OtlComponent,OtlListComponent,OtlViewComponent,OtlAddComponent]

})
export class OtlModule { }

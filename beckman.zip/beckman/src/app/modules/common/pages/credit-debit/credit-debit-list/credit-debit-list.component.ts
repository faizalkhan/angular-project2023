import { Component, OnInit, HostListener } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { AgGridRouterComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-router.component';
import { IGetRowsParams } from 'ag-grid-community';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { Roles } from 'src/app/modules/auth/model/user';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { ActionItems } from 'src/app/core/services/constants';

@Component({
  selector: 'app-credit-debit-list',
  templateUrl: './credit-debit-list.component.html',
  styleUrls: ['./credit-debit-list.component.css']
})
export class CreditDebitListComponent implements OnInit {

  public columnDefs;
  public defaultColDef;
  public gridOptions;
  public gridApi; 
  public gridColumnApi;
  public searchValue;
  public custNameList = [];
  public gridData = [];
  public creditDebitForm: FormGroup;
  public role ;
  public moduleName ;
  public pageSize = 10;
  // public cpLogin = false;
  public isSecondaryLock = false;
  public creditPermission;
  public invoiceNumberList = [];
  public issuanceNumberList = [];
  public editCreditPermission = false;
  public editDC = false;
  public isAdmin:boolean = false;
  public cpList = [];
  public isChannelPartner;
  public displayChannelPartnerKeys = ['name', 'cpnumber']
  public displayChannelPartnerKeys1 = ['name', 'custNumber'];
  public displaychannelPartnerKeys2 = ['Name', 'issuanceBased']

 public IssuanceBasedValue = [];
 public selectedvalue: any;
  constructor(private _secondarySalesService: SecondarysalesService,private _UtilsService : UtilsService, private _storageService: StorageService,
  private _momentService: MomentService, private fb: FormBuilder, private _bookingService: CpbookingService, private _PermissionMenuListService:PermissionMenuListService,
 private _formValidator: FormValidatorService, private _StorageService: StorageService) { }
 @HostListener('window:resize', ['$event'])onResize(event) {
  this.gridApi.sizeColumnsToFit();
}
  ngOnInit() {
    this.checkEditAccessControl();
    this.moduleName = this._UtilsService.moduleName();
    this.role = this._StorageService.getUserDetails().role;
    this.isAdmin = this.role == Roles.Admin ;
    this.isChannelPartner = this._UtilsService.isCpRole(this.role);
      this.loadPermissionList();
      this._secondarySalesService.getissuanceDeatails(response=>{
        this.IssuanceBasedValue = response;
      })
    // this.cpLogin = this._storageService.getUserDetails().role == Roles.Channel_Partner;
    if (this._storageService.getUserDetails().role == Roles.Channel_Partner) {
      this._secondarySalesService.cpModuleAccess(res => {
        this.isSecondaryLock = res['secondaryLock'] == 1 ? true : false 
        });
        
        this._secondarySalesService.getPrintDNoteConfiguration(res=>{
        }, 'isCreditnote');
    
    }
    this._secondarySalesService.getIssuanceList(response=>{
      this.issuanceNumberList = response.issuanceNumber;
      this.invoiceNumberList= this._UtilsService.getDistinctRecords(response.invoiceNumber,'invoiceNumber') 
    })


  

    this. loadCreditDebitFilterForm();
    this.setClientList ();
    this.setCPList();
    this.defaultColDef = {
      sortable: true,
      filter: true,
      resizable: true
    };

    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2
    };

    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.gridOptions.onFilterChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: 'id',
        headerName: 'S No.',
        width: 100,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
      },
      {
        headerName: 'Issuance Number',
        field: 'issuanceNumber',
        width: 250,
        cellRendererFramework: AgGridRouterComponent,
        cellRendererParams: {
          inRouterLink:'/'+this.moduleName+'/secondary-sales/credit/view',
          navigateId: 'id'
        },
      },
      {
        headerName: 'Issuance Date',
        field: 'issuanceDate',
        valueFormatter : this.formatDate.bind(this),
        width: 250,
      },
      {
        headerName: 'Type',
        field: 'type',
        valueFormatter : this.formatType.bind(this),
        width: 150,
      },
      {
        headerName: 'Issuance Based On',
        field: 'issuance_type',
        valueFormatter: this.formatIssuanceType.bind(this),
        width: 250,
      },
      // {
      //   headerName: 'Invoice Number',
      //   field: 'invoiceNumber',
      //   width: 190,
      
      //   comparator: (param1, param2) => {
      //     return this._UtilsService.numberSorting(param1,param2);
      //   },
      // },
      
      {
        headerName: 'Client Name',
        field: 'custName',
        width: 300,
      },
      
      {
        headerName: 'Net Amount', 
        field: 'net_amount',
        width: 200,
        comparator: (param1, param2) => {
          return this._UtilsService.numberSorting(param1,param2);
        },
        cellRenderer :(params) =>{

          return typeof params.value !== 'undefined' ?  "<div class = 'text-right'>" + this._UtilsService.rupeeFormat(this.RoundOFTwoDigit(params.value)) + "</div>"  : ''
        }
      },
      {
        field: 'isEditable',
        headerName: 'Action',
        sortable: false,
        filter: false, 
        width: 100,
        cellRendererFramework: AgGridMenuComponent,
        cellRendererParams:   (params) => {
          
         let menu=[{
            name: 'View',
            link: '/'+this.moduleName+'/secondary-sales/credit/view',
          }]
         if ((this.editCreditPermission && this.role != Roles.Channel_Partner)||(this.role == Roles.Channel_Partner && this.editCreditPermission  && ! this.isSecondaryLock && params.value  && this.editDC))
      {
           menu.push({
              name: 'Edit',
              link: '/'+this.moduleName+'/secondary-sales/credit/edit',
            })
          }
          return { 
            menu
          }

      }
    }]; 

  }



  
 


  onIssuanceBasedChange(value) {
    this.selectedvalue = value['value']
  }
  loadPermissionList(){
    this._PermissionMenuListService.getActionPermission({model : 'creditdebit'},response =>{
     this.creditPermission = response['creditdebit'];
      this.editCreditPermission = this.setActionsPermission('EDIT')
       })
  }

RoundOFTwoDigit(num: any){
      var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
      return number;
    }
  setActionsPermission(name){
 
    return this.creditPermission && typeof this.creditPermission[ActionItems[name]] != 'undefined' ? true : false;
 }
  setClientList(){
    this._bookingService.listHospital( res =>{
      this.custNameList = this._UtilsService.groupByMultipleKeys(res,['name','custNumber'])
    })
  }
  setCPList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpList = this._UtilsService.groupByMultipleKeys(res,['name','cpnumber'])   
    })
  }

  checkEditAccessControl(){
    this._bookingService.getPermissionAccessControls({module : 'Credit_Debit_Edit' },response =>{      
    this.editDC = response.parent_permission[0].is_allowed;
    })
  }


  formatDate(params){    
    return params.data ? this._momentService.getDateTimeFormat(params.data.created_on) : ''
  }
  /* Type is converted to uppercase */
  formatType(params){            
    return params.data ?  params.data['type'].charAt(0).toUpperCase() + params.data['type'].slice(1) : '';
  }
  /* Issuance type is converted to Camel case to be shown in List UI*/
  formatIssuanceType(params){      
    return params.data ?  params.data['issuance_type'] == 'quantity' ? 'Quantity': params.data['issuance_type'] == 'value' ? 'Value' : params.data['issuance_type'] == 'value_parts' ? 'Value-Parts' : params.data['issuance_type'] == 'value_invoice' ? 'Value-Invoice':'' : '';    
  } 

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.setCreditDebitParams()
  }

  setCreditDebitParams(){
    let data = {
      from_date : this._momentService.getFilterFormat(this.creditDebitForm.get('from_date').value),
      to_date : this._momentService.getFilterFormat(this.creditDebitForm.get('to_date').value, "toDate"),
    }
   return  this.getCreditDebitList(data);
  }

  getCreditDebitList(data ?:any) {
    let payload = {};
    var datasource = {
      getRows: (params: IGetRowsParams) =>{
        if (data) {
          payload = data;
        }
        payload['page_size'] =this.pageSize
        payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
        payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
        payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
          this._secondarySalesService.searchCreditDebitList(data,(res)=>{
            let length = res['total'];
            console.log("results", res['results']);
            this.gridData = res['results'];            
            params.successCallback(res['results'], length)
          })
      }
    }
      this.gridApi.setDatasource(datasource);
  }


  loadCreditDebitFilterForm(){
    this.creditDebitForm = this.fb.group({
      from_date:[this._momentService.deceedDate(new Date(),31)],
      to_date:[new Date()],
      //invoiceNumber: ['',this._formValidator.requireMatch],
      issuanceBased: ['', this._formValidator.requireMatch],
      custNumber: ['',this._formValidator.requireMatch],
      type: [''] ,
      issuanceNumber :['',this._formValidator.requireMatch],
      cpNumber : ['', this._formValidator.requireMatch],
      invoiceNumber: ['']
    },{ validator: this._formValidator.dateValidation('from_date', 'to_date') });
  }

  searchFilter(){
    if (this.creditDebitForm.valid){
    let payload =  this.getPayload(this.creditDebitForm.value);
    this.getCreditDebitList(payload);
   }
   }

  cancelFilter(){
    this.creditDebitForm.reset();
    this.creditDebitForm.get('from_date').setValue(this._momentService.deceedDate(new Date(),31));
    this.creditDebitForm.get('to_date').setValue(new Date())
    this.creditDebitForm.get('type').setValue('')

    this.setCreditDebitParams();
  }

  getPayload(payload) {
    let data = {};
    data['from_date'] = payload.from_date ? this._momentService.getFilterFormat(payload.from_date) : '';
    data['to_date'] = payload.to_date ? this._momentService.getFilterFormat(payload.to_date, "toDate") : '';
    data['issuance_type'] = payload.issuanceBased ? payload.issuanceBased.value : '';
    data['custNumber'] = payload.custNumber ? payload.custNumber.custNumber : '';
    data['type'] = payload.type ? payload.type : '';
    data['issuanceNumber'] = payload.issuanceNumber ? payload.issuanceNumber.issuanceNumber : '';
    data['cpNumber'] = payload.cpNumber ? payload.cpNumber.cpnumber : '';
    data['invoiceNumber'] = payload.invoiceNumber ? payload.invoiceNumber : '';

    return data;
  }

  exportCreditDebit() {
    let payload = this.getPayload(this.creditDebitForm.value);
    //payload['from_date'] = payload['from_date'] ?  payload['from_date'] : this._momentService.getFilterFormat(this._momentService.deceedDate(new Date(),90));
    //payload['to_date'] =  payload['to_date'] ?  payload['to_date'] : this._momentService.getFilterFormat(new Date(),"toDate");
    // this._secondarySalesService.exportSecondaryInvoiceFilter(payload);
       this._bookingService.exportCreditdebitNoteFilter(payload);
      

  }
 

  add(value:any){
    this._secondarySalesService.getPrintDNoteConfiguration(res=>{
    }, 'isCreditnote'); 
    localStorage.setItem('creditdebitvalue',value)
    
  }
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-credit-debit',
  templateUrl: './credit-debit.component.html',
  styleUrls: ['./credit-debit.component.css']
})
export class CreditDebitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

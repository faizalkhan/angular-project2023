import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { ErrorMessage, colorCodes, ActionItems, BILLING,SuccessMessage } from 'src/app/core/services/constants';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { CreditDebitPartsDialog, AddBeckmanInvoiceDialog, AddInParts, TaxDialog, EditValueParts, AddInputItems, 
  TaxValueFreeDialog, EditValueFreeAmount, TaxValueInvoiceDialog, ValueInvoiceDialog, ListShippingAddress } from '../../../dialogs/secondary-dialog/dialog.component';
import { MatDateFormats, MatDialog } from '@angular/material';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { Roles } from 'src/app/modules/auth/model/user';
import { PermissionMenuListService } from 'src/app/core/services/utils/permission-menu-list.service';
import { ThemeService } from 'ng2-charts';
import { AlertInvoice, AlertTax, AlertParts, AlertQuantity  } from '../../../dialogs/booking-dialog';

@Component({
  selector: 'app-credit-add',
  templateUrl: './credit-add.component.html',
  styleUrls: ['./credit-add.component.css']
})
export class CreditAddComponent implements OnInit {
  public creditId;
  public currentDate = new Date();
  public clientNames =[];
  public creditForm: FormGroup;
  public viewCredit =false
  public displayClientKeys = ['name','address','city','pincode']
  public clientNumber;
  public partsData = [];
  public netAmount = 0;
  public totalTax = 0;
  public packageAmount = 0;
  public calculatedDiscount = 0;
  public partsCurrentOptions = [];
  public cessAmount=0;
  public tcsAmount =0;
  public invoiceList =[];
  public creditData:any;
  public originalInvoiceData;
  public iGst = false;
  public value_free_iGst = false;
  public invoice_identifier: any;
  public IssuanceBasedValue: [];
  public IssuanceDebitValue: [];
  public CreditDebitValue= [];
  public isIssuance: boolean= false;
  public isclientSelect: boolean = true;
  public selected_customerNumber: any;
public selected_siteId: any;
public partsValue: any[];
public partsList: any;
 public selected_partsList = [];
 public invoice_value:any;
 public invoiceNum: any;
 public invoiceIde: any;
 public invoiceDate: any;
 public filter_data: any;
 public isDiscountShow: boolean=false;
 public ListArray :any;
 public filter_parts=[];
 public filter_invoice_parts = [];
 public filter_Arr=[];
 public remove_arr =[];
 public editpart_arr = [];
 public selected_issuanceBased = '';
 selectedIssuanceId = 1;
 public valuefree_netamount = 0
 public valuefree_totaltax =0;
 public valueinvoice_netamount = 0;
 public valueinvoice_totaltax =0;
 public value_partslist = [];
 public value_invoicelist=[]
 public filter_value_arr = [];
 public value_free_arr = [];
 public value_free_list = [];
 public invoiceList_with_tax = [];
 public login_cpNumber: any;
 public cpAddress ;
 public cpSiteList ;
 public shipSiteList ;
 public shipAddress ;
 public : any;
 public isshowCustomerAdress: boolean = false;
 
 public valuefree_form: FormGroup;
 public hospital_address: any;
 public issuance_Value: any;
 public creditdebit_value: any;
 public role;
 public accessControls = [];
 public cd_value: any;
 isAdmincpnumber : any;
 check_invoice_zero: boolean = false;
 check_parts_zero: boolean = false;
 check_value_free_zero: boolean = false;
 //public cpcheckbox : boolean = false;
 //public shipcheckbox : boolean = false;
 public currentlyCheckedbillbox :boolean;
 public currentlyCheckedshipbox :boolean;
public address_type: any;
//public value_free_netamount: any
 public tax_zero = [];
 public bill_to_cpSiteId;
 public billCheckbox:boolean;


 
  constructor(public route: ActivatedRoute,private _snackBar :SnackbarService,public _dialog: MatDialog,
     public _dialogRef: MatDialog, public _dialogRefe: MatDialog,public _dialogtaxRef: MatDialog, public dialogtaxInvoice: MatDialog,
      public  _dialogvalueRef: MatDialog, public inputdialog: MatDialog,public value_free_dialog: MatDialog, 
      value_free_edit_dialog: MatDialog, public address_dialog: MatDialog, public alert_tax: MatDialog, public ship_address_dialog: MatDialog,
    private _momentService: MomentService,private _storageService: StorageService,private _PermissionMenuListService:PermissionMenuListService,
     private _bookingService: CpbookingService,private _formValidator: FormValidatorService,private fb: FormBuilder, private _secondarySalesService: SecondarysalesService) { }

  ngOnInit() {
    this.role = this._storageService.getUserDetails()['role'];
    this.loadCurrentCPDeatils();
    this._secondarySalesService.getType(response=>{
      this.CreditDebitValue = response;
    })
    this._PermissionMenuListService.getActionPermission({model : 'creditdebit'},response =>{
       if ((!this.creditId && response['creditdebit'] && typeof response['creditdebit'][ActionItems['ADD']] == 'undefined') ||  (this.creditId && response['creditdebit'] && typeof response['creditdebit'][ActionItems['EDIT']] == 'undefined') ) {
        this._secondarySalesService.navigateCreditDebitList()
       }
    })
    if (this._storageService.getUserDetails().role == Roles.Channel_Partner) {
      this._secondarySalesService.cpModuleAccess(res => {
        if (res['secondaryLock'] == 1 ) this._secondarySalesService.navigateCreditDebitList();
      });
    }
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.creditId = parseInt(params.get('id'));
      if (this.creditId){
          this.getCreditDetails();          
          this.getInvoicePermissionAccessControl();
      }else{
      
          //get Hospital
          this.getDistinctHospital();
         
      }
    });
    this.loadCreditForm();
   if(JSON.parse(localStorage.getItem('creditdebitvalue')) == 1){
      this._secondarySalesService.getDebitissuanceDeatails(response=>{
      this.IssuanceBasedValue = response;
    })
    }
    else{
      this._secondarySalesService.getissuanceDeatails(response=>{
        this.IssuanceBasedValue = response;
      })
    }
 
   

    // this._secondarySalesService.getDebitissuanceDeatails(response=>{
    //   this.IssuanceDebitValue = response;
    // })
  


//  }
   
     //Calculate package Amount
     this.creditForm.get('packageAmount').valueChanges.subscribe((response) => { 
      this.packageAmount = Number(response);
    });
    //Calculate cess Amount
    this.creditForm.get('cess_amount').valueChanges.subscribe((response) => { 
      this.cessAmount = Number(response);
      // this.calculateDiscount();
    });
    //Calculate tcs Amount
    this.creditForm.get('tcs').valueChanges.subscribe((response) => { 
      this.tcsAmount = Number(response);
      // this.calculateDiscount();
    });
    //Calculate Discount value when discount value changes
    this.creditForm.get('discount_value').valueChanges.subscribe((response) => { 
      this.calculateDiscount();
    });

  //Calculate discount when discount type changes
    this.creditForm.get('discount_type').valueChanges.subscribe((response) => {
      this.creditForm.get('discount_value').reset();
      if (response == 0) this.creditForm.get('discount_value').setValidators([this._formValidator.noDecimalsValidation,this._formValidator.maxEqualLength(99)])
       if (response == 1) this.creditForm.get('discount_value').setValidators([this._formValidator.noDecimalsValidation, this._formValidator.maxEqualLength(this.netAmount -1) ])
    
    });


   

  
  
     }
  
  getInvoicePermissionAccessControl(){
    this._bookingService.getPermissionAccessControls({module : 'Credit_Debit_Edit'}, response =>{
        this.accessControls =  response.field_permission;
        if (!response.parent_permission[0].is_allowed &&  this.role != Roles.Admin)this.cancel();
        if (this.role == Roles.Channel_Partner &&  response.field_permission.length){
          this.getEditInvoiceAccessControl();
        }
       })
}
getEditInvoiceAccessControl(){
  this.accessControls.map((editControl) => {
      if(editControl.name == 'issuance_comment'){
        if(editControl['is_allowed']){
          this.creditForm.get('issuanceComment').enable();
        }else{
          this.creditForm.get('issuanceComment').disable();
        }
      }
   });
}
checkEditAccess(fieldName){
  if (this.role == Roles.Channel_Partner){
    let control  = this.accessControls.find(response => response['name'] == fieldName);
    if (control ){
     return  control['is_allowed'] ;
    }
  }else 
  return true;
}

editAccessTax(fieldName){

  if (this.role == Roles.Channel_Partner){
    let control  = this.accessControls.find(response => response['name'] == fieldName);
    if (control ){
     return  control['is_allowed'] ;
    }
  }else 
  return true;
}
editAccessAmount(fieldName){
  if (this.role == Roles.Channel_Partner){
    let control  = this.accessControls.find(response => response['name'] == fieldName);
    if (control ){
     return  control['is_allowed'] ;
    }
  }else 
  return true;

}

 
  // ---------- hospital api ---------
  getDistinctHospital(){
     this._bookingService.getDistinctHospitals({order_by:"name", model:"secondary"},(response => {
      this.clientNames = response;
     }));
  }
  loadCreditForm(){
   this.creditdebit_value = localStorage.getItem('creditdebitvalue');
   
   if(JSON.parse(localStorage.getItem('creditdebitvalue')) == 1){
    //this.creditdebit_value = 'debit'
    this.creditdebit_value = this.CreditDebitValue[0]
   }else{
    // this.creditdebit_value = 'credit'
    this.creditdebit_value = this.CreditDebitValue[1]
   }
    this.creditForm = this.fb.group({
      custName: [{value : '' , disabled: this.creditId ? true : false}, [Validators.required, this._formValidator.requireMatch]],
      custNumber: ['', Validators.required],
      siteId: ['', Validators.required],
      issuanceDate :[{value : new Date() , disabled: this.creditId ? true : false},Validators.required],
      issuanceComment :['',[Validators.required, this._formValidator.noWhitespaceValidation]],
      type :[{value : this.creditdebit_value , disabled: this.creditId ? true : false}],
      packageAmount: ['0'],
      discount_type: ['2'],
      discount_value: [''],
      tcs:['0',this._formValidator.withZeroAndNegativeValidation],
      cess_amount :['0', this._formValidator.withZeroAndNegativeValidation],
      cpNumber:[''],
      id :[''],
      issuanceBased:[{value:'',disabled:true},[Validators.required]],
      billCheckbox: ['', Validators.required],
      shipCheckbox: ['', Validators.required]

      

    });


  }
  // ---------------setting the credit note form  ------------------


  loadCurrentCPDeatils(){
    this._secondarySalesService.cpModuleAccess(res => {
      if(res){
        this.login_cpNumber = res['cpnumber'];
      }
      });
  }
getCreditDetails(){
  this._secondarySalesService.getCreditDetails(this.creditId, response =>{
    this.creditData= response;
    if(this.creditData){
      this.selected_customerNumber = this.creditData['custNumber'];
      this.selected_siteId = this.creditData['siteId'];
      this.bill_to_cpSiteId = this.creditData['bill_to_cpSiteId']
      this._secondarySalesService.getInvoiceNumber({ "custNumber":this.selected_customerNumber , "siteId" : this.selected_siteId }, (response) => {
        if (response.length) {
          this.invoiceList =response;
          if(this.role != Roles.Channel_Partner){
            this.isAdmincpnumber = this.invoiceList[0]['cpNumber'];
          }
          this.setCreditForm();
          
        }
      });

      
    }
    
   // this.setIssuanceValue(this.creditData['issuance_type'])
   
  })
}

setCreditForm(){
  this._secondarySalesService.getCreditDetails(this.creditId, response =>{
    this.creditData= response;
  });
 if(this.creditData.type == 'credit'){
  this.creditData.type = 'Credit';
  this.cd_value = 'credit';
 }else{
  this.creditData.type = 'Debit';
  this.cd_value = 'debit';
 }
  if(this.creditData.issuance_type == 'quantity'){
    this.creditData.issuance_type = 'Quantity'
    this.issuance_Value = 'quantity'
    this.loadCPaddress(this.creditData['bill_to_cpSiteId']);
    this.loadShipaddress(this.creditData['ship_to_cpSiteId']);
   
  }
  else if(this.creditData.issuance_type == 'value_parts'){
    this.creditData.issuance_type = 'Value-Parts'
    this.issuance_Value = 'value_parts'
    this.loadCPaddress(this.creditData['bill_to_cpSiteId']);
    this.loadShipaddress(this.creditData['ship_to_cpSiteId']);
  }
  else if(this.creditData.issuance_type == 'value'){
    this.creditData.issuance_type = 'Value';
    this.issuance_Value = 'value'
    this.loadCPaddress(this.creditData['bill_to_cpSiteId']);
    this.loadShipaddress(this.creditData['ship_to_cpSiteId']);
  //  if(this.creditData.)
  }
  else{
    this.creditData.issuance_type = 'Value-Invoice';
    this.issuance_Value = 'value_invoice';
    this.loadCPaddress(this.creditData['bill_to_cpSiteId']);
    this.loadShipaddress(this.creditData['ship_to_cpSiteId']);
  }
  this.creditForm.patchValue({
    custName : this.creditData.custName,
    custNumber : this.creditData['custNumber'],
    siteId : this.creditData['siteId'],
    invoiceNumber : this.creditData['invoiceNumber'],
    type : this.creditData.type,
    tcs: this.creditData.tcs ? this.creditData.tcs : 0,
    cess_amount : this.creditData.cess_amount ? this.creditData.cess_amount :0,
    discount_type : this.creditData.discount_type,
    discount_value : this.creditData.discount_value,
    cpNumber:this.creditData.cpNumber ,
    id : this.creditData.id,
    packageAmount: this.creditData.packageAmount ? this.creditData.packageAmount: 0,
    issuanceComment:this.creditData.issuanceComment,
    issuanceDate :this.creditData.issuanceDate,
    issuanceBased: this.creditData.issuance_type
    //invoiceDate :  this.creditData.invoiceDate
  })
  this.isIssuance = this.creditForm.get('issuanceBased').value ? true:false;
  
  if(this.creditData['print_address_type'] === 'bill_to' )
  {
   
    this.creditForm.patchValue({
      billCheckbox: true
   }); 

   this.creditForm.patchValue({
 

    shipCheckbox: false
 }); 

  }
  if(this.creditData['print_address_type'] === 'ship_to')
  {

    this.creditForm.patchValue({
    shipCheckbox: true
    }); 

    this.creditForm.patchValue({
     billCheckbox: false
    }); 




    //this.currentlyCheckedbillbox = false;
  //  this.currentlyCheckedshipbox  = true;
    //this.setshipCheckBox(false);
 
  }
  //this.currentlyCheckedbillbox = this.creditData['print_address_type'] === 'bill_to' ? true : true;
 // this.currentlyCheckedshipbox = this.creditData['print_address_type'] === 'ship_to' ? true : true;
 //  this.getInvoiceDeatils(this.creditData.invoiceIdentifier);
if(this.creditData.issuance_type == 'Value-Parts'){
  this.selectedIssuanceId = 4;
  this.value_partslist =  this.creditData['creditDebitParts'].map(part =>{
    let amount = part['net_amount'];
    let hssntax = part['HSSNtax'];
    part['igst'] = this.RoundOFTwoDigit((amount *hssntax)/100); 
     
    part['cgst'] = this.RoundOFTwoDigit((amount *hssntax)/200);
    part['sgst'] = this.RoundOFTwoDigit((amount *hssntax)/200);
    return part
   })
  this.loadvaluePartsTable(this.value_partslist)
} else if(this.creditData.issuance_type == 'Value'){
  this.selectedIssuanceId = 3;
  this.value_free_arr =  this.creditData['creditDebitParts'].map(part =>{
    let amount = part['net_amount'];
    let hssntax = part['HSSNtax'];
    part['igst'] = this.RoundOFTwoDigit((amount *hssntax)/100); 
     
    part['cgst'] = this.RoundOFTwoDigit((amount *hssntax)/200);
    part['sgst'] = this.RoundOFTwoDigit((amount *hssntax)/200);
    return part
   })
  this.loadValuesTable(this.value_free_arr)
}
else if(this.creditData.issuance_type == 'Value-Invoice'){
 // con
  this.selectedIssuanceId = 2;
  this.value_invoicelist =  this.creditData['creditDebitParts'].map(part =>{
    let amount = part['net_amount'];
    let hssntax = part['HSSNtax'];
    part['igst'] = (amount *hssntax)/100; 
     
    part['cgst'] = (amount *hssntax)/200;
    part['sgst'] = (amount *hssntax)/200;
    return part
   })
  this.loadInvoiceTable(this.value_invoicelist)
}
else{
  this.partsData = this.creditData['creditDebitParts'].map(part =>{
    // to maintain the remaning qty  invoiceqty -alreadyraisecreditqty -currentcreditqty
    part['alreadyRaiseCreditQty'] =  part['creditQuantity'];
    // for request purpose
    part['edited_quantity'] = part['creditQuantity'] ;
    let amount = part['net_amount'];
    let hssntax = part['HSSNtax'];
    part['igst'] = this.RoundOFTwoDigit((amount *hssntax)/100); 
     
    part['cgst'] = this.RoundOFTwoDigit((amount *hssntax)/200);
    part['sgst'] = this.RoundOFTwoDigit((amount *hssntax)/200);

 
    return part
   })
this.getloadedparts(this.partsData);
}
  
}


setValidators(data){
  // this.creditForm.get('tcs').setValidators(this._formValidator.maxEqualLength(data.tcs))
  // this.creditForm.get('packageAmount').setValidators(this._formValidator.maxEqualLength(data.packageAmount))
  // this.creditForm.get('cess_amount').setValidators(this._formValidator.maxEqualLength(data.cess_amount))
//  this.creditForm.get('packageAmount').updateValueAndValidity();
 // this.creditForm.get('tcs').updateValueAndValidity();this.creditForm.get('cess_amount').updateValueAndValidity()

}


  //   end  // -------Set credit Form ---------------
 // -------------------form controls autocomplete ------------------
  clearDataOnClientChange(){
    this.partsData= [];
    this.value_invoicelist = [];
    this.value_partslist =[];
    this.value_free_arr = [];
  
    this.netAmount =0;
    this.totalTax =0;
    this.creditForm.patchValue({
      site_id: '',
      custNumber: '',
      tcs: '',
      cess_amount : '',
      discount_type : '',
      discount_value : '',
      invoiceNumber :'',
      packageAmount : ''
    })
  }
  onClientChange(value) {
    this.isclientSelect = false;
    this.creditForm.get('issuanceBased').enable();
    this.creditForm.get('issuanceBased').reset();
    
    this.isDiscountShow = false;
    this.filter_Arr=[]
    this.clearDataOnClientChange()
    if (value) { 
      this.creditForm.get('custNumber').setValue(value.custNumber);
      this.creditForm.get('siteId').setValue(value.site_id);
      this.creditForm.get('packageAmount').setValue(0);
      this.creditForm.get('cess_amount').setValue(0);
      this.creditForm.get('tcs').setValue(0);
      // get invoice number
      this.selected_customerNumber = value.custNumber;
      this.selected_siteId = value.site_id
     
    

      // this._secondarySalesService.getInvoiceListwithTax({ "custNumber":value.custNumber , "siteId" : value.site_id}, (response) => {
      //   if (response.length) {
      //     this.invoiceList_with_tax =response;
      //   }else {
      //     this._snackBar.loadSnackBar(ErrorMessage.NO_INVOICE_RAISED_FOR_THIS_HOSPITAL, colorCodes.ERROR);
      //   }
      // });
      if( this.selected_customerNumber && this.selected_siteId){
        this.loadCPaddress();
       this.loadShipaddress();
      }
    }
  }

  onIssuanceBasedChange(value) {
    this.partsData= [];
    this.value_partslist =[];
    this.value_free_arr = [];
    this.value_invoicelist = [];
    if(value){ 
      this.isIssuance = this.creditForm.get('issuanceBased').value['value'] ? true:false;
      this.selected_issuanceBased = value;
      if(this.selected_issuanceBased['id'] == 1){
        this.selectedIssuanceId = 1;
        this.creditForm.get('packageAmount').setValue(0);
        this.creditForm.get('cess_amount').setValue(0);
        this.creditForm.get('tcs').setValue(0);
        this._secondarySalesService.getInvoiceListwithTax({ "custNumber":this.selected_customerNumber, "siteId" : this.selected_siteId, 
        "type":this.creditForm.get('type').value['value'], "issuance_type":this.selected_issuanceBased['value']}, (response) => {
          if (response.length) {
            this.invoiceList =response;
          }else {
            this._snackBar.loadSnackBar(ErrorMessage.NO_INVOICE_RAISED_FOR_THIS_HOSPITAL, colorCodes.ERROR);
          }
        });
        
      } else if(this.selected_issuanceBased['id'] ==  2){
        this.issuance_Value = this.selected_issuanceBased['value'];
        this.selectedIssuanceId = 2; 
        this.creditForm.get('packageAmount').setValue(0);
        this.creditForm.get('cess_amount').setValue(0);
        this.creditForm.get('tcs').setValue(0);       
        this._secondarySalesService.getInvoiceListwithTax({ "custNumber": this.selected_customerNumber, 
        "siteId" : this.selected_siteId,  "type":this.creditForm.get('type').value['value'], "issuance_type":this.selected_issuanceBased['value']}, (response) => {
          if (response.length) {
            this.invoiceList_with_tax =response;
          }else {
            this._snackBar.loadSnackBar(ErrorMessage.NO_INVOICE_RAISED_FOR_THIS_HOSPITAL, colorCodes.ERROR);
          }
        });
      }
      else if(this.selected_issuanceBased['id'] == 3){
        this.selectedIssuanceId = 3;
        this.creditForm.get('packageAmount').setValue(0);
        this.creditForm.get('cess_amount').setValue(0);
        this.creditForm.get('tcs').setValue(0);
        // this._secondarySalesService.getInvoiceListwithTax({ "custNumber":this.selected_customerNumber, 
        // "siteId" : this.selected_siteId,  "type":this.creditForm.get('type').value['value'], "issuance_type":this.selected_issuanceBased['value']}, (response) => {
        //   if (response.length) {
        //     this.invoiceList =response;
        //   }else {
        //     this._snackBar.loadSnackBar(ErrorMessage.NO_INVOICE_RAISED_FOR_THIS_HOSPITAL, colorCodes.ERROR);
        //   }
        // });
      }
      else{
        this.issuance_Value = this.selected_issuanceBased['value'];
        this.selectedIssuanceId = 4;
        this.creditForm.get('packageAmount').setValue(0);
        this.creditForm.get('cess_amount').setValue(0);
        this.creditForm.get('tcs').setValue(0);
        this._secondarySalesService.getInvoiceListwithTax({ "custNumber":this.selected_customerNumber, 
        "siteId" : this.selected_siteId,  "type":this.creditForm.get('type').value['value'], "issuance_type":this.selected_issuanceBased['value']}, (response) => {
          if (response.length) {
            this.invoiceList =response;
          }else {
            this._snackBar.loadSnackBar(ErrorMessage.NO_INVOICE_RAISED_FOR_THIS_HOSPITAL, colorCodes.ERROR);
          }
        });
        
      }
     
    }
  }
  onTypeChange(event:any){
    this.partsData= [];
    this.value_partslist =[];
    this.value_free_arr = [];
    this.value_invoicelist = [];
    this.creditForm.get('issuanceBased').reset();
 
    if(this.creditForm.get('type').value['value'] == 'credit' ){
    this._secondarySalesService.getissuanceDeatails(response=>{
      this.IssuanceBasedValue = response;
    })
  }
 else{
    this._secondarySalesService.getDebitissuanceDeatails(response=>{
      this.IssuanceBasedValue = response;
    })
  }
  }

 loadCPaddress(checkedId?: any){
      this._secondarySalesService.getCustomerAddress({"cpNumber": this.role!=Roles.Channel_Partner?this.isAdmincpnumber: this.login_cpNumber, "custNumber":this.selected_customerNumber , "siteId" : this.selected_siteId }, response=>{
      if(response){   
      if(this.creditId){
        let filtervalue = response['bill_to_cp_address'].filter(item => item['cpSiteId'] == checkedId);
        this.cpAddress = filtervalue[0];
        this.cpSiteList = response['bill_to_cp_address'];
        this.hospital_address = response['hospital_address'];
        this.isshowCustomerAdress = true;
        /* Tax based on state is calculated only for issuance type - Value */
       // if(this.selectedIssuanceId == 3){
          this.loadTaxBasedOnstate(this.cpAddress);
        //}


    





      }else{
        this.cpAddress = response['bill_to_cp_address'][0];
        this.cpSiteList = response['bill_to_cp_address'];
        this.hospital_address = response['hospital_address'];
        this.isshowCustomerAdress = true;
        /* Tax based on state is calculated only for issuance type - Value */
      //  if(this.selectedIssuanceId == 3){
          this.loadTaxBasedOnstate(this.cpAddress);
       // }
      }
      }
    })

 }


 loadShipaddress(checkedId?: any){
  this._secondarySalesService.getCustomerAddress({"cpNumber": this.role!=Roles.Channel_Partner?this.isAdmincpnumber: this.login_cpNumber, "custNumber":this.selected_customerNumber , "siteId" : this.selected_siteId }, response=>{
    if(response){      
    if(this.creditId){
      let filtervalue = response['ship_to_cp_address'].filter(item => item['cpSiteId'] == checkedId);
      this.shipAddress = filtervalue[0];
      this.shipSiteList = response['ship_to_cp_address'];
     // this.hospital_address = response['hospital_address'];
      this.isshowCustomerAdress = true;
      /* Tax based on state is calculated only for issuance type - Value */
     // if(this.selectedIssuanceId == 3){
      //  this.loadTaxBasedOnstate(this.cpAddress);
      //}

    }else{
      this.shipAddress = response['ship_to_cp_address'][0];
      this.shipSiteList = response['ship_to_cp_address'];
      //this.hospital_address = response['hospital_address'];
      this.isshowCustomerAdress = true;
      /* Tax based on state is calculated only for issuance type - Value */
    //  if(this.selectedIssuanceId == 3){
      //  this.loadTaxBasedOnstate(this.cpAddress);
     // }
    }
    }
  })

 }
 lisChannelPartnertAddress(){
  const dialogRef = this.address_dialog.open(ListShippingAddress, {
    width: '500px',
    data: {details: this.cpSiteList, currentAddressDetails:  this.cpAddress , type : 'Channel_Partner'}
  });
  dialogRef.afterClosed().subscribe(result => {
    if (result ) {
    this.cpAddress = result;
    this.loadTaxBasedOnstate(this.cpAddress);
    }
  });
 }
 listshipAddress(){
  const dialogRef = this.ship_address_dialog.open(ListShippingAddress, {
    width: '500px',
    data: {details: this.shipSiteList, currentAddressDetails:  this.shipAddress , type : 'Channel_Partner'}
  });
  dialogRef.afterClosed().subscribe(result => {
    if (result ) {
    this.shipAddress = result;
    }
  });
 }
loadTaxBasedOnstate(selectAddress: any){
  if(selectAddress['cpSiteAddress']['state'] == this.hospital_address['address']['state']){
      this.value_free_iGst = false;
  }else{
    this.value_free_iGst =true;
  }

}

  onInvoiceChange(value){
    this.filter_parts =[];
    this.invoice_identifier = value.invoiceIdentifier;
    this.partsList =  [];
    this.value_free_arr =[];
    this.value_partslist =[];
    this.netAmount =0;
    this.totalTax =0;
    this.creditForm.patchValue({
      tcs: '0',
      cess_amount : '',
      discount_type : '',
      discount_value : ''
    })
      if (value['array'].length) {
      
        if(!this.partsData.length){
          this.partsData=[];
         this.filter_parts = value['array'];
         this.calculatePartsTax();
       this.partsData = this.partsData.concat(this.filter_parts)
    
     
        }
        else{
          value['array'] =   value['array'].filter(res=> !this.partsData.some(part => (part['partNumber'] == res['partNumber'] && part['lotNumber'] == res['lotNumber'] 
          && part['invoiceNumber'] == res['invoiceNumber'] )));
  
          if(value['array'].length){
            this.filter_parts = value['array'];
            this.calculatePartsTax();
           
          this.partsData =this.partsData.concat(this.filter_parts);
        }
     
          }
          if(!this.creditId){
           
          this.onLoadDiscount(this.filter_parts, this.invoice_identifier);       
          }
          // else{
          //   this.onLoadDiscount(this.partsData,this.invoice_identifier);
          // }
  
      }else {
        this._snackBar.loadSnackBar(ErrorMessage.NO_OTLNUMBER_STOCK, colorCodes.ERROR);
      }
  }
  

  onLoadDiscount(partsList, invoice_identifier){
      partsList.filter((item:any)=>{
        var i = this.filter_Arr.findIndex(x => (x.invoiceNumber == item.invoiceNumber && x.partNumber == item.partNumber));
        if(i <= -1){
              this.filter_Arr.push(item);
        }
        return null;
      });
      if(this.filter_Arr.length == 1){
        this.isDiscountShow = true;
        this._secondarySalesService.getInvoiceNumber({invoiceIdentifier :invoice_identifier}, (response) => {
          this.invoice_value = response;
          if(this.invoice_value){
            this.creditForm.get('id').setValue(this.invoice_value[0].id);
            this.creditForm.get('discount_type').setValue(this.invoice_value[0].discount_type);
            this.creditForm.get('discount_value').setValue(this.invoice_value[0].discount_value);
            // this.creditForm.get('packageAmount').setValue(this.invoice_value[0].packageAmount);
            // this.creditForm.get('cess_amount').setValue(this.invoice_value[0].cess_amount);
            // this.creditForm.get('tcs').setValue(this.invoice_value[0].tcs);
            this.creditForm.get('packageAmount').setValue(0);
            this.creditForm.get('cess_amount').setValue(0);
            this.creditForm.get('tcs').setValue(0);
            this.creditForm.get('cpNumber').setValue(this.invoice_value[0].cpNumber);
            this.getInvoiceDeatils(invoice_identifier)

          }
         })
      }else{
        this.isDiscountShow = false;
        this.creditForm.get('discount_type').setValue(2);
        this.creditForm.get('discount_value').setValue(0);
        this.creditForm.get('packageAmount').setValue(0);
        this.creditForm.get('cess_amount').setValue(0);
        this.creditForm.get('tcs').setValue(0);

        this.getInvoiceDeatils(invoice_identifier)
      }
  }

  calculatePartsTax(){
    this.filter_parts = this.filter_parts.map(part =>{
      part['alreadyRaiseCreditQty'] =  part['creditQuantity'];
      part['creditQuantity'] = part['quantity'] - part['creditQuantity'] ;
     part['remainingUpdatedQuantity'] = Math.abs(part.quantity  - part.alreadyRaiseCreditQty - part.creditQuantity) 
     let amount = part['price']* part['creditQuantity'];
     let hssntax = part['HSSNtax'];
     part['igst'] = this.RoundOFTwoDigit((amount *hssntax)/100); 
      
     part['cgst'] = this.RoundOFTwoDigit((amount *hssntax)/200);
     part['sgst'] = this.RoundOFTwoDigit((amount *hssntax)/200);

      return part
     })
   }

   getInvoiceDeatils(invoiceNo){
    this._secondarySalesService.listInvoices({invoiceIdentifier : invoiceNo}, (response) => {
      this.checkTax( response[0].address.find(res => res.type == BILLING), response[0].cpSiteAddress)
      this.setValidators(response[0]);
      // if (this.creditId){
      //   this.originalInvoiceData = response[0];
      // }
        this.loadPartsTable(this.partsData)
    },
      (error) => {}); 
    }
    getloadedparts(parts){
      parts.filter((item:any)=>{
        var i = this.editpart_arr.findIndex(x => (x.invoiceNumber == item.invoiceNumber && x.partNumber == item.partNumber));
        if(i <= -1){
              this.editpart_arr.push(item);
        }
        return null;
      });
      if(this.editpart_arr.length == 1){

        this.isDiscountShow = true;
      }else{
        this.isDiscountShow = false;
      }
      this.loadPartsTable(parts);
    }
  
 
  // // --------------------------- edit, delete dialog ----------
  editCreditParts(index){
    let part =  this.partsData[index];
    this._secondarySalesService.getPartsBasedOnInvoiceNo({invoiceIdentifier :part['invoiceIdentifier'], ungroup_parts : true, partNumber : part.partNumber,
   dcNumber:part.dcNumber,lotNumber : part.lotNumber,type:part.type, OTLNumber:part.OTLNumber}, (response) => { 
      this.partsData[index]['groupedData'] = response;
      if (!this.partsData[index]['validateQty']) 
      this.partsData[index]['validateQty'] = this.partsData[index]['creditQuantity'] + (this.partsData[index]['invoiceQuantity'] - response.reduce((currentStock, res ) =>currentStock + res['creditQuantity'] , 0));
      this.partsData[index]['stockAvailableQuantity'] = response.reduce((currentStock, res ) =>currentStock + res['stockAvailableQuantity'] , 0);
      this.editParts(index)
    })
  }
  editParts(index){
    if ( !this.partsData[index]['validateQty']) this.partsData[index]['validateQty'] = this.partsData[index]['creditQuantity'];
    let dialogRef = this.openCreditDebitDialog(this.partsData[index]);
    dialogRef.afterClosed().subscribe(result => { 
      if (result){
        if (!this.creditId){
          // adding 
          this.partsData[index]['creditQuantity'] = result['creditQty']
          this.partsData[index]['remainingUpdatedQuantity'] = Math.abs( this.partsData[index]['quantity'] -this.partsData[index]['alreadyRaiseCreditQty'] - this.partsData[index]['creditQuantity'])
          this.partsData[index]['net_amount'] = this.RoundOFTwoDigit(Number((this.partsData[index].price *  this.partsData[index]['creditQuantity']))); 

        }
         else if (this.creditId && this.partsData[index]['edited_quantity'] !=result['creditQty'] ) {
       
          if ((this.partsData[index]['creditQuantity'] - result['creditQty']) <= this.partsData[index]['stockAvailableQuantity']){
             this.partsData[index]['edited_quantity'] = result['creditQty'];
        
          
            this.partsData[index]['remainingUpdatedQuantity'] = Math.abs(result['creditQty']  - this.partsData[index]['creditQuantity'] -this.partsData[index]['remainingQuantity'])
           this.partsData[index]['net_amount'] = this.RoundOFTwoDigit(Number((this.partsData[index].price *  this.partsData[index]['edited_quantity'])));  
   
          }else{
              this._snackBar.loadSnackBar(ErrorMessage.CREDIT_QTY_REDUCED_PART_STOCK, colorCodes.ERROR);
          }
        }

        this.updateSinglePart(index );
      } })
  } 

  editTaxInParts( index){
    let dialogRefe = this.openTaxDialog(this.partsData[index]);
    dialogRefe.afterClosed().subscribe(result=>{
      if( result >= 0){
            this.partsData[index]['HSSNtax'] =result;
      
              this.partsData[index]['igst'] = this.RoundOFTwoDigit((this.partsData[index]['net_amount'] *this.partsData[index]['HSSNtax'])/100); 
      
              this.partsData[index]['cgst'] = this.RoundOFTwoDigit((this.partsData[index]['net_amount'] *this.partsData[index]['HSSNtax'])/200);
              this.partsData[index]['sgst'] = this.RoundOFTwoDigit((this.partsData[index]['net_amount'] *this.partsData[index]['HSSNtax'])/200);
        
           this.loadPartsTable(this.partsData);

          
      }
         // this.updateSinglePart(index);
        //}
    })
  }
  editTaxValueparts(index){
    let dialogRefe = this.openTaxDialog(this.value_partslist[index]);
    dialogRefe.afterClosed().subscribe(result=>{
        if(this.selectedIssuanceId ==  4){
          if(result>=0){
          this.value_partslist[index]['HSSNtax'] =result;
        //  if(this.value_partslist[index]['igst']){
            this.value_partslist[index]['igst'] = this.RoundOFTwoDigit((this.value_partslist[index]['net_amount'] *this.value_partslist[index]['HSSNtax'])/100); 
         // }else{
            this.value_partslist[index]['cgst'] = this.RoundOFTwoDigit((this.value_partslist[index]['net_amount'] *this.value_partslist[index]['HSSNtax'])/200);
            this.value_partslist[index]['sgst'] = this.RoundOFTwoDigit((this.value_partslist[index]['net_amount'] *this.value_partslist[index]['HSSNtax'])/200);
        //  }
         this.loadvaluePartsTable(this.value_partslist);
          }

        }
    
    });
  }
  editvalueparts(index){
    let value = this.value_partslist[index];
    let dialogRef = this.openedit_parts(this.value_partslist[index], this.creditId, this.creditdebit_value);
    dialogRef.afterClosed().subscribe(result =>{
      if(result){
        this.value_partslist[index]['net_amount'] = result;
     
          this.value_partslist[index]['igst'] = this.RoundOFTwoDigit((this.value_partslist[index]['net_amount'] *this.value_partslist[index]['HSSNtax'])/100); 
     
          this.value_partslist[index]['cgst'] = this.RoundOFTwoDigit((this.value_partslist[index]['net_amount'] *this.value_partslist[index]['HSSNtax'])/200);
          this.value_partslist[index]['sgst'] = this.RoundOFTwoDigit((this.value_partslist[index]['net_amount'] *this.value_partslist[index]['HSSNtax'])/200);
     
      }
      this.loadvaluePartsTable(this.value_partslist);
    })
 }
 editValueFreeparts(index:any){
  let value = this.value_free_arr[index];
  let dialogRef = this.openValueFreeEditParts(this.value_free_arr[index], index);
  dialogRef.afterClosed().subscribe(result =>{
    if(result){
      this.value_free_arr[index]['net_amount'] = result;
    //  if(this.value_free_arr[index]['igst']){
        this.value_free_arr[index]['igst'] = this.RoundOFTwoDigit((this.value_free_arr[index]['net_amount'] *this.value_free_arr[index]['HSSNtax'])/100); 
   //   }else{
        this.value_free_arr[index]['cgst'] = this.RoundOFTwoDigit((this.value_free_arr[index]['net_amount'] *this.value_free_arr[index]['HSSNtax'])/200);
        this.value_free_arr[index]['sgst'] = this.RoundOFTwoDigit((this.value_free_arr[index]['net_amount'] *this.value_free_arr[index]['HSSNtax'])/200);
     // }
    }
    this.loadValuesTable(this.value_free_arr);
  })

 }
 openedit_parts(value:any, editId: any, type: any){
   const dialog = this._dialogvalueRef.open(EditValueParts,{
    autoFocus: false,
    width: '750px',
    data: { "parts": value, 'creditId':editId? editId: 0, 'type': !this.creditId? this.creditForm.get('type').value['value'] : this.cd_value }
   })
   return dialog
 }
 openValueFreeEditParts(value, indexid){
  const dialog = this._dialogvalueRef.open(EditValueFreeAmount,{
    autoFocus: false,
    width: '750px',
    data: { "parts": value , "index":indexid  }
   })
   return dialog
 }
  openTaxDialog(value:any){
    const dialog = this.value_free_dialog.open(TaxDialog,{
      autoFocus: false,
      width: '750px',
      data: { "parts": value  }
    })
     return dialog;
  }
  updateSinglePart(index){
    if (this.creditForm.get('discount_type').value == 1) {
        this.calculatePartsTaxWithDiscountPrice();
    }
  //  else if (this.creditForm.get('discount_type').value == 0) {
  
  //   this.calculateSinglePart(index , this.partsData[index]['net_amount'] ? (this.partsData[index]['net_amount'] - ( this.partsData[index]['net_amount'] * (this.creditForm.get('discount_value').value/100))) : 0);
  
  // }
    
  else  this.calculateSinglePart(index , this.partsData[index]['net_amount']); 
    this.loadPartsTable(this.partsData);
  }

  openCreditDebitDialog(response){
    const dialogRef =  this._dialog.open(CreditDebitPartsDialog, {
      autoFocus: false,
      width: '950px',
      data: { "parts": response , 'invoiceNumber' :response['invoiceNumber'],
      // 'invoiceNumber' : this.creditId ? 
      // this.creditForm.get('invoiceNumber').value : response['invoiceNumber'] , 
      editCredit : this.creditId ? true : false }
      });
    return dialogRef;
  }
  deleteParts(index){
    this.remove_arr = [];
    this.partsData.splice(index, 1);
    this.partsData.filter((item:any)=>{
      var i = this.remove_arr.findIndex(x => (x.invoiceNumber == item.invoiceNumber && x.partNumber == item.partNumber));
      if(i <= -1){
            this.remove_arr.push(item);
      }
      //return null;
    });
    if(this.remove_arr.length == 1){
      this.isDiscountShow = true;
  //  if (this.creditForm.get('discount_type').value == 1) this.calculatePartsTaxWithDiscountPrice();
  //  this.checkPartsDataCount();
  this._secondarySalesService.getInvoiceNumber({invoiceIdentifier :this.remove_arr[0]['invoiceIdentifier']}, (response) => {
    this.invoice_value = response;
    if(this.invoice_value){
     // this.creditForm.get('id').setValue(this.invoice_value[0].id);
      this.creditForm.get('discount_type').setValue(this.invoice_value[0].discount_type);
      this.creditForm.get('discount_value').setValue(this.invoice_value[0].discount_value);
      this.creditForm.get('packageAmount').setValue(0);
      this.creditForm.get('cess_amount').setValue(0);
      this.creditForm.get('tcs').setValue(0);
      this.creditForm.get('cpNumber').setValue(this.invoice_value[0].cpNumber);
      //if (this.creditForm.get('discount_type').value == 1)
      // this.calculatePartsTaxWithDiscountPrice();
    }
   })
    }else{
      this.isDiscountShow = false;
    }
  
    this.checkPartsDataCount();
  }
 
  // // /---------------------Tax calucltion -----------------------------------
 
  loadPartsTable(result) {
    if (result && this.partsData) {
      this.netAmount= this.partsData.reduce((currentAmount, part)=>{
        return this.RoundOFTwoDigit(Number(currentAmount+ (part['price'] * (this.creditId ? part['edited_quantity'] :part['creditQuantity']))))
     
      },0)
   if(!this.creditId){
    this.totalTax = this.partsData.reduce((currentAmount, part)=>{
      return this.RoundOFTwoDigit(Number(currentAmount+ (this.value_free_iGst ? part['igst'] : (part['sgst'] + part['cgst']))))
    },0);

   }else{
    this.totalTax = this.partsData.reduce((currentAmount, part)=>{
      return this.RoundOFTwoDigit(Number(currentAmount+ ( this.value_free_iGst ? part['igst'] : (part['sgst'] + part['cgst']))));
    },0);
   }
     if ( !this.netAmount ){
        this.creditForm.get('discount_type').setValue('2');
        this.creditForm.get('discount_value').reset();
        this.calculatedDiscount = 0
      }
      if (this.creditForm.get('discount_type').value == 1)  this.creditForm.get('discount_value').setValidators([this._formValidator.noDecimalsValidation, this._formValidator.maxEqualLength(this.netAmount -1) ])
      this.calculateDiscount();
      
    }
  } 
  checkTax(billingAddress , cpsiteAddress) {
    if(billingAddress['state'].toLowerCase().replace(/\s/g,'')  ==  cpsiteAddress['state'].toLowerCase().replace(/\s/g,'')) {
      this.iGst = false;
    }
    else {
      this.iGst = true;
    }
  }
  // // -------------------------caluculate discount ------------------------------
  calculateDiscount() {
    if((this.creditForm.get('discount_type').value != 2  ) && this.creditForm.get('discount_value').value)
    {
       if(this.creditForm.get('discount_type').value == '0') this.calculatedDiscount = this.RoundOFTwoDigit(Number((this.netAmount) * (this.creditForm.get('discount_value').value/100))); 
       if(this.creditForm.get('discount_type').value == '1') this.calculatedDiscount = this.creditForm.get('discount_value').value; 
   }
   else {
       this.calculatedDiscount = 0;
   }

  }
  // tax should be caluclate after netamount is minus by discount amount  price

  calculatePartsTaxWithDiscountPrice(){

let partsQty = this.partsData.reduce((currentAmount, partData) => currentAmount +
 (!this.creditId &&partData.price ? partData.creditQuantity : (partData.edited_quantity && partData.price  ? 
  partData.edited_quantity : 0 ))  ,0) ;
// (!this.creditId &&partData.price ? partData.creditQuantity : (partData.creditQuantity && partData.price  ? 
//   partData.creditQuantity : 0 ))  ,0) ;
let singlePartDiscountAmt = this.creditForm.get('discount_value').value / partsQty;

this.partsData.map((part,index) => {
      let discountAmount = part['net_amount']  ? part['net_amount']  - 
      (singlePartDiscountAmt * (!this.creditId ? part.creditQuantity : part.edited_quantity) ) : 0; 
     // (singlePartDiscountAmt * (part.creditQuantity ) ) : 0; 
      if (discountAmount < 0) {
        this.creditForm.get('discount_type').setValue('2');
        this.creditForm.get('discount_value').reset();
        this.calculatePartsTaxWithDiscountPrice();
      }else {
      this.calculateSinglePart(index , discountAmount);
      }
      return part;
})
this.loadPartsTable(this.partsData)

  }
  calculateSinglePart(index, discountAmount){
    this.partsData[index]['cgst'] =  this.RoundOFTwoDigit(Number((discountAmount*(this.partsData[index].HSSNtax/2))/100)); 
        this.partsData[index]['sgst'] = this.RoundOFTwoDigit(Number((discountAmount*(this.partsData[index].HSSNtax/2))/100));
        this.partsData[index]['igst'] =  this.RoundOFTwoDigit(Number((discountAmount*this.partsData[index].HSSNtax)/100));
      }
  // tax should be caluclate after netamount is minus by discount amount  percentage
  calculatePartsTaxWithDiscountPercentage(){
          this.partsData.map((part,index) => {
              let netAmount = part['net_amount'] 
               this.calculateSinglePart(index , netAmount ? (netAmount - (netAmount * (this.creditForm.get('discount_value').value/100))) : 0);
              return part;
        })
        this.loadPartsTable(this.partsData)

  }
  // checking credit discount is not greater  than actual invoice discount   
  discountFocusOut(value){
    let originalAmount =  !this.creditData ?  this.creditForm.get('invoiceNumber').value.discount_amount : this.originalInvoiceData.discount_amount
    if (value &&  this.calculatedDiscount > originalAmount && !this.creditForm.get('discount_value').errors ){
      this._snackBar.loadSnackBar('Discount Value should be less than or equal to actual invoice   ' + originalAmount, colorCodes.ERROR);
    }else{
        
        if (this.creditForm.get('discount_type').value == 0) this.calculatePartsTaxWithDiscountPercentage();
        else if (this.creditForm.get('discount_type').value == 1) this.calculatePartsTaxWithDiscountPrice();

    }
    
  }
  //  disabling save button when  credit discount is not greater  than actual invoice discount  
  checkDiscountAmount(){
    if (this.creditForm.get('discount_type').value == 2 || !this.netAmount ) return true
    else if ( (this.originalInvoiceData ||this.creditForm.get('invoiceNumber').value.discount_amount ) ) {
      let originalAmount =  !this.creditData ?  this.creditForm.get('invoiceNumber').value.discount_amount : this.originalInvoiceData.discount_amount
       return  (this.calculatedDiscount > originalAmount || (this.creditForm.get('discount_type').value != 2 &&  (this.creditId ? this.creditForm.get('discount_value').value == null : !this.creditForm.get('discount_value').value)) ) ? false : true
    }    
    else{
      return true;
    }
  }
 
  // for delete parts 
  checkPartsDataCount() {
    if (this.partsData.length > 0){ 
       this.loadPartsTable(this.partsData);}
    else {
      this.netAmount = 0;
      this.totalTax = 0;
      this.creditForm.get('tcs').setValue('0')
      this.creditForm.get('cess_amount').setValue('0')
      this.creditForm.get('packageAmount').setValue('0')
      this.creditForm.get('discount_value').setValue('0')
      this.creditForm.get('discount_type').setValue('2')
      this.creditForm.get('type').setValue('credit')

    }
    this.calculateDiscount()
  }


  submit(){
    if(this.selectedIssuanceId == 4){
    let payload=this.creditForm.getRawValue();
    payload.cess_amount = payload.cess_amount ?payload.cess_amount : '0'
    payload.packageAmount = payload.packageAmount ?payload.packageAmount : '0'
    payload.tcs = payload.tcs ?payload.tcs : '0'
    payload.discount_value = '0'
    payload.discount_type =  '2'
    //payload.cp_address_id = this.cpAddress['cpSiteAddress']['id'];
    payload.bill_to_cpSiteId = this.cpAddress['cpSiteId'];
    payload.ship_to_cpSiteId = this.shipAddress['cpSiteId'];
    payload.print_address_type = this.address_type;
    payload.type = !this.creditId? this.creditForm.get('type').value['value'] : this.cd_value;
    payload.issuance_type = !this.creditId? this.creditForm.get('issuanceBased').value['value'] : this.issuance_Value;
    payload.total_amount = this.netAmount + this.totalTax + parseInt(payload.cess_amount)+parseInt(payload.packageAmount)+ parseInt(payload.tcs);
    payload.total_tax = this.totalTax;
    payload.net_amount = this.netAmount;
    payload.amount = this.bill_to_cpSiteId;
    payload['creditDebitParts'] = this.value_partslist;
    if(this.creditId){
      this._secondarySalesService.updateCredit(this.creditId ,payload)

    }else{
    payload.custName = this.creditForm.get('custName').value.name;
    payload.issuanceDate = payload.issuanceDate ? this._momentService.getIsoFormat(payload.issuanceDate): null;
   this._secondarySalesService.addCredit(payload)
    }

   }
   else if(this.selectedIssuanceId == 3){
    let  payload = this.creditForm.getRawValue();
    payload.cess_amount = payload.cess_amount ?payload.cess_amount : '0'
    payload.packageAmount = payload.packageAmount ?payload.packageAmount : '0'
    payload.tcs = payload.tcs ?payload.tcs : '0'
    payload.discount_value = '0'
    payload.discount_type =  '2'
   // payload.cp_address_id = this.cpAddress['cpSiteAddress']['id'];
    payload.bill_to_cpSiteId = this.cpAddress['cpSiteId'];
    payload.ship_to_cpSiteId = this.shipAddress['cpSiteId'];
    payload.print_address_type = this.address_type;
    payload.type = !this.creditId? this.creditForm.get('type').value['value'] : this.cd_value;
    payload.issuance_type = !this.creditId? this.creditForm.get('issuanceBased').value['value'] : this.issuance_Value;
    payload.total_amount = this.valuefree_netamount + this.valuefree_totaltax + parseInt(payload.cess_amount)+parseInt(payload.packageAmount)+ parseInt(payload.tcs);
    payload.total_tax = this.valuefree_totaltax;
    payload.net_amount =  this.valuefree_netamount;

    payload['creditDebitParts'] = this.value_free_arr;
   
    if(this.creditId){
      this._secondarySalesService.updateCredit(this.creditId ,payload)

    }else{
    payload.custName = this.creditForm.get('custName').value.name;
    payload.issuanceDate = payload.issuanceDate ? this._momentService.getIsoFormat(payload.issuanceDate): null;
    this._secondarySalesService.addCredit(payload)
    }
   }

   else if(this.selectedIssuanceId ==  2){
    let  payload = this.creditForm.getRawValue();
    payload.cess_amount = payload.cess_amount ?payload.cess_amount : '0'
    payload.packageAmount = payload.packageAmount ?payload.packageAmount : '0'
    payload.tcs = payload.tcs ?payload.tcs : '0'
    payload.discount_value = '0'
    payload.discount_type =  '2'
    //payload.cp_address_id = this.cpAddress['cpSiteAddress']['id'];
    payload.bill_to_cpSiteId = this.cpAddress['cpSiteId'];
    payload.ship_to_cpSiteId = this.shipAddress['cpSiteId'];
    payload.print_address_type = this.address_type;
    payload.type = !this.creditId? this.creditForm.get('type').value['value'] : this.cd_value;
    payload.issuance_type = !this.creditId? this.creditForm.get('issuanceBased').value['value'] : this.issuance_Value;
    payload.total_amount = this.valueinvoice_netamount + this.valueinvoice_totaltax + parseInt(payload.cess_amount)+parseInt(payload.packageAmount)+ parseInt(payload.tcs);
    payload.total_tax = this.valueinvoice_totaltax;
    payload.net_amount =  this.valueinvoice_netamount;
    payload['creditDebitParts'] = this.value_invoicelist;

    if(this.creditId){
      this._secondarySalesService.updateCredit(this.creditId ,payload)

    }else{
    payload.custName = this.creditForm.get('custName').value.name;
    payload.issuanceDate = payload.issuanceDate ? this._momentService.getIsoFormat(payload.issuanceDate): null;
  
    this._secondarySalesService.addCredit(payload)
    }
   }
   else{
   if(this.selectedIssuanceId ==  1){
    let payload=this.creditForm.getRawValue();
    payload.cess_amount = payload.cess_amount ?payload.cess_amount : '0'
    payload.packageAmount = payload.packageAmount ?payload.packageAmount : '0'
    payload.tcs = payload.tcs ?payload.tcs : '0'
   // payload.cp_address_id = this.cpAddress['cpSiteAddress']['id']
    payload.bill_to_cpSiteId = this.cpAddress['cpSiteId'];
    payload.ship_to_cpSiteId = this.shipAddress['cpSiteId'];
    payload.print_address_type = this.address_type;
    payload.discount_value = this.netAmount && payload.discount_value ?payload.discount_value : '0'
    payload.discount_type = this.netAmount && typeof payload.discount_type != 'undefined' ?payload.discount_type : '2'
    payload.discount_amount = this.calculatedDiscount  ? this.calculatedDiscount  : '0'
    payload.type = !this.creditId? this.creditForm.get('type').value['value'] : this.cd_value;
    payload.issuance_type = !this.creditId? this.creditForm.get('issuanceBased').value['value'] : this.issuance_Value
    payload['creditDebitParts'] = this.partsData;
    payload.total_amount = this.netAmount -this.calculatedDiscount + this.totalTax + parseInt(payload.cess_amount)+parseInt(payload.packageAmount)+ parseInt(payload.tcs);
    payload.total_tax = this.totalTax;
    payload.net_amount = this.netAmount;
    if (this.creditId){
     // payload.invoiceIdentifier = this.creditData['invoiceIdentifier'];
      this._secondarySalesService.updateCredit(this.creditId ,payload)
    }else{
      payload.custName = this.creditForm.get('custName').value.name;
      payload.issuanceDate = payload.issuanceDate ? this._momentService.getIsoFormat(payload.issuanceDate): null;
     this._secondarySalesService.addCredit(payload)
    }
   }
   }
  }

  cancel(){
     this._secondarySalesService.navigateCreditDebitList();
  }

  reset(){
    if (this.creditId){ 
      this.creditData['issuance_type'] ='quantity'
      this.setCreditForm();
    }
    
    else{
      this.isIssuance = false;
      this.partsData = [];
      this.creditForm.reset();
      this.creditForm.get('discount_type').setValue('2')
     // this.creditForm.get('type').setValue('credit')
     this.creditForm.patchValue({
       type: this.CreditDebitValue[1]
     })

      this.netAmount = 0;
      this.totalTax = 0;
      this.loadCPaddress();
    }
  }
resetValueParts() {
  if(!this.creditId){
    this.isIssuance = false;
    this.value_partslist =[];
    this.creditForm.reset();
  //  this.creditForm.get('type').setValue('credit')
  this.creditForm.patchValue({
    type: this.CreditDebitValue[1]
  })
    this.netAmount = 0;
    this.totalTax = 0;
    this.loadCPaddress();
  }else{
    this.creditData.issuance_type = 'value_parts'
    this.setCreditForm();
  }
  }

  resetValueFree(){
    if(!this.creditId){
      this.isIssuance = false;
      this.value_free_arr =[];
      this.creditForm.reset();
     // this.creditForm.get('type').setValue('credit')
     this.creditForm.patchValue({
      type: this.CreditDebitValue[1]
    })
      this.valuefree_netamount = 0;
      this.valuefree_totaltax = 0;
      this.loadCPaddress();
    }else{
      this.creditData.issuance_type = 'value'
      this.setCreditForm();
    }
  }


  viewCreditDetails(status, button =''){
    if(!this.creditId){
      if(this.creditForm.get('type').value['value'] == 'debit'){
        if(this.creditForm.get('issuanceBased').value['value'] == 'value_invoice'){
         
          this.check_invoice_zero =this.value_invoicelist.some(item=>item['net_amount'] == 0)
          if(this.check_invoice_zero){
            this.viewCredit = false;
            this._snackBar.loadSnackBar(SuccessMessage.DONT_ALLOW_ZERO_NETAMOUNT, colorCodes.ERROR);
          }else{
            this.viewCredit = status;
          }
        
       
        }
        else if(this.creditForm.get('issuanceBased').value['value'] == 'value_parts'){
       
          this.check_parts_zero = this.value_partslist.some(item=>item['net_amount'] == 0)
          if(this.check_parts_zero){
            this.viewCredit = false;
            this._snackBar.loadSnackBar(SuccessMessage.DONT_ALLOW_ZERO_NETAMOUNT, colorCodes.ERROR);
          }else{
            this.viewCredit = status;
          }
        }
        else{
            this.viewCredit = status;
         
        }
       
      }
      else{
        if(button == 'save'){
        if(this.creditForm.get('issuanceBased').value['value'] == 'quantity'){
          this.tax_zero = this.partsData.filter(item=>(item['price']>0 && item['HSSNtax'] == 0));
         }else if(this.creditForm.get('issuanceBased').value['value'] == 'value_parts'){
          this.tax_zero = this.value_partslist.filter(item =>item['HSSNtax'] == 0);
         }else if(this.creditForm.get('issuanceBased').value['value'] == 'value_invoice'){
          this.tax_zero = this.value_invoicelist.filter(item =>item['HSSNtax'] == 0);
         }
         else{
          this.tax_zero = this.value_free_arr.filter(item =>item['HSSNtax'] == 0);
         }
        if(this.tax_zero.length>0){
          let dialog = this.loadAlerttax();
          dialog.afterClosed().subscribe(result=>{
            if(result == 'ok'){
              this.viewCredit= status 
            }
          })
        }else{
          this.viewCredit= status 
        }
      }
      else{
        this.viewCredit = status;
      }
    
      }
    }
    else{
      if(button == 'save'){

        if(this.creditForm.get('issuanceBased').value == 'Quantity'){
          this.tax_zero = this.partsData.filter(item=>( item['price']>0 && item['HSSNtax'] == 0));
         }else if(this.creditForm.get('issuanceBased').value == 'Value_Parts'){
          this.tax_zero = this.value_partslist.filter(item =>item['HSSNtax'] == 0);
         }else if(this.creditForm.get('issuanceBased').value == 'Value-Invoice'){
          this.tax_zero = this.value_invoicelist.filter(item =>item['HSSNtax'] == 0);
         }
         else{
          this.tax_zero = this.value_free_arr.filter(item =>item['HSSNtax'] == 0);
         }
        if(this.tax_zero.length>0){
          let dialog = this.loadAlerttax();
          dialog.afterClosed().subscribe(result=>{
            if(result == 'ok'){
              this.viewCredit= status 
            }
          })
        }else{
          this.viewCredit= status 
        }
      }
      else{
        this.viewCredit = status;
      }
     // this.viewCredit = status;
    }
 
  }
  loadInvoice(){


    if(this.selectedIssuanceId == 2){



 
    let dialogRef = this.openInvoiceParts(this.invoiceList_with_tax, this.selected_customerNumber, this.selected_siteId, this.selectedIssuanceId);

     
 console.log(this.invoiceList_with_tax);



 
    dialogRef.afterClosed().subscribe(result => {
       if(result.length){   


        if(this.value_invoicelist[0])
        {
          
          this.value_invoicelist.forEach((e, index) => {

            if(this.value_invoicelist[index].invoiceIdentifier === result[0].invoiceIdentifier)
          {
             let dialogRefe = this.invoiceAlert();
              return;
          }
        
         });







       
        }

             this.loadValueInvoiceList({'array':result})
       }
     })

   }else{
    let dialogRef = this.openInvoiceParts(this.invoiceList, this.selected_customerNumber, this.selected_siteId, this.selectedIssuanceId);
    dialogRef.afterClosed().subscribe(result => {
  
    console.log(result);
      if(result.length){
        if(this.selectedIssuanceId == 2){
             this.loadValueInvoiceList({'array':result})
        }
        else{
        this.loadAddInParts(result);
        }
      }
     })
   }
  }
  
  loadAddInParts(data: any){ 
      let dialogRefe = this.openAddInParts(data, this.selected_issuanceBased, this.creditForm.get('type').value['value']);
      dialogRefe.afterClosed().subscribe((result) => {     
     
       if(result){
          if( this.selectedIssuanceId == 4){        
          
 if(this.value_partslist[0])
{
  this.value_partslist.forEach((e, index) => {
    if(this.value_partslist[index].partNumber === result.array[0].partNumber && this.value_partslist[index].lotNumber === result.array[0].lotNumber &&
      this.value_partslist[index].OTLNumber === result.array[0].OTLNumber &&  this.value_partslist[index].invoiceIdentifier === result['invoice_identifier'] )  {
     let dialogRefe = this.partsAlert();
    return;
  }    
  });
}           this.loadValuePartslist({'invoiceIdentifier':result['invoice_identifier'], 'array':result['array']});
          }
          else{

            if(this.partsData[0])
            {
              console.log("Quantity result", result);
             this.partsData.forEach((e, index) => {
                if(this.partsData[index].partNumber === result.array[0].partNumber && this.partsData[index].lotNumber === result.array[0].lotNumber &&
                this.partsData[index].OTLNumber === result.array[0].OTLNumber && this.partsData[index].invoiceIdentifier === result['invoice_identifier']) {
        
              let dialogRefe = this.quantityAlert();
            return;
          }
        
        
            });
        
          }
          this.onInvoiceChange({'invoiceIdentifier':result['invoice_identifier'], 'array':result['array']})
          }
        }
       
       })   
  }

  openInvoiceParts(value, cust_num, site_id, issuanceId){
    const dialogRef = this._dialogRef.open(AddBeckmanInvoiceDialog, {
      autoFocus: false,
      width: '750px',
      data:{ "currentData": value, 'customerNumber':cust_num, 'siteId':site_id,'IssuanceId': issuanceId, 
      'Issuancekey':this.issuance_Value}
    });
    return dialogRef;

  }
 
  openAddInParts(value: any, issuance:any, type:any){
    const dialogRef = this._dialogRefe.open(AddInParts,{
      autoFocus: false,
      width: '1000px',
      data:{ "selectedInvoiceValue": value, "selectedParts":this.selected_partsList,
       'SelectedIssuance': issuance, 'Issuancekey': this.issuance_Value, "selected_type": type }
    });
    return dialogRef;
  }
  loadValuePartslist(value:any){
    this.filter_value_arr =[];
    this.invoice_identifier = value.invoiceIdentifier;
    this.netAmount =0;
    this.totalTax =0;
    this.creditForm.patchValue({
      tcs: '0',
      cess_amount : '0',
      packageAmount: '0',
      
      discount_type : '',
      discount_value : ''
    })
      if (value['array'].length) {
      
        if(!this.value_partslist.length){
          this.value_partslist=[];
         this.filter_value_arr = value['array'];
        this.calculateValuepartsnetamount();
       this.value_partslist = this.value_partslist.concat(this.filter_value_arr)
      
     
        }
        else{
          value['array'] =   value['array'].filter(res=> !this.value_partslist.some(part => (part['partNumber'] == res['partNumber'] && part['lotNumber'] == res['lotNumber'] 
          && part['invoiceNumber'] == res['invoiceNumber'] )));
  
          if(value['array'].length){
            this.filter_value_arr = value['array'];
           this.calculateValuepartsnetamount();
          this.value_partslist =this.value_partslist.concat(this.filter_value_arr);
        }
       }
       this.getpartsInvoiceList(this.invoice_identifier) 
      }else {
        this._snackBar.loadSnackBar(ErrorMessage.NO_OTLNUMBER_STOCK, colorCodes.ERROR);
      }

  }
  calculateValuepartsnetamount(){

    this.filter_value_arr = this.filter_value_arr.map(part =>{
   
     let amount = part['net_amount'];
     let hssntax = part['HSSNtax'];
     part['igst'] = this.RoundOFTwoDigit((amount *hssntax)/100); 
      
     part['cgst'] = this.RoundOFTwoDigit((amount *hssntax)/200);
     part['sgst'] = this.RoundOFTwoDigit((amount *hssntax)/200);

      return part
     })

  }
  loadValueInvoiceList(value:any){
    this.filter_invoice_parts =[];
    this.invoice_identifier = value['array'][0].invoiceIdentifier;
    this.netAmount =0;
    this.totalTax =0;
    this.creditForm.patchValue({
      tcs: '0',
      cess_amount : '0',
      packageAmount: '0',
      discount_type : '',
      discount_value : ''
    })
      if (value['array'].length) {
      
        if(!this.value_invoicelist.length){
          this.value_invoicelist=[];
         this.filter_invoice_parts = value['array'];
          this.calculateValueInvoiceTax();
       this.value_invoicelist = this.value_invoicelist.concat(this.filter_invoice_parts)
      
     
        }
        else{
          value['array'] =   value['array'].filter(res=> !this.value_invoicelist.some(part => (part['invoiceNumber'] == res['invoiceNumber'] )));
  
          if(value['array'].length){
            this.filter_invoice_parts = value['array'];
            this.calculateValueInvoiceTax();
          this.value_invoicelist =this.value_invoicelist.concat(this.filter_invoice_parts);
        }
        
       } 
       this.loadInvoiceTable(this.value_invoicelist) 
      }else {
        this._snackBar.loadSnackBar(ErrorMessage.NO_OTLNUMBER_STOCK, colorCodes.ERROR);
      }

  }
  calculateValueInvoiceTax(){
    this.filter_invoice_parts = this.filter_invoice_parts.map(part =>{
   
      let amount = part['net_amount'];
      let hssntax = part['HSSNtax'];
      part['igst'] = this.RoundOFTwoDigit((amount *hssntax)/100); 
       
      part['cgst'] = this.RoundOFTwoDigit((amount *hssntax)/200);
      part['sgst'] = this.RoundOFTwoDigit((amount *hssntax)/200);
       return part
      })
  }
  getpartsInvoiceList(ident:any){
    this._secondarySalesService.listInvoices({invoiceIdentifier : ident}, (response) => {
      this.checkTax( response[0].address.find(res => res.type == BILLING), response[0].cpSiteAddress)
      this.setValidators(response[0]);
      // if (this.creditId){
      //   this.originalInvoiceData = response[0];
      // }
        this.loadvaluePartsTable(this.value_partslist)
    },
      (error) => {}); 

  }

  loadvaluePartsTable(result: any){
    if (result && this.value_partslist) {
      this.netAmount= this.value_partslist.reduce((currentAmount, part)=>{
        return this.RoundOFTwoDigit(Number(currentAmount+ (part['net_amount'])))
       // return Number((currentAmount+ (part['price'] * (part['creditQuantity']))).toFixed(2))
      },0)
   if(!this.creditId){
    this.totalTax = this.value_partslist.reduce((currentAmount, part)=>{
      return this.RoundOFTwoDigit(Number(currentAmount+ (this.value_free_iGst ? part['igst'] : (part['sgst'] + part['cgst']))))
    },0);
   }else{
    this.totalTax = this.value_partslist.reduce((currentAmount, part)=>{
      return this.RoundOFTwoDigit(Number(currentAmount+ (this.value_free_iGst ? part['igst'] : (part['sgst'] + part['cgst']))))
    },0);
   }      
    }

  }

  loadInvoiceTable(result:any){
    if(result && this.value_invoicelist){
      this.valueinvoice_netamount= this.value_invoicelist.reduce((currentAmount, part)=>{
        return this.RoundOFTwoDigit(Number(currentAmount+ (part['net_amount'])))
       // return Number((currentAmount+ (part['price'] * (part['creditQuantity']))).toFixed(2))
      },0)
   if(!this.creditId){
    this.valueinvoice_totaltax = this.value_invoicelist.reduce((currentAmount, part)=>{
      return this.RoundOFTwoDigit(Number(currentAmount+ (this.value_free_iGst ? part['igst'] : (part['sgst'] + part['cgst']))))
    },0);
   }else{
    this.valueinvoice_totaltax = this.value_invoicelist.reduce((currentAmount, part)=>{
      return this.RoundOFTwoDigit(Number(currentAmount+ (this.value_free_iGst ? part['igst'] : (part['sgst'] + part['cgst']))))
    },0);
   }     
    }
  }
  loadValuesTable(result: any){
   
    if(result && this.value_free_arr){
      this.valuefree_netamount= this.value_free_arr.reduce((currentAmount, part)=>{
        return this.RoundOFTwoDigit(Number(currentAmount+ (part['net_amount'])))
      
      },0)
   if(!this.creditId){
    this.valuefree_totaltax = this.value_free_arr.reduce((currentAmount, part)=>{
      return this.RoundOFTwoDigit(Number(currentAmount+ (this.value_free_iGst ? part['igst'] : (part['sgst'] + part['cgst']))))
    },0);
   }else{
    this.valuefree_totaltax = this.value_free_arr.reduce((currentAmount, part)=>{
      return this.RoundOFTwoDigit(Number(currentAmount+ ( this.value_free_iGst ? part['igst'] : (part['sgst'] + part['cgst']))))
    },0);
   }     
    }

  }
  editTaxValueFreeparts(index){

    let dialogRefe = this.openValueFreeTaxDialog(this.value_free_arr[index], index);
    dialogRefe.afterClosed().subscribe(result=>{
       if(result>=0){
          this.value_free_arr[index]['HSSNtax'] =result;
          
              this.value_free_arr[index]['cgst'] = this.RoundOFTwoDigit((this.value_free_arr[index]['net_amount'] *this.value_free_arr[index]['HSSNtax'])/200);
              this.value_free_arr[index]['sgst'] = this.RoundOFTwoDigit((this.value_free_arr[index]['net_amount'] *this.value_free_arr[index]['HSSNtax'])/200);
              this.value_free_arr[index]['igst'] = this.RoundOFTwoDigit((this.value_free_arr[index]['net_amount'] *this.value_free_arr[index]['HSSNtax'])/100);
          
           this.loadValuesTable(this.value_free_arr);

    }
        
    })
  }
  openValueFreeTaxDialog(value, indexid){
    const dialogRef = this.value_free_dialog.open(TaxValueFreeDialog,{
      autoFocus: false,
      width: '500px',
      data:{ "parts": value, "index":indexid}
    });
    return dialogRef;
  }
  deleteValueParts(index:any){
    this.value_partslist.splice(index, 1);
    this.loadvaluePartsTable(this.value_partslist)
  }
  deleteValueFreeParts(index:any){
    this.value_free_arr.splice(index,1);
    this.loadValuesTable(this.value_free_arr);
  }
  loadInputItems(){
    const dialogRefe = this.openInputItems(!this.creditId? this.creditForm.get('type').value['value'] : this.cd_value);
    dialogRefe.afterClosed().subscribe(result=>{
   
      if(result){
        let object = {
          'description':result['inputData']['description'],
          'net_amount':result['inputData']['creditvalue'],
          'HSSNtax':0,
          'igst':0,
          'sgst':0,
          'cgst':0,
        }
        this.value_free_arr.push(object);
        this.loadValuesTable(this.value_free_arr)
      }
    })

  
  }
  openInputItems(type: any){
    const dialogRef = this.inputdialog.open(AddInputItems, {
      autoFocus: false,
      width: '1000px',
      data:{ "currentData": '', "Creditdebittype": type}
    });
    return dialogRef;

  }


  deleteValueInvoice(index:any){
    this.value_invoicelist.splice(index, 1);
    this.loadInvoiceTable(this.value_invoicelist)
  }
  resetValueInvoice() {
    if(!this.creditId){
      this.isIssuance = false;
      this.value_invoicelist =[];
      this.creditForm.reset();
     // this.creditForm.get('type').setValue('credit')
     this.creditForm.patchValue({
      type: this.CreditDebitValue[1]
    })
      this.valueinvoice_netamount = 0;
      this.valueinvoice_totaltax = 0;
      this.loadCPaddress();
    }else{
      this.creditData.issuance_type = 'value_invoice'
      this.setCreditForm();
    }  
  }

 editValueInvoice(index){

    let dialogRefe = this.openValueInvoiceDialog(this.value_invoicelist[index], this.creditId, this.creditdebit_value);
    dialogRefe.afterClosed().subscribe(result=>{
        // if(result){
        //   this.value_invoicelist[index]['net_amount'] =result;          
        // }
        if(result){
          this.value_invoicelist[index]['net_amount'] =result;
          this.value_invoicelist[index]['igst'] = this.RoundOFTwoDigit((this.value_invoicelist[index]['net_amount'] *this.value_invoicelist[index]['HSSNtax'])/100); 
          this.value_invoicelist[index]['cgst'] = this.RoundOFTwoDigit((this.value_invoicelist[index]['net_amount'] *this.value_invoicelist[index]['HSSNtax'])/200);
          this.value_invoicelist[index]['sgst'] = this.RoundOFTwoDigit((this.value_invoicelist[index]['net_amount'] *this.value_invoicelist[index]['HSSNtax'])/200);
          }
          this.loadInvoiceTable(this.value_invoicelist);

    })
  }
  openValueInvoiceDialog(value:any, editId:any, type: any){
    const dialog = this._dialogtaxRef.open(ValueInvoiceDialog,{
      autoFocus: false,
      width: '750px',
      data: { "parts": value , 'creditId':editId? editId: 0, 'type': !this.creditId? this.creditForm.get('type').value['value'] : this.cd_value }
    })
     return dialog;
  }
  
  // Tax edit in value invoice
  editTaxInValueInvoice( index){
    let dialogInvoiceRefe = this.openTaxValueInvoiceDialog(this.value_invoicelist[index]);
    dialogInvoiceRefe.afterClosed().subscribe(result=>{
        if(result >=0){
          this.value_invoicelist[index]['HSSNtax'] =result;
      
            this.value_invoicelist[index]['igst'] = this.RoundOFTwoDigit((this.value_invoicelist[index]['net_amount'] *this.value_invoicelist[index]['HSSNtax'])/100); 
        
            this.value_invoicelist[index]['cgst'] = this.RoundOFTwoDigit((this.value_invoicelist[index]['net_amount'] *this.value_invoicelist[index]['HSSNtax'])/200);
            this.value_invoicelist[index]['sgst'] = this.RoundOFTwoDigit((this.value_invoicelist[index]['net_amount'] *this.value_invoicelist[index]['HSSNtax'])/200);            

        //  }
        this.loadInvoiceTable(this.value_invoicelist);
         // this.updateSinglePart(index);
       // }
    }
    })
  }
  openTaxValueInvoiceDialog(value:any){
    const dialog = this.dialogtaxInvoice.open(TaxValueInvoiceDialog,{
      autoFocus: false,
      width: '450px',
      data: { "parts": value  }
    })
     return dialog;
  }
  
  RoundOFTwoDigit(num: any){
    var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
    return number;
  }

   loadAlerttax(){
    const dialogRef = this.alert_tax.open(AlertTax, {
      autoFocus: false,
      width: '500px',
      data:{}
    });
    return dialogRef;
  } 
  invoiceAlert(){
    const dialogRef = this.alert_tax.open(AlertInvoice, {
      autoFocus: false,
      width: '500px',
      data:{}
    });
    return dialogRef;
  } 
  partsAlert(){
    const dialogRef = this.alert_tax.open(AlertParts, {
      autoFocus: false,
      width: '500px',
      data:{}
    });
    return dialogRef;
  }
  quantityAlert(){
    const dialogRef = this.alert_tax.open(AlertQuantity, {
      autoFocus: false,
      width: '500px',
      data:{}
    });
    return dialogRef;
  }
  setcpCheckBox(event: any){   
    
     if(event.checked)
     {
         this.creditForm.patchValue({
          shipCheckbox: false
         }); 
         this.currentlyCheckedbillbox = event.checked;  
         this.address_type = 'bill_to';
   
     }
     else if(event.checked == false){
        this.creditForm.patchValue({
        billCheckbox: ''
     });

     }
    }

    setshipCheckBox(event: any){   
      if(event.checked)
       {

        this.creditForm.patchValue({
          billCheckbox: false
         }); 
          
          this.currentlyCheckedbillbox = false;          
          this.currentlyCheckedshipbox = event.checked;  
          this.address_type = 'ship_to';
     
       }
       else if (event.checked == false){  
        this.creditForm.patchValue({
          billCheckbox: ''
       });  
       }
      }
  
 
} 
function id(id: any, arg1: (any: any) => any): any[] {
  throw new Error('Function not implemented.');
}


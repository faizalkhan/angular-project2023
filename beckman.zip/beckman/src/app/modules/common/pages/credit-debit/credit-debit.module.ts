import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreditDebitComponent } from './credit-debit.component';
import { CreditDebitListComponent } from './credit-debit-list/credit-debit-list.component';
import { CreditAddComponent } from './credit-add/credit-add.component';
import { CreditDebitDetailsComponent } from './credit-debit-details/credit-debit-details.component';
import { Routes, RouterModule } from '@angular/router';
import { AgGridModule } from 'ag-grid-angular';
import { CommonDialogModule } from '../../dialogs/common-dialog.module';
import { CreditDebitPartsDialog, AddBeckmanInvoiceDialog, AddInParts, TaxDialog, EditValueParts, AddInputItems, 
  TaxValueFreeDialog, EditValueFreeAmount, TaxValueInvoiceDialog, ValueInvoiceDialog, ListShippingAddress } from '../../dialogs/secondary-dialog/dialog.component';
  import { AlertInvoice, AlertTax, AlertParts, AlertQuantity } from '../../dialogs/booking-dialog';


const routes: Routes = [{ 
  path:'', 
  component:CreditDebitComponent,
  children:[{
    path: '', 
    component:CreditDebitListComponent
  },{
    path: 'add',
    component:CreditAddComponent
  },{
    path: 'view/:id',
    component:CreditDebitDetailsComponent
  },{
    path: 'edit/:id',
    component:CreditAddComponent
  }
]
}]

@NgModule({
  declarations: [CreditDebitComponent, CreditDebitListComponent,CreditAddComponent, CreditDebitDetailsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    AgGridModule.withComponents([]),
    CommonDialogModule,
  ],
  entryComponents:[CreditDebitPartsDialog, AddBeckmanInvoiceDialog, AddInParts, TaxDialog, EditValueParts, AddInputItems,
     TaxValueFreeDialog, EditValueFreeAmount, TaxValueInvoiceDialog, ValueInvoiceDialog, ListShippingAddress, AlertTax, AlertInvoice, AlertParts, AlertQuantity ],
})
export class CreditDebitModule { }

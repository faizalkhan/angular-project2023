import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { environment } from 'src/environments/environment';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { ActionItems } from 'src/app/core/services/constants';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { Roles } from 'src/app/modules/auth/model/user';

@Component({
  selector: 'app-credit-debit-details',
  templateUrl: './credit-debit-details.component.html',
  styleUrls: ['./credit-debit-details.component.css']
})
export class CreditDebitDetailsComponent implements OnInit {
  public creditId;
  public creditData;
  public moduleName;
  public serverUrl = environment.apiUrl;
  public editCreditPermission= false;
  public editCredit = false;
  public issuanceType =1;
  public login_cpNumber: any;
  public cp_address: any;
  public cpAddress: any;
  public cpSiteList:any;
  public hospital_address: any;
  public value_free_iGst: boolean= false;
  public role:any;
  public discount: any;
  public editDc = false;
  constructor( private router: Router,public route: ActivatedRoute,private _utilsService : UtilsService , public _CpbookingService: CpbookingService,private _storageService:StorageService,
    private _secondarySalesService: SecondarysalesService) { }

  ngOnInit() {
    this.role = this._storageService.getUserDetails()['role'];
  
      this.loadCurrentCPDeatils();
   // }
   
    this.moduleName = this._utilsService.moduleName()

    this.route.paramMap.subscribe((params: ParamMap) => {
      if(parseInt(params.get('id'))){
        this.creditId = parseInt(params.get('id'));
        this.getCreditDetails();
        if (this._storageService.getUserDetails().role !=Roles.Channel_Partner){
          this.editCredit  = true;
        }else{
          this.checkSecondaryLockAccess()
        }
      }
    });
    this._CpbookingService.getActionPermission({model : 'creditdebit'},response =>{ 
      this.editCreditPermission = response['creditdebit'] && typeof response['creditdebit'][ActionItems['EDIT']] != 'undefined' ? true : false;
   }) 
  }
  checkSecondaryLockAccess(){
    this._secondarySalesService.cpModuleAccess(res => {
      if (res['secondaryLock'] == 0 ) {
        this.editCredit = true;
        this.checkAccessControl();
      }else{
        this.editCredit= false
      }
    });
  }

  checkAccessControl(){
    this._CpbookingService.getPermissionAccessControls({module : 'Credit_Debit_Edit'},response =>{
      this.editDc = response.parent_permission[0]['is_allowed'];
    })
  }

  getCreditDetails(){
    this._secondarySalesService.getCreditDetails(this.creditId, response =>{
      this.creditData= response;
      if(this.creditData['type'] == 'credit'){
        this.creditData['type'] = 'Credit';
      }else{
        this.creditData['type'] = 'Debit';
      }
      if(this.creditData['issuance_type'] == 'value_parts'){
        this.creditData['issuance_type'] ='Value-Parts'
        this.issuanceType = 4;
        this.cp_address = this.creditData['bill_to_cpSiteId'];
        this.loadcurrentdetails( this.role != Roles.Admin ?this.login_cpNumber: this.creditData['cpNumber'],this.creditData.custNumber,this.creditData.siteId)
      }else if(this.creditData['issuance_type'] == 'value'){
        this.creditData['issuance_type'] ='Value'
        this.issuanceType = 3;
        this.cp_address = this.creditData['bill_to_cpSiteId'];
        this.loadcurrentdetails(this.role != Roles.Admin ?this.login_cpNumber: this.creditData['cpNumber'],this.creditData.custNumber,this.creditData.siteId)        
      }
      else if(this.creditData['issuance_type'] == 'value_invoice'){
        this.creditData['issuance_type'] ='Value-Invoice'
        this.issuanceType = 2;
        this.cp_address = this.creditData['bill_to_cpSiteId'];
        this.loadcurrentdetails(this.role != Roles.Admin ?this.login_cpNumber: this.creditData['cpNumber'],this.creditData.custNumber,this.creditData.siteId)
      }
      else{
        this.creditData['issuance_type'] ="Quantity";
        debugger;
        if(this.creditData['discount_type'] === 1)
        {
          this.discount = this.creditData['discount_value'].toFixed(2);
        }
        else if(this.creditData['discount_type'] === 0)
       {
        this.discount = ((this.creditData['net_amount'] * this.creditData['discount_value'])/100).toFixed(2);
        }
        else
      {
        this.discount = ((this.creditData['net_amount'] * this.creditData['discount_value'])/100).toFixed(2);
      }
        
        this.issuanceType = 1;
        this.cp_address = this.creditData['bill_to_cpSiteId'];
        this.loadcurrentdetails(this.role != Roles.Admin ?this.login_cpNumber: this.creditData['cpNumber'],this.creditData.custNumber,this.creditData.siteId)
      }
    })
  }
  loadCurrentCPDeatils(){
    this._secondarySalesService.cpModuleAccess(res => {
      if(res){
        this.login_cpNumber = res['cpnumber'];
      }
      });
  }
  loadTaxBasedOnstate(selectAddress: any){
    if(selectAddress['cpSiteAddress']['state'] == this.hospital_address['address']['state']){
        this.value_free_iGst = false;
    }else{
      this.value_free_iGst =true;
    }
  }
  loadcurrentdetails(login?: any, cpnum?:any, site_id?: any){
    this._secondarySalesService.getCustomerAddress({"cpNumber":login, 
    "custNumber":cpnum, "siteId" : site_id }, response=>{
      if(response){    
        let filtervalue = response['bill_to_cp_address'].filter(item => item['cpSiteId'] == this.cp_address);
        this.cpAddress = filtervalue[0];
        this.cpSiteList = response['cp_address'];
        this.hospital_address = response['hospital_address'];
        this.loadTaxBasedOnstate(this.cpAddress);
      }
    })
  }
 
  navigateEditCredit(){
    this._secondarySalesService.navigateCreditEdit(this.creditId);
  }

}

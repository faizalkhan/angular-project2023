import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog'
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { ErrorMessage, colorCodes, OTL_params } from 'src/app/core/services/constants';
import { CpbookingService } from '../../cpadmin/service/cpbooking.service';

// parts dialog 
@Component({
    selector: 'parts-dialog',
    templateUrl: 'parts-dialog.html',
    styles: [`.mat-dialog-container{
      padding : 0 !important;
      margin-top: 20px;
      margin-bottom: 20px;
  }`],
    encapsulation: ViewEncapsulation.None
  })
  export class PartsDialog implements OnInit {
    public displayPartsKeys = ['partNumber','description']
    public partsForm: FormGroup;
    public ncmsAvailableQty:number;
    public invoicedQuantity:number;
    constructor(
      public dialogRef: MatDialogRef<PartsDialog>, private fb: FormBuilder,private _formValidator: FormValidatorService,private _snackBar :SnackbarService, private _cpbookingService:CpbookingService,
      @Inject(MAT_DIALOG_DATA) public data) { }
  
    ngOnInit() {
      this.loadPartsForm();
      if (this.data.editParts) {
         this.invoicedQuantity = this.data.editParts['invoicedQuantity'];
         this.setPartsList(this.data.editParts);
        }
     
    }

  
    onQuantityChange(qty){
      if (qty ==0 || qty>0) {
        //this.data.partsOutput['total_amount'] =this.RoundOFTwoDigit(Number((this.data.partsOutput['price'] * qty - ((this.data.partsOutput['price'] * qty) * this.data.partsOutput['discount'])/100)));
        this.data.partsOutput['discount_amount'] = this.RoundOFTwoDigit(this.data.partsOutput['price'] * this.data.partsOutput['discount'] / 100);
        this.data.partsOutput['total_diff'] = this.data.partsOutput['price'] - this.data.partsOutput['discount_amount'];
        this.data.partsOutput['total_amount']  = this.data.partsOutput['total_diff'] * qty;
        this.data.partsOutput['cgst'] = this.RoundOFTwoDigit(Number(((this.data.partsOutput['total_amount']*(this.data.partsOutput['HSSNtax']/2))/100)));
        this.data.partsOutput['sgst'] = this.RoundOFTwoDigit(Number(((this.data.partsOutput['total_amount']*(this.data.partsOutput['HSSNtax']/2))/100))); 
        this.data.partsOutput['igst'] = this.RoundOFTwoDigit(Number(((this.data.partsOutput['total_amount']*this.data.partsOutput['HSSNtax'])/100))); 
        this.data.partsOutput['quantity'] = qty;
        
      }
    }
    RoundOFTwoDigit(num: any){
      var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
      return number;
    }

  
    loadPartsForm() {
      this.partsForm = this.fb.group({
        partNumber : [{value:'' ,disabled :true}],
        partsList: ['', [Validators.required,this._formValidator.requireMatch]],
        quantity: ['', [Validators.required,this._formValidator.negativeValidation, this._formValidator.noDecimalsValidation]],
      })
    }

    onPartsChange(value) {
      if (value.isActive == 0) {
        this._snackBar.loadSnackBar(  value.partNumber + "-"  + ErrorMessage.IN_ACTIVE_PARTS, colorCodes.ERROR);
        value = ''
      }
      
      this.partsForm.get('quantity').setValue(value.quantity)
      this.setPartAvailableQty(value)
      if (value.discount == 100 && this.data.OpfType == "OTL" ){
        value = '';
        this.partsForm.get('partsList').setValue('');
        this._snackBar.loadSnackBar(ErrorMessage.OTL_TYPE, colorCodes.ERROR);
      }
      
      this.data.partsOutput['partNumber'] = value.partNumber;
      this.data.partsOutput['price'] = value.price;
      this.data.partsOutput['total_amount'] = this.RoundOFTwoDigit(Number((value.price - (value.price * value.discount)/100)));
      this.data.partsOutput['discount'] = value.discount;
      this.data.partsOutput['description'] = value.description;
      this.data.partsOutput['HSSNcode'] = value.HSSNcode;
      this.data.partsOutput['HSSNtax'] = value.HSSNtax;
      this.data.partsOutput['lotNumber'] = value.lotNumber;
      this.data.partsOutput['lotExpiryDate']=value.lotExpiryDate;
      this.data.partsOutput['cgst'] = this.RoundOFTwoDigit(Number(((this.data.partsOutput['total_amount']*(value.HSSNtax/2))/100))); 
      this.data.partsOutput['sgst'] = this.RoundOFTwoDigit(Number(((this.data.partsOutput['total_amount']*(value.HSSNtax/2))/100))); 
      this.data.partsOutput['igst'] =  this.RoundOFTwoDigit(Number(((this.data.partsOutput['total_amount']*value.HSSNtax)/100))); 
      // this.data.partsOutput['id'] = value.id;
      this.data.partsOutput['quantity'] = this.partsForm.get('quantity').value;
    }
    setPartAvailableQty(value){
      if(this.data.OpfType === 'FOC-D' || this.data.OpfType === 'FOC-S' || this.data.OpfType === 'FOC-A') { 
        this.setNCMSAvailableQty(value)
       }else{
        this._cpbookingService.getOpfPartsQty({'partNumber' : value.partNumber,'cpnumber' : this.data.OTLNumber.cpnumber,  'OTLNumber': this.data.OTLNumber.OTLnumber,'opf_type' : this.data.OpfType == 'FOC' ? OTL_params[this.data.OpfType ]  :this.data.OpfType }, response => {
          this.ncmsAvailableQty = response['available_quantity'];
        })
       }
    }
    setNCMSAvailableQty(partValue){
      this.ncmsAvailableQty = this.data.editParts ? partValue.ncmsAvailableQty : partValue.cpAcknowledgedQty;
      this.data.partsOutput['salesOrderNumber'] = partValue.salesOrderNumber;
      this.data.partsOutput['salesOrderLineNumber'] = partValue.salesOrderLineNumber;
      this.partsForm.controls['quantity'].setValidators([this._formValidator.maxLength(this.data.editParts ? partValue.ncmsAvailableQty : partValue.cpAcknowledgedQty, 'AllowZero'), Validators.required, this._formValidator.noDecimalsValidation]);
      
    }
    setPartsList(value) {
      this.partsForm.get('quantity').setValidators([Validators.required,this._formValidator.noDecimalsValidation,this._formValidator.withZeroAndNegativeValidation])
      this.partsForm.get('partNumber').markAsTouched();
      this.partsForm.get('partsList').clearValidators();
      this.partsForm.get('partsList').updateValueAndValidity();
      this.partsForm.get('quantity').updateValueAndValidity();

      this.data.partsOutput['partNumber'] = value.partNumber;
      this.data.partsOutput['price'] = value.price;
      this.data.partsOutput['total_amount'] = this.RoundOFTwoDigit(Number(value.total_amount));
      this.data.partsOutput['discount'] = value.discount;
      this.data.partsOutput['id'] = value.id;
      this.data.partsOutput['description'] = value.description;
      this.data.partsOutput['HSSNcode'] = value.HSSNcode;
      this.data.partsOutput['HSSNtax'] = value.HSSNtax;
      this.data.partsOutput['lotNumber'] = value.lotNumber;
      this.data.partsOutput['lotExpiryDate']=value.lotExpiryDate;
      this.data.partsOutput['cgst'] = this.RoundOFTwoDigit(Number(((value.total_amount*(value.HSSNtax/2))/100))); 
      this.data.partsOutput['sgst'] = this.RoundOFTwoDigit(Number(((value.total_amount*(value.HSSNtax/2))/100))); 
      this.data.partsOutput['igst'] =this.RoundOFTwoDigit(Number(((value.total_amount*value.HSSNtax)/100)));
      this.data.partsOutput['opf_id'] = value.opf_id;
      this.data.partsOutput['OPFNumber'] = value.OPFNumber;
      this.partsForm.patchValue({
        quantity : value.quantity,
        partNumber : value.partNumber,
        
      })
      
      if(this.data.OpfType === 'FOC-D' || this.data.OpfType === 'FOC-S' || this.data.OpfType === 'FOC-A') { 
        this.setNCMSAvailableQty(value)
       }
       else{

         this.ncmsAvailableQty = value.ncmsAvailableQty ;
       }
    }
  

    dialogClose(): void {
      this.dialogRef.close();
    }
  
  
  }
  

  @Component({
    selector: 'ship-address-dialog',
    templateUrl: 'ship-address-dialog.html',
    styles: [`.mat-dialog-container {padding : 0 !important;margin-top: 20px;margin-bottom: 20px;
      overflow-y : auto;
      overflow-x :hidden;
    }
    .mat-dialog-content{overflow-x : hidden}
  .pointer:hover {cursor: pointer} 
  .pointer{margin-left: -12px;}
  `],
    encapsulation: ViewEncapsulation.None
  })
  export class ListShippingAddressDialog implements OnInit {
    constructor(
      public dialogRef: MatDialogRef<ListShippingAddressDialog>, private fb: FormBuilder,
      @Inject(MAT_DIALOG_DATA) public data) { }
    public currentAddress;
  
    ngOnInit() {
      this.onAddressChange(this.data.currentAddressDetails);
    }
  
    dialogClose(): void {
      this.dialogRef.close();
    }
    onAddressChange(currentAddress) {
     this.data.details.map(data =>{
       if (currentAddress && data['id'] == currentAddress['id']) {
         data['isActive'] = true;
       }else{
         data['isActive'] =  false;
       }
     })
  
      this.currentAddress = currentAddress;
    }
    changingAddress() {
      delete this.currentAddress.isActive;
      this.dialogRef.close(this.currentAddress);
    }
  }

  @Component({
    selector: 'alert-tax',
    templateUrl: 'alert-tax.html',
    styles: [`.mat-dialog-container {padding : 0 !important;margin-top: 20px;margin-bottom: 20px;
      overflow-x : hidden;
      overflow-y : auto;
    }.pointer:hover {cursor: pointer} .pointer{margin-left: -12px;}.bg-green{background:green !important;}
    thead  th {
      background-color: rgba(94, 88, 88, 0.15);
    }
    tr:nth-child(even) {
      background-color: rgba(174, 174, 174, 0.15);
  }
  .mat-checkbox-layout{
    font-size: 14px;
    color: #212529;
    font-weight: 500;
  }
   ` 
  ],
    encapsulation: ViewEncapsulation.None
  })
  export class AlertTax implements OnInit{
    constructor(public dialogRef: MatDialogRef<AlertTax>){}

    ngOnInit(): void {
        
    }
    dialogClose(){
      this.dialogRef.close('ok');
      
    }
    dialogClosecancel(){
      this.dialogRef.close('cancel')
    }

  }


  @Component({
    selector: 'alert-invoice',
    templateUrl: 'alert-invoice.html',
    styles: [`.mat-dialog-container {padding : 0 !important;margin-top: 20px;margin-bottom: 20px;
      overflow-x : hidden;
      overflow-y : auto;
    }.pointer:hover {cursor: pointer} .pointer{margin-left: -12px;}.bg-green{background:green !important;}
    thead  th {
      background-color: rgba(94, 88, 88, 0.15);
    }
    tr:nth-child(even) {
      background-color: rgba(174, 174, 174, 0.15);
  }
  .mat-checkbox-layout{
    font-size: 14px;
    color: #212529;
    font-weight: 500;
  }
   ` 
  ],
    encapsulation: ViewEncapsulation.None
  })
  export class AlertInvoice implements OnInit{
    constructor(public dialogRef: MatDialogRef<AlertInvoice>,
      
      @Inject(MAT_DIALOG_DATA) public data: any
      ){}

    ngOnInit(): void {
        
    }
    dialogClose(){
      this.dialogRef.close('ok');
      
    }
    dialogClosecancel(){
      this.dialogRef.close('cancel')
    }

  }


  @Component({
    selector: 'alert-addparts',
    templateUrl: 'alert-addparts.html',
    styles: [`.mat-dialog-container {padding : 0 !important;margin-top: 20px;margin-bottom: 20px;
      overflow-x : hidden;
      overflow-y : auto;
    }.pointer:hover {cursor: pointer} .pointer{margin-left: -12px;}.bg-green{background:green !important;}
    thead  th {
      background-color: rgba(94, 88, 88, 0.15);
    }
    tr:nth-child(even) {
      background-color: rgba(174, 174, 174, 0.15);
  }
  .mat-checkbox-layout{
    font-size: 14px;
    color: #212529;
    font-weight: 500;
  }
   ` 
  ],
    encapsulation: ViewEncapsulation.None
  })
  export class AlertParts implements OnInit{
    constructor(public dialogRef: MatDialogRef<AlertParts>,
      
      @Inject(MAT_DIALOG_DATA) public data: any
      ){}

    ngOnInit(): void {
        
    }
    dialogClose(){
      this.dialogRef.close('ok');
      
    }
    dialogClosecancel(){
      this.dialogRef.close('cancel')
    }

  }


  @Component({
    selector: 'alert-quantity',
    templateUrl: 'alert-quantity.html',
    styles: [`.mat-dialog-container {padding : 0 !important;margin-top: 20px;margin-bottom: 20px;
      overflow-x : hidden;
      overflow-y : auto;
    }.pointer:hover {cursor: pointer} .pointer{margin-left: -12px;}.bg-green{background:green !important;}
    thead  th {
      background-color: rgba(94, 88, 88, 0.15);
    }
    tr:nth-child(even) {
      background-color: rgba(174, 174, 174, 0.15);
  }
  .mat-checkbox-layout{
    font-size: 14px;
    color: #212529;
    font-weight: 500;
  }
   ` 
  ],
    encapsulation: ViewEncapsulation.None
  })
  export class AlertQuantity implements OnInit{
    constructor(public dialogRef: MatDialogRef<AlertQuantity>,
      
      @Inject(MAT_DIALOG_DATA) public data: any
      ){}

    ngOnInit(): void {
        
    }
    dialogClose(){
      this.dialogRef.close('ok');
      
    }
    dialogClosecancel(){
      this.dialogRef.close('cancel')
    }

  }
  
  
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListShippingAddressDialog, PartsDialog, AlertTax, AlertInvoice, AlertParts, AlertQuantity } from './booking-dialog';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { PipeModule } from 'src/app/core/pipe/pipe.module';
import { ReactiveFormsModule } from '@angular/forms';
import { AddShippingDialog, ListShippingAddress, AddPartsDialog, ReduceReverseDialog, DcToInvoicePartsDialog, 
  CreditDebitPartsDialog, AddBeckmanInvoiceDialog, AddInParts, TaxDialog, EditValueParts, AddInputItems, TaxValueFreeDialog, EditValueFreeAmount, TaxValueInvoiceDialog,
   ValueInvoiceDialog, AddStockSwapTransfer, BackTopartsDialog, CPRTBILLING, EditCPRT, EditStatus } from './secondary-dialog/dialog.component';



@NgModule({
  declarations: [PartsDialog,ListShippingAddressDialog, AddShippingDialog,ListShippingAddress, 
    CreditDebitPartsDialog, AddPartsDialog, TaxDialog, TaxValueFreeDialog,
    ReduceReverseDialog,DcToInvoicePartsDialog, AddBeckmanInvoiceDialog, AddInParts, EditValueParts, AddInputItems, EditValueFreeAmount, 
    TaxValueInvoiceDialog, ValueInvoiceDialog, AddStockSwapTransfer, BackTopartsDialog, CPRTBILLING, EditCPRT, EditStatus, AlertTax, AlertInvoice, AlertParts, AlertQuantity ],



  // declarations: [PartsDialog,ListShippingAddressDialog, AddShippingDialog,ListShippingAddress, CreditDebitPartsDialog,
  //    AddPartsDialog,ReduceReverseDialog,DcToInvoicePartsDialog, AddStockSwapTransfer, BackTopartsDialog],


  imports: [
    CommonModule,
    CustomFormsModule,
    PipeModule,
    ReactiveFormsModule,
    AppMaterialModule
  ],
  exports:[PartsDialog,ListShippingAddressDialog,
    AddShippingDialog,ListShippingAddress,AddPartsDialog,ReduceReverseDialog,DcToInvoicePartsDialog,CreditDebitPartsDialog, 
    AddBeckmanInvoiceDialog, AddInParts,TaxDialog, EditValueParts, AddInputItems, TaxValueFreeDialog, EditValueFreeAmount,
    TaxValueInvoiceDialog, ValueInvoiceDialog, AddStockSwapTransfer,BackTopartsDialog, CPRTBILLING,EditCPRT, EditStatus,AlertTax,
    CustomFormsModule,PipeModule,AppMaterialModule]
})
export class CommonDialogModule { }

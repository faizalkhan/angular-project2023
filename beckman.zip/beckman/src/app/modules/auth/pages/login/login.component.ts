import { AuthService } from './../../service/auth.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms'
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  constructor(private _authService: AuthService, private fb: FormBuilder, private _formValidator: FormValidatorService) { }
  get email() {
    return this.loginForm.get('email');
  }
  get password() {
    return this.loginForm.get('password');
  }
  get emailError() {
    return this.loginForm.get('email').errors;
  }
  get passwordError() {
    return this.loginForm.get('password').errors;
  }
  ngOnInit() {
    this.loginForm = this.fb.group({
      email: [null, [Validators.required, this._formValidator.emailValidation]],
      password: [null, Validators.required]
    })
  }

  onSubmit(): void {
    this._authService.login(this.loginForm.value,()=>{
      this.loginForm.reset();
    });
  }

}

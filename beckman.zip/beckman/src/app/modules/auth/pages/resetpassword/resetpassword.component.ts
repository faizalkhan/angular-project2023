import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { SettingsService } from 'src/app/modules/settings/service/settings.service';
import { AuthService } from '../../service/auth.service';

@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.css']
})
export class ResetpasswordComponent implements OnInit {
  resetPwdForm :FormGroup;
  constructor( private _router: Router, private _route: ActivatedRoute ,private _authService: AuthService, private fb: FormBuilder,  private _settingsService:  SettingsService,  private _formValidator: FormValidatorService) { }
  newPassword:any;
  checkPassword:any;
  ngOnInit() {
    this.loadNewPwdForm();
    this._settingsService.checkPassword(this._route.snapshot.params.token, this._route.snapshot.params.id,  (res)=>{
        this.resetPwdForm.reset();   
    })
    }
  onSubmit()
  {  
     this.newPassword = {
        "password": this.resetPwdForm.value.new_password       
        }         
      this._settingsService.resetPassword(this._route.snapshot.params.token, this._route.snapshot.params.id,this.newPassword,(res)=>{
        this.resetPwdForm.reset();  
        this._router.navigate(['auth']);       
     })     
  }

  loadNewPwdForm() { 
    this.resetPwdForm = this.fb.group({
      new_password: ['', Validators.required],
      confirm_new_password: ['', Validators.required]
    },
    { 
      validator: this._formValidator.ConfirmedValidator('new_password', 'confirm_new_password')
    });
  }


  get f(){
    return this.resetPwdForm .controls;
  }


}

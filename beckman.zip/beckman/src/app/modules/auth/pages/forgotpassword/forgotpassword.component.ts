import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { AuthService } from '../../service/auth.service';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {
  forgotForm :FormGroup;
  constructor(private _authService: AuthService, private fb: FormBuilder,  private _formValidator: FormValidatorService) { }
  ngOnInit() {
     this.forgotForm = this.fb.group({    
      email : [null, [Validators.required, this._formValidator.emailValidation]]  
     })
  }
  get email() {
    return this.forgotForm.get('email');
  }
  get emailError() {
    return this.forgotForm.get('email').errors;
  }
  onSubmit()
  {        
      this._authService.forgot(this.forgotForm.value,()=>{
        this.forgotForm.reset();   
      })
      
  }
}

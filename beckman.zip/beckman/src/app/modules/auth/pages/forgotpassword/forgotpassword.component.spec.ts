
import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { HttpClientModule } from '@angular/common/http';
import { ForgotpasswordComponent } from './forgotpassword.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { routes } from 'src/app/app-routing.module';



describe('ForgotpasswordComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes),
        AppMaterialModule,
        HttpClientModule,
        ReactiveFormsModule,
        FormsModule
      ],
     
      declarations: [
        ForgotpasswordComponent
      ],
    }).compileComponents();
   
  }));

  it('should create forgot password', () => {
    const fixture = TestBed.createComponent(ForgotpasswordComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

});



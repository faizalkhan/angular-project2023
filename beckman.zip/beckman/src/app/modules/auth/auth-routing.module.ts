import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthComponent } from './auth.component';

const routes: Routes = [{
    path: '',
    component: AuthComponent,
    children:[
        { 
            path:'login',
            loadChildren: () => import('./pages/login/login.module').then(m => m.LoginModule) 
        },
        {
            path:'forgot-password',
            loadChildren: () => import('./pages/forgotpassword/forgotpassword.module').then(m => m.ForgotpasswordModule)
        },
        {
            path:'reset-password/:token/:id',
            loadChildren: () => import('./pages/resetpassword/resetpassword.module').then(m => m.ResetpasswordModule)
        },
        {
            path: '',
            redirectTo: 'login',
            pathMatch: 'full'
        }
    ]
}]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }

export interface LoginPayload {
    email: string;
    password: string;
}

export interface ForgotPwd {
    email: string
}


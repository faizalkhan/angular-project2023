
import { TestBed, async, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { routes } from 'src/app/app-routing.module';
import { BeckmanComponent } from './beckman.component';
import { HttpClientModule } from '@angular/common/http';
import { LayoutModule } from 'src/app/layout/layout.module';




describe('BeckmanComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes),
        AppMaterialModule, 
        LayoutModule,
        HttpClientModule
      ],
      
      declarations: [
        BeckmanComponent
      ],
    }).compileComponents();
   
  }));

  it('should create the beckman', () => {
    const fixture = TestBed.createComponent(BeckmanComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

});



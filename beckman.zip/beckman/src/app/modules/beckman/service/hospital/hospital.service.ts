import { Injectable } from '@angular/core';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { HttpService } from 'src/app/core/services/http/http.service';
import { Endpoints, ApiMethod, colorCodes, SuccessMessage } from 'src/app/core/services/constants';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { Tab } from '../../../common/model/dynamic-tab.model';
import { Roles } from 'src/app/modules/auth/model/user';
import { StorageService } from 'src/app/core/services/storage/storage.service';

@Injectable({
  providedIn: 'root'
})
export class HospitalService {

  constructor(private _http: HttpService, private _StorageService: StorageService,private _snackBar: SnackbarService,private _router: Router) { }

  importHospital(hospitalFile,successResponseCallback) {
    this._http.requestCall(Endpoints.IMPORT_HOSPITAL, ApiMethod.POST, hospitalFile).subscribe(
      (res) => {
        successResponseCallback();
        this._snackBar.loadSnackBar(SuccessMessage.HOSPITAL_IMPORT, colorCodes.SUCCESS);
        return false;
      },
      (error) => {
        console.log(error);
      }
    );
  }

  listHospital(role,successResponseCallback, errorResponseCallback) {
    let endpoint = (role == Roles.Admin) ? Endpoints.LIST_HOSPITAL : ((role == Roles.Channel_Partner) ?  Endpoints.HOSPITAL_CP_SEARCH : Endpoints.HOSPITAL_SP_SEARCH  )
    this._http.requestCall(endpoint, ApiMethod.GET).subscribe(
      (res) => {
        successResponseCallback(res);
      },
      (error) => {
        errorResponseCallback(error);
      });
  }

  deleteHospital(hospitalId,successCallBack) {
    //Dynamically adding enum key pair
    Endpoints['DELETE_HOSPITAL'] = `/hospitals/${hospitalId.toString()}`;
    this._http.requestCall(Endpoints['DELETE_HOSPITAL'], ApiMethod.DELETE).subscribe(
      (res) => {
        successCallBack();
        this._snackBar.loadSnackBar(SuccessMessage.HOSPITAL_DELETE, colorCodes.SUCCESS);
        this.navigate();
      },
      (error) => {
        console.log(error);
      });
  }

  viewHospital (hospitalId,successCallBack){
    Endpoints['VIEW_HOSPITAL'] = `/hospitals/${hospitalId.toString()}`;
    this._http.requestCall(Endpoints['VIEW_HOSPITAL'], ApiMethod.GET).subscribe(
      (res) => {
        successCallBack(res);
      },
      (error) => {
        console.log(error);
      });
  }

  addHospital(hospitalPayLoad){
    this._http.requestCall(Endpoints['ADD_HOSPITAL'], ApiMethod.POST,hospitalPayLoad).subscribe(
      (res) => {
        this.navigate();
        this._snackBar.loadSnackBar(SuccessMessage.HOSPITAL_ADD, colorCodes.SUCCESS);
      },
      (error) => {
        console.log(error);
      });
  }

  exportHospital() {
    this._http.requestCall(Endpoints.EXPORT_HOSPITAL,ApiMethod.DOWNLOAD).subscribe(
      (res) => {
        var downloadLink = document.createElement("a");
        const blob = new Blob([res], { type: 'text/csv' });
        const url= window.URL.createObjectURL(blob);
        downloadLink.href = url;
        downloadLink.download = "HospitalMaster.csv";
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
        this._snackBar.loadSnackBar(SuccessMessage.HOSPITAL_EXPORT, colorCodes.SUCCESS);
        return false;
      },
      (error) => {
        console.log(error);
      }
    );
  }

  searchHospital (hospitalPayload, successResponseCallback , role ?:any) {
    let endpoint = role == Roles.Channel_Partner ?  Endpoints.HOSPITAL_CP_SEARCH :  Endpoints.ADD_HOSPITAL ;
    this._http.requestCall(endpoint, ApiMethod.GETPARAMS, hospitalPayload).subscribe(
      (res) => {
        successResponseCallback(res);
      },
      (error) => {
        console.log(error)
      });
  }

  editHospital(hospitalId, hospitalPayload, successResponseCallback) {
    Endpoints['EDIT_HOSPITAL'] = `/hospitals/${hospitalId.toString()}`;
    this._http.requestCall(Endpoints['EDIT_HOSPITAL'], ApiMethod.PUT, hospitalPayload).subscribe(
      (res) => {
        successResponseCallback(res);
        this._snackBar.loadSnackBar(SuccessMessage.HOSPITAL_EDIT, colorCodes.SUCCESS);
        this.navigate()
      },
      (error) => {
        console.log(error);
      });
  }

  getChannelPartner(successResponseCallback){
    this._http.requestCall(Endpoints['GET_PRODUCTLINE'], ApiMethod.GET).subscribe(
      (res) => {
        successResponseCallback(res);
      },
      (error) => {
        successResponseCallback([]);
        console.log(error);
      });
  }
  
  addOtl(otlPayload,successResponseCallback){
    this._http.requestCall(Endpoints['ADD_OTL'], ApiMethod.POST, otlPayload).subscribe(
      (res) => {
        successResponseCallback(res);
        this._snackBar.loadSnackBar(SuccessMessage.OTL_ADD, colorCodes.SUCCESS);
      },
      (error) => {
        console.log(error);
      });
  }


  viewOtl(otlID, successResponseCallback, errorResponseCallback) {
    Endpoints['VIEW_OTL'] = `/otl/${otlID.toString()}`;
    this._http.requestCall(Endpoints['VIEW_OTL'], ApiMethod.GET).subscribe(
      (res) => {
        successResponseCallback(res);
      },
      (error) => {
        errorResponseCallback(error);
      });
  }

  editOtl(otlID, otlPayload, successResponseCallback) {
    Endpoints['EDIT_OTL'] = `/otl/${otlID.toString()}`;
    this._http.requestCall(Endpoints['EDIT_OTL'], ApiMethod.PUT, otlPayload).subscribe(
      (res) => {
        successResponseCallback(res);
        this._snackBar.loadSnackBar(SuccessMessage.OTL_EDIT, colorCodes.SUCCESS);
      },
      (error) => console.log(error));
  }

  deleteOtl(otlID,successResponseCallback){
    Endpoints['DELETE_OTL'] = `/otl/${otlID.toString()}`;
    this._http.requestCall(Endpoints['DELETE_OTL'], ApiMethod.DELETE).subscribe(
      (res) => {
        successResponseCallback(res);
        this._snackBar.loadSnackBar(SuccessMessage.OTL_DELETE, colorCodes.SUCCESS);
      },
      (error) => {
        console.log(error);
      });

  }
 
  navigate(){

    let roles = this._StorageService.getUserDetails().role;
    if (roles == Roles.Admin)   this._router.navigate(['beckman/hospitals']);
    else if (roles == Roles.Channel_Partner)   this._router.navigate(['channel-partner/hospitals']);
    else if (roles == Roles.Agent)   this._router.navigate(['agent/hospitals']);
    else this._router.navigate(['beckman-billing/hospitals']);
  }

  navigateToEditHospital(id){
    let roles = this._StorageService.getUserDetails().role;
    if (roles == Roles.Admin)   this._router.navigate(['/beckman/hospitals/edit/' ,id]);
    else if (roles == Roles.Channel_Partner)   this._router.navigate(['channel-partner/hospitals/edit', id]);
    // else if (roles == Roles.Agent)   this._router.navigate(['agent/hospitals']);
    else this._router.navigate(['beckman-billing/hospitals/edit', id]);
  }


  exportHospitalFilter(hospitalPayload){
    this._http.requestCall(Endpoints.EXPORT_HOSPITAL,ApiMethod.DOWNLOAD_PARAMS,hospitalPayload).subscribe(
      (res) => {
        var downloadLink = document.createElement("a");
        const blob = new Blob([res], { type: 'text/csv' });
        const url= window.URL.createObjectURL(blob);
        downloadLink.href = url;
        downloadLink.download = "HospitalMaster.csv";
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
        return false;
      },
      (error) => {
        console.log(error);
      }
    );
  }

  listShippingAddress(hospitalId, successResponseCallback) {
    this._http.requestCall(Endpoints.ADD_SHIPPING_ADDRESS, ApiMethod.GETPARAMS, {custNumber:hospitalId}).subscribe(
      (res) => {
        successResponseCallback(res);
      },
      (error) => {
        console.log(error)
      });
  }
  


  //dynamic tabs 
  public tabs: Tab[] = [];
 
  public tabSub = new BehaviorSubject<Tab[]>(this.tabs);

  public addTab(tab: Tab) {
    if(this.tabs.length > 0){
      for (let i = 0; i < this.tabs.length; i++) {
        if (this.tabs[i].active === true) {
          this.tabs[i].active = false;
        }
      }
    }
    
    tab.id = this.tabs.length;
    tab.active = true;
    this.tabs.push(tab);
    // updating in subject
    this.tabSub.next(this.tabs);
  }

  public removeTab(index: number) {
    this.tabs.splice(index, 1);
    if (this.tabs.length > 0) {
      this.tabs[this.tabs.length - 1].active = true;
    }
    this.tabSub.next(this.tabs);
  }

  public resetTab(){
    this.tabs = [];
    this.tabSub.next([])
  }

  public editOtlData(data, index){
    for(let i=0; i<this.tabs.length;i++){
        if (i == index){
          this.tabs[i]['tabData'] = data;
        }
    }
    this.tabSub.next(this.tabs)
  }

}

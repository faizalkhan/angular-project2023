import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/core/services/http/http.service';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { Endpoints, ApiMethod, colorCodes, SuccessMessage } from 'src/app/core/services/constants';
import { Router } from '@angular/router';
import { Roles } from 'src/app/modules/auth/model/user';
import { StorageService } from 'src/app/core/services/storage/storage.service';

@Injectable({
  providedIn: 'root'
})
export class OtlmasterService {

  constructor(private _http:HttpService, private _StorageService: StorageService ,private _snackBar:SnackbarService, private _router: Router) { }

  importOtlMaster(otlMasterFile,successResponseCallback) {
    this._http.requestCall(Endpoints.IMPORT_OTLMASTER, ApiMethod.POST, otlMasterFile).subscribe(
      (res) => {
        successResponseCallback();
        this._snackBar.loadSnackBar(SuccessMessage.OTL_IMPORT, colorCodes.SUCCESS);
        return false;
      },
      (error) => {
        console.log(error);
      }
    );
  }

  exportOtlMaster() {
    this._http.requestCall(Endpoints.EXPORT_OTLMASTER,ApiMethod.DOWNLOAD).subscribe(
      (res) => {
        var downloadLink = document.createElement("a");
        const blob = new Blob([res], { type: 'text/csv' });
        const url= window.URL.createObjectURL(blob);
        downloadLink.href = url;
        downloadLink.download = "OTLMaster.csv";
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
        this._snackBar.loadSnackBar(SuccessMessage.OTL_EXPORT, colorCodes.SUCCESS);
        return false;
      },
      (error) => {
        console.log(error);
      }
    );
  }



  getOtlList(payload, successResponseCallback) {
    this._http.requestCall(Endpoints.GET_OTL_BY_SITE, ApiMethod.GETPARAMS,  payload).subscribe(
      (res) => {
        successResponseCallback(res);
      });
  }

  getDistinctHospitals(payload, successCallback) {
    this._http.requestCall(Endpoints.LIST_HOSPITAL, ApiMethod.GETPARAMS, payload).subscribe(
      (res) => { successCallback(res);},
      (error) => { console.log(error) }
    )
  }

  navigate() {
    let roles = this._StorageService.getUserDetails().role;
    if (roles == Roles.Admin)   this._router.navigate(['beckman/otl']);
    else if (roles == Roles.Channel_Partner)   this._router.navigate(['channel-partner/otl']);
     else if (roles == Roles.Agent)   this._router.navigate(['agent/otl']);
    else this._router.navigate(['beckman-billing/otl']);
  }

  navigateEditOtl(id) {
    let roles = this._StorageService.getUserDetails().role;
    if (roles == Roles.Admin)   this._router.navigate(['beckman/otl/edit',id]);
    else if (roles == Roles.Channel_Partner)   this._router.navigate(['channel-partner/otl/edit', id]);
     else if (roles == Roles.Agent)   this._router.navigate(['agent/otl/edit' ,id]);
    else this._router.navigate(['beckman-billing/otl/edit', id]);
  }
  groupUserEmail(successResponseCallback) {
    this._http.requestCall(Endpoints.GROUPED_USER_VIEW, ApiMethod.GET).subscribe(
      (res) => {
        successResponseCallback(res);
      });
  }

  exportOTLData(payload){
    this._http.requestCall(Endpoints.DOWNLOAD_OTLDATA,ApiMethod.DOWNLOAD_PARAMS,payload).subscribe(
      (res) => {
        var downloadLink = document.createElement("a");
        const blob = new Blob([res], { type: 'text/csv' });
        const url= window.URL.createObjectURL(blob);
        downloadLink.href = url;
        downloadLink.download = "OTL-Master.csv";
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
        this._snackBar.loadSnackBar(SuccessMessage.DOWNLOAD_OTL_DATA, colorCodes.SUCCESS);
        return false;
      },
      (error) => {
        console.log(error);
      }
    );
  }
}
 
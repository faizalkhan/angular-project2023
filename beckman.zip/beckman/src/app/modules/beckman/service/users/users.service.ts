import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { HttpService } from 'src/app/core/services/http/http.service';
import { Endpoints, ApiMethod, colorCodes, SuccessMessage } from 'src/app/core/services/constants';
import { Roles } from 'src/app/modules/auth/model/user';
import { StorageService } from 'src/app/core/services/storage/storage.service';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
 constructor(private _http: HttpService,private _StorageService: StorageService , private _snackBar: SnackbarService,private _router: Router) { }
  
 listUser(successResponseCallback, errorResponseCallback) {
    this._http.requestCall(Endpoints.USERS, ApiMethod.GET).subscribe(
      (res) => {
        successResponseCallback(res);
      },
      (error) => {
        errorResponseCallback(error);
      });
 }
 searchUser (userPayload, successResponseCallback) {
  this._http.requestCall(Endpoints.USERS, ApiMethod.GETPARAMS, userPayload).subscribe(
    (res) => {
      successResponseCallback(res);
    },
    (error) => {
      console.log(error)
    });
}
addUser(userPayload){
  this._http.requestCall(Endpoints.USERS, ApiMethod.POST,userPayload).subscribe(
    (res) => {
      this.navigateUsers()
      this._snackBar.loadSnackBar(SuccessMessage.USER_ADD, colorCodes.SUCCESS);
    },
    (error) => {
      console.log(error);
    });
}
viewUsers (userId,successCallBack){
  Endpoints['VIEW_USER'] = `/users/${userId.toString()}`;
   this._http.requestCall(Endpoints['VIEW_USER'], ApiMethod.GET).subscribe(
    (res) => {
      successCallBack(res);
    },
    (error) => {
      console.log(error);
    });
}

editUser(userId, userPayload) {
  Endpoints['EDIT_USER'] = `/users/${userId.toString()}`;
  this._http.requestCall(  Endpoints['EDIT_USER'], ApiMethod.PUT, userPayload).subscribe(
    (res) => {
      this._snackBar.loadSnackBar(SuccessMessage.USER_EDIT, colorCodes.SUCCESS);
      this.navigateUsers()
    },
    (error) => {
      console.log(error);
    }); 
}
deleteUser(userId,successCallBack) {
  Endpoints['DELETE_USER'] = `/users/${userId.toString()}`;
  this._http.requestCall(  Endpoints['DELETE_USER'], ApiMethod.DELETE).subscribe(
    (res) => {
      successCallBack(res);
      this._snackBar.loadSnackBar(SuccessMessage.USER_DELETE, colorCodes.SUCCESS);
    },
    (error) => {
      console.log(error);
    }); 
}
navigateUsers(){
  let roles = this._StorageService.getUserDetails().role;

  if (roles == Roles.Admin)   this._router.navigate(['beckman/users']);
  else if (roles == Roles.Channel_Partner)   this._router.navigate(['channel-partner/users']);
   else if (roles == Roles.Agent)   this._router.navigate(['agent/users']);
  else this._router.navigate(['beckman-billing/users']);
}



importUsers(userFile,successResponseCallback) {
  this._http.requestCall(Endpoints.IMPORT_USERS, ApiMethod.POST, userFile).subscribe(
    (res) => {
      successResponseCallback();
      this._snackBar.loadSnackBar(SuccessMessage.USER_IMPORT, colorCodes.SUCCESS);
      return false;
    },
    (error) => {
      console.log(error);
    }
  );
}

exportUsers() {
  this._http.requestCall(Endpoints.EXPORT_USERS, ApiMethod.DOWNLOAD).subscribe(
    (res) => {
      var downloadLink = document.createElement("a");
      const blob = new Blob([res], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      downloadLink.href = url;
      downloadLink.download = "Users.csv";
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      this._snackBar.loadSnackBar(SuccessMessage.USERS_EXPORT, colorCodes.SUCCESS);
      return false;
    },
    (error) => {
      console.log(error);
    }
  );

}

getBAaccessControl(successCallBack){
  this._http.requestCall(Endpoints.GET_BA_EDIT_ACCESS, ApiMethod.GET).subscribe(
    (res) => {
      successCallBack(res);
    });
}


getBAaccessControls(userFiles, successCallBack){
  this._http.requestCall(Endpoints.GET_BA_EDIT_ACCESS, ApiMethod.GETPARAMS, userFiles).subscribe(
    (res) => {
      successCallBack(res);
    });
}

}

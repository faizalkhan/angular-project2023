import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/core/services/http/http.service';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { Endpoints, ApiMethod, colorCodes, SuccessMessage } from 'src/app/core/services/constants';
import { Router } from '@angular/router';
import { Roles } from 'src/app/modules/auth/model/user';
import { StorageService } from 'src/app/core/services/storage/storage.service';



@Injectable({
  providedIn: 'root'
})
export class ChannelpartnerService {

  constructor(private _http: HttpService, private _StorageService: StorageService,private _snackBar: SnackbarService, private _router: Router) { }

  importChannelpartner(cpFile, successResponseCallback) {
    this._http.requestCall(Endpoints.IMPORT_CP, ApiMethod.POST, cpFile).subscribe(
      (res) => {
        successResponseCallback();
        this._snackBar.loadSnackBar(SuccessMessage.CP_IMPORT, colorCodes.SUCCESS);
        return false;
      },
      (error) => {
        console.log(error);
      }
    );
  }

  listChannelPartner( successResponseCallback, errorResponseCallback) {
    this._http.requestCall(Endpoints.LIST_CP, ApiMethod.GET).subscribe(
      (res) => {
        successResponseCallback(res);
      },
      (error) => {
        errorResponseCallback(error);
      });
  }

  viewChannelPartner(cpId, successResponseCallback, errorResponseCallback) {
    Endpoints['VIEW_CP'] = `/cp/${cpId.toString()}`;
    this._http.requestCall(Endpoints['VIEW_CP'], ApiMethod.GET).subscribe(
      (res) => {
        successResponseCallback(res);
      },
      (error) => {
        errorResponseCallback(error);
      });
  }

  exportChannelPartner() {
    this._http.requestCall(Endpoints.EXPORT_CP, ApiMethod.DOWNLOAD).subscribe(
      (res) => {
        var downloadLink = document.createElement("a");
        const blob = new Blob([res], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        downloadLink.href = url;
        downloadLink.download = "ChannelPartner.csv";
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
        this._snackBar.loadSnackBar(SuccessMessage.CP_EXPORT, colorCodes.SUCCESS);
        return false;
      },
      (error) => {
        console.log(error);
      }
    );
  }
  addChannelPartner(cpPayload) {

    this._http.requestCall(Endpoints['LIST_CP'], ApiMethod.POST, cpPayload).subscribe(
      (res) => {
        this._snackBar.loadSnackBar(SuccessMessage.CP_ADD, colorCodes.SUCCESS);
        this.navigateCP();
      },
      (error) => {
        console.log(error);
      });
  }

  editChannelPartner(cpId, cpPayload, successResponseCallback) {
    Endpoints['EDIT_CP'] = `/cp/${cpId.toString()}`;
    this._http.requestCall(Endpoints['EDIT_CP'], ApiMethod.PUT, cpPayload).subscribe(
      (res) => {
        successResponseCallback(res);
        this._snackBar.loadSnackBar(SuccessMessage.CP_EDIT, colorCodes.SUCCESS);
        this.navigateCP();
      },
      (error) => {
        console.log(error);
      });
  }

  searchChannelPartner(cpPayload, successResponseCallback) {
    this._http.requestCall(Endpoints.LIST_CP, ApiMethod.GETPARAMS, cpPayload).subscribe(
      (res) => {
        successResponseCallback(res);
      },
      (error) => {
        console.log(error)
      });
  }
  
  deleteChannelPartner(cpId,successResponseCallback) {
    Endpoints['DELETE_CP'] = `/cp/${cpId.toString()}`;
    this._http.requestCall(Endpoints['DELETE_CP'], ApiMethod.DELETE).subscribe(
      (res) => {
        successResponseCallback();
        this._snackBar.loadSnackBar(SuccessMessage.CP_DELETE, colorCodes.SUCCESS);
      },
      (error) => {
        console.log(error);
      });
  }

  exportCpFilter(cpPayload) {
    this._http.requestCall(Endpoints.EXPORT_CP, ApiMethod.DOWNLOAD_PARAMS, cpPayload).subscribe(
      (res) => {
        var downloadLink = document.createElement("a");
        const blob = new Blob([res], { type: 'text/csv' });
        const url= window.URL.createObjectURL(blob);
        downloadLink.href = url;
        downloadLink.download = "ChannelPartner.csv";
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
        this._snackBar.loadSnackBar(SuccessMessage.CP_EXPORT, colorCodes.SUCCESS);
        return false;
      },
      (error) => {
        console.log(error);
      }
    );
  }

  navigateCP(){
    let roles = this._StorageService.getUserDetails().role;
    if (roles == Roles.Admin)   this._router.navigate(['beckman/channel-partners']);
    else if (roles == Roles.Channel_Partner)   this._router.navigate(['channel-partner/channel-partners']);
    else if (roles == Roles.Agent)   this._router.navigate(['agent/channel-partners']);
    else this._router.navigate(['beckman-billing/channel-partners']);
  }
  navigateEditCp(id){
      let roles = this._StorageService.getUserDetails().role;
      if (roles == Roles.Admin)    this._router.navigate(['/beckman/channel-partners/edit', id]);
      else if (roles == Roles.Channel_Partner)   this._router.navigate(['/channel-partner/channel-partners/edit', id]);
      // else if (roles == Roles.Agent)   this._router.navigate(['agent/hospitals']);
      else  this._router.navigate(['/beckman-billing/channel-partners/edit', id]);

}
}


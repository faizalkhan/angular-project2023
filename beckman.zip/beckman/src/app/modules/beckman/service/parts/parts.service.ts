import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/core/services/http/http.service';
import { Endpoints, ApiMethod, colorCodes, SuccessMessage } from 'src/app/core/services/constants';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { Router } from '@angular/router';
import { Roles } from 'src/app/modules/auth/model/user';
import { StorageService } from 'src/app/core/services/storage/storage.service';

@Injectable({
  providedIn: 'root'
})
export class PartsService {

  constructor(private _http: HttpService,  private _StorageService: StorageService,private _snackBar: SnackbarService,private _router: Router) { }
  
  importParts(partsfile, successResponseCallback) {
    this._http.requestCall(Endpoints.IMPORT_PARTS, ApiMethod.POST, partsfile).subscribe(
      (res) => {
        successResponseCallback();
        this._snackBar.loadSnackBar(SuccessMessage.PARTS_IMPORT, colorCodes.SUCCESS);
        return false;
      },
      (error) => {
        console.log(error);
      }
    ); 
  } 

  listParts(role,successResponseCallback, errorResponseCallback) {
    let endpoint = (role == Roles.Admin) ? Endpoints.LIST_PARTS : Endpoints.SP_PARTS;
    this._http.requestCall(endpoint, ApiMethod.GET).subscribe(
      (res) => {
        successResponseCallback(res);
      },
      (error) => {
        errorResponseCallback(error);
      });
  }

  exportParts() {
    this._http.requestCall(Endpoints.EXPORT_PARTS,ApiMethod.DOWNLOAD).subscribe(
      (res) => {
        var downloadLink = document.createElement("a");
        const blob = new Blob([res], { type: 'text/csv' });
        const url= window.URL.createObjectURL(blob);
        downloadLink.href = url;
        downloadLink.download = "PartsMaster.csv";
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
        this._snackBar.loadSnackBar(SuccessMessage.PARTS_EXPORT, colorCodes.SUCCESS);
        return false;
      },
      (error) => {
        console.log(error);
      }
    );
  }

  viewPart(partId, successCallBack,errorResponseCallback) {
    Endpoints['VIEW_PART'] = `/parts/${partId.toString()}`;
    this._http.requestCall(Endpoints['VIEW_PART'], ApiMethod.GET).subscribe(
      (res) => {
        successCallBack(res);
      },
      (error) => {
        errorResponseCallback(error);
      });

  }

  searchParts(role, partPayload, successResponseCallback) {
    let endpoint = (role == Roles.Admin) ? Endpoints.LIST_PARTS : Endpoints.SP_PARTS;
    this._http.requestCall(endpoint, ApiMethod.GETPARAMS,partPayload).subscribe(
      (res) => {
        successResponseCallback(res);
      },
      (error) => {
        console.log(error)
      })
  }

  getProductLine(successResponseCallback){
    this._http.requestCall(Endpoints['GET_PRODUCTLINE'], ApiMethod.GET).subscribe(
      (res) => {
        successResponseCallback(res);
      },
      (error) => {
        successResponseCallback([]);
        console.log(error);
      });
  }
  addParts(partsPayLoad){
    this._http.requestCall(Endpoints['LIST_PARTS'], ApiMethod.POST,partsPayLoad).subscribe(
      (res) => {
        this.navigateParts()
        this._snackBar.loadSnackBar(SuccessMessage.PARTS_ADD, colorCodes.SUCCESS);
      },
      (error) => {
        console.log(error);
      });
  }
  editParts(partId, partsPayLoad, successResponseCallback){
    Endpoints['EDIT_PARTS'] =  `/parts/${partId.toString()}`;
    this._http.requestCall(Endpoints['EDIT_PARTS'], ApiMethod.PUT, partsPayLoad).subscribe(
      (res) => {
        successResponseCallback(res);
        this.navigateParts()
        this._snackBar.loadSnackBar(SuccessMessage.PARTS_EDIT, colorCodes.SUCCESS);
      },
      (error) => {
        console.log(error);
      });
  }
  deleteParts(partId,successResponseCallback) {
    Endpoints['DELETE_PARTS'] = `/parts/${partId.toString()}`;
    this._http.requestCall(Endpoints['DELETE_PARTS'], ApiMethod.DELETE).subscribe(
      (res) => {
        successResponseCallback();
        this._snackBar.loadSnackBar(SuccessMessage.PARTS_DELETE, colorCodes.SUCCESS);
      },
      (error) => {
        console.log(error);
      });
  }

  navigateParts() {
    let roles = this._StorageService.getUserDetails().role;

    if (roles == Roles.Admin)   this._router.navigate(['beckman/parts']);
    else if (roles == Roles.Channel_Partner)   this._router.navigate(['channel-partner/parts']);
     else if (roles == Roles.Agent)   this._router.navigate(['agent/parts']);
    else this._router.navigate(['beckman-billing/parts']);
  }

  navigateEditParts(id){
    let roles = this._StorageService.getUserDetails().role;

    if (roles == Roles.Admin)   this._router.navigate(['/beckman/parts/edit/', id]);
    else if (roles == Roles.Channel_Partner) this._router.navigate(['/channel-partner/parts/edit/', id]);
    //  else if (roles == Roles.Agent)   this._router.navigate(['/beckman/parts/edit/', id]);
    else  this._router.navigate(['/beckman-billing/parts/edit/', id]);
  }
}

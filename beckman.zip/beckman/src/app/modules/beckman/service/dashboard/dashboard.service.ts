import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/core/services/http/http.service';
import { Endpoints, ApiMethod, colorCodes } from 'src/app/core/services/constants';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';


@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  constructor(private _http: HttpService,private _snackBar :SnackbarService) { }

  checkAuthenticated() {
    this._http.requestCall(Endpoints.AUTH_ENDPOINT, ApiMethod.GET).subscribe(
      (res) => {
        this._snackBar.loadSnackBar(res.message, colorCodes.SUCCESS);
      },
      (error) => {
        this._snackBar.loadSnackBar(error.error, colorCodes.ERROR);
      }
    );
  }

  getDashboardInventory(successCallback) {
    this._http.requestCall(Endpoints.DASHBOARD_INVENTORY, ApiMethod.GET).subscribe((res) => {
      successCallback(res);
    },
    (error) => { console.log(error); });
  }

  getInventoryDio(successCallback) {
    this._http.requestCall(Endpoints.INVENTORY_DIO, ApiMethod.GET).subscribe((res) => {
      successCallback(res);
    },
    (error) => { console.log(error); });
  }

  filterInventoryDaysOutstanding(payload, successCallback) {

    this._http.requestCall(Endpoints.DASHBOARD_INVENTORY_DAYS_OUTSTANDING, ApiMethod.SEARCHPARAMS,payload).subscribe((res) => {
        successCallback(res);
      },
      (error) => { console.log(error); });
  }

  getPrimarySecondarySales(successCallback) {
    this._http.requestCall(Endpoints.DASHBOARD_PRIMARY_SECONDARY_SALES_ORDER, ApiMethod.GET).subscribe((res) => {
      successCallback(res);
    },
    (error) => { console.log(error); });
  }

  FilterPrimarySecondarySales(payload, successCallback) {

    this._http.requestCall(Endpoints.DASHBOARD_PRIMARY_SECONDARY_SALES_ORDER, ApiMethod.SEARCHPARAMS,payload).subscribe((res) => {
        successCallback(res);
      },
      (error) => { console.log(error); });
  }

  FilterPrimaryTrendLine(payload, successCallback) {

    this._http.requestCall(Endpoints.DASHBOARD_PRIMARY_TREND_LINE, ApiMethod.SEARCHPARAMS,payload).subscribe((res) => {
        successCallback(res);
      },
      (error) => { console.log(error); });
  }

  yearFilterPrimaryTrendLine(payload, successCallback) {
    this._http.requestCall(Endpoints.DASHBOARD_PRIMARY_TREND_LINE, ApiMethod.GETPARAMS,payload).subscribe((res) => {
        successCallback(res);
      },
      (error) => { console.log(error); });
  }


  getPrimaryTrendLine(successCallback) {
    this._http.requestCall(Endpoints.DASHBOARD_PRIMARY_TREND_LINE, ApiMethod.GET).subscribe((res) => {
      successCallback(res);
    },
    (error) => { console.log(error); });
  }

  getSecondaryTrendLine(successCallback) {
    this._http.requestCall(Endpoints.DASHBOARD_SECONDARY_TREND_LINE, ApiMethod.GET).subscribe((res) => {
      successCallback(res);
    },
    (error) => { console.log(error); });
  }

  yearFilterSecondaryTrendLine(payload, successCallback) {
    this._http.requestCall(Endpoints.DASHBOARD_SECONDARY_TREND_LINE, ApiMethod.GETPARAMS,payload).subscribe((res) => {
        successCallback(res);
      },
      (error) => { console.log(error); });
  }


  FilterSecondaryTrendLine(payload, successCallback) {

    this._http.requestCall(Endpoints.DASHBOARD_SECONDARY_TREND_LINE, ApiMethod.SEARCHPARAMS,payload).subscribe((res) => {
        successCallback(res);
      },
      (error) => { console.log(error); });
  }
 
  getPrimarySecondaryTrendLine(successCallback) {
    this._http.requestCall(Endpoints.DASHBOARD_PRIMARY_SECONDARY_TREND_LINE, ApiMethod.GET).subscribe((res) => {
      successCallback(res);
    },
    (error) => { console.log(error); });
  }

  FilterPrimarySecondaryTrendLine(payload, successCallback) {

    this._http.requestCall(Endpoints.DASHBOARD_PRIMARY_SECONDARY_TREND_LINE, ApiMethod.SEARCHPARAMS,payload).subscribe((res) => {
        successCallback(res);
      },
      (error) => { console.log(error); });
  }

  yearFilterPrimarySecondaryTrendLine(payload, successCallback) {
    this._http.requestCall(Endpoints.DASHBOARD_PRIMARY_SECONDARY_TREND_LINE, ApiMethod.GETPARAMS,payload).subscribe((res) => {
        successCallback(res);
      },
      (error) => { console.log(error); });
  }

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BeckmanRoutingModule } from './beckman-routing.module'
import { BeckmanComponent } from './beckman.component';
import { LayoutModule } from './../../layout/layout.module';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';


@NgModule({
  declarations: [
    BeckmanComponent,
  ],
  imports: [
    CommonModule,
    BeckmanRoutingModule,
    LayoutModule,
    AppMaterialModule
  ]
})
export class BeckmanModule { }

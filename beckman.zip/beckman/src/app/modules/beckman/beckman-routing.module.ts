import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BeckmanComponent } from './beckman.component';
import { ModulesGuard } from 'src/app/core/guard/modules.guard';
import { Modules } from 'src/app/core/services/constants';



const routes: Routes = [{ 
    path: '',
    component: BeckmanComponent, 
    children:[ 
    {
      path: 'dashboard',
      loadChildren: () => import('../common/pages/dashboard/dashboard.module').then(m => m.DashboardModule),
    },
    {
      path: 'training',
      loadChildren: () => import('../common/pages/training-tutorials/trainings.module').then(m => m.TrainingsModule),
    },
    {
      path: 'hospitals',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/hospital/hospital.module').then(m => m.HospitalModule),
      data: { menu: Modules.hospitals }
    },
    { 
      path: 'otl',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/otl/otl.module').then(m => m.OtlModule),
      data: { menu: Modules.otl }
    },
    {
      path: 'channel-partners',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/channelpartners/channelpartners.module').then(m => m.ChannelpartnersModule),
      data: { menu: Modules.channelPartner }
    },
    {
      path: 'parts',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/parts/parts.module').then(m => m.PartsModule),
      data: { menu: Modules.parts }

    },
    {
      path: 'otlparts',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/otlparts/otlparts.module').then(m => m.OtlpartsModule),
      data: { menu: Modules.otlParts }

    },
    {
      path: 'bookings',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/cpbookings/cpbookings.module').then(m => m.CpbookingsModule),
      data: { menu: Modules.opf }

    },
    
    {
      path: 'invoices',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/beckman-invoice/invoice.module').then(m => m.InvoiceModule),
      data: { menu: Modules.beckmanInvoice }

    },
    {
      path: 'users',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/users/users.module').then(m => m.UsersModule),
      data: { menu: Modules.users }
    },
    {
      path: 'outbound',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/outbound/outbound.module').then(m => m.OutboundModule),
      data: { menu: Modules.outbound }

    },
    {
      path: 'inbound',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/inbound/inbound.module').then(m => m.InboundModule),
      data: { menu: Modules.inbound }

    },
    {
      path: 'secondary-sales',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/stock-log/stock-log.module').then(m => m.StockLogModule),
      data: { menu: Modules.stockLog }
    },
    { 
      path: 'secondary-sales/invoice',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/secondary-invoice/secondary-invoice.module').then(m => m.SecondaryInvoiceModule),
      data: { menu: Modules.clientInvoice }
    },
    {
      path: 'secondary-sales/delivery-challan',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/delivery-challan/delivery-challan.module').then(m => m.DeliveryChallanModule),
      data: { menu: Modules.dc }
    },
    {
      path: 'secondary-sales/credit',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/credit-debit/credit-debit.module').then(m => m.CreditDebitModule),
      data: { menu: Modules.creditDebit }
    },
     
    {
      path: 'secondary-sales/otl-otl-transfer',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/otl-report/otl-otl-transfer/otl-otl-transfer.module').then(m => m.OtlOtlTransferModule),
      data: { menu: Modules.OtlTransfer }
    },
    {
      path: 'secondary-sales/configuration',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/configuration/configuration.module').then(m => m.ConfigurationModule),
      data: { menu: Modules.config }
    },

    {
      path: 'reports/stock-swap-transfer',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/stock-report/stock-transfer-swap/stock-swap-transfer-report.module').then(m => m.StockSwapTransferReportModule),
      data: { menu: Modules.stockSwapTransferReport }
    },    
    {
      path: 'reports/otl-otl-transfer',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/otl-report/otl-transfer-report/otl-transfer-report.module').then(m => m.OtlTransferReportModule),
      data: { menu: Modules.OtlTransferReport }
    },   
    {
      path: 'reports/dashboard',
      //canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/dashboard-reports/dashboard-reports.module').then(m => m.DashboardReportsModule),
      //data: { menu: Modules.OtlTransferReport }
    },
    {
      path: 'audit_log',
      //canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/audit-log/audit-log.module').then(m => m.AuditLogModule),
      //data: { menu: Modules.OtlTransferReport }
    },
    {
      path: 'reports/stock-overview',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/stock-report/stock-overview/stock-overview.module').then(m => m.StockOverviewModule),
      data: { menu: Modules.stockOverviewReport }
    },
    {
      path: 'reports/opf-invoice-report',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/stock-report/opf-invoice-report/opf-overview.module').then(m => m.OpfOverviewModule),
      data: { menu: Modules.opfOverviewReport}
    },
    {
      path: 'reports/primary-secondary-report',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/stock-report/primary-secondary-report/primary-secondary-report.module').then(m => m.primarySecondaryReportModule),
      data: { menu: Modules.primarySecondaryReport }
    },
    {
      path: 'reports/dc-invoice-report',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/stock-report/dc-invoice-report/dc-overview.module').then(m => m.DcOverviewModule),
      data: { menu: Modules.dcInvoiceReport }
    },
    {
      path: 'reports',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/stock-report/stock-report-list/stock-report.module').then(m => m.StockReportModule),
      data: { menu: Modules.stockReport }
    },
    {
      path: 'permission',
      loadChildren: () => import('../common/pages/permissions/permissions.module').then(m => m.PermissionsModule),
      
    },
    
    {  
      path: '',
      redirectTo: 'dashboard',
      pathMatch: 'full'
    }]
}]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule ]
})
export class BeckmanRoutingModule { }

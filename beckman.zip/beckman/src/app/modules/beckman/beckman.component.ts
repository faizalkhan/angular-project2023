import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-beckman',
  templateUrl: './beckman.component.html',
  styleUrls: ['./beckman.component.css']
})
export class BeckmanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

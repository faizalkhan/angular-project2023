import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AgentComponent } from './agent.component';
import { AgentMyBookingComponent } from './pages/agentbookings/agent-my-booking/agent-my-booking.component';
import { AgentbookingViewComponent } from './pages/agentbookings/agentbooking-view/agentbooking-view.component';
import { AgentbookingListComponent } from './pages/agentbookings/agentbooking-list/agentbooking-list.component';
import { AgentbookingRejectedComponent } from './pages/agentbookings/agentbooking-rejected/agentbooking-rejected.component';
import { AgentbookingEditComponent } from './pages/agentbookings/agentbooking-edit/agentbooking-edit.component';
import { ModulesGuard } from 'src/app/core/guard/modules.guard';
import { Modules } from 'src/app/core/services/constants';




const routes: Routes = [{
  path:'',
  component: AgentComponent,
  children : [
    {
      path:'home',
      component: AgentbookingListComponent
    },

    {
      path:'bookings',
      component: AgentMyBookingComponent
    },
    {
      path:'rejected',
      component: AgentbookingRejectedComponent
    },
    {
      path: ':name/ba/edit/:id',
      component:AgentbookingEditComponent
    }, 
    {
      path: ':name/ba/view/:id',
      component:AgentbookingViewComponent
    }, 
    {
      path: 'outbound',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/outbound/outbound.module').then(m => m.OutboundModule),
      data: { menu: Modules.outbound}
    },
    {
      path: 'inbound',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/inbound/inbound.module').then(m => m.InboundModule),
      data: { menu: Modules.inbound }
    },
    {
      path: 'reports/stock-swap-transfer',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/stock-report/stock-transfer-swap/stock-swap-transfer-report.module').then(m => m.StockSwapTransferReportModule),
      data: { menu: Modules.stockSwapTransferReport }
    }, 
    {
      path: 'reports/dashboard',
      // canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/dashboard-reports/dashboard-reports.module').then(m => m.DashboardReportsModule),
      // data: { menu: Modules.OtlTransferReport }
    },       
    {
      path: 'reports/otl-otl-transfer',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/otl-report/otl-transfer-report/otl-transfer-report.module').then(m => m.OtlTransferReportModule),
      data: { menu: Modules.OtlTransferReport }
    },
    {
      path: 'reports',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/stock-report/stock-report-list/stock-report.module').then(m => m.StockReportModule),
      data: { menu: Modules.stockReport }
    },
    {
      path: 'reports/stock-overview',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/stock-report/stock-overview/stock-overview.module').then(m => m.StockOverviewModule),
      data: { menu: Modules.stockOverviewReport }
    },

    {
      path: 'reports/opf-invoice-report',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/stock-report/opf-invoice-report/opf-overview.module').then(m => m.OpfOverviewModule),
      data: { menu: Modules.opfOverviewReport}
    },
    {
      path: 'reports/primary-secondary-report',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/stock-report/primary-secondary-report/primary-secondary-report.module').then(m => m.primarySecondaryReportModule),
      data: { menu: Modules.primarySecondaryReport }
    },
    {
      path: 'reports/dc-invoice-report',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/stock-report/dc-invoice-report/dc-overview.module').then(m => m.DcOverviewModule),
      data: { menu: Modules.dcInvoiceReport }
    },
    {
      path: 'otl',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/otl/otl.module').then(m => m.OtlModule),
      data: { menu: Modules.otl }
    }, 
    {
      path: 'hospitals',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/hospital/hospital.module').then(m => m.HospitalModule),
      data: { menu: Modules.hospitals }
    },
    {
      path: 'channel-partners',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/channelpartners/channelpartners.module').then(m => m.ChannelpartnersModule),
      data: { menu: Modules.channelPartner }
    },
    {
      path: 'parts',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/parts/parts.module').then(m => m.PartsModule),
      data: { menu: Modules.parts }

    },
    {
      path: 'otlparts',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/otlparts/otlparts.module').then(m => m.OtlpartsModule),
      data: { menu: Modules.otlParts }
    },
    {
      path: 'invoices',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/beckman-invoice/invoice.module').then(m => m.InvoiceModule),
      data: { menu: Modules.beckmanInvoice }
    },
    {
      path: 'invoiceIntegration',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/beckman-invoice/invoice.module').then(m => m.InvoiceModule),
      data: { menu: Modules.beckmanInvoice }
    },
    { 
      path: 'secondary-sales/invoice',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/secondary-invoice/secondary-invoice.module').then(m => m.SecondaryInvoiceModule),
      data: { menu: Modules.clientInvoice }
    },
    {
      path: 'secondary-sales/delivery-challan',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/delivery-challan/delivery-challan.module').then(m => m.DeliveryChallanModule),
      data: { menu: Modules.dc }
    },
    {
      path: 'secondary-sales/configuration',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/configuration/configuration.module').then(m => m.ConfigurationModule),
      data: { menu: Modules.config }
    },
    {
      path: 'secondary-sales',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/stock-log/stock-log.module').then(m => m.StockLogModule),
      data: { menu: Modules.stockLog }
    },   
    {
      path: 'secondary-sales/otl-otl-transfer',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/otl-report/otl-otl-transfer/otl-otl-transfer.module').then(m => m.OtlOtlTransferModule),
      data: { menu: Modules.OtlTransfer }
    }, 
     
    {
      path: 'reports',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/dashboard-reports/dashboard-reports.module').then(m => m.DashboardReportsModule),
      data: { menu: Modules.OtlTransferReport }
    },
   
    {
      path: 'users',
      canLoad:[ModulesGuard],
      loadChildren: () => import('../common/pages/users/users.module').then(m => m.UsersModule),
      data: { menu: Modules.users }
    },
    {
      path: 'training',
      loadChildren: () => import('../common/pages/training-tutorials/trainings.module').then(m => m.TrainingsModule),
    },
    { 
      path: '',
      redirectTo: 'home',
      pathMatch: 'full'
    }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AgentRoutingModule { }
 
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AgentRoutingModule } from './agent-routing.module';
import { AgentComponent } from './agent.component';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { LayoutModule } from 'src/app/layout/layout.module';


import { AgentMyBookingComponent } from './pages/agentbookings/agent-my-booking/agent-my-booking.component';
import { AgGridModule } from 'ag-grid-angular';
import { PipeModule } from 'src/app/core/pipe/pipe.module';
import { AgentbookingViewComponent } from './pages/agentbookings/agentbooking-view/agentbooking-view.component';
import { AgentbookingListComponent } from './pages/agentbookings/agentbooking-list/agentbooking-list.component';
import { AgentbookingRejectedComponent } from './pages/agentbookings/agentbooking-rejected/agentbooking-rejected.component';
import { ListShippingAddressDialog, PartsDialog } from '../common/dialogs/booking-dialog';
import { CommonDialogModule } from '../common/dialogs/common-dialog.module';
import { AgentbookingEditComponent } from './pages/agentbookings/agentbooking-edit/agentbooking-edit.component';




@NgModule({
  declarations: [AgentComponent,AgentMyBookingComponent,AgentbookingViewComponent,AgentbookingListComponent,   AgentbookingRejectedComponent, AgentbookingEditComponent],
  entryComponents: [PartsDialog,ListShippingAddressDialog ],
  imports: [
    CommonModule,
    AgentRoutingModule,
    LayoutModule,
    AgGridModule.withComponents([]),
    CommonDialogModule
  ]
})
export class AgentModule { }

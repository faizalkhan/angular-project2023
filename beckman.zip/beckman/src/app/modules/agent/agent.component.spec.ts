
import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { routes } from 'src/app/app-routing.module';
import { AgentComponent } from './agent.component';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { LayoutModule } from 'src/app/layout/layout.module';
import { HttpClientModule } from '@angular/common/http';



describe('AgentComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes),
        AppMaterialModule,
        LayoutModule,
        HttpClientModule

      ],
     
      declarations: [
        AgentComponent
      ],
    }).compileComponents();
   
  }));

  it('should create the agent booking ', () => {
    const fixture = TestBed.createComponent(AgentComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

});



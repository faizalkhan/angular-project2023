import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentMyBookingComponent } from './agent-my-booking.component';

describe('AgentMyBookingComponent', () => {
  let component: AgentMyBookingComponent;
  let fixture: ComponentFixture<AgentMyBookingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentMyBookingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentMyBookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

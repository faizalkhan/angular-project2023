import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentbookingRejectedComponent } from './agentbooking-rejected.component';

describe('AgentbookingRejectedComponent', () => {
  let component: AgentbookingRejectedComponent;
  let fixture: ComponentFixture<AgentbookingRejectedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentbookingRejectedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentbookingRejectedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

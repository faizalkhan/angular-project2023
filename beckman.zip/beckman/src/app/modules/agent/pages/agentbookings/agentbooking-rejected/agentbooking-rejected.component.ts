import { Component, OnInit, HostListener } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { AgGridRouterComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-router.component';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { Roles } from 'src/app/modules/auth/model/user';
import { IGetRowsParams } from 'ag-grid-community';
import { ActionItems } from 'src/app/core/services/constants';
import { StockReportService } from 'src/app/modules/common/service/stock-reports/stock-report.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { FilterService } from '../../../filterService';

@Component({
  selector: 'app-agentbooking-rejected',
  templateUrl: './agentbooking-rejected.component.html',
  styleUrls: ['./agentbooking-rejected.component.css']
})
export class AgentbookingRejectedComponent implements OnInit {

  
  public columnDefs;
  public defaultColDef
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public searchValue;
  public gridData =[];
  public cpName =[] ;
  public pageSize = 10;
  public partList=[];
  public role;
  public displayChannelPartnerKeys = ['name', 'cpnumber']
  public displayHospitalKeys = ['name', 'custNumber']

  public bookingSearchForm: FormGroup;
  otlList =[];
  clientNames=[];
  public opfPermission;
  public subscription;
  public cpnum:any;
  public custNumber :any;

  constructor(private _bookingService: CpbookingService,private _utilsService : UtilsService , private _StockReportService:StockReportService,private _StorageService : StorageService,
     private _momentService: MomentService, private fb: FormBuilder,private _formValidator: FormValidatorService, public _FilterService : FilterService) { }
     @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
  }
  ngOnInit() {
    this.role = this._StorageService.getUserDetails().role
    this. loadBookingSearchForm();
    this.loadopfPermission();
    this.setClientList();
    this.setCpList();
    this.setOtlList();
    this.setPartsList()
    this.defaultColDef = {
      sortable: true,
      filter: false,
      resizable: true
    };

    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2,
      onPaginationChanged: (params) => {
        if (params.newPage) {
            let rejectCurrentPage = params.api.paginationGetCurrentPage();    
           localStorage.setItem('rejectCurrentPage', JSON.stringify(rejectCurrentPage));
          }
        }
    };

    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.gridOptions.onFilterChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.columnDefs = [
      {
        field: 'id',
        headerName: 'S No.',
        width: 100,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
      },
      {
        headerName: 'OPF Number',
        field: 'OPFNumber',
        width: 190,
        cellRendererFramework: AgGridRouterComponent,
        cellRendererParams: {
          inRouterLink: '/agent/rejected/ba/view/',
        },
      },
      {
        headerName: 'Ordered Date and Time',
        field: 'created_on',
        valueFormatter : this.formatDate.bind(this),
        width: 250,
      },
      {
        headerName: 'Client Name',
        field: 'custName',
        width: 420,
      },
      {
        headerName: 'Channel Partner',
        field: 'cpName',
        width: 250,
      },
      {
        headerName: 'OTL No.',
        field: 'OTLNumber',
        width: 150,
      },
      {
        headerName: 'Net Amount (Rs.)',
        field: 'net_amount',
        width: 200,
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        cellRenderer :(params) =>{
          return typeof params.value !== 'undefined' ?  "<div class = 'text-right'>" + this._utilsService.rupeeFormat(this.RoundOFTwoDigit(params.value))  + "</div>"  : ""
        }

      },
      {
        headerName: 'Total Amount (Rs.)',
        field: 'total_amount',
        width: 200,
   
        comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        cellRenderer :(params) =>{
          return typeof params.value !== 'undefined' ?  "<div class = 'text-right'>" + this._utilsService.rupeeFormat(this.RoundOFTwoDigit(params.value))  + "</div>"  : ""
        }
      },
      {
        headerName: 'Order Status',
        field: 'status',
        width: 180,
      },
      {
        field: '',
        headerName: 'Action',
        sortable: false,
        filter: false,
        width: 100,
        cellRendererFramework: AgGridMenuComponent,
        cellRendererParams: {
          menu: [{
            name: 'View',
            link: '/agent/rejected/ba/view/',
          }
        ],
        },
      }
    ];

  }
  setActionsPermission(name){
    return this.opfPermission && typeof this.opfPermission[ActionItems[name]] != 'undefined'  ?  true : false;
  }

  loadopfPermission(){
      this._bookingService.getActionPermission({model : 'opf'}, response =>{
        this.opfPermission= response['opf'];
      });
  }
  setOtlList(){
    this._bookingService.getListofOTLParts(res =>{
      this.otlList =  this._utilsService.groupByMultipleKeys(res,['name','OTLnumber'])
    })
  }
  setClientList(){
    this._bookingService.listHospital( res =>{
      this.clientNames = this._utilsService.groupByMultipleKeys(res,['name','custNumber'])
    })
  }
  setPartsList(){
    // need to change api  
    this._StockReportService.getListParts(this.role,(res) => {
      this.partList = res  
    });
  }

  setCpList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpName =  this._utilsService.groupByMultipleKeys(res,['name','cpnumber']) 
    })
  }
  formatDate(params){
    return params.data ?  this._momentService.getDateTimeFormat(params.data.created_on) : ""
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.sizeColumnsToFit();
    this.setOpfParams();
  }

  setOpfParams(){
  //   let data = {
  //     from_date : this._momentService.getFilterFormat(this.bookingSearchForm.get('from_date').value),
  //     to_date : this._momentService.getFilterFormat(this.bookingSearchForm.get('to_date').value, "toDate"),
  //     status: 'Rejected'
  //   }
  //  this.getOPFList(data);





   this.subscription = this._FilterService.getFilterData('rejected').subscribe(res => {
    let data = {};

    if(res)
    {
    this._bookingService.listChannelPartner(res1=>{
   this.cpName =  this._utilsService.groupByMultipleKeys(res1,['name','cpnumber'])
  this.cpnum = this.cpName.filter(marker => {
    return marker.cpnumber === res.cpnumber;

 })

 this.bookingSearchForm.get('cpnumber').setValue({ name: this.cpnum[0].name, cpnumber: this.cpnum[0].cpnumber });

})

this._bookingService.listHospital( res2 =>{
  this.clientNames =  this._utilsService.groupByMultipleKeys(res2,['name','custNumber'])

     this.custNumber = this.clientNames.filter(clientnames => {
       return clientnames.custNumber  === res.custNumber
     })

     this.bookingSearchForm.get('custNumber').setValue({ name: this.custNumber[0].name, cpnumber: this.custNumber[0].custNumber });
})




       console.log(this.cpnum, this.bookingSearchForm);

      this.bookingSearchForm.get('OTLNumber').setValue({OTLnumber : res.OTLNumber});
      this.bookingSearchForm.get('partNumber').setValue({partNumber: res.partNumber});

      this.bookingSearchForm.get('OPFNumber').setValue(res.OPFNumber);

      this.bookingSearchForm.get('status').setValue(res.status);
      this.bookingSearchForm.get('from_date').setValue(res.from_date);
      this.bookingSearchForm.get('to_date').setValue(res.to_date);
      this.getOPFList(res);

    }
    else
    {
       data = {
        from_date : this._momentService.getFilterFormat(this.bookingSearchForm.get('from_date').value),
        to_date : this._momentService.getFilterFormat(this.bookingSearchForm.get('to_date').value, "toDate"),
        status: this.bookingSearchForm.get('status').value ? this.bookingSearchForm.get('status').value : 'Open'
       }

      this.getOPFList(data);
    }

  });









  }


  getOPFList(data ?:any) {
    let payload = {};
    var datasource = {
      getRows: (params: IGetRowsParams) =>{
        if (data) {
          payload = data;
        }
        payload['page_size'] =this.pageSize
        payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
        payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
        payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
          this._bookingService.searchBooking(payload,(res)=>{
            let length = res['total'];
            this.gridData = res['results'];
            params.successCallback(res['results'], length)
            const pageToNavigate = JSON.parse(localStorage.getItem('rejectCurrentPage'));
            this.gridApi.paginationGoToPage(pageToNavigate);
          })
      }
    }
      this.gridApi.setDatasource(datasource);
  }



 //  search filter 
 loadBookingSearchForm(){
  this.bookingSearchForm = this.fb.group({
    custNumber: ['',this._formValidator.requireMatch],
    OPFNumber: [''],
    cpnumber: [''],
    OTLNumber: [''],
    status :['Rejected'],
    from_date:[this._momentService.deceedDate(new Date(),31)],
    to_date:[new Date()],
    partNumber :  ['',this._formValidator.requireMatch],
  },{ validator: this._formValidator.dateValidation('from_date', 'to_date') });
}





searchBookingFilter(){
//   if (this.bookingSearchForm.valid){
//   let data = this.getBookingPayload(this.bookingSearchForm.value);
//   this.getOPFList(data);
// }


if (this.bookingSearchForm.valid){
  let data = this.getBookingPayload(this.bookingSearchForm.value);
  this._FilterService.setFilterData(data, 'rejected');
  this._FilterService.getFilterData('rejected').subscribe(res => {
  this.getOPFList(res);
 })
}
}

ngOnDestroy() {
  this.subscription.unsubscribe();
}

getBookingPayload(bookingValue){
  // let data =  {};
  // data['custNumber'] =  bookingValue.custNumber ? bookingValue.custNumber.custNumber : '';
  // data['OTLNumber'] = bookingValue.OTLNumber ? bookingValue.OTLNumber.OTLnumber : '';
  // data['cpnumber'] =  bookingValue.cpnumber ? bookingValue.cpnumber.cpnumber : '';
  // data['from_date'] = bookingValue.from_date ?  this._momentService.getFilterFormat(bookingValue.from_date) : '';
  // data['to_date'] = bookingValue.to_date ? this._momentService.getFilterFormat(bookingValue.to_date, "toDate") : '';
  // data['OPFNumber'] =bookingValue.OPFNumber ? bookingValue.OPFNumber : '';
  // data['status'] =  bookingValue.status ? bookingValue.status : '';
  // data['partNumber'] =bookingValue.partNumber ? bookingValue.partNumber.partNumber : '';
  // return data;



  let data =  {};
  data['custNumber'] =  bookingValue.custNumber ? bookingValue.custNumber.custNumber : '';

  if(data['custNumber'] == undefined)
  {
    data['custNumber'] = bookingValue.custNumber.cpnumber;
  }
  data['OTLNumber'] = bookingValue.OTLNumber ? bookingValue.OTLNumber.OTLnumber : '';

  if(data['OTLNumber'] == undefined)
  {
    data['OTLNumber'] = "";
  }
  data['cpnumber'] =  bookingValue.cpnumber ? bookingValue.cpnumber.cpnumber : '';

  if(data['cpnumber'] == undefined)
  {
    data['cpnumber'] = bookingValue.cpnumber.cpnumber;
  }
  data['from_date'] = bookingValue.from_date ?  this._momentService.getFilterFormat(bookingValue.from_date, "toDate") : '';
  data['to_date'] = bookingValue.to_date ? this._momentService.getFilterFormat(bookingValue.to_date, "toDate") : '';
  data['OPFNumber'] =bookingValue.OPFNumber ? bookingValue.OPFNumber : '';
  data['status'] =  bookingValue.status ? bookingValue.status : 'Open'
  data['partNumber'] =bookingValue.partNumber ? bookingValue.partNumber.partNumber : '';
  if(data['partNumber'] == undefined)
  {
    data['partNumber'] = "";
  }
  return data;







}
cancelFilter(){
  
  // this.bookingSearchForm.reset();
  // this.bookingSearchForm.get('from_date').setValue(this._momentService.deceedDate(new Date(),31));
  // this.bookingSearchForm.get('to_date').setValue(new Date())
  // this.setOpfParams();

  this.bookingSearchForm.reset()
  this.bookingSearchForm.get('from_date').setValue(this._momentService.deceedDate(new Date(),31));
 this.bookingSearchForm.get('to_date').setValue(new Date());
  this.bookingSearchForm.get('status').setValue('Rejected');

  let data = {
  from_date : this._momentService.getFilterFormat(this.bookingSearchForm.get('from_date').value, "toDate"),
  to_date : this._momentService.getFilterFormat(this.bookingSearchForm.get('to_date').value, "toDate"),
  status: this.bookingSearchForm.get('status').value ? this.bookingSearchForm.get('status').value : 'Rejected'
 }
 this.getOPFList(data);
 this._FilterService.setFilterData(data, 'rejected');









}

exportBookingFilter(){
  let bookingPayload =  this.getBookingPayload(this.bookingSearchForm.value);

  // bookingPayload['from_date'] = bookingPayload['from_date'] ?  bookingPayload['from_date'] : this._momentService.getFilterFormat(this._momentService.deceedDate(new Date(),90))
  // bookingPayload['to_date'] =  bookingPayload['to_date'] ?  bookingPayload['to_date'] : this._momentService.getFilterFormat(new Date(), "toDate")
  bookingPayload['status'] = 'Rejected'
 this._bookingService.exportBookingFilter(bookingPayload);
}

RoundOFTwoDigit(num: any){
  var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
  return number;
}
}

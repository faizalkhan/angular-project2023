
import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { routes } from 'src/app/app-routing.module';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { AgentbookingViewComponent } from './agentbooking-view.component';



describe('AgentbookingViewComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes),
        AppMaterialModule,
        CustomFormsModule,
        HttpClientModule,
        BrowserAnimationsModule
      ],
     
      declarations: [
        AgentbookingViewComponent
      ],
    }).compileComponents();
   
  }));

  it('should create the agent booking view ', () => {
    const fixture = TestBed.createComponent(AgentbookingViewComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

});



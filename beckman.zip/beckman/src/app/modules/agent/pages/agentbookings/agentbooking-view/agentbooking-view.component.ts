import { Component, OnInit , ViewEncapsulation, Inject } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { Roles } from 'src/app/modules/auth/model/user';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { BECKMAN_GODOWN, SHIPPING, BILLING, ErrorMessage, colorCodes, ActionItems } from 'src/app/core/services/constants';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import {Location} from '@angular/common';
import { InputDialogService } from 'src/app/core/modules/shared/components/input-dialog/input-dialog.service';
import { OutboundService } from 'src/app/modules/common/service/outbound/outbound.service';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';

@Component({
  selector: 'app-agentbooking-view',
  templateUrl: './agentbooking-view.component.html',
  styleUrls: ['./agentbooking-view.component.css']
})
export class AgentbookingViewComponent implements OnInit {

  public bookingId;
  public data;
  public netAmount = 0;
  public CGST = 0; 
  public totalAmount;
  public totalTax;
  public shippingAddress;
  public billingAddress;
  public editBooking;
  public serverUrl = environment.apiUrl;
  public iGst:boolean;
  public subTotal = 0;
  public currentTab ;
  public editBookingPermission = false;
  public editOpf = false;
  public status: any;
  public statusDate: any;
  public userEmail;
  
  constructor(public _inputDialogService : InputDialogService ,public route: ActivatedRoute,  
    private _snackBar: SnackbarService,
    private _outboundService: OutboundService,
    private _StorageService : StorageService,
    private _formValidator: FormValidatorService,private router: Router, private _PromptService: PromptService, public _CpbookingService: CpbookingService, public _dialog: MatDialog) {
  
   }
  


  ngOnInit() {
    this.userEmail = this._StorageService.getUserDetails().email
    this.route.paramMap.subscribe((params: ParamMap) => {
          this.currentTab = params.get('name');
      if (parseInt(params.get('id'))) {
        this.bookingId = parseInt(params.get('id'));
        this.editBooking = false;
      } else {
        this.bookingId = parseInt(params.get('editId'));
        this.editBooking = true;
      }
    });
    this.getBookingDetails();
    this._CpbookingService.getActionPermission({model : 'opf'},response =>{
      this.editBookingPermission =response['opf'] && typeof response['opf'][ActionItems['EDIT']] != 'undefined'  ?  true : false; 
    });
  }

  checkEditAccessControl(){
    this._CpbookingService.getOPFAccessControls({module:'OPF_Edit', email:  this.userEmail},response =>{
      this.editOpf = response.parent_permission[0]['is_allowed'] && !this.data['isInvoiced']
    })
  }


  getSubTotal(){
    this.subTotal = this.data.parts.reduce((currentAmount, part)=>{
      return this.RoundOFTwoDigit(Number((currentAmount+ (part['price'] * part['quantity']))));
    },0);
   }

  getBookingDetails() {
    this._CpbookingService.viewBooking(this.bookingId,
      (response) => {
        this.data = response;
        this.status = this.data['status'];
        this.statusDate = this.data['status_updated_on'];
        this.billingAddress = response.address.find(address => address.type === BILLING);
        this.shippingAddress = response.address.find(address => address.type === SHIPPING);
        this.totalTax = response.total_tax;
        this.netAmount = response.net_amount;
        this.totalAmount = response.total_amount;
          // need to remove in future
        this.getSubTotal();
        this.checkTax();
        this.checkEditAccessControl();

      },
      (error) => console.log(error))

  }
  getNetAmount() {
    if (this.data.parts) {
      let data = 0;
      for (let i = 0; i < this.data.parts.length; i++) {
        data = data + this.data.parts[i]['total_amount'];
      }
      this.netAmount =this.RoundOFTwoDigit(Number(data));
      this.CGST = this.RoundOFTwoDigit(Number(this.percentage(data, 6)));
      this.totalAmount = this.RoundOFTwoDigit((this.CGST + this.CGST + this.netAmount));
    }
  }

  percentage(num, per) {
    return ((num / 100) * per);
  }



  deleteParts(partIndex) {
    this._PromptService.openDialog({title : 'Delete Part',btnLabel : 'CONFIRM'}, response =>{
      if (response){
        this.deletePartService(partIndex)
      }
    })
  }
  deletePartService(partIndex){
    this._CpbookingService.deleteParts(this.data.parts[partIndex]['id'], (res) => {
      this.data.parts.splice(partIndex, 1);
      this.checkPartsDataCount();
      this.updateOpf();
    })
  }
  checkPartsDataCount() {
    if (this.data.parts.length > 0) this.calculateOpfTotal(this.data.parts);
    else {
      this.netAmount = 0;
      this.totalTax = 0;
      this.totalAmount = this.netAmount + this.totalTax;
    }
  }



  loadPartsTableForm(result, index) {
    for (let part = 0; part < this.data.parts.length; part++) {
      if (part == index) {
        this.data.parts[part] = result;
      }
    }
    this.calculateOpfTotal(result)
  }

  calculateOpfTotal(result) {
    if (result && this.data.parts) {
      this.netAmount= this.data.parts.reduce((currentAmount, part)=>{
        return currentAmount+ part['total_amount']
      },0)
      this.totalTax = this.data.parts.reduce((currentAmount, part)=>{
        return currentAmount+ (this.iGst ? part['igst'] : (part['sgst'] + part['cgst']))
      },0)
        // need to remove in future
        this.getSubTotal();
      this.totalAmount = this.netAmount + this.totalTax;
    }
  }

  updateOpf() {
    this.data['net_amount'] = this.RoundOFTwoDigit(Number(this.netAmount));
    this.data['total_tax'] =  this.RoundOFTwoDigit(Number(this.totalTax));
    this.data['total_amount'] = this.RoundOFTwoDigit(Number(this.totalAmount));
    this._CpbookingService.editBooking(this.bookingId, this.data);
  }

  

  checkTax() {
    if(this.billingAddress['state'].toLowerCase().replace(/\s/g,'') == BECKMAN_GODOWN.toLowerCase().replace(/\s/g,'')) {
      this.iGst = false;
    }
    else {
      this.iGst = true;
    }
    
  }
 
  download(id){
    this._CpbookingService.exportAttachment(id);
  }

  print() {
    window.print();
  }
  oracleStatus() {
    this._outboundService.checkSyncStatus(res=> {
      if (res.is_stopped) {
        this.openDialog();
      }
      else{
        this._snackBar.loadSnackBar(ErrorMessage.NOT_ACK_MANUALLY, colorCodes.ERROR);
      }
      
    });
  }

  openDialog(){


    let fields =  [
      {
        "type":"textbox",
        "label":"Sales Order Number",
        "fieldName" :'oracleOrderNumber',
        "fieldMaxLength" : 8,
        'validator' : [Validators.required, this._formValidator.noDecimalsValidation, this._formValidator.numberValidation]
      }
    ]

    this._inputDialogService.openDialog({btnLabel: 'Submit',title : 'Enter Sales Order Number',fields:fields },result =>{
          if (result){
            result['OPFNumber'] = this.data.OPFNumber;
            this._outboundService.inboundAckManually(result, res=>{
              console.log(res);
            })
          }

    });
  }
  
  setBookingStatus(status) {
   

    if (status == 'Rejected') {
      let fields =  [
      {
        "type":"textarea",
        "label":"Reason for Rejection",
        "fieldName" :'rejectReason',
        'validator' : [Validators.required,this._formValidator.noWhitespaceValidation]
      }
     ]
      this._inputDialogService.openDialog({btnLabel: 'REJECTED',title : 'REJECTED OPF',fields:fields },result =>{
      if (result){
        this.data['rejectReason'] = result['rejectReason'];
        this.bookingService(status);
      }
      }); 
    }else {
      this.bookingService(status);
    }
   
  }

  bookingService(status){
    this.data['status'] = status;
    this._CpbookingService.editBooking(this.bookingId, this.data, status);
  }

  navigate(){
    if (this.currentTab == 'rejected') this.router.navigate(['agent/rejected']);
    else if (this.currentTab == 'bookings') this.router.navigate(['agent/bookings']);
    else if (this.currentTab == 'outbound') this.router.navigate(['agent/outbound']);
    else if (this.currentTab == 'inbound') this.router.navigate(['agent/inbound']);

   else this.router.navigate(['agent/home'])
  }
  navigateEditBooking(){
   if (this.currentTab == 'home')this.router.navigate(['/agent/home/ba/edit/' ,this.bookingId ]);
   else if (this.currentTab == 'bookings')this.router.navigate(['/agent/bookings/ba/edit/' ,this.bookingId ]);
  }
  RoundOFTwoDigit(num: any){
    var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
    return number;
  }

}




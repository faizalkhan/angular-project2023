
import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppMaterialModule } from 'src/app/core/modules/material/material.module';
import { routes } from 'src/app/app-routing.module';
import { CustomFormsModule } from 'src/app/core/modules/forms/forms.module';
import { AgGridModule } from 'ag-grid-angular';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { AgentbookingListComponent } from './agentbooking-list.component';



describe('AgentbookingListComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes),
        AppMaterialModule,
        CustomFormsModule,
        AgGridModule.withComponents([]),
        HttpClientModule,
        BrowserAnimationsModule
      ],
     
      declarations: [
        AgentbookingListComponent
      ],
    }).compileComponents();
   
  }));

  it('should create the booking list in admin', () => {
    const fixture = TestBed.createComponent(AgentbookingListComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

});



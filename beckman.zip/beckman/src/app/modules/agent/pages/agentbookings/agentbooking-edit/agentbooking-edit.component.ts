import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { SnackbarService } from 'src/app/core/services/snackBar/snackbar.service';
import { MatDialog } from '@angular/material';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { StockService } from 'src/app/modules/cpadmin/service/stock.service';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { SecondarysalesService } from 'src/app/modules/cpadmin/service/secondarysales.service';
import { colorCodes, OPF_Type_Value, OTL_params, ErrorMessage, BECKMAN_GODOWN, BILLING, SHIPPING, OPF_type, SuccessMessage, ActionItems } from 'src/app/core/services/constants';
import { requiredFileType } from 'src/app/core/services/formValidator/upload-file-validator';
import { PartsDialog, ListShippingAddressDialog } from 'src/app/modules/common/dialogs/booking-dialog';
import { Roles } from 'src/app/modules/auth/model/user';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { StorageService } from 'src/app/core/services/storage/storage.service';

@Component({
  selector: 'app-agentbooking-edit',
  templateUrl: './agentbooking-edit.component.html',
  styleUrls: ['./agentbooking-edit.component.css']
})
export class AgentbookingEditComponent implements OnInit {
  public accessControl =[];
  public parent_permission =[];
  public bookingId ;
  public bookingData; 
  public date =new Date ();
  public displayClientKeys = ['name','address','city','pincode']
  public opfForm: FormGroup;
  public clientNames = [];
  public cpDetails;
  public clientNumber;
  public otlList = [];
  public otlPartsList = [];
  public partsData = [];
  public subTotal = 0;
  public netAmount = 0;
  public totalTax = 0;
  public regionalId = '';
  public salesId = '';
  public shipDetails ; // current shipping address
  public billingDetails ;
  public attachmentData = new FormData();
  public iGst:boolean;
  public partsCurrentOptions = [];
  public viewOPF = false;
  public attachmentArray =[];
  public othersFoc:boolean = false;
  public billingList = [];
  public shippingList = [];
  public onSubmit = false  //   used to avoid multiple times of OPF creation 
  public isOltNoActive = false;
  public reset = false;
  public invalidParts = '';
  public currentTab ;
  public userEmail;
  
  constructor(private fb: FormBuilder,public _dialog: MatDialog, private _bookingService: CpbookingService, private _formValidator: FormValidatorService,public _utilsService : UtilsService,
    private _router: Router,private _snackBar :SnackbarService, private _stockService:StockService,private _secondarysalesService :SecondarysalesService, private _StorageService : StorageService,
    public route: ActivatedRoute) { }

  ngOnInit() {
    this.userEmail = this._StorageService.getUserDetails().email
    this._bookingService.getActionPermission({model : 'opf'}, response =>{
      if (!response['opf'] || !response['opf'][ActionItems['EDIT']])this.cancelOpf();
    })
    this.loadBookingForm();
    this.getEditOpfAccessControl();
    
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.currentTab = params.get('name');
      this.bookingId = parseInt(params.get('id'));
      this._bookingService.viewBooking(this.bookingId,
        (response) => {
          this.bookingData = response; 
          if (response.status == "Cancelled" || response.status == "Rejected" || response.isInvoiced) this.navigate();
          this.setBookingForm(response);
          this.getDistinctHospitals();
          this.getCpDetail();
        },
        (error) => console.log(error))
    });

    // on Uploading  attachment checking validation 
    this.opfForm.get('attachment').valueChanges.subscribe(res => {
      if (this.opfForm.get('attachment').errors && this.opfForm.get('attachment').errors.requiredFileType){
        this._snackBar.loadSnackBar('Please attach (pdf ,png ,jpg) file', colorCodes.ERROR);
      }
    })
  }
  loadBookingForm() { 
    this.opfForm = this.fb.group({
      OPFNumber: [{value : '' , disabled : true }],
      clientPOnumber: [''],
      custName: [{value : '' , disabled : true }, [Validators.required, this._formValidator.requireMatch]],
      custNumber: ['', Validators.required],
      OTLNumber: [{value : '' , disabled : true }, [Validators.required, this._formValidator.requireMatch]],
      site_id: ['', Validators.required],
      type: [{value : '' , disabled : true }, Validators.required],
      transcationType: ['', Validators.required],
      priority: ['', Validators.required],
      comment: [''],
      attachment:['',  [requiredFileType(["jpg", "png", "pdf"])] ],
      regionalName:[''],
      salesName:[''],
      invoiceNumber:[{value : '' , disabled : true }],
      cpnumber:[''],
      cfNumber:[{value : '' , disabled : true }],
      oracleOrderNumber:[''],
      oracleStatus:[''],
      orderAgainRef:[''],
      rejectReason:['']

    })
  }
  // setting  edit  access for each controls 
  getEditOpfAccessControl(){
    this._bookingService.getOPFAccessControls({module:'OPF_Edit', email: this.userEmail},response =>{
      this.accessControl = response.field_permission;
     this.parent_permission = response.parent_permission[0];
      //response.parent_permission[0]['is_allowed']
      if (!response.parent_permission[0]['is_allowed']) this.navigate();
      this.accessControl.map((editControl) => {
        // need to work on it FOC-D,FOC-S,FOC-A
         if (typeof this.opfForm.controls[editControl.name] !== 'undefined'  && editControl.name !== 'type'&&  editControl.name != 'custName' && editControl.name != 'OTLNumber'){
           if ( editControl['is_allowed']) {
             this.opfForm.controls[editControl.name].enable();
            }
           else this.opfForm.controls[editControl.name].disable();
         }  
       });
    })
  }
  setBookingForm(response){
    
    this.billingDetails = response.address.find(address => address.type === BILLING );
    this.shipDetails = response.address.find(address => address.type === SHIPPING );
    this.opfForm.patchValue({
      clientPOnumber: response.clientPOnumber,
      type: OPF_Type_Value[response.type],
      transcationType:response.transcationType.toLowerCase(),
      priority:'standard',
      comment: response.comment,
      regionalName :response.regionalBranchName,
      salesName :   response.salesManagerName,
      OPFNumber : response.OPFNumber,
      invoiceNumber : response.invoiceNumber ,
      cpnumber:response.cpnumber,
      cfNumber:response.cfNumber,
      oracleOrderNumber:response.oracleOrderNumber ? response.oracleOrderNumber  : '',
      oracleStatus:response.oracleStatus ?response.oracleStatus:'',
      orderAgainRef:response.orderAgainRef ?response.orderAgainRef:'',
      rejectReason:response.rejectReason ?response.rejectReason:''

    });
    this.checkTax();
  }
  getDistinctHospitals(){
    this._bookingService.listHospital( response =>{
      this.clientNames = response
      let cilentName =   response.find((res) => {
        return res.custNumber == this.bookingData.custNumber && res.site_id == this.bookingData.site_id  ;
      });
      this.opfForm.get('custName').setValue(cilentName);
      this.onClientChange(cilentName);
    })
  }
  
  clearPriceFields(){
    this.partsData = [];
    this.netAmount = 0; 
    this.totalTax = 0;
    this.subTotal = 0;
  }
  // giving access to bilto , shipto, quantity , add parts
  checkEditAccess(label){
     let control  = this.accessControl.find(response => response['name'] == label);
     if (control){
     return  control['is_allowed'];
    }
}
  // ----------------------------Autocomplete changes custname and otlnumber 
  onClientChange(value) {
    this.opfForm.patchValue({
      OTLNumber: '',
      site_id: '',
      custNumber: ' '
    });
    this.clearPriceFields();
    this.otlList = [];
     
    if (value) {
        this.opfForm.get('custNumber').setValue(value.custNumber);
        this.opfForm.get('site_id').setValue(value.site_id);
        //set OTL
        this._stockService.getOtl({ "site_id": value.site_id, "order_by":"otl_number", "opf_type":this.opfForm.get('type').value == 'FOC'? OTL_params.FOC : this.opfForm.get('type').value }, (response) => {
          this.otlList = response;
          // setting the values to the fields  on-load  and reset the page 
          if (!this.opfForm.get('custName').touched || this.reset) {
            let currentOTL = response.find(res => res.OTLnumber === this.bookingData['OTLNumber']);
            this.opfForm.get('OTLNumber').setValue(currentOTL);
            this.onOtlChange(currentOTL);
          }
        });
    }else{
      this._snackBar.loadSnackBar(" You don't have a permission to raise OPF,Since  hospital is Inactive", colorCodes.ERROR);
      this.cancelOpf();
    }
  }
  onOtlChange(value) {
    // this.clearPriceFields();
    this.isOltNoActive = false;
    if (value) {
        this.isOltNoActive = true;
        //updating regional ID 
        this.upDateRegionalSalesId(value);
        this._bookingService.getOtlPartsOpf({ "OTLNumber": value.OTLnumber,"opf_type":this.opfForm.get('type').value == 'FOC'? OTL_params.FOC : this.opfForm.get('type').value, "order_by": "name"}, (response) => {
          if(!this.opfForm.get('OTLNumber').touched  || this.reset) {
            // add parts dialog list
           if (!this.opfForm.get('invoiceNumber').value) this.otlPartsList = response;
           else  {
            this.othersFoc = false;
           this.getNcmsPartsList()
          }

         }
            this.partsData =JSON.parse(JSON.stringify(this.bookingData['parts']));
            this.loadPartsTable(this.partsData);
            this.reset = false;
      });
    }
  }
  getNcmsPartsList(){
    this.othersFoc = true;
    this._bookingService.getInvoiceDetails(this.opfForm.get('invoiceNumber').value, (invoiceDetails) => { 
      // this.opfForm.get('OTLNumber').setValue(value);
      this.otlPartsList = invoiceDetails['parts'];
    });
  }
  upDateRegionalSalesId(value){
         this.regionalId =value['regionalBranchEmailid'] ?value['regionalBranchEmailid'] : '';
         this.opfForm.get('regionalName').setValue(value['regional_name'] ) ;
         this.opfForm.get('salesName').setValue(value['sales_name']) ;
         this.salesId =value['salesEmail'];
  }
  updateOTLPartsPrice(response,otlField){
    let bookingParts = this.bookingData['parts'].filter(part => {
      return response.find(res =>{
        if (res['partNumber'] == part['partNumber'] && res['OTLNumber'] == otlField.OTLnumber ) {
          if (res['isActive'] == 1) {
           part['HSSNtax'] = res['HSSNtax']
           part['HSSNcode'] =  res['HSSNcode']
           part['price'] =  res['price']
           part['discount'] = res['discount']
           part['total_amount'] = this.RoundOFTwoDigit(Number((res['price'] * part['quantity'] - ((res['price'] * part['quantity']) * res['discount'])/100))) ;
           part['cgst'] = this.RoundOFTwoDigit(Number(((part['total_amount']*(res['HSSNtax']/2))/100))); 
           part['sgst'] = this.RoundOFTwoDigit(Number(((part['total_amount']*(res['HSSNtax']/2))/100))); 
           part['igst'] = this.RoundOFTwoDigit(Number(((part['total_amount']*res['HSSNtax'])/100))); 
            return part;
          }else{
            this.invalidParts += res['partNumber'] + '-'
          }
        }
      })
   });
   if (this.invalidParts)  this._snackBar.loadSnackBar( this.invalidParts +  ErrorMessage.IN_ACTIVE_PARTS, colorCodes.ERROR);
    this.partsData = bookingParts;
    this.loadPartsTable(this.partsData);
  }

 
// ---------------------------Dialog Functionalities ------------------------
 //clicking add parts
 loadPartsDialog() {
  this.partsCurrentOptions= !this.partsData.length ? this.otlPartsList : this.otlPartsList.filter(otlPart => !this.partsData.find(part =>otlPart['partNumber'] === part['partNumber'] ));
  let dialogRef = this.openPartsDialog(this.partsCurrentOptions);
  dialogRef.afterClosed().subscribe(result => {
    if (result && Object.keys(result).length > 0) {
      result['newPart'] = true
      this.partsData.push(result);
    }
    this.loadPartsTable(result)
  });
}
 //clicking Edit parts

editParts(index) {
   // to get avaiable qty of the part 
  if (this.bookingData.type == 'OTL' || this.bookingData.type == OPF_type['FOC']) {
    this._bookingService.getOpfPartsQty({'partNumber' : this.partsData[index].partNumber, 'OTLNumber': this.opfForm.get('OTLNumber').value.OTLnumber,'opf_type' : this.opfForm.get('type').value == 'FOC' ? OTL_params[this.opfForm.get('type').value ]  :this.opfForm.get('type').value }, response => {
      this.partsData[index]['ncmsAvailableQty'] = response['available_quantity'];
      this.loadEditPartsDialog(index);
    })
  }else{
    this.partsData[index]['ncmsAvailableQty'] = this.otlPartsList.find(res => res['partNumber'] ==this.partsData[index]['partNumber'] )['netInvoicedQty']
    this.loadEditPartsDialog(index);
  }
  
}

loadEditPartsDialog(index){
  let dialogRef = this.openPartsDialog(this.otlPartsList, this.partsData[index]);
  dialogRef.afterClosed().subscribe(result => {
    if (result && typeof result.quantity != 'undefined' ) {
          let part =  this.partsData[index];
          part['quantity'] = result['quantity']
          part['total_amount'] = this.RoundOFTwoDigit(Number((part['price'] * part['quantity'] - ((part['price'] * part['quantity']) * part['discount'])/100)));
          part['cgst'] =this.RoundOFTwoDigit(Number((( part['total_amount']*(part.HSSNtax/2))/100)))  
          part['sgst'] =this.RoundOFTwoDigit(Number((( part['total_amount']*(part.HSSNtax/2))/100)));
          part['igst'] =  this.RoundOFTwoDigit(Number((( part['total_amount']*part.HSSNtax)/100)));
          this.loadPartsTable(result)
    }
  });
}
deleteParts(index) {
  this.partsData.splice(index, 1);
this.checkPartsDataCount();
}
checkPartsDataCount() {
if (this.partsData.length > 0) this.loadPartsTable(this.partsData);
else {
  this.netAmount = 0;
  this.totalTax = 0;
  this.subTotal = 0;
}
}


// open dialog for both add and edit parts -  parts-dialog.html
openPartsDialog(data, parts?: any) {
  const dialogRef = this._dialog.open(PartsDialog, {
    autoFocus: false,
    width: '500px',
    data: { "partsOutput": {}, "partsOptions": data, "editParts": parts ? parts : '', "iGst" : this.iGst, "editBooking" : this.bookingId , "OpfType" : this.opfForm.get('type').value,"OTLNumber": this.opfForm.get('OTLNumber').value}
  });
  return dialogRef;
}
//---------------------Price and Tax calculation - ---------------------
percentage(num, per) {
  return ((num / 100) * per);
}

//calculate net, tax,total amount 
loadPartsTable(result) {
  if (result && this.partsData) {
    this.netAmount= this.partsData.reduce((currentAmount, part)=>{
      return currentAmount+ part['total_amount']
    },0)
    this.totalTax = this.partsData.reduce((currentAmount, part)=>{
      return currentAmount+ (this.iGst ? part['igst'] : (part['sgst'] + part['cgst']))
    },0)
    this.subTotal =  this.partsData.reduce((currentAmount, part)=>{
      return currentAmount+ (part['price'] * part['quantity'])
    },0)
  }
}
reCalculateTax(){
  this.partsData =  this.partsData.map(part =>{
      part['cgst'] =this.RoundOFTwoDigit(Number((( part['total_amount']*(part.HSSNtax/2))/100)));  
      part['sgst'] =this.RoundOFTwoDigit(Number((( part['total_amount']*(part.HSSNtax/2))/100)));
      part['igst'] = this.RoundOFTwoDigit(Number((( part['total_amount']*part.HSSNtax)/100)));
      return part;
    })
}


checkTax() {
  if(this.billingDetails['state'].toLowerCase().replace(/\s/g,'') == BECKMAN_GODOWN.toLowerCase().replace(/\s/g,'')) {
    this.iGst = false;
  }
  else {
    this.iGst = true;
  }
}
// ----------------------to hide and show the save page and update page --------------------
viewOpfDetails(status){
  this.viewOPF= status 
  this.onSubmit = false;
}

/// --------------------Open shipping address list and billing address list ------------------
listBillingAddress(){
  this.openshipAddressDialog(this.billingList, this.billingDetails,'BILL_TO');
}

listShippingAddress() {
    this.openshipAddressDialog(this.shippingList,this.shipDetails,'SHIP_TO');
}
openshipAddressDialog(addressList,currentAddress,name) {
  const dialogRef = this._dialog.open(ListShippingAddressDialog, {
    width: '500px',
    data: { details: addressList, currentAddressDetails: currentAddress}
  });
  dialogRef.afterClosed().subscribe(result => {
    if (result) {
      if (name == 'BILL_TO') {
        this.billingDetails = result;
      }else{
        this.shipDetails = result;
      }
      this.checkTax()
      this.reCalculateTax();

    }
  });
}
//------------attachments ------------
setAttachment($event) {
  if(!this.opfForm.get('attachment').errors && $event.target.files[0] && !this.attachmentArray.find(file => file.name ==$event.target.files[0]['name'] ) && !this.bookingData.attachment.find(file => file.fileName.split('/')[file.fileName.split('/').length-1] == $event.target.files[0]['name'] )) {
    this.attachmentArray.push($event.target.files[0])
  }
}
addAttachment(opfId) {
  this.attachmentData.append('opf_id', opfId);
  this.attachmentArray.map((file, index) =>{
    this.attachmentData.append(index == 0  ? 'attachment' : 'attachment'+ index, file);
  })
  this._bookingService.addAttachment(this.attachmentData,(response) => {
    this._snackBar.loadSnackBar(SuccessMessage.OPF_UPDATE, colorCodes.SUCCESS);
    this.navigate();
   
  });
}
navigate(){
   if (this.currentTab == 'home') this._router.navigate(['agent/home'])
   else this._router.navigate(['agent/bookings']); 
}

clearAttachment(index){
  this.attachmentArray.splice(index,1)
}

cancelOpf(){

 this.navigate();
}
//--------------Setting  bill to and ship to and cp address--------------------------

// to show bill to and ship to address
getCpDetail() {
  this._bookingService.getCpDetails((response => {
    this.cpDetails = response;  
    this.billingList = response.bill_to;
    this.shippingList = response.ship_to;
   }), {'cpnumber' : this.bookingData.cpnumber });
}

getBillingAddress() {
  let data = {
    name: this.cpDetails.name,
    contactperson : this.cpDetails.contactPerson
  }
  return data;
}

//------------------OTL type change ---------
OnTypeChange(event){
  if (this.bookingId) {
    this.opfForm.get('OTLNumber').markAsTouched();
    this.partsData = [];
  }
  const isOTLnumberControl = this.opfForm.get('OTLNumber');
  if(this.opfForm.get('type').value || (this.opfForm.value.OTLNumber || this.partsData.length)) {
    // let opfType = this.opfForm.get('type').value;
       this.resetOpf();
    // this.opfForm.get('type').setValue(opfType);
       this.otlList = [];
      this.othersFoc = false;
      isOTLnumberControl.setValue('');
      this.getCpDetail();
      isOTLnumberControl.enable();
      this.opfForm.get('comment').enable();
  }
  else 
  {
    isOTLnumberControl.disable();
    isOTLnumberControl.updateValueAndValidity();
  }
  this.opfForm.get('comment').updateValueAndValidity();
}
editOpf(){
  let data = this.opfForm.getRawValue();
  this.onSubmit = true
  if (this.opfForm.valid){
  data.OTLNumber = this.opfForm.get('OTLNumber').value.OTLnumber;
  data.custName = this.opfForm.get('custName').value.name;
  data.type = OPF_type[this.opfForm.get('type').value];
  data.regionalBranchEmailid = this.regionalId
  data.salesManagerEmailid = this.salesId;
  data['bill_to'] = this.billingDetails['id'];
  data['ship_to'] = this.shipDetails['id'];
  data['net_amount'] = this.RoundOFTwoDigit(Number(this.netAmount));
  data['total_amount'] = this.RoundOFTwoDigit(Number((data['net_amount'] + this.totalTax)));
  data['total_tax'] = this.RoundOFTwoDigit(Number(this.totalTax));
  data['status'] = this.partsData.find(res => res.quantity  > 0 ) ? this.bookingData.status : 'Cancelled';
  data['hasAttachments'] = this.opfForm.get('attachment').value ? true : false
  data['id'] = this.bookingData.id
  let updateData = Object.assign(this.getBillingAddress(), data);
  updateData.parts = this.partsData;
  this._bookingService.updateBooking(this.bookingId,updateData,response=>{
    if (this.opfForm.get('attachment').value){
          this.addAttachment(response.id);
        }else{
         this.navigate();
         this._snackBar.loadSnackBar(SuccessMessage.OPF_UPDATE, colorCodes.SUCCESS);
        }
  });
   
}
}
resetOpf(value?:any) {
  this.reset = value ? true : false;
      this.setBookingForm(this.bookingData);
      this.getDistinctHospitals();
      this.partsData = this.bookingData['parts'];
      this.loadPartsTable(this.partsData);
      this.attachmentArray = [];
 

}

RoundOFTwoDigit(num: any){
  var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
  return number;
}
}

import { Component, OnInit, HostListener } from '@angular/core';
import { AgGridMenuComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-menu.component';
import { AgGridRouterComponent } from 'src/app/core/modules/shared/components/ag-grid-router/ag-grid-router.component';
import { CpbookingService } from 'src/app/modules/cpadmin/service/cpbooking.service';
import { FormGroup, FormBuilder,  Validators } from '@angular/forms';
import { FormValidatorService } from 'src/app/core/services/formValidator/form-validator.service';
import { MomentService } from 'src/app/core/services/utils/moment.service';
import { Roles } from 'src/app/modules/auth/model/user';
import { UtilsService } from 'src/app/core/services/utils/utils.service';
import { BECKMAN_GODOWN, SHIPPING, BILLING, ErrorMessage, colorCodes, ActionItems } from 'src/app/core/services/constants';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { OutboundService } from 'src/app/modules/common/service/outbound/outbound.service';
import { PromptService } from 'src/app/core/modules/shared/components/prompt/prompt.service';
import { IGetRowsParams } from 'ag-grid-community';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { StockReportService } from 'src/app/modules/common/service/stock-reports/stock-report.service';
import { InputDialogService } from 'src/app/core/modules/shared/components/input-dialog/input-dialog.service';
import { FilterService } from '../../../filterService';
@Component({
  selector: 'app-agentbooking-list',
  templateUrl: './agentbooking-list.component.html',
  styleUrls: ['./agentbooking-list.component.css']
})
export class AgentbookingListComponent implements OnInit {
  public bookingId;
  public bookingdata;
  public columnDefs;
  public defaultColDef
  public gridOptions;
  public gridApi;
  public gridColumnApi;
  public searchValue;
  public gridData =[];
  public cpName =[] ;
  public isStopped:boolean;
  public otlList =[];
  public pageSize = 10;

  public editOpf = false;
  public bookingSearchForm: FormGroup;  
  clientNames=[];
  public editOpfActionMenu = false;
  public opfPermission;
  public partList=[];
  public role;
  public displayChannelPartnerKeys = ['name', 'cpnumber']
  public displayHospitalKeys = ['name', 'custNumber'];
  public status: any;
  public statusDate: any;
  public rejectReason:any;
  public shippingAddress;
  public billingAddress;

  public netAmount = 0;
  public CGST = 0; 
  public totalAmount;
  public totalTax;
  public iGst:boolean;
  public subTotal = 0;
  public bookstatus;
  public editBookingPermission = false;
  public name;
  public lastSearchFilter;
  public userEmail;
  public subscription;
  public cpnum:any;
  public custNumber :any;
  constructor( private _bookingService: CpbookingService,private _utilsService : UtilsService , private _StockReportService:StockReportService,private _StorageService : StorageService,
    private _momentService: MomentService, private fb: FormBuilder,private _formValidator: FormValidatorService,private _outboundService: OutboundService,private _PromptService: PromptService,
    private _inputDialogService :InputDialogService, public _CpbookingService: CpbookingService , public _FilterService : FilterService ) { }
    @HostListener('window:resize', ['$event'])onResize(event) {
      this.gridApi.sizeColumnsToFit();
  }
  ngOnInit() {
    this.role = this._StorageService.getUserDetails().role
    this.userEmail = this._StorageService.getUserDetails().email
    this.loadopfPermission();
    this.loadBookingSearchForm();
    this.setClientList();
    this.setCpList();
    this.setOtlList();
    this.setPartsList()
    this.checkEditAccessControl();
    
    this._CpbookingService.getActionPermission({model : 'opf'},response =>{
      this.editBookingPermission =response['opf'] && typeof response['opf'][ActionItems['EDIT']] != 'undefined'  ?  true : false; 
    });

    this.checkSyncStatus();
    this.defaultColDef = {
      sortable: true,
      filter: false,
      resizable: true
    };

    this.gridOptions = {
      rowHeight: 45,
      paginationPageSize: 10,
      cacheBlockSize : 10,
      rowModelType :'infinite',
      cacheOverflowSize:100,
      maxConcurrentDatasourceRequests: 2,
      onPaginationChanged: (params) => {
        if (params.newPage) {
            let currentPage = params.api.paginationGetCurrentPage();    
           localStorage.setItem('currentPage', JSON.stringify(currentPage));
          }
        }
    };

    this.gridOptions.onSortChanged = event => {
      this.gridApi.redrawRows(); 
    }
    this.gridOptions.onFilterChanged = event => {
      this.gridApi.redrawRows(); 
    }

    this.columnDefs = [
      {
        field: 'id',
        headerName: 'S No.',
        width: 100,
        sortable: false,
        filter: false,
        valueGetter: "node.rowIndex + 1",
      },
      {
        headerName: 'OPF Number',
        field: 'OPFNumber',
        width: 190,
        cellRendererFramework: AgGridRouterComponent,
        cellRendererParams: {
          inRouterLink: '/agent/home/ba/view/',
        },
      },
      {
        headerName: 'Ordered Date and Time',
        field: 'created_on',
        valueFormatter : this.formatDate.bind(this),
        width: 250,
      },
      {
        headerName: 'Client Name',
        field: 'custName',
        width: 420,
      },
      {
        headerName: 'Channel Partner',
        field: 'cpName',
        width: 250
      },
      {
        headerName: 'OTL No.',
        field: 'OTLNumber',
        width: 190,
      },
      {
        headerName: 'Net Amount (Rs.)',
        field: 'net_amount',
        width: 200,
         comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        cellRenderer :(params) =>{
          return typeof params.value !== 'undefined'? "<div class = 'text-right'>" + this._utilsService.rupeeFormat(this.RoundOFTwoDigit(params.value))  + "</div>" :""
        },
        getDetailRowData:(params) => {
         
          params.successCallback(params.data.callRecords);
          console.log("getDetailRowData", params);
        },
        
        
      },
      {
        headerName: 'Total Amount (Rs.)',
        field: 'total_amount',
        width: 200,
          comparator: (param1, param2) => {
          return this._utilsService.numberSorting(param1,param2);
        },
        cellRenderer :(params) =>{
        
          return typeof params.value !== 'undefined' ? "<div class = 'text-right'>" + this._utilsService.rupeeFormat(this.RoundOFTwoDigit(params.value))  + "</div>"  : ""
        }
      },
      {
        headerName: 'Order Status',
        field: 'status',
        width: 190,
      },
      {
        field: 'status',
        headerName: 'Action',
        sortable: false,
        filter: false,
        width: 100,
        cellRendererFramework: AgGridMenuComponent,
        cellRendererParams:  (params) => {
          let menus = [];
          menus.push({
            name: 'View',
            link: '/agent/home/ba/view/',
            newTab : false       
                    
          },
          {
            name: 'Book',
            onMenuActions: this.setBookingStatus.bind(this)
            
          },
          {
            name: 'Reject',
            onMenuActions: this.setBookingStatus.bind(this)
          }       
          
          );

        
        
          if (this.editOpfActionMenu && (params.data && !params.data['isInvoiced']) && this.editOpf &&  params.value != "Cancelled" &&  params.value != "Rejected" && params.value != "Booked" ) {


            menus.push({
                name: 'Edit',
                link: '/agent/home/ba/edit/',
              }
            
              )
          }
          return { 
            menus
          }
        },
      }
    ];

  
        

  }


  setActionsPermission(name){
      return this.opfPermission && typeof this.opfPermission[ActionItems[name]] != 'undefined'  ?  true : false;
  }

  loadopfPermission(){
      this._bookingService.getActionPermission({model : 'opf'}, response =>{
        this.opfPermission= response['opf'];
        this.editOpfActionMenu = this.setActionsPermission('EDIT')
      });
  }



  checkEditAccessControl(){
    this._bookingService.getOPFAccessControls({module:'OPF_Edit', email: this.userEmail}, response =>{
    this.editOpf = response.parent_permission[0]['is_allowed']
    })
  }

  setOtlList(){
      this._bookingService.getListofOTLParts(res =>{
      this.otlList =  this._utilsService.groupByMultipleKeys(res,['name','OTLnumber'])
    })
  }
  setPartsList(){
    // need to change api  
    this._StockReportService.getListParts(this.role,(res) => {
      this.partList = res  
    });
  }
  formatDate(params){
    return params.data ?  this._momentService.getDateTimeFormat(params.data.created_on) : ""
  }

  setClientList(){
    this._bookingService.listHospital( res =>{
      this.clientNames =  this._utilsService.groupByMultipleKeys(res,['name','custNumber'])
    })
  }

  setCpList(){
    this._bookingService.listChannelPartner(res=>{
      this.cpName =  this._utilsService.groupByMultipleKeys(res,['name','cpnumber']) 
     })
  }

  checkSyncStatus() {
    this._outboundService.checkSyncStatus(res=> {
      this.isStopped = res.is_stopped;
      if(res.is_stopped == true ) {
       this.openPromptDialog(res.can_start,res);
      }
    });
  }

  startSync() {
    this._outboundService.startSync(res => {
      this.isStopped = false;
    });
  }
  
  stopSync() {
    this._outboundService.stopSync(res => {
      this.isStopped = true;
    });
  }

  openPromptDialog(status, response) {
    let  message =  status ? 'There are pending OPFs which was not sent because of an Oracle error, Would you like to Start Interface?' : ( response['message'] ? response['message']  : 'There are orders that have not been interfaced due to an error. Please contact Admin to start the interface' )
    this._PromptService.openDialog({ status : status ,type: 'ORACLE', title: 'ERROR', secondaryBtnLabel:status ? 'TRY LATER' : 'CLOSE',  btnLabel: 'START INTERFACE', content: message }, response => {
      if (response) {
        this.startSync();
      }
    })
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi; 
    this.gridApi.sizeColumnsToFit();
    this.setOpfParams();
  }

 

  setOpfParams(){

    this.subscription = this._FilterService.getFilterData('open').subscribe(res => {
      let data = {};

      if(res)
      {
      this._bookingService.listChannelPartner(res1=>{
     this.cpName =  this._utilsService.groupByMultipleKeys(res1,['name','cpnumber'])
    this.cpnum = this.cpName.filter(marker => {
      return marker.cpnumber === res.cpnumber;

   })

   this.bookingSearchForm.get('cpnumber').setValue({ name: this.cpnum[0].name, cpnumber: this.cpnum[0].cpnumber });

  })

  this._bookingService.listHospital( res2 =>{
    this.clientNames =  this._utilsService.groupByMultipleKeys(res2,['name','custNumber'])

       this.custNumber = this.clientNames.filter(clientnames => {
         return clientnames.custNumber  === res.custNumber
       })

       this.bookingSearchForm.get('custNumber').setValue({ name: this.custNumber[0].name, cpnumber: this.custNumber[0].custNumber });
  })




         console.log(this.cpnum, this.bookingSearchForm);

        this.bookingSearchForm.get('OTLNumber').setValue({OTLnumber : res.OTLNumber});
        this.bookingSearchForm.get('partNumber').setValue({partNumber: res.partNumber});

        this.bookingSearchForm.get('OPFNumber').setValue(res.OPFNumber);

        this.bookingSearchForm.get('status').setValue(res.status);
        this.bookingSearchForm.get('from_date').setValue(res.from_date);
        this.bookingSearchForm.get('to_date').setValue(res.to_date);
        this.getOPFList(res);

      }
      else
      {
         data = {
          from_date : this._momentService.getFilterFormat(this.bookingSearchForm.get('from_date').value),
          to_date : this._momentService.getFilterFormat(this.bookingSearchForm.get('to_date').value, "toDate"),
          status: this.bookingSearchForm.get('status').value ? this.bookingSearchForm.get('status').value : 'Open'
         }

        this.getOPFList(data);
      }

    });

  }

  getOPFList(data ?:any) {
    let payload = {};
    var datasource = {
      getRows: (params: IGetRowsParams) =>{
        if (data) {
          payload = data;
        }
        payload['page_size'] =this.pageSize
        payload['page'] = ((params.endRow % this.pageSize) == 0) ? (params.endRow / this.pageSize) : (params.endRow / this.pageSize)+1
        payload['sort_key'] =params.sortModel.length ? params.sortModel[0]['colId'] : ''
        payload['sort_type'] = params.sortModel.length ? params.sortModel[0]['sort'] : ''
          this._bookingService.searchBooking(payload,(res)=>{
            let length = res['total'];
            this.gridData = res['results'];
            params.successCallback(res['results'], length)
            const pageToNavigate = JSON.parse(localStorage.getItem('currentPage'));
           this.gridApi.paginationGoToPage(pageToNavigate);
          })
      }
    }
      this.gridApi.setDatasource(datasource);
  }


 //  search filter 
 loadBookingSearchForm(){
    this.bookingSearchForm = this.fb.group({
    custNumber: ['',this._formValidator.requireMatch],
    OPFNumber: [''],
    cpnumber: [''],
    OTLNumber: [''],
    status : ['Open'],
    from_date:[this._momentService.deceedDate(new Date(),31)],
    to_date:[new Date()],
    partNumber :  ['',this._formValidator.requireMatch],
  },{ validator: this._formValidator.dateValidation('from_date', 'to_date') });
}

searchBookingFilter(){
  if (this.bookingSearchForm.valid){
    let data = this.getBookingPayload(this.bookingSearchForm.value);
    this._FilterService.setFilterData(data, 'open');
    this._FilterService.getFilterData('open').subscribe(res => {
    this.getOPFList(res);
   })
 }
} 
ngOnDestroy() {
  this.subscription.unsubscribe();
}
getBookingPayload(bookingValue){
  console.log(bookingValue);
  let data =  {};
  data['custNumber'] =  bookingValue.custNumber ? bookingValue.custNumber.custNumber : '';

  if(data['custNumber'] == undefined)
  {
    data['custNumber'] = bookingValue.custNumber.cpnumber;
  }
  data['OTLNumber'] = bookingValue.OTLNumber ? bookingValue.OTLNumber.OTLnumber : '';

  if(data['OTLNumber'] == undefined)
  {
    data['OTLNumber'] = "";
  }
  data['cpnumber'] =  bookingValue.cpnumber ? bookingValue.cpnumber.cpnumber : '';

  if(data['cpnumber'] == undefined)
  {
    data['cpnumber'] = bookingValue.cpnumber.cpnumber;
  }
  data['from_date'] = bookingValue.from_date ?  this._momentService.getFilterFormat(bookingValue.from_date, "toDate") : '';
  data['to_date'] = bookingValue.to_date ? this._momentService.getFilterFormat(bookingValue.to_date, "toDate") : '';
  data['OPFNumber'] =bookingValue.OPFNumber ? bookingValue.OPFNumber : '';
  data['status'] =  bookingValue.status ? bookingValue.status : 'Open'
  data['partNumber'] =bookingValue.partNumber ? bookingValue.partNumber.partNumber : '';
  if(data['partNumber'] == undefined)
  {
    data['partNumber'] = "";
  }
  return data;
}
cancelFilter(){

  this.bookingSearchForm.reset()
  this.bookingSearchForm.get('from_date').setValue(this._momentService.deceedDate(new Date(),31));
 this.bookingSearchForm.get('to_date').setValue(new Date())
  this.bookingSearchForm.get('status').setValue('Open')

  let data = {
  from_date : this._momentService.getFilterFormat(this.bookingSearchForm.get('from_date').value, "toDate"),
  to_date : this._momentService.getFilterFormat(this.bookingSearchForm.get('to_date').value, "toDate"),
  status: this.bookingSearchForm.get('status').value ? this.bookingSearchForm.get('status').value : 'Open'
 }
 this.getOPFList(data);
 this._FilterService.setFilterData(data, 'open');

  //this.setOpfParams();

}

exportBookingFilter(){
  let bookingPayload =  this.getBookingPayload(this.bookingSearchForm.value);

  // bookingPayload['from_date'] = bookingPayload['from_date'] ?  bookingPayload['from_date'] : this._momentService.getFilterFormat(this._momentService.deceedDate(new Date(),90))
  // bookingPayload['to_date'] =  bookingPayload['to_date'] ?  bookingPayload['to_date'] : this._momentService.getFilterFormat(new Date(), "toDate")
  

 this._bookingService.exportBookingFilter(bookingPayload);
}

getSubTotal(){
  this.subTotal = this.bookingdata.parts.reduce((currentAmount, part)=>{
    return this.RoundOFTwoDigit(Number((currentAmount+ (part['price'] * part['quantity']))));
  },0);
 }
 checkTax() {
  if(this.billingAddress['state'].toLowerCase().replace(/\s/g,'') == BECKMAN_GODOWN.toLowerCase().replace(/\s/g,'')) {
    this.iGst = false;
  }
  else {
    this.iGst = true;
  }
  
}
getBookingDetails(bookstatus) {
  this._CpbookingService.viewBooking(this.bookingId,
    (response) => {
      this.bookingdata = response;
      this.status = this.bookingdata['status'];
      this.statusDate = this.bookingdata['status_updated_on'];
      this.bookingdata.rejectReason = this.rejectReason;
      this.billingAddress = response.address.find(address => address.type === BILLING);
      this.shippingAddress = response.address.find(address => address.type === SHIPPING);
      this.totalTax = response.total_tax;
      this.netAmount = response.net_amount;
      this.totalAmount = response.total_amount;
        // need to remove in future
      this.getSubTotal();
      this.checkTax();
      this.checkEditAccessControl();
      if(bookstatus == "Booked")
      {
        this.bookingdata['status'] = bookstatus;
      }
      else {
        this.bookingdata['status'] = bookstatus;
      }
      this._CpbookingService.editlistBooking(this.bookingId, this.bookingdata, bookstatus);
      this.searchBookingFilter();

    },
    (error) => console.log(error))

}
setBookingStatus(bookingId,bookstatus) {

    if (bookstatus == 'Reject') {
    let fields =  [
    {
      "type":"textarea",
      "label":"Reason for Rejection",
      "fieldName" :'rejectReason',
      'validator' : [Validators.required,this._formValidator.noWhitespaceValidation]
    }
   ]
    this._inputDialogService.openDialog({btnLabel: 'REJECTED',title : 'REJECTED OPF',fields:fields },result =>{
    if (result){
     this.rejectReason = result['rejectReason'];
      this.bookingService(bookingId, bookstatus);
    }
    }); 
  }else {
    this.bookingService(bookingId, bookstatus);
  }
 
}

bookingService(bookingId, bookstatus){
 // bookstatus = 'Booked';
  this.bookingId = bookingId;
  console.log(this.bookingId);
  if(bookstatus == 'Book')
  {
   
    this.getBookingDetails("Booked");
  }
  else
  {
    this.getBookingDetails("Rejected");
  }
  
}
RoundOFTwoDigit(num: any){
  var number = Math.round(num * Math.pow(10, 2)) / Math.pow(10, 2);
  return number;
}
}

import { Component,  OnInit,  ViewChild  } from '@angular/core';
import { ReportService } from '../_services/report.service';
import { DatePipe } from '@angular/common';
import { SlimScrollOptions, SlimScrollEvent } from 'ngx-slimscroll';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { NgForm } from '@angular/forms';
import { MyGlobal } from '../_services/myglobal.service';
import { TokenStorageService } from '../_services/token-storage.service';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { ConfirmDialogService } from '../confirm-dialog/confirm-dialog.service';

declare function HideMenu(): any;

@Component({
  selector: 'app-home',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.css'],
  providers: [DatePipe],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class RoleComponent implements OnInit{

show_add_user = false;

adduser(){
  this.userDetails.isActive=1;
  this.show_add_user= true ; 
}


// toggle(nav: any){
//   if(nav.opened){
//     nav.close()
//   }
//   else{
//     nav.open();
//   }
// }

    
  @ViewChild('form') form!: NgForm;
    userListData:any;
    userRoleData :any;
    userId:string;
    areaFilterData:any;
    regionList:any;
    statesList:any;
    districtList:any;
    selectedRegion:any;
    selectedState:any;
    selectedRoles:any;
    displayType:string="1";
    userDetails:any={};
    opts: SlimScrollOptions;
    roleSettings:NgMultiSelectDropDownModule = {
      singleSelection: false,
      idField: 'id',
      textField: 'roleName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 100,
      allowSearchFilter: true,
      enableCheckAll:true,
    };

    regionSettings:NgMultiSelectDropDownModule = {
      singleSelection: false,
      idField: 'regionId',
      textField: 'regionName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 100,
      allowSearchFilter: true,
      enableCheckAll:true,
    };
    statedownSettings:NgMultiSelectDropDownModule = {
      singleSelection: false,
      idField: 'stateId',
      textField: 'stateName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 100,
      allowSearchFilter: true,
      enableCheckAll:true,
    };


    constructor(
      private GlobalVariable:MyGlobal, 
      private regionService:ReportService,
      public datepipe: DatePipe,
      private tokenStorage: TokenStorageService,
      private confirmDialog:ConfirmDialogService
      ) { }
  
     
    ngOnInit(): void {
 
      HideMenu();
      this.opts = new SlimScrollOptions({
        position:'right',
        barWidth: "8",
        barBorderRadius:"20",
        alwaysVisible:true,
        visibleTimeout: 1000,
        alwaysPreventDefaultScroll: true
      });
       
      document.body.classList.remove('logoin-bg');
      document.body.classList.add('fixed-nav');
      this.getUserListing();
  }


  getUserListing(){
    this.userListData = [];
    this.regionService.getUserListing().subscribe(
        rdata => {
            if (rdata.resp_code == "200") {
                this.userListData=rdata.resp_body;
            }
        },
        err => {
            alert(err.message);
        }
    );
  }
  getUserRoles(userId:string){
    this.userRoleData = [];
    this.selectedRoles=[];
    let selected=[];
    this.regionService.getRoleListing(userId).subscribe(
        rdata => {
            if (rdata.resp_code == "200") {
                this.userRoleData=rdata.resp_body;
                this.userRoleData.forEach(element => {
                    if(element.selected=="1"){
                        selected.push(element);
                    }
              });
              this.selectedRoles=selected;  
              this.getUserArea(userId);
            }
        },
        err => {
            alert(err.message);
        }
    );
  }

  getUserArea(userId:string){
    this.areaFilterData = [];
    this.regionList=[];
    this.selectedRegion=[];
    let selected=[];
    this.regionService.getAreaListing(userId).subscribe(
        rdata => {
            let regions=[];
            if (rdata.resp_code == "200") {
                this.areaFilterData=rdata.resp_body;
                this.areaFilterData.forEach(element => {
                  if(!regions.find(x=>x.regionId==element.regionId)){
                    regions.push(element);
                    if(this.areaFilterData.find(s=>s.regionId==element.regionId && s.selected)){
                        selected.push(element);
                    }
                }    
              });
            }
          this.regionList=regions;
          this.selectedRegion=selected;
          
         
        },
        err => {
            alert(err.message);
        }
    );
  }
  getStateList(){
    this.statesList=[];
    let states=[];
    let selected=[];
    this.areaFilterData?.forEach(element => {
        if(this.selectedRegion.find(y=>y.regionId==element.regionId)){
          if(!states.find(x=>x.stateId==element.stateId)){
            states.push(element); 
            if(this.areaFilterData.find(y=>y.stateId==element.stateId && y.selected)){
              selected.push(element);
            }
        }    
      }              
    });
    this.statesList=states;
    this.selectedState=selected;
  }

  getStateDistricts(){
    this.districtList=[];
    let districts=[];
    this.areaFilterData?.forEach(element => {
        if(this.selectedState.find(z=>z.stateId==element.stateId)){
            districts.push(element);            
        }    
      }              
    );
    this.districtList=districts;
  }
  onSelectedChange(data){
  }
  getValue(data:any,label:string){
    var result="";
    if(data){
      if(data[label]){
        result=data[label]
      }
    }
    return result;
  }
  submitData(){
    var obj:any={};
    //obj.reportType=this.selectedReportType;
    obj.detail=[];
    // this.regionDetailDataTmp.forEach(element => {
    //    if(element.DistrictData && element.DistrictData.length>0){
    //     obj.detail=obj.detail.concat(element.DistrictData);
    //    }
    // });
    // this.regionService.getPriceDetail(obj).subscribe(
    //     rdata => {
    //     },
    //     err => {
    //     }
    // );
  } 
  showUserRole(userData:any){
      if(userData){
        this.userId=userData.id;
        this.userDetails.userId=this.userId;
        this.userDetails.username=userData.username;
        this.userDetails.userEmail=userData.userEmail;
      }else{
        this.userId="0";
        this.userDetails.username="";
        this.userDetails.userEmail="";
      }
      this.getUserRoles(this.userId);
      this.displayType="3";
  }
  onDeSelect(item: any) {
  }
  onItemSelect(item: any) {
  }
  onSelectAll(items: any) {
  }
  roleSelectionChange() {
    //this.selectedItems = $event;
  }
  regionSelectionChange() {
    this.getStateList();
  }
  
  stateSelectionChange() {
    this.getStateDistricts();
  }
  onDropDownClose() {
    //console.log('dropdown closed');
  }
  backToList(){
    this.displayType="1";
  }
  submitUser(){
    if(this.form.invalid) {
      this.confirmDialog.showMessage("Please fill mandatory fields !",() => { });
      return;
    }
    this.regionService.postUser(this.userDetails).subscribe(
        rdata => {
          if (rdata.resp_code == "200") {
            this.confirmDialog.showMessage("User Saved !",() => { });

            this.hide();
          }
        },
        err => {
        }
    );
  }
  hide(){
    this.userDetails={};
    this.userDetails.isActive=1;
    this.show_add_user=false;
    this.displayType="1";
  }
  submitRoleArea(){
    if(this.form.invalid) {
      this.confirmDialog.showMessage("Please fill mandatory fields !",() => { });
      return;
    }
    var obj:any={};
    obj.userId=this.userId;
    obj.username=this.userDetails.username;
    obj.userEmail=this.userDetails.userEmail;
    obj.role=[];
    obj.area=[];

        this.selectedState.forEach(element => {
        let areamap={"regionId":"","stateId":"","districtId":""};
        areamap.regionId="EAST";
        areamap.stateId=element.stateId;
        areamap.districtId="-1";
        obj.area.push(areamap);       
    });
    this.selectedRoles.forEach(element => {
      obj.role.push(element);       
  });
    this.regionService.postRoleArea(obj).subscribe(
        rdata => {
          if (rdata.resp_code == "200") {
            this.confirmDialog.showMessage("User Saved !",() => { });
            this.selectedRegion=[];
            this.selectedRoles=[];
            this.selectedState=[];
            this.getUserListing();
            this.hide();
          }
        },
        err => {
        }
    );
  }
  removeUser(userId:string){
    let userDetail={"id":"0"};
    userDetail.id=userId;
    this.confirmDialog.confirmThis("confirm","Do you want to delete the user?",() => {
      this.regionService.removeUser(userDetail).subscribe(
        rdata => {
          if (rdata.resp_code == "200") {
            this.confirmDialog.showMessage("User Deleted !",() => { });
            this.getUserListing();
            this.hide();
          }else{
            this.confirmDialog.showMessage("User Email Already Exists !",() => { });
            this.getUserListing();
            this.hide();
          }
        },
        err => {
          this.confirmDialog.showMessage("System Error Try again !",() => { });
        }
    );
      },()=>{
        this.hide();
      });
  }
}


import { Component, OnChanges, OnInit, SimpleChanges  } from '@angular/core';
import { HomeService } from './home.service';
import { DatePipe } from '@angular/common';
import { SlimScrollOptions, SlimScrollEvent } from 'ngx-slimscroll';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MyGlobal } from '../_services/myglobal.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [DatePipe],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})


export class HomeComponent implements OnInit{
    
   
    User:any;
    constructor(
      private gVar: MyGlobal, 
      private homeService:HomeService,
      public datepipe: DatePipe
      ) { }
    ngOnInit(): void {
      document.body.classList.remove('logoin-bg');
      document.body.classList.add('fixed-nav');
      var currentDate=new Date();
     
  }

  
 
 


}

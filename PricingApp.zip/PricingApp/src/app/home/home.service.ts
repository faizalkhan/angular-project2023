import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { MyGlobal } from '../_services/myglobal.service';

const AUTH_API_DOMAIN = environment.apiURL;
const AUTH_API = environment.apiURL + environment.apiPATH ;

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' })
};


@Injectable({
  providedIn: 'root'
})
export class HomeService  {

    constructor(private gVaraible: MyGlobal, private http: HttpClient) {  }
    result = new Observable<any>();
    // getHeaders(){
    //     const httpHeaer = {
    //         headers: new HttpHeaders({
    //             'Content-Type': 'application/json',
    //             'Access-Control-Allow-Origin': '*',
              
    //         })
    //     };
    //     return httpHeaer;
    // }
   
  
}

import { AfterViewInit, Component,ChangeDetectorRef, ElementRef, EventEmitter,  Input,  OnChanges,  OnInit,  Output,  SimpleChanges,  ViewChild, ViewChildren  } from '@angular/core';
import { ReportService } from '../_services/report.service';
import { DatePipe } from '@angular/common';
import { SlimScrollOptions, SlimScrollEvent } from 'ngx-slimscroll';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { NgForm } from '@angular/forms';
import { MyGlobal } from '../_services/myglobal.service';
import { TokenStorageService } from '../_services/token-storage.service';
import { ConfirmDialogService } from '../confirm-dialog/confirm-dialog.service';
import { Router } from '@angular/router';
import { LoaderService } from '../_services/loader.service';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';



declare function HideMenu(): any;

@Component({
  selector: 'app-home',
  templateUrl: './pricing.component.html',
  styleUrls: ['./pricing.component.css'],
  providers: [DatePipe],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class PricingComponent implements OnInit {
  @ViewChildren('datefocus') datefocusElementRh: any =[];
  @ViewChildren('datefocussh') datefocusElementSh: any = [];
  @ViewChildren('datefocuszh') datefocusElementZh: any  = [];

  @ViewChildren('subdatefocussh') subdatefocusElementSh: any = [];
 
  @ViewChild('copyPD', { static :false}) checkboxPD : any;

  @ViewChild('form') form!: NgForm;
    areaFilterData:any;
    regions:any;
    states:any;
    pricingDetailData:any;
    selectedRegion:any;
    selectedState:any;
    selectedReportType:string="M";
    selectedProductCat:string="DALMIA";
    selectProductCatName:string="DCFT";
    username:string;
    User:any; 
    opts: SlimScrollOptions;
    rateLabel:string="WSP";
    isAdmin:boolean=false;
    isUser:boolean=false;
    totalPricePoints:number=0;
    totalDistrict:number=0;
    totalDistrictPrice:number=0;
    showPriceColumns:boolean=false;
    wspEnable:boolean=true;
    date: Date;
    latest_date: string;
    pdValue:any;
    calculatedPd  :any;
    hoverBrand1:number = -1;
    hoverBrand2:number = -1;  
    compWspBrand1:number = -1;
    compWspBrand2:number = -1;
    hoverSubBrand1:number = -1;
    hoverSubBrand2:number = -1;
    compWspSubBrand1:number = -1;
    compWspSubBrand2:number = -1;
    wspprice;
    wspSubprice :number = -1;
    systemcalculated : number = -1;
    subsystemcalculated:number = -1;
    subzhCheckingValues:number = -1;
    shComments;
    shSubComments;
    rhComments;
    zhComments;
    zhCheckingValues; 
    show =true;
    paraElementsRh:any = [];
    paraElementsSh:any = [];
    paraElementszh:any = [];
    copyPd = false;
    accepted;
    firstrowaccepted;
    isSelected = true;
    copyPdValues = [];
    copyFirstRowPdValue = [];
    roles;
    role;
    copynewrole;
    zhavailbalestate;
    defaultrole;
    defaultzone;
    defaultADzone;
    zhvalidation;
    removecomment = false;
    paraelement ;
    commentarray:any =[];
    selectedRoles;
    userRoleData;
    approvalZHToRh= false;
    approvalZHText  =false;
  requestDate;
  copyshPdRec;
  copyshRec; 
  isShown: any =  true // hidden by default
  newsub: boolean;
  sublistindex: any;
  SubparaElementsSh: any[];
  subparaElementsSh: any[];

  subzhComments: any;
  dcftcopyshRec;
  dcftcopyshPdRec;
  dcftcopyshcomment;
  dcftcopyrequestDate;  
  dcftcopyzhPdRec; 
  dcftcopyzhRec;
  dcftcopyzhcomment; 
  dcftcopyzh_effective_date;   
  dcftcopyrhPdRec; 
  dcftcopyrhRec;
  dcftcopyrhcomment; 
  dcftcopylastapprovedDate;
  subCopyshPdRec;
  subCopyshRec;
  subCopyrequestDate;
  subCopyshComments;
  subCopyrsPdRec;
  subCopyrsRec;
  subCopyRHrequestDate;
  subCopyrshComments;
  subCopyzhPdRec;
  subCopyzhRec;
  subCopyzh_effective_date;
  subCopyzhComments;
  copiedNewRole;
  isLoading: BehaviorSubject<boolean> = this.loader.isLoading;
  regionShow:any = true;
  productShow :any = true;
  statesShow :any = true;

    constructor(
      private GlobalVariable:MyGlobal, 
      private regionService:ReportService,
      public datepipe: DatePipe,
      private tokenStorage: TokenStorageService,
      private confirmDialog:ConfirmDialogService,
      private cdref : ChangeDetectorRef,
      private router: Router,
      private loader: LoaderService
      ) {
       
       
       }
  ngOnChanges(changes: SimpleChanges): void {

    throw new Error('Method not implemented.');
  }
 
 
  
    ngOnInit(): void {

      
      
 this.regionService.FilterData.emit(true);

 console.log("price");
      this.roles=this.tokenStorage.getUserRole();
     this.copiedNewRole =  this.roles?.indexOf("3")!=-1 ? "SH" : this.roles?.indexOf("5")!=-1 ?  "ZH" : this.roles?.indexOf("2")!=-1? 'RH' :"AD";  

      this.role =  this.roles?.indexOf("3")!=-1 ? "SH" : this.roles?.indexOf("5")!=-1 ?  "ZH" : this.roles?.indexOf("2")!=-1? 'RH' :"AD";  

      this.copynewrole =this.roles?.indexOf("3")!=-1 ? "SH" : this.roles?.indexOf("5")!=-1 ?  "ZH" : this.roles?.indexOf("2")!=-1? 'RH' :"AD";  

    

      

      if(this.role == "SH")
      { 
       this.approvalZHText = false;
     } 

      if(this.role == "ZH")
      {
        this.defaultzone = "SH";

        this.approvalZHText = true;
        
      }
      if(this.role == "AD")
      {
        
        this.defaultzone = "RH";
        this.defaultADzone = "SH";
      }
    
      HideMenu();      
      this.username=this.GlobalVariable.userName;
      this.opts = new SlimScrollOptions({
        position:'right',
        barWidth: "8",
        barBorderRadius:"20",
        alwaysVisible:true,
        visibleTimeout: 1000,
        alwaysPreventDefaultScroll: true
      });
       
      document.body.classList.remove('logoin-bg');
      document.body.classList.add('fixed-nav');
      this.date=new Date((new Date()).valueOf() - 1000*60*60*24);;
      this.latest_date =this.datepipe.transform(this.date, 'dd-MM-yyyy');
      // this.getAreaFiterData();
   
      this.getData();
      this.showAdmin();
    
     

  }


  listOfSubdistricts:any;
  isSubdistrict :any;
  datas:any;

toggleShow(data) {
     data.isShown =  !data.isShown 
    }


showFocusing(e?:any, datas?:any)
{
  let newVals = 'sub' + datas.id;
  e.currentTarget.focus();
(<HTMLInputElement>document.getElementById(newVals))?.focus();
  document.getElementById(newVals).focus();
setTimeout(()=>{ 
  e.currentTarget.focus();
   document.getElementById(newVals).focus();
   (<HTMLInputElement>document.getElementById(newVals)).focus();

  
},1000);
}
copyPDValueDCFT(nValue?:any)
{
 
  if(this.selectedProductCat === 'DCFT')      {
      
     
    this.copyPd = false;

      
  
  }

  this.copyPdValues = [];
 
console.log(nValue);

   nValue?.forEach((element, index) => {


    console.log(index);

     var roles=this.tokenStorage.getUserRole();
   
     let objRole:any={};

     objRole.type = roles.indexOf("3")!=-1 ? "SH" : roles.indexOf("5")!=-1 ? "ZH" : "RH";
    
 
     let  copyObjpdValues:any = {}
 
     if(objRole.type =="SH")
     {
       copyObjpdValues.requestDate = element.requestDate;
 
       copyObjpdValues.copyshPdRec = element.shPdRec;
   
       copyObjpdValues.copyshcomment = element.shComments;

     }
     if(objRole.type =="ZH")
     {
       copyObjpdValues.zh_effective_date = element.zh_effective_date;
 
       copyObjpdValues.copyzhPdRec = element.zhPdRec;  
    
       copyObjpdValues.copyzhcomment = element.zhComments;
     }
     if(objRole.type =="RH")
     {
       copyObjpdValues.lastapprovedDate = element.lastApprovedDate;
 
       copyObjpdValues.copyrhPdRec = element.lrsPdRec;
   

       copyObjpdValues.copyrhcomment = element.lrshComments;

     }
     
   
    
    

      //element?.listOfSubdistricts?.forEach(listelements => {

 copyObjpdValues.listOfSubdistricts =[];


 for(var i=0; i < element?.listOfSubdistricts?.length; i++)
{



        let subObj:any ={}
            
        if(objRole.type =="SH")
        {
          
         
           subObj['SHsubrequestDate'] = element?.listOfSubdistricts[i].requestDate;
   
           subObj['SHsubshPdRec'] = element?.listOfSubdistricts[i].shPdRec;
      
           subObj['SHsubshcomment'] =  element?.listOfSubdistricts[i].shComments;

           
        }
  

        if(objRole.type =="ZH")
        {
          subObj['ZHsubzh_effective_date'] = element?.listOfSubdistricts[i].zh_effective_date;
    
          subObj['ZHsubzhPdRec'] = element?.listOfSubdistricts[i].zhPdRec;  
       
          subObj['ZHsubcopyzhcomment'] = element?.listOfSubdistricts[i].zhComments;
        }



        if(objRole.type =="RH")
        {
          subObj['RHsublastapprovedDate'] = element?.listOfSubdistricts[i].lastApprovedDate;
    
          subObj['RHsubrhPdRec'] = element?.listOfSubdistricts[i].lrsPdRec;
      
   
          subObj['RHsubrhcomment'] = element?.listOfSubdistricts[i].lrshComments;
   
        }
      
  
       copyObjpdValues.listOfSubdistricts.push(subObj);

     
        
      }


    
   

 
 
     this.copyPdValues.push(copyObjpdValues);

     console.log(this.copyPdValues);


    });







}

copyFirstRowPdValues(nValue?:any)
{
 
  if(this.selectedProductCat === 'DCFT')      {
      
     
    this.copyPd = false;

      
  
  }

  this.copyFirstRowPdValue = [];
 

   nValue?.forEach((element) => {
    
     var roles=this.tokenStorage.getUserRole();
   
     var obj:any={};
    obj.type = roles.indexOf("3")!=-1 ? "SH" : roles.indexOf("5")!=-1 ? "ZH" : "RH";
    
 
     let  copyFirstrowObjpdValues:any = {}
 
     if(obj.type =="SH")
     {
      copyFirstrowObjpdValues.requestDate = element.requestDate;
 
      copyFirstrowObjpdValues.copyshPdRec = element.shPdRec;
   
      copyFirstrowObjpdValues.copyshcomment = element.shComments;
     }
     if(obj.type =="ZH")
     {
      copyFirstrowObjpdValues.zh_effective_date = element.zh_effective_date;
 
      copyFirstrowObjpdValues.copyzhPdRec = element.zhPdRec;  
    
      copyFirstrowObjpdValues.copyzhcomment = element.zhComments;
     }
     if(obj.type =="RH")
     {
      copyFirstrowObjpdValues.lastapprovedDate = element.lastApprovedDate;
 
      copyFirstrowObjpdValues.copyrhPdRec = element.lrsPdRec;
   

      copyFirstrowObjpdValues.copyrhcomment = element.lrshComments;

     }
    
   
     this.copyFirstRowPdValue.push(copyFirstrowObjpdValues);
    });
}


priceToggle()
{
  let total = 2000;
  this.pricingDetailData?.forEach((element, index , arrys) =>
  {

    element['isShown'] = this.isShown;


    element['datevalue'] = element.requestDate;

    element['datezhvalue'] = element.zh_effective_date;

    element['daterhvalue']  = element.requestDate;


    element.listOfSubdistricts?.forEach((sublistdist) =>
    {
      sublistdist['newIds'] = total++;
    })


  
    
  });
 
}





checkZHhasvalues()
{

    this.pricingDetailData?.forEach((element, index , arry) =>
    {
  
       if(arry[index].zhPdRec && arry[index].zhRec  && arry[index].zhComments && arry[index].zh_effective_date !="" && this.role =="ZH"
       
       && arry[index].shPdRec &&  arry[index].shRec && arry[index].shComments  && arry[index].requestDate !="" )
       {

         element['zhvalidation'] = true
          
       }

       else if(arry[index].zhPdRec && arry[index].zhRec  && arry[index].zhComments && arry[index].zh_effective_date !="" )
       {

        
        element['zhvalidation'] = true
  
        
       }
       else if(arry[index].zhPdRec && arry[index].zhRec  && arry[index].zhComments && arry[index].zh_effective_date =="" )
       {
        element['zhvalidation'] = false
       }

       if(arry[index].zhUpdatedBy !=null && arry[index].zhUpdatedBy != "")
       {
         element['gerror'] =true;

         this.approvalZHToRh  =true;

       }



        element.listOfSubdistricts?.forEach((listofelement, indexValue, listArry) => {



          if(listArry[indexValue].zhPdRec && listArry[indexValue].zhRec  && listArry[indexValue].zhComments && listArry[indexValue].zh_effective_date !="" && this.role =="ZH"
       
          && listArry[indexValue].shPdRec &&  listArry[indexValue].shRec && listArry[indexValue].shComments  && listArry[indexValue].requestDate !="" )
          {
   
            listofelement['zhvalidation'] = true
             
          }



          else if(listArry[indexValue].zhPdRec && listArry[indexValue].zhRec  && listArry[indexValue].zhComments && listArry[indexValue].zh_effective_date !="" )
          {
   
           
            listofelement['zhvalidation'] = true
     
           
          }
          else if(listArry[indexValue].zhPdRec && listArry[indexValue].zhRec  && listArry[indexValue].zhComments && listArry[indexValue].zh_effective_date =="" )
          {
            listofelement['zhvalidation'] = false
          }









          if(listArry[indexValue].zhUpdatedBy !=null && listArry[indexValue].zhUpdatedBy != "")

          {
            listofelement['gerror'] =true;
   
            this.approvalZHToRh  =true;
   
          }
          
        });
            
    











   
    })
}
 getData()
{


  this.copyPDValueDCFT();

  this.firstrowaccepted = false;
     this.accepted = false;
    this.regionService.GetData.subscribe(res => {   


    this.selectProductCatName=res["categoryname"];
    this.selectedProductCat=res["category"];
    this.selectedRegion=res["region"];
    this.selectedState=res["state"];
    this.pricingDetailData=res["pricedata"];

    this.priceToggle();
    this.zhavailbalestate = res["isZHAvailForState"];     
    this.totalPricePoints=0;
    this.totalDistrict=0;
    this.totalDistrictPrice=0;
     this.systemCalculate();
     this.firstrowaccepted = false;
     if(this.zhavailbalestate)
     {
          this.role = "ZH"; 
          this.defaultrole = this.roles.indexOf("3")!=-1 ? "SH" : this.roles.indexOf("5")!=-1 ?  "ZH" :  this.roles.indexOf("2")!=-1? "RH" : "AD";

          if(this.defaultrole  == "AD")
          {
            this.defaultADzone = "";
          }
      


      }
     else
     {
     
      this.role =  this.roles.indexOf("3")!=-1 ? "SH" : this.roles.indexOf("5")!=-1 ?  "ZH" :    this.roles.indexOf("2")!=-1? "RH" : "AD";

      if(this.role == "AD")
      {
        this.defaultADzone = "SH";
      }

    
     }
  
    if(this.selectedProductCat === 'DDSP')
    {
      

      this.copyPd = true;
      
    
     }


      else if(this.selectedProductCat === 'KONARK')
     {
    
    this.copyPd = true;
  
    }
    
   
  else 
  {

    this.copyPDValueDCFT();  
    this.checkZHhasvalues();
     
   
  } 
 
  });

 

 
 

}




copypd(event?:any)
{
 
 if(this.selectedRegion){
      
   let roles =  this.tokenStorage.getUserRole().indexOf("3")!=-1 ? "SH" : this.tokenStorage.getUserRole().indexOf("5")!=-1 ?  "ZH" : 'RH';


 this.loader.show(true);
  this.regionService.getPriceDetail(this.selectedRegion.regionId,this.selectedState.stateId,"DCFT",roles).subscribe(
    rdata => {
        if (rdata.resp_code == "200") {    
          
          this.copyPDValueDCFT(rdata.resp_body.priceDetail);  
      
 

            this.copyPdValues.forEach((element, index) =>
            {
                   
               // clearing the values once checkbox is unchecked
                var roles=this.tokenStorage.getUserRole();
           
                 var obj:any={};
                 obj.type=this.tokenStorage.getUserRole().indexOf("3")!=-1 ? "SH" : this.tokenStorage.getUserRole().indexOf("5")!=-1 ?  "ZH" : 'RH';
          
                           
                if(event)
                {
              
                  
                   if(obj.type ==="SH")
                   {
              


                    this.pricingDetailData[index]['shPdRec'] = element.copyshPdRec;    

                    this.pricingDetailData[index]['shRec'] =  element.copyshRec;

                     this.pricingDetailData[index]['shComments']  = element.copyshcomment;

                   this.pricingDetailData[index]['requestDate'] =   element.requestDate;


                     this.pdvalueUpdated(this.pricingDetailData[index]['shPdRec'], this.pricingDetailData[index], "shRec");
                    
                   }
                
                   if(obj.type ==="ZH")
                   {
                    this.pricingDetailData[index]['zhPdRec'] = element.copyzhPdRec;
                    this.pricingDetailData[index]['zhRec'] =  element.copyzhRec;
                    this.pricingDetailData[index]['zhComments']  = element.copyzhcomment;
                     this.pricingDetailData[index]['zh_effective_date'] =   element.zh_effective_date
                     this.pdvalueUpdated(this.pricingDetailData[index]['zhPdRec'], this.pricingDetailData[index], "zhRec");
                   }
          
               
                   if(obj.type ==="RH")
                   {
                 this.pricingDetailData[index]['rsPdRec'] = element.copyrhPdRec;
                this.pricingDetailData[index]['rsRec'] =  element.copyrhRec;
                this.pricingDetailData[index]['rshComments']  = element.copyrhcomment;
                    this.pricingDetailData[index]['approvedDate'] =   element.lastapprovedDate;
                    this.pdvalueUpdated(this.pricingDetailData[index]['rsPdRec'], this.pricingDetailData[index], "rsRec");
          
                   }




                
                 
               
          
                  
                } 
                else
                {
                 
                    // clearing the values once checkbox is unchecked
                    this.pricingDetailData[index]['shPdRec'] = "";
                    this.pricingDetailData[index]['shRec'] =  "";
                    this.pricingDetailData[index]['shComments']  = "";
                    this.pricingDetailData[index]['requestDate'] =  "";  
            
                    this.pricingDetailData[index]['rsPdRec'] = "";
                    this.pricingDetailData[index]['rsRec'] =  "";
                    this.pricingDetailData[index]['rshComments']  =  "";
                    this.pricingDetailData[index]['approvedDate'] =   "";
          
                    this.pricingDetailData[index]['zhPdRec'] = "";
                    this.pricingDetailData[index]['zhRec'] =  "";
                    this.pricingDetailData[index]['zhComments']  =  "";
                    this.pricingDetailData[index]['zh_effective_date'] = "";
                    
                  
                  
                }



           

        
            
                element.listOfSubdistricts?.forEach((subdcftele, subindex) => {

                  if(this.copynewrole == "SH")
                  {
                    
                    this.pricingDetailData[index].listOfSubdistricts[subindex]['shPdRec'] = subdcftele.SHsubshPdRec;

                    this.pricingDetailData[index].listOfSubdistricts[subindex]['requestDate'] = subdcftele.SHsubrequestDate;

                    this.pricingDetailData[index].listOfSubdistricts[subindex]['shComments'] =  subdcftele.SHsubshcomment;

                  
                  }
            
            
                  if(this.copynewrole == "RH")
                  {

                  
 
                    this.pricingDetailData[index].listOfSubdistricts[subindex]['rsPdRec'] =      subdcftele.RHsubrhPdRec;
                    this.pricingDetailData[index].listOfSubdistricts[subindex]['approvedDate'] =  subdcftele.RHsublastapprovedDate;
                    this.pricingDetailData[index].listOfSubdistricts[subindex]['rshComments'] =   subdcftele.RHsubrhcomment;
            
            
            
                  }
            
                  if(this.copynewrole == "ZH")
                  {
            
           


                    this.pricingDetailData[index].listOfSubdistricts[subindex]['zhPdRec']  =  subdcftele.ZHsubzh_effective_date;             
                    this.pricingDetailData[index].listOfSubdistricts[subindex]['zh_effective_date'] =  subdcftele.subzh_effective_date;
                    this.pricingDetailData[index].listOfSubdistricts[subindex]['zhComments'] = subdcftele.ZHsubcopyzhcomment;
                    
                  }
            
                         
            
            
            
                  
            
            
                      
            
                
                });
            





                








              
            });
          









            this.loader.show(false);

            
            }
    },
    err => {
        //this.confirmDialogService.showMessage(err.message, () => { });
    }
);
  }




}








copyFirstRowPd(event?:any)
{

   let newobj:any = {};

   let newsubobj:any = {};

   let rhsubobj:any = {};

  if(event)
  {



    let  shfirstelement = this.pricingDetailData.findIndex ( x => x.shRec  && x.shPdRec ||  x.shComments || x.requestDate && !this.Disabled('shRec'));

    let  zhfirstelement = this.pricingDetailData.findIndex ( x => x.zhRec && x.zhPdRec || x.shComments || x.zh_effective_date && !this.Disabled('zhRec')); 

    let  rhfirstelement = this.pricingDetailData.findIndex ( x => x.rsRec || x.rshComments || x.lastApprovedDate); 


       

   this.pricingDetailData.forEach((ele, index, itemarray) =>
    {


 
      if(ele.hasOwnProperty('zhvalidation'))
      {
   
        if(this.copynewrole == "SH")
        {
          ele['shPdRec'] =  this.subCopyshPdRec =  ele?.shPdRec;
          ele['shRec'] =    this.subCopyshRec = ele?.shRec;
          ele['requestDate'] = this.subCopyrequestDate =  ele?.requestDate;
          ele['shComments'] = this.subCopyshComments = ele?.shComments;

      

    




          
        }
    
        if(this.copynewrole == "RH")
        {


          ele['rsPdRec'] =  this.subCopyrsPdRec = ele?.rsPdRec;
          ele['rsRec'] =    this.subCopyrsRec =ele?.rsRec;
          ele['requestDate'] =  this.subCopyRHrequestDate = ele?.requestDate;
          ele['rshComments'] = this.subCopyrshComments =ele?.rshComments;
        }
      
    
        if(this.copynewrole == "ZH")
        {

          ele['zhPdRec'] = this.subCopyzhPdRec = ele?.zhPdRec;
          ele['zhRec'] =   this.subCopyzhRec =  ele?.zhRec;
          ele['zh_effective_date'] =  this.subCopyzh_effective_date = ele?.zh_effective_date;
          ele['zhComments'] = this.subCopyzhComments = ele?.zhComments;
        }


       
     
      }
    
 

      if( !(this.Disabled('shRec') || ele['zhvalidation']))
      {


       
     if(this.copynewrole == "SH" && index >= shfirstelement && this.pricingDetailData[shfirstelement].shRec || this.pricingDetailData[shfirstelement].shComments || this.pricingDetailData[shfirstelement].requestDate)
    {
  
     
      

       if(newobj.shPdRec == undefined)
       {

        newobj['shPdRec'] =   this.subCopyshPdRec =  ele?.shPdRec;
        newobj['shRec'] =    this.subCopyshRec = ele?.shRec;
        newobj['requestDate'] = this.subCopyrequestDate =  ele?.requestDate;
        newobj['shComments']   = this.subCopyshComments = ele?.shComments;




        
       }
       else
       {

   

        if(!newobj.shRec)
        {
          ele['shRec'] =  this.subCopyshRec =   ele['shRec'];
        }
        else
        {
          ele['shRec'] =   this.subCopyshRec = newobj.shRec;
        }



        if(!newobj.shPdRec)
        {
          ele['shPdRec'] =  this.subCopyshPdRec = ele['shPdRec'];
        }
        else
        {
          ele['shPdRec'] =  this.subCopyshPdRec = newobj.shPdRec;
        }


          if(!newobj.shComments)
        {
          ele['shComments'] = this.subCopyshComments = ele['shComments']
        }
        else {

          ele['shComments'] = this.subCopyshComments = newobj.shComments;

        }


        if(!newobj.requestDate)
        {
          ele['requestDate'] = this.subCopyrequestDate = ele['requestDate']
        }
        else
        {
          ele['requestDate'] =   this.subCopyrequestDate =  newobj.requestDate;
        }
       
       


       
   
       }
          
         } 
        

      }




   if(!(this.Disabled('rshRec'))) {

    if(this.copynewrole == "RH"  && index >= rhfirstelement && this.pricingDetailData[rhfirstelement].rsRec || this.pricingDetailData[rhfirstelement].rshComments || this.pricingDetailData[rhfirstelement].approvedDate)
       {



        if(!newobj.approvedDate && !newobj.rshComments && !newobj.rsRec && !newobj.rsPdRec) 
        {
        newobj['rsPdRec'] =  ele?.rsPdRec;
        newobj['rsRec'] =   ele?.rsRec;
        newobj['approvedDate'] = ele?.approvedDate;
        newobj['rshComments'] =   ele?.rshComments;
         }
        else
        {
          
           if(!newobj.rsRec)
          {
            ele['rsRec'] =  this.subCopyrsRec =   ele['rsRec'];
          }
          else
          {
            ele['rsRec'] =   this.subCopyrsRec =   newobj?.rsRec
          }

          if(!newobj.rsPdRec)
          {
            ele['rsPdRec'] =  this.subCopyrsPdRec  =  ele['rsPdRec'];
          }
          else
          {
            ele['rsPdRec'] =  this.subCopyrsPdRec  =  newobj.rsPdRec;
          }


          if(!newobj.rshComments)
          {
            ele['rshComments'] =  this.subCopyrshComments =  ele['rshComments'];
          }
          else {
  
            ele['rshComments'] =   this.subCopyrshComments = newobj.rshComments;
  
          }

          if(!newobj.approvedDate)
          {
            ele['approvedDate'] = this.subCopyRHrequestDate = ele['approvedDate'];
          }
          else
          {
            ele['approvedDate'] = this.subCopyRHrequestDate = newobj.approvedDate;
          }

     
           }

        }

    }

    if(!this.Disabled('zhRec'))
    { 
      if(this.copynewrole == "ZH" && index >= zhfirstelement && this.pricingDetailData[zhfirstelement].zhRec || this.pricingDetailData[zhfirstelement].zhComments || this.pricingDetailData[zhfirstelement].zh_effective_date)
      {



        
       if(newobj.zhPdRec == undefined)
       {

  
       newobj['zhPdRec'] = this.subCopyzhPdRec = ele?.zhPdRec;
       newobj['zhRec'] =  this.subCopyzhRec =   ele?.zhRec;
       newobj['zh_effective_date'] =  this.subCopyzh_effective_date = ele?.zh_effective_date;
       newobj['zhComments'] = this.subCopyzhComments = ele?. zhComments;
        }
       else
       {
     



         if(!newobj.zhPdRec)
         {
           ele['zhPdRec'] =   this.subCopyzhPdRec = ele['zhPdRec'];
         }
         else
         {
           ele['zhPdRec'] =   this.subCopyzhPdRec = newobj.zhPdRec;
         }
 


         if(!newobj.zhRec)
         {
           ele['zhRec'] =    this.subCopyzhRec = ele['zhRec'];
         }
         else
         {
           ele['zhRec'] =  this.subCopyzhRec = newobj.zhRec;
         }





         if(!newobj.zhComments)
         {
           ele['zhComments'] =   this.subCopyzhComments = ele['zhComments']
         }
         else {
 
           ele['zhComments'] =   this.subCopyzhComments = newobj.zhComments;
 
         }

         if(!newobj.zh_effective_date)
         {
           ele['zh_effective_date'] =  this.subCopyzh_effective_date = ele['zh_effective_date']
         }
         else
         {
           ele['zh_effective_date'] =  this.subCopyzh_effective_date = newobj.zh_effective_date;
         }

         
  
 

       }

      }
      
    }
     
 
        if( !(this.Disabled('shRec') || ele['zhvalidation']))
        { 
       if(this.copynewrole == "SH" && index >= shfirstelement && this.pricingDetailData[0].shRec)
      {
    
        this.pdvalueUpdated(this.pricingDetailData[index]['shPdRec'], this.pricingDetailData[index], "shRec");
        }
        }
      
       if(!(this.Disabled('rshRec'))) {
      if(this.copynewrole == "RH" && index >= rhfirstelement && this.pricingDetailData[0].rsRec)
      {
     
        this.pdvalueUpdated(this.pricingDetailData[index]['rsPdRec'], this.pricingDetailData[index], "rsRec");
      }
       }

      if(!this.Disabled('zhRec'))
    {
      if(this.copynewrole == "ZH" && index >= zhfirstelement && this.pricingDetailData[0].zhRec)
      {
       this.pdvalueUpdated(this.pricingDetailData[index]['zhPdRec'], this.pricingDetailData[index], "zhRec");
      }
       }
    
 
       // subdistrict


       ele.listOfSubdistricts?.forEach((subele, subindex, subitemarray) => {




        if(!(this.Disabled('rshRec'))) {

          if(this.copynewrole == "RH"  && index >= rhfirstelement && this.pricingDetailData[rhfirstelement].rsRec || this.pricingDetailData[rhfirstelement].rshComments || this.pricingDetailData[rhfirstelement].approvedDate)
             {
      
      

     
      
              if(!newsubobj.approvedDate && !newsubobj.rshComments && !newsubobj.rsRec && !newsubobj.rsPdRec) 
              {
                newsubobj['rsPdRec'] =   subele?.rsPdRec;
                newsubobj['rsRec'] = subele?.rsRec;
                newsubobj['approvedDate'] = subele?.approvedDate;
                newsubobj['rshComments'] = subele?.rshComments;
               }
              else
              {
                
                 if(!newsubobj.rsRec)
                {
                  subele['rsRec'] =  subele['rsRec'];
                }
                else
                {
                  subele['rsRec'] =   newsubobj?.rsRec
                }
      
                if(!newsubobj.rsPdRec)
                {
                  subele['rsPdRec'] =   subele['rsPdRec'];
                }
                else
                {
                  subele['rsPdRec'] =  newsubobj.rsPdRec;
                }
      
      
                if(!newsubobj.rshComments)
                {
                  subele['rshComments'] =   subele['rshComments'];
                }
                else {
        
                  subele['rshComments'] =    newsubobj.rshComments;
        
                }
      
                if(!newsubobj.approvedDate)
                {
                  subele['approvedDate'] =  subele['approvedDate'];
                }
                else
                {
                  subele['approvedDate'] = newsubobj.approvedDate;
                }
      
           
                 }
      
              }
      
          }





        if(!(this.Disabled('rshRec'))) {

          if(this.copynewrole == "RH" && index >= rhfirstelement && this.pricingDetailData[0].rsRec)
          {
         
    

            this.pdvalueUpdated(this.pricingDetailData[index].listOfSubdistricts[subindex]['rsPdRec'], this.pricingDetailData[index].listOfSubdistricts[subindex], "rsRec");
          }
           }




           if(!this.Disabled('zhRec'))
           {
             if(this.copynewrole == "ZH" && index >= zhfirstelement && this.pricingDetailData[0].zhRec)
             {
              this.pdvalueUpdated(this.pricingDetailData[index].listOfSubdistricts[subindex]['zhPdRec'], this.pricingDetailData[index].listOfSubdistricts[subindex], "zhRec");
             }
              }

        if(this.copynewrole == "SH")
        {
          if(itemarray[0].shPdRec =="" && subele.shPdRec =="" )
          {
             throw Error
          }
  
        }       

        if(this.copynewrole == "RH")
        {
          if(itemarray[0].rsPdRec =="" && subele.rsPdRec =="" )
          {
             throw Error
          }
  
        }
        
        if(this.copynewrole == "ZH")
        {
          console.log(subele.gerror )


          if( (itemarray[0].zhPdRec =="" && subele.gerror )  && (subele.zhPdRec =="" && subele.gerror ))
          {
           throw Error
          }
          if(itemarray[0].zhPdRec !="" && !subele.gerror)
          {
          subele['zh_effective_date'] = ele?.zh_effective_date;
          subele['zhComments'] = ele?.zhComments;
          }
         

         return 
        }    


        if(ele.hasOwnProperty('zhvalidation'))
        {
     
          if(this.copynewrole == "SH")
          {
            subele['shPdRec'] =   ele?.shPdRec;
            subele['shRec'] =     ele?.shRec;
            subele['requestDate'] =  ele?.requestDate;
            subele['shComments'] =  ele?.shComments;
  
                   
          }

          if(this.copynewrole == "ZH")
          {
  
            subele['zhPdRec'] = ele?.zhPdRec;
            subele['zhRec'] =  ele?.zhRec;
            subele['zh_effective_date'] = ele?.zh_effective_date;
            subele['zhComments'] = ele?.zhComments;
          }


        if(this.copynewrole == "RH")
        {


          ele['rsPdRec'] =  ele?.rsPdRec;
          ele['rsRec'] =   ele?.rsRec;
          ele['requestDate'] =  ele?.requestDate;
          ele['rshComments'] = ele?.rshComments;
        }
      


      
   
       
        }

        if(!(this.Disabled('shRec') || ele['zhvalidation']))
        {
  
       if(this.copynewrole == "SH" && index >= shfirstelement && this.pricingDetailData[shfirstelement].shRec || this.pricingDetailData[shfirstelement].shComments || this.pricingDetailData[shfirstelement].requestDate)
      {
    
       
        
  
         if(newobj.shPdRec == undefined)
         {
  
          newobj['shPdRec'] =    ele?.shPdRec;
          newobj['shRec'] =    ele?.shRec;
          newobj['requestDate'] =   ele?.requestDate;
          newobj['shComments']   =  ele?.shComments;
  
  
  
  
          
         }
         else
         {
  
     
  
          if(!newobj.shRec)
          {
            subele['shRec'] =   ele['shRec'];
          }
          else
          {
            subele['shRec'] =   newobj.shRec;
          }
  
  
  
          if(!newobj.shPdRec)
          {
            subele['shPdRec'] =  ele['shPdRec'];
          }
          else
          {
            subele['shPdRec'] =   newobj.shPdRec;
          }
  
  
            if(!newobj.shComments)
          {
            subele['shComments'] =  ele['shComments']
          }
          else {
  
            subele['shComments'] = newobj.shComments;
  
          }
  
  
          if(!newobj.requestDate)
          {
            subele['requestDate'] = ele['requestDate']
          }
          else
          {
            subele['requestDate'] =   newobj.requestDate;
          }
         
         
  
  
         
     
         }
            
           } 
          
  
        }
  

        if(!(this.Disabled('shRec') || ele['zhvalidation']))
        { 
       if(this.copynewrole == "SH" && index >= shfirstelement && this.pricingDetailData[0].shRec)
      {
      
        this.pdvalueUpdated(this.pricingDetailData[index].listOfSubdistricts[subindex]['shPdRec'], this.pricingDetailData[index].listOfSubdistricts[subindex], "shRec");
        }
        }



        if(!this.Disabled('zhRec'))
        { 
          if(this.copynewrole == "ZH" && index >= zhfirstelement && this.pricingDetailData[zhfirstelement].zhRec || this.pricingDetailData[zhfirstelement].zhComments || this.pricingDetailData[zhfirstelement].zh_effective_date)
          {
    
    
    
            
           if(newsubobj.zhPdRec == undefined)
           {
    
      
            newsubobj['zhPdRec'] =  subele?.zhPdRec;
            newsubobj['zhRec'] =    subele?.zhRec;
            newsubobj['zh_effective_date'] =  subele?.zh_effective_date;
            newsubobj['zhComments'] = subele?.zhComments;
            }
           else
           {
         
    
    
    
             if(!newsubobj.zhPdRec)
             {
              subele['zhPdRec'] = subele['zhPdRec'];
             }
             else
             {
              subele['zhPdRec'] = newsubobj.zhPdRec;
             }
     
    
    
             if(!newsubobj.zhRec)
             {
              subele['zhRec'] = subele['zhRec'];
             }
             else
             {
              subele['zhRec'] = newsubobj.zhRec;
             }
    
    
    
    
    
             if(!newsubobj.zhComments)
             {
              subele['zhComments'] = subele['zhComments']
             }
             else {
     
              subele['zhComments'] =  newsubobj.zhComments;
     
             }
    
             if(!newsubobj.zh_effective_date)
             {
              subele['zh_effective_date'] =  subele['zh_effective_date']
             }
             else
             {
              subele['zh_effective_date'] =  newsubobj.zh_effective_date;
             }
    
             
      
     
    
           }
    
          }
          
        }


  



  
            


    });












   
      
   })

 







console.log(this.pricingDetailData);



  
  }

  else
  {

  this.firstrowaccepted = false;
  }
 








}












systemCalculate()
{

  this.pricingDetailData?.forEach(element => {
    if(element.billingPrice === "0" || element.dcblWsp ==="" ) 
      {
        element['cal_pd']  = "";
      }
  
      else if(element.cbrand1Wsp !="" )
        {
     
         
          element['cal_pd']  = (element.billingPrice - element.dcblWsp - element.ddf  +  (element.dcblWsp - element.cbrand1Wsp)).toString();
          element['cal_pd'] =  element['cal_pd'] < 0 ? "0" :  element['cal_pd'] ;
          element['final']  = (element.billingPrice - element.dcblWsp - element.ddf) .toString();
        }
       else if(element.cbrand1Wsp === '')
       {
      
        element['cal_pd']  = element.billingPrice - element.dcblWsp - element.ddf ;
        element['cal_pd'] =  element['cal_pd'] < 0 ? "0" :  element['cal_pd'] ;
        element['final']  = element.billingPrice - element.dcblWsp - element.ddf ;
       }
      else if(element.cbrand1Wsp !="" &&  element.dcblWsp !="" )
       {
  
      element['cal_pd'] = element.billingPrice - element.dcblWsp - element.ddf +  (element.dcblWsp - element.cbrand1Wsp);
      element['cal_pd'] =  element['cal_pd'] < 0 ? "0" :  element['cal_pd'] ;
      element['final'] = element.billingPrice - element.dcblWsp - element.ddf +  (element.dcblWsp - element.cbrand1Wsp);
      }
      else if(element.cbrand1Wsp === '' || element.dcblWsp === '')
      {
        element['cal_pd'] = element.billingPrice  - element.dcblWsp - element.ddf ;
        element['cal_pd'] =  element['cal_pd'] < 0 ? "0" :  element['cal_pd'] ;
        element['final'] = element.billingPrice  - element.dcblWsp - element.ddf ;
      }

      
      element['aso_tsm'] =  (Number(element.dcblAso)+Number(element.dcblTso));
  
      this.totalPricePoints+=(Number(element.dcblAso)+Number(element.dcblTso));
      this.totalDistrict+=1;
      if(Number(element.dcblAso)>0 || Number(element.dcblTso)>0){
        this.totalDistrictPrice+=1;
      }


  


        element.listOfSubdistricts?.forEach(elements => {





        elements['aso_tsm'] =  (Number(elements.dcblAso)+Number(elements.dcblTso));


        })











    });
}




  onHover(x:number, data, isflag?){

     if(!isflag)
     {
      return 
     }
     else
     {
      if(data == "brand1")
      {
        this.hoverBrand1= x;
        
      }
      else if(data == "subbrand1")
      {
        this.hoverSubBrand1 =x;
      }
      else if(data == "subbrand2")
      {
        this.hoverSubBrand2 =x;
      }
  
      else if(data == "compWspSubBrand1")
      {
        this.compWspSubBrand1 = x;
      }
  
      else if(data == "compWspSubBrand2")
      {
        this.compWspSubBrand2  = x;
      }  

      else if(data == "brand2")
      {
        this.hoverBrand2 = x ;
      }
  
      else if(data == "compWspBrand1")
      {
        this.compWspBrand1  = x;
      }
  
      else if(data == "compWspBrand2")
      {
        this.compWspBrand2  = x;
      }   
  
      else if(data == "shComments")
      {
  
        this.shComments  = x;
          
     
     
      } 

      else if(data == "shSubComments")
      {
  
        this.shSubComments  = x;
          
     
     
      } 
      else if(data == "rhComments")
      {
  
      
         
        this.rhComments = x;
      }  
      
      else if(data == "zhComments")
      {
  
      
         
        this.zhComments = x;
      }  
      else if(data == "subzhComments")
      {
  
      
         
        this.subzhComments = x;
      }  
      
  

      else if(data == "zhCheckingValues")
      {
        this.zhCheckingValues = x;
        this.removecomment = false;

   
        
       
      }

      else if(data == "subzhCheckingValues")
      {
        this.subzhCheckingValues = x;
        this.removecomment = false;              
      }
      else if(data == "systemcalculated")
      {
        this.systemcalculated = x;
      } 
      else if(data == "subsystemcalculated")
      {
        this.subsystemcalculated = x;
      }
     
      else if(data == "wspprice")
      {
        this.wspprice = x;
      } 
      else if(data == "wspSubprice")
      {
        this.wspSubprice= x;
      } 
     
   
  
     }

   
   }


 
  focusElements(paraelement:any, commentarray:any, side)
  {
    this.commentarray =[];
    this.paraElementszh = [];

    commentarray = paraelement.map(index =>
      {
       
        return index.nativeElement;
               
      })

      if(side === 'sh')
      {
        this.paraElementsSh  = commentarray;
      }
      
      else if(side === 'zh')
      {
        this.paraElementszh  = commentarray;
      }
      else
      {
         this.paraElementsRh  = commentarray;
      }
  }
 


   showFocus(index:any, comment, fieldname){
       this.paraElementsSh =[];
    this.paraElementszh =[];
    this.subparaElementsSh =[];

    this.SubparaElementsSh = []; 

    if(comment == "sh")
    {
      this.focusElements(this.datefocusElementSh, 'paraElementsSh', 'sh')

      this.show = !this.show;  
      
      setTimeout(()=>{ 
        this.paraElementsSh[index]?.focus();
        
      },0); 

    }
    if(comment == "zh")
    {
      this.focusElements(this.datefocusElementZh, 'paraElementszh', 'zh')

      this.show = !this.show;  
      setTimeout(()=>{ 
        this.paraElementszh[index]?.focus();
        
      },0); 
    }
    else
    {
      this.focusElements(this.datefocusElementRh, 'paraElementsRh', 'rh')

      this.show = !this.show;  
      setTimeout(()=>{ 
        this.paraElementsRh[index]?.focus();
        
      },0); 

      }
    
 

    }




pdvalueUpdated(event, obj?:any, pdrec?:any) {  


  if(typeof event !== 'string')
  {

    obj['currentPrice2'] =  event?.target?.value == "" ? "" : +event?.target?.value;
    this.pdCalculation2(obj, pdrec);  
  }
 else
 {
  obj['currentPrice2'] = event == "" ? "" : +event;
  this.pdCalculation2(obj, pdrec); 
 }
 
 obj.listOfSubdistricts?.forEach(element => {


if(this.copiedNewRole  == "SH")
{
  if(element['shPdRec'] === "" ||  element['shRec'] === "") 
  {

    element['shPdRec'] = obj.shPdRec;
    element['shRec'] = obj.shRec;

  } 
}

if(this.copiedNewRole == "ZH")
{
  if(element['zhPdRec'] === "" ||  element['zhRec'] === "") 
  {

    element['zhPdRec'] = obj.zhPdRec;
    element['zhRec'] = obj.zhRec;

  } 
}


if(this.copiedNewRole == "RH")
{

  if(element['rsPdRec'] === "" ||  element['rsRec'] === "") 
  {

    element['rsPdRec'] = obj.rsPdRec;
    element['rsRec'] = obj.rsRec;

  } 
}


 });
   

}
pdCalculation(element, pd)
{

  if(this.selectedRegion.regionId === "SOUTH")
  {

    if(element.currentPrice ==="")
    {
      element[pd] = "" 
      return
    }
   
  if(element.billingPrice === "0") 
  {  
    element[pd] = "0";
    return
    
 }
 else if(element.currentPrice != '')   {

 element[pd]  = (element.billingPrice - element.currentPrice).toString();
 element[pd]  = element[pd]  > 0  ?  element[pd]    : "0"
 }
    
  }

  else
  {

    if(element.currentPrice ==="")
    {
      element[pd] = "" 
   
    }
     if(element.billingPrice === "0") 
  {  
    element[pd] = "0" 
 }
else if(element.cbrand1Wsp !="" )
  {   
       element[pd]  =  (+element.billingPrice - element.currentPrice - element.ddf +  (element.dcblWsp - +element.cbrand1Wsp)    
      ? +element.billingPrice - element.currentPrice - element.ddf  +  (element.dcblWsp  - +element.cbrand1Wsp) : "").toString();
     element[pd]  = element[pd]  > 0  ?  element[pd]  : "0"
  }
 else if(element.cbrand1Wsp === '')   {
 element[pd]  = (element.billingPrice - element.currentPrice - element.ddf  ?  element.billingPrice - element.currentPrice - element.ddf  : "").toString();
 element[pd]  = element[pd]  > 0  ?  element[pd] : "0"
 }     
 else if(element.cbrand1Wsp !="" )
 {
  element[pd]  = (element.billingPrice - element.currentPrice - element.ddf  +  (element.dcblWsp - element.cbrand1Wsp) ?
  element.billingPrice - element.currentPrice - element.ddf  +  (element.dcblWsp - element.cbrand1Wsp) : "").toString();
  element[pd]  = element[pd]  > 0  ?  element[pd]   : "0"
 }
else if(element.cbrand1Wsp === '')
{
  element[pd]   = (element.billingPrice  - element.currentPrice - element.ddf  ?  element.billingPrice  - element.currentPrice - element.ddf  : "").toString();
  element[pd]  = element[pd]  > 0  ?  element[pd]    : "-1"
}


  }





}

pdCalculation2(element, pd)
{ 
 



  console.log("selectedstate", this.selectedState)

  console.log("region", this.selectedRegion.regionId)


  if(this.selectedRegion.regionId === "SOUTH")

  {

    if(element.currentPrice2 ==="")
    {
      element[pd] = "" 
      return
    }
   
  if(element.billingPrice === "0") 
  {  
    element[pd] = "0";
    return
    
 }
 else if(element.currentPrice2 != '')   {

 element[pd]  = (element.billingPrice - element.currentPrice2).toString();
 element[pd]  = element[pd]  > 0  ?  element[pd]    : "0"
 }
    
  }


  else
  {

    if(element.currentPrice2 ==="")
    {
      element[pd] = "" 
      return
    }
   
  if(element.billingPrice === "0") 
  {  
    element[pd] = "0";
    return
    
 }
else if(element.cbrand1Wsp !="" &&  element.dcblWsp !="" )
  {   
      element[pd]  =  (+element.billingPrice - element.currentPrice2 - element.ddf +  (element.dcblWsp - +element.cbrand1Wsp)    
      ? +element.billingPrice - element.currentPrice2 - element.ddf  +  (element.dcblWsp  - element.cbrand1Wsp) : "").toString();

     element[pd]  = element[pd]  > 0  ?  element[pd]    : "0"
  }

 else if(element.cbrand1Wsp === '' || element.dcblWsp === '')   {

 element[pd]  = (element.billingPrice - element.currentPrice2 - element.ddf  ?  element.billingPrice - element.currentPrice2 - element.ddf  : "").toString();
 element[pd]  = element[pd]  > 0  ?  element[pd]    : "0"
 }
    
  }
}

valueUpdated(event, obj:any, pdrec) {  



  obj['currentPrice'] = event.target.value == "" ? '' : +event.target.value;
  this.pdCalculation(obj, pdrec);  

    // Working code for district to sub district copy

  obj.listOfSubdistricts?.forEach(element => {


    if(element['shPdRec'] == "" ||  element['shRec'] == "") 
    {

      element['shPdRec'] = obj.shPdRec;
      element['shRec'] = obj.shRec;
    } 


    
     if(element['zhPdRec'] === "" ||  element['zhRec'] === "") 
      {

    element['zhPdRec'] = obj.zhPdRec;
    element['zhRec'] = obj.zhRec;

    } 


    		  
    if(element['rsPdRec'] === "" ||  element['rsRec'] === "") 
    {
  
      element['rsPdRec'] = obj.rsPdRec;
      element['rsRec'] = obj.rsRec;
  
    } 

    

 });


} 

valueCopyComment(obj)
{

  // Working code for district to sub district copy

 obj.listOfSubdistricts?.forEach(element => {   
  
   if(obj.shComments !=""  && obj['datevalue']  && obj.shPdRec!="" && obj.shRec !="")
   {     
         return
   }
  
   if(element['shComments'] == ""  || element['requestDate'] == "") 
   {
    element['shComments'] = obj.shComments;
    element['requestDate'] = obj.requestDate;

   }
 });
   
 obj['datevalue']  = obj.requestDate

}


valueCopyZHComment(obj)
{

  // Working code for district to sub district copy

 obj.listOfSubdistricts?.forEach(element => {   
  
   if(obj.zhComments !=""  && obj['datezhvalue']  && obj.zhPdRec!="" && obj.zhRec !="")
   {     
         return
   }
  
   if(element['zhComments'] == ""  || element['zh_effective_date'] == "") 
   {
    element['zhComments'] = obj.zhComments;
    element['zh_effective_date'] = obj.zh_effective_date;

   }
 });
   
 obj['datezhvalue']  = obj.zh_effective_date;

}



valueCopyRHComment(obj)
{

  // Working code for district to sub district copy

 obj.listOfSubdistricts?.forEach(element => {   
  
   if(obj.rshComments !=""  && obj['daterhvalue']  && obj.rsPdRec!=""  && obj.rsRec !="")
   {     
         return
   }
  
   if(element['rshComments'] == ""  || element['approvedDate'] == "") 
   {
    element['rshComments'] = obj.rshComments;
    element['approvedDate'] = obj.approvedDate;

   }
 });
   
 obj['daterhvalue']  =  obj.approvedDate;

}



getValue(data:any,label:string){
    var result="";
    if(data){
      if(data[label]){
        result=data[label]
      }
    }
    return result;
  }

  getPricingDetailData(){
    if(this.selectedProductCat=="DALMIA"){
      this.selectProductCatName="DCFT";
    }else if(this.selectedProductCat=="DSP"){
      this.selectProductCatName="DDSP";
    }else{
      this.selectProductCatName=this.selectedProductCat;
    }
    if(this.selectedRegion){
      
      //let roles=this.tokenStorage.getUserRole();

      //this._LoaderService.Spinloader.emit(true);

   this.loader.show(true);

      let roles =  this.tokenStorage.getUserRole().indexOf("3")!=-1 ? "SH" : this.tokenStorage.getUserRole().indexOf("5")!=-1 ?  "ZH" : 'RH';
      this.regionService.getPriceDetail(this.selectedRegion.regionId,this.selectedState.stateId,this.selectedProductCat,roles).subscribe(
        rdata => {
            if (rdata.resp_code == "200") {
           
                this.pricingDetailData=rdata.resp_body.priceDetail;
                this.priceToggle();
                this.getData();
                this.systemCalculate();
              
                this.checkZHhasvalues();
                
                this.loader.show(false);
                }
        },
        err => {
            //this.confirmDialogService.showMessage(err.message, () => { });
        }
    );
      }
    
  }

  IsNullorEmpty(value): boolean {
    if (value == undefined || value == "") {
        return true;
    }
    return false;;
  }
  submitData(){
   


     var roles=this.tokenStorage.getUserRole();
    var obj:any={};

    //obj.type=roles.indexOf("3")!=-1?"SH":"RH";

    obj.type =  this.roles.indexOf("3")!=-1 ? "SH" : this.roles.indexOf("5")!=-1 ?  "ZH" : 'RH';

    obj.stateId=this.selectedState.stateId;
    obj.regionId=this.selectedRegion.regionId;
    obj.categoryName=this.selectedProductCat;
    obj.detail=[];
    let valid:boolean=true;
    let empty:boolean=false;
    
    console.log(this.pricingDetailData)

    this.pricingDetailData.forEach(element => {
      empty=false;





   
       if(element.shPdRec?.toString().includes(',')  || element.shRec?.toString().includes(',') ||   
          element.zhPdRec?.toString()?.includes(',')  ||  element.zhRec?.toString().includes(',') ||      
          element.rsPdRec?.toString().includes(',') || element.rsRec?.toString().includes(',')     )
       {
         element.shPdRec =  element.shPdRec.replace(/,/g, '');
         element.shRec =  element.shRec.replace(/,/g, '');
         element.zhPdRec =  element.zhPdRec.replace(/,/g, '');
         element.zhRec =  element.zhRec.replace(/,/g, '');
         element.rsPdRec =  element.rsPdRec.replace(/,/g, '');
         element.rsRec =  element.rsRec.replace(/,/g, '');


       }




   


      if(obj.type=="SH"){



        element.listOfSubdistricts?.forEach((subelement,index) => {

          this.sublistindex =  index;
  
          if(!this.IsNullorEmpty(subelement.shRec) || !this.IsNullorEmpty(subelement.shComments) || !this.IsNullorEmpty(subelement.requestDate)){
            if(this.IsNullorEmpty(subelement.shRec) || this.IsNullorEmpty(subelement.shComments) || this.IsNullorEmpty(subelement.requestDate)){   
              this.confirmDialog.showMessage("SH Price, SH PD, Comments and Effective Date are mandatory. Please fill all four for "+subelement.districtName + " district",() => { });
              valid=false;
              subelement.serror=true;
              return;
            }
          }else{
            empty=true;
          }
  
          subelement.serror =undefined;


          if(!empty){
            let curDate:Date=new Date();
            let lastValidDate:Date=new Date(curDate.getFullYear(),curDate.getMonth(),curDate.getDate());
            let selectedDate:Date;
            if (!this.IsNullorEmpty(subelement.lastApprovedDate)) {
              lastValidDate=new Date(subelement.lastApprovedDate);
              if(obj.type=="SH"){
                selectedDate=new Date(subelement.requestDate);
              }
              else if (obj.type=="RH"){
                selectedDate=new Date(subelement.approvedDate);
              }
              else {
                selectedDate=new Date(subelement.zh_effective_date);
              }
           
              if(lastValidDate.getTime()>selectedDate.getTime() || lastValidDate.getTime()>=selectedDate.getTime()){
                this.confirmDialog.showMessage("Effective date cannot be less than the last approved date for the district "+ subelement.districtName,() => { });
                valid=false;
                if(obj.type=="SH"){
                  subelement.serror=true;
                }
                else if(obj.type=="RH")
                {
                  subelement.rerror=true;
                }
                else
                {
                  subelement.zerror=true;
                }
                return;
              }
            }
            
          }
    
  
        });









        if(!this.IsNullorEmpty(element.shRec) || !this.IsNullorEmpty(element.shComments) || !this.IsNullorEmpty(element.requestDate)){
          if(this.IsNullorEmpty(element.shRec) || this.IsNullorEmpty(element.shComments) || this.IsNullorEmpty(element.requestDate)){   
            this.confirmDialog.showMessage("SH Price, SH PD, Comments and Effective Date are mandatory. Please fill all four for "+element.districtName + " district",() => { });
            valid=false;
            element.serror=true;
          return;
        }

        }
        else{
          empty=true;
        }


         






      }

      
      else if(obj.type=="RH") {


        element.listOfSubdistricts?.forEach((subelement,index) => {

          this.sublistindex =  index;
  
          if(!this.IsNullorEmpty(subelement.rsRec) || !this.IsNullorEmpty(subelement.rshComments) || !this.IsNullorEmpty(subelement.approvedDate)){
            if(this.IsNullorEmpty(subelement.rsRec) || this.IsNullorEmpty(subelement.rshComments) || this.IsNullorEmpty(subelement.approvedDate)){   

              this.confirmDialog.showMessage("RH Price, RH PD, Comments and Effective Date are mandatory. Please fill all four for the "+subelement.districtName + " district",() => { });

              valid=false;
              subelement.rerror=true;
              return;
            }
          }else{
            empty=true;
          }
  
          subelement.rerror =undefined;

          if(!empty){
            let curDate:Date=new Date();
            let lastValidDate:Date=new Date(curDate.getFullYear(),curDate.getMonth(),curDate.getDate());
            let selectedDate:Date;
            if (!this.IsNullorEmpty(subelement.lastApprovedDate)) {
              lastValidDate=new Date(subelement.lastApprovedDate);
              if(obj.type=="SH"){
                selectedDate=new Date(subelement.requestDate);
              }
              else if (obj.type=="RH"){
                selectedDate=new Date(subelement.approvedDate);
              }
              else {
                selectedDate=new Date(subelement.zh_effective_date);
              }
           
              if(lastValidDate.getTime()>selectedDate.getTime() || lastValidDate.getTime()>=selectedDate.getTime()){
                this.confirmDialog.showMessage("Effective date cannot be less than the last approved date for the district "+ subelement.districtName,() => { });
                valid=false;
                if(obj.type=="SH"){
                  subelement.serror=true;
                }
                else if(obj.type=="RH")
                {
                  subelement.rerror=true;
                }
                else
                {
                  subelement.zerror=true;
                }
                return;
              }
            }
            
          }
    
  
        });



        if(!this.IsNullorEmpty(element.rsRec) || !this.IsNullorEmpty(element.rshComments) || !this.IsNullorEmpty(element.approvedDate)){
          if(this.IsNullorEmpty(element.rsRec) || this.IsNullorEmpty(element.rshComments) || this.IsNullorEmpty(element.approvedDate)){

            
            this.confirmDialog.showMessage("RH Price, RH PD, Comments and Effective Date are mandatory. Please fill all four for the "+element.districtName + " district",() => { });
            valid=false;
            element.rerror=true;
            return;
          }
        }else{
          empty=true;
        }
      }



   else if(obj.type=="ZH")
      {


        element.listOfSubdistricts?.forEach((subelement,index) => {

          this.sublistindex =  index;
  
          if(!this.IsNullorEmpty(subelement.zhRec) || !this.IsNullorEmpty(subelement.zhComments) || !this.IsNullorEmpty(subelement.zh_effective_date)){
            if(this.IsNullorEmpty(subelement.zhRec) || this.IsNullorEmpty(subelement.zhComments) || this.IsNullorEmpty(subelement.zh_effective_date)){   


              this.confirmDialog.showMessage("ZH Price, ZH PD, Comments and Effective Date are mandatory. Please fill all four for "+subelement.districtName + " district",() => { });
             

              valid=false;
              subelement.zerror=true;
              return;
            }
          }else{
            empty=true;
          }
  
          subelement.zerror =undefined;


          
          if(!empty){
            let curDate:Date=new Date();
            let lastValidDate:Date=new Date(curDate.getFullYear(),curDate.getMonth(),curDate.getDate());
            let selectedDate:Date;
            if (!this.IsNullorEmpty(subelement.lastApprovedDate)) {
              lastValidDate=new Date(subelement.lastApprovedDate);
              if(obj.type=="SH"){
                selectedDate=new Date(subelement.requestDate);
              }
              else if (obj.type=="RH"){
                selectedDate=new Date(subelement.approvedDate);
              }
              else {
                selectedDate=new Date(subelement.zh_effective_date);
              }
           
              if(lastValidDate.getTime()>selectedDate.getTime() || lastValidDate.getTime()>=selectedDate.getTime()){
                this.confirmDialog.showMessage("Effective date cannot be less than the last approved date for the district "+ subelement.districtName,() => { });
                valid=false;
                if(obj.type=="SH"){
                  subelement.serror=true;
                }
                else if(obj.type=="RH")
                {
                  subelement.rerror=true;
                }
                else
                {
                  subelement.zerror=true;
                }
                return;
              }
            }
            
          }
  
        });











           if(!this.IsNullorEmpty(element.zhRec) || !this.IsNullorEmpty(element.zhComments) || !this.IsNullorEmpty(element.zh_effective_date)){

          if(this.IsNullorEmpty(element.zhRec) || this.IsNullorEmpty(element.zhComments) || this.IsNullorEmpty(element.zh_effective_date)){   
            this.confirmDialog.showMessage("ZH Price, ZH PD, Comments and Effective Date are mandatory. Please fill all four for "+element.districtName + " district",() => { });
            valid=false;
            element.zerror=true;
            return;
          }

        }
        else
        {
          empty=true;
        }
      }




      if(!empty){
        let curDate:Date=new Date();
        let lastValidDate:Date=new Date(curDate.getFullYear(),curDate.getMonth(),curDate.getDate());
        let selectedDate:Date;
        if (!this.IsNullorEmpty(element.lastApprovedDate)) {
          lastValidDate=new Date(element.lastApprovedDate);
          if(obj.type=="SH"){
            selectedDate=new Date(element.requestDate);
          }
          else if (obj.type=="RH"){
            selectedDate=new Date(element.approvedDate);
          }
          else {
            selectedDate=new Date(element.zh_effective_date);
          }
       
          if(lastValidDate.getTime()>selectedDate.getTime() || lastValidDate.getTime()>=selectedDate.getTime()){
            this.confirmDialog.showMessage("Effective date cannot be less than the last approved date for the district "+element.districtName,() => { });
            valid=false;
            if(obj.type=="SH"){
              element.serror=true;
            }
            else if(obj.type=="RH")
            {
              element.rerror=true;
            }
            else
            {
              element.zerror=true;
            }
            return;
          }
        }
        
      }


      element.error=undefined;
      element.serror=undefined;
      element.zerror=undefined;
      element.rerror =undefined;
      obj.detail.push(element);      
      
      
      
    });











   
    if(!valid) return;
    this.loader.show(true);
    this.regionService.postPriceDetail(obj).subscribe(
        rdata => {
            if (rdata.resp_code == "200") {
            this.checkZHhasvalues();
            this.confirmDialog.saveMessage("Data Saved !", () => {

                    this.getPricingDetailData();     
            this.checkZHhasvalues();
            });    
                    
            this.loader.show(false);
            return
          }
          if (rdata.resp_code == "403") {
            this.confirmDialog.showMessageRole(rdata.resp_msg, () => {  
                localStorage.clear(); 
                this.regionService.LoginData.emit(false);
                this.router.navigate(['/login']);
           
                });  
            return
          }
          else
          {
            this.confirmDialog.showMessage("Data Not Saved",() => { });  
          }
        },
        err => {
          alert()
        }
    );
 
    
  }  
  Disabled(type):boolean {

    var disabled=false;
    var roles=this.tokenStorage.getUserRole();


    if(roles.indexOf("1")!=-1){

  
      if(type=="shRec" && roles.indexOf("3")==-1){ 
        disabled=true;
      }
      if(type=="rshRec" && roles.indexOf("2")==-1){ 
     
       disabled=true;
      }
      if(type=="zhRec" && roles.indexOf("5")==-1){ 
     
        disabled=true;
       }

      
      if(type=="shComments" && roles.indexOf("3")==-1){ 
       disabled=true;
      }

      if(type=="rshComments" && roles.indexOf("2")==-1){ 
       disabled=true;
      }
      if(type=="zhComments" && roles.indexOf("5")==-1){ 
        disabled=true;
       }
      
   }




    if(roles.indexOf("3")!=-1){

         if(type=="rshRec"){ 
          disabled=true;
         }
         if(type=="rshComments"){ 
          disabled=true;
         }

         if(type=="zhRec"){ 
          disabled=true;
         }
         if(type=="zhComments"){ 
          disabled=true;
         }
       
    }
    
   if(roles.indexOf("2")!=-1){


    if(type=="shRec"){ 
     disabled=true;
    }
    if(type=="shComments"){ 
     disabled=true;
    }
    if(type=="zhRec"){ 
      disabled=true;
     }
     if(type=="zhComments"){ 
      disabled=true;
     }
   }

   if(roles.indexOf("4")!=-1){


    if(type=="shRec"){ 
     disabled=true;
    }
    if(type=="shComments"){ 
     disabled=true;
    }
    if(type=="rshRec"){ 
      disabled=true;
     }
     if(type=="rshComments"){ 
      disabled=true;
     }
   }




   if(roles.indexOf("5")!=-1){

  
    if(type=="shRec"){ 
     disabled=true;
    }
    if(type=="shComments"){ 
     disabled=true;
    }
  
   }



    return disabled
  }
  changeRate(type:string){
    this.rateLabel=type;
    this.wspEnable =!this.wspEnable;
  }

  showHidePrice(){
    this.showPriceColumns=!this.showPriceColumns
  }
  showAdmin(){
    var roles=this.tokenStorage.getUserRole();
    this.isAdmin=false;
    this.isUser=false;
    if(roles && roles.indexOf("1")!=-1){
        this.isAdmin=true;
    }
    if(roles && roles.indexOf("4")!=-1){
      this.isAdmin=true;
    }
    
    if(roles && (roles.indexOf("2")!=-1 || roles.indexOf("3")!=-1  || roles.indexOf("5")!=-1    )  ){
      this.isUser=true;
    }

  }

  downloadData(){

    

    window.open("https://app.powerbi.com/links/YOBrAX7YRo?ctid=62cabb44-c579-4103-b18b-be08807d2114&pbi_source=linkShare", "_blank");


    // this.regionService.XLsExportReportData(this.selectedRegion.regionId,this.selectedRegion.stateId,this.selectedProductCat).subscribe((response: any) => { //when you use stricter type checking
     
    //   var url = window.URL.createObjectURL(response);
     
    //   const a = document.createElement('a');
    //   a.href = url;
    //   a.download = 'regiontradedata.xls';
    //   a.click();
    //   window.URL.revokeObjectURL(url);
   
    // }), (error: any) => console.log('Error downloading the file'), //when you use stricter type checking
    //              () => console.info('File downloaded successfully');
  }
 
}

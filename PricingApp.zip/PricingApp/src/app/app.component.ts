import { Component, OnInit } from '@angular/core';
import { TokenStorageService } from './_services/token-storage.service';
import { Router } from '@angular/router';
import { environment } from '../environments/environment';
import { MyGlobal } from './_services/myglobal.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { v4 as uuidv4 } from 'uuid';
import { NgIdleService } from './_services/ng-idle.service';
import { AuthService } from './_services/auth.service';
import { LoaderService } from './_services/loader.service';
import { LoginService } from './_services/login.service';
import { BehaviorSubject } from 'rxjs';
import { ReportService } from './_services/report.service';
import { ConfirmDialogService } from './confirm-dialog/confirm-dialog.service';

declare function ShowHideMenu(): any;


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
    providers: [
        NgIdleService
    ]
})
export class AppComponent implements OnInit {
    isLogIn = false;
    showAdminBoard = false;
    showModeratorBoard = false;
    username: string | undefined;
    deviceType: string | undefined;
    deviceDetails: string | undefined;
    idleTimerLeft: string;
    timeRemain: number;
    isLoggedIn: BehaviorSubject<boolean> = this.login.isLoggedIn;
    isLoading: BehaviorSubject<boolean> = this.loader.isLoading;
    showAdminMenu:boolean=false;

    showSchemeMenu:boolean=false;
    showAreaFilters:boolean=true;
    areaFilterData:any;
    regions:any;
    states:any;
    pricingDetailData:any;
    selectedRegion:any;
    selectedState:any;
    selectedReportType:string="M";
    selectedProductCat:string="DCFT";
    selectProductCatName:string="DCFT";
    newRoles;
    curRole;
    copyPdValues;

    regionShow:any = true;
    productShow :any = true;
    statesShow :any = true;
    constructor(
        private tokenStorage: TokenStorageService,
         private login:LoginService,
         private loader: LoaderService,
         private authService: AuthService, 
         private ngIdle: NgIdleService, 
         private GlobalVariable: MyGlobal, 
         private router: Router, 
         private tokenStorageService: TokenStorageService, 
         private deviceService: DeviceDetectorService, 
         private regionService:ReportService,
         private _LoaderService:  LoaderService,
         private _ConfirmDialogService :  ConfirmDialogService 
     
         ) { }
    
    ngOnInit(): void {
     
    this.regionService.FilterData.subscribe(res =>
            {
                this.productShow = this.statesShow  = res;
            })

        if(location.pathname == "/role" || location.pathname == "/scheme" )
        {
            this.showAreaFilters =false;
        }

      
           this.regionService.LoginData.subscribe(res =>
            {
                this.isLogIn = res;
            })
        this.newRoles =  this.tokenStorage.getUserRole()?.indexOf("3")!=-1 ? "SH" :this.tokenStorage.getUserRole()?.indexOf("5")!=-1 ?  "ZH" :   this.tokenStorage.getUserRole()?.indexOf("2")!=-1? 'RH' :"AD";
        this.username = "";
        this.isLogIn =  !!this.tokenStorageService.getToken();
        this.initTimer(environment.idleTimeinMin, 1);
        this.GlobalVariable.userName = this.tokenStorageService.getUser();
        this.showAdmin();
        if (this.isLogIn) {
            this.login.login();
            const user = this.tokenStorageService.getUser();
            this.GlobalVariable.userName=user;
            this.username = this.GlobalVariable.userName;

          

            this.getAreaFiterData();
        } else {
            this.login.logout();
             
        }
        window.addEventListener('storage', (event) => {
          if (event.storageArea == localStorage) {
              if (this.isLogIn) {
                  let token = localStorage.getItem('auth-token');
                  if (token == undefined) {
                      //alert("Ooops.... Session expired.");
                      this.isLogIn = false;
                      this.login.logout();
                        this.tokenStorageService.signOut();
                        NgIdleService.runTimer = false;
                        this.router.navigate(['/login']);
                  }
              }
                  
              }
          });
    }
    openHideMenu(menu:number){
             // this.showAreaFilters=false;

         if(menu==0){
            this.showAreaFilters=true;
            //this.getAreaFiterData();
            this.getPricingDetailData();
           // this.getRegionStates();
            
        }
        if(menu==2){
            this.showAreaFilters=false;
    
            
        }
     
        if(menu==3){
            this.showAreaFilters=true;
    
            
        }

        ShowHideMenu();
    }
    formatTimeLeft = (time: number) => {
        if (time > 0) {
            let seconds = Math.trunc(time / 1000);
            let min = 0;
            if (seconds >= 60) {
                min = Math.trunc(seconds / 60);
                seconds -= (min * 60);
            }
            return `${min}:${seconds}`;
        } else {
            return `0:0`;
        }
    }
    initiateFirstTimer = (status: string) => {
        switch (status) {
            case 'INITIATE_TIMER':
                break;

            case 'RESET_TIMER':
                break;

            case 'STOPPED_TIMER':
                this.logout();
                break;

            default:
                this.idleTimerLeft = this.formatTimeLeft(Number(status));
                break;
        }
    }

    initiateSecondTimer = (status: string) => {
        switch (status) {
            case 'INITIATE_SECOND_TIMER':
                break;

            case 'SECOND_TIMER_STARTED':
                break;

            case 'SECOND_TIMER_STOPPED':
                this.logout();
                break;

            default:
                //this.secondTimerLeft = status;
                break;
        }
    }
    initTimer(firstTimerValue: number, secondTimerValue: number): void {
        // Timer value initialization
        this.ngIdle.USER_IDLE_TIMER_VALUE_IN_MIN = firstTimerValue;
        this.ngIdle.FINAL_LEVEL_TIMER_VALUE_IN_MIN = secondTimerValue;
        // end

        // Watcher on timer
        this.ngIdle.initilizeSessionTimeout();
        this.ngIdle.userIdlenessChecker.subscribe((status: string) => {
            this.initiateFirstTimer(status);
        });

        this.ngIdle.secondLevelUserIdleChecker.subscribe((status: string) => {
            this.initiateSecondTimer(status);
        });

    }
    
    logout(): void {
        
        //if (this.isLogIn) {
            this.isLogIn = false;
            this.tokenStorageService.signOut();
            this.login.logout();
            NgIdleService.runTimer = false;
            this.router.navigate(['/login']);
        //}
    }
    showAdmin(){
        var roles=this.tokenStorageService.getUserRole();
        this.showAdminMenu=false;
        if(roles && roles.indexOf("1")!=-1  ){
            this.showAdminMenu=true;
        }

        if( roles && roles.indexOf("6")!=-1 )
        {
            this.showSchemeMenu=true;
        }
    }

    getAreaFiterData(){

       // this.loader.show();
        this.regions = [];
        this.regionService.getAreaFiterData(this.GlobalVariable.userName).subscribe(
            rdata => {

                if (rdata.resp_code == "200") {
                    this.areaFilterData=rdata.resp_body;

                     if(this.areaFilterData.length > 0)
                     {
                        this.areaFilterData.forEach(element => {



                            if(!this.regions.find(x=>x.regionId==element.regionId))
                            {
                              if(!this.selectedRegion) {
                                this.selectedRegion=element;

                              // this.regionService.RegionData.emit(this.selectedRegion);

                                this.regionService.SelectedRegion = this.selectedRegion.regionId;

                                this.getRegionStates();
                              }
                                 this.regions.push(element);
                            }                  
                          });
                        
                     }

                     else
                     {
                    
                        this._ConfirmDialogService.showMessage('No Data Found - Please select the Region and State in Admin Panel', ()=> {});
                      
                     }
                 
                 
                
                   
                }
            },
            err => {
                this.loader.show(false);
                alert( err.message);
              
            }
        );


      }
     getRegionStates() {

        this.states=[];
        this.selectedState=undefined;
        this.areaFilterData.forEach(element => {

            if(element.regionId==this.selectedRegion.regionId)
            {
      
              if(!this.states.find(x=>x.stateId==element.stateId))
              {
                if(!this.selectedState) 
                 { 
                     this.selectedState=element;
                 }
                   this.states.push(element);                
              }           

          } 

       
          
         
        });

        this.regionService.RegionData.emit(this.selectedRegion);
      

        //this.selectedState = this.states?.[0]
        //this.loader.show();
        //this.getPricingDetailData();

       
        if(location.pathname == "/role" ||  location.pathname == "/scheme")
        {
          return
          
        }
        else
        {
            
            this.getPricingDetailData();
        }
      }

      getPricingDetailData(){
    
        if(this.selectedProductCat=="DALMIA"){
          this.selectProductCatName="DCFT";
        }else if(this.selectedProductCat=="DSP"){
          this.selectProductCatName="DDSP";
        }else{
          this.selectProductCatName=this.selectedProductCat;
        }
        if(this.selectedRegion){

     
         

          let roles =  this.tokenStorage.getUserRole()?.indexOf("3")!=-1 ? "SH" : this.tokenStorage.getUserRole()?.indexOf("5")!=-1 ?  "ZH" : 'RH';
       // let roles=this.tokenStorage.getUserRole().indexOf("3") != -1 ? 'SH' : 'RH';

 
       this.regionService.SelectedRegion = this.selectedRegion.regionId;
       
    
       this.loader.show(true);
         this.regionService.getPriceDetail(this.selectedRegion.regionId,this.selectedState.stateId,this.selectedProductCat,roles).subscribe(
            rdata => {
          
                let data:any={};
                if (rdata.resp_code == "200") {
        
                    if(rdata.resp_body.priceDetail.length === 0) {            
                        this.loader.show(false); 
                    this._ConfirmDialogService.showMessage("No Data Found", () => { });    

                    data["pricedata"]= [];
                    this.regionService.GetData.emit(data); 
                 
                    return
                     }
    
                         this.pricingDetailData=rdata.resp_body.priceDetail;                       
                        data["region"]=this.selectedRegion;
                        data["state"]=this.selectedState;
                        data["category"]=this.selectedProductCat;
                        data["categoryname"]=this.selectProductCatName;
                        data["pricedata"]=this.pricingDetailData;
                        data["isZHAvailForState"] = rdata.resp_body.isZHAvailForState;  
                        this.regionService.GetData.emit(data);  
                        this.loader.show(false);                 
                        
                }

                else
                {
                    this.loader.show(false);
                    this._ConfirmDialogService.showMessage("No Data Found", () => { });
                 
                }
            },
            err => {
                this.loader.show(false);
                this._ConfirmDialogService.showMessage(err.message, () => { });
            }
        );
     

          }

          
      }
    
      
    
}
     

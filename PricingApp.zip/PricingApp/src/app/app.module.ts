import { APP_INITIALIZER, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule,HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { CommonModule } from "@angular/common";
import { ToastrModule } from 'ngx-toastr';
import { ISlimScrollOptions, NgSlimScrollModule, SLIMSCROLL_DEFAULTS } from 'ngx-slimscroll';

// Anguler material
import { AdminGuard } from './admin/admin.guard';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import {MatSidenavModule} from '@angular/material/sidenav';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown'; 
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatListModule} from '@angular/material/list';
// Component

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
//Services
//Modules


import { ConfirmDialogModule } from './confirm-dialog/confirm-dialog.module';

//Directive
import { NumericValidatorDirective } from './directives/numeric.directive';
import { NumericDirective } from './directives/numericwithdecimal.directive';
import { LoaderInterceptor } from './_services/loader.interceptor';
import { LoginComponent } from './login/login.component';
import { PricingComponent } from './pricing/pricing.component';
import { RoleComponent } from './roles/role.component';
import { PositivePipe } from './pipes/negative-to-postive.pipes';
import { SchemeComponent } from './scheme/scheme.component';
import { SchemeApprovalComponent } from './scheme-approval/scheme-approval.component';



@NgModule({
  declarations: [ 
    NumericValidatorDirective,
    NumericDirective,
    PositivePipe,
    AppComponent, 
	  HomeComponent,
    LoginComponent,
    PricingComponent,
    RoleComponent,
    SchemeComponent,
    SchemeApprovalComponent
    ],

  imports: [ 
    FormsModule,
    ReactiveFormsModule,
    BrowserModule, 
    HttpClientModule ,
    ConfirmDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSlideToggleModule,
    MatSidenavModule,
    MatListModule,
    
    CommonModule,
    NgMultiSelectDropDownModule,
    NgSlimScrollModule,
    ToastrModule.forRoot({
      positionClass :'toast-top-right'
    }),
    RouterModule.forRoot([
      { path: 'home', component: HomeComponent, canActivate: [AdminGuard] },
      { path: 'login', component: LoginComponent },
      { path: 'pricing', component: PricingComponent , canActivate: [AdminGuard]},
      { path: 'scheme', component: SchemeComponent, canActivate: [AdminGuard]},
      { path: 'approval', component: SchemeApprovalComponent },
      { path: 'role', component: RoleComponent , canActivate: [AdminGuard]},
      { path: '', redirectTo: 'login', pathMatch: 'full' }
    ]),
  BrowserAnimationsModule],
  bootstrap: [AppComponent],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true },
    { provide: SLIMSCROLL_DEFAULTS,useValue: { alwaysVisible : false }  }
  ]
})
export class AppModule { }

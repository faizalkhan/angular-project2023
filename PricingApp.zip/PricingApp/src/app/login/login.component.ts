import { Component, OnInit,  ViewChild } from '@angular/core';
import { AuthService } from '../_services/auth.service';
import { TokenStorageService } from '../_services/token-storage.service';
import { timer } from 'rxjs';
import { Router } from '@angular/router';
import { MyGlobal } from '../_services/myglobal.service';
import { CountdownComponent } from 'ngx-countdown';
import { ReportService } from '../_services/report.service';
import { ToastrService } from 'ngx-toastr';
import { ConfirmDialogService } from '../confirm-dialog/confirm-dialog.service';
import { LoaderService } from '../_services/loader.service';

declare function toggelePass():any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [ MyGlobal ]
})
export class LoginComponent implements OnInit  {
    status = 'start';
    @ViewChild('countdown') counter: CountdownComponent;
 
    showPassword:boolean=false;
    form: any = {};
    isLoggedIn = false;
    isLoginFailed = false;
    errorMessage = '';
    isOTPGenerated = false;
    submitted = false;
    smstimer= "";
    retrytimer = "";
    source = timer(0);

    public showResendBtn: boolean = false;
    //private subscription: Subscription;
    //private timer: Observable<any>;

    constructor(
        private GlobalVariable: MyGlobal, 
        private router: Router, 
        private authService: AuthService, 
        private tokenStorage: TokenStorageService,
        private report :ReportService,
        private toaster:ToastrService,
        private loader: LoaderService,
        private confirmDialog:ConfirmDialogService) { }
    
   
    ngOnInit(): void {
        document.body.classList.add('logoin-bg');
        if (this.tokenStorage.getToken()) {
            this.isLoggedIn = true;
            this.router.navigate(['/pricing']);
        } else {
            this.isLoggedIn = false;

        }
        //this.toggele();
    }
    
    get f() { return this.form.controls; }
    IsNullorEmpty(value): boolean {
        if (value == undefined || value == "") {
            return true;
        }
        return false;;
    }
    onSubmit(): void {
         if (this.IsNullorEmpty(this.form.username)) {
            this.confirmDialog.showMessage("Please enter Email",() => { });
            //this.toaster.success("Enter email id");
            //this.toaster.error("Enter email id");
            return;
        } 
        if (this.IsNullorEmpty(this.form.password)) {
            this.confirmDialog.showMessage("Please enter Password",() => { });
            return;
        }
        this.authService.login({"username":this.form.username,"password":this.form.password}).subscribe(
        rdata => {
            if (rdata.resp_code == "200") {
                if( rdata.resp_body.token !="" && rdata.resp_body.token !=null){
                    window.localStorage.clear();
                    this.tokenStorage.saveToken(rdata.resp_body.token);
                    this.tokenStorage.saveUser(this.form.username);
                    this.GlobalVariable.userName=this.form.username;
                    this.tokenStorage.saveRefId(rdata.resp_body.employeeId);
                    this.tokenStorage.saveUserRole(rdata.resp_body.roleId);
                    this.isLoggedIn=true;
                    window.location.reload();
                } else {
                    this.confirmDialog.showMessage("Invalid User Details",() => { });
                }
            }else{
                this.confirmDialog.showMessage("Invalid User Details",() => { });
            }
        },
        err => {
            this.loader.show(false);
            alert("Error")
            //this.confirmDialogService.showMessage(err.message, () => { });
        }
        );
        
        //this.getAreaFiterData();
        
    }

    reloadPage(): void {
        window.location.reload();
    }
    numberOnly(event): boolean {
        const charCode = (event.which) ? event.which : event.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    }
    toggele(){
        this.showPassword=!this.showPassword;
        //toggelePass();
    }
}

import { HTTP_INTERCEPTORS, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import {LoaderService} from './loader.service';
import { Router } from '@angular/router';
import { AuthService } from '../_services/auth.service';
import { TokenStorageService } from '../_services/token-storage.service';
import { MyGlobal } from '../_services/myglobal.service';
import { ConfirmDialogService } from '../confirm-dialog/confirm-dialog.service';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError, filter, finalize, switchMap, take } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class LoaderInterceptor implements HttpInterceptor  {


  private isRefreshing = false;
  private refreshTokenSubject: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  constructor(private loader: LoaderService,private router: Router,
    private confirmDialogService:ConfirmDialogService,
    private authService:AuthService,
    private token:TokenStorageService,
    private gVar:MyGlobal
    ) {

  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>  {
       // this.loader.show(true);
 
          let authReq = req;
          const token = this.token.getToken();
          if (token != null) {
            authReq = this.addTokenHeader(req, token);
          }
          return next.handle(authReq).pipe(catchError(error => {
            if (error instanceof HttpErrorResponse  && error.status === 401) {//&& !authReq.url.includes('auth/signin')
              return this.handle401Error(authReq, next);
            }
            return throwError(error);
          }),finalize(() => {}));

          


    // return next.handle(req).pipe(
    //   tap(evt => {
    //     if(req.url.indexOf("refreshToken")==-1){
    //    if (evt instanceof HttpResponse) {
    //       console.log("event tap"+evt.status);
    //         if(evt.body && (evt.body.resp_code || evt.body.response_code))
    //          {
    //            if(evt.body.resp_code=="DM1019" || evt.body.response_code=="DM1019"){
    //               this.token.signOut();
    //               this.router.navigate(['/login']);
    //            }else if(evt.body.resp_code=="9000"){
    //              //this.getRefreshToken();
    //              console.log("refresh token");
    //              //this.router.navigate(['/pricing']);
    //              req.headers.set("Authorization",'Bearer '+this.token.getToken());
    //              req=req.clone();
    //              console.log(req);
    //              next.handle(req);
    //            }
    //          }
    //     }
    //   }
    //   }),
    //   finalize(() => this.loader.hide())
    // );

  }

  private handle401Error(request: HttpRequest<any>, next: HttpHandler) {
    if (!this.isRefreshing) {
      this.isRefreshing = true;
      this.refreshTokenSubject.next(null);
      // const token = this.token.getRefreshToken();
      // if (token)
        return this.authService.refreshToken().pipe(
          switchMap((token: any) => {
            this.isRefreshing = false;
            this.token.saveToken(token.resp_body.token);
            this.refreshTokenSubject.next(token.resp_body.token);
            return next.handle(this.addTokenHeader(request, token.resp_body.token));
          }),
          catchError((err) => {
            this.isRefreshing = false;
            this.token.signOut();
            return throwError(err);
          })
        );
    }
    return this.refreshTokenSubject.pipe(
      filter(token => token !== null),
      take(1),
      switchMap((token) => next.handle(this.addTokenHeader(request, token)))
    );
  }
  private addTokenHeader(request: HttpRequest<any>, token: string) {
    return request.clone({ headers: request.headers.set("Authorization", 'Bearer '+token) });
  }

  
  getRefreshToken(){
    let retData=this.authService.refreshToken().toPromise();
    retData.then((rdata) =>{
            if (rdata.resp_code == "200") {
              // this.gVar.accesstoken = rdata.resp_body.token;
              // this.gVar.refreshToken = rdata.resp_body.token;
              // this.token.saveToken(rdata.resp_body.token);
            } else {
                this.confirmDialogService.showMessage(rdata.resp_msg, () => { });
            }
    }, function(error){
        //handle error
    });                  
}
}
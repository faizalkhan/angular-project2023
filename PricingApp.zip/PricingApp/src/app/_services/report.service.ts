import { EventEmitter, Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { MyGlobal } from './myglobal.service';
import { TokenStorageService } from '../_services/token-storage.service';


const AUTH_API = environment.apiURL + environment.apiPATH ;



@Injectable({
  providedIn: 'root'
})
export class ReportService  {
    GetData= new EventEmitter<any>();

    LoginData = new EventEmitter<any>();

    FilterData = new EventEmitter<any>();

    RegionData = new EventEmitter<any>();

    SelectedRegion = "";


    constructor(private gVaraible: MyGlobal, private http: HttpClient,private tokenStorage:TokenStorageService) {  }
    result = new Observable<any>();
    getHeader(){
        const httpHeaer = {
            headers: new HttpHeaders({
                'Authorization':'Bearer '+this.tokenStorage.getToken(),
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Origin, Content-Type, Accept'
            })
        };
        return httpHeaer;
    }

    getAreaFiterData(emailId): Observable<any> {
        return this.http.get(AUTH_API + 'api/v1/authorize/getFilter',this.getHeader());
    }
    getPriceDetail(regionid,stateid,productCat, roles?): Observable<any> {
        return this.http.get(AUTH_API + 'api/v1/pricedata/getPriceDetail?regionid='+regionid+'&stateid='+encodeURIComponent(stateid)+'&productCat='+productCat+'&role='+roles,this.getHeader());
    }
    postPriceDetail(regiontradedata:any): Observable<any> {
        return this.http.post(AUTH_API + 'api/v1/pricedata/savePriceDetail',regiontradedata,this.getHeader());
    }

   
    postSchemeDetail(schemedata:any): Observable<any> {
        return this.http.post(AUTH_API + 'api/v1/schemesdata/schemePostConfig',schemedata,this.getHeader());
    }

    getUserListing(): Observable<any> {
        return this.http.get(AUTH_API + 'api/v1/admin/getUserList',this.getHeader());
    }
    
    getSchemeDetail(regionid): Observable<any> {
        return this.http.get(AUTH_API + 'api/v1/schemesdata/schemeGetConfig?regionid='+regionid,this.getHeader());
    }
    removeSchemeDetail(schemedatalist:any): Observable<any> {
 
        return this.http.post(AUTH_API + 'api/v1/schemesdata/schemeDeleteConfig',schemedatalist,this.getHeader());
    }

    getRoleListing(userId): Observable<any> {
        return this.http.get(AUTH_API + 'api/v1/admin/getUserRoles?userId='+userId,this.getHeader());
    }
    getAreaListing(userId): Observable<any> {
        return this.http.get(AUTH_API + 'api/v1/admin/getUserArea?userId='+userId,this.getHeader());
    }
    postUser(userdata:any): Observable<any> {
        return this.http.post(AUTH_API + 'api/v1/admin/saveUser',userdata,this.getHeader());
    }
    postRoleArea(roleareadata:any): Observable<any> {
        return this.http.post(AUTH_API + 'api/v1/admin/saveUserRoleArea',roleareadata,this.getHeader());
    }
    removeUser(userdata:any): Observable<any> {
        return this.http.post(AUTH_API + 'api/v1/admin/deleteUser',userdata,this.getHeader());
    }

    XLsExportReportData(regionid,stateid,productCat): Observable<any> {
        return this.http.get(AUTH_API + 'api/v1/pricedata/exportReport?regionId='+regionid+'&stateId='+encodeURIComponent(stateid)+'&productCat='+productCat,  {
            responseType: "blob",
            headers: new HttpHeaders({
                'Authorization':'Bearer '+this.tokenStorage.getToken(),
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Origin, Content-Type, Accept',
                "Content-Type":"application/json"
            })
          });
    }
    
}

import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
})
export class MyGlobal {
    encryptdecryptMobile: string;
    encryptdecryptCode: string;
    tokenID: string;
    accesskey: string;
    accesstoken: string;
    active: string;
    refreshToken: string;
    userType: string;
    contactName: string;
    userName:string;
    userFilter:any;
    userRegion:any;
    userId:any;
}

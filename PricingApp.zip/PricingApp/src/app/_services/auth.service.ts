import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { MyGlobal } from '../_services/myglobal.service';
import { TokenStorageService } from './token-storage.service';


const AUTH_API = environment.apiURL + environment.apiPATH 

const AUTH_GET_API = 'https://mobileqacloud.dalmiabharat.com/dalmiabharat-smartd/';
const API_KEY = environment.apiaccessKey;


const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' })
};
const httpKeyOption = {
    headers: new HttpHeaders({
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Origin, Content-Type, Accept'
    })
};


@Injectable({
  providedIn: 'root'
})
export class AuthService {
    encryptdecryptMobile: string;
    encryptdecryptCode: string;

    constructor(private gVaraible: MyGlobal, private http: HttpClient,private tokenStorage:TokenStorageService) { }
    result = new Observable<any>();
    
    getHeader(){
        const httpHeaer = {
            headers: new HttpHeaders({
                'Authorization':'Bearer '+this.tokenStorage.getToken(),
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Origin, Content-Type, Accept'
            })
        };
        return httpHeaer;
    }
    login(credentials): Observable<any> {
        return this.http.post(AUTH_API + 'api/v1/authorize/validateUser', {
            emailId: credentials.username, 
            password: credentials.password, 
        }, httpKeyOption);
    }
    
    encryptpass(credentials): Observable<any> {
         return this.http.get(AUTH_GET_API + 'getkey?paramater=' + credentials.mobilenumber + '&type=encrypt', httpKeyOption);
    } 

    getAreaFiterData(): Observable<any> {
        return this.http.get(AUTH_API + 'api/v1/authorize/getFilter?emailId='+this.gVaraible.userName);
    }

    
    // submit(user): Observable<any> {
    //     const httpOtpSubmit = {
    //         headers: new HttpHeaders({
    //             'Content-Type': 'application/json',
    //             'Access-Control-Allow-Origin': '*',
    //         })
    //     };
    //     return this.http.post(AUTH_API + 'checkValidUserNewOTP', {
    //         referenceId:this.gVaraible.referenceId, // userid
    //         mobileNumber: null ,// this.gVaraible.encryptdecryptMobile,
    //         appName: environment.appName,
    //         code: this.gVaraible.encryptdecryptCode, //otp 
    //         imei: null,
    //         userId: this.gVaraible.referenceId, // userid
    //         gcmId: "dgmlGXV1RAuPHeHCAWxTJz:APA91bHwy0ciouIMfkeOKrbanZ1SaP3QLdIJzFnSHC_3KhCd9zo0jp41AYpgdhGnVxOMc2ywaJ",
    //         otpTokenId: this.gVaraible.otpTokenID,
    //         appVersion: environment.appVersion
    //     }, httpOtpSubmit);
    // }
    logout(): Observable<any> {
        const logoutOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*',
                'X-Access-Token': this.gVaraible.accesstoken
            })
        };
        return this.http.get(AUTH_API + 'logout', logoutOptions);
    }
   
    refreshToken(): Observable<any> {
        return this.http.get(AUTH_API + 'api/v1/authorize/refreshtoken', this.getHeader());
    }
}

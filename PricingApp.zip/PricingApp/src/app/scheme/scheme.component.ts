
import { AfterViewInit, Component,ChangeDetectorRef, ElementRef, EventEmitter,  Input,  OnChanges,  OnInit,  Output,  SimpleChanges,  ViewChild, ViewChildren  } from '@angular/core';
import { ReportService } from '../_services/report.service';
import { DatePipe } from '@angular/common';
import { SlimScrollOptions, SlimScrollEvent } from 'ngx-slimscroll';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { NgForm } from '@angular/forms';
import { MyGlobal } from '../_services/myglobal.service';
import { TokenStorageService } from '../_services/token-storage.service';
import { ConfirmDialogService } from '../confirm-dialog/confirm-dialog.service';
import { Router } from '@angular/router';
import { LoaderService } from '../_services/loader.service';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';



declare function HideMenu(): any;


@Component({
  selector: 'app-home',
  templateUrl: './scheme.component.html',
  styleUrls: ['./scheme.component.css'],
  providers: [DatePipe],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class  SchemeComponent implements OnInit {

  schemeDetailData :any;  
  opts: SlimScrollOptions; 
  isLoading: BehaviorSubject<boolean> = this.loader.isLoading;




    constructor(
      private GlobalVariable:MyGlobal, 
      private regionService:ReportService,
      private tokenStorage: TokenStorageService,
      private confirmDialog:ConfirmDialogService,
      private cdref : ChangeDetectorRef,
      private router: Router,
      private loader: LoaderService,
      private _ConfirmDialogService :  ConfirmDialogService 
      ) {
       
       
       }

 
  
    ngOnInit(): void {



      this.regionService.FilterData.emit(false);

    
      HideMenu();
      this.opts = new SlimScrollOptions({
        position:'right',
        barWidth: "8",
        barBorderRadius:"20",
        alwaysVisible:true,
        visibleTimeout: 1000,
        alwaysPreventDefaultScroll: true
      });
       
      document.body.classList.remove('logoin-bg');
      document.body.classList.add('fixed-nav');

      

     let regionId;
     this.regionService.RegionData.subscribe((resdata:any) => 
     {
       
         console.log("region", resdata.regionId)
 
         regionId = resdata.regionId;
         this.getPSchemeData(regionId)
         return



         
     });
 
    
     this.getPSchemeData(this.regionService.SelectedRegion)

  }




  getPSchemeData(regionId?:any) {
    

 

          this.loader.show(true);
  
            this.regionService.getSchemeDetail(regionId).subscribe(
               rdata => {
             
                   let data:any={};
                   if (rdata.resp_code == "200") {
           
                       if(rdata.resp_body.length === 0) {            
                           this.loader.show(false); 
                       this._ConfirmDialogService.showMessage("No Data Found", () => { });    
                    
                       return
                        }
       
                            this.schemeDetailData = rdata.resp_body;                       
                            this.loader.show(false);         
                            
                 
                           
                   }
       
                   else
                   {
                       this.loader.show(false);
                       this._ConfirmDialogService.showMessage("No Data Found", () => { });
                    
                   }
               },
               err => {
                   this.loader.show(false);    
                   this._ConfirmDialogService.showMessage(err.message, () => { });
               }
           );
   


 
 

  

      
  }


  IsNullorEmpty(value): boolean {
   
    if (value == undefined || value == "") {
        return true;
    }
    return false;
  }

  submitData()
  {
 
     let valid:boolean=true;

    let empty:boolean=false;

    var obj:any={};



    obj.detail=[];



    this.schemeDetailData?.forEach(element => {

      empty=false;

      element.regionId =    element.regionId?.toString();
      element.stateId =     element.stateId?.toString();
      element.startDate =   element.startDate?.toString();
      element.endDate=      element.endDate?.toString()
      element.postingDate = element.postingDate?.toString();
   
       if(element.regionId?.toString().includes(',')  || element.stateId?.toString().includes(',') ||   
          element.startDate?.toString().includes(',')  ||  element.endDate?.toString().includes(',') ||      
          element.postingDate?.toString().includes(',')  )
       {
         element.regionId =    element.regionId.toString().replace(/,/g, '');
         element.stateId =     element.stateId.toString().replace(/,/g, '');
         element.startDate =   element.startDate.toString().replace(/,/g, '');
         element.endDate=      element.endDate.toString().replace(/,/g, '');
         element.postingDate = element.postingDate.toString().replace(/,/g, '');
       


       }



       if(!this.IsNullorEmpty(element.regionId) || !this.IsNullorEmpty(element.stateId) || !this.IsNullorEmpty(element.startDate) ||  !this.IsNullorEmpty(element.endDate) 
         || !this.IsNullorEmpty(element.postingDate)) 
       {

        if(this.IsNullorEmpty(element.startDate) ||  this.IsNullorEmpty(element.endDate) ||  this.IsNullorEmpty(element.postingDate))
        {
        this.confirmDialog.showMessage("Region, State ,Start Date, End Date and Posting Date are mandatory. Please fill all the fields", () => { });
 
         element.serror=true;

          valid = false

         return;

      }
        
           if(!(parseInt(element.startDate) <= 31)  ||  !(parseInt(element.endDate) <= 31)   || !(parseInt(element.postingDate) <= 31) )
          {
          this.confirmDialog.showMessage("Date should be 1 to 31", () => { });
   
           element.serror=true;
 
            valid = false
 
           return;

        }
         
     
        
       }
      
       else
       {
           empty = true;
       }





       
        
       element.serror=undefined;

       obj.detail.push(element);    


      

  });




  if(!valid) return;

  this.regionService.postSchemeDetail(obj).subscribe(
      rdata => {
          if (rdata.resp_code == "200") {
      
          this.confirmDialog.saveMessage("Data Saved !", () => {

                  this. getPSchemeData();     
         
          });    
                  
        
          return
        }
        if (rdata.resp_code == "403") {
          this.confirmDialog.showMessageRole(rdata.resp_msg, () => {  
              localStorage.clear(); 
              this.regionService.LoginData.emit(false);
              this.router.navigate(['/login']);
         
              });  
          return
        }
        else
        {
          this.confirmDialog.showMessage("Data Not Saved",() => { });  
        }
      },
      err => {
  
      }
  );










 
}



deleteScheme(id:any)
{

   let objs:any = {}

   objs.detail = [{
 
    "id" : id

   }];



   this.confirmDialog.confirmThis("confirm","Do you want to delete the Scheme?",() => {
    this.regionService.removeSchemeDetail(objs).subscribe(
      rdata => {
        if (rdata.resp_code == "200") {
          this.confirmDialog.saveMessageDialog("Scheme Deleted !",() => {  this.getPSchemeData();    });
         
        
        }
      },
      err => {
        this.confirmDialog.showMessage("System Error Try again !",() => { });
      }
   )},
   
   ()=>{
   
    });

}



}

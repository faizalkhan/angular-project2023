import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SchemeApprovalComponent } from './scheme-approval.component';

describe('SchemeApprovalComponent', () => {
  let component: SchemeApprovalComponent;
  let fixture: ComponentFixture<SchemeApprovalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SchemeApprovalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SchemeApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

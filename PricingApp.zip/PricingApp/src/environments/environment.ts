// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
    production: false,
   // apiURL: "http://localhost:8080",
  // apiURL: "https://mobileapps.dalmiabharat.com",
   apiURL: "https://mobileqacloud.dalmiabharat.com",
   apiPATH: "/pricecapture/",
   // apiPATH: "/price_plan_server/",
    appName: "PRICE PLANER",
    appVersion: "1.00",
    idleTimeinMin: 3000,
    apiaccessKey:"8a1f32b6-7b40-447e-9a96-a54c073ed536",
};


export const environment = {
    production: true,
    apiURL: "https://mobileapps.dalmiabharat.com",
    apiPATH: "/pricecapture/",
    appName: "PRICE PLANER",
    appVersion: "1.00",
    idleTimeinMin: 3000,
    apiaccessKey:"8a1f32b6-7b40-447e-9a96-a54c073ed536",
};

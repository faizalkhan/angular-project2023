﻿function ShowHideMenu(){
    $("#SideBar").toggleClass("open-sidebar");
    $("#navbarResponsive").toggleClass("open-mobile-sidebar");
    $(this).toggleClass("close-togle");
}
function ShowDetails(element) {
    element.classList.add("show-details");
}

function HideDetails(element) {
    element.classList.remove("show-details");
}
function HideMenu(){
    $("#SideBar").removeClass("open-sidebar");
}

function toggelePass(){
    $(".toggle-password").click(function () {

       $(this).toggleClass("fa-eye fa-eye-slash");
       
        var input = $(this).attr("toggle");
        var el=$(this).parents().find("[id='"+input+"']")
        //var input =document.getElementById($(this).attr("toggle"));
        if (el.attr("type") == "password") {
            el.attr("type", "text");
        } else {
            el.attr("type", "password");
        }
    });
}
 
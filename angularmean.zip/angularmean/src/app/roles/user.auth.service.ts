import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { User } from './user';
import { UserRole } from './user.role.enum';

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {

  
  constructor(public router: Router) {


   }



  setToken()
  {
    debugger
    const user: User = { id: 1, username: 'john.doe', role: UserRole.Admin };
    
    localStorage.setItem('currentUser', JSON.stringify(user));
  }








}

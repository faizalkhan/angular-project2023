export enum UserRole {

    Admin = 'Admin',
    Manager = 'Manager',
    User = 'User',

}
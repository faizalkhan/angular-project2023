import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from './user';
import { UserRole } from './user.role.enum';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {
  
  constructor(private router: Router) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

      const requiredRole = route.data['requiredRole'] as UserRole;

      // let getcurrentuser = localStorage?.getItem('currentUser') || '';

      // console.log(getcurrentuser);

      const currentUser = JSON.parse(localStorage?.getItem('currentUser') as any);

      console.log(requiredRole);

      console.log(currentUser);

      if (currentUser && currentUser.role === requiredRole) {
        return true;
      }


    this.router.navigate(['route/unauthorized']);
    return false;
  }
  
}

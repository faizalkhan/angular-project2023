import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { ManagerComponent } from './manager/manager.component';
import { UserComponent } from './user/user.component';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';
import { SigninComponent } from '../components/signin/signin.component';
import { RoleComponent } from './role/role.component';
import { RoleGuard } from './role-guard.guard';
import { UserRole } from './user.role.enum';


const routers: Routes = [



  {
    path : 'route', 

    children : [ 
      { path: 'admin', component: AdminComponent, canActivate: [RoleGuard], data: { requiredRole: UserRole.Admin } },
      { path: 'manager', component: ManagerComponent,  canActivate: [RoleGuard], data: { requiredRole: UserRole.Manager }},
      { path: 'user', component: UserComponent },
      { path : 'unauthorized', component : UnauthorizedComponent}

    ]
   }
 
];

@NgModule({
  declarations: [],
  imports: [
    RouterModule.forRoot(routers),
    CommonModule
  ],

  exports: [RouterModule]
})
export class RolesRoutingModule { }




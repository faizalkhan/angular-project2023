import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RolesRoutingModule } from './roles-routing.module';
import { RoleComponent } from './role/role.component';



@NgModule({
  declarations: [
    RoleComponent
  ],
  imports: [
    RolesRoutingModule,
    CommonModule
  ],
  bootstrap: [RoleComponent]

  
 
})
export class RolesModule { }

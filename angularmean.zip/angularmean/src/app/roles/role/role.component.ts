import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserAuthService } from '../user.auth.service';
import { UserRole } from '../user.role.enum';


const user: User = { id: 1, username: 'john.doe', role: UserRole.Admin };
    
localStorage.setItem('currentUser', JSON.stringify(user)) as any;

@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.css']
})

export class RoleComponent implements OnInit {


  
  constructor(private _UserAuthService : UserAuthService) {
      

   }

  ngOnInit(): void {


  }

}
